﻿namespace Icsp.Open21.Persistence.HonsitenModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.HonsitenModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class HonsitenTenkaiHeaderRepository : IHonsitenTenkaiHeaderRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        /// <summary>
        /// 本支店展開ヘッダリストを取得します
        /// </summary>
        /// <returns>本支店展開ヘッダリスト</returns>
        public virtual IList<HonsitenTenkaiHeader> FindAll()
        {
            return this.dbc.QueryForList(
                "SELECT kesn, hsflg, hstype, method1, method2, method3, method4, method5 " +
                "FROM hstbl_h ",
                (values, no) => this.Map(values, no),
                () => new List<HonsitenTenkaiHeader>());
        }

        /// <summary>
        /// 指定条件の本支店展開ヘッダを取得します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <returns>指定条件の本支店展開ヘッダ</returns>
        public HonsitenTenkaiHeader FindByKesn(int kesn)
        {
            return this.dbc.QueryForObject(
                "SELECT kesn, hsflg, hstype, method1, method2, method3, method4, method5 " +
                "FROM hstbl_h " +
                "WHERE kesn = :p ",
                (values, no) => this.Map(values, no),
                kesn);
        }

        private HonsitenTenkaiHeader Map(object[] values, int rowNo)
        {
            var row = new HonsitenTenkaiHeader((short)values[0]);
            row.IsUseHonsitenZidouSiwakeProcessing = (short)values[1] == 1; // 本支店実行フラグ
            row.HonsitenProcessingType = (HonsitenProcessingType)(short)values[2]; // 本支店処理タイプ
            row.ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists = (ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists)(short)values[3]; // 本支店未登録部門があるときの処理設定
            row.HonsitenTenkaiMethod = (HonsitenTenkaiMethod)(short)values[4]; // 本支店展開方法
            row.IsTenkaiTradingBetweenSameHonsiten = (short)values[5] == 0; // 同一本支店間取引を展開するかどうか
            row.IsSortBySiwakeLineNoBeforeHonsitenTenkai = (short)values[6] == 1; // 本支店展開前行順に並べ替えするかどうか
            row.HonsitenSiwakeCreateOrder = (HonsitenSiwakeCreateOrder)(short)values[7]; // 本支店仕訳の作成順
            return row;
        }
    }
}
