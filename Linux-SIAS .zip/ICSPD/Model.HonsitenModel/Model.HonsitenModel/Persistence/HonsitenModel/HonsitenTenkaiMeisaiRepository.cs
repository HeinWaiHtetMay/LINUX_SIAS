﻿namespace Icsp.Open21.Persistence.HonsitenModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.HonsitenModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class HonsitenTenkaiMeisaiRepository : IHonsitenTenkaiMeisaiRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        /// <summary>
        /// 指定条件の本支店展開明細リストを取得します。
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <returns>本支店展開明細リスト</returns>
        public virtual IList<HonsitenTenkaiMeisai> FindByKesnAndHonsitenKubun(int kesn)
        {
            return this.dbc.QueryForList(
                "SELECT bcod, kicd, hkbn " +
                "FROM hstbl_m " +
                "WHERE kesn = :p ",
                (values, no) =>
                {
                    var row = new HonsitenTenkaiMeisai(kesn, DbNullConverter.ToString(values[0]));
                    row.Kicd = DbNullConverter.ToString(values[1]); // 科目コード
                    row.HonsitenKubun = (HonsitenKubun)(short)values[2]; // 本支店区分
                    return row;
                },
                () => new List<HonsitenTenkaiMeisai>(),
                kesn);
        }
    }
}
