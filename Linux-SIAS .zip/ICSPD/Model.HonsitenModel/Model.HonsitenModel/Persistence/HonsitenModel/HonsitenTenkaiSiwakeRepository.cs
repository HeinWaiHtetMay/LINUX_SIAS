﻿namespace Icsp.Open21.Persistence.HonsitenModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Framework.Data;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Persistence.DenpyouModel;

    /// <summary>
    /// テンポラリテーブルを使用するため、
    /// </summary>
    internal class HonsitenTenkaiSiwakeRepository : IHonsitenTenkaiSiwakeRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private ISiwakeFactory siwakeFactory = null;

        private HonsitenSiwakeCreateOrder honsitenSiwakeCreateOrder;

        public HonsitenTenkaiSiwakeRepository(InjectionContainer container, TemporaryTable honsitenTenkaiSiwakeTemporaryTable, TemporaryTable siwakeBeforeCreateSyouhizeiSiwakeTemporaryTable, HonsitenSiwakeCreateOrder honsitenSiwakeCreateOrder)
        {
            this.HonsitenTenkaiSiwakeTemporaryTable = honsitenTenkaiSiwakeTemporaryTable;
            this.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable = siwakeBeforeCreateSyouhizeiSiwakeTemporaryTable;
            this.honsitenSiwakeCreateOrder = honsitenSiwakeCreateOrder;
            container.InjectDependeciesToAutoInjectionMembers(this);
        }

        public TemporaryTable HonsitenTenkaiSiwakeTemporaryTable { get; private set; }

        public TemporaryTable SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable { get; private set; }

        /// <summary>
        /// 本支店仕訳リストを取得します
        /// </summary>
        /// <param name="masterRepositoryCache">マスターリポジトリキャッシュ</param>
        /// <returns>本支店仕訳リスト</returns>
        public virtual IList<HonsitenTenkaiSiwake> FindValidSiwakeListOrderBySortKeys(MasterRepositoryCache masterRepositoryCache)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  tmp.kesn,   tmp.dkei,   tmp.dseq,   tmp.sseq,   tmp.pseq ");
            selectQuery.AppendLine("  , tmp.pflg,   tmp.bkbn,   tmp.grno,   tmp.dcpg,   tmp.dlin ");
            selectQuery.AppendLine("  , tmp.dflg,   tmp.rbmn,   tmp.rtor,   tmp.rkmk,   tmp.reda ");
            selectQuery.AppendLine("  , tmp.rkoj,   tmp.rkos,   tmp.rprj,   tmp.rseg,   tmp.rdm1 ");
            selectQuery.AppendLine("  , tmp.rdm2,   tmp.rdm3,   tmp.rtky,   tmp.rtno,   tmp.rimg ");
            selectQuery.AppendLine("  , tmp.sbmn,   tmp.stor,   tmp.skmk,   tmp.seda,   tmp.skoj ");
            selectQuery.AppendLine("  , tmp.skos,   tmp.sprj,   tmp.sseg,   tmp.sdm1,   tmp.sdm2 ");
            selectQuery.AppendLine("  , tmp.sdm3,   tmp.stky,   tmp.stno,   tmp.simg,   tmp.tflg ");
            selectQuery.AppendLine("  , tmp.exvl,   tmp.zkvl,   tmp.valu,   tmp.zkmk,   tmp.zrit ");
            selectQuery.AppendLine("  , tmp.zzkb,   tmp.zgyo,   tmp.zsre,   tmp.rrit,   tmp.srit ");
            selectQuery.AppendLine("  , tmp.rzkb,   tmp.rgyo,   tmp.rsre,   tmp.szkb,   tmp.sgyo ");
            selectQuery.AppendLine("  , tmp.ssre,   tmp.ifri,   tmp.symd,   tmp.skbn,   tmp.skiz ");
            selectQuery.AppendLine("  , tmp.uymd,   tmp.ukbn,   tmp.ukiz,   tmp.sexp,   tmp.dkec ");
            selectQuery.AppendLine("  , tmp.pcsw,   tmp.upsw,   tmp.zrsw,   tmp.gpcd,   tmp.fmod ");
            selectQuery.AppendLine("  , tmp.ftim,   tmp.fusr,   tmp.fway,   tmp.lmod,   tmp.ltim ");
            selectQuery.AppendLine("  , tmp.lusr,   tmp.lway,   tmp.delf,   tmp.cprt,   tmp.fsen ");
            selectQuery.AppendLine("  , tmp.smnt,   tmp.idm4,   tmp.rhei_cd,tmp.shei_cd,tmp.rate ");
            selectQuery.AppendLine("  , tmp.gaika,  tmp.gexvl,  tmp.gzkvl,  tmp.smexp,  tmp.rdm4 ");
            selectQuery.AppendLine("  , tmp.rdm5,   tmp.rdm6,   tmp.rdm7,   tmp.rdm8,   tmp.rdm9 ");
            selectQuery.AppendLine("  , tmp.rdm10,  tmp.rdm11,  tmp.rdm12,  tmp.rdm13,  tmp.rdm14 ");
            selectQuery.AppendLine("  , tmp.rdm15,  tmp.rdm16,  tmp.rdm17,  tmp.rdm18,  tmp.rdm19 ");
            selectQuery.AppendLine("  , tmp.rdm20,  tmp.sdm4,   tmp.sdm5,   tmp.sdm6,   tmp.sdm7 ");
            selectQuery.AppendLine("  , tmp.sdm8,   tmp.sdm9,   tmp.sdm10,  tmp.sdm11,  tmp.sdm12 ");
            selectQuery.AppendLine("  , tmp.sdm13,  tmp.sdm14,  tmp.sdm15,  tmp.sdm16,  tmp.sdm17 ");
            selectQuery.AppendLine("  , tmp.sdm18,  tmp.sdm19,  tmp.sdm20,  tmp.rsseqai,tmp.ssseqai ");
            selectQuery.AppendLine("  , tmp.tekiflg,tmp.hflg,   tmp.swgflg, tmp.swiflg ");
            selectQuery.AppendLine("  , tmp.odlin,  tmp.osseq,  tmp.opseq,  tmp.rsflg,  tmp.ssflg ");
            selectQuery.AppendLine("  , tmp.jflg ");
            selectQuery.AppendLine("  , tmp.rbreg,  tmp.rbinp,  tmp.rbkinp ");
            selectQuery.AppendLine("  , tmp.sbreg,  tmp.sbinp,  tmp.sbkinp ");
            selectQuery.AppendLine("  , tmp.rp1flg, tmp.sp1flg ");
            selectQuery.AppendLine("  , tmp.rp2flg, tmp.sp2flg ");
            selectQuery.AppendLine("  , zh.dfuk ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendFormatAndLine("  {0} tmp ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            selectQuery.AppendLine("  INNER JOIN sjdat_h zh ");
            selectQuery.AppendLine("  ON tmp.kesn = zh.kesn AND tmp.dkei = zh.dkei AND tmp.dseq = zh.dseq ");
            selectQuery.AppendLine("WHERE tmp.pkey > 0 ");
            selectQuery.AppendLine("ORDER BY ");
            selectQuery.AppendLine("  tmp.kesn, tmp.dkei, tmp.dseq, tmp.grno, tmp.dlin, tmp.dflg, tmp.sseq, tmp.pkey ");
            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var row = new HonsitenTenkaiSiwake(this.siwakeFactory.CreateKizonSiwake((short)values[0], (short)values[1], (int)values[2], (int)values[3]), masterRepositoryCache);
                    row.Siwake.ParentChildSiwakeSequenceNumber = (int)values[4]; // 親仕訳seqno.
                    row.Siwake.ParentChildFlag = (SiwakeParentChildRelated)(short)values[5]; // 親子フラグ
                    row.Siwake.BunriKubun = (BunriKubun)(short)values[6]; // 分離区分
                    row.Siwake.GroupNumber = DbNullConverter.ToNullableInt(values[7]) ?? 0; // グループ番号
                    // row.Siwake.Dcpg = DbNullConverter.ToNullableInt(values[8]); // 伝票頁
                    row.Siwake.LineNo = DbNullConverter.ToNullableInt(values[9]) ?? 0; // 行番号
                    row.Siwake.SiwakeTaisyakuZokusei = (SiwakeTaisyakuZokusei)(short)values[10]; // 貸借属性
                    row.Siwake.KarikataBumonCode = DbNullConverter.ToString(values[11]); // 借方部門
                    row.Siwake.KarikataTorihikisakiCode = DbNullConverter.ToString(values[12]); // 借方取引先
                    row.Siwake.KarikataKamokuCode = DbNullConverter.ToString(values[13]); // 借方科目
                    row.Siwake.KarikataEdabanCode = DbNullConverter.ToString(values[14]); // 借方枝番
                    row.Siwake.KarikataKouziCode = DbNullConverter.ToString(values[15]); // 借方工事ｎｏ
                    row.Siwake.KarikataKousyuCode = DbNullConverter.ToString(values[16]); // 借方工種ｎｏ
                    row.Siwake.KarikataProjectCode = DbNullConverter.ToString(values[17]); // 借方ﾌﾟﾛｼﾞｪｸﾄ
                    row.Siwake.KarikataSegmentCode = DbNullConverter.ToString(values[18]); // 借方セグメント
                    row.Siwake.KarikataUniversalField1Code = DbNullConverter.ToString(values[19]); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.Siwake.KarikataUniversalField2Code = DbNullConverter.ToString(values[20]); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.Siwake.KarikataUniversalField3Code = DbNullConverter.ToString(values[21]); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.Siwake.KarikataTekiyou = DbNullConverter.ToString(values[22]); // 借方摘要
                    row.Siwake.KarikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[23]); // 借方摘要ｺｰﾄﾞ
                    row.Siwake.KarikataImageNumber = (int)values[24]; // 借方ｲﾒｰｼﾞno.
                    row.Siwake.KasikataBumonCode = DbNullConverter.ToString(values[25]); // 貸方部門
                    row.Siwake.KasikataTorihikisakiCode = DbNullConverter.ToString(values[26]); // 貸方取引先
                    row.Siwake.KasikataKamokuCode = DbNullConverter.ToString(values[27]); // 貸方科目
                    row.Siwake.KasikataEdabanCode = DbNullConverter.ToString(values[28]); // 貸方枝番
                    row.Siwake.KasikataKouziCode = DbNullConverter.ToString(values[29]); // 貸方工事ｎｏ
                    row.Siwake.KasikataKousyuCode = DbNullConverter.ToString(values[30]); // 貸方工種ｎｏ
                    row.Siwake.KasikataProjectCode = DbNullConverter.ToString(values[31]); // 貸方ﾌﾟﾛｼﾞｪｸﾄ
                    row.Siwake.KasikataSegmentCode = DbNullConverter.ToString(values[32]); // 貸方セグメント
                    row.Siwake.KasikataUniversalField1Code = DbNullConverter.ToString(values[33]); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.Siwake.KasikataUniversalField2Code = DbNullConverter.ToString(values[34]); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.Siwake.KasikataUniversalField3Code = DbNullConverter.ToString(values[35]); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.Siwake.KasikataTekiyou = DbNullConverter.ToString(values[36]); // 貸方摘要
                    row.Siwake.KasikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[37]); // 貸方摘要ｺｰﾄﾞ
                    row.Siwake.KasikataImageNumber = (int)values[38]; // 貸方ｲﾒｰｼﾞno.
                    row.Siwake.IsInputTaika = (short)values[39] == 1; // 対価入力ﾌﾗｸﾞ
                    row.Siwake.TaikaKingaku = (decimal)values[40]; // 対価金額
                    row.Siwake.ZeikomiKingaku = (decimal)values[41]; // 税込金額
                    row.Siwake.Kingaku = (decimal)values[42]; // 金額
                    row.Siwake.ZeitaisyouKamokuCode = DbNullConverter.ToString(values[43]); // 税対象科目 科目
                    row.Siwake.ZeitaisyouKamokuZeiritu = new Percentage((decimal)((DbNullConverter.ToNullableInt(values[44]) / 10000) ?? 0)); // 税対象科目 税率
                    row.Siwake.ZeitaisyouKamokuKazeiKubun = (KazeiKubun)(short)values[45]; // 税対象科目 課税区分
                    row.Siwake.ZeitaisyouKamokuGyousyuKubun = (GyousyuKubun)(short)values[46]; // 税対象科目 業種区分
                    row.Siwake.ZeitaisyouKamokuSiireKubun = (SiwakeSiireKubun)(short)values[47]; // 税対象科目 仕入区分
                    row.Siwake.KarikataZeiritu = new Percentage((decimal)((DbNullConverter.ToNullableInt(values[48]) / 10000) ?? 0)); // 借方税率
                    row.Siwake.KasikataZeiritu = new Percentage((decimal)((DbNullConverter.ToNullableInt(values[49]) / 10000) ?? 0)); // 貸方税率
                    row.Siwake.KarikataKazeiKubun = (KazeiKubun)(short)values[50]; // 借方課税区分
                    row.Siwake.KarikataGyousyuKubun = (GyousyuKubun)(short)values[51]; // 借方業種区分
                    row.Siwake.KarikataSiireKubun = (SiwakeSiireKubun)(short)values[52]; // 借方仕入区分
                    row.Siwake.KasikataKazeiKubun = (KazeiKubun)(short)values[53]; // 貸方課税区分
                    row.Siwake.KasikataGyousyuKubun = (GyousyuKubun)(short)values[54]; // 貸方業種区分
                    row.Siwake.KasikataSiireKubun = (SiwakeSiireKubun)(short)values[55]; // 貸方仕入区分
                    row.Siwake.IkkatuZeinukiSiwakeFlag = (IkkatuZeinukiSiwakeFlag)(short)values[56]; // "一括税抜仕訳 フラグ"
                    row.Siwake.Siharaibi = (int)values[57]; // 支払日
                    row.Siwake.SiharaiKubun = (int?)DbNullConverter.ToNullableShort(values[58]); // 支払区分
                    row.Siwake.SiharaiKizitu = (int)values[59]; // 支払期日
                    row.Siwake.Kaisyuubi = (int)values[60]; // 回収日
                    row.Siwake.NyuukinKubun = (int?)DbNullConverter.ToNullableShort(values[61]); // 入金区分
                    row.Siwake.KaisyuuKizitu = (int)values[62]; // 回収期日
                    row.Siwake.IsExportSiharai = (short)values[63] == 1; // 支払exportﾌﾗｸﾞ
                    row.Siwake.KesikomiCode = values[64].ToString(); // 消込ｺｰﾄﾞ
                    row.Siwake.IsKesikomiTyuusyutu = (short)values[65] == 1; // 消込抽出ﾌﾗｸﾞ
                    row.Siwake.IsKesikomiUpdate = (short)values[66] == 1; // 消込更新ﾌﾗｸﾞ
                    row.Siwake.IsKesikomiZero = (short)values[67] == 1; // 消込ゼロﾌﾗｸﾞ
                    row.Siwake.KesikomiGroupCode = DbNullConverter.ToString(values[68]); // 消込ｸﾞﾙｰﾌﾟｺｰﾄﾞ
                    row.Siwake.SiwakeSakuseibi = (int)values[69]; // 入力年月日
                    row.Siwake.SiwakeSakuseiZikan = (int)values[70]; // 入力時分秒
                    row.Siwake.SiwakeSakuseisyaCode = (int)values[71]; // 入力者
                    row.Siwake.SiwakeSakuseiHouhou = (DenpyouSiwakeWayToCreate)values[72]; // 入力手段
                    row.Siwake.SiwakeKousinbi = (int)values[73]; // 最終変更年月日
                    row.Siwake.SiwakeKousinZikan = (int)values[74]; // 最終変更時分秒
                    row.Siwake.SiwakeKousinsyaCode = (int)values[75]; // 最終変更者
                    row.Siwake.SiwakeKousinHouhou = (DenpyouSiwakeWayToCreate)values[76]; // 最終変更手段
                    row.Siwake.IsTorikesi = (short)values[77] == 1; // 削除ﾌﾗｸﾞ
                    row.Siwake.IsPrintedChecklist = (short)values[78] == 1; // 出力ﾌﾗｸﾞ
                    row.Siwake.SiwakeHusen = (SiwakeHusen)(short)values[79]; // 付箋番号
                    row.Siwake.IsSyouninsyaHensyuu = (short)values[80] == 1; // 承認者編集
                    row.Siwake.OdcImportRirekiNumber = (int)values[81]; // "odcｲﾝﾎﾟｰﾄ履歴番号"
                    row.Siwake.KarikataHeisyuCode = DbNullConverter.ToString(values[82]); // 借方通貨コード
                    row.Siwake.KasikataHeisyuCode = DbNullConverter.ToString(values[83]); // 貸方通貨コード
                    row.Siwake.Rate = (decimal)values[84]; // レート
                    row.Siwake.GaikaKingaku = (decimal)values[85]; // 外貨金額
                    row.Siwake.GaikaTaikaKingaku = (decimal)values[86]; // 外貨対価
                    row.Siwake.GaikaZeikomiKingaku = (decimal)values[87]; // 外貨税込金額
                    row.Siwake.IsExportSaimu = (int)values[88] == 1; // 債務支払export
                    row.Siwake.KarikataUniversalField4Code = DbNullConverter.ToString(values[89]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.Siwake.KarikataUniversalField5Code = DbNullConverter.ToString(values[90]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.Siwake.KarikataUniversalField6Code = DbNullConverter.ToString(values[91]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.Siwake.KarikataUniversalField7Code = DbNullConverter.ToString(values[92]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.Siwake.KarikataUniversalField8Code = DbNullConverter.ToString(values[93]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.Siwake.KarikataUniversalField9Code = DbNullConverter.ToString(values[94]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.Siwake.KarikataUniversalField10Code = DbNullConverter.ToString(values[95]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.Siwake.KarikataUniversalField11Code = DbNullConverter.ToString(values[96]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.Siwake.KarikataUniversalField12Code = DbNullConverter.ToString(values[97]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.Siwake.KarikataUniversalField13Code = DbNullConverter.ToString(values[98]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.Siwake.KarikataUniversalField14Code = DbNullConverter.ToString(values[99]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.Siwake.KarikataUniversalField15Code = DbNullConverter.ToString(values[100]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.Siwake.KarikataUniversalField16Code = DbNullConverter.ToString(values[101]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.Siwake.KarikataUniversalField17Code = DbNullConverter.ToString(values[102]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.Siwake.KarikataUniversalField18Code = DbNullConverter.ToString(values[103]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.Siwake.KarikataUniversalField19Code = DbNullConverter.ToString(values[104]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.Siwake.KarikataUniversalField20Code = DbNullConverter.ToString(values[105]); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.Siwake.KasikataUniversalField4Code = DbNullConverter.ToString(values[106]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.Siwake.KasikataUniversalField5Code = DbNullConverter.ToString(values[107]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.Siwake.KasikataUniversalField6Code = DbNullConverter.ToString(values[108]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.Siwake.KasikataUniversalField7Code = DbNullConverter.ToString(values[109]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.Siwake.KasikataUniversalField8Code = DbNullConverter.ToString(values[110]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.Siwake.KasikataUniversalField9Code = DbNullConverter.ToString(values[111]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.Siwake.KasikataUniversalField10Code = DbNullConverter.ToString(values[112]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.Siwake.KasikataUniversalField11Code = DbNullConverter.ToString(values[113]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.Siwake.KasikataUniversalField12Code = DbNullConverter.ToString(values[114]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.Siwake.KasikataUniversalField13Code = DbNullConverter.ToString(values[115]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.Siwake.KasikataUniversalField14Code = DbNullConverter.ToString(values[116]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.Siwake.KasikataUniversalField15Code = DbNullConverter.ToString(values[117]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.Siwake.KasikataUniversalField16Code = DbNullConverter.ToString(values[118]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.Siwake.KasikataUniversalField17Code = DbNullConverter.ToString(values[119]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.Siwake.KasikataUniversalField18Code = DbNullConverter.ToString(values[120]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.Siwake.KasikataUniversalField19Code = DbNullConverter.ToString(values[121]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.Siwake.KasikataUniversalField20Code = DbNullConverter.ToString(values[122]); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.Siwake.KarikataAiteSiwakeSeqNumber = (int)values[123]; // 借方相手仕訳seqno.
                    row.Siwake.KasikataAiteSiwakeSeqNumber = (int)values[124]; // 貸方相手仕訳seqno.
                    row.Siwake.IsTaisyakubetuTekiyou = (short)values[125] == 1; // 貸借摘要フラグ
                    row.Siwake.IsHininSiwake = (short)values[126] == 1; // 否認状況
                    row.Siwake.IsUpdatedLine = (short)values[127] == 1; // 行変更フラグ
                    row.Siwake.IsPrintedSiwakeList = (short)values[128] == 1; // 仕訳一覧フラグ
                    row.LineNoBeforeHonsitenTenkai = DbNullConverter.ToNullableInt(values[129]) ?? 0; // 本支店展開前の行番号
                    row.SseqBeforeHonsitenTenkai = (int)values[130]; // 本支店展開前の仕訳SEQ
                    row.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = (int)values[131]; // 本支店展開前の親仕訳SEQ
                    row.KarikataHonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[132]; // 借方本支店勘定設定フラグ
                    row.KasikataHonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[133]; // 貸方本支店勘定設定フラグ
                    row.IsHonsitenTenkaiEnabledSiwake = (int)values[134] == 1; // 本支店展開可能な仕訳かどうか
                    row.IsInputedKarikataBumon = (int)values[135] == 1; // 借方部門が入力されているかどうか
                    row.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = (int)values[136] == 1; // 本支店展開明細テーブル（hstbl_m）に、借方部門が登録されているかどうか
                    row.IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable = (int)values[137] == 1; // 部門科目残高テーブル（bkzan）に、借方部門科目が登録されているかどうか
                    row.IsInputedKasikataBumon = (int)values[138] == 1; // 貸方部門が入力されているかどうか
                    row.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = (int)values[139] == 1; // 本支店展開明細テーブル（hstbl_m）に、貸方部門が登録されているかどうか
                    row.IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable = (int)values[140] == 1; // 部門科目残高テーブル（bkzan）に、貸方部門科目が登録されているかどうか
                    row.IsKarikataParent = (int)values[141] == 1; // 借方が親かどうか
                    row.IsKasikataParent = (int)values[142] == 1; // 貸方が親かどうか
                    row.IsKarikataChild = (int)values[143] == 1; // 借方が子かどうか
                    row.IsKasikataChild = (int)values[144] == 1; // 貸方が子かどうか
                    row.DenpyouKeisiki = (DenpyouKeisiki)(short)values[145]; // 複合フラグ
                    return row;
                },
                () => new List<HonsitenTenkaiSiwake>());
        }

        public virtual void InsertSiwakeBeforeCreateSyouhizeiSiwake(Siwake siwakeBeforeCreateSyouhizeiSiwake)
        {
            if (this.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable == null)
            {
                return;
            }

            var insertCommand = this.CreateSiwakeInsertSqlStatementBuilder(siwakeBeforeCreateSyouhizeiSiwake, this.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable.TableName);
            this.dbc.Execute(insertCommand.GetSqlStatement(), insertCommand.GetSqlParameters());
        }

        /// <summary>
        /// 本支店仕訳を挿入します
        /// </summary>
        /// <param name="honsitenSiwake">挿入対象の本支店仕訳</param>
        public virtual void Insert(HonsitenTenkaiSiwake honsitenSiwake)
        {
            var insertCommand = this.CreateSiwakeInsertSqlStatementBuilder(honsitenSiwake.Siwake, this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            insertCommand.AppendColumnNameAndValue("pkey", honsitenSiwake.PrimaryKey);

            insertCommand.AppendColumnNameAndValue("odlin", honsitenSiwake.LineNoBeforeHonsitenTenkai);
            insertCommand.AppendColumnNameAndValue("osseq", honsitenSiwake.SseqBeforeHonsitenTenkai);
            insertCommand.AppendColumnNameAndValue("opseq", honsitenSiwake.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai);
            insertCommand.AppendColumnNameAndValue("rsflg", (int)honsitenSiwake.KarikataHonsitenKanzyouSetFlag);
            insertCommand.AppendColumnNameAndValue("ssflg", (int)honsitenSiwake.KasikataHonsitenKanzyouSetFlag);
            insertCommand.AppendColumnNameAndValue("jflg", honsitenSiwake.IsHonsitenTenkaiEnabledSiwake ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("rbreg", honsitenSiwake.IsInputedKarikataBumon ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("rbinp", honsitenSiwake.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("rbkinp", honsitenSiwake.IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("sbreg", honsitenSiwake.IsInputedKasikataBumon ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("sbinp", honsitenSiwake.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("sbkinp", honsitenSiwake.IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("rp1flg", honsitenSiwake.IsKarikataParent ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("sp1flg", honsitenSiwake.IsKasikataParent ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("rp2flg", honsitenSiwake.IsKarikataChild ? 1 : 0);
            insertCommand.AppendColumnNameAndValue("sp2flg", honsitenSiwake.IsKasikataChild ? 1 : 0);
            this.dbc.Execute(insertCommand.GetSqlStatement(), insertCommand.GetSqlParameters());
        }

        /// <summary>
        /// 部門科目として登録されているかどうかのデータを更新します
        /// </summary>
        public virtual void UpdateIsRegisteredAsBumonKamoku()
        {
            //// 借方
            var karikataUpdateQuery = new SqlStatementBuilder();
            karikataUpdateQuery.AppendFormatAndLine("UPDATE {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            karikataUpdateQuery.AppendLine("SET ");
            karikataUpdateQuery.AppendLine("  rbkinp = 0 ");
            karikataUpdateQuery.AppendLine("WHERE ");
            karikataUpdateQuery.AppendLine("  dflg IN (0, 1) ");
            karikataUpdateQuery.AppendLine("  AND NOT EXISTS ( ");
            karikataUpdateQuery.AppendLine("    SELECT ");
            karikataUpdateQuery.AppendLine("      bkzan.kesn ");
            karikataUpdateQuery.AppendLine("    FROM ");
            karikataUpdateQuery.AppendLine("      bkzan ");
            karikataUpdateQuery.AppendLine("    WHERE ");
            karikataUpdateQuery.AppendFormatAndLine("      bkzan.kesn = {0}.kesn ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            karikataUpdateQuery.AppendLine("      AND bkzan.kicd = rkmk ");
            karikataUpdateQuery.AppendLine("      AND bkzan.bcod = rbmn ");
            karikataUpdateQuery.AppendLine("  ) ");
            karikataUpdateQuery.AppendLine("  AND rkmk NOT IN ('000000000001001', '000000000001002') ");
            this.dbc.Execute(karikataUpdateQuery.GetSqlStatement(), karikataUpdateQuery.GetSqlParameters());

            //// 貸方
            var kasikataUpdateQuery = new SqlStatementBuilder();
            kasikataUpdateQuery.AppendFormatAndLine("UPDATE {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            kasikataUpdateQuery.AppendLine("SET ");
            kasikataUpdateQuery.AppendLine("  sbkinp = 0 ");
            kasikataUpdateQuery.AppendLine("WHERE ");
            kasikataUpdateQuery.AppendLine("  dflg IN (0, 2) ");
            kasikataUpdateQuery.AppendLine("  AND NOT EXISTS ( ");
            kasikataUpdateQuery.AppendLine("    SELECT ");
            kasikataUpdateQuery.AppendLine("      bkzan.kesn ");
            kasikataUpdateQuery.AppendLine("    FROM ");
            kasikataUpdateQuery.AppendLine("      bkzan ");
            kasikataUpdateQuery.AppendLine("    WHERE ");
            kasikataUpdateQuery.AppendFormatAndLine("      bkzan.kesn = {0}.kesn ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            kasikataUpdateQuery.AppendLine("      AND bkzan.kicd = skmk ");
            kasikataUpdateQuery.AppendLine("      AND bkzan.bcod = sbmn ");
            kasikataUpdateQuery.AppendLine("  ) ");
            kasikataUpdateQuery.AppendLine("  AND skmk NOT IN ('000000000001001', '000000000001002') ");
            this.dbc.Execute(kasikataUpdateQuery.GetSqlStatement(), kasikataUpdateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 仕訳の親子関係を更新します
        /// </summary>
        public virtual void UpdateParentChildRelationship()
        {
            foreach (var honsitenSiwake in this.FindSiwakeWithParentChildRelationship())
            {
                foreach (var sseq in this.GetParentOrChildSiwakeSequence(honsitenSiwake))
                {
                    var updateQuery = new SqlStatementBuilder();
                    updateQuery.AppendFormatAndLine("UPDATE {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
                    updateQuery.AppendLine("SET ");
                    updateQuery.AppendLine("  sseq = CASE ");
                    updateQuery.AppendLine("    WHEN pflg = 2 ");
                    updateQuery.AppendLine("      THEN :p ", sseq);
                    updateQuery.AppendLine("    ELSE sseq ");
                    updateQuery.AppendLine("    END ");
                    updateQuery.AppendLine("  , pseq = CASE ");
                    updateQuery.AppendLine("    WHEN pflg = 2 ");
                    updateQuery.AppendLine("      THEN :p + 1 ", sseq);
                    updateQuery.AppendLine("    ELSE sseq ");
                    updateQuery.AppendLine("    END ");
                    updateQuery.AppendLine("WHERE ");
                    updateQuery.AppendLine("  pkey = :p ", honsitenSiwake.PrimaryKey);
                    this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
                }
            }
        }

        public virtual void UpdateSortKeys()
        {
            Siwake previousSiwake = this.siwakeFactory.CreateKizonSiwake(0, 0, 0, 0);
            Siwake siwakeForUpdate = this.siwakeFactory.CreateKizonSiwake(0, 0, 0, 0);
            var lineNoDifference = 0;
            var aiteSseq = 0;
            var tempSseq = 0;
            var tempLineNo = 0;
            var sseqForStorage = 0;
            var lineNoForStorage = 0;
            foreach (var sortJudgement in this.GetHonsitenTenkaiSiwakeSortJudgementValue())
            {
                if (previousSiwake.Dkei != sortJudgement.Dkei
                    || previousSiwake.DenpyouSequenceNumber != sortJudgement.DenpyouSequenceNumber)
                {
                    //// 伝票切り替え時
                    aiteSseq =
                    lineNoDifference =
                    siwakeForUpdate.LineNo =
                    previousSiwake.LineNo = 0;
                }

                if (previousSiwake.LineNo != sortJudgement.LineNo)
                {
                    //// 仕訳行切り替え時
                    aiteSseq = 0;
                    lineNoDifference = sortJudgement.LineNo - previousSiwake.LineNo - 1;
                    lineNoDifference = lineNoDifference < 0 ? 0 : lineNoDifference;
                }
                else
                {
                    lineNoDifference = 0;
                }

                siwakeForUpdate.GroupNumber = sortJudgement.GroupNumber;
                siwakeForUpdate.SetSseq(siwakeForUpdate.SiwakeSequenceNumber + 1);
                siwakeForUpdate.LineNo += 1 + lineNoDifference;

                sseqForStorage = siwakeForUpdate.SiwakeSequenceNumber;
                lineNoForStorage = siwakeForUpdate.LineNo;

                if (sortJudgement.DenpyouKeisiki == DenpyouKeisiki.Hukugou
                    && sortJudgement.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Taisyaku)
                {
                    if (aiteSseq != sortJudgement.SiwakeSequenceNumber)
                    {
                        aiteSseq = this.GetSiwakeSequenceFromBeforeHonsitenTenkaiSiwakeByHonsitenTenkaiSiwakeKeyAndTaisyakuZokusei(sortJudgement, sortJudgement.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata ? SiwakeTaisyakuZokusei.Kasikata : SiwakeTaisyakuZokusei.Karikata);
                        if (aiteSseq > 0)
                        {
                            tempSseq =
                            sseqForStorage = siwakeForUpdate.SiwakeSequenceNumber + 1;
                            tempLineNo = siwakeForUpdate.LineNo;
                        }
                    }
                    else
                    {
                        siwakeForUpdate.SetSseq(tempSseq);
                        siwakeForUpdate.LineNo = tempLineNo;
                        aiteSseq = 0;

                        sseqForStorage -= 1;
                        lineNoForStorage -= 1 + lineNoDifference;
                    }
                }

                this.UpdateSortKeysFromSiwakeByPrimaryKey(siwakeForUpdate, sortJudgement.PrimaryKey);

                siwakeForUpdate.SetSseq(sseqForStorage);
                siwakeForUpdate.LineNo = lineNoForStorage;

                previousSiwake.SetDkei(sortJudgement.Dkei);
                previousSiwake.SetDseq(sortJudgement.DenpyouSequenceNumber);
                previousSiwake.LineNo = sortJudgement.LineNo;
            }
        }

        /// <summary>
        /// 本支店展開不可の仕訳を含む伝票に属する仕訳を削除します
        /// </summary>
        public virtual void DeleteBelongingToDenpyouContainsHonsitenTenkaiImpossibleSiwake()
        {
            var sql = new SqlStatementBuilder();
            sql.AppendFormatAndLine("DELETE FROM {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            sql.AppendLine("WHERE ");
            sql.AppendLine("  EXISTS ( ");
            sql.AppendLine("    SELECT ");
            sql.AppendLine("      t.kesn ");
            sql.AppendLine("      , t.dkei ");
            sql.AppendLine("      , t.dseq ");
            sql.AppendLine("      , t.sseq ");
            sql.AppendLine("    FROM ");
            sql.AppendFormatAndLine("      {0} t ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            sql.AppendLine("    WHERE ");
            sql.AppendLine("      t.jflg = 0 ");
            sql.AppendFormatAndLine("      AND {0}.kesn = t.kesn ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            sql.AppendFormatAndLine("      AND {0}.dkei = t.dkei ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            sql.AppendFormatAndLine("      AND {0}.dseq = t.dseq ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            sql.AppendLine("  ) ");
            this.dbc.Execute(sql.GetSqlStatement(), sql.GetSqlParameters());
        }

        /// <summary>
        /// 本支店展開前仕訳が格納されたテーブル名を取得します
        /// </summary>
        /// <returns></returns>
        private string GetSiwakeBeforeHonsitenTenkaiTableName()
        {
            return this.honsitenSiwakeCreateOrder == HonsitenSiwakeCreateOrder.BeforeCreateSyouhizeiZidouSeiseiChildSiwake ? this.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable.TableName : "sjdat";
        }

        /// <summary>
        /// 親子関係のある仕訳を取得します
        /// </summary>
        /// <returns></returns>
        private IList<HonsitenTenkaiSiwake> FindSiwakeWithParentChildRelationship()
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  pkey ");
            selectQuery.AppendLine("  , osseq ");
            selectQuery.AppendLine("  , opseq ");
            selectQuery.AppendLine("  , rp1flg ");
            selectQuery.AppendLine("  , sp1flg ");
            selectQuery.AppendLine("  , rp2flg ");
            selectQuery.AppendLine("  , sp2flg ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendFormatAndLine("  {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  pflg > 0 ");
            selectQuery.AppendLine("ORDER BY ");
            selectQuery.AppendLine("  pkey ");
            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var row = new HonsitenTenkaiSiwake(null, null);
                    row.PrimaryKey = (int)values[0];
                    row.SseqBeforeHonsitenTenkai = (int)values[1];
                    row.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = (int)values[2];
                    row.IsKarikataParent = (int)values[3] == 1;
                    row.IsKasikataParent = (int)values[4] == 1;
                    row.IsKarikataChild = (int)values[5] == 1;
                    row.IsKasikataChild = (int)values[6] == 1;
                    return row;
                },
                () => new List<HonsitenTenkaiSiwake>());
        }

        /// <summary>
        /// 親または子の仕訳SEQを取得します
        /// </summary>
        /// <param name="honsitenSiwake">条件指定用本支店仕訳リスト</param>
        /// <returns>親または子の仕訳SEQリスト</returns>
        private IList<int> GetParentOrChildSiwakeSequence(HonsitenTenkaiSiwake honsitenSiwake)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  sseq ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendFormatAndLine("  {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  osseq = :p ", honsitenSiwake.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai);
            selectQuery.AppendLine("  AND pflg > 0 ");
            selectQuery.AppendLine("  AND ( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      WHEN :p = 1 ", honsitenSiwake.IsKarikataParent ? 1 : 0); // 借方親仕訳なら、借方子仕訳を取得
            selectQuery.AppendLine("        THEN rp2flg ");
            selectQuery.AppendLine("      ELSE CASE ");
            selectQuery.AppendLine("        WHEN :p = 1 ", honsitenSiwake.IsKasikataParent ? 1 : 0); // 借方子仕訳なら、借方親仕訳を取得
            selectQuery.AppendLine("          THEN sp2flg ");
            selectQuery.AppendLine("        ELSE CASE ");
            selectQuery.AppendLine("          WHEN :p = 1 ", honsitenSiwake.IsKarikataChild ? 1 : 0); // 貸方親仕訳なら、貸方子仕訳を取得
            selectQuery.AppendLine("            THEN rp1flg ");
            selectQuery.AppendLine("          ELSE CASE ");
            selectQuery.AppendLine("            WHEN :p = 1 ", honsitenSiwake.IsKasikataChild ? 1 : 0); // 貸方子仕訳なら、貸方親仕訳を取得
            selectQuery.AppendLine("              THEN sp1flg ");
            selectQuery.AppendLine("            ELSE 0 ");
            selectQuery.AppendLine("            END ");
            selectQuery.AppendLine("          END ");
            selectQuery.AppendLine("        END ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) = 1 ");
            selectQuery.AppendLine("ORDER BY ");
            selectQuery.AppendLine("  pkey ");
            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) => (int)values[0],
                () => new List<int>(),
                selectQuery.GetSqlParameters());
        }

        private IList<HonsitenTenkaiSiwakeSortJudgementValue> GetHonsitenTenkaiSiwakeSortJudgementValue()
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  tmp.kesn ");
            selectQuery.AppendLine("  , z.dkei ");
            selectQuery.AppendLine("  , z.dseq ");
            selectQuery.AppendLine("  , z.sseq ");
            selectQuery.AppendLine("  , z.grno ");
            selectQuery.AppendLine("  , z.dlin ");
            selectQuery.AppendLine("  , tmp.dflg ");
            selectQuery.AppendLine("  , tmp.pkey ");
            selectQuery.AppendLine("  , tmp.rsflg ");
            selectQuery.AppendLine("  , tmp.ssflg ");
            selectQuery.AppendLine("  , zh.dfuk ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendFormatAndLine("  {0} tmp ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            selectQuery.AppendLine("  INNER JOIN sjdat_h zh ");
            selectQuery.AppendLine("    ON tmp.kesn = zh.kesn ");
            selectQuery.AppendLine("    AND tmp.dkei = zh.dkei ");
            selectQuery.AppendLine("    AND tmp.dseq = zh.dseq ");
            selectQuery.AppendFormatAndLine("  LEFT OUTER JOIN {0} z ", this.GetSiwakeBeforeHonsitenTenkaiTableName());
            selectQuery.AppendLine("    ON tmp.kesn = z.kesn ");
            selectQuery.AppendLine("    AND tmp.dkei = z.dkei ");
            selectQuery.AppendLine("    AND tmp.dseq = z.dseq ");
            selectQuery.AppendLine("    AND tmp.osseq = z.sseq ");
            selectQuery.AppendLine("ORDER BY ");
            selectQuery.AppendLine("  z.kesn ");
            selectQuery.AppendLine("  , z.dkei ");
            selectQuery.AppendLine("  , z.dseq ");
            selectQuery.AppendLine("  , z.grno ");
            selectQuery.AppendLine("  , z.dlin ");
            selectQuery.AppendLine("  , z.sseq ");
            selectQuery.AppendLine("  , tmp.rsflg ");
            selectQuery.AppendLine("  , tmp.ssflg ");
            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var row = new HonsitenTenkaiSiwakeSortJudgementValue();
                    row.Kesn = (short)values[0];
                    row.Dkei = (short)values[1];
                    row.DenpyouSequenceNumber = (int)values[2];
                    row.SiwakeSequenceNumber = (int)values[3];
                    row.GroupNumber = (int)values[4];
                    row.LineNo = (int)values[5];
                    row.SiwakeTaisyakuZokusei = (SiwakeTaisyakuZokusei)(short)values[6];
                    row.PrimaryKey = (int)values[7];
                    row.KarikataHonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[8];
                    row.KasikataHonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[9];
                    row.DenpyouKeisiki = (DenpyouKeisiki)(short)values[10];
                    return row;
                },
                () => new List<HonsitenTenkaiSiwakeSortJudgementValue>());
        }

        /// <summary>
        /// primaryKeyを条件として、指定の仕訳から本支店展開仕訳のソートキーを更新します
        /// </summary>
        /// <param name="updateValue"></param>
        /// <param name="primaryKey"></param>
        private void UpdateSortKeysFromSiwakeByPrimaryKey(Siwake updateValue, int primaryKey)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendFormatAndLine("UPDATE {0} ", this.HonsitenTenkaiSiwakeTemporaryTable.TableName);
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  sseq = :p ", updateValue.SiwakeSequenceNumber);
            updateQuery.AppendLine("  , pseq = :p ", updateValue.SiwakeSequenceNumber);
            updateQuery.AppendLine("  , grno = :p ", updateValue.GroupNumber);
            updateQuery.AppendLine("  , dlin = :p ", updateValue.LineNo);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  pkey = :p ", primaryKey);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        private int GetSiwakeSequenceFromBeforeHonsitenTenkaiSiwakeByHonsitenTenkaiSiwakeKeyAndTaisyakuZokusei(HonsitenTenkaiSiwakeSortJudgementValue honsitenSiwakeSortJudgement, SiwakeTaisyakuZokusei taisyakuZokusei)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  sseq ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendFormatAndLine("  {0} z ", this.GetSiwakeBeforeHonsitenTenkaiTableName());
            selectQuery.AppendLine("  INNER JOIN sjdat_h zh ");
            selectQuery.AppendLine("    ON z.kesn = zh.kesn ");
            selectQuery.AppendLine("    AND z.dkei = zh.dkei ");
            selectQuery.AppendLine("    AND z.dseq = zh.dseq ");
            selectQuery.AppendLine("    AND zh.dfuk = :p ", (short)honsitenSiwakeSortJudgement.DenpyouKeisiki);
            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  z.kesn = :p ", honsitenSiwakeSortJudgement.Kesn);
            selectQuery.AppendLine("  AND z.dkei = :p ", honsitenSiwakeSortJudgement.Dkei);
            selectQuery.AppendLine("  AND z.dseq = :p ", honsitenSiwakeSortJudgement.DenpyouSequenceNumber);
            selectQuery.AppendLine("  AND z.grno = :p ", honsitenSiwakeSortJudgement.GroupNumber);
            selectQuery.AppendLine("  AND z.dlin = :p ", honsitenSiwakeSortJudgement.LineNo);
            selectQuery.AppendLine("  AND z.dflg = :p ", (short)taisyakuZokusei);
            return this.dbc.QueryForObject(
                selectQuery.GetSqlStatement(),
                (values, no) => (int)values[0],
                selectQuery.GetSqlParameters());
        }

        private InsertSqlStatementBuilder CreateSiwakeInsertSqlStatementBuilder(Siwake siwake, string tableName)
        {
            // TODO DenyouModelと統合
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder(tableName);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", siwake.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkei", siwake.Dkei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dseq", siwake.DenpyouSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sseq", siwake.SiwakeSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pseq", siwake.ParentChildSiwakeSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pflg", (short)siwake.ParentChildFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("bkbn", (short)siwake.BunriKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("grno", siwake.GroupNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dcpg", 1);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dlin", siwake.LineNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dflg", (short)siwake.SiwakeTaisyakuZokusei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rbmn", siwake.KarikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtor", siwake.KarikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkmk", siwake.KarikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("reda", siwake.KarikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkoj", siwake.KarikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkos", siwake.KarikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rprj", siwake.KarikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rseg", siwake.KarikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm1", siwake.KarikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm2", siwake.KarikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm3", siwake.KarikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtky", siwake.KarikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtno", siwake.KarikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rimg", siwake.KarikataImageNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sbmn", siwake.KasikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stor", siwake.KasikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skmk", siwake.KasikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("seda", siwake.KasikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skoj", siwake.KasikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skos", siwake.KasikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sprj", siwake.KasikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sseg", siwake.KasikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm1", siwake.KasikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm2", siwake.KasikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm3", siwake.KasikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stky", siwake.KasikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stno", siwake.KasikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("simg", siwake.KasikataImageNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tflg", siwake.IsInputTaika ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("exvl", siwake.TaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zkvl", siwake.ZeikomiKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("valu", siwake.Kingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zkmk", siwake.ZeitaisyouKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zrit", (int?)(siwake.ZeitaisyouKamokuZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("zzkb", (short)siwake.ZeitaisyouKamokuKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zgyo", (short)siwake.ZeitaisyouKamokuGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zsre", (short)siwake.ZeitaisyouKamokuSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rrit", (int?)(siwake.KarikataZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("srit", (int?)(siwake.KasikataZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzkb", (short)siwake.KarikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgyo", (short)siwake.KarikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsre", (short)siwake.KarikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szkb", (short)siwake.KasikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgyo", (short)siwake.KasikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssre", (short)siwake.KasikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ifri", (short)siwake.IkkatuZeinukiSiwakeFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("symd", siwake.Siharaibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skbn", siwake.SiharaiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skiz", siwake.SiharaiKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("uymd", siwake.Kaisyuubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ukbn", siwake.NyuukinKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ukiz", siwake.KaisyuuKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sexp", siwake.IsExportSiharai ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkec", siwake.KesikomiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pcsw", siwake.IsKesikomiTyuusyutu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("upsw", siwake.IsKesikomiUpdate ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zrsw", siwake.IsKesikomiZero ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gpcd", siwake.KesikomiGroupCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fmod", siwake.SiwakeSakuseibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ftim", siwake.SiwakeSakuseiZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", siwake.SiwakeSakuseisyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fway", (int)siwake.SiwakeSakuseiHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", siwake.SiwakeKousinbi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", siwake.SiwakeKousinZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", siwake.SiwakeKousinsyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lway", (int)siwake.SiwakeKousinHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("delf", siwake.IsTorikesi ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cprt", siwake.IsPrintedChecklist ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fsen", (short)siwake.SiwakeHusen);
            insertSqlStatementBuilder.AppendColumnNameAndValue("smnt", siwake.IsSyouninsyaHensyuu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm4", siwake.OdcImportRirekiNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rhei_cd", siwake.KarikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("shei_cd", siwake.KasikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rate", siwake.Rate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gaika", siwake.GaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gexvl", siwake.GaikaTaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gzkvl", siwake.GaikaZeikomiKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("smexp", siwake.IsExportSaimu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm4", siwake.KarikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm5", siwake.KarikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm6", siwake.KarikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm7", siwake.KarikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm8", siwake.KarikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm9", siwake.KarikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm10", siwake.KarikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm11", siwake.KarikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm12", siwake.KarikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm13", siwake.KarikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm14", siwake.KarikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm15", siwake.KarikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm16", siwake.KarikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm17", siwake.KarikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm18", siwake.KarikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm19", siwake.KarikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm20", siwake.KarikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm4", siwake.KasikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm5", siwake.KasikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm6", siwake.KasikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm7", siwake.KasikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm8", siwake.KasikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm9", siwake.KasikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm10", siwake.KasikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm11", siwake.KasikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm12", siwake.KasikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm13", siwake.KasikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm14", siwake.KasikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm15", siwake.KasikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm16", siwake.KasikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm17", siwake.KasikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm18", siwake.KasikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm19", siwake.KasikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm20", siwake.KasikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsseqai", siwake.KarikataAiteSiwakeSeqNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssseqai", siwake.KasikataAiteSiwakeSeqNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tekiflg", siwake.IsTaisyakubetuTekiyou ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("hflg", siwake.IsHininSiwake ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("swgflg", siwake.IsUpdatedLine ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("swiflg", siwake.IsPrintedSiwakeList ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fsflg", (short)siwake.GaikaKanzanSiwakeFlag);
            return insertSqlStatementBuilder;
        }

        /// <summary>
        /// 並び替え判定用
        /// </summary>
        private class HonsitenTenkaiSiwakeSortJudgementValue
        {
            public int Kesn { get; set; }

            public int Dkei { get; set; }

            public int DenpyouSequenceNumber { get; set; }

            public int SiwakeSequenceNumber { get; set; }

            public int GroupNumber { get; set; }

            public int LineNo { get; set; }

            public SiwakeTaisyakuZokusei SiwakeTaisyakuZokusei { get; set; }

            public int PrimaryKey { get; set; }

            public HonsitenKanzyouSetFlag KarikataHonsitenKanzyouSetFlag { get; set; }

            public HonsitenKanzyouSetFlag KasikataHonsitenKanzyouSetFlag { get; set; }

            public DenpyouKeisiki DenpyouKeisiki { get; set; }
        }
    }
}
