﻿namespace Icsp.Open21.Persistence.HonsitenModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.HonsitenModel;

    /// <summary>
    /// テーブルレイアウトを定義するため、Persistence層に定義
    /// </summary>
    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class HonsitenTenkaiRepositoryFactory : IHonsitenTenkaiRepositoryFactory
    {
        [KaisyaDbAutoInjection]
        private IDbTableUtilityDao dbTableUtilityDao = null;
        [AutoInjection]
        private InjectionContainer container = null;

        public virtual IHonsitenTenkaiSiwakeRepository CreateHonsitenTenkaiSiwakeRepository(HonsitenSiwakeCreateOrder honsitenSiwakeCreateOrder)
        {
            var honsitenTenkaiSiwakeTemporaryTable = this.CreateHonsitenTenkaiSiwakeTemporaryTable();
            var siwakeBeforeCreateSyouhizeiSiwakeTemporaryTable = honsitenSiwakeCreateOrder == HonsitenSiwakeCreateOrder.BeforeCreateSyouhizeiZidouSeiseiChildSiwake
                ? this.CreateSiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable()
                : null;
            return new HonsitenTenkaiSiwakeRepository(this.container, honsitenTenkaiSiwakeTemporaryTable, siwakeBeforeCreateSyouhizeiSiwakeTemporaryTable, honsitenSiwakeCreateOrder);
        }

        private TemporaryTable CreateHonsitenTenkaiSiwakeTemporaryTable()
        {
            var columns = this.dbTableUtilityDao.GetColumnDefinitionListByTableNameOrderByColumnId("sjdat");
            var columnId = columns[columns.Count - 1].Id;

            // rsflgはsjdatに存在する（支払借方科目）// r_honten_or_siten
            // ssflgはsjdatに存在する（支払貸方科目）// s_honten_or_siten
            columns = columns.Where(column => column.Name != "rsflg" && column.Name != "ssflg").ToList();
            columns.Add(new DbColumnDefinition(columnId++, "pkey", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "odlin", DbDataType.Integer));
            columns.Add(new DbColumnDefinition(columnId++, "osseq", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "opseq", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rsflg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "ssflg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "jflg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rbreg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rbinp", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rbkinp", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "sbreg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "sbinp", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "sbkinp", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rp1flg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "sp1flg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "rp2flg", DbDataType.Integer) { IsNullable = false });
            columns.Add(new DbColumnDefinition(columnId++, "sp2flg", DbDataType.Integer) { IsNullable = false });
            return this.dbTableUtilityDao.CreateTemporaryTable("sjdat", columns, true, true);
        }

        private TemporaryTable CreateSiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable()
        {
            return this.dbTableUtilityDao.CreateTemporaryTableFromExistingTable("sjdat_syznasi", "sjdat", true, true);
        }
    }
}
