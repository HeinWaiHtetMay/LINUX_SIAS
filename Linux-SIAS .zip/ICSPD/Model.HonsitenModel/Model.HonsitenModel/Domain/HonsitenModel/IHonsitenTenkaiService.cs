﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System.Collections.Generic;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DenpyouModel;

    public interface IHonsitenTenkaiService
    {
        HonsitenTenkaiServiceResult InsertHonsitenTenkaiSiwake<T>(HonsitenTenkaiParameter<T> parameter)
            where T : IDenpyouKey;
    }
}