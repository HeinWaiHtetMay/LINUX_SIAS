﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.DenpyouModel;

    public static class HonsitenTenkaiParameter
    {
        public static HonsitenTenkaiParameter<T> Create<T>(int kesn, IEnumerable<T> honsitenTenkaiTargetDenpyouKeyEnumerable)
            where T : IDenpyouKey
        {
            return new HonsitenTenkaiParameter<T>(kesn, honsitenTenkaiTargetDenpyouKeyEnumerable);
        }
    }
}
