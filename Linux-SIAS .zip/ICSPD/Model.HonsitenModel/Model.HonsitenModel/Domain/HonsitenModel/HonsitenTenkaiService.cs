﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    ////[Service(ServiceType.DomainService)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class HonsitenTenkaiService : IHonsitenTenkaiService
    {
        [AutoInjection]
        private IDenpyouFactory denpyouFactory = null;
        [AutoInjection]
        private IHonsitenTenkaiHeaderRepository honsitenTenkaiHeaderRepository = null;
        [AutoInjection]
        private IHonsitenTenkaiMeisaiRepository honsitenTenkaiMeisaiRepository = null;
        [AutoInjection]
        private InjectionContainer container = null;
        [AutoInjection]
        private ISiharaiNyuukinKamokuRepository siharaiNyuukinKamokuRepository = null;
        [AutoInjection]
        private ISiwakeRepository siwakeRepository = null;
        [AutoInjection]
        private IHonsitenTenkaiRepositoryFactory honsitenTenkaiFactory = null;

        #region public methods

        public virtual HonsitenTenkaiServiceResult InsertHonsitenTenkaiSiwake<T>(HonsitenTenkaiParameter<T> parameter)
            where T : IDenpyouKey
        {
            var header = this.honsitenTenkaiHeaderRepository?.FindByKesn(parameter.Kesn);
            if (header == null
                || !header.IsUseHonsitenZidouSiwakeProcessing
                || header.HonsitenProcessingType != HonsitenProcessingType.KakutyouIOProcessing)
            {
                //// 本支店展開ヘッダ情報がない、または本支店展開しない設定の場合、本支店展開しない
                return null;
            }

            var honsitenTenkaiMeisaiList = this.honsitenTenkaiMeisaiRepository?.FindByKesnAndHonsitenKubun(parameter.Kesn);
            if (honsitenTenkaiMeisaiList == null)
            {
                //// 本支店展開明細情報がなければ、本支店展開しない
                return new HonsitenTenkaiServiceResult();
            }

            var repository = this.honsitenTenkaiFactory.CreateHonsitenTenkaiSiwakeRepository(header.HonsitenSiwakeCreateOrder);
            var context = new HonsitenTenkaiContext(header, honsitenTenkaiMeisaiList, new MasterRepositoryCache(this.container), repository, this.siharaiNyuukinKamokuRepository.FindByKesnAsSiharaiNyuukinKamokuCodeCollection(parameter.Kesn));
            this.StoreHonsitenTenkaiSiwake(parameter, context);
            if (repository.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable != null)
            {
                repository.SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable.Dispose();
            }

            return new HonsitenTenkaiServiceResult(repository.HonsitenTenkaiSiwakeTemporaryTable);
        }

        #endregion

        #region private methods

        private void StoreHonsitenTenkaiSiwake<T>(HonsitenTenkaiParameter<T> parameter, HonsitenTenkaiContext context)
            where T : IDenpyouKey
        {
            var hontenMeisai = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.HonsitenKubun == HonsitenKubun.Honten);
            foreach (var denpyouPrimaryKey in parameter.HonsitenTenkaiTargetDenpyouPrimaryKeyEnumerable)
            {
                context.LineNoForAdjustment =
                context.GroupNoForAdjustment = 0;
                var siwakeList = context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder == HonsitenSiwakeCreateOrder.BeforeCreateSyouhizeiZidouSeiseiChildSiwake
                    ? this.CreateAndInsertSiwakeBeforeCreateSyouhizeiZidouSiwake(context, parameter.Kesn, denpyouPrimaryKey).ToList()
                    : this.siwakeRepository.FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(this.denpyouFactory.CreateKizonDenpyou(parameter.Kesn, denpyouPrimaryKey.Dkei, denpyouPrimaryKey.DenpyouSequenceNumber), DenpyouType.Busyo);
                var siwakeDictionary = context.HonsitenTenkaiHeader.HonsitenTenkaiMethod == HonsitenTenkaiMethod.TenkaiPerSiwakeRow
                    ? this.CreateSiwakeListAfterGroupNoRenumbered(siwakeList).ToMultiDictionary(siwake => siwake.GroupNumber)
                    : siwakeList.ToMultiDictionary(siwake => siwake.GroupNumber);
                foreach (var siwakeKeyValuePair in siwakeDictionary)
                {
                    var honsitenSiwakeList = new List<HonsitenTenkaiSiwake>();
                    foreach (var siwake in siwakeKeyValuePair.Value)
                    {
                        honsitenSiwakeList.Add(new HonsitenTenkaiSiwake(siwake, context.MasterRepositoryCache));
                    }

                    if (this.IsHonsitenTenkaiTargetDenpyou(honsitenSiwakeList, context))
                    {
                        //// 本支店展開する場合
                        if (honsitenSiwakeList[0].IsHonsitenTenkaiEnabledSiwake)
                        {
                            //// 本支店展開対象の仕訳のみの場合
                            if (context.HonsitenTenkaiHeader.IsTenkaiTradingBetweenSameHonsiten)
                            {
                                //// 同一本支店間取引を本支店展開する場合
                                this.InsertSitenKanzyouSiwake(context, honsitenSiwakeList, hontenMeisai?.Bcod);
                                this.InsertHontenKanzyouSiwake(context, honsitenSiwakeList, hontenMeisai);
                            }
                            else
                            {
                                //// 同一本支店間取引を本支店展開しない場合
                                this.InsertNotHonsitenTenkaiSiwakeInTradingBetweenSameHonsiten(context, honsitenSiwakeList, hontenMeisai?.Kicd);
                                this.InsertHonsitenTenkaiSiwakeInTradingBetweenSameHonsiten(context, honsitenSiwakeList, hontenMeisai);
                            }
                        }
                        else
                        {
                            //// 本支店展開対象外の仕訳が含まれる場合
                            this.InsertNotHonsitenTenkaiSiwake(context, honsitenSiwakeList);
                        }
                    }
                    else
                    {
                        //// 本支店展開しない場合
                        this.InsertNotHonsitenTenkaiSiwake(context, honsitenSiwakeList);
                    }

                    if (honsitenSiwakeList.Any(honsitenSiwake => !honsitenSiwake.IsHonsitenTenkaiEnabledSiwake)
                        && parameter.DeleteHonsitenTenkaiErrorDenpyou
                        && context.HonsitenTenkaiHeader.ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists == ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists.DoZaimuTenkiExpectDenpyouIncludingUnregisteredBumon)
                    {
                        //// 本支店展開不可の仕訳を含む伝票を除いて財務転記をおこなう設定の場合、本支店展開しない
                        return;
                    }

                    context.LineNoForAdjustment = context.InsertedMaxLineNo - siwakeKeyValuePair.Value.Max(siwake => siwake.LineNo);
                }
            }

            if (context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
            {
                //// 並べ替え処理を実行
                context.HonsitenTenkaiSiwakeRepository.UpdateSortKeys();
            }

            if (context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder == HonsitenSiwakeCreateOrder.BeforeCreateSyouhizeiZidouSeiseiChildSiwake)
            {
                //// 消費税自動生成子仕訳作成前の状態から本支店仕訳を作成
                this.InsertHonsitenTenkaiSiwakeAfterCreateSyouhizeiZidouSiwake(context);
            }

            //// 部門科目残高ﾃｰﾌﾞﾙに存在しない組合せのデータを更新
            context.HonsitenTenkaiSiwakeRepository.UpdateIsRegisteredAsBumonKamoku();

            //// 消費税行との親子関係を再構築
            context.HonsitenTenkaiSiwakeRepository.UpdateParentChildRelationship();

            if (parameter.DeleteHonsitenTenkaiErrorDenpyou
                && context.HonsitenTenkaiHeader.ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists == ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists.DoZaimuTenkiExpectDenpyouIncludingUnregisteredBumon)
            {
                //// NG仕訳が含まれる伝票を、一時テーブルから削除
                context.HonsitenTenkaiSiwakeRepository.DeleteBelongingToDenpyouContainsHonsitenTenkaiImpossibleSiwake();
            }
        }

        #region テンポラリテーブルへのINSERT

        /// <summary>
        /// 消費税自動生成子仕訳作成前の仕訳リストを作成し、テンポラリテーブルにINSERTします
        /// </summary>
        /// <param name="context"></param>
        /// <param name="kesn"></param>
        /// <param name="denpyouKey"></param>
        /// <returns></returns>
        private IList<Siwake> CreateAndInsertSiwakeBeforeCreateSyouhizeiZidouSiwake(HonsitenTenkaiContext context, int kesn, IDenpyouKey denpyouKey)
        {
            var siwakeList = new List<Siwake>();
            var syouhizeiSiwakeLineNoList = new List<int>();
            var siwakeDictionary = this.siwakeRepository.FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(this.denpyouFactory.CreateKizonDenpyou(kesn, denpyouKey.Dkei, denpyouKey.DenpyouSequenceNumber), DenpyouType.Busyo).ToMultiDictionary(siwake => siwake.GroupNumber);
            foreach (var siwakeKeyValuePair in siwakeDictionary)
            {
                foreach (var siwake in siwakeKeyValuePair.Value)
                {
                    if (siwake.ParentChildFlag == SiwakeParentChildRelated.Child
                        && siwakeKeyValuePair.Value.Any(value => value.ParentChildFlag == SiwakeParentChildRelated.Parent && value.ParentChildSiwakeSequenceNumber == siwake.SiwakeSequenceNumber && value.SiwakeSequenceNumber == siwake.ParentChildSiwakeSequenceNumber))
                    {
                        //// 子仕訳は追加しない
                        if (syouhizeiSiwakeLineNoList.Count == 0
                            || (syouhizeiSiwakeLineNoList.Count > 0 && syouhizeiSiwakeLineNoList.LastOrDefault() < siwake.LineNo))
                        {
                            syouhizeiSiwakeLineNoList.Add(siwake.LineNo);
                        }
                    }
                    else
                    {
                        if (siwake.ParentChildFlag == SiwakeParentChildRelated.Parent
                            && siwakeKeyValuePair.Value.Any(value => value.ParentChildFlag == SiwakeParentChildRelated.Child && value.ParentChildSiwakeSequenceNumber == siwake.SiwakeSequenceNumber && value.SiwakeSequenceNumber == siwake.ParentChildSiwakeSequenceNumber))
                        {
                            //// 親仕訳
                            if (siwake.BunriKubun == BunriKubun.ZidouBunri
                                || siwake.BunriKubun == BunriKubun.ZeiSakusei)
                            {
                                //// 分離区分が自動分離または税作成の場合、子仕訳金額を加算
                                siwake.Kingaku += siwakeKeyValuePair.Value.FirstOrDefault(value => value.ParentChildFlag == SiwakeParentChildRelated.Child && value.ParentChildSiwakeSequenceNumber == siwake.SiwakeSequenceNumber && value.SiwakeSequenceNumber == siwake.ParentChildSiwakeSequenceNumber).Kingaku;
                            }
                        }

                        //// 子仕訳以降の仕訳行番号を詰める
                        foreach (var syouhizeiSiwakeLineNo in syouhizeiSiwakeLineNoList)
                        {
                            if (syouhizeiSiwakeLineNo < siwake.LineNo)
                            {
                                siwake.LineNo--;
                            }
                        }

                        siwakeList.Add(siwake);
                        //// 親仕訳のみ追加（並べ替え用に、テンポラリテーブルへのINSERTも合わせておこなう）
                        context.HonsitenTenkaiSiwakeRepository.InsertSiwakeBeforeCreateSyouhizeiSiwake(siwake);
                    }
                }
            }

            return siwakeList;
        }

        private void InsertSitenKanzyouSiwake(HonsitenTenkaiContext context, IList<HonsitenTenkaiSiwake> honsitenSiwakeList, string hontenBumonCode)
        {
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);

                //// 自動分離後で、本支店展開時に振替子仕訳の場合、本支店展開しない
                if (context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder != HonsitenSiwakeCreateOrder.AfterCreateSyouhizeiZidouSeiseiChildSiwake
                    || honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei
                    || honsitenSiwake.Siwake.ParentChildFlag != SiwakeParentChildRelated.Child)
                {
                    //// 借方
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                        && honsitenSiwake.Siwake.KarikataBumonCode != hontenBumonCode)
                    {
                        //// 借方部門が本店部門、または本支店に結びつかない場合、本支店展開しない
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                        honsitenSiwakeForInsert.Siwake.KarikataBumonCode = hontenBumonCode;
                        honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KarikataBumonCode)?.Kicd;
                        honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.IsKarikataChild =
                        honsitenSiwakeForInsert.IsKarikataParent = false;
                        honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                        this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, true);
                    }

                    //// 貸方
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                        && honsitenSiwake.Siwake.KasikataBumonCode != hontenBumonCode)
                    {
                        //// 貸方部門が本店部門、または本支店に結びつかない場合、本支店展開しない
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);
                        honsitenSiwakeForInsert.Siwake.KasikataBumonCode = hontenBumonCode;
                        honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KasikataBumonCode)?.Kicd;
                        honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.IsKasikataChild =
                        honsitenSiwakeForInsert.IsKasikataParent = false;
                        honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                        this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, false, true);
                    }
                }

                //// 貸借共に支店勘定セット済、または相手科目が諸口の場合、各項目をクリア
                if ((honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata && honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou))
                {
                    this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, false);
                }

                honsitenSiwakeForInsert.PrimaryKey =
                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);
                honsitenSiwakeForInsert.Siwake.LineNo += context.LineNoForAdjustment;
                honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment;

                //// Insert処理
                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                context.CurrentPrimaryKey++;
                context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
            }
        }

        /// <summary>
        /// 本店勘定仕訳を挿入します
        /// </summary>
        /// <param name="context"></param>
        /// <param name="honsitenSiwakeList"></param>
        /// <param name="hontenMeisai"></param>
        private void InsertHontenKanzyouSiwake(HonsitenTenkaiContext context, IList<HonsitenTenkaiSiwake> honsitenSiwakeList, HonsitenTenkaiMeisai hontenMeisai)
        {
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                //// 自動分離後で、本支店展開時に振替子仕訳の場合、本支店展開しない
                if (context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder != HonsitenSiwakeCreateOrder.AfterCreateSyouhizeiZidouSeiseiChildSiwake
                    || honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei
                    || honsitenSiwake.Siwake.ParentChildFlag != SiwakeParentChildRelated.Child)
                {
                    //// 借方
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                        && honsitenSiwake.Siwake.KarikataBumonCode != hontenMeisai.Bcod)
                    {
                        //// 借方部門が本店部門、または本支店に結びつかない場合、本支店展開しない
                        var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);
                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        honsitenSiwakeForInsert.Siwake.KasikataBumonCode = honsitenSiwake.Siwake.KarikataBumonCode;
                        honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = hontenMeisai.Kicd;
                        honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.HontenKanzyou;
                        honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                        honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;

                        if (honsitenSiwake.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku)
                        {
                            this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, false, true);
                        }

                        honsitenSiwakeForInsert.IsKasikataChild =
                        honsitenSiwakeForInsert.IsKasikataParent = false;
                        if (!honsitenSiwakeForInsert.IsKarikataParent
                            && !honsitenSiwakeForInsert.IsKarikataChild)
                        {
                            honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                            honsitenSiwakeForInsert.Siwake.BunriKubun = BunriKubun.NotSet;
                            honsitenSiwakeForInsert.Siwake.ZeikomiKingaku = 0;
                        }

                        honsitenSiwakeForInsert.PrimaryKey =
                        honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                        honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);

                        //// Insert処理
                        context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                        context.CurrentPrimaryKey++;
                        context.GroupNoForAdjustment++;
                        context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
                    }

                    //// 貸方
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                        && honsitenSiwake.Siwake.KasikataBumonCode != hontenMeisai.Bcod)
                    {
                        //// 貸方部門が本店部門、または本支店に結びつかない場合、本支店展開しない
                        var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        honsitenSiwakeForInsert.Siwake.KarikataBumonCode = honsitenSiwake.Siwake.KasikataBumonCode;
                        honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = hontenMeisai.Kicd;
                        honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.HontenKanzyou;
                        honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                        honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;

                        if (honsitenSiwake.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku)
                        {
                            this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, true);
                        }

                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        honsitenSiwakeForInsert.IsKarikataChild =
                        honsitenSiwakeForInsert.IsKarikataParent = false;
                        if (!honsitenSiwakeForInsert.IsKasikataParent
                            && !honsitenSiwakeForInsert.IsKasikataChild)
                        {
                            honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                            honsitenSiwakeForInsert.Siwake.BunriKubun = BunriKubun.NotSet;
                            honsitenSiwakeForInsert.Siwake.ZeikomiKingaku = 0;
                        }

                        honsitenSiwakeForInsert.PrimaryKey =
                        honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                        honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);

                        //// Insert処理
                        context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                        context.CurrentPrimaryKey++;
                        context.GroupNoForAdjustment++;
                        context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
                    }
                }
            }
        }

        /// <summary>
        /// 同一本支店間取引において、本支店展開しない仕訳を挿入します
        /// </summary>
        /// <param name="context"></param>
        /// <param name="honsitenSiwakeList"></param>
        /// <param name="hontenKamokuCode"></param>
        private void InsertNotHonsitenTenkaiSiwakeInTradingBetweenSameHonsiten(HonsitenTenkaiContext context, IList<HonsitenTenkaiSiwake> honsitenSiwakeList, string hontenKamokuCode)
        {
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                //// 自動分離後で、本支店展開時に振替子仕訳の場合、本支店展開しない
                if (context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder != HonsitenSiwakeCreateOrder.AfterCreateSyouhizeiZidouSeiseiChildSiwake
                    || honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei
                    || honsitenSiwake.Siwake.ParentChildFlag != SiwakeParentChildRelated.Child)
                {
                    //// 借方
                    var karikataHonsitenKamokuCode = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KarikataBumonCode)?.Kicd;
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                        && karikataHonsitenKamokuCode != context.HonsitenKamokuCodeForTradingBetweenSameHonsiten)
                    {
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                        honsitenSiwakeForInsert.Siwake.KarikataBumonCode = context.HonsitenBumonCodeForTradingBetweenSameHonsiten;
                        honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten == hontenKamokuCode
                            ? karikataHonsitenKamokuCode
                            : hontenKamokuCode;
                        honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.IsKarikataChild =
                        honsitenSiwakeForInsert.IsKarikataParent = false;
                        honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                        this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, true);
                    }

                    //// 貸方
                    var kasikataHonsitenKamokuCode = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KasikataBumonCode)?.Kicd;
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                        && kasikataHonsitenKamokuCode != context.HonsitenKamokuCodeForTradingBetweenSameHonsiten)
                    {
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);
                        honsitenSiwakeForInsert.Siwake.KasikataBumonCode = context.HonsitenBumonCodeForTradingBetweenSameHonsiten;
                        honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten == hontenKamokuCode
                            ? kasikataHonsitenKamokuCode
                            : hontenKamokuCode;
                        honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.IsKasikataChild =
                        honsitenSiwakeForInsert.IsKasikataParent = false;
                        honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                        this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, false, true);
                    }

                    //// 貸借共に支店勘定セット済、または相手科目が諸口の場合、各項目をクリア
                    if ((honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                        || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata && honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                        || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou))
                    {
                        this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, false);
                    }
                }

                honsitenSiwakeForInsert.PrimaryKey =
                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);
                honsitenSiwakeForInsert.Siwake.LineNo += context.LineNoForAdjustment;
                honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment;

                //// Insert処理
                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                context.CurrentPrimaryKey++;
                context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
            }
        }

        /// <summary>
        /// 同一本支店間取引において、本支店展開する仕訳を挿入します
        /// </summary>
        /// <param name="context"></param>
        /// <param name="honsitenSiwakeList"></param>
        /// <param name="hontenMeisai"></param>
        private void InsertHonsitenTenkaiSiwakeInTradingBetweenSameHonsiten(HonsitenTenkaiContext context, IList<HonsitenTenkaiSiwake> honsitenSiwakeList, HonsitenTenkaiMeisai hontenMeisai)
        {
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                //// 自動分離後で、本支店展開時に振替子仕訳の場合、本支店展開しない
                if (context.HonsitenTenkaiHeader.HonsitenSiwakeCreateOrder != HonsitenSiwakeCreateOrder.AfterCreateSyouhizeiZidouSeiseiChildSiwake
                    || honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei
                    || honsitenSiwake.Siwake.ParentChildFlag != SiwakeParentChildRelated.Child)
                {
                    //// 借方
                    var karikataHonsitenValue = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KarikataBumonCode);
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                        && karikataHonsitenValue?.Kicd != context.HonsitenKamokuCodeForTradingBetweenSameHonsiten)
                    {
                        var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);
                        honsitenSiwakeForInsert.Siwake.KasikataBumonCode = karikataHonsitenValue?.Bcod;
                        honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                        honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;
                        honsitenSiwakeForInsert.PrimaryKey =
                        honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                        honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);
                        honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.HontenKanzyou;
                        honsitenSiwakeForInsert.IsKasikataChild =
                        honsitenSiwakeForInsert.IsKasikataParent = false;

                        if (honsitenSiwake.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku)
                        {
                            this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, false, true);
                        }

                        if (!honsitenSiwakeForInsert.IsKarikataParent
                            && !honsitenSiwakeForInsert.IsKarikataChild)
                        {
                            honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                            honsitenSiwakeForInsert.Siwake.BunriKubun = BunriKubun.NotSet;
                            honsitenSiwakeForInsert.Siwake.ZeikomiKingaku = 0;
                        }

                        if (string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                            || karikataHonsitenValue?.Kicd == hontenMeisai?.Kicd)
                        {
                            //// 本店
                            honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten;

                            //// Insert処理
                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                        }
                        else
                        {
                            //// 本店以外
                            honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = hontenMeisai?.Kicd;

                            //// Insert処理
                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                            context.CurrentPrimaryKey++;
                            context.GroupNoForAdjustment++;
                            context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;

                            if (context.HonsitenKamokuCodeForTradingBetweenSameHonsiten != hontenMeisai?.Kicd)
                            {
                                //// 本支店展開しない科目が支店の場合
                                honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                                this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                                this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);

                                //// 借方には本店部門と展開する支店、貸方には本店部門と展開しない支店をセット
                                honsitenSiwakeForInsert.Siwake.KarikataBumonCode =
                                honsitenSiwakeForInsert.Siwake.KasikataBumonCode = hontenMeisai?.Bcod;
                                honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = karikataHonsitenValue?.Kicd;
                                honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten;
                                honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                                honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun =
                                honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                                honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag =
                                honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                                honsitenSiwakeForInsert.IsKarikataChild =
                                honsitenSiwakeForInsert.IsKasikataChild =
                                honsitenSiwakeForInsert.IsKarikataParent =
                                honsitenSiwakeForInsert.IsKasikataParent = false;
                                honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                                honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;
                                honsitenSiwakeForInsert.PrimaryKey =
                                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                                honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);

                                //// 貸借共に支店勘定セット済、または相手科目が諸口の場合、各項目をクリア
                                if ((honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata && honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou))
                                {
                                    this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, false);
                                }

                                //// Insert処理
                                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                            }
                        }

                        context.CurrentPrimaryKey++;
                        context.GroupNoForAdjustment++;
                        context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
                    }

                    //// 貸方
                    var kasikataHonsitenValue = context.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Kesn == honsitenSiwake.Siwake.Kesn && meisai.Bcod == honsitenSiwake.Siwake.KasikataBumonCode);
                    if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                        && kasikataHonsitenValue?.Kicd != context.HonsitenKamokuCodeForTradingBetweenSameHonsiten)
                    {
                        var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                        this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                        honsitenSiwakeForInsert.Siwake.KarikataBumonCode = kasikataHonsitenValue?.Bcod;
                        honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                        honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;
                        honsitenSiwakeForInsert.PrimaryKey =
                        honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                        honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);
                        honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.HontenKanzyou;
                        honsitenSiwakeForInsert.IsKasikataChild =
                        honsitenSiwakeForInsert.IsKasikataParent = false;

                        if (honsitenSiwake.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku)
                        {
                            this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, true);
                        }

                        if (!honsitenSiwakeForInsert.IsKasikataParent
                            && !honsitenSiwakeForInsert.IsKasikataChild)
                        {
                            honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                            honsitenSiwakeForInsert.Siwake.BunriKubun = BunriKubun.NotSet;
                            honsitenSiwakeForInsert.Siwake.ZeikomiKingaku = 0;
                        }

                        if (string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                            || kasikataHonsitenValue?.Kicd == hontenMeisai?.Kicd)
                        {
                            //// 本店
                            honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten;

                            //// Insert処理
                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                            context.CurrentPrimaryKey++;
                            context.GroupNoForAdjustment++;
                            context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
                        }
                        else
                        {
                            //// 本店以外
                            honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = hontenMeisai?.Kicd;

                            //// Insert処理
                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                            context.CurrentPrimaryKey++;
                            context.GroupNoForAdjustment++;
                            context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;

                            if (context.HonsitenKamokuCodeForTradingBetweenSameHonsiten != hontenMeisai?.Kicd)
                            {
                                //// 本支店展開しない科目が支店の場合
                                honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                                this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, true);
                                this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, false);

                                //// 借方には本店部門と展開する支店、貸方には本店部門と展開しない支店をセット
                                honsitenSiwakeForInsert.Siwake.KarikataBumonCode =
                                honsitenSiwakeForInsert.Siwake.KasikataBumonCode = hontenMeisai?.Bcod;
                                honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = context.HonsitenKamokuCodeForTradingBetweenSameHonsiten;
                                honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = kasikataHonsitenValue?.Kicd;
                                honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                                honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun =
                                honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                                honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag =
                                honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.SitenKanzyou;
                                honsitenSiwakeForInsert.IsKarikataChild =
                                honsitenSiwakeForInsert.IsKasikataChild =
                                honsitenSiwakeForInsert.IsKarikataParent =
                                honsitenSiwakeForInsert.IsKasikataParent = false;
                                honsitenSiwakeForInsert.Siwake.LineNo = context.InsertedMaxLineNo + 1;
                                honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment + 1;
                                honsitenSiwakeForInsert.PrimaryKey =
                                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                                honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);

                                //// 貸借共に支店勘定セット済、または相手科目が諸口の場合、各項目をクリア
                                if ((honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata && honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou)
                                    || (honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata && honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.SitenKanzyou))
                                {
                                    this.InitializeHonsitenTenkaiSiwake(context, honsitenSiwakeForInsert, honsitenSiwake.Siwake, true, false);
                                }

                                //// Insert処理
                                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                                context.CurrentPrimaryKey++;
                                context.GroupNoForAdjustment++;
                                context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 本支店展開しない仕訳を挿入します
        /// </summary>
        /// <param name="context"></param>
        /// <param name="honsitenSiwakeList"></param>
        private void InsertNotHonsitenTenkaiSiwake(HonsitenTenkaiContext context, IList<HonsitenTenkaiSiwake> honsitenSiwakeList)
        {
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                honsitenSiwakeForInsert.PrimaryKey =
                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = context.CurrentPrimaryKey;
                honsitenSiwakeForInsert.Siwake.SetSseq(context.CurrentPrimaryKey);
                honsitenSiwakeForInsert.Siwake.LineNo += context.LineNoForAdjustment;
                honsitenSiwakeForInsert.Siwake.GroupNumber += context.GroupNoForAdjustment;

                //// Insert処理
                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                context.CurrentPrimaryKey++;
                context.InsertedMaxLineNo = honsitenSiwakeForInsert.Siwake.LineNo;
            }
        }

        /// <summary>
        /// 消費税自動生成子仕訳作成後の本支店仕訳を挿入します
        /// </summary>
        /// <param name="context"></param>
        private void InsertHonsitenTenkaiSiwakeAfterCreateSyouhizeiZidouSiwake(HonsitenTenkaiContext context)
        {
            var previousDkei = 0;
            var previousDseq = 0;
            var previousGroupNo = 0;
            var primaryKeyForInsert = 0;
            var lineNoDifference = 0;
            var syouhizeiSiwakeLineNoList = new List<int>();
            foreach (var honsitenSiwake in context.HonsitenTenkaiSiwakeRepository.FindValidSiwakeListOrderBySortKeys(context.MasterRepositoryCache))
            {
                var siwakeList = this.siwakeRepository.FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(this.denpyouFactory.CreateKizonDenpyou(honsitenSiwake.Siwake.Kesn, honsitenSiwake.Siwake.Dkei, honsitenSiwake.Siwake.DenpyouSequenceNumber), DenpyouType.Busyo);
                var parentSiwake = siwakeList.FirstOrDefault(siwake => siwake.SiwakeSequenceNumber == honsitenSiwake.SseqBeforeHonsitenTenkai);
                var childSiwake = siwakeList.FirstOrDefault(siwake => siwake.SiwakeSequenceNumber == honsitenSiwake.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai);
                if (previousDkei != honsitenSiwake.Siwake.Dkei
                    || previousDseq != honsitenSiwake.Siwake.DenpyouSequenceNumber)
                {
                    lineNoDifference = 0;
                }

                if (previousDkei != honsitenSiwake.Siwake.Dkei
                    || previousDseq != honsitenSiwake.Siwake.DenpyouSequenceNumber
                    || previousGroupNo != honsitenSiwake.Siwake.GroupNumber)
                {
                    syouhizeiSiwakeLineNoList.Clear();
                    previousDkei = honsitenSiwake.Siwake.Dkei;
                    previousDseq = honsitenSiwake.Siwake.DenpyouSequenceNumber;
                    previousGroupNo = honsitenSiwake.Siwake.GroupNumber;
                }

                var honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                if (honsitenSiwake.Siwake.BunriKubun != BunriKubun.NotSet)
                {
                    //// 自動分離・振替作成・税作成
                    if (syouhizeiSiwakeLineNoList.Count == 0
                        || (syouhizeiSiwakeLineNoList.Count > 0 && syouhizeiSiwakeLineNoList.LastOrDefault() < honsitenSiwake.Siwake.LineNo))
                    {
                        syouhizeiSiwakeLineNoList.Add(honsitenSiwake.Siwake.LineNo);
                    }

                    foreach (var syouhizeiSiwakeLineNo in syouhizeiSiwakeLineNoList)
                    {
                        if (syouhizeiSiwakeLineNo < honsitenSiwake.Siwake.LineNo)
                        {
                            honsitenSiwake.Siwake.LineNo++;
                        }
                    }

                    //// 単一
                    if (honsitenSiwake.DenpyouKeisiki != DenpyouKeisiki.Hukugou)
                    {
                        //// 親仕訳
                        if (honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZidouBunri
                            || honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZeiSakusei)
                        {
                            //// 子仕訳分の金額追加前の金額に戻す
                            honsitenSiwakeForInsert.Siwake.Kingaku = parentSiwake.Kingaku;
                        }

                        honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                        honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;
                        if (!context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
                        {
                            honsitenSiwakeForInsert.Siwake.LineNo += lineNoDifference;
                        }

                        context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                        //// 子仕訳
                        honsitenSiwakeForInsert.SetSiwake(childSiwake.CloneAsDeepCopy(), true, true);
                        if (honsitenSiwake.IsKarikataParent
                            && !honsitenSiwake.IsKasikataParent
                            && honsitenSiwake.Siwake.KasikataKamokuCode != childSiwake.KasikataKamokuCode
                            && honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei)
                        {
                            //// 貸方のみセット
                            honsitenSiwakeForInsert.SetSiwake(honsitenSiwake.Siwake, false, true);
                        }
                        else if (!honsitenSiwake.IsKarikataParent
                                 && honsitenSiwake.Siwake.KarikataKamokuCode != childSiwake.KarikataKamokuCode
                                 && honsitenSiwake.Siwake.BunriKubun != BunriKubun.HurikaeSakusei)
                        {
                            //// 借方のみセット
                            honsitenSiwakeForInsert.SetSiwake(honsitenSiwake.Siwake, true, false);
                        }

                        honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = childSiwake.SiwakeSequenceNumber;
                        honsitenSiwakeForInsert.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = honsitenSiwake.SseqBeforeHonsitenTenkai;

                        honsitenSiwakeForInsert.IsKarikataChild = honsitenSiwake.IsKarikataParent;
                        honsitenSiwakeForInsert.IsKasikataChild = honsitenSiwake.IsKasikataParent;
                        honsitenSiwakeForInsert.IsKarikataParent =
                        honsitenSiwakeForInsert.IsKasikataParent = false;

                        this.SetBumonRelatedFlagInHonsitenSiwake(honsitenSiwakeForInsert, honsitenSiwake);

                        honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                        honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;
                        honsitenSiwakeForInsert.Siwake.GroupNumber = honsitenSiwake.Siwake.GroupNumber;
                        lineNoDifference++;
                        honsitenSiwakeForInsert.Siwake.LineNo = context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai
                            ? honsitenSiwake.Siwake.LineNo + 1
                            : honsitenSiwake.Siwake.LineNo + lineNoDifference;

                        context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                    }
                    else
                    {
                        //// 複合
                        if (honsitenSiwake.IsKarikataParent
                            && honsitenSiwake.IsKasikataParent)
                        {
                            //// 親仕訳
                            this.SetTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake, parentSiwake);
                            honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai =
                            honsitenSiwakeForInsert.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = parentSiwake.SiwakeSequenceNumber;
                            honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = parentSiwake.SiwakeTaisyakuZokusei;
                            if (honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZidouBunri
                                || honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZeiSakusei)
                            {
                                //// 子仕訳分の金額追加前の金額に戻す
                                honsitenSiwakeForInsert.Siwake.Kingaku = parentSiwake.Kingaku;
                            }

                            honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                            honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;
                            if (!honsitenSiwake.IsKarikataParent)
                            {
                                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = primaryKeyForInsert;
                            }

                            if (!context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
                            {
                                honsitenSiwakeForInsert.Siwake.LineNo += lineNoDifference;
                            }

                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);

                            //// 子仕訳
                            honsitenSiwakeForInsert.SetSiwake(childSiwake.CloneAsDeepCopy(), true, true);
                            honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = childSiwake.SiwakeSequenceNumber;
                            honsitenSiwakeForInsert.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = parentSiwake.SiwakeSequenceNumber;
                            honsitenSiwakeForInsert.Siwake.GroupNumber = honsitenSiwake.Siwake.GroupNumber;
                            lineNoDifference++;
                            honsitenSiwakeForInsert.Siwake.LineNo = context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai
                                ? honsitenSiwake.Siwake.LineNo + 1
                                : honsitenSiwake.Siwake.LineNo + lineNoDifference;
                            honsitenSiwakeForInsert.IsKarikataParent =
                            honsitenSiwakeForInsert.IsKasikataParent = false;
                            honsitenSiwakeForInsert.IsKarikataChild =
                            honsitenSiwakeForInsert.IsKasikataChild = true;

                            this.SetBumonRelatedFlagInHonsitenSiwake(honsitenSiwakeForInsert, honsitenSiwake);
                            honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                            honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;

                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                        }
                        else
                        {
                            //// 借方
                            if (!new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KarikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                            {
                                if (honsitenSiwake.IsKarikataParent)
                                {
                                    //// 借方が親
                                    if (honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZidouBunri
                                        || honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZeiSakusei)
                                    {
                                        honsitenSiwakeForInsert.Siwake.Kingaku = parentSiwake.Kingaku;
                                    }

                                    if (new KamokuInnerCodeFormat(parentSiwake.KasikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                                    {
                                        honsitenSiwakeForInsert.SetSiwake(parentSiwake, false, true);
                                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = parentSiwake.SiwakeTaisyakuZokusei;
                                    }
                                    else
                                    {
                                        this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, false);
                                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Karikata;
                                        if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                        {
                                            honsitenSiwakeForInsert.Siwake.KasikataTekiyou = null;
                                            if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                                && !string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                            {
                                                honsitenSiwakeForInsert.Siwake.KarikataTekiyou = honsitenSiwakeForInsert.Siwake.KasikataTekiyou;
                                            }
                                        }
                                    }

                                    if (honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.Nothing)
                                    {
                                        this.SetTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake, parentSiwake);
                                    }
                                    else
                                    {
                                        this.ClearTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake);
                                    }

                                    honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = parentSiwake.SiwakeSequenceNumber;
                                }
                                else
                                {
                                    this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, false);
                                    this.ClearTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake);
                                    honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = honsitenSiwake.Siwake.SiwakeSequenceNumber;
                                    honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Karikata;
                                    if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                    {
                                        honsitenSiwakeForInsert.Siwake.KasikataTekiyou = null;
                                        if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                            && !string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                        {
                                            honsitenSiwakeForInsert.Siwake.KarikataTekiyou = honsitenSiwakeForInsert.Siwake.KasikataTekiyou;
                                        }
                                    }
                                }

                                honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                                honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;
                                if (!honsitenSiwake.IsKarikataParent)
                                {
                                    honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = primaryKeyForInsert;
                                }

                                if (!context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
                                {
                                    honsitenSiwakeForInsert.Siwake.LineNo += lineNoDifference;
                                }

                                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                            }

                            //// 貸方
                            honsitenSiwakeForInsert = this.CreateHonsitenSiwakeForInsert(honsitenSiwake, context.HonsitenTenkaiMeisaiList);
                            if (!new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KasikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                            {
                                if (honsitenSiwake.IsKasikataParent)
                                {
                                    //// 貸方が親
                                    if (honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZidouBunri
                                        || honsitenSiwakeForInsert.Siwake.BunriKubun == BunriKubun.ZeiSakusei)
                                    {
                                        honsitenSiwakeForInsert.Siwake.Kingaku = parentSiwake.Kingaku;
                                    }

                                    if (new KamokuInnerCodeFormat(parentSiwake.KarikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                                    {
                                        honsitenSiwakeForInsert.SetSiwake(parentSiwake, true, false);
                                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = parentSiwake.SiwakeTaisyakuZokusei;
                                    }
                                    else
                                    {
                                        this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, true);
                                        honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Kasikata;
                                        if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                        {
                                            honsitenSiwakeForInsert.Siwake.KasikataTekiyou = null;
                                            if (!string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                                && string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                            {
                                                honsitenSiwakeForInsert.Siwake.KasikataTekiyou = honsitenSiwakeForInsert.Siwake.KarikataTekiyou;
                                            }
                                        }
                                    }

                                    if (honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag == HonsitenKanzyouSetFlag.Nothing)
                                    {
                                        this.SetTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake, parentSiwake);
                                    }
                                    else
                                    {
                                        this.ClearTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake);
                                    }

                                    honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = parentSiwake.SiwakeSequenceNumber;
                                }
                                else
                                {
                                    this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, true);
                                    this.ClearTaisyakuCommonValue(honsitenSiwakeForInsert.Siwake);
                                    honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = honsitenSiwake.Siwake.SiwakeSequenceNumber;
                                    honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Kasikata;
                                    if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                    {
                                        honsitenSiwakeForInsert.Siwake.KasikataTekiyou = null;
                                        if (!string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                            && string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                        {
                                            honsitenSiwakeForInsert.Siwake.KasikataTekiyou = honsitenSiwakeForInsert.Siwake.KarikataTekiyou;
                                        }
                                    }
                                }

                                honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                                honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;
                                if (!honsitenSiwake.IsKasikataParent)
                                {
                                    honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = primaryKeyForInsert;
                                }

                                if (!context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
                                {
                                    honsitenSiwakeForInsert.Siwake.LineNo += lineNoDifference;
                                }

                                context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                            }

                            //// 子仕訳
                            honsitenSiwakeForInsert.SetSiwake(childSiwake.CloneAsDeepCopy(), true, true);
                            if (honsitenSiwake.IsKarikataParent)
                            {
                                if (!new KamokuInnerCodeFormat(childSiwake.KasikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                                {
                                    this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, false);
                                    honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Karikata;
                                    if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                    {
                                        honsitenSiwakeForInsert.Siwake.KasikataTekiyou = null;
                                        if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                            && !string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                        {
                                            honsitenSiwakeForInsert.Siwake.KarikataTekiyou = honsitenSiwakeForInsert.Siwake.KasikataTekiyou;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (!new KamokuInnerCodeFormat(childSiwake.KarikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
                                {
                                    this.SetSiwakeSyokutiValue(honsitenSiwakeForInsert, true);
                                    honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei = SiwakeTaisyakuZokusei.Kasikata;
                                    if (honsitenSiwakeForInsert.Siwake.IsTaisyakubetuTekiyou)
                                    {
                                        honsitenSiwakeForInsert.Siwake.KarikataTekiyou = null;
                                        if (!string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataTekiyou)
                                            && string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataTekiyou))
                                        {
                                            honsitenSiwakeForInsert.Siwake.KasikataTekiyou = honsitenSiwakeForInsert.Siwake.KarikataTekiyou;
                                        }
                                    }
                                }
                            }

                            honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = childSiwake.SiwakeSequenceNumber;
                            honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = parentSiwake.SiwakeSequenceNumber;
                            honsitenSiwakeForInsert.Siwake.GroupNumber = honsitenSiwake.Siwake.GroupNumber;
                            lineNoDifference++;
                            honsitenSiwakeForInsert.Siwake.LineNo = context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai
                                ? honsitenSiwake.Siwake.LineNo + 1
                                : honsitenSiwake.Siwake.LineNo + lineNoDifference;
                            honsitenSiwakeForInsert.IsKarikataChild = honsitenSiwake.IsKarikataParent;
                            honsitenSiwakeForInsert.IsKasikataChild = !honsitenSiwake.IsKarikataParent;
                            honsitenSiwakeForInsert.IsKarikataParent =
                            honsitenSiwakeForInsert.IsKasikataParent = false;
                            this.SetBumonRelatedFlagInHonsitenSiwake(honsitenSiwakeForInsert, honsitenSiwake);
                            honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                            honsitenSiwakeForInsert.PrimaryKey = primaryKeyForInsert;

                            context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                        }
                    }
                }
                else
                {
                    foreach (var syouhizeiSiwakeLineNo in syouhizeiSiwakeLineNoList)
                    {
                        if (syouhizeiSiwakeLineNo < honsitenSiwake.Siwake.LineNo)
                        {
                            honsitenSiwake.Siwake.LineNo++;
                        }
                    }

                    if (!context.HonsitenTenkaiHeader.IsSortBySiwakeLineNoBeforeHonsitenTenkai)
                    {
                        honsitenSiwakeForInsert.Siwake.LineNo += lineNoDifference;
                    }

                    honsitenSiwakeForInsert.Siwake.SetSseq(primaryKeyForInsert++);
                    honsitenSiwakeForInsert.PrimaryKey =
                    honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = primaryKeyForInsert;
                    context.HonsitenTenkaiSiwakeRepository.Insert(honsitenSiwakeForInsert);
                }
            }
        }

        #endregion

        #region 値の初期化

        /// <summary>
        /// 貸借共通の値をクリアします
        /// </summary>
        /// <param name="siwakeForInsert">挿入用仕訳データ</param>
        private void ClearTaisyakuCommonValue(Siwake siwakeForInsert)
        {
            //// 親子関係
            siwakeForInsert.ParentChildFlag = SiwakeParentChildRelated.Nothing;
            siwakeForInsert.ParentChildSiwakeSequenceNumber = siwakeForInsert.SiwakeSequenceNumber;
            siwakeForInsert.BunriKubun = BunriKubun.NotSet;
            siwakeForInsert.ZeikomiKingaku = 0;

            //// 対価関係
            siwakeForInsert.IsInputTaika = false;
            siwakeForInsert.TaikaKingaku = 0;

            //// 税対象関係
            siwakeForInsert.ZeitaisyouKamokuCode = null;
            siwakeForInsert.ZeitaisyouKamokuZeiritu = null;
            siwakeForInsert.ZeitaisyouKamokuKazeiKubun = KazeiKubun.消費税設定対象外;
            siwakeForInsert.ZeitaisyouKamokuGyousyuKubun = GyousyuKubun.None;
            siwakeForInsert.ZeitaisyouKamokuSiireKubun = SiwakeSiireKubun.Taisyougai;

            //// 支払関係
            siwakeForInsert.Siharaibi =
            siwakeForInsert.SiharaiKizitu = 0;
            siwakeForInsert.SiharaiKubun = null;

            //// 入金関係
            siwakeForInsert.Kaisyuubi =
            siwakeForInsert.KaisyuuKizitu = 0;
            siwakeForInsert.NyuukinKubun = null;

            //// 外貨関係
            siwakeForInsert.Rate =
            siwakeForInsert.GaikaKingaku =
            siwakeForInsert.GaikaTaikaKingaku =
            siwakeForInsert.GaikaZeikomiKingaku = 0;

            //// 消込関係
            siwakeForInsert.KesikomiCode =
            siwakeForInsert.KesikomiGroupCode = null;
            siwakeForInsert.IsKesikomiZero =
            siwakeForInsert.IsKesikomiUpdate =
            siwakeForInsert.IsKesikomiTyuusyutu = false;
        }

        /// <summary>
        /// 貸借別仕訳項目の値をクリアします
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="isKarikata">借方かどうか</param>
        private void ClearSiwakeTaisyakubetuValue(Siwake siwake, bool isKarikata)
        {
            if (isKarikata)
            {
                //// 借方項目の値をクリア
                siwake.KarikataBumonCode =
                siwake.KarikataTorihikisakiCode =
                siwake.KarikataKamokuCode =
                siwake.KarikataEdabanCode =
                siwake.KarikataKouziCode =
                siwake.KarikataKousyuCode =
                siwake.KarikataProjectCode =
                siwake.KarikataSegmentCode =
                siwake.KarikataHeisyuCode =
                siwake.KarikataUniversalField1Code =
                siwake.KarikataUniversalField2Code =
                siwake.KarikataUniversalField3Code =
                siwake.KarikataUniversalField4Code =
                siwake.KarikataUniversalField5Code =
                siwake.KarikataUniversalField6Code =
                siwake.KarikataUniversalField7Code =
                siwake.KarikataUniversalField8Code =
                siwake.KarikataUniversalField9Code =
                siwake.KarikataUniversalField10Code =
                siwake.KarikataUniversalField11Code =
                siwake.KarikataUniversalField12Code =
                siwake.KarikataUniversalField13Code =
                siwake.KarikataUniversalField14Code =
                siwake.KarikataUniversalField15Code =
                siwake.KarikataUniversalField16Code =
                siwake.KarikataUniversalField17Code =
                siwake.KarikataUniversalField18Code =
                siwake.KarikataUniversalField19Code =
                siwake.KarikataUniversalField20Code = null;
                siwake.KarikataZeiritu = null;
                siwake.KarikataKazeiKubun = KazeiKubun.対象外;
                siwake.KarikataGyousyuKubun = GyousyuKubun.None;
                siwake.KarikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                siwake.KarikataTekiyouCode = null;
            }
            else
            {
                //// 貸方項目の値をクリア
                siwake.KasikataBumonCode =
                siwake.KasikataTorihikisakiCode =
                siwake.KasikataKamokuCode =
                siwake.KasikataEdabanCode =
                siwake.KasikataKouziCode =
                siwake.KasikataKousyuCode =
                siwake.KasikataProjectCode =
                siwake.KasikataSegmentCode =
                siwake.KasikataHeisyuCode =
                siwake.KasikataUniversalField1Code =
                siwake.KasikataUniversalField2Code =
                siwake.KasikataUniversalField3Code =
                siwake.KasikataUniversalField4Code =
                siwake.KasikataUniversalField5Code =
                siwake.KasikataUniversalField6Code =
                siwake.KasikataUniversalField7Code =
                siwake.KasikataUniversalField8Code =
                siwake.KasikataUniversalField9Code =
                siwake.KasikataUniversalField10Code =
                siwake.KasikataUniversalField11Code =
                siwake.KasikataUniversalField12Code =
                siwake.KasikataUniversalField13Code =
                siwake.KasikataUniversalField14Code =
                siwake.KasikataUniversalField15Code =
                siwake.KasikataUniversalField16Code =
                siwake.KasikataUniversalField17Code =
                siwake.KasikataUniversalField18Code =
                siwake.KasikataUniversalField19Code =
                siwake.KasikataUniversalField20Code = null;
                siwake.KasikataZeiritu = null;
                siwake.KasikataKazeiKubun = KazeiKubun.対象外;
                siwake.KasikataGyousyuKubun = GyousyuKubun.None;
                siwake.KasikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                siwake.KasikataTekiyouCode = null;
            }
        }

        private void InitializeHonsitenTenkaiSiwake(HonsitenTenkaiContext context, HonsitenTenkaiSiwake honsitenSiwakeForInsert, Siwake siwake, bool isKarikata, bool isCheckedValue)
        {
            var karikataKamoku = context.MasterRepositoryCache?.FindKamokuByKesnAndKicd(siwake.Kesn, siwake.KarikataKamokuCode);
            var kasikataKamoku = context.MasterRepositoryCache?.FindKamokuByKesnAndKicd(siwake.Kesn, siwake.KasikataKamokuCode);

            //// 親仕訳チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && this.IsParentSiwake(siwake, isKarikata)
                    && !this.IsParentSiwake(siwake, !isKarikata)))
            {
                honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                honsitenSiwakeForInsert.Siwake.BunriKubun = BunriKubun.NotSet;
                honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber = siwake.SiwakeSequenceNumber;
                honsitenSiwakeForInsert.Siwake.ZeikomiKingaku = 0;
            }

            //// 子仕訳チェック
            if (isCheckedValue
                && this.IsChildSiwake(siwake, karikataKamoku) == isKarikata
                && this.IsChildSiwake(siwake, kasikataKamoku) != isKarikata)
            {
                honsitenSiwakeForInsert.Siwake.ParentChildFlag = SiwakeParentChildRelated.Nothing;
            }

            //// 対価項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && !this.CanOutputTaikaItem(siwake, isKarikata ? kasikataKamoku : karikataKamoku, !isKarikata)))
            {
                honsitenSiwakeForInsert.Siwake.IsInputTaika = false;
                honsitenSiwakeForInsert.Siwake.TaikaKingaku = 0;
            }

            //// 税対象項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && this.CanOutputSyouhizeiTaisyouItem(siwake.KarikataKazeiKubun, karikataKamoku.SyoriGroup) == isKarikata
                    && this.CanOutputSyouhizeiTaisyouItem(siwake.KasikataKazeiKubun, kasikataKamoku.SyoriGroup) != isKarikata))
            {
                honsitenSiwakeForInsert.Siwake.ZeitaisyouKamokuCode = null;
                honsitenSiwakeForInsert.Siwake.ZeitaisyouKamokuZeiritu = null;
                honsitenSiwakeForInsert.Siwake.ZeitaisyouKamokuKazeiKubun = KazeiKubun.消費税設定対象外;
                honsitenSiwakeForInsert.Siwake.ZeitaisyouKamokuGyousyuKubun = GyousyuKubun.None;
                honsitenSiwakeForInsert.Siwake.ZeitaisyouKamokuSiireKubun = SiwakeSiireKubun.Taisyougai;
            }

            //// 支払項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && this.CanOutputSiharaiNyuukinItem(siwake.KarikataKamokuCode, context.SiharaiNyuukinKamokuCodeCollection.KarikataSiharaiKamokuCodeSet) == isKarikata
                    && this.CanOutputSiharaiNyuukinItem(siwake.KasikataKamokuCode, context.SiharaiNyuukinKamokuCodeCollection.KasikataSiharaiKamokuCodeSet) != isKarikata))
            {
                honsitenSiwakeForInsert.Siwake.Siharaibi =
                honsitenSiwakeForInsert.Siwake.SiharaiKizitu = 0;
                honsitenSiwakeForInsert.Siwake.SiharaiKubun = null;
            }

            //// 入金項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && this.CanOutputSiharaiNyuukinItem(siwake.KarikataKamokuCode, context.SiharaiNyuukinKamokuCodeCollection.KarikataNyuukinKamokuCodeSet) == isKarikata
                    && this.CanOutputSiharaiNyuukinItem(siwake.KasikataKamokuCode, context.SiharaiNyuukinKamokuCodeCollection.KasikataNyuukinKamokuCodeSet) != isKarikata))
            {
                honsitenSiwakeForInsert.Siwake.Kaisyuubi =
                honsitenSiwakeForInsert.Siwake.KaisyuuKizitu = 0;
                honsitenSiwakeForInsert.Siwake.NyuukinKubun = null;
            }

            //// 外貨項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && string.IsNullOrEmpty(siwake.KarikataHeisyuCode) == isKarikata
                    && string.IsNullOrEmpty(siwake.KasikataHeisyuCode) != isKarikata))
            {
                honsitenSiwakeForInsert.Siwake.Rate =
                honsitenSiwakeForInsert.Siwake.GaikaKingaku =
                honsitenSiwakeForInsert.Siwake.GaikaTaikaKingaku =
                honsitenSiwakeForInsert.Siwake.GaikaZeikomiKingaku = 0;
            }

            //// 消込項目チェック
            if (!isCheckedValue
                || (isCheckedValue
                    && karikataKamoku.AllowUseKesikomiCode == isKarikata
                    && kasikataKamoku.AllowUseKesikomiCode != isKarikata))
            {
                honsitenSiwakeForInsert.Siwake.KesikomiCode =
                honsitenSiwakeForInsert.Siwake.KesikomiGroupCode = null;
                honsitenSiwakeForInsert.Siwake.IsKesikomiZero =
                honsitenSiwakeForInsert.Siwake.IsKesikomiUpdate =
                honsitenSiwakeForInsert.Siwake.IsKesikomiTyuusyutu = false;
            }
        }

        #endregion

        #region 値のチェック

        /// <summary>
        /// 本支店展開対象の伝票かどうかを返します
        /// </summary>
        /// <param name="honsitenSiwakeList">チェック対象の本支店仕訳リスト</param>
        /// <param name="honsitenTenkaiRelatedValue">本支店展開関連の値</param>
        /// <returns>本支店展開対象の伝票かどうか</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private bool IsHonsitenTenkaiTargetDenpyou(IList<HonsitenTenkaiSiwake> honsitenSiwakeList, HonsitenTenkaiContext honsitenTenkaiRelatedValue)
        {
            var isContainOnlyHonsitenTenkaiTargetSiwake = true;
            var karikataHonsitenKamokuDictionary = new Dictionary<string, decimal>();
            var kasikataHonsitenKamokuDictionary = new Dictionary<string, decimal>();
            var karikataHonsitenBumonSet = new HashSet<string>();
            var kasikataHonsitenBumonSet = new HashSet<string>();
            foreach (var honsitenSiwake in honsitenSiwakeList)
            {
                var karikataMeisai = honsitenTenkaiRelatedValue.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Bcod == honsitenSiwake.Siwake.KarikataBumonCode);
                var kasikataMeisai = honsitenTenkaiRelatedValue.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.Bcod == honsitenSiwake.Siwake.KasikataBumonCode);
                //// 本支店に紐付かない部門があればNG（諸口・資金繰諸口は除く）
                if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode)
                    && karikataMeisai == null)
                {
                    isContainOnlyHonsitenTenkaiTargetSiwake = false;
                }
                if (!string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode)
                    && kasikataMeisai == null)
                {
                    isContainOnlyHonsitenTenkaiTargetSiwake = false;
                }

                var karikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(honsitenSiwake.Siwake.KarikataKamokuCode);
                var kasikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(honsitenSiwake.Siwake.KasikataKamokuCode);
                switch (honsitenSiwake.Siwake.SiwakeTaisyakuZokusei)
                {
                    //// 貸借の場合、貸借両方に部門が必要（諸口・資金繰諸口は除く）
                    case SiwakeTaisyakuZokusei.Taisyaku:
                        this.AddHonsitenBumon(karikataHonsitenBumonSet, karikataMeisai?.Bcod);
                        this.AddHonsitenKamokuAndKingaku(karikataHonsitenKamokuDictionary, karikataMeisai?.Kicd, honsitenSiwake.Siwake.Kingaku);
                        this.AddHonsitenBumon(kasikataHonsitenBumonSet, kasikataMeisai?.Bcod);
                        this.AddHonsitenKamokuAndKingaku(kasikataHonsitenKamokuDictionary, kasikataMeisai?.Kicd, honsitenSiwake.Siwake.Kingaku);
                        if ((string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode) && !karikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                            || (string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode) && !kasikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku))
                        {
                            isContainOnlyHonsitenTenkaiTargetSiwake = false;
                        }
                        break;

                    //// 借方の場合、借方部門が必要（諸口・資金繰諸口は除く）
                    case SiwakeTaisyakuZokusei.Karikata:
                        this.AddHonsitenBumon(karikataHonsitenBumonSet, karikataMeisai?.Bcod);
                        this.AddHonsitenKamokuAndKingaku(karikataHonsitenKamokuDictionary, karikataMeisai?.Kicd, honsitenSiwake.Siwake.Kingaku);
                        if (string.IsNullOrEmpty(honsitenSiwake.Siwake.KarikataBumonCode) && !karikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                        {
                            isContainOnlyHonsitenTenkaiTargetSiwake = false;
                        }
                        break;

                    //// 貸方の場合、貸方部門が必要（諸口・資金繰諸口は除く）
                    case SiwakeTaisyakuZokusei.Kasikata:
                        this.AddHonsitenBumon(kasikataHonsitenBumonSet, kasikataMeisai?.Bcod);
                        this.AddHonsitenKamokuAndKingaku(kasikataHonsitenKamokuDictionary, kasikataMeisai?.Kicd, honsitenSiwake.Siwake.Kingaku);
                        if (string.IsNullOrEmpty(honsitenSiwake.Siwake.KasikataBumonCode) && !kasikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                        {
                            isContainOnlyHonsitenTenkaiTargetSiwake = false;
                        }
                        break;
                }
            }

            //// 貸借何れかの本支店科目が存在しない場合、本支店展開しない
            if (!karikataHonsitenKamokuDictionary.Any() || !kasikataHonsitenKamokuDictionary.Any())
            {
                if (!karikataHonsitenBumonSet.Any() && !kasikataHonsitenBumonSet.Any())
                {
                    isContainOnlyHonsitenTenkaiTargetSiwake = true;
                }
                honsitenSiwakeList.ForEachIfNotNull(siwake => siwake.IsHonsitenTenkaiEnabledSiwake = isContainOnlyHonsitenTenkaiTargetSiwake);
                return false;
            }

            //// 同一本支店間の取引の場合、本支店展開しない
            if (karikataHonsitenKamokuDictionary.Count == 1
                && kasikataHonsitenKamokuDictionary.Count == 1
                && karikataHonsitenKamokuDictionary.FirstOrDefault().Key == kasikataHonsitenKamokuDictionary.FirstOrDefault().Key)
            {
                return false;
            }

            if (!honsitenTenkaiRelatedValue.HonsitenTenkaiHeader.IsTenkaiTradingBetweenSameHonsiten)
            {
                //// 貸借の本支店科目の金額が一致しない場合、本支店展開しない
                if (this.IsSameTaisyakuHonsitenKamokuKingaku(karikataHonsitenKamokuDictionary, kasikataHonsitenKamokuDictionary))
                {
                    return false;
                }

                this.SetValueWhenNotTenkaiTradingBetweenSameHonsiten(
                    honsitenSiwakeList,
                    karikataHonsitenBumonSet,
                    karikataHonsitenKamokuDictionary,
                    kasikataHonsitenBumonSet,
                    kasikataHonsitenKamokuDictionary,
                    honsitenTenkaiRelatedValue);
            }

            honsitenSiwakeList.ForEachIfNotNull(siwake => siwake.IsHonsitenTenkaiEnabledSiwake = isContainOnlyHonsitenTenkaiTargetSiwake);

            return true;
        }

        /// <summary>
        /// 貸借本支店科目の金額が一致しているかどうかを返します
        /// </summary>
        /// <param name="karikataHonsitenKamokuDictionary">借方本支店科目ディクショナリ</param>
        /// <param name="kasikataHonsitenKamokuDictionary">貸方本支店科目ディクショナリ</param>
        /// <returns>貸借本支店科目の金額が一致しているかどうか</returns>
        private bool IsSameTaisyakuHonsitenKamokuKingaku(IDictionary<string, decimal> karikataHonsitenKamokuDictionary, IDictionary<string, decimal> kasikataHonsitenKamokuDictionary)
        {
            foreach (var keyValuePair in karikataHonsitenKamokuDictionary)
            {
                if (!kasikataHonsitenKamokuDictionary.ContainsKey(keyValuePair.Key)
                    || kasikataHonsitenKamokuDictionary[keyValuePair.Key] != keyValuePair.Value)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 親仕訳かどうかを返します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <returns>親仕訳かどうか</returns>
        private bool IsParentSiwake(Siwake siwake, bool isKarikata)
        {
            var kazeiKubun = isKarikata ? siwake.KarikataKazeiKubun : siwake.KasikataKazeiKubun;
            return siwake.ParentChildFlag == SiwakeParentChildRelated.Parent
                   && ((siwake.BunriKubun == BunriKubun.HurikaeSakusei
                       && (kazeiKubun == KazeiKubun.税込 || kazeiKubun == KazeiKubun.課込仕入 || kazeiKubun == KazeiKubun.課込売上 || kazeiKubun == KazeiKubun.貸倒損込 || kazeiKubun == KazeiKubun.貸倒回込))
                       || ((siwake.BunriKubun == BunriKubun.ZidouBunri || siwake.BunriKubun == BunriKubun.ZeiSakusei)
                           && (kazeiKubun == KazeiKubun.税抜 || kazeiKubun == KazeiKubun.課抜仕入 || kazeiKubun == KazeiKubun.課抜売上 || kazeiKubun == KazeiKubun.貸倒損抜 || kazeiKubun == KazeiKubun.貸倒回抜)));
        }

        /// <summary>
        /// 子仕訳かどうかを返します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="kamoku">科目</param>
        /// <returns>子仕訳かどうか</returns>
        private bool IsChildSiwake(Siwake siwake, Kamoku kamoku)
            => siwake.ParentChildFlag == SiwakeParentChildRelated.Child
               && (kamoku.SyoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || kamoku.SyoriGroup == KamokuSyoriGroup.KariukeSyouhizei);

        /// <summary>
        /// 対価項目を出力できるかどうかを返します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="kamoku">科目</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <returns>対価項目を出力できるかどうか</returns>
        private bool CanOutputTaikaItem(Siwake siwake, Kamoku kamoku, bool isKarikata)
        {
            var kazeiKubun = isKarikata ? siwake.KarikataKazeiKubun : siwake.KasikataKazeiKubun;
            return siwake.IsInputTaika
                    && kamoku.AllowUseTaika
                    && (kamoku.SyoriGroup == KamokuSyoriGroup.Sisan || kamoku.SyoriGroup == KamokuSyoriGroup.Yuukasyoken)
                    && ((!isKarikata && kazeiKubun == KazeiKubun.免税) || kazeiKubun == KazeiKubun.課込売上 || kazeiKubun == KazeiKubun.課抜売上 || kazeiKubun == KazeiKubun.非課税売上);
        }

        /// <summary>
        /// 税対象項目を出力できるかどうかを返します
        /// </summary>
        /// <param name="kazeiKubun">課税区分</param>
        /// <param name="syoriGroup">科目処理グループ</param>
        /// <returns>税対象項目を出力できるか</returns>
        private bool CanOutputSyouhizeiTaisyouItem(KazeiKubun kazeiKubun, KamokuSyoriGroup syoriGroup) =>
            (syoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || syoriGroup == KamokuSyoriGroup.KariukeSyouhizei)
            && kazeiKubun == KazeiKubun.消費税設定対象外;

        /// <summary>
        /// 支払・入金科目を出力できるかどうかを返します
        /// </summary>
        /// <param name="kamokuCode">チェック対象の科目コード</param>
        /// <param name="siharaiNyuukinKamokuCodeSet">支払・入金科目コードハッシュセット</param>
        /// <returns>支払・入金科目を出力できるかどうか</returns>
        private bool CanOutputSiharaiNyuukinItem(string kamokuCode, ISet<string> siharaiNyuukinKamokuCodeSet) =>
            siharaiNyuukinKamokuCodeSet.Any(siharaiNyuukinKamokuCode => siharaiNyuukinKamokuCode == kamokuCode);

        #endregion

        #region 値の設定

        /// <summary>
        /// 本支店仕訳における部門関連のフラグを設定します
        /// </summary>
        /// <param name="honsitenSiwakeForInsert">挿入用本支店仕訳データ</param>
        /// <param name="honsitenSiwake">設定元本支店仕訳データ</param>
        private void SetBumonRelatedFlagInHonsitenSiwake(HonsitenTenkaiSiwake honsitenSiwakeForInsert, HonsitenTenkaiSiwake honsitenSiwake)
        {
            //// 借方
            honsitenSiwakeForInsert.IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable = true;
            if (new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KarikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
            {
                honsitenSiwakeForInsert.IsInputedKarikataBumon =
                honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = true;
            }
            else
            {
                if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataBumonCode)
                    && honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                {
                    honsitenSiwakeForInsert.IsInputedKarikataBumon =
                    honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = false;
                }
                else
                {
                    honsitenSiwakeForInsert.IsInputedKarikataBumon = true;
                    honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable =
                        honsitenSiwake.IsKasikataParent && honsitenSiwake.Siwake.BunriKubun == BunriKubun.HurikaeSakusei
                            ? honsitenSiwake.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable
                            : honsitenSiwake.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable;
                }
            }

            //// 貸方
            honsitenSiwakeForInsert.IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable = true;
            if (new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KasikataKamokuCode).IsSyokutiOrSikinguriSyokutiKamoku)
            {
                honsitenSiwakeForInsert.IsInputedKasikataBumon =
                honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = true;
            }
            else
            {
                if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataBumonCode)
                    && honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                {
                    honsitenSiwakeForInsert.IsInputedKasikataBumon =
                    honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = false;
                }
                else
                {
                    honsitenSiwakeForInsert.IsInputedKasikataBumon = true;
                    honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable =
                        honsitenSiwake.IsKarikataParent && honsitenSiwake.Siwake.BunriKubun == BunriKubun.HurikaeSakusei
                            ? honsitenSiwake.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable
                            : honsitenSiwake.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable;
                }
            }
        }

        /// <summary>
        /// 貸借共通の値を設定します
        /// </summary>
        /// <param name="siwakeForInsert">挿入用仕訳データ</param>
        /// <param name="originalSiwake">設定元仕訳データ</param>
        private void SetTaisyakuCommonValue(Siwake siwakeForInsert, Siwake originalSiwake)
        {
            //// 親子関係
            siwakeForInsert.ParentChildFlag = originalSiwake.ParentChildFlag;
            siwakeForInsert.ParentChildSiwakeSequenceNumber = originalSiwake.ParentChildSiwakeSequenceNumber;
            siwakeForInsert.BunriKubun = originalSiwake.BunriKubun;
            siwakeForInsert.ZeikomiKingaku = originalSiwake.ZeikomiKingaku;

            //// 対価関係
            siwakeForInsert.IsInputTaika = originalSiwake.IsInputTaika;
            siwakeForInsert.TaikaKingaku = originalSiwake.TaikaKingaku;

            //// 税対象関係
            siwakeForInsert.ZeitaisyouKamokuCode = originalSiwake.ZeitaisyouKamokuCode;
            siwakeForInsert.ZeitaisyouKamokuZeiritu = originalSiwake.ZeitaisyouKamokuZeiritu;
            siwakeForInsert.ZeitaisyouKamokuKazeiKubun = originalSiwake.ZeitaisyouKamokuKazeiKubun;
            siwakeForInsert.ZeitaisyouKamokuGyousyuKubun = originalSiwake.ZeitaisyouKamokuGyousyuKubun;
            siwakeForInsert.ZeitaisyouKamokuSiireKubun = originalSiwake.ZeitaisyouKamokuSiireKubun;

            //// 支払関係
            siwakeForInsert.Siharaibi = originalSiwake.Siharaibi;
            siwakeForInsert.SiharaiKizitu = originalSiwake.SiharaiKizitu;
            siwakeForInsert.SiharaiKubun = originalSiwake.SiharaiKubun;

            //// 入金関係
            siwakeForInsert.Kaisyuubi = originalSiwake.Kaisyuubi;
            siwakeForInsert.KaisyuuKizitu = originalSiwake.KaisyuuKizitu;
            siwakeForInsert.NyuukinKubun = originalSiwake.NyuukinKubun;

            //// 外貨関係
            siwakeForInsert.Rate = originalSiwake.Rate;
            siwakeForInsert.GaikaKingaku = originalSiwake.GaikaKingaku;
            siwakeForInsert.GaikaTaikaKingaku = originalSiwake.GaikaTaikaKingaku;
            siwakeForInsert.GaikaZeikomiKingaku = originalSiwake.GaikaZeikomiKingaku;

            //// 消込関係
            siwakeForInsert.KesikomiCode = originalSiwake.KesikomiCode;
            siwakeForInsert.KesikomiGroupCode = originalSiwake.KesikomiGroupCode;
            siwakeForInsert.IsKesikomiZero = originalSiwake.IsKesikomiZero;
            siwakeForInsert.IsKesikomiUpdate = originalSiwake.IsKesikomiUpdate;
            siwakeForInsert.IsKesikomiTyuusyutu = originalSiwake.IsKesikomiTyuusyutu;
        }

        /// <summary>
        /// 仕訳の諸口関係の値を設定します
        /// </summary>
        /// <param name="honsitenSiwakeForInsert">挿入用本支店仕訳データ</param>
        /// <param name="isKarikata">借方かどうか</param>
        private void SetSiwakeSyokutiValue(HonsitenTenkaiSiwake honsitenSiwakeForInsert, bool isKarikata)
        {
            this.ClearSiwakeTaisyakubetuValue(honsitenSiwakeForInsert.Siwake, isKarikata);
            if (isKarikata)
            {
                //// 借方
                honsitenSiwakeForInsert.Siwake.KarikataKamokuCode = "000000000001001";
                honsitenSiwakeForInsert.Siwake.KarikataZeiritu = null;
                honsitenSiwakeForInsert.Siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
                honsitenSiwakeForInsert.Siwake.KarikataGyousyuKubun = GyousyuKubun.None;
                honsitenSiwakeForInsert.Siwake.KarikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                honsitenSiwakeForInsert.Siwake.KarikataHeisyuCode = null;
                honsitenSiwakeForInsert.IsInputedKarikataBumon =
                honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable =
                honsitenSiwakeForInsert.IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable = true;
            }
            else
            {
                //// 貸方
                honsitenSiwakeForInsert.Siwake.KasikataKamokuCode = "000000000001001";
                honsitenSiwakeForInsert.Siwake.KasikataZeiritu = null;
                honsitenSiwakeForInsert.Siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
                honsitenSiwakeForInsert.Siwake.KasikataGyousyuKubun = GyousyuKubun.None;
                honsitenSiwakeForInsert.Siwake.KasikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                honsitenSiwakeForInsert.Siwake.KasikataHeisyuCode = null;
                honsitenSiwakeForInsert.IsInputedKasikataBumon =
                honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable =
                honsitenSiwakeForInsert.IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable = true;
            }
        }

        /// <summary>
        /// 同一本支店間の取引を展開しない時の各値を設定します
        /// </summary>
        /// <param name="honsitenSiwakeList">本支店仕訳リスト</param>
        /// <param name="karikataHonsitenBumonSet">借方本支店部門ハッシュセット</param>
        /// <param name="karikataHonsitenKamokuDictionary">借方本支店科目ディクショナリ</param>
        /// <param name="kasikataHonsitenBumonSet">貸方本支店部門ハッシュセット</param>
        /// <param name="kasikataHonsitenKamokuDictionary">貸方本支店科目ディクショナリ</param>
        /// <param name="honsitenTenkaiRelatedValue">本支店展開関連の値</param>
        private void SetValueWhenNotTenkaiTradingBetweenSameHonsiten(IList<HonsitenTenkaiSiwake> honsitenSiwakeList, ISet<string> karikataHonsitenBumonSet, IDictionary<string, decimal> karikataHonsitenKamokuDictionary, ISet<string> kasikataHonsitenBumonSet, IDictionary<string, decimal> kasikataHonsitenKamokuDictionary, HonsitenTenkaiContext honsitenTenkaiRelatedValue)
        {
            var hontenMeisai = honsitenTenkaiRelatedValue.HonsitenTenkaiMeisaiList.FirstOrDefault(meisai => meisai.HonsitenKubun == HonsitenKubun.Honten);
            if (karikataHonsitenBumonSet.Count() == 1 || kasikataHonsitenBumonSet.Count == 1)
            {
                //// 1部門の場合
                if (honsitenSiwakeList.Min(honsitenSiwake => honsitenSiwake.Siwake.LineNo) == honsitenSiwakeList.Max(honsitenSiwake => honsitenSiwake.Siwake.LineNo))
                {
                    //// 1行仕訳の場合
                    honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = hontenMeisai.Kicd;
                    if (karikataHonsitenKamokuDictionary.FirstOrDefault().Key == hontenMeisai.Kicd)
                    {
                        honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = karikataHonsitenBumonSet.FirstOrDefault();
                    }
                    else if (kasikataHonsitenKamokuDictionary.FirstOrDefault().Key == hontenMeisai.Kicd)
                    {
                        honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = kasikataHonsitenBumonSet.FirstOrDefault();
                    }
                    else
                    {
                        honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = hontenMeisai.Bcod;
                    }
                }
                else
                {
                    if (karikataHonsitenKamokuDictionary.FirstOrDefault().Key == hontenMeisai.Kicd
                        && karikataHonsitenBumonSet.Count == 1)
                    {
                        honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = hontenMeisai.Kicd;
                        honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = karikataHonsitenBumonSet.FirstOrDefault();
                    }
                    else if (kasikataHonsitenKamokuDictionary.FirstOrDefault().Key == hontenMeisai.Kicd
                        && kasikataHonsitenBumonSet.Count == 1)
                    {
                        honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = hontenMeisai.Kicd;
                        honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = kasikataHonsitenBumonSet.FirstOrDefault();
                    }
                    else
                    {
                        if (karikataHonsitenBumonSet.Count == 1)
                        {
                            honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = karikataHonsitenKamokuDictionary.FirstOrDefault().Key;
                            honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = karikataHonsitenBumonSet.FirstOrDefault();
                        }
                        else if (kasikataHonsitenBumonSet.Count == 1)
                        {
                            honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = kasikataHonsitenKamokuDictionary.FirstOrDefault().Key;
                            honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = kasikataHonsitenBumonSet.FirstOrDefault();
                        }
                    }
                }
            }
            else
            {
                honsitenTenkaiRelatedValue.HonsitenKamokuCodeForTradingBetweenSameHonsiten = hontenMeisai.Kicd;
                honsitenTenkaiRelatedValue.HonsitenBumonCodeForTradingBetweenSameHonsiten = hontenMeisai.Bcod;
            }
        }

        #endregion

        /// <summary>
        /// グループ番号再付番後の仕訳リストを作成します
        /// </summary>
        /// <param name="siwakeListBeforeGroupNoRenumbered">グループ番号再付番前の仕訳リスト</param>
        /// <returns>作成したグループ番号再付番後の仕訳リスト</returns>
        private IList<Siwake> CreateSiwakeListAfterGroupNoRenumbered(IList<Siwake> siwakeListBeforeGroupNoRenumbered)
        {
            var renumberedSiwakeList = new List<Siwake>();
            var karikataTotalKingaku = 0m;
            var kasikataTotalKingaku = 0m;
            var groupNoForRenumbering = 0;
            foreach (var siwake in siwakeListBeforeGroupNoRenumbered)
            {
                var karikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(siwake.KarikataKamokuCode);
                var kasikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(siwake.KasikataKamokuCode);
                if (!karikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                {
                    //// 借方諸口金額は除く
                    karikataTotalKingaku += siwake.Kingaku;
                }

                if (!kasikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                {
                    //// 貸方諸口金額は除く
                    kasikataTotalKingaku += siwake.Kingaku;
                }

                siwake.GroupNumber += groupNoForRenumbering;
                renumberedSiwakeList.Add(siwake);
                if (karikataTotalKingaku == kasikataTotalKingaku)
                {
                    //// 貸借金額が一致すれば、次のグループ
                    groupNoForRenumbering++;
                    karikataTotalKingaku =
                    kasikataTotalKingaku = 0;
                }
            }

            return renumberedSiwakeList;
        }

        /// <summary>
        /// 本支店部門をハッシュセットに追加します
        /// </summary>
        /// <param name="honsitenBumonSet">追加先本支店部門ハッシュセット</param>
        /// <param name="bumonCode">追加対象の部門コード</param>
        private void AddHonsitenBumon(ISet<string> honsitenBumonSet, string bumonCode)
        {
            if (!string.IsNullOrEmpty(bumonCode))
            {
                honsitenBumonSet.Add(bumonCode);
            }
        }

        /// <summary>
        /// 本支店科目及び金額をディクショナリに追加します
        /// </summary>
        /// <param name="honsitenKamokuDictionary">追加先本支店科目ディクショナリ</param>
        /// <param name="kamokuCode">追加対象の科目コード</param>
        /// <param name="kingaku">追加対象の金額</param>
        private void AddHonsitenKamokuAndKingaku(IDictionary<string, decimal> honsitenKamokuDictionary, string kamokuCode, decimal kingaku)
        {
            if (string.IsNullOrEmpty(kamokuCode))
            {
                return;
            }

            if (!honsitenKamokuDictionary.ContainsKey(kamokuCode))
            {
                honsitenKamokuDictionary.Add(kamokuCode, kingaku);
                return;
            }

            honsitenKamokuDictionary[kamokuCode] += kingaku;
        }

        /// <summary>
        /// 挿入用本支店仕訳を作成します
        /// </summary>
        /// <param name="honsitenSiwake">元となる本支店仕訳</param>
        /// <param name="honsitenTenkaiMeisaiList">本支店明細リスト</param>
        /// <returns>作成した挿入用本支店仕訳</returns>
        private HonsitenTenkaiSiwake CreateHonsitenSiwakeForInsert(HonsitenTenkaiSiwake honsitenSiwake, IList<HonsitenTenkaiMeisai> honsitenTenkaiMeisaiList)
        {
            var honsitenSiwakeForInsert = honsitenSiwake.CloneAsDeepCopy();
            honsitenSiwakeForInsert.LineNoBeforeHonsitenTenkai = honsitenSiwakeForInsert.Siwake.LineNo;
            honsitenSiwakeForInsert.SseqBeforeHonsitenTenkai = honsitenSiwakeForInsert.Siwake.SiwakeSequenceNumber;
            honsitenSiwakeForInsert.ParentChildSiwakeSequenceNoBeforeHonsitenTenkai = honsitenSiwakeForInsert.Siwake.ParentChildSiwakeSequenceNumber;
            honsitenSiwakeForInsert.KarikataHonsitenKanzyouSetFlag =
            honsitenSiwakeForInsert.KasikataHonsitenKanzyouSetFlag = HonsitenKanzyouSetFlag.Nothing;
            honsitenSiwakeForInsert.IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable =
            honsitenSiwakeForInsert.IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable = true;
            if (honsitenSiwakeForInsert.IsHonsitenTenkaiEnabledSiwake)
            {
                //// 本支店展開可能な仕訳の場合、部門が入力・登録済とする
                honsitenSiwakeForInsert.IsInputedKarikataBumon =
                honsitenSiwakeForInsert.IsInputedKasikataBumon =
                honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable =
                honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = true;
            }
            else
            {
                //// 借方側のチェック
                var karikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KarikataKamokuCode);
                if (karikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                {
                    honsitenSiwakeForInsert.IsInputedKarikataBumon =
                    honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = true;
                }
                else
                {
                    if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KarikataBumonCode)
                        && honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                    {
                        honsitenSiwakeForInsert.IsInputedKarikataBumon =
                        honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = false;
                    }
                    else
                    {
                        honsitenSiwakeForInsert.IsInputedKarikataBumon = true;
                        honsitenSiwakeForInsert.IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable = honsitenTenkaiMeisaiList.Any(meisai => meisai.Bcod == honsitenSiwakeForInsert.Siwake.KarikataBumonCode);
                    }
                }

                //// 貸方側のチェック
                var kasikataKamokuInnerCodeFormat = new KamokuInnerCodeFormat(honsitenSiwakeForInsert.Siwake.KasikataKamokuCode);
                if (kasikataKamokuInnerCodeFormat.IsSyokutiOrSikinguriSyokutiKamoku)
                {
                    honsitenSiwakeForInsert.IsInputedKasikataBumon =
                    honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = true;
                }
                else
                {
                    if (string.IsNullOrEmpty(honsitenSiwakeForInsert.Siwake.KasikataBumonCode)
                        && honsitenSiwakeForInsert.Siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                    {
                        honsitenSiwakeForInsert.IsInputedKasikataBumon =
                        honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = false;
                    }
                    else
                    {
                        honsitenSiwakeForInsert.IsInputedKasikataBumon = true;
                        honsitenSiwakeForInsert.IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable = honsitenTenkaiMeisaiList.Any(meisai => meisai.Bcod == honsitenSiwakeForInsert.Siwake.KasikataBumonCode);
                    }
                }
            }

            return honsitenSiwakeForInsert;
        }

        #endregion

        /// <summary>
        /// 本支店展開関連の値
        /// </summary>
        internal class HonsitenTenkaiContext
        {
            public HonsitenTenkaiContext(HonsitenTenkaiHeader header, IList<HonsitenTenkaiMeisai> meisaiList, MasterRepositoryCache masterRepositoryCache, IHonsitenTenkaiSiwakeRepository repository, SiharaiNyuukinKamokuCodeCollection siharaiNyuukinKamokCodeCollection)
            {
                this.HonsitenTenkaiHeader = header;
                this.HonsitenTenkaiMeisaiList = meisaiList;
                this.MasterRepositoryCache = masterRepositoryCache;
                this.HonsitenTenkaiSiwakeRepository = repository;
                this.SiharaiNyuukinKamokuCodeCollection = siharaiNyuukinKamokCodeCollection;
            }

            /// <summary>
            /// 現在のプライマリキー
            /// </summary>
            public int CurrentPrimaryKey { get; set; } = 1;

            /// <summary>
            /// 現在のプライマリキー（消費税仕訳用）
            /// </summary>
            public int CurrentPrimaryKeyForSyouhizeiSiwake { get; set; } = 1;

            /// <summary>
            /// 行番号（本支店展開時調整用）
            /// </summary>
            public int LineNoForAdjustment { get; set; }

            /// <summary>
            /// グループ番号（本支店展開時調整用）
            /// </summary>
            public int GroupNoForAdjustment { get; set; }

            /// <summary>
            /// 挿入済みの行番号の最大値
            /// </summary>
            public int InsertedMaxLineNo { get; set; }

            /// <summary>
            /// 本支店部門コード（同一支店間取引用）
            /// </summary>
            public string HonsitenBumonCodeForTradingBetweenSameHonsiten { get; set; }

            /// <summary>
            /// 本支店科目コード（同一支店間取引用）
            /// </summary>
            public string HonsitenKamokuCodeForTradingBetweenSameHonsiten { get; set; }

            /// <summary>
            /// 本支店展開ヘッダ
            /// </summary>
            public HonsitenTenkaiHeader HonsitenTenkaiHeader { get; private set; }

            /// <summary>
            /// 本支店展開明細リスト
            /// </summary>
            public IList<HonsitenTenkaiMeisai> HonsitenTenkaiMeisaiList { get; private set; } = new List<HonsitenTenkaiMeisai>();

            public MasterRepositoryCache MasterRepositoryCache { get; private set; }

            public IHonsitenTenkaiSiwakeRepository HonsitenTenkaiSiwakeRepository { get; private set; }

            public SiharaiNyuukinKamokuCodeCollection SiharaiNyuukinKamokuCodeCollection { get; private set; }
        }
    }
}
