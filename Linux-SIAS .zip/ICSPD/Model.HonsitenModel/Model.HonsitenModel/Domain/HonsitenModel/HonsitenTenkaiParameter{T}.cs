﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.DenpyouModel;

    public class HonsitenTenkaiParameter<T>
        where T : IDenpyouKey
    {
        public HonsitenTenkaiParameter(int kesn, IEnumerable<T> honsitenTenkaiTargetDenpyouPrimaryKeyEnumerable)
        {
            this.Kesn = kesn;
            this.HonsitenTenkaiTargetDenpyouPrimaryKeyEnumerable = honsitenTenkaiTargetDenpyouPrimaryKeyEnumerable;
        }

        public int Kesn { get; private set; }

        public IEnumerable<T> HonsitenTenkaiTargetDenpyouPrimaryKeyEnumerable { get; private set; }

        public bool DeleteHonsitenTenkaiErrorDenpyou { get; set; }
    }
}
