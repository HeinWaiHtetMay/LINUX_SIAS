﻿using System.Collections.Generic;
using Icsp.Open21.Domain.HonsitenModel;

namespace Icsp.Open21.Domain.HonsitenModel
{
    public interface IHonsitenTenkaiHeaderRepository
    {
        /// <summary>
        /// 本支店展開ヘッダリストを取得します
        /// </summary>
        /// <returns>本支店展開ヘッダリスト</returns>
        IList<HonsitenTenkaiHeader> FindAll();

        /// <summary>
        /// 指定条件の本支店展開ヘッダを取得します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <returns>指定条件の本支店展開ヘッダ</returns>
        HonsitenTenkaiHeader FindByKesn(int kesn);
    }
}