﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Data.Dao;

    public class HonsitenTenkaiServiceResult : IDisposable
    {
        internal HonsitenTenkaiServiceResult(TemporaryTable honsitenTenkaiSiwakeTemporaryTable)
        {
            this.HonsitenTenkaiSiwakeTemporaryTable = honsitenTenkaiSiwakeTemporaryTable;
        }

        internal HonsitenTenkaiServiceResult()
        {
        }

        /// <summary>
        /// 本支店展開仕訳のテンポラリテーブルは作成されたかどうかを取得します
        /// </summary>
        public bool HonsitenTenkaiSiwakeTemporaryTableCreated => this.HonsitenTenkaiSiwakeTemporaryTable != null;

        public TemporaryTable HonsitenTenkaiSiwakeTemporaryTable { get; private set; }

        public string HonsitenTenkaiSiwakeTemporaryTableName => this.HonsitenTenkaiSiwakeTemporaryTable?.TableName ?? string.Empty;

        public void Dispose()
        {
            this.HonsitenTenkaiSiwakeTemporaryTable?.Dispose();
        }
    }
}
