﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.HonsitenModel
{
    /// <summary>
    /// 本支店展開明細（テーブル名：hstbl_m）
    /// </summary>
    public class HonsitenTenkaiMeisai
    {
        public HonsitenTenkaiMeisai(int kesn, string bcod)
        {
            this.Kesn = kesn;
            this.Bcod = bcod;
        }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 部門コード（カラム名：bcod）
        /// </summary>
        public string Bcod { get; private set; }

        /// <summary>
        /// 科目コード（カラム名：kicd）
        /// </summary>
        public string Kicd { get; set; }

        /// <summary>
        /// 本支店区分（カラム名：hkbn）
        /// </summary>
        public HonsitenKubun HonsitenKubun { get; set; }
    }
}
