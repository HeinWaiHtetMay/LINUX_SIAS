﻿using Icsp.Framework.Data.Dao;

namespace Icsp.Open21.Domain.HonsitenModel
{
    internal interface IHonsitenTenkaiRepositoryFactory
    {
        IHonsitenTenkaiSiwakeRepository CreateHonsitenTenkaiSiwakeRepository(HonsitenSiwakeCreateOrder honsitenSiwakeCreateOrder);
    }
}