﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using System.Collections.Generic;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.MasterModel;

    internal interface IHonsitenTenkaiSiwakeRepository
    {
        TemporaryTable HonsitenTenkaiSiwakeTemporaryTable { get; }

        TemporaryTable SiwakeBeforeCreateSyouhizeiSiwakeTemporaryTable { get; }

        void DeleteBelongingToDenpyouContainsHonsitenTenkaiImpossibleSiwake();

        IList<HonsitenTenkaiSiwake> FindValidSiwakeListOrderBySortKeys(MasterRepositoryCache masterRepositoryCache);

        void Insert(HonsitenTenkaiSiwake honsitenSiwake);

        /// <summary>
        /// 消費税仕訳作成前の仕訳をInsertします
        /// </summary>
        /// <param name="siwakeBeforeCreateSyouhizeiSiwake"></param>
        void InsertSiwakeBeforeCreateSyouhizeiSiwake(Siwake siwakeBeforeCreateSyouhizeiSiwake);

        void UpdateIsRegisteredAsBumonKamoku();

        void UpdateParentChildRelationship();

        void UpdateSortKeys();
    }
}