﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    /// <summary>
    /// 本支店処理タイプ
    /// </summary>
    public enum HonsitenProcessingType
    {
        /// <summary>
        /// 拡張入出力処理：財務転記
        /// </summary>
        KakutyouIOProcessing = 0,

        /// <summary>
        /// 月次一括処理
        /// </summary>
        MonthlyBatchProcessing = 1
    }

    /// <summary>
    /// 本支店未登録部門があるときの処理設定
    /// </summary>
    public enum ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists
    {
        /// <summary>
        /// 財務転記を行わない
        /// </summary>
        DoNotZaimuTenki = 0,

        /// <summary>
        /// 登録されていない部門を含む伝票を除いて転記を行う
        /// </summary>
        DoZaimuTenkiExpectDenpyouIncludingUnregisteredBumon = 1
    }

    /// <summary>
    /// 本支店展開方法
    /// </summary>
    public enum HonsitenTenkaiMethod
    {
        /// <summary>
        /// 仕訳毎に展開
        /// </summary>
        TenkaiPerSiwake = 0,

        /// <summary>
        /// 仕訳行毎に展開
        /// </summary>
        TenkaiPerSiwakeRow = 1
    }

    /// <summary>
    /// 本支店仕訳の作成順
    /// </summary>
    public enum HonsitenSiwakeCreateOrder
    {
        /// <summary>
        /// 消費税自動生成子仕訳作成後の状態から本支店仕訳を作成する
        /// </summary>
        AfterCreateSyouhizeiZidouSeiseiChildSiwake = 0,

        /// <summary>
        /// 消費税自動生成子仕訳作成前の状態から本支店仕訳を作成する
        /// </summary>
        BeforeCreateSyouhizeiZidouSeiseiChildSiwake = 1
    }
}
