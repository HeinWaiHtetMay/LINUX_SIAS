﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.HonsitenModel
{
    /// <summary>
    /// 本支店勘定設定フラグ
    /// </summary>
    public enum HonsitenKanzyouSetFlag
    {
        /// <summary>
        /// 未設定
        /// </summary>
        Nothing = 0,

        /// <summary>
        /// 本店勘定
        /// </summary>
        HontenKanzyou = 1,

        /// <summary>
        /// 支店勘定
        /// </summary>
        SitenKanzyou = 2
    }
}
