﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    /// <summary>
    /// 本支店区分
    /// </summary>
    public enum HonsitenKubun
    {
        /// <summary>
        /// 支店
        /// </summary>
        Siten = 0,

        /// <summary>
        /// 本店
        /// </summary>
        Honten = 1
    }
}
