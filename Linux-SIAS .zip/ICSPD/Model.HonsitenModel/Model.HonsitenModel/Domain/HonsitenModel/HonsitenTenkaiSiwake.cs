﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 本支店仕訳
    /// </summary>
    internal class HonsitenTenkaiSiwake
    {
        public HonsitenTenkaiSiwake(Siwake siwake, MasterRepositoryCache masterRepositoryCache)
        {
            this.Siwake = siwake;

            this.IsKarikataParent =
                siwake?.ParentChildFlag == SiwakeParentChildRelated.Parent
                && ((siwake?.BunriKubun == BunriKubun.HurikaeSakusei
                     && (siwake?.KarikataKazeiKubun == KazeiKubun.税込 || siwake?.KarikataKazeiKubun == KazeiKubun.課込仕入 || siwake?.KarikataKazeiKubun == KazeiKubun.課込売上 || siwake?.KarikataKazeiKubun == KazeiKubun.貸倒損込 || siwake?.KarikataKazeiKubun == KazeiKubun.貸倒回込))
                    || ((siwake?.BunriKubun == BunriKubun.ZidouBunri || siwake?.BunriKubun == BunriKubun.ZeiSakusei)
                         && (siwake?.KarikataKazeiKubun == KazeiKubun.税抜 || siwake?.KarikataKazeiKubun == KazeiKubun.課抜仕入 || siwake?.KarikataKazeiKubun == KazeiKubun.課抜売上 || siwake?.KarikataKazeiKubun == KazeiKubun.貸倒損抜 || siwake?.KarikataKazeiKubun == KazeiKubun.貸倒回抜)));
            this.IsKasikataParent =
                siwake?.ParentChildFlag == SiwakeParentChildRelated.Parent
                && ((siwake?.BunriKubun == BunriKubun.HurikaeSakusei
                     && (siwake?.KasikataKazeiKubun == KazeiKubun.税込 || siwake?.KasikataKazeiKubun == KazeiKubun.課込仕入 || siwake?.KasikataKazeiKubun == KazeiKubun.課込売上 || siwake?.KasikataKazeiKubun == KazeiKubun.貸倒損込 || siwake?.KasikataKazeiKubun == KazeiKubun.貸倒回込))
                    || ((siwake?.BunriKubun == BunriKubun.ZidouBunri || siwake?.BunriKubun == BunriKubun.ZeiSakusei)
                         && (siwake?.KasikataKazeiKubun == KazeiKubun.税抜 || siwake?.KasikataKazeiKubun == KazeiKubun.課抜仕入 || siwake?.KasikataKazeiKubun == KazeiKubun.課抜売上 || siwake?.KasikataKazeiKubun == KazeiKubun.貸倒損抜 || siwake?.KasikataKazeiKubun == KazeiKubun.貸倒回抜)));

            var karikataKamoku = masterRepositoryCache?.FindKamokuByKesnAndKicd(siwake?.Kesn ?? 0, siwake?.KarikataKamokuCode);
            this.IsKarikataChild =
                siwake?.ParentChildFlag == SiwakeParentChildRelated.Child
                && (karikataKamoku.SyoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || karikataKamoku.SyoriGroup == KamokuSyoriGroup.KariukeSyouhizei);
            var kasikataKamoku = masterRepositoryCache?.FindKamokuByKesnAndKicd(siwake?.Kesn ?? 0, siwake?.KasikataKamokuCode);
            this.IsKasikataChild =
                siwake?.ParentChildFlag == SiwakeParentChildRelated.Child
                && (kasikataKamoku.SyoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || kasikataKamoku.SyoriGroup == KamokuSyoriGroup.KariukeSyouhizei);
        }

        #region プロパティ

        /// <summary>
        /// 仕訳
        /// </summary>
        public Siwake Siwake { get; private set; }

        /// <summary>
        /// プライマリキー（カラム名：pkey）
        /// </summary>
        public int PrimaryKey { get; set; }

        /// <summary>
        /// 本支店展開前の行番号（カラム名：odlin）
        /// </summary>
        public int LineNoBeforeHonsitenTenkai { get; set; }

        /// <summary>
        /// 本支店展開前の仕訳SEQ（カラム名：osseq）
        /// </summary>
        public int SseqBeforeHonsitenTenkai { get; set; }

        /// <summary>
        /// 本支店展開前の親仕訳SEQ（カラム名：opseq）
        /// </summary>
        public int ParentChildSiwakeSequenceNoBeforeHonsitenTenkai { get; set; }

        /// <summary>
        /// 借方本支店勘定設定フラグ（カラム名：rsflg）
        /// </summary>
        public HonsitenKanzyouSetFlag KarikataHonsitenKanzyouSetFlag { get; set; }

        /// <summary>
        /// 貸方本支店勘定設定フラグ（カラム名：s_honten_or_siten）
        /// </summary>
        public HonsitenKanzyouSetFlag KasikataHonsitenKanzyouSetFlag { get; set; }

        /// <summary>
        /// 本支店展開可能な仕訳かどうか（カラム名：jflg）
        /// </summary>
        public bool IsHonsitenTenkaiEnabledSiwake { get; set; }

        /// <summary>
        /// 借方部門が入力されているかどうか（カラム名：rbreg）
        /// </summary>
        public bool IsInputedKarikataBumon { get; set; }

        /// <summary>
        /// 本支店展開明細テーブル（hstbl_m）に、借方部門が登録されているかどうか（カラム名：rbinp）
        /// </summary>
        public bool IsRegisteredKarikataBumonToHonsitenTenkaiMeisaiTable { get; set; }

        /// <summary>
        /// 部門科目残高テーブル（bkzan）に、借方部門科目が登録されているかどうか（カラム名：rbkinp）
        /// </summary>
        public bool IsRegisteredKarikataBumonKamokuToBumonKamokuZandakaTable { get; set; }

        /// <summary>
        /// 貸方部門が入力されているかどうか（カラム名：sbreg）
        /// </summary>
        public bool IsInputedKasikataBumon { get; set; }

        /// <summary>
        /// 本支店展開明細テーブル（hstbl_m）に、貸方部門が登録されているかどうか（カラム名：sbinp）
        /// </summary>
        public bool IsRegisteredKasikataBumonToHonsitenTenkaiMeisaiTable { get; set; }

        /// <summary>
        /// 部門科目残高テーブル（bkzan）に、貸方部門科目が登録されているかどうか（カラム名：sbkinp）
        /// </summary>
        public bool IsRegisteredKasikataBumonKamokuToBumonKamokuZandakaTable { get; set; }

        /// <summary>
        /// 借方が親かどうか（カラム名：rp1flg）
        /// </summary>
        public bool IsKarikataParent { get; set; }

        /// <summary>
        /// 貸方が親かどうか（カラム名：sp1flg）
        /// </summary>
        public bool IsKasikataParent { get; set; }

        /// <summary>
        /// 借方が子かどうか（カラム名：rp2flg）
        /// </summary>
        public bool IsKarikataChild { get; set; }

        /// <summary>
        /// 貸方が子かどうか（カラム名：sp2flg）
        /// </summary>
        public bool IsKasikataChild { get; set; }

        /// <summary>
        /// 複合フラグ
        /// </summary>
        public DenpyouKeisiki DenpyouKeisiki { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// 仕訳を設定します
        /// </summary>
        /// <param name="siwake">設定元の仕訳</param>
        /// <param name="isSetKarikataValue">借方側の値を設定するかどうか</param>
        /// <param name="isSetKasikataValue">貸方側の値を設定するかどうか</param>
        public void SetSiwake(Siwake siwake, bool isSetKarikataValue, bool isSetKasikataValue)
        {
            if (isSetKarikataValue && isSetKasikataValue)
            {
                this.Siwake = siwake;
                return;
            }

            if (isSetKarikataValue)
            {
                this.Siwake.KarikataBumonCode = siwake.KarikataBumonCode;
                this.Siwake.KarikataTorihikisakiCode = siwake.KarikataTorihikisakiCode;
                this.Siwake.KarikataKamokuCode = siwake.KarikataKamokuCode;
                this.Siwake.KarikataEdabanCode = siwake.KarikataEdabanCode;
                this.Siwake.KarikataKouziCode = siwake.KarikataKouziCode;
                this.Siwake.KarikataKousyuCode = siwake.KarikataKousyuCode;
                this.Siwake.KarikataProjectCode = siwake.KarikataProjectCode;
                this.Siwake.KarikataSegmentCode = siwake.KarikataSegmentCode;
                this.Siwake.KarikataTekiyou = siwake.KarikataTekiyou;
                this.Siwake.KarikataTekiyouCode = siwake.KarikataTekiyouCode;
                this.Siwake.KarikataImageNumber = siwake.KarikataImageNumber;
                this.Siwake.KarikataZeiritu = siwake.KarikataZeiritu;
                this.Siwake.KarikataKazeiKubun = siwake.KarikataKazeiKubun;
                this.Siwake.KarikataGyousyuKubun = siwake.KarikataGyousyuKubun;
                this.Siwake.KarikataSiireKubun = siwake.KarikataSiireKubun;
                this.Siwake.KarikataHeisyuCode = siwake.KarikataHeisyuCode;
                this.Siwake.KarikataUniversalField1Code = siwake.KarikataUniversalField1Code;
                this.Siwake.KarikataUniversalField2Code = siwake.KarikataUniversalField2Code;
                this.Siwake.KarikataUniversalField3Code = siwake.KarikataUniversalField3Code;
                this.Siwake.KarikataUniversalField4Code = siwake.KarikataUniversalField4Code;
                this.Siwake.KarikataUniversalField5Code = siwake.KarikataUniversalField5Code;
                this.Siwake.KarikataUniversalField6Code = siwake.KarikataUniversalField6Code;
                this.Siwake.KarikataUniversalField7Code = siwake.KarikataUniversalField7Code;
                this.Siwake.KarikataUniversalField8Code = siwake.KarikataUniversalField8Code;
                this.Siwake.KarikataUniversalField9Code = siwake.KarikataUniversalField9Code;
                this.Siwake.KarikataUniversalField10Code = siwake.KarikataUniversalField10Code;
                this.Siwake.KarikataUniversalField11Code = siwake.KarikataUniversalField11Code;
                this.Siwake.KarikataUniversalField12Code = siwake.KarikataUniversalField12Code;
                this.Siwake.KarikataUniversalField13Code = siwake.KarikataUniversalField13Code;
                this.Siwake.KarikataUniversalField14Code = siwake.KarikataUniversalField14Code;
                this.Siwake.KarikataUniversalField15Code = siwake.KarikataUniversalField15Code;
                this.Siwake.KarikataUniversalField16Code = siwake.KarikataUniversalField16Code;
                this.Siwake.KarikataUniversalField17Code = siwake.KarikataUniversalField17Code;
                this.Siwake.KarikataUniversalField18Code = siwake.KarikataUniversalField18Code;
                this.Siwake.KarikataUniversalField19Code = siwake.KarikataUniversalField19Code;
                this.Siwake.KarikataUniversalField20Code = siwake.KarikataUniversalField20Code;
                if (!string.IsNullOrEmpty(this.Siwake.KarikataHeisyuCode))
                {
                    this.Siwake.Rate = siwake.Rate;
                    this.Siwake.GaikaKingaku = siwake.GaikaKingaku;
                    this.Siwake.GaikaTaikaKingaku = siwake.GaikaTaikaKingaku;
                    this.Siwake.GaikaZeikomiKingaku = siwake.GaikaZeikomiKingaku;
                }
            }
            else if (isSetKasikataValue)
            {
                this.Siwake.KasikataBumonCode = siwake.KasikataBumonCode;
                this.Siwake.KasikataTorihikisakiCode = siwake.KasikataTorihikisakiCode;
                this.Siwake.KasikataKamokuCode = siwake.KasikataKamokuCode;
                this.Siwake.KasikataEdabanCode = siwake.KasikataEdabanCode;
                this.Siwake.KasikataKouziCode = siwake.KasikataKouziCode;
                this.Siwake.KasikataKousyuCode = siwake.KasikataKousyuCode;
                this.Siwake.KasikataProjectCode = siwake.KasikataProjectCode;
                this.Siwake.KasikataSegmentCode = siwake.KasikataSegmentCode;
                this.Siwake.KasikataTekiyou = siwake.KasikataTekiyou;
                this.Siwake.KasikataTekiyouCode = siwake.KasikataTekiyouCode;
                this.Siwake.KasikataImageNumber = siwake.KasikataImageNumber;
                this.Siwake.KasikataZeiritu = siwake.KasikataZeiritu;
                this.Siwake.KasikataKazeiKubun = siwake.KasikataKazeiKubun;
                this.Siwake.KasikataGyousyuKubun = siwake.KasikataGyousyuKubun;
                this.Siwake.KasikataSiireKubun = siwake.KasikataSiireKubun;
                this.Siwake.KasikataHeisyuCode = siwake.KasikataHeisyuCode;
                this.Siwake.KasikataUniversalField1Code = siwake.KasikataUniversalField1Code;
                this.Siwake.KasikataUniversalField2Code = siwake.KasikataUniversalField2Code;
                this.Siwake.KasikataUniversalField3Code = siwake.KasikataUniversalField3Code;
                this.Siwake.KasikataUniversalField4Code = siwake.KasikataUniversalField4Code;
                this.Siwake.KasikataUniversalField5Code = siwake.KasikataUniversalField5Code;
                this.Siwake.KasikataUniversalField6Code = siwake.KasikataUniversalField6Code;
                this.Siwake.KasikataUniversalField7Code = siwake.KasikataUniversalField7Code;
                this.Siwake.KasikataUniversalField8Code = siwake.KasikataUniversalField8Code;
                this.Siwake.KasikataUniversalField9Code = siwake.KasikataUniversalField9Code;
                this.Siwake.KasikataUniversalField10Code = siwake.KasikataUniversalField10Code;
                this.Siwake.KasikataUniversalField11Code = siwake.KasikataUniversalField11Code;
                this.Siwake.KasikataUniversalField12Code = siwake.KasikataUniversalField12Code;
                this.Siwake.KasikataUniversalField13Code = siwake.KasikataUniversalField13Code;
                this.Siwake.KasikataUniversalField14Code = siwake.KasikataUniversalField14Code;
                this.Siwake.KasikataUniversalField15Code = siwake.KasikataUniversalField15Code;
                this.Siwake.KasikataUniversalField16Code = siwake.KasikataUniversalField16Code;
                this.Siwake.KasikataUniversalField17Code = siwake.KasikataUniversalField17Code;
                this.Siwake.KasikataUniversalField18Code = siwake.KasikataUniversalField18Code;
                this.Siwake.KasikataUniversalField19Code = siwake.KasikataUniversalField19Code;
                this.Siwake.KasikataUniversalField20Code = siwake.KasikataUniversalField20Code;
                if (!string.IsNullOrEmpty(this.Siwake.KasikataHeisyuCode))
                {
                    this.Siwake.Rate = siwake.Rate;
                    this.Siwake.GaikaKingaku = siwake.GaikaKingaku;
                    this.Siwake.GaikaTaikaKingaku = siwake.GaikaTaikaKingaku;
                    this.Siwake.GaikaZeikomiKingaku = siwake.GaikaZeikomiKingaku;
                }
            }
        }

        /// <summary>
        /// 本支店仕訳を複製します
        /// </summary>
        /// <returns>複製された本支店仕訳</returns>
        public HonsitenTenkaiSiwake CloneAsDeepCopy()
        {
            var honsitenSiwake = this.MemberwiseClone() as HonsitenTenkaiSiwake;
            honsitenSiwake.Siwake = honsitenSiwake.Siwake.CloneAsDeepCopy();
            return honsitenSiwake;
        }

        #endregion
    }
}
