﻿namespace Icsp.Open21.Domain.HonsitenModel
{
    /// <summary>
    /// 本支店展開ヘッダ(テーブル名：hstbl_h)
    /// </summary>
    public class HonsitenTenkaiHeader
    {
        public HonsitenTenkaiHeader(int kesn)
        {
            this.Kesn = kesn;
        }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 本支店自動仕訳処理を使用するかどうか（カラム名：hsflg）
        /// </summary>
        public bool IsUseHonsitenZidouSiwakeProcessing { get; set; }

        /// <summary>
        /// 本支店処理タイプ（カラム名：hstype）
        /// </summary>
        public HonsitenProcessingType HonsitenProcessingType { get; set; }

        /// <summary>
        /// 本支店未登録部門があるときの処理設定（カラム名：method1）
        /// </summary>
        public ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists ProcessingSettingTypeWhenHonsitenUnregisteredBumonExists { get; set; }

        /// <summary>
        /// 本支店展開方法（カラム名：method2）
        /// </summary>
        public HonsitenTenkaiMethod HonsitenTenkaiMethod { get; set; }

        /// <summary>
        /// 同一本支店間取引を展開するかどうか（カラム名：method3）
        /// </summary>
        public bool IsTenkaiTradingBetweenSameHonsiten { get; set; } = true;

        /// <summary>
        /// 本支店展開前行順に並べ替えするかどうか（カラム名：method4）
        /// </summary>
        public bool IsSortBySiwakeLineNoBeforeHonsitenTenkai { get; set; }

        /// <summary>
        /// 本支店仕訳の作成順（カラム名：method5）
        /// </summary>
        public HonsitenSiwakeCreateOrder HonsitenSiwakeCreateOrder { get; set; }
    }
}
