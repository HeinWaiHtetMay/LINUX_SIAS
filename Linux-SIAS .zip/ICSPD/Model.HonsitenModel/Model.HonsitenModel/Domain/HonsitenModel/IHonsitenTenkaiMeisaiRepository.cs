﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.HonsitenModel
{
    public interface IHonsitenTenkaiMeisaiRepository
    {
        /// <summary>
        /// 指定条件の本支店展開明細リストを取得します。
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <returns>本支店展開明細リスト</returns>
        IList<HonsitenTenkaiMeisai> FindByKesnAndHonsitenKubun(int kesn);
    }
}