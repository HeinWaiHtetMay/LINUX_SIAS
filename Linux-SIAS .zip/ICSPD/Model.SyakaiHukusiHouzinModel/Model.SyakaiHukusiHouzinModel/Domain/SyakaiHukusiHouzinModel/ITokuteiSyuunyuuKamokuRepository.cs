﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.SyakaiHukusiHouzinModel
{
    public interface ITokuteiSyuunyuuKamokuRepository
    {
        IList<TokuteiSyuunyuuKamoku> FindByKesn(int kesn);

        bool GetExistsByKesnAndKicd(int kesn, string kicd);
    }
}