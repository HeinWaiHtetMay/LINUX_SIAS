﻿namespace Icsp.Open21.Domain.SyakaiHukusiHouzinModel
{
    public static class TokuteiSyuunyuuKubunExtension
    {
        /// <summary>
        /// 特定収入区分の略称を取得します。
        /// </summary>
        /// <param name="value">特定収入区分の値</param>
        /// <returns>特定収入区分の略称</returns>
        public static string GetShortName(this TokuteiSyuunyuuKubun value)
        {
            switch (value)
            {
                case TokuteiSyuunyuuKubun.TaisyougaiTokuteiSyuunyuu:
                    return "外特定収";

                case TokuteiSyuunyuuKubun.TokuteiSyuunyuu:
                    return "特定収入";

                case TokuteiSyuunyuuKubun.HutokuteiSyuunyuu:
                    return "不特定収";

                default:
                    return string.Empty;
            }
        }
    }
}
