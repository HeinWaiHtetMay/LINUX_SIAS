﻿namespace Icsp.Open21.Domain.SyakaiHukusiHouzinModel
{
    public enum TokuteiSyuunyuuKubun
    {
        /// <summary>
        /// 外特定収入
        /// </summary>
        TaisyougaiTokuteiSyuunyuu = 0,

        /// <summary>
        /// 特定収入
        /// </summary>
        TokuteiSyuunyuu = 1,

        /// <summary>
        /// HutokuteiSyuunyuu
        /// </summary>
        HutokuteiSyuunyuu = 2,
    }
}
