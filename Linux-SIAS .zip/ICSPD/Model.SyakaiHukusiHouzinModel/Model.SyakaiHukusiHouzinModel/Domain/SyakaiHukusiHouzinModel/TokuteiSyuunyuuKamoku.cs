﻿namespace Icsp.Open21.Domain.SyakaiHukusiHouzinModel
{
    public class TokuteiSyuunyuuKamoku
    {
        public TokuteiSyuunyuuKamoku(int kesn, string kicd)
        {
            this.Kesn = kesn;
            this.Kicd = kicd;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 科目内部コード（カラム名：kicd）
        /// </summary>
        public string Kicd { get; private set; }

        /// <summary>
        /// 特定収入区分（カラム名：tkbn）
        /// </summary>
        public TokuteiSyuunyuuKubun TokuteiSyuunyuuKubun { get; set; }

        #endregion
    }
}
