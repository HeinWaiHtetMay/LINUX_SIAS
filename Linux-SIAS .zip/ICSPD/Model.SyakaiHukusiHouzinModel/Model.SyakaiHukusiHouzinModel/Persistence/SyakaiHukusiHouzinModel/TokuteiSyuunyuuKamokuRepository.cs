﻿namespace Icsp.Open21.Persistence.SyakaiHukusiHouzinModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TokuteiSyuunyuuKamokuRepository : ITokuteiSyuunyuuKamokuRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual bool GetExistsByKesnAndKicd(int kesn, string kicd)
        {
            SqlStatementBuilder sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.Append("SELECT COUNT(kicd) FROM tskname WHERE kesn = :p AND kicd = :p ");

            return this.dbc.QueryForObject(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    return Convert.ToInt32(values[0]) > 0;
                },
                kesn,
                kicd);
        }

        public virtual IList<TokuteiSyuunyuuKamoku> FindByKesn(int kesn)
        {
            return this.dbc.QueryForList(
                "SELECT kesn, kicd, tkbn, idm1, idm2, cdm1, cdm2 " +
                "FROM tskname WHERE kesn = :p ",
                (values, no) =>
                {
                    var kicd = values[1].ToString();
                    var row = new TokuteiSyuunyuuKamoku(kesn, kicd);
                    row.TokuteiSyuunyuuKubun = (TokuteiSyuunyuuKubun)(short)values[2]; // 特定収入区分
                    ////row.Idm1 = (int)values[3]; // ダミー
                    ////row.Idm2 = (int)values[4]; // ダミー
                    ////row.Cdm1 = DbNullConverter.ToString(values[5], null); // ダミー
                    ////row.Cdm2 = DbNullConverter.ToString(values[6], null); // ダミー
                    return row;
                },
                () => new List<TokuteiSyuunyuuKamoku>(),
                kesn);
        }
    }
}
