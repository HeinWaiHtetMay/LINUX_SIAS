﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class DenpyouSyuuseiDenpyouKeisikiOption
    {
        public DenpyouSyuuseiDenpyouKeisikiOptionDetail KoteisisanKanriSystemDenpyouKeisikiOptionDetail { get; set; }

        public DenpyouSyuuseiDenpyouKeisikiOptionDetail LeasesisanKanriSystemDenpyouKeisikiOptionDetail { get; set; }

        public DenpyouSyuuseiDenpyouKeisikiOptionDetail SaikenSystemDenpyouKeisikiOptionDetail { get; set; }

        public DenpyouSyuuseiDenpyouKeisikiOptionDetail FarmBankingZidouSiwakeSystemDenpyouKeisikiOptionDetail { get; set; }

        public DenpyouSyuuseiDenpyouKeisikiOptionDetail SaimuKizituKanriSystemDenpyouKeisikiOptionDetail { get; set; }

        public DenpyouSyuuseiDenpyouKeisikiOptionDetail GetDetail(DenpyouCreateSystem system)
        {
            switch (system)
            {
                case DenpyouCreateSystem.KoteisisanKanriSystem:
                    return this.KoteisisanKanriSystemDenpyouKeisikiOptionDetail;
                case DenpyouCreateSystem.LeasesisanKanriSystem:
                    return this.LeasesisanKanriSystemDenpyouKeisikiOptionDetail;
                case DenpyouCreateSystem.SaikenSystem:
                    return this.SaikenSystemDenpyouKeisikiOptionDetail;
                case DenpyouCreateSystem.FarmBankingZidouSiwakeSystem:
                    return this.FarmBankingZidouSiwakeSystemDenpyouKeisikiOptionDetail;
                case DenpyouCreateSystem.SaimuKizituKanriSystem:
                    return this.SaimuKizituKanriSystemDenpyouKeisikiOptionDetail;
                default:
                    return null;
            }
        }
    }
}
