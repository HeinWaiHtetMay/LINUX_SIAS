﻿using System;

namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class LinkInfomationOption
    {
        public LinkInfomationOption() => this.TimeStampSetting = new TimeStampSetting();

        /// <summary>
        /// リンク情報の登録可能な拡張子(XPS)
        /// </summary>
        public bool AvailableXps { get; set; }

        /// <summary>
        /// リンク情報の登録可能な拡張子(OXPS)
        /// </summary>
        public bool AvailableOxps { get; set; }

        /// <summary>
        /// リンク情報の登録可能な拡張子(DOC)
        /// </summary>
        public bool AvailableDocAndDocx { get; set; }

        /// <summary>
        /// リンク情報の登録可能な拡張子(DOCX)
        /// </summary>
        public bool AvailableXlsAndXlsx { get; set; }

        /// <summary>
        /// 月締め処理後にリンク情報の編集を許可する
        /// </summary>
        public bool AllowLinkInformationEditAfterTukizime { get; set; }

        /// <summary>
        /// タイムスタンプの付与をおこなう書類種別の設定
        /// </summary>
        public TimeStampSetting TimeStampSetting { get; set; }
    }
}
