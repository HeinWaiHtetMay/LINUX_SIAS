﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    /// <summary>
    /// 税率の出力タイプ
    /// </summary>
    public enum ZeirituOutputType
    {
        /// <summary>
        /// 最新の税率は出力しない
        /// </summary>
        NotOutputLatestZeiritu = 0,

        /// <summary>
        /// すべての税率を出力する
        /// </summary>
        OutputAllZeiritu = 1,
    }

    /// <summary>
    /// 税率の比較タイプ（元帳の税率設定）
    /// </summary>
    public enum ZeirituCompareType
    {
        /// <summary>
        /// 有効税率に置き換えて比較する
        /// </summary>
        CompareToConvertAvailableZeiritu = 0,

        /// <summary>
        /// 科目マスターの税率と比較する
        /// </summary>
        CompareToKamokuMasterZeiritu = 1,
    }
}
