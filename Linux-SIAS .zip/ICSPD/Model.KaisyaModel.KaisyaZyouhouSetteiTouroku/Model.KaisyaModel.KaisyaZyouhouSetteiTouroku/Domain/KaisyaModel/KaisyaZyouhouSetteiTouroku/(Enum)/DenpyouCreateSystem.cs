﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public enum DenpyouCreateSystem
    {
        OtherSystem = 0,

        Conversion = 901,

        KouziGenkaKanriSystem = 1000,

        KoteisisanKanriSystem = 2000,

        LeasesisanKanriSystem = 2051,

        SougouSiharaiKanriSystem = 3000,

        SaikenSystem = 4000,

        FarmBankingZidouSiwakeSystem = 5000,

        KesikomiKanriSystem = 6000,

        SaimuKizituKanriSystem = 7000,

        YosanSikkou = 8000,
    }
}
