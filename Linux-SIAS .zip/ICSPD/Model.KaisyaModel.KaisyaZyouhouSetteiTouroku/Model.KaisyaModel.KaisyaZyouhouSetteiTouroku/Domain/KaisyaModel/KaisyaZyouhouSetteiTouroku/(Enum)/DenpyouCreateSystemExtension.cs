﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public static class DenpyouCreateSystemExtension
    {
        public static string GetOptionKeyString(this DenpyouCreateSystem denpyouCreateSystem) => ((int)denpyouCreateSystem).ToString();
    }
}
