﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public enum KaisyaZyouhouSetteiTourokuDenpyouKeisiki
    {
        Unspecified = 0,
        TannituKeisiki = 1,
        HukugouKeisiki = 2,
    }
}
