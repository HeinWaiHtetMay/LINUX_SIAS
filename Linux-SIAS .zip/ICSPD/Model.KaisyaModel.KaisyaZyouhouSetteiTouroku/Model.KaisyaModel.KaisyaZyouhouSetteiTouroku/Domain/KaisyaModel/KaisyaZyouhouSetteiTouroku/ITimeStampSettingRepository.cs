﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface ITimeStampSettingRepository
    {
        /// <summary>
        /// タイムスタンプの付与をおこなう書類種別の設定を取得
        /// </summary>
        /// <returns></returns>
        TimeStampSetting Find();
    }
}