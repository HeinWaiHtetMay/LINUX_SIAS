﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface IPrintPreviewOptionRepository
    {
        PrintPreviewOption Find();
    }
}