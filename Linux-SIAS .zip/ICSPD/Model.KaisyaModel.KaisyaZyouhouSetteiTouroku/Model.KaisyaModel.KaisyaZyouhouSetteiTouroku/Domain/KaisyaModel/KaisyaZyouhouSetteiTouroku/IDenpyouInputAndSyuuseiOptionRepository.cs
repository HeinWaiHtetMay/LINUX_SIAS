﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface IDenpyouInputAndSyuuseiOptionRepository
    {
        /// <summary>
        /// 伝票入力修正設定を取得
        /// </summary>
        /// <returns></returns>
        DenpyouInputAndSyuuseiOption Find();
    }
}