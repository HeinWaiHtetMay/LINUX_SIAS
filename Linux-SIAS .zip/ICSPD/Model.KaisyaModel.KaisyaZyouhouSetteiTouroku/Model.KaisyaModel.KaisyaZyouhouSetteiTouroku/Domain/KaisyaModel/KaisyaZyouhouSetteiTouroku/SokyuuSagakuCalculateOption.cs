﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class SokyuuSagakuCalculateOption
    {
        /// <summary>
        /// 差額行の適用（元帳）
        /// </summary>
        public string MototyouTekiyouOfSagakuRow { get; set; } = Properties.Resources.過年度遡及による累積的影響額;

        /// <summary>
        /// 前期繰越の適用（元帳）
        /// </summary>
        public string MototyouTekiyouOfZenkiKurikosi { get; set; } = Properties.Resources.遡及処理後前期繰越;
    }
}
