﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    /// <summary>
    /// オプション単位の設定
    /// </summary>
    public class OptionUnit
    {
        /// <summary>
        /// 振替伝票のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue HurikaeDenpyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 部署別振替伝票のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue BusyobetuHurikaeDenpyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 元帳のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue MototyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 部署別元帳のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue BusyobetuMototyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 外貨元帳伝票のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue GaikaMototyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 部署別外貨元帳のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue BusyobetuGaikaMototyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 試算表・四半期諸表のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue SisanhyouSihankiSyoyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 部署別試算表・四半期諸表のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue BusyobetuSisanhyouSihankiSyoyouOptionUnit { get; set; } = OptionUnitValue.User;

        /// <summary>
        /// 四半期諸表（開示処理・過年度遡及）のオプション単位を取得・設定します
        /// </summary>
        public OptionUnitValue SihankiSyoyouOptionUnit { get; set; } = OptionUnitValue.User;
    }
}
