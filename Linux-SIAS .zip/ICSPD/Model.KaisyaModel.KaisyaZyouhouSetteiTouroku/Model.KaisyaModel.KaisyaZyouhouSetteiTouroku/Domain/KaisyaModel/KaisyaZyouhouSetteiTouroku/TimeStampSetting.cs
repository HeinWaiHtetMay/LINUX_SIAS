﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System;
    using Icsp.Open21.Domain.DateTimeModel;

    [Serializable]
    public class TimeStampSetting
    {
        /// <summary>
        /// 領収書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime ReceiptTimeStampStartDate { get; set; }

        /// <summary>
        /// 領収書e文書申請開始日
        /// </summary>
        public IcspDateTime ReceiptEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 領収書e文書申請終了日
        /// </summary>
        public IcspDateTime ReceiptEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 請求書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime InvoiceTimeStampStartDate { get; set; }

        /// <summary>
        /// 請求書e文書申請開始日
        /// </summary>
        public IcspDateTime InvoiceEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 請求書e文書申請終了日
        /// </summary>
        public IcspDateTime InvoiceEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 契約書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime ContractTimeStampStartDate { get; set; }

        /// <summary>
        /// 契約書e文書申請開始日
        /// </summary>
        public IcspDateTime ContractEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 契約書e文書申請終了日
        /// </summary>
        public IcspDateTime ContractEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 納品書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime DeliverySlipTimeStampStartDate { get; set; }

        /// <summary>
        /// 納品書e文書申請開始日
        /// </summary>
        public IcspDateTime DeliverySlipEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 納品書e文書申請終了日
        /// </summary>
        public IcspDateTime DeliverySlipEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 注文書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime PurchaseOrderTimeStampStartDate { get; set; }

        /// <summary>
        /// 注文書e文書申請開始日
        /// </summary>
        public IcspDateTime PurchaseOrderEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 注文書e文書申請終了日
        /// </summary>
        public IcspDateTime PurchaseOrderEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 見積書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime QuotationTimeStampStartDate { get; set; }

        /// <summary>
        /// 見積書e文書申請開始日
        /// </summary>
        public IcspDateTime QuotationEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 見積書e文書申請終了日
        /// </summary>
        public IcspDateTime QuotationEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 領収書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime ReceiptCopyTimeStampStartDate { get; set; }

        /// <summary>
        /// 領収書e文書申請開始日
        /// </summary>
        public IcspDateTime ReceiptCopyEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 領収書e文書申請終了日
        /// </summary>
        public IcspDateTime ReceiptCopyEdocumentApplicationEndDate { get; set; }

        /// <summary>
        /// 請求書タイムスタンプ付与開始日
        /// </summary>
        public IcspDateTime InvoiceCopyTimeStampStartDate { get; set; }

        /// <summary>
        /// 請求書e文書申請開始日
        /// </summary>
        public IcspDateTime InvoiceCopyEdocumentApplicationStartDate { get; set; }

        /// <summary>
        /// 請求書e文書申請終了日
        /// </summary>
        public IcspDateTime InvoiceCopyEdocumentApplicationEndDate { get; set; }
    }
}
