﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class PrintPreviewOption
    {
        /// <summary>
        /// チェックリストを印刷済みにするかどうか
        /// </summary>
        public bool AllowToMakeCheckListPrinted { get; set; } = false;

        /// <summary>
        /// 入力確定・チェックリストを印刷済みにするかどうか
        /// </summary>
        public bool AllowToMakeNyuuryokuKakuteiCheckListPrinted { get; set; } = false;

        /// <summary>
        /// 振替伝票（基本財務）を印刷済みにするかどうか
        /// </summary>
        public bool AllowToMakeHurikaeDenpyouOfZaimuPrinted { get; set; } = false;

        /// <summary>
        /// 振替伝票（部署入出力）を印刷済みにするかどうか
        /// </summary>
        public bool AllowToMakeHurikaeDenpyouOfBusyobetuPrinted { get; set; } = false;
    }
}
