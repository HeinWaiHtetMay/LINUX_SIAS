﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    /// <summary>
    /// 仕訳の出力設定
    /// </summary>
    public class SiwakeOutputOption
    {
        /// <summary>
        /// 税率の出力設定（振替伝票・仕訳日記帳）
        /// </summary>
        public ZeirituOutputType ZeirituOutputType { get; set; } = ZeirituOutputType.NotOutputLatestZeiritu;

        /// <summary>
        /// 元帳の税率設定（絶対表示）
        /// </summary>
        public ZeirituOutputType MototyouZeirituOutputTypeWhenKazeiKubunIsAbsoluteDisplay { get; set; } = ZeirituOutputType.NotOutputLatestZeiritu;

        /// <summary>
        /// 元帳の税率設定（相対表示）
        /// </summary>
        public ZeirituCompareType MototyouCompareTypeWhenKazeiKubunIsRelativeDisplay { get; set; } = ZeirituCompareType.CompareToConvertAvailableZeiritu;

        /// <summary>
        /// 諸口名称（画面用）
        /// </summary>
        public string SyokutiNameForForm { get; set; } = "諸　　　　　口";

        /// <summary>
        /// 諸口名称（印刷用）
        /// </summary>
        public string SyokutiNameForPrint { get; set; } = "諸　　　　　　　　　口";
    }
}
