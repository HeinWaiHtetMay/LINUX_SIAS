﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class DenpyouSyuuseiDenpyouKeisikiOptionDetail
    {
        public DenpyouSyuuseiDenpyouKeisikiOptionDetail(KaisyaZyouhouSetteiTourokuDenpyouKeisiki denpyouKeisiki, int denpyouLayoutPatternNo)
        {
            this.DenpyouKeisiki = denpyouKeisiki;
            this.DenpyouLayoutPatternNo = denpyouLayoutPatternNo;
        }

        public KaisyaZyouhouSetteiTourokuDenpyouKeisiki DenpyouKeisiki { get; set; }

        public int DenpyouLayoutPatternNo { get; set; }
    }
}
