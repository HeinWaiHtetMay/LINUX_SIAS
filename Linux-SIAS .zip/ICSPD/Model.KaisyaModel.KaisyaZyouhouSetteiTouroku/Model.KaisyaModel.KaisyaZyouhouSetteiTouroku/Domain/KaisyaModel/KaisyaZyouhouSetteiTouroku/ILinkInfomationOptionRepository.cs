﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface ILinkInfomationOptionRepository
    {
        LinkInfomationOption Find();
    }
}