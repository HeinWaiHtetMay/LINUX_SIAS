﻿using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface IDenpyouSyuuseiDenpyouKeisikiOptionRepository
    {
        DenpyouSyuuseiDenpyouKeisikiOption FindByKesn(int kesn);
    }
}