﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface ISiwakeOutputOptionRepository
    {
        SiwakeOutputOption Find();
    }
}