﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class ZandakaSyuukeihyouMeisyouKintouWaritukeOption
    {
        /// <summary>
        /// 名称の均等割り付け設定：均等割り付けするかどうか
        /// </summary>
        public bool IsKintouWarituke { get; set; } = false;

        /// <summary>
        /// 名称の均等割り付け設定：スペースを除去するかどうか
        /// </summary>
        public bool IsRemoveSpace { get; set; } = true;
    }
}
