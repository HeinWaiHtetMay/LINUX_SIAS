﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface IZandakaSyuukeihyouMeisyouKintouWaritukeOptionRepository
    {
        ZandakaSyuukeihyouMeisyouKintouWaritukeOption Find();
    }
}
