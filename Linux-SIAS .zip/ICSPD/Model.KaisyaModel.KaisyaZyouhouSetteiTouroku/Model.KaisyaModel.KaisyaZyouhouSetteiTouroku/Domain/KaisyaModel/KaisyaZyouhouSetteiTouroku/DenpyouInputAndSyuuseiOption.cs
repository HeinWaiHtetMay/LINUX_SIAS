﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public class DenpyouInputAndSyuuseiOption
    {
        public bool CheckTaikaInputted { get; set; }

        public bool CheckKihyosyaInputted { get; set; }

        public bool CheckKihyoBumonInputted { get; set; }

        public bool CheckHeaderField1Inputted { get; set; }

        public bool CheckHeaderField2Inputted { get; set; }

        public bool CheckHeaderField3Inputted { get; set; }

        public bool CheckHeaderField4Inputted { get; set; }

        public bool CheckHeaderField5Inputted { get; set; }

        public bool CheckHeaderField6Inputted { get; set; }

        public bool CheckHeaderField7Inputted { get; set; }

        public bool CheckHeaderField8Inputted { get; set; }

        public bool CheckHeaderField9Inputted { get; set; }

        public bool CheckHeaderField10Inputted { get; set; }

        public bool RegisterableSyokutiUnmatchDenpyou { get; set; }
    }
}