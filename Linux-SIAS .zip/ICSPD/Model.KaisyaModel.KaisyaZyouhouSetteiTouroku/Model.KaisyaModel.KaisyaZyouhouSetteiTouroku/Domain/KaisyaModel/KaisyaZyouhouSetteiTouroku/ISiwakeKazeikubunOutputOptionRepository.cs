﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    /// <summary>
    /// 会社情報設定登録、仕訳の税区分出力設定
    /// </summary>
    public interface ISiwakeKazeikubunOutputOptionRepository
    {
        /// <summary>
        /// 仕訳の課税区分「対象外」を出力するかどうかを取得します
        /// </summary>
        /// <param name="kesn"></param>
        /// <returns></returns>
        bool GetOutputKazeiKubunTaisyougaiByKesn(int kesn);
    }
}