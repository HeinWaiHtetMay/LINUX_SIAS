﻿namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public interface ISokyuuSagakuCalculateOptionRepository
    {
        SokyuuSagakuCalculateOption Find();
    }
}