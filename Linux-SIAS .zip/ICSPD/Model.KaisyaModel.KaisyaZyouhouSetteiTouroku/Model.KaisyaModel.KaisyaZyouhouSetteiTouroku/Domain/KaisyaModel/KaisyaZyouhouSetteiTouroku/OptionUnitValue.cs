﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    public enum OptionUnitValue
    {
        /// <summary>
        /// ユーザー単位
        /// </summary>
        User = 1,

        /// <summary>
        /// 会社単位
        /// </summary>
        Kaisya = 2
    }
}
