﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class SiwakeOutputOptionRepository : ISiwakeOutputOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual SiwakeOutputOption Find()
        {
            var siwakeOutputOption = new SiwakeOutputOption();
            var dtoList = this.option1Dao.FindByPrgidForUserShared(Data.DataSource.DatabaseType.KaisyaDb, "CCINFOMNT");
            if (dtoList != null)
            {
                foreach (var dto in dtoList)
                {
                    switch (dto.Keynm1)
                    {
                        case "RituOut":
                            siwakeOutputOption.ZeirituOutputType = (ZeirituOutputType)(dto.Idata ?? 0);
                            break;
                        case "Led_Zettai":
                            siwakeOutputOption.MototyouZeirituOutputTypeWhenKazeiKubunIsAbsoluteDisplay = (ZeirituOutputType)(dto.Idata ?? 0);
                            break;
                        case "Led_Soutai":
                            siwakeOutputOption.MototyouCompareTypeWhenKazeiKubunIsRelativeDisplay = (ZeirituCompareType)(dto.Idata ?? 0);
                            break;
                        case "SYOKUCHI_NAM1":
                            siwakeOutputOption.SyokutiNameForForm = dto.Cdata;
                            break;
                        case "SYOKUCHI_NAM2":
                            siwakeOutputOption.SyokutiNameForPrint = dto.Cdata;
                            break;
                    }
                }
            }

            return siwakeOutputOption;
        }
    }
}
