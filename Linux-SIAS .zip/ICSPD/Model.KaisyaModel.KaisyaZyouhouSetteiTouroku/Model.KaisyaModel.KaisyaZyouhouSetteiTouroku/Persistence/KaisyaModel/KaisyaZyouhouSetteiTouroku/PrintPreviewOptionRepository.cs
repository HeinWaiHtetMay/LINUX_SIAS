﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class PrintPreviewOptionRepository : IPrintPreviewOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual PrintPreviewOption Find()
        {
            var printPreviewOption = new PrintPreviewOption();
            var dtoList = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(Data.DataSource.DatabaseType.KaisyaDb, "CCINFOMNT", "PrevCPRT");
            foreach (var item in dtoList)
            {
                switch (item.Keynm2)
                {
                    case "CHKMAIN":
                        printPreviewOption.AllowToMakeCheckListPrinted = item.Idata == 1;
                        break;
                    case "SFCHKMAIN":
                        printPreviewOption.AllowToMakeNyuuryokuKakuteiCheckListPrinted = item.Idata == 1;
                        break;
                    case "FURIKAE":
                        printPreviewOption.AllowToMakeHurikaeDenpyouOfZaimuPrinted = item.Idata == 1;
                        break;
                    case "SFFURIKAE":
                        printPreviewOption.AllowToMakeHurikaeDenpyouOfBusyobetuPrinted = item.Idata == 1;
                        break;
                }
            }

            return printPreviewOption;
        }
    }
}
