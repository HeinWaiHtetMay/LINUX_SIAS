﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class OptionUnitRepository : IOptionUnitRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual OptionUnit Find()
        {
            var result = new OptionUnit();
            foreach (var dto in this.option1Dao.FindByPrgidForUserShared(DatabaseType.KaisyaDb, "CCINFOMNT"))
            {
                var value = dto.Idata.HasValue ? (OptionUnitValue)dto.Idata.Value : OptionUnitValue.User;
                var isBasic = dto.Keynm2 == "BASIC";
                switch (dto.Keynm1)
                {
                    case "FURIKAEOPT":
                        if (isBasic)
                        {
                            result.HurikaeDenpyouOptionUnit = value;
                        }
                        else
                        {
                            result.BusyobetuHurikaeDenpyouOptionUnit = value;
                        }

                        break;
                    case "MOTOOPT":
                        if (isBasic)
                        {
                            result.MototyouOptionUnit = value;
                        }
                        else
                        {
                            result.BusyobetuMototyouOptionUnit = value;
                        }

                        break;
                    case "GAIKAMOTOOPT":
                        if (isBasic)
                        {
                            result.GaikaMototyouOptionUnit = value;
                        }
                        else
                        {
                            result.BusyobetuGaikaMototyouOptionUnit = value;
                        }

                        break;
                    case "SISANOPT":
                        if (isBasic)
                        {
                            result.SisanhyouSihankiSyoyouOptionUnit = value;
                        }
                        else
                        {
                            result.BusyobetuSisanhyouSihankiSyoyouOptionUnit = value;
                        }

                        break;
                    case "SIHANKIOPT":
                        result.SihankiSyoyouOptionUnit = value;
                        break;
                    default:
                        break;
                }
            }

            return result;
        }
    }
}
