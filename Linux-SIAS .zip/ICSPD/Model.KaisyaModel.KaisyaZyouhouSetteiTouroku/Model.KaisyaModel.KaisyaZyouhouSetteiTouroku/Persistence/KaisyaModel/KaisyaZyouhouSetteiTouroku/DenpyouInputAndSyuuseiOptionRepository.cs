﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    /// <summary>
    /// 伝票入力修正設定
    /// </summary>
    [Component]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputAndSyuuseiOptionRepository : IDenpyouInputAndSyuuseiOptionRepository
    {
        private static readonly string KaisyaZyouhouSetteiTourokuProgramId = "CCINFOMNT";
        private static readonly string DenpyouSyuuseiProgramId = "DMNTFRIV";

        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual DenpyouInputAndSyuuseiOption Find()
        {
            var dtoList = this.option1Dao.FindByPrgidForUserShared(DatabaseType.KaisyaDb, KaisyaZyouhouSetteiTourokuProgramId);
            var denpyouSyuuseiOption = new DenpyouInputAndSyuuseiOption();
            denpyouSyuuseiOption.CheckTaikaInputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "TAIKA", 0, 0) == 1;
            denpyouSyuuseiOption.CheckKihyosyaInputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "KIHYOSYA_MI", 0, 0) == 1;
            denpyouSyuuseiOption.CheckKihyoBumonInputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "KIHYOBMN_MI", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField1Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF1", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField2Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF2", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField3Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF3", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField4Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF4", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField5Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF5", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField6Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF6", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField7Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF7", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField8Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF8", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField9Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF9", 0, 0) == 1;
            denpyouSyuuseiOption.CheckHeaderField10Inputted = dtoList.GetIdata(DenpyouSyuuseiProgramId, "HF10", 0, 0) == 1;
            denpyouSyuuseiOption.RegisterableSyokutiUnmatchDenpyou = dtoList.GetIdata(DenpyouSyuuseiProgramId, "SYOKUCHI_UNMATCH", 0, 0) == 1;
            return denpyouSyuuseiOption;
        }
    }
}
