﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ZandakaSyuukeihyouMeisyouKintouWaritukeOptionRepository : IZandakaSyuukeihyouMeisyouKintouWaritukeOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual ZandakaSyuukeihyouMeisyouKintouWaritukeOption Find()
        {
            var optionDataList = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(Data.DataSource.DatabaseType.KaisyaDb, "CCINFOMNT", "TOIMAIN");
            var zandakaSyuukeihyouMeisyouKintouWaritukeOption = new ZandakaSyuukeihyouMeisyouKintouWaritukeOption();
            this.SetZandakaSyuukeihyouMeisyouKintouWaritukeOptionProperties(optionDataList, zandakaSyuukeihyouMeisyouKintouWaritukeOption);
            return zandakaSyuukeihyouMeisyouKintouWaritukeOption;
        }

        private void SetZandakaSyuukeihyouMeisyouKintouWaritukeOptionProperties(IList<Option1Dto> dtoList, ZandakaSyuukeihyouMeisyouKintouWaritukeOption meisyouKintouWaritukeOption)
        {
            if (dtoList != null)
            {
                foreach (var item in dtoList)
                {
                    switch (item.Keyno)
                    {
                        case 1:
                            meisyouKintouWaritukeOption.IsKintouWarituke = item.Idata == 1;
                            break;
                        case 2:
                            meisyouKintouWaritukeOption.IsRemoveSpace = item.Idata == 1;
                            break;
                    }
                }
            }
        }
    }
}
