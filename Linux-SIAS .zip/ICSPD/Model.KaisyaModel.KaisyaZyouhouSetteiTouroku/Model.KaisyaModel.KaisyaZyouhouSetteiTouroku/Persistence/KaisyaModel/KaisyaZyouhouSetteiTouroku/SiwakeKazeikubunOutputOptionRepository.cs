﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeKazeikubunOutputOptionRepository : ISiwakeKazeikubunOutputOptionRepository
    {
        [AutoInjection]
        private IOption2Dao option2Dao = null;

        public bool GetOutputKazeiKubunTaisyougaiByKesn(int kesn)
        {
            var idata = this.option2Dao.FindByPrgidAndKesnAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, "CCINFOMNT", kesn, "SWKLIST").FirstOrDefault(dto => dto.Keynm2 == "TAISYOGAI" && dto.Keyno == 0)?.Idata;
            return idata.HasValue ? idata == 1 : true;
        }
    }
}
