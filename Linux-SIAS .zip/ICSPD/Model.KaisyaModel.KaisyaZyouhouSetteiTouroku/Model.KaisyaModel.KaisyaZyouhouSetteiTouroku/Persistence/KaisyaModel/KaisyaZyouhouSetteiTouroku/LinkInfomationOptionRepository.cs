﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class LinkInfomationOptionRepository : ILinkInfomationOptionRepository
    {
        private static readonly string KaisyaZyouhouSetteiTourokuProgramId = "CCINFOMNT";
        private static readonly string DenpyouSyuuseiProgramId = "DMNTFRIV";

        [AutoInjection]
        private IOption1Dao option1Dao = null;

        [AutoInjection]
        private ITimeStampSettingRepository timeStampSettingRepository = null;

        public virtual LinkInfomationOption Find()
        {
            var linkInfomationOption = new LinkInfomationOption();

            var dtoList = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, KaisyaZyouhouSetteiTourokuProgramId, DenpyouSyuuseiProgramId);
            linkInfomationOption.AvailableXps = dtoList.GetIdata(DenpyouSyuuseiProgramId, "XPS", 0, 0) == 1;
            linkInfomationOption.AvailableOxps = dtoList.GetIdata(DenpyouSyuuseiProgramId, "OXPS", 0, 0) == 1;
            linkInfomationOption.AvailableDocAndDocx = dtoList.GetIdata(DenpyouSyuuseiProgramId, "DOCDOCX", 0, 0) == 1;
            linkInfomationOption.AvailableXlsAndXlsx = dtoList.GetIdata(DenpyouSyuuseiProgramId, "XLSXLSX", 0, 0) == 1;

            dtoList = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, KaisyaZyouhouSetteiTourokuProgramId, "LinkInfo");
            linkInfomationOption.AllowLinkInformationEditAfterTukizime = dtoList.GetIdata("LinkInfo", "LINKHENSHU", 0, 0) == 1;

            linkInfomationOption.TimeStampSetting = this.timeStampSettingRepository.Find();

            return linkInfomationOption;
        }
    }
}
