﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    /// <summary>
    /// タイムスタンプの付与をおこなう書類種別の設定
    /// </summary>
    [Component]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TimeStampSettingRepository : ITimeStampSettingRepository
    {
        private static readonly string KaisyaZyouhouSetteiTourokuProgramId = "CCINFOMNT";
        private static readonly string LinkInfomationOptionKeynm1 = "LinkInfo";

        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual TimeStampSetting Find()
        {
            var option1List = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(
                Data.DataSource.DatabaseType.KaisyaDb,
                KaisyaZyouhouSetteiTourokuProgramId,
                LinkInfomationOptionKeynm1);

            var timeStampSetting = new TimeStampSetting();

            var dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUSHO", 1, 0);
            timeStampSetting.ReceiptTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUSHO", 2, 0);
            timeStampSetting.ReceiptTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUSHO", 3, 0);
            timeStampSetting.ReceiptEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUSHO", 1, 0);
            timeStampSetting.InvoiceTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUSHO", 2, 0);
            timeStampSetting.InvoiceEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUSHO", 3, 0);
            timeStampSetting.InvoiceEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "KEIYAKUSHO", 1, 0);
            timeStampSetting.ContractTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "KEIYAKUSHO", 2, 0);
            timeStampSetting.ContractEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "KEIYAKUSHO", 3, 0);
            timeStampSetting.ContractEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "NOUHINSHO", 1, 0);
            timeStampSetting.DeliverySlipTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "NOUHINSHO", 2, 0);
            timeStampSetting.DeliverySlipEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "NOUHINSHO", 3, 0);
            timeStampSetting.DeliverySlipEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "CHUMONSHO", 1, 0);
            timeStampSetting.PurchaseOrderTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "CHUMONSHO", 2, 0);
            timeStampSetting.PurchaseOrderEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "CHUMONSHO", 3, 0);
            timeStampSetting.PurchaseOrderEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "MITSUMORISHO", 1, 0);
            timeStampSetting.QuotationTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "MITSUMORISHO", 2, 0);
            timeStampSetting.QuotationEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "MITSUMORISHO", 3, 0);
            timeStampSetting.QuotationEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUHIKAE", 1, 0);
            timeStampSetting.ReceiptCopyTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUHIKAE", 2, 0);
            timeStampSetting.ReceiptCopyEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "RYOSHUHIKAE", 3, 0);
            timeStampSetting.ReceiptCopyEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUHIKAE", 1, 0);
            timeStampSetting.InvoiceCopyTimeStampStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUHIKAE", 2, 0);
            timeStampSetting.InvoiceCopyEdocumentApplicationStartDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);
            dateNumber = option1List.GetIdata(LinkInfomationOptionKeynm1, "SEIKYUHIKAE", 3, 0);
            timeStampSetting.InvoiceCopyEdocumentApplicationEndDate = dateNumber == 0 ? null : new IcspDateTime(dateNumber, 0);

            return timeStampSetting;
        }
    }
}
