﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Component]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouSyuuseiDenpyouKeisikiOptionRepository : IDenpyouSyuuseiDenpyouKeisikiOptionRepository
    {
        private static readonly string KaisyaZyouhouSetteiTourokuProgramId = "CCINFOMNT";
        private static readonly string DenpyouSyuuseiProgramId = "DMNTFRIV";

        [AutoInjection]
        private IOption2Dao option2Dao = null;

        public virtual DenpyouSyuuseiDenpyouKeisikiOption FindByKesn(int kesn)
        {
            var dtoList = this.option2Dao.FindByPrgidAndKesnAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, KaisyaZyouhouSetteiTourokuProgramId, kesn, DenpyouSyuuseiProgramId);
            var denpyouSyuuseiDenpyouKeisikiOption = new DenpyouSyuuseiDenpyouKeisikiOption();

            denpyouSyuuseiDenpyouKeisikiOption.KoteisisanKanriSystemDenpyouKeisikiOptionDetail =
                new DenpyouSyuuseiDenpyouKeisikiOptionDetail(
                    (KaisyaZyouhouSetteiTourokuDenpyouKeisiki)dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.KoteisisanKanriSystem.GetOptionKeyString(), 1, 0),
                    dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.KoteisisanKanriSystem.GetOptionKeyString(), 2, 0));

            denpyouSyuuseiDenpyouKeisikiOption.LeasesisanKanriSystemDenpyouKeisikiOptionDetail =
                new DenpyouSyuuseiDenpyouKeisikiOptionDetail(
                    (KaisyaZyouhouSetteiTourokuDenpyouKeisiki)dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.LeasesisanKanriSystem.GetOptionKeyString(), 1, 0),
                    dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.LeasesisanKanriSystem.GetOptionKeyString(), 2, 0));

            denpyouSyuuseiDenpyouKeisikiOption.SaikenSystemDenpyouKeisikiOptionDetail =
                new DenpyouSyuuseiDenpyouKeisikiOptionDetail(
                    (KaisyaZyouhouSetteiTourokuDenpyouKeisiki)dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.SaikenSystem.GetOptionKeyString(), 1, 0),
                    dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.SaikenSystem.GetOptionKeyString(), 2, 0));

            denpyouSyuuseiDenpyouKeisikiOption.FarmBankingZidouSiwakeSystemDenpyouKeisikiOptionDetail =
                new DenpyouSyuuseiDenpyouKeisikiOptionDetail(
                    (KaisyaZyouhouSetteiTourokuDenpyouKeisiki)dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.FarmBankingZidouSiwakeSystem.GetOptionKeyString(), 1, 0),
                    dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.FarmBankingZidouSiwakeSystem.GetOptionKeyString(), 2, 0));

            denpyouSyuuseiDenpyouKeisikiOption.SaimuKizituKanriSystemDenpyouKeisikiOptionDetail =
                new DenpyouSyuuseiDenpyouKeisikiOptionDetail(
                    (KaisyaZyouhouSetteiTourokuDenpyouKeisiki)dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.SaimuKizituKanriSystem.GetOptionKeyString(), 1, 0),
                    dtoList.GetIdata(DenpyouSyuuseiProgramId, DenpyouCreateSystem.SaimuKizituKanriSystem.GetOptionKeyString(), 2, 0));

            return denpyouSyuuseiDenpyouKeisikiOption;
        }
    }
}
