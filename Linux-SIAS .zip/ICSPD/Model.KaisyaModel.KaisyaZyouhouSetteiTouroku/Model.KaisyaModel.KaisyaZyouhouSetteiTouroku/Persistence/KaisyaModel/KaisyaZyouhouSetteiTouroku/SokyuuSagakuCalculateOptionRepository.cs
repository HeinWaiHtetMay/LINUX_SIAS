﻿namespace Icsp.Open21.Persistence.KaisyaModel.KaisyaZyouhouSetteiTouroku
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class SokyuuSagakuCalculateOptionRepository : ISokyuuSagakuCalculateOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual SokyuuSagakuCalculateOption Find()
        {
            var optionDataList = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(Data.DataSource.DatabaseType.KaisyaDb, "CCINFOMNT", "LEDMAIN");
            var sokyuuSagakuCalculateOption = new SokyuuSagakuCalculateOption();
            this.SetSokyuuSagakuCalculateOptionProperties(optionDataList, sokyuuSagakuCalculateOption);
            return sokyuuSagakuCalculateOption;
        }

        private void SetSokyuuSagakuCalculateOptionProperties(IList<Option1Dto> dtoList, SokyuuSagakuCalculateOption option)
        {
            if (dtoList != null)
            {
                foreach (var item in dtoList)
                {
                    switch (item.Keynm2)
                    {
                        case "TEKIYO1":
                            option.MototyouTekiyouOfSagakuRow = item.Cdata;
                            break;
                        case "TEKIYO2":
                            option.MototyouTekiyouOfZenkiKurikosi = item.Cdata;
                            break;
                    }
                }
            }
        }
    }
}
