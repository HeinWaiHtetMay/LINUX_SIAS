﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IDenpyouKoumokuNotInputCheckSettingRepository
    {
        DenpyouKoumokuNotInputCheckSetting Find();
    }
}