﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface ISyouninCommentRepository
    {
        IList<SyouninComment> FindByKesnOrderByCseqDesc(int kesn, DenpyouType denpyouType);

        IList<SyouninComment> FindByKesnAndKeikAndDseqAndSseqOrderByCseqDesc(int kesn, int dkei, int dseq, int sseq, DenpyouType denpyouType);

        bool GetExistsByKesnAndKeikAndDseqAndSseqAndCseq(SyouninComment syouninComment, DenpyouType denpyouType);

        bool Insert(SyouninComment syouninComment, DenpyouType denpyouType);

        bool Insert(SyouninComment syouninComment, DenpyouType denpyouType, bool isHubanCommentSequenceNumber);
    }
}