﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface ILinkInfomationFileRepository
    {
        string FileImport(string ccod, int kesn, string userCode, string originalFileFullPath);
    }
}