﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface ILinkInfomationFactory
    {
        /// <summary>
        /// 既存リンク情報
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="lkid"></param>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        LinkInfomation CreateKizonLinkInfomation(int kesn, int dkei, int dseq, int lkid, DenpyouType denpyouType);

        /// <summary>
        /// 新規リンク情報
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="lkid"></param>
        /// <param name="denpyouType"></param>
        /// <param name="nyuuryokusyaCode"></param>
        /// <param name="nyuuryokuSyudan"></param>
        /// <returns></returns>
        LinkInfomation CreateNewLinkInfomation(int kesn, int dkei, int dseq, int lkid, DenpyouType denpyouType, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan);
    }
}