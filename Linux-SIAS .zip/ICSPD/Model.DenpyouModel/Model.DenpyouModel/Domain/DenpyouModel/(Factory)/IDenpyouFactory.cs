﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IDenpyouFactory
    {
        Denpyou CreateSinkiDenpyou(int kesn, int dkei, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokusyudan);

        Denpyou CreateKizonDenpyou(int kesn, int dkei, int dseq);
    }
}