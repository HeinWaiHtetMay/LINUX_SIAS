﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.ComponentModel;
    using System.IO;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.IO;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class EdocumentFactory : IEdocumentFactory
    {
        [AutoInjection]
        private IFileResourceFactory fileResourceFactory = null;

        [AutoInjection]
        private IEdocumentFileRepository edocumentFileRepository = null;

        public virtual Edocument CreateNewEdocument(string ccod, int kesn, User user, string originalFilePath)
        {
            // 会社フォルダを作成
            var kaisyaDirectoryPath = this.fileResourceFactory.CreateEdocumentResource(ccod, string.Empty).FileFullPath;
            if (!Directory.Exists(kaisyaDirectoryPath))
            {
                Directory.CreateDirectory(kaisyaDirectoryPath);
            }

            // 決算期フォルダを作成
            var kessankiDirectoryPath = this.fileResourceFactory.CreateEdocumentResource(ccod, kesn, string.Empty).FileFullPath;
            if (!Directory.Exists(kessankiDirectoryPath))
            {
                Directory.CreateDirectory(kessankiDirectoryPath);
            }

            // tmpフォルダを作成
            var tmpDirectoryPath = this.fileResourceFactory.CreateEdocumentResource(ccod, kesn, "tmp").FileFullPath;
            if (!Directory.Exists(tmpDirectoryPath))
            {
                Directory.CreateDirectory(tmpDirectoryPath);
            }

            // e文書番号を作成
            var edocumentNo = this.edocumentFileRepository.NumberEdocumentNo(ccod, kesn);

            // e文書（タイムスタンプ付与前）を作成
            this.edocumentFileRepository.ImportTemporaryFile(ccod, kesn, edocumentNo, originalFilePath);

            // e文書を作成
            return new Edocument(kesn, edocumentNo, user.UserCode)
                {
                    Nusr = string.Format("{0}:{1:0000}", user.Name, user.UserCode)
                };
        }

        public virtual Edocument CreateRegisteredEdocument(int kesn, string edoc) => new Edocument(kesn, edoc);
    }
}