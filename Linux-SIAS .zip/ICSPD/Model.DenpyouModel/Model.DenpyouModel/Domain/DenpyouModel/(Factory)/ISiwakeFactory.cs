﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface ISiwakeFactory
    {
        Siwake CreateSinkiSiwake(int kesn, int dkei, int dseq, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan);

        Siwake CreateKizonSiwake(int kesn, int dkei, int dseq, int sseq);
    }
}