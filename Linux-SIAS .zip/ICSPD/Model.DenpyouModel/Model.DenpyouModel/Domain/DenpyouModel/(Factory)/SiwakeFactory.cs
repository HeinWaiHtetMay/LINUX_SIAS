﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class SiwakeFactory : ISiwakeFactory
    {
        public virtual Siwake CreateSinkiSiwake(int kesn, int dkei, int dseq, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan) =>
            new Siwake(kesn, dkei, dseq, nyuuryokusyaCode, nyuuryokuSyudan);

        public virtual Siwake CreateKizonSiwake(int kesn, int dkei, int dseq, int sseq) =>
            new Siwake(kesn, dkei, dseq, sseq);
    }
}
