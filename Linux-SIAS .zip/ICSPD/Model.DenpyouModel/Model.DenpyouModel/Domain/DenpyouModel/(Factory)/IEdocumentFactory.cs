﻿using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IEdocumentFactory
    {
        Edocument CreateNewEdocument(string ccod, int kesn, User user, string originalFilePath);

        Edocument CreateRegisteredEdocument(int kesn, string edoc);
    }
}
