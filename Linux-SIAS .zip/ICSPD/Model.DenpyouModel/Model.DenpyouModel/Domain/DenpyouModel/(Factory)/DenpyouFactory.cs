﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class DenpyouFactory : IDenpyouFactory
    {
        public virtual Denpyou CreateSinkiDenpyou(int kesn, int dkei, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokusyudan) =>
            new Denpyou(kesn, dkei, nyuuryokusyaCode, nyuuryokusyudan);

        public virtual Denpyou CreateKizonDenpyou(int kesn, int dkei, int dseq) =>
            new Denpyou(kesn, dkei, dseq);
    }
}
