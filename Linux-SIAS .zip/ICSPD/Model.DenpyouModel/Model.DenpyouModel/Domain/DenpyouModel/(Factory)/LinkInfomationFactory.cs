﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class LinkInfomationFactory : ILinkInfomationFactory
    {
        public virtual LinkInfomation CreateNewLinkInfomation(
            int kesn,
            int dkei,
            int dseq,
            int lkid,
            DenpyouType denpyouType,
            int nyuuryokusyaCode,
            DenpyouSiwakeWayToCreate nyuuryokuSyudan) =>
            new LinkInfomation(kesn, dkei, dseq, lkid, denpyouType, nyuuryokusyaCode, nyuuryokuSyudan);

        public virtual LinkInfomation CreateKizonLinkInfomation(
            int kesn,
            int dkei,
            int dseq,
            int lkid,
            DenpyouType denpyouType) =>
            new LinkInfomation(kesn, dkei, dseq, lkid, denpyouType);
    }
}
