﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IZidouhubanService
    {
        ZidouhubanResult NumberDenpyouNo(Denpyou denpyou, ZidouhubanSyokiSettei zidouhubanSyokiSettei, ZidouhubanGroup zidouhubanGroup, DenpyouType denpyouType);
    }
}
