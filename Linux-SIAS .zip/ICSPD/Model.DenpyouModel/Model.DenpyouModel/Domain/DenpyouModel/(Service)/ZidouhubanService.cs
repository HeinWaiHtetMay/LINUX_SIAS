﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;

    [Service(ServiceType.DomainService)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ZidouhubanService : IZidouhubanService
    {
        [AutoInjection]
        private IZidouhubanDenpyouNoRepository zidouhubanDenpyouNoRepository = null;

        [AutoInjection]
        private IDenpyouNoDuplicationValidator denpyouNoDuplicationValidator = null;

        public virtual ZidouhubanResult NumberDenpyouNo(Denpyou denpyou, ZidouhubanSyokiSettei zidouhubanSyokiSettei, ZidouhubanGroup zidouhubanGroup, DenpyouType denpyouType)
        {
            var keik = 0;
            var zidouHubanGroupNo = 0;
            switch (zidouhubanSyokiSettei.ZidouhubanType)
            {
                case ZidouhubanType.GekkanItii:
                    keik = denpyou.Dkei;
                    break;
                case ZidouhubanType.NenkanItii:
                    break;
                case ZidouhubanType.GroupGekkanItii:
                    keik = denpyou.Dkei;
                    zidouHubanGroupNo = zidouhubanGroup.Fgno;
                    break;
                case ZidouhubanType.GroupNenkanItii:
                    zidouHubanGroupNo = zidouhubanGroup.Fgno;
                    break;
            }

            var zidouhubanDenpyouNoEntity = this.zidouhubanDenpyouNoRepository.FindByKesnAndKeikAndFgno(denpyou.Kesn, keik, zidouHubanGroupNo);
            zidouhubanDenpyouNoEntity.Dcno++;
            denpyou.DenpyouNo = zidouhubanDenpyouNoEntity.Dcno;
            var result = this.denpyouNoDuplicationValidator.ValidateDenpyouNoDuplication(denpyou, denpyouType, zidouhubanSyokiSettei);
            if (result.HasDuplication)
            {
                return new ZidouhubanResult(result.DuplicationDenpyouType);
            }

            this.zidouhubanDenpyouNoRepository.UpdateDcno(zidouhubanDenpyouNoEntity);
            return new ZidouhubanResult();
        }
    }
}
