﻿using System;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface ITimeStampService
    {
        /// <summary>
        /// PDFにタイムスタンプを付与
        /// </summary>
        /// <param name="denpyou">
        /// タイムスタンプ付与をおこなうe文書を含んでいる伝票
        /// </param>
        /// <param name="ccod">
        /// 処理会社コード
        /// </param>
        /// <param name="errorHanding">
        /// エラー時のメッセージ表示処理
        /// </param>
        /// <returns></returns>
        bool CopyFileOrSetTimeStamp(Denpyou denpyou, string ccod, Func<TimeStampProcessResult, bool> errorHanding);
    }
}