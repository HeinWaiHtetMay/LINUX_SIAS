﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;
    using Icsp.Open21.Persistence.ZandakaYosanModel;

    [Service(ServiceType.ApplicationService)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouZandakaUpdateService : IDenpyouZandakaUpdateService
    {
        [AutoInjection]
        private IKamokuZandakaRepository kamokuZandakaRipository = null;

        [AutoInjection]
        private IBumonKamokuZandakaRepository bumonKamokuZandakaRipository = null;

        [AutoInjection]
        private IKamokuEdabanZandakaRepository kamokuEdabanZandakaRipository = null;

        [AutoInjection]
        private ITorihikisakiKamokuZandakaRepository torihikisakiKamokuZandakaRipository = null;

        [AutoInjection]
        private IBumonKamokuEdabanZandakaRepository bumonKamokuEdabanZandakaRipository = null;

        [AutoInjection]
        private IBumonKamokuTorihikisakiZandakaRepository bumonKamokuTorihikisakiZandakaRipository = null;

        [AutoInjection]
        private ISegmentKamokuZandakaRepository segmentKamokuZandakaRipository = null;

        [AutoInjection]
        private ISegmentKamokuTorihikisakiZandakaRepository segmentKamokuTorihikisakiZandakaRipository = null;

        [AutoInjection]
        private IUniversalFieldKamokuZandakaRepository universalFieldKamokuZandakaRipository = null;

        [AutoInjection]
        private IGaikaKamokuZandakaRepository gaikaKamokuZandakaRipository = null;

        [AutoInjection]
        private IGaikaBumonKamokuZandakaRepository gaikaBumonKamokuZandakaRipository = null;

        [AutoInjection]
        private IGaikaKamokuEdabanZandakaRepository gaikaKamokuEdabanZandakaRipository = null;

        [AutoInjection]
        private IGaikaTorihikisakiKamokuZandakaRepository gaikaTorihikisakiKamokuZandakaRipository = null;

        /// <summary>
        /// 伝票登録、伝票取り消し時の残高更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        /// <param name="syoriki"></param>
        /// <param name="isTorikesi"></param>
        /// <param name="isZandakaUpdate"></param>
        /// <param name="useGaika"></param>
        public virtual void UpdateZandakaAtInsertDenpyouAndDenpyouTorikesi(
            Denpyou denpyou,
            DenpyouType denpyouType,
            Syoriki syoriki,
            bool isTorikesi,
            bool isZandakaUpdate,
            bool useGaika)
        {
            if (denpyouType != DenpyouType.TuuzyouDenpyou || !isZandakaUpdate)
            {
                return;
            }

            this.kamokuZandakaRipository.Update(this.GetKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
            if (syoriki.BumonInfo.Use)
            {
                this.bumonKamokuZandakaRipository.Update(this.GetBumonKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.EdabanInfo.Use)
            {
                this.kamokuEdabanZandakaRipository.Update(this.GetKamokuEdabanZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseTorihikisakiKamokuZandakaImmediateUpdate)
            {
                this.torihikisakiKamokuZandakaRipository.Update(this.GetTorihikisakiKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseBumonKamokuEdabanZandakaImmediateUpdate)
            {
                this.bumonKamokuEdabanZandakaRipository.Update(this.GetBumonKamokuEdabanZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseBumonKamokuTorihikisakiZandakaImmediateUpdate)
            {
                this.bumonKamokuTorihikisakiZandakaRipository.Update(this.GetBumonKamokuTorihikisakiZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseSegmentKamokuZandakaImmediateUpdate)
            {
                this.segmentKamokuZandakaRipository.Update(this.GetSegmentKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseSegmentKamokuTorihikisakiZandakaImmediateUpdate)
            {
                this.segmentKamokuTorihikisakiZandakaRipository.Update(this.GetSegmentKamokuTorihikisakiZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseUniversal1KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(syoriki.GetUniversalFieldInfo(false, 1), this.GetUniversalField1ZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseUniversal2KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(syoriki.GetUniversalFieldInfo(false, 2), this.GetUniversalField2ZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (syoriki.UseUniversal3KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(syoriki.GetUniversalFieldInfo(false, 3), this.GetUniversalField3ZandakaTargetUpdate(denpyou, !isTorikesi));
            }

            if (useGaika)
            {
                this.gaikaKamokuZandakaRipository.Update(this.GetGaikaKamokuZandakaTargetUpdate(denpyou, !isTorikesi));

                if (syoriki.BumonInfo.Use)
                {
                    this.gaikaBumonKamokuZandakaRipository.Update(this.GetGaikaBumonKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
                }

                if (syoriki.EdabanInfo.Use)
                {
                    this.gaikaKamokuEdabanZandakaRipository.Update(this.GetGaikaKamokuEdabanZandakaTargetUpdate(denpyou, !isTorikesi));
                }

                if (syoriki.UseTorihikisakiKamokuZandakaImmediateUpdate)
                {
                    this.gaikaTorihikisakiKamokuZandakaRipository.Update(this.GetGaikaTorihikisakiKamokuZandakaTargetUpdate(denpyou, !isTorikesi));
                }
            }
        }

        /// <summary>
        /// 伝票更新時の残高更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouOld"></param>
        /// <param name="denpyouType"></param>
        /// <param name="syoriki"></param>
        /// <param name="isZandakaUpdate"></param>
        /// <param name="useGaika"></param>
        public virtual void UpdateZandakaAtUpdateDenpyou(
            Denpyou denpyou,
            Denpyou denpyouOld,
            DenpyouType denpyouType,
            Syoriki syoriki,
            bool isZandakaUpdate,
            bool useGaika)
        {
            if (denpyouType != DenpyouType.TuuzyouDenpyou || !isZandakaUpdate)
            {
                return;
            }

            this.kamokuZandakaRipository.Update(this.GetKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));

            if (syoriki.BumonInfo.Use)
            {
                this.bumonKamokuZandakaRipository.Update(this.GetBumonKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.EdabanInfo.Use)
            {
                this.kamokuEdabanZandakaRipository.Update(this.GetKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseTorihikisakiKamokuZandakaImmediateUpdate)
            {
                this.torihikisakiKamokuZandakaRipository.Update(this.GetTorihikisakiKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseBumonKamokuEdabanZandakaImmediateUpdate)
            {
                this.bumonKamokuEdabanZandakaRipository.Update(this.GetBumonKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseBumonKamokuTorihikisakiZandakaImmediateUpdate)
            {
                this.bumonKamokuTorihikisakiZandakaRipository.Update(this.GetBumonKamokuTorihikisakiZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseSegmentKamokuZandakaImmediateUpdate)
            {
                this.segmentKamokuZandakaRipository.Update(this.GetSegmentKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseSegmentKamokuTorihikisakiZandakaImmediateUpdate)
            {
                this.segmentKamokuTorihikisakiZandakaRipository.Update(this.GetSegmentKamokuTorihikisakiZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseUniversal1KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(
                    syoriki.GetUniversalFieldInfo(false, 1),
                    this.GetUniversalField1ZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseUniversal2KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(
                    syoriki.GetUniversalFieldInfo(false, 2),
                    this.GetUniversalField2ZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseUniversal3KamokuZandakaImmediateUpdate)
            {
                this.universalFieldKamokuZandakaRipository.Update(
                    syoriki.GetUniversalFieldInfo(false, 3),
                    this.GetUniversalField3ZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (!useGaika)
            {
                return;
            }

            this.gaikaKamokuZandakaRipository.Update(this.GetGaikaKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));

            if (syoriki.BumonInfo.Use)
            {
                this.gaikaBumonKamokuZandakaRipository.Update(this.GetGaikaBumonKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.EdabanInfo.Use)
            {
                this.kamokuEdabanZandakaRipository.Update(this.GetKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }

            if (syoriki.UseTorihikisakiKamokuZandakaImmediateUpdate)
            {
                this.gaikaTorihikisakiKamokuZandakaRipository.Update(this.GetGaikaTorihikisakiKamokuZandakaTargetUpdateAtUpdateDenpyou(denpyou, denpyouOld));
            }
        }

        /// <summary>
        /// 更新対象科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd">
        /// </param>
        /// <returns></returns>
        private IList<IKamokuZandaka> GetKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => siwake.KarikataKamokuCode)
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => siwake.KasikataKamokuCode)
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var kamokuZandakaList = new List<IKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var kamokuZandaka = new KamokuZandakaWithName(denpyou.Kesn, hassei.key);
                kamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                kamokuZandakaList.Add(kamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var kamokuZandaka = kamokuZandakaList.FirstOrDefault(zandaka => zandaka.Kicd == hassei.key);
                if (kamokuZandaka != null)
                {
                    kamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    kamokuZandaka = new KamokuZandakaWithName(denpyou.Kesn, hassei.key);
                    kamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    kamokuZandakaList.Add(kamokuZandaka);
                }
            }

            return kamokuZandakaList;
        }

        /// <summary>
        /// 更新対象部門科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IBumonKamokuZandaka> GetBumonKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataBumonCode, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataBumonCode, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var bumonKamokuZandakaList = new List<IBumonKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuZandaka = new BumonKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataBumonCode, hassei.key.KarikataKamokuCode);
                bumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                bumonKamokuZandakaList.Add(bumonKamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var bumonKamokuZandaka = bumonKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Bcod == hassei.key.KasikataBumonCode && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (bumonKamokuZandaka != null)
                {
                    bumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    bumonKamokuZandaka = new BumonKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataBumonCode, hassei.key.KasikataKamokuCode);
                    bumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    bumonKamokuZandakaList.Add(bumonKamokuZandaka);
                }
            }

            return bumonKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象取引先科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<ITorihikisakiKamokuZandaka> GetTorihikisakiKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataTorihikisakiCode, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataTorihikisakiCode, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var torihikisakiKamokuZandakaList = new List<ITorihikisakiKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var torihikisakiKamokuZandaka = new TorihikisakiKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataTorihikisakiCode, hassei.key.KarikataKamokuCode);
                torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                torihikisakiKamokuZandakaList.Add(torihikisakiKamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var torihikisakiKamokuZandaka = torihikisakiKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Trcd == hassei.key.KasikataTorihikisakiCode && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (torihikisakiKamokuZandaka != null)
                {
                    torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    torihikisakiKamokuZandaka = new TorihikisakiKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataTorihikisakiCode, hassei.key.KasikataKamokuCode);
                    torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    torihikisakiKamokuZandakaList.Add(torihikisakiKamokuZandaka);
                }
            }

            return torihikisakiKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IKamokuEdabanZandaka> GetKamokuEdabanZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataKamokuCode, siwake.KarikataEdabanCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataKamokuCode, siwake.KasikataEdabanCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var kamokuEdabanZandakaList = new List<IKamokuEdabanZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var kamokuEdabanZandaka = new KamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KarikataKamokuCode, hassei.key.KarikataEdabanCode);
                kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                kamokuEdabanZandakaList.Add(kamokuEdabanZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var kamokuEdabanZandaka = kamokuEdabanZandakaList
                    .FirstOrDefault(zandaka => zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.Ecod == hassei.key.KasikataEdabanCode);
                if (kamokuEdabanZandaka != null)
                {
                    kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    kamokuEdabanZandaka = new KamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KasikataKamokuCode, hassei.key.KasikataEdabanCode);
                    kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    kamokuEdabanZandakaList.Add(kamokuEdabanZandaka);
                }
            }

            return kamokuEdabanZandakaList;
        }

        /// <summary>
        /// 更新対象部門科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IBumonKamokuEdabanZandaka> GetBumonKamokuEdabanZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataBumonCode, siwake.KarikataKamokuCode, siwake.KarikataEdabanCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataBumonCode, siwake.KasikataKamokuCode, siwake.KasikataEdabanCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var bumonKamokuEdabanZandakaList = new List<IBumonKamokuEdabanZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuEdabanZandaka = new BumonKamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KarikataBumonCode, hassei.key.KarikataKamokuCode, hassei.key.KarikataEdabanCode);
                bumonKamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                bumonKamokuEdabanZandakaList.Add(bumonKamokuEdabanZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var bumonKamokuEdabanZandaka = bumonKamokuEdabanZandakaList
                    .FirstOrDefault(zandaka => zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.Ecod == hassei.key.KasikataEdabanCode);
                if (bumonKamokuEdabanZandaka != null)
                {
                    bumonKamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    bumonKamokuEdabanZandaka = new BumonKamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KasikataBumonCode, hassei.key.KasikataKamokuCode, hassei.key.KasikataEdabanCode);
                    bumonKamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    bumonKamokuEdabanZandakaList.Add(bumonKamokuEdabanZandaka);
                }
            }

            return bumonKamokuEdabanZandakaList;
        }

        /// <summary>
        /// 更新対象部門科目取引先残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IBumonKamokuTorihikisakiZandaka> GetBumonKamokuTorihikisakiZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataBumonCode, siwake.KarikataKamokuCode, siwake.KarikataTorihikisakiCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataBumonCode, siwake.KasikataKamokuCode, siwake.KasikataTorihikisakiCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var bumonKamokuTorihikisakiZandakaList = new List<IBumonKamokuTorihikisakiZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = new BumonKamokuTorihikisakiZandakaWithName(denpyou.Kesn, hassei.key.KarikataBumonCode, hassei.key.KarikataKamokuCode, hassei.key.KarikataTorihikisakiCode);
                bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                bumonKamokuTorihikisakiZandakaList.Add(bumonKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = bumonKamokuTorihikisakiZandakaList
                    .FirstOrDefault(zandaka => zandaka.Bcod == hassei.key.KasikataKamokuCode && zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.Trcd == hassei.key.KasikataTorihikisakiCode);
                if (bumonKamokuTorihikisakiZandaka != null)
                {
                    bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    bumonKamokuTorihikisakiZandaka = new BumonKamokuTorihikisakiZandakaWithName(denpyou.Kesn, hassei.key.KasikataBumonCode, hassei.key.KasikataKamokuCode, hassei.key.KasikataTorihikisakiCode);
                    bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    bumonKamokuTorihikisakiZandakaList.Add(bumonKamokuTorihikisakiZandaka);
                }
            }

            return bumonKamokuTorihikisakiZandakaList;
        }

        /// <summary>
        /// 更新対象セグメント科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<ISegmentKamokuZandaka> GetSegmentKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataSegmentCode, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataSegmentCode, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var segmentKamokuZandakaList = new List<ISegmentKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = new SegmentKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataSegmentCode, hassei.key.KarikataKamokuCode);
                bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                segmentKamokuZandakaList.Add(bumonKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var segmentKamokuZandaka = segmentKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Sgcd == hassei.key.KasikataSegmentCode && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (segmentKamokuZandaka != null)
                {
                    segmentKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    segmentKamokuZandaka = new SegmentKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataSegmentCode, hassei.key.KasikataKamokuCode);
                    segmentKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    segmentKamokuZandakaList.Add(segmentKamokuZandaka);
                }
            }

            return segmentKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象セグメント科目取引先残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<ISegmentKamokuTorihikisakiZandaka> GetSegmentKamokuTorihikisakiZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataSegmentCode, siwake.KarikataKamokuCode, siwake.KarikataTorihikisakiCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataSegmentCode, siwake.KasikataKamokuCode, siwake.KasikataTorihikisakiCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var segmentKamokuTorihikisakiZandakaList = new List<ISegmentKamokuTorihikisakiZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var segmentKamokuTorihikisakiZandaka = new SegmentKamokuTorihikisakiZandakaWithName(denpyou.Kesn, hassei.key.KarikataSegmentCode, hassei.key.KarikataKamokuCode, hassei.key.KarikataTorihikisakiCode);
                segmentKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                segmentKamokuTorihikisakiZandakaList.Add(segmentKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var segmentKamokuZandaka = segmentKamokuTorihikisakiZandakaList
                    .FirstOrDefault(zandaka => zandaka.Sgcd == hassei.key.KasikataSegmentCode && zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.Sgcd == hassei.key.KasikataSegmentCode);
                if (segmentKamokuZandaka != null)
                {
                    segmentKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    segmentKamokuZandaka = new SegmentKamokuTorihikisakiZandakaWithName(denpyou.Kesn, hassei.key.KasikataSegmentCode, hassei.key.KasikataKamokuCode, hassei.key.KasikataTorihikisakiCode);
                    segmentKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    segmentKamokuTorihikisakiZandakaList.Add(segmentKamokuZandaka);
                }
            }

            return segmentKamokuTorihikisakiZandakaList;
        }

        /// <summary>
        /// 更新対象ユニバーサルフィールド1科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField1ZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataUniversalField1Code, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataUniversalField1Code, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var universalFieldKamokuZandakaList = new List<IUniversalFieldKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataUniversalField1Code, hassei.key.KarikataKamokuCode);
                bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                universalFieldKamokuZandakaList.Add(bumonKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Code == hassei.key.KasikataUniversalField1Code && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    universalFieldKamokuZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataUniversalField1Code, hassei.key.KasikataKamokuCode);
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    universalFieldKamokuZandakaList.Add(universalFieldKamokuZandaka);
                }
            }

            return universalFieldKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象ユニバーサルフィールド2科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField2ZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataUniversalField2Code, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataUniversalField2Code, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var universalFieldKamokuZandakaList = new List<IUniversalFieldKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataUniversalField2Code, hassei.key.KarikataKamokuCode);
                bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                universalFieldKamokuZandakaList.Add(bumonKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Code == hassei.key.KasikataUniversalField2Code && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    universalFieldKamokuZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataUniversalField2Code, hassei.key.KasikataKamokuCode);
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    universalFieldKamokuZandakaList.Add(universalFieldKamokuZandaka);
                }
            }

            return universalFieldKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象ユニバーサルフィールド3科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField3ZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataUniversalField3Code, siwake.KarikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataUniversalField3Code, siwake.KasikataKamokuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku) });

            var universalFieldKamokuZandakaList = new List<IUniversalFieldKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var bumonKamokuTorihikisakiZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataUniversalField3Code, hassei.key.KarikataKamokuCode);
                bumonKamokuTorihikisakiZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                universalFieldKamokuZandakaList.Add(bumonKamokuTorihikisakiZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Code == hassei.key.KasikataUniversalField3Code && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                }
                else
                {
                    universalFieldKamokuZandaka = new UniversalFieldKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataUniversalField3Code, hassei.key.KasikataKamokuCode);
                    universalFieldKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.kingakuSum, isAdd);
                    universalFieldKamokuZandakaList.Add(universalFieldKamokuZandaka);
                }
            }

            return universalFieldKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象外貨科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd">
        /// </param>
        /// <returns></returns>
        private IList<IGaikaKamokuZandaka> GetGaikaKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataKamokuCode, siwake.KarikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataKamokuCode, siwake.KasikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });

            var gaikaKamokuZandakaList = new List<IGaikaKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var gaikaKamokuZandaka = new GaikaKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataKamokuCode, hassei.key.KarikataHeisyuCode);
                gaikaKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                gaikaKamokuZandakaList.Add(gaikaKamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var gaikaKamokuZandaka = gaikaKamokuZandakaList.FirstOrDefault(zandaka => zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.HeiCd == hassei.key.KasikataHeisyuCode);
                if (gaikaKamokuZandaka != null)
                {
                    gaikaKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                }
                else
                {
                    gaikaKamokuZandaka = new GaikaKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataKamokuCode, hassei.key.KasikataHeisyuCode);
                    gaikaKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                    gaikaKamokuZandakaList.Add(gaikaKamokuZandaka);
                }
            }

            return gaikaKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象外貨部門科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IGaikaBumonKamokuZandaka> GetGaikaBumonKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataBumonCode, siwake.KarikataKamokuCode, siwake.KarikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataBumonCode, siwake.KasikataKamokuCode, siwake.KasikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });

            var gaikaBumonKamokuZandakaList = new List<IGaikaBumonKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var gaikaBumonKamokuZandaka = new GaikaBumonKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataBumonCode, hassei.key.KarikataKamokuCode, hassei.key.KarikataHeisyuCode);
                gaikaBumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                gaikaBumonKamokuZandakaList.Add(gaikaBumonKamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var gaikaBumonKamokuZandaka = gaikaBumonKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Bcod == hassei.key.KasikataBumonCode && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (gaikaBumonKamokuZandaka != null)
                {
                    gaikaBumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                }
                else
                {
                    gaikaBumonKamokuZandaka = new GaikaBumonKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataBumonCode, hassei.key.KasikataKamokuCode, hassei.key.KasikataHeisyuCode);
                    gaikaBumonKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                    gaikaBumonKamokuZandakaList.Add(gaikaBumonKamokuZandaka);
                }
            }

            return gaikaBumonKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象外貨取引先科目残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IGaikaTorihikisakiKamokuZandaka> GetGaikaTorihikisakiKamokuZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataTorihikisakiCode, siwake.KarikataKamokuCode, siwake.KarikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataTorihikisakiCode, siwake.KasikataKamokuCode, siwake.KasikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });

            var torihikisakiKamokuZandakaList = new List<IGaikaTorihikisakiKamokuZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var torihikisakiKamokuZandaka = new GaikaTorihikisakiKamokuZandakaWithName(denpyou.Kesn, hassei.key.KarikataTorihikisakiCode, hassei.key.KarikataKamokuCode, hassei.key.KarikataHeisyuCode);
                torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                torihikisakiKamokuZandakaList.Add(torihikisakiKamokuZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var torihikisakiKamokuZandaka = torihikisakiKamokuZandakaList
                    .FirstOrDefault(zandaka => zandaka.Trcd == hassei.key.KasikataTorihikisakiCode && zandaka.Kicd == hassei.key.KasikataKamokuCode);
                if (torihikisakiKamokuZandaka != null)
                {
                    torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                }
                else
                {
                    torihikisakiKamokuZandaka = new GaikaTorihikisakiKamokuZandakaWithName(denpyou.Kesn, hassei.key.KasikataTorihikisakiCode, hassei.key.KasikataKamokuCode, hassei.key.KasikataHeisyuCode);
                    torihikisakiKamokuZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                    torihikisakiKamokuZandakaList.Add(torihikisakiKamokuZandaka);
                }
            }

            return torihikisakiKamokuZandakaList;
        }

        /// <summary>
        /// 更新対象外貨科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="isAdd"></param>
        /// <returns></returns>
        private IList<IGaikaKamokuEdabanZandaka> GetGaikaKamokuEdabanZandakaTargetUpdate(Denpyou denpyou, bool isAdd)
        {
            var karikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KarikataKamokuCode, siwake.KarikataEdabanCode, siwake.KarikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });
            var kasikataHasseiList = denpyou.SiwakeList.GroupBy(siwake => new { siwake.KasikataKamokuCode, siwake.KasikataEdabanCode, siwake.KasikataHeisyuCode })
                .Select(siwakeGroup => new { key = siwakeGroup.Key, kingakuSum = siwakeGroup.Sum(siwake => siwake.Kingaku), gaikaSum = siwakeGroup.Sum(siwake => siwake.GaikaKingaku) });

            var kamokuEdabanZandakaList = new List<IGaikaKamokuEdabanZandaka>();

            foreach (var hassei in karikataHasseiList)
            {
                var kamokuEdabanZandaka = new GaikaKamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KarikataKamokuCode, hassei.key.KarikataEdabanCode, hassei.key.KarikataHeisyuCode);
                kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Karikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                kamokuEdabanZandakaList.Add(kamokuEdabanZandaka);
            }

            foreach (var hassei in kasikataHasseiList)
            {
                var kamokuEdabanZandaka = kamokuEdabanZandakaList
                    .FirstOrDefault(zandaka => zandaka.Kicd == hassei.key.KasikataKamokuCode && zandaka.Ecod == hassei.key.KasikataEdabanCode);
                if (kamokuEdabanZandaka != null)
                {
                    kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                }
                else
                {
                    kamokuEdabanZandaka = new GaikaKamokuEdabanZandakaWithName(denpyou.Kesn, hassei.key.KasikataKamokuCode, hassei.key.KasikataEdabanCode, hassei.key.KasikataHeisyuCode);
                    kamokuEdabanZandaka.AggregateKingaku(KamokuTaisyakuZokusei.Kasikata, denpyou.Dkei, hassei.gaikaSum, hassei.kingakuSum, isAdd);
                    kamokuEdabanZandakaList.Add(kamokuEdabanZandaka);
                }
            }

            return kamokuEdabanZandakaList;
        }

        /// <summary>
        /// 伝票更新処理用更新対象科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IKamokuZandaka> GetKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var kamokuZandakaListAdd = this.GetKamokuZandakaTargetUpdate(denpyou, true);
            var kamokuZandakaListSub = this.GetKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in kamokuZandakaListSub)
            {
                var kamokuZandaka = kamokuZandakaListAdd.FirstOrDefault(zandakaAdd => zandakaAdd.Kicd == zandakaSub.Kicd);
                if (kamokuZandaka != null)
                {
                    kamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    kamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return kamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象部門科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IBumonKamokuZandaka> GetBumonKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var bumonKamokuZandakaListAdd = this.GetBumonKamokuZandakaTargetUpdate(denpyou, true);
            var bumonKamokuZandakaListSub = this.GetBumonKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in bumonKamokuZandakaListSub)
            {
                var bumonKamokuZandaka = bumonKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Bcod == zandakaSub.Bcod && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (bumonKamokuZandaka != null)
                {
                    bumonKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    bumonKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return bumonKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IKamokuEdabanZandaka> GetKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var kamokuEdabanZandakaListAdd = this.GetKamokuEdabanZandakaTargetUpdate(denpyou, true);
            var kamokuEdabanZandakaListSub = this.GetKamokuEdabanZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in kamokuEdabanZandakaListSub)
            {
                var kamokuEdabanZandaka = kamokuEdabanZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.Ecod == zandakaSub.Ecod);
                if (kamokuEdabanZandaka != null)
                {
                    kamokuEdabanZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    kamokuEdabanZandakaListAdd.Add(zandakaSub);
                }
            }

            return kamokuEdabanZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象取引先科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<ITorihikisakiKamokuZandaka> GetTorihikisakiKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var torihikisakiKamokuZandakaListAdd = this.GetTorihikisakiKamokuZandakaTargetUpdate(denpyou, true);
            var torihikisakiKamokuZandakaListSub = this.GetTorihikisakiKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in torihikisakiKamokuZandakaListSub)
            {
                var torihikisakiKamokuZandaka = torihikisakiKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Trcd == zandakaSub.Trcd && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (torihikisakiKamokuZandaka != null)
                {
                    torihikisakiKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    torihikisakiKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return torihikisakiKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象部門科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IBumonKamokuEdabanZandaka> GetBumonKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var bumonKamokuEdabanZandakaListAdd = this.GetBumonKamokuEdabanZandakaTargetUpdate(denpyou, true);
            var bumonKamokuEdabanZandakaListSub = this.GetBumonKamokuEdabanZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in bumonKamokuEdabanZandakaListSub)
            {
                var bumonKamokuEdabanZandaka = bumonKamokuEdabanZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Bcod == zandakaSub.Bcod && zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.Ecod == zandakaSub.Ecod);
                if (bumonKamokuEdabanZandaka != null)
                {
                    bumonKamokuEdabanZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    bumonKamokuEdabanZandakaListAdd.Add(zandakaSub);
                }
            }

            return bumonKamokuEdabanZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象部門科目取引先残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IBumonKamokuTorihikisakiZandaka> GetBumonKamokuTorihikisakiZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var bumonKamokuTorihikisakiZandakaListAdd = this.GetBumonKamokuTorihikisakiZandakaTargetUpdate(denpyou, true);
            var bumonKamokuTorihikisakiZandakaListSub = this.GetBumonKamokuTorihikisakiZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in bumonKamokuTorihikisakiZandakaListSub)
            {
                var bumonKamokuTorihikisakiZandaka = bumonKamokuTorihikisakiZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Bcod == zandakaSub.Bcod && zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.Trcd == zandakaSub.Trcd);
                if (bumonKamokuTorihikisakiZandaka != null)
                {
                    bumonKamokuTorihikisakiZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    bumonKamokuTorihikisakiZandakaListAdd.Add(zandakaSub);
                }
            }

            return bumonKamokuTorihikisakiZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象セグメント科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<ISegmentKamokuZandaka> GetSegmentKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var segmentKamokuZandakaListAdd = this.GetSegmentKamokuZandakaTargetUpdate(denpyou, true);
            var segmentKamokuZandakaListSub = this.GetSegmentKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in segmentKamokuZandakaListSub)
            {
                var segmentKamokuZandaka = segmentKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Sgcd == zandakaSub.Sgcd && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (segmentKamokuZandaka != null)
                {
                    segmentKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    segmentKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return segmentKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象セグメント科目取引先残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<ISegmentKamokuTorihikisakiZandaka> GetSegmentKamokuTorihikisakiZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var segmentKamokuTorihikisakiZandakaListAdd = this.GetSegmentKamokuTorihikisakiZandakaTargetUpdate(denpyou, true);
            var segmentKamokuTorihikisakiZandakaListSub = this.GetSegmentKamokuTorihikisakiZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in segmentKamokuTorihikisakiZandakaListSub)
            {
                var segmentKamokuTorihikisakiZandaka = segmentKamokuTorihikisakiZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Sgcd == zandakaSub.Sgcd && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (segmentKamokuTorihikisakiZandaka != null)
                {
                    segmentKamokuTorihikisakiZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    segmentKamokuTorihikisakiZandakaListAdd.Add(zandakaSub);
                }
            }

            return segmentKamokuTorihikisakiZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象ユニバーサルフィールド1科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField1ZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var universalFieldKamokuZandakaListAdd = this.GetUniversalField1ZandakaTargetUpdate(denpyou, true);
            var universalFieldKamokuZandakaListSub = this.GetUniversalField1ZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in universalFieldKamokuZandakaListSub)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Code == zandakaSub.Code && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    universalFieldKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return universalFieldKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象ユニバーサルフィールド2科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField2ZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var universalFieldKamokuZandakaListAdd = this.GetUniversalField2ZandakaTargetUpdate(denpyou, true);
            var universalFieldKamokuZandakaListSub = this.GetUniversalField2ZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in universalFieldKamokuZandakaListSub)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Code == zandakaSub.Code && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    universalFieldKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return universalFieldKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象ユニバーサルフィールド3科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IUniversalFieldKamokuZandaka> GetUniversalField3ZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var universalFieldKamokuZandakaListAdd = this.GetUniversalField3ZandakaTargetUpdate(denpyou, true);
            var universalFieldKamokuZandakaListSub = this.GetUniversalField3ZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in universalFieldKamokuZandakaListSub)
            {
                var universalFieldKamokuZandaka = universalFieldKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Code == zandakaSub.Code && zandakaAdd.Kicd == zandakaSub.Kicd);
                if (universalFieldKamokuZandaka != null)
                {
                    universalFieldKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    universalFieldKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return universalFieldKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象外貨科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IGaikaKamokuZandaka> GetGaikaKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var gaikaKamokuZandakaListAdd = this.GetGaikaKamokuZandakaTargetUpdate(denpyou, true);
            var gaikaKamokuZandakaListSub = this.GetGaikaKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in gaikaKamokuZandakaListSub)
            {
                var kamokuZandaka = gaikaKamokuZandakaListAdd.FirstOrDefault(zandakaAdd => zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.HeiCd == zandakaSub.HeiCd);
                if (kamokuZandaka != null)
                {
                    kamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    gaikaKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return gaikaKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象外貨部門科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IGaikaBumonKamokuZandaka> GetGaikaBumonKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var gaikaBumonKamokuZandakaListAdd = this.GetGaikaBumonKamokuZandakaTargetUpdate(denpyou, true);
            var gaikaBumonKamokuZandakaListSub = this.GetGaikaBumonKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in gaikaBumonKamokuZandakaListSub)
            {
                var gaikaBumonKamokuZandaka = gaikaBumonKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Bcod == zandakaSub.Bcod && zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.HeiCd == zandakaSub.HeiCd);
                if (gaikaBumonKamokuZandaka != null)
                {
                    gaikaBumonKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    gaikaBumonKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return gaikaBumonKamokuZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象外貨科目枝番残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IGaikaKamokuEdabanZandaka> GetGaikaKamokuEdabanZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var gaikaKamokuEdabanZandakaListAdd = this.GetGaikaKamokuEdabanZandakaTargetUpdate(denpyou, true);
            var gaikaKamokuEdabanZandakaListSub = this.GetGaikaKamokuEdabanZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in gaikaKamokuEdabanZandakaListSub)
            {
                var gaikaKamokuEdabanZandaka = gaikaKamokuEdabanZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.HeiCd == zandakaSub.HeiCd && zandakaAdd.Ecod == zandakaSub.Ecod);
                if (gaikaKamokuEdabanZandaka != null)
                {
                    gaikaKamokuEdabanZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    gaikaKamokuEdabanZandakaListAdd.Add(zandakaSub);
                }
            }

            return gaikaKamokuEdabanZandakaListAdd;
        }

        /// <summary>
        /// 伝票更新処理用更新対象外貨取引先科目残高を取得
        /// </summary>
        /// <param name="denpyou">更新対象伝票</param>
        /// <param name="denpyouOld">更新前伝票</param>
        /// <returns></returns>
        private IList<IGaikaTorihikisakiKamokuZandaka> GetGaikaTorihikisakiKamokuZandakaTargetUpdateAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld)
        {
            var gaikaTorihikisakiKamokuZandakaListAdd = this.GetGaikaTorihikisakiKamokuZandakaTargetUpdate(denpyou, true);
            var gaikaTorihikisakiKamokuZandakaListSub = this.GetGaikaTorihikisakiKamokuZandakaTargetUpdate(denpyouOld, false);
            foreach (var zandakaSub in gaikaTorihikisakiKamokuZandakaListSub)
            {
                var torihikisakiKamokuZandaka = gaikaTorihikisakiKamokuZandakaListAdd.FirstOrDefault(
                    zandakaAdd => zandakaAdd.Trcd == zandakaSub.Trcd && zandakaAdd.Kicd == zandakaSub.Kicd && zandakaAdd.HeiCd == zandakaSub.HeiCd);
                if (torihikisakiKamokuZandaka != null)
                {
                    torihikisakiKamokuZandaka.AddKingakuAllKeikazuki(zandakaSub);
                }
                else
                {
                    gaikaTorihikisakiKamokuZandakaListAdd.Add(zandakaSub);
                }
            }

            return gaikaTorihikisakiKamokuZandakaListAdd;
        }
    }
}
