﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;

    [Service(ServiceType.DomainService)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TimeStampService : ITimeStampService
    {
        [AutoInjection]
        private IEdocumentFileRepository edocumentFileRepository = null;

        public bool CopyFileOrSetTimeStamp(Denpyou denpyou, string ccod, Func<TimeStampProcessResult, bool> errorHanding) =>
            this.edocumentFileRepository.CopyFileOrSetTimeStamp(ccod, this.GetTimeStampTarget(denpyou), errorHanding);

        private IList<Edocument> GetTimeStampTarget(Denpyou denpyou)
        {
            var timeStampTarget = new List<Edocument>();
            foreach (var linkInfomation in denpyou.LinkInfomationList.Where(linkInfomation => !string.IsNullOrEmpty(linkInfomation.Edoc)))
            {
                if (linkInfomation.Edocument.NeedTimeStamp)
                {
                    timeStampTarget.Add(linkInfomation.Edocument);
                }
            }

            return timeStampTarget;
        }
    }
}
