﻿using Icsp.Open21.Domain.KaisyaModel;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IDenpyouZandakaUpdateService
    {
        void UpdateZandakaAtInsertDenpyouAndDenpyouTorikesi(Denpyou denpyou, DenpyouType denpyouType, Syoriki syoriki, bool isTorikesi, bool isZandakaUpdate, bool useGaika);

        void UpdateZandakaAtUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld, DenpyouType denpyouType, Syoriki syoriki, bool isZandakaUpdate, bool useGaika);
    }
}