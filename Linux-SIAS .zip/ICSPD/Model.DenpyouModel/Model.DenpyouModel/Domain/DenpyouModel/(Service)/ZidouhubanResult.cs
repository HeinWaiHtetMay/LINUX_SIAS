﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class ZidouhubanResult
    {
        public ZidouhubanResult() => this.ErrorDenpyouType = null;

        public ZidouhubanResult(DenpyouType? errorDenpyouType) => this.ErrorDenpyouType = errorDenpyouType;

        public bool HasError => this.ErrorDenpyouType != null;

        public DenpyouType? ErrorDenpyouType { get; set; }
    }
}
