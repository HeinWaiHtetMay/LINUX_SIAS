﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

    [Serializable]
    public class Edocument : ICreatedAndLastUpdatedYmdHmsEntity
    {
        internal Edocument(int kesn, string edoc)
        {
            this.Kesn = kesn;
            this.Edoc = edoc;
        }

        internal Edocument(int kesn, string edoc, int nyuuryokusyaCode)
        {
            this.Kesn = kesn;
            this.Edoc = edoc;
            this.Fusr = nyuuryokusyaCode;
            this.IsNew = true;
        }

        #region public properties

        public bool IsNew { get; private set; }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// e文書番号（カラム名：edoc）
        /// </summary>
        public string Edoc { get; private set; }

        /// <summary>
        /// 申請者名称（カラム名：nusr）
        /// </summary>
        public string Nusr { get; set; }

        /// <summary>
        /// 最終承認者名称（カラム名：susr）
        /// </summary>
        public string Susr { get; set; }

        /// <summary>
        /// コメント（カラム名：cmt）
        /// </summary>
        public string Cmt { get; set; }

        /// <summary>
        /// タイムスタンプ付与対象か（カラム名：tsfuyo）
        /// </summary>
        public bool NeedTimeStamp { get; internal set; }

        /// <summary>
        /// 新規作成者（カラム名：fusr）
        /// </summary>
        public int Fusr { get; set; }

        /// <summary>
        /// 新規作成年月日（カラム名：fmod）
        /// </summary>
        public int Fmod { get; set; }

        /// <summary>
        /// 新規作成時間（カラム名：ftim）
        /// </summary>
        public int Ftim { get; set; }

        /// <summary>
        /// 最終更新者（カラム名：lusr）
        /// </summary>
        public int Lusr { get; set; }

        /// <summary>
        /// 最終更新年月日（カラム名：lmod）
        /// </summary>
        public int Lmod { get; set; }

        /// <summary>
        /// 最終更新時間（カラム名：ltim）
        /// </summary>
        public int Ltim { get; set; }

        /// <summary>
        /// e文書検索項目（テーブル名：EDOCSRCH）
        /// </summary>
        public IList<EdocumentSearchItem> EdocumentSearchItemList { get; set; } = new List<EdocumentSearchItem>();

        #region implements ICreatedAndLastUpdatedYmdHmsEntity
        public int CreatedYmd { get => this.Fmod; set => this.Fmod = value; }

        public int CreatedHms { get => this.Ftim; set => this.Ftim = value; }

        public int LastUpdatedYmd { get => this.Lmod; set => this.Lmod = value; }

        public int LastUpdatedHms { get => this.Ltim; set => this.Ltim = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Second;
        #endregion

        #endregion

        #region public methods

        /// <summary>
        /// タイムスタンプ付与設定を設定
        /// </summary>
        /// <param name="timeStampSetting"></param>
        /// <param name="oldEdocument"></param>
        public void SetNeedTimeStamp(TimeStampSetting timeStampSetting, Edocument oldEdocument)
        {
            var edocumentTypeList = this.EdocumentSearchItemList
                .Select(edocumentSerchItem => edocumentSerchItem.EdocumentType).ToList();
            var oldEdocumentTypeList = oldEdocument?.EdocumentSearchItemList
                .Select(edocumentSerchItem => edocumentSerchItem.EdocumentType).ToList();

            var date = new IcspDateTime(this.Lmod, 0);

            if (oldEdocumentTypeList != null)
            {
                // 登録済みの書類種別をチェック対象から除く
                foreach (var oldEdocumentType in oldEdocumentTypeList)
                {
                    edocumentTypeList.RemoveAll(edocumentType => edocumentType == oldEdocumentType);
                }
            }

            // 1件でもタイムスタンプ付与する設定の場合は付与する
            foreach (var edocumentType in edocumentTypeList)
            {
                if (this.NeedTimeStamp = edocumentType.NeedTimeStamp(timeStampSetting, date))
                {
                    return;
                }
            }
        }

        /// <summary>
        /// 変更が加えられているかチェック
        /// </summary>
        /// <param name="oldEdocument"></param>
        /// <returns></returns>
        public bool HasChanged(Edocument oldEdocument)
        {
            if (oldEdocument == null
                || this.Kesn != oldEdocument.Kesn
                || this.Edoc != oldEdocument.Edoc
                || this.Nusr != oldEdocument.Nusr
                || this.Susr != oldEdocument.Susr
                || this.Cmt != oldEdocument.Cmt
                || this.NeedTimeStamp != oldEdocument.NeedTimeStamp
                || this.Fusr != oldEdocument.Fusr
                || this.Fmod != oldEdocument.Fmod
                || this.Ftim != oldEdocument.Ftim
                || this.Lusr != oldEdocument.Lusr
                || this.Lmod != oldEdocument.Lmod
                || this.Ltim != oldEdocument.Ltim
                || this.EdocumentSearchItemList.Count != oldEdocument.EdocumentSearchItemList.Count)
            {
                return true;
            }

            for (int index = 0; index < this.EdocumentSearchItemList.Count; index++)
            {
                if (this.EdocumentSearchItemList[index].HasChanged(this.EdocumentSearchItemList[index]))
                {
                    return true;
                }
            }

            return false;
        }

        #endregion
    }
}
