﻿//using EDOCUMENTLIB;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public class TimeStampProcessResult
    {
        private static readonly int TimeStampErrorCode = 4500;
        private static readonly string NotExistsTimeStampErrorCode = "3200";

        //e文書についてコメントする【.NetStandard2.1へ移行】
        //public TimeStampProcessResult(ProcessResult processResult) => this.ProcessResult = processResult;

        //public ProcessResult ProcessResult { get; private set; }

        //public bool HasError => this.ProcessResult.ExitCode != 0;

        //public bool HasErrorCode => this.ProcessResult.ExitCode == TimeStampErrorCode;

        //public bool NotExistsTimeStamp => this.ProcessResult.OutputError.IndexOf(NotExistsTimeStampErrorCode) >= 0;

        //public string ExitCodeAndErrorCodeString => this.HasErrorCode
        //    ? this.ProcessResult.ExitCode.ToString() + "-" + this.ProcessResult.OutputError
        //    : this.ProcessResult.ExitCode.ToString();
    }
}
