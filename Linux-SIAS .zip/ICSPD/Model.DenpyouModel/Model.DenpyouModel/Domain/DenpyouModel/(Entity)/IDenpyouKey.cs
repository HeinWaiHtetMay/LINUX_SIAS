﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IDenpyouKey
    {
        /// <summary>
        /// 経過月
        /// </summary>
        int Dkei { get; }

        /// <summary>
        /// 伝票SEQNo.
        /// </summary>
        int DenpyouSequenceNumber { get; }
    }
}
