﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Serialization;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KesikomiModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    [Serializable]
    public class Denpyou : ICreatedAndLastUpdatedYmdHmsEntity, IDenpyouKey
    {
        internal Denpyou()
        {
            this.DenpyouTabaLink = null;
            this.LinkInfomationList = new List<LinkInfomation>();
            this.SiwakeList = new List<Siwake>();
        }

        /// <summary>
        /// 新規伝票
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="nyuuryokusyaCode"></param>
        /// <param name="nyuuryokuSyudan"></param>
        internal Denpyou(int kesn, int dkei, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan)
            : this()
        {
            this.IsNew = true;

            this.Kesn = kesn;
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = 0;

            this.DenpyouSakuseisyaCode = nyuuryokusyaCode;
            this.DenpyouSakuseiHouhou = nyuuryokuSyudan;
            this.DenpyouKousinsyaCode = nyuuryokusyaCode;
            this.DenpyouKousinHouhou = nyuuryokuSyudan;
        }

        /// <summary>
        /// 既存伝票
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        internal Denpyou(int kesn, int dkei, int dseq)
            : this()
        {
            this.IsNew = false;

            this.Kesn = kesn;
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = dseq;
        }

        #region public properties

        /// <summary>
        /// 新規
        /// </summary>
        public bool IsNew { get; set; }

        /// <summary>
        /// 整理月フラグ
        /// </summary>
        public bool Seirituki { get; set; }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; protected set; }

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei { get; protected set; }

        /// <summary>
        /// 伝票seqno.（カラム名：dseq）
        /// </summary>
        public int DenpyouSequenceNumber { get; protected set; }

        /// <summary>
        /// 伝票日付（カラム名：dymd）
        /// </summary>
        public int DenpyouHizuke { get; set; }

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        public int? DenpyouNo { get; set; }

        /// <summary>
        /// 複合ﾌﾗｸﾞ（カラム名：dfuk）
        /// </summary>
        public DenpyouKeisiki DenpyouKeisiki { get; set; }

        /// <summary>
        /// 入力パターン（カラム名：ijpt）
        /// </summary>
        public int DenpyouInputPatternNumber { get; set; }

        /// <summary>
        /// 起票年月日（カラム名：kymd）
        /// </summary>
        public int Kihyoubi { get; set; }

        /// <summary>
        /// 起票部門（カラム名：kbmn）
        /// </summary>
        public string KihyouBumonCode { get; set; }

        /// <summary>
        /// 起票者（カラム名：kusr）
        /// </summary>
        public string KihyousyaCode { get; set; }

        /// <summary>
        /// 入力年月日（カラム名：fmod）
        /// </summary>
        public int DenpyouSakuseibi { get; set; }

        /// <summary>
        /// 入力時分秒（カラム名：ftim）
        /// </summary>
        public int DenpyouSakuseiZikan { get; set; }

        /// <summary>
        /// 入力者（カラム名：fusr）
        /// </summary>
        public int DenpyouSakuseisyaCode { get; set; }

        /// <summary>
        /// 入力手段（カラム名：fway）
        /// </summary>
        public DenpyouSiwakeWayToCreate DenpyouSakuseiHouhou { get; set; }

        /// <summary>
        /// 最終変更年月日（カラム名：lmod）
        /// </summary>
        public int DenpyouKousinbi { get; set; }

        /// <summary>
        /// 最終変更時分秒（カラム名：ltim）
        /// </summary>
        public int DenpyouKousinZikan { get; set; }

        /// <summary>
        /// 最終変更者（カラム名：lusr）
        /// </summary>
        public int DenpyouKousinsyaCode { get; set; }

        /// <summary>
        /// 最終変更手段（カラム名：lway）
        /// </summary>
        public DenpyouSiwakeWayToCreate DenpyouKousinHouhou { get; set; }

        /// <summary>
        /// 削除ﾌﾗｸﾞ（カラム名：Delf）
        /// </summary>
        public bool IsTorikesi { get; set; }

        /// <summary>
        /// 出力ﾌﾗｸﾞ（カラム名：cprt）
        /// </summary>
        public bool IsPrintedChecklist { get; set; }

        /// <summary>
        /// 伝票発行済sw（カラム名：dprt）
        /// </summary>
        public PrintedFlag HurikaeDenpyouPrintedFlag { get; set; }

        /// <summary>
        /// 受付番号（カラム名：duno）
        /// </summary>
        public int UketukeNo { get; set; }

        /// <summary>
        /// 入力確定日（カラム名：kday）
        /// </summary>
        public int NyuuryokuKakuteibi { get; set; }

        /// <summary>
        /// 承認前伝票発行sw（カラム名：fprt）
        /// </summary>
        public PrintedFlag PrintedDenpyouBeforeSyounin { get; set; }

        /// <summary>
        /// 承認ｸﾞﾙｰﾌﾟno（カラム名：sgno）
        /// </summary>
        public int SyouninGroupNumber { get; set; }

        /// <summary>
        /// 判定済最上位承認者順序（カラム名：hjno）
        /// </summary>
        public int HanteizumiSaizyouiSyouninsyaZyunzyo { get; set; }

        /// <summary>
        /// 承認状況（カラム名：sflg）
        /// </summary>
        public SyouninStatus SyouninZyoukyou { get; set; }

        /// <summary>
        /// 承認者編集（カラム名：smnt）
        /// </summary>
        public bool IsSyouninUserUpdate { get; set; }

        /// <summary>
        /// 第一承認者（カラム名：sn01）
        /// 第一承認者が存在しない場合は0
        /// </summary>
        public int Dai1SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第一承認判定（カラム名：sf01）
        /// </summary>
        public SyouninStatus Dai1SyouninStatus { get; set; }

        /// <summary>
        /// 第二承認者（カラム名：sn02）
        /// 第二承認者が存在しない場合は0
        /// </summary>
        public int Dai2SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第二承認判定（カラム名：sf02）
        /// </summary>
        public SyouninStatus Dai2SyouninStatus { get; set; }

        /// <summary>
        /// 第三承認者（カラム名：sn03）
        /// 第三承認者が存在しない場合は0
        /// </summary>
        public int Dai3SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第三承認判定（カラム名：sf03）
        /// </summary>
        public SyouninStatus Dai3SyouninStatus { get; set; }

        /// <summary>
        /// 第四承認者（カラム名：sn04）
        /// 第四承認者が存在しない場合は0
        /// </summary>
        public int Dai4SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第四承認判定（カラム名：sf04）
        /// </summary>
        public SyouninStatus Dai4SyouninStatus { get; set; }

        /// <summary>
        /// 第五承認者（カラム名：sn05）
        /// 第五承認者が存在しない場合は0
        /// </summary>
        public int Dai5SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第五承認判定（カラム名：sf05）
        /// </summary>
        public SyouninStatus Dai5SyouninStatus { get; set; }

        /// <summary>
        /// 第六承認者（カラム名：sn06）
        /// 第六承認者が存在しない場合は0
        /// </summary>
        public int Dai6SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第六承認判定（カラム名：sf06）
        /// </summary>
        public SyouninStatus Dai6SyouninStatus { get; set; }

        /// <summary>
        /// 第七承認者（カラム名：sn07）
        /// 第七承認者が存在しない場合は0
        /// </summary>
        public int Dai7SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第七承認判定（カラム名：sf07）
        /// </summary>
        public SyouninStatus Dai7SyouninStatus { get; set; }

        /// <summary>
        /// 第八承認者（カラム名：sn08）
        /// 第八承認者が存在しない場合は0
        /// </summary>
        public int Dai8SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第八承認判定（カラム名：sf08）
        /// </summary>
        public SyouninStatus Dai8SyouninStatus { get; set; }

        /// <summary>
        /// 第九承認者（カラム名：sn09）
        /// 第九承認者が存在しない場合は0
        /// </summary>
        public int Dai9SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第九承認判定（カラム名：sf09）
        /// </summary>
        public SyouninStatus Dai9SyouninStatus { get; set; }

        /// <summary>
        /// 第十承認者（カラム名：sn10）
        /// 第十承認者が存在しない場合は0
        /// </summary>
        public int Dai10SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第十承認判定（カラム名：sf10）
        /// </summary>
        public SyouninStatus Dai10SyouninStatus { get; set; }

        /// <summary>
        /// 履歴番号（カラム名：idm1）
        /// </summary>
        public int RirekiNumber { get; set; }

        /// <summary>
        /// 履歴伝票seqno.（カラム名：idm2）
        /// </summary>
        public int RirekiDenpyouSequence { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ1（カラム名：duf1）
        /// </summary>
        public string HeaderField1Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ2（カラム名：duf2）
        /// </summary>
        public string HeaderField2Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ3（カラム名：duf3）
        /// </summary>
        public string HeaderField3Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ4（カラム名：duf4）
        /// </summary>
        public string HeaderField4Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ5（カラム名：duf5）
        /// </summary>
        public string HeaderField5Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ6（カラム名：duf6）
        /// </summary>
        public string HeaderField6Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ7（カラム名：duf7）
        /// </summary>
        public string HeaderField7Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ8（カラム名：duf8）
        /// </summary>
        public string HeaderField8Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ9（カラム名：duf9）
        /// </summary>
        public string HeaderField9Code { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ10（カラム名：duf10）
        /// </summary>
        public string HeaderField10Code { get; set; }

        /// <summary>
        /// 未完伝票ﾌﾗｸﾞ（カラム名：bflg）
        /// </summary>
        public bool IsMikanDenpyou { get; set; }

        /// <summary>
        /// 伝票状態フラグ（カラム名：hsflg）
        /// </summary>
        public DenpyouUpdateStatusFlag DenpyouUpdateStatusFlag { get; set; }

        /// <summary>
        /// 行変更仕訳存在フラグ（カラム名：hgflg）
        /// </summary>
        public bool IsUpdatedLine { get; set; }

        /// <summary>
        /// 伝票束リンク
        /// </summary>
        public DenpyouTabaLink DenpyouTabaLink { get; set; }

        /// <summary>
        /// リンク情報
        /// </summary>
        public IList<LinkInfomation> LinkInfomationList { get; set; }

        public IList<Siwake> SiwakeList { get; set; }

        #region implements ICreatedAndLastUpdatedYmdHmsEntity
        public int CreatedYmd { get => this.DenpyouSakuseibi; set => this.DenpyouSakuseibi = value; }

        public int CreatedHms { get => this.DenpyouSakuseiZikan; set => this.DenpyouSakuseiZikan = value; }

        public int LastUpdatedYmd { get => this.DenpyouKousinbi; set => this.DenpyouKousinbi = value; }

        public int LastUpdatedHms { get => this.DenpyouKousinZikan; set => this.DenpyouKousinZikan = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Centisecond;
        #endregion

        #endregion

        #region public Methods

        /// <summary>
        /// 伝票を複製
        /// </summary>
        /// <returns></returns>
        public Denpyou CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);

        public Denpyou SetDkei(int dkei)
        {
            this.Dkei = dkei;
            return this;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        public bool HasChanged(Denpyou denpyou)
        {
            if (this.DenpyouHizuke != denpyou.DenpyouHizuke
                || this.DenpyouNo != denpyou.DenpyouNo
                || this.Kihyoubi != denpyou.Kihyoubi
                || this.KihyouBumonCode != denpyou.KihyouBumonCode
                || this.KihyousyaCode != denpyou.KihyousyaCode
                || this.UketukeNo != denpyou.UketukeNo
                || this.NyuuryokuKakuteibi != denpyou.NyuuryokuKakuteibi
                || this.SyouninGroupNumber != denpyou.SyouninGroupNumber
                || this.HeaderField1Code != denpyou.HeaderField1Code
                || this.HeaderField2Code != denpyou.HeaderField2Code
                || this.HeaderField3Code != denpyou.HeaderField3Code
                || this.HeaderField4Code != denpyou.HeaderField4Code
                || this.HeaderField5Code != denpyou.HeaderField5Code
                || this.HeaderField6Code != denpyou.HeaderField6Code
                || this.HeaderField7Code != denpyou.HeaderField7Code
                || this.HeaderField8Code != denpyou.HeaderField8Code
                || this.HeaderField9Code != denpyou.HeaderField9Code
                || this.HeaderField10Code != denpyou.HeaderField10Code
                || this.SiwakeChangedExists(denpyou)
                || this.LinkInfomationChangedExists(denpyou)
                || (this.DenpyouTabaLink == null && denpyou.DenpyouTabaLink != null)
                || (this.DenpyouTabaLink != null && this.DenpyouTabaLink.HasChanged(denpyou.DenpyouTabaLink)))
            {
                return true;
            }

            return false;
        }

        public bool LinkInfomationChangedExists(Denpyou oldDenpyou)
        {
            if (this.LinkInfomationList.Count != oldDenpyou.LinkInfomationList.Count)
            {
                return true;
            }

            for (int index = 0; index < this.LinkInfomationList.Count; index++)
            {
                if (!this.LinkInfomationList[index].HasChanged(oldDenpyou.LinkInfomationList[index]))
                {
                    return true;
                }
            }

            return false;
        }

        public void AddEmptySiwake(int userCode, DenpyouSiwakeWayToCreate createWay)
        {
            var newSiwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, userCode, createWay);
            newSiwake.LineNo = this.SiwakeList.Count > 0 ? this.SiwakeList.Max(siwake => siwake.LineNo) + 1 : 1;
            this.SiwakeList.Add(newSiwake);
        }

        public void AddKizonSiwake(Siwake kizonSiwake)
        {
            this.SiwakeList.Add(kizonSiwake);
        }

        public void InsertEmptySiwake(int index, int userCode, DenpyouSiwakeWayToCreate createWay)
        {
            this.SiwakeList.Insert(index, new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, userCode, createWay));
        }

        public void InsertKizonSiwake(int index, Siwake kizonSiwake)
        {
            this.SiwakeList.Insert(index, kizonSiwake);
        }

        /// <summary>
        /// 処理期と経過月をセット
        /// </summary>
        /// <param name="syorikikan"></param>
        /// <returns></returns>
        public Denpyou SetSyorikiAndSyorituki(IKaisyaSyoriKikan syorikikan)
        {
            this.Kesn = syorikikan.Syoriki.Kesn;
            foreach (var syorituki in syorikikan.Syoriki.SyoritukiList)
            {
                if (!syorituki.IsKisyu && syorituki.StartDate.Ymd <= this.DenpyouHizuke && this.DenpyouHizuke <= syorituki.EndDate.Ymd)
                {
                    // 整理月
                    if (!this.Seirituki || syorituki.Ckei == 35 || syorituki.Ckei == 65 || syorituki.Ckei == 95 || syorituki.Ckei == 125)
                    {
                        this.Dkei = syorituki.Ckei;
                        break;
                    }
                }
            }

            return this;
        }

        /// <summary>
        /// 登録対象外仕訳を取り除く
        /// </summary>
        /// <returns></returns>
        public Denpyou RemoveEmptySiwake()
        {
            IList<Siwake> siwakeList = new List<Siwake>();
            siwakeList.AddRangeIfNotNull(this.SiwakeList.Where(siwake => !string.IsNullOrEmpty(siwake.KarikataKamokuCode) || !string.IsNullOrEmpty(siwake.KasikataKamokuCode) || siwake.Kingaku != 0));
            this.SiwakeList = siwakeList;
            return this;
        }

        public int GetSiwakeCount() => this.SiwakeList.Count;

        public decimal GetTaisyakuSagaku() =>
            this.SiwakeList.Where(siwake => siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata).Sum(siwake => siwake.Kingaku) -
            this.SiwakeList.Where(siwake => siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata).Sum(siwake => siwake.Kingaku);

        public decimal GetTaisyakuSyokutiSagaku() =>
            this.SiwakeList.Where(siwake => (siwake.KarikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd
                || siwake.KarikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd)
                && siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata).Sum(siwake => siwake.Kingaku) -
            this.SiwakeList.Where(siwake => (siwake.KasikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd
                || siwake.KasikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd)
                && siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata).Sum(siwake => siwake.Kingaku);

        public Siwake GetSiwake(int index) => this.SiwakeList[index];

        public int GetSiwakeIndex(Siwake siwake) => this.SiwakeList.IndexOf(siwake);

        /// <summary>
        /// 貸借ともに分離区分が指定されている仕訳を2仕訳に変換
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="meisaiKamokuList"></param>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <returns></returns>
        public Denpyou ConvertTaisyakuBunriSiwakeTo2Siwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList)
        {
            var siwakeList = new List<Siwake>();
            this.SiwakeList.ForEachIfNotNull(siwake =>
            {
                if (siwake.ShouldCreateTwoSiwake(syouhizeiMaster))
                {
                    siwakeList.AddRange(siwake.CreateKarikataSiwakeAndKasikataSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList));
                }
                else
                {
                    siwakeList.Add(siwake);
                }
            });
            this.SiwakeList = siwakeList;
            return this;
        }

        /// <summary>
        /// 伝票登録時、作成日時と最終更新日時を更新する対象を取得
        /// 分離子仕訳作成後に実行する必要有
        /// </summary>
        /// <returns></returns>
        public IList<ICreatedAndLastUpdatedYmdHmsEntity> GetUpdateTargetCreatedAndLastUpdatedDateTime()
        {
            var updateTargetList = new List<ICreatedAndLastUpdatedYmdHmsEntity>();

            if (this.IsNew)
            {
                updateTargetList.Add(this);
            }

            updateTargetList.AddRange(this.SiwakeList.Where(siwake => siwake.IsNew));
            foreach (var linkInfomation in this.LinkInfomationList)
            {
                if (linkInfomation.IsNew)
                {
                    updateTargetList.Add(linkInfomation);
                }

                if (linkInfomation.Edocument?.IsNew ?? false)
                {
                    updateTargetList.Add(linkInfomation.Edocument);
                }
            }

            updateTargetList.AddRange(this.GetSyouninCommentUpdateTargetCreatedDateTime());
            return updateTargetList;
        }

        /// <summary>
        /// 伝票更新時、最終更新日時を更新する対象を取得
        /// </summary>
        /// <returns></returns>
        public IList<ICreatedAndLastUpdatedYmdHmsEntity> GetUpdateTargetLastUpdatedDateTimeAtDenpyouUpdate()
        {
            var updateTargetList = new List<ICreatedAndLastUpdatedYmdHmsEntity>();

            if (!this.IsNew)
            {
                updateTargetList.Add(this);
            }

            updateTargetList.AddRange(this.SiwakeList.Where(siwake => !siwake.IsNew).ToList());
            foreach (var linkInfomation in this.LinkInfomationList)
            {
                if (!linkInfomation.IsNew)
                {
                    updateTargetList.Add(linkInfomation);
                }

                if (!linkInfomation.Edocument?.IsNew ?? false)
                {
                    updateTargetList.Add(linkInfomation.Edocument);
                }
            }

            // 上記以外については作成日時の更新も必要
            return updateTargetList;
        }

        /// <summary>
        /// 伝票取消時、最終更新日時を更新する対象を取得
        /// </summary>
        /// <returns></returns>
        public IList<ICreatedAndLastUpdatedYmdHmsEntity> GetUpdateTargetLastUpdatedDateTimeAtDenpyouCancel()
        {
            var updateTargetList = new List<ICreatedAndLastUpdatedYmdHmsEntity>();

            // 伝票取消の場合、伝票、仕訳に関しては全件更新対象
            updateTargetList.Add(this);
            updateTargetList.AddRange(this.SiwakeList);

            // 上記以外についてはレコードが削除されるため更新の必要なし
            return updateTargetList;
        }

        /// <summary>
        /// 各月情報の最終伝票SEQを伝票にセット
        /// </summary>
        /// <param name="saisyuuDenpyouSequence"></param>
        public void SetDseq(int saisyuuDenpyouSequence) => this.DenpyouSequenceNumber = saisyuuDenpyouSequence;

        /// <summary>
        /// 全リンク情報に伝票の経過月をセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetDkeiToLinkInfomation()
        {
            this.LinkInfomationList.ForEachIfNotNull(linkInfomation => linkInfomation.SetDkei(this.Dkei));
            return this;
        }

        /// <summary>
        /// 全リンク情報に伝票のDseqをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetDseqToLinkInfomation()
        {
            this.LinkInfomationList.ForEachIfNotNull(linkInfomation => linkInfomation.SetDseq(this.DenpyouSequenceNumber));
            return this;
        }

        /// <summary>
        /// 伝票内の全仕訳に伝票の経過月をセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetDkeiToSiwake()
        {
            this.SiwakeList.ForEachIfNotNull(siwake => siwake.SetDkei(this.Dkei));
            return this;
        }

        /// <summary>
        /// 伝票内の全仕訳に伝票のDseqをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetDseqToSiwake()
        {
            this.SiwakeList.ForEachIfNotNull(siwake => siwake.SetDseq(this.DenpyouSequenceNumber));
            return this;
        }

        /// <summary>
        /// 伝票内の全仕訳にグループ番号を付番
        /// </summary>
        /// <returns></returns>
        public Denpyou NumberGroupNumber()
        {
            Siwake previousSiwake = null;
            this.SiwakeList.Where(siwake => !siwake.IsTorikesi).ForEachIfNotNull(siwake =>
            {
                previousSiwake = siwake.SetGroupNumber(previousSiwake);
            });
            return this;
        }

        /// <summary>
        /// 伝票に分離子仕訳を追加
        /// </summary>
        /// <param name="syohizeiMaster"></param>
        /// <param name="meisaiKamokuList"></param>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public Denpyou AddChildSiwake(SyouhizeiMaster syohizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, Syoriki syoriki)
        {
            var newSiwakeList = new List<Siwake>();
            foreach (var siwake in this.SiwakeList.Where(siwake => !siwake.IsTorikesi))
            {
                // 親→子の順番でシーケンスを付番するために親→子の順に追加
                newSiwakeList.Add(siwake);
                var childSiwake = siwake.CreateChildSiwake(syohizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList, syoriki);
                if (childSiwake != null)
                {
                    newSiwakeList.Add(childSiwake);
                }
            }

            this.SiwakeList = newSiwakeList;
            return this;
        }

        /// <summary>
        /// 伝票から削除された仕訳を取消仕訳として追加
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public Denpyou AddTorikesiSiwake(Denpyou denpyouOld)
        {
            foreach (var siwakeOld in denpyouOld.SiwakeList)
            {
                if (this.SiwakeList.FirstOrDefault(siwake => siwake.SiwakeSequenceNumber == siwakeOld.SiwakeSequenceNumber) == null)
                {
                    siwakeOld.IsTorikesi = true;
                    this.SiwakeList.Add(siwakeOld);
                }
            }

            return this;
        }

        /// <summary>
        /// 伝票内の新規仕訳のSSEQを付番
        /// </summary>
        /// <param name="kakutukiZyouhou"></param>
        /// <returns></returns>
        public Denpyou NumberSiwakeSequence(ISyoritukiDenpyouSummary kakutukiZyouhou)
        {
            foreach (var siwake in this.SiwakeList.Where(siwake => siwake.SiwakeSequenceNumber == 0))
            {
                kakutukiZyouhou.LastSiwakeSequence++;
                siwake.SetSseq(kakutukiZyouhou.LastSiwakeSequence);
            }

            return this;
        }

        /// <summary>
        /// 伝票内の全仕訳のPSEQをセット
        /// SSEQ付番後に実行
        /// </summary>
        /// <returns></returns>
        public Denpyou SetParentChildSequence()
        {
            for (var parentSiwakeIndex = 0; parentSiwakeIndex < this.SiwakeList.Count; parentSiwakeIndex++)
            {
                // PSEQがセットされていない場合に処理をおこなう。
                if (this.SiwakeList[parentSiwakeIndex].ParentChildSiwakeSequenceNumber < 1)
                {
                    // 親子関係がない場合は自SSEQをセット
                    this.SiwakeList[parentSiwakeIndex].ParentChildSiwakeSequenceNumber = this.SiwakeList[parentSiwakeIndex].SiwakeSequenceNumber;
                    if (this.SiwakeList[parentSiwakeIndex].ParentChildFlag == SiwakeParentChildRelated.Parent)
                    {
                        // 親仕訳の直後に子仕訳がある前提の処理
                        // 子仕訳が０円仕訳で作成されていない場合は自SSEQがセットされた状態となる
                        var childSiwakeIndex = parentSiwakeIndex + 1;
                        if (childSiwakeIndex < this.SiwakeList.Count &&
                            this.SiwakeList[childSiwakeIndex].ParentChildFlag == SiwakeParentChildRelated.Child)
                        {
                            this.SiwakeList[parentSiwakeIndex].ParentChildSiwakeSequenceNumber = this.SiwakeList[childSiwakeIndex].SiwakeSequenceNumber;
                            this.SiwakeList[childSiwakeIndex].ParentChildSiwakeSequenceNumber = this.SiwakeList[parentSiwakeIndex].SiwakeSequenceNumber;
                        }
                    }
                }
            }

            return this;
        }

        /// <summary>
        /// 伝票内の全仕訳に行番号を再付番
        /// 分離仕訳作成後に実行
        /// </summary>
        /// <returns></returns>
        public Denpyou RenumberLineNo()
        {
            if (this.DenpyouKeisiki == DenpyouKeisiki.Hukugou)
            {
                // 行番号付番済みSSEQを格納
                var sseqList = new List<int>();
                var childSiwakeGyouCount = 0;
                foreach (var siwake in this.SiwakeList.Where(siwake => !siwake.IsTorikesi))
                {
                    // 行番号再付番未了且つ子仕訳でない場合に処理
                    // 子仕訳については親仕訳の付番時に処理
                    if (!sseqList.Contains(siwake.SiwakeSequenceNumber) && !(siwake.ParentChildFlag == SiwakeParentChildRelated.Child))
                    {
                        // 相手仕訳の行番号＝自仕訳の行番号とするため再付番前に相手仕訳を取得
                        var aiteSiwake = this.FindAiteSiwake(siwake, sseqList);

                        // 自仕訳の行番号を再付番してSSEQをリストにセット
                        siwake.LineNo += childSiwakeGyouCount;
                        sseqList.Add(siwake.SiwakeSequenceNumber);

                        if (aiteSiwake != null)
                        {
                            // 相手仕訳が存在する場合は行番号を再付番してリストにセット
                            aiteSiwake.LineNo = siwake.LineNo;
                            sseqList.Add(aiteSiwake.SiwakeSequenceNumber);
                        }

                        // 自仕訳の分離子仕訳が存在する場合は行番号を付番してリストにセット
                        var childSiwake = this.FindChildSiwakeAfterNumberingPseq(siwake);
                        if (childSiwake != null)
                        {
                            childSiwake.LineNo = siwake.LineNo + 1;
                            sseqList.Add(childSiwake.SiwakeSequenceNumber);
                        }

                        // 相手仕訳の分離子仕訳が存在する場合は行番号を付番してリストにセット
                        var aiteChildSiwake = this.FindChildSiwakeAfterNumberingPseq(aiteSiwake);
                        if (aiteChildSiwake != null)
                        {
                            if (childSiwake?.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku
                                || (childSiwake != null && aiteChildSiwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku))
                                {
                                // 貸借共に子仕訳を作成するが子仕訳が1行にできない場合
                                aiteChildSiwake.LineNo = childSiwake.LineNo + 1;
                            }
                            else
                            {
                                aiteChildSiwake.LineNo = aiteSiwake.LineNo + 1;
                            }

                            sseqList.Add(aiteChildSiwake.SiwakeSequenceNumber);
                        }

                        // 分離子仕訳が存在する場合は以降の行番号を＋１する
                        if ((childSiwake?.IsNew ?? false) || (aiteChildSiwake?.IsNew ?? false))
                        {
                            childSiwakeGyouCount++;
                            if (childSiwake != null && aiteChildSiwake != null
                                && childSiwake.IsNew && aiteChildSiwake.IsNew
                                && (childSiwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku
                                    || aiteChildSiwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku))
                            {
                                // 貸借共に子仕訳を作成するが子仕訳が1行にできない場合
                                childSiwakeGyouCount++;
                            }
                        }
                    }
                }
            }
            else
            {
                var beforeNumber = 0;
                foreach (var siwake in this.SiwakeList.Where(siwake => !siwake.IsTorikesi))
                {
                    if (beforeNumber >= siwake.LineNo)
                    {
                        siwake.LineNo = ++beforeNumber;
                    }

                    beforeNumber = siwake.LineNo;
                }
            }

            return this;
        }

        /// <summary>
        /// 経過月、伝票SEQ、伝票タイプを伝票束リンクにセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetPrimaryKeyToDenpyouTabaLink()
        {
            this.DenpyouTabaLink?
                .SetDkei(this.Dkei)
                .SetDuno(this.UketukeNo)
                .SetDymd(this.DenpyouHizuke)
                .SetDcno(this.DenpyouNo);
            return this;
        }

        /// <summary>
        /// 伝票タイプを全リンク情報にセット
        /// </summary>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        public Denpyou SetDenpyouTypeToLinkInfomation(DenpyouType denpyouType)
        {
            this.LinkInfomationList.ForEachIfNotNull(linkInfomation =>
            {
                linkInfomation.SetDenpyouType(denpyouType);
            });
            return this;
        }

        /// <summary>
        /// 伝票と仕訳の取り消しフラグをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetTorikesiFlag()
        {
            this.IsTorikesi = true;
            this.SiwakeList.ForEachIfNotNull(siwake => siwake.IsTorikesi = true);
            return this;
        }

        /// <summary>
        /// 承認前振替伝票出力済フラグをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetPrintedDenpyouBeforeSyounin()
        {
            this.PrintedDenpyouBeforeSyounin =
                (this.PrintedDenpyouBeforeSyounin != PrintedFlag.NotPrinted) ? PrintedFlag.UpdatedAfterPrinting : PrintedFlag.NotPrinted;
            return this;
        }

        /// <summary>
        /// 振替伝票出力済フラグをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetHurikaeDenpyouPrintedFlag()
        {
            this.HurikaeDenpyouPrintedFlag =
                this.HurikaeDenpyouPrintedFlag != PrintedFlag.NotPrinted ? PrintedFlag.UpdatedAfterPrinting : PrintedFlag.NotPrinted;
            return this;
        }

        /// <summary>
        /// チェックリスト出力済フラグをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetIsPrintedChecklist()
        {
            this.IsPrintedChecklist = false;
            return this;
        }

        /// <summary>
        /// 伝票状態フラグをセット
        /// 伝票ヘッダーの変更をおこなった場合には「1:修正あり」に更新します。
        /// 仕訳の追加または変更をおこなった場合には「1:修正あり」に更新します。
        /// 仕訳の削除等をおこない、変更内容が行番号の変更のみの場合は「2:行番号のみの修正」に更新します。
        /// 最終行を削除した場合や、削除した行に空行を挿入する処理を行なった場合等、
        /// 伝票として変更が行われているが、変更後、どの実仕訳も変更されていない状態の場合に、「3：出力対象データなし」に更新します。
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public Denpyou SetDenpyouUpdateStatusFlag(Denpyou denpyouOld)
        {
            if (this.IsModifiedDenpyouHeader(denpyouOld) || this.IsContainsNewSiwake() || this.IsSiwakeModified(denpyouOld))
            {
                this.DenpyouUpdateStatusFlag = DenpyouUpdateStatusFlag.Modified;
            }
            else if (this.IsChangeSiwakeLineNo(denpyouOld))
            {
                this.DenpyouUpdateStatusFlag = DenpyouUpdateStatusFlag.ModifiedOnlyLineNo;
            }
            else if (this.SiwakeList.Count == denpyouOld.SiwakeList.Count && this.SiwakeList[this.SiwakeList.Count - 1].IsTorikesi)
            {
                this.DenpyouUpdateStatusFlag = DenpyouUpdateStatusFlag.NoOutputTargetData;
            }

            return this;
        }

        /// <summary>
        /// 行変更仕訳存在フラグをセット
        /// 仕訳データで１つでも行変更フラグが「1：行変更あり」であれば「1：行変更仕訳あり」
        /// なければ、「0：行変更仕訳なし」に更新します。
        /// 仕訳の行変更フラグ設定後に実行する。
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public Denpyou SetIsUpdatedLine(Denpyou denpyouOld)
        {
            this.SetIsUpdatedLineToSiwake(denpyouOld);
            this.IsUpdatedLine = this.SiwakeList.FirstOrDefault(siwake => siwake.IsUpdatedLine) != null;
            return this;
        }

        /// <summary>
        /// 全仕訳のチェックリスト出力済フラグをセット
        /// 仕訳に変更があった場合はフラグを「0：未出力」にします。
        /// ただし、変更内容が行番号のみの場合は、更新しません。
        /// 取消仕訳についても「0：未出力」にします。
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public Denpyou SetIsPrintedChecklistToSiwake(Denpyou denpyouOld)
        {
            this.SiwakeList.ForEachIfNotNull(siwake =>
            {
                if (siwake.IsTorikesi || (!siwake.IsNew && siwake.IsModified(denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber))))
                {
                    siwake.IsPrintedChecklist = false;
                }
            });
            return this;
        }

        /// <summary>
        /// 全仕訳の仕訳一覧フラグをセット
        /// 仕訳が修正された場合、または、ヘッダーが修正された場合に未出力にします。
        /// （伝票ヘッダーに変更があった場合は、変更された伝票ヘッダーの伝票のすべての仕訳の仕訳一覧フラグを「0：未出力」にします。）
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public Denpyou SetIsSiwakeListOutputTargetToSiwake(Denpyou denpyouOld)
        {
            if (this.IsModifiedDenpyouHeader(denpyouOld))
            {
                this.SiwakeList.ForEachIfNotNull(siwake => siwake.IsPrintedSiwakeList = false);
            }
            else
            {
                this.SiwakeList.ForEachIfNotNull(siwake =>
                {
                    if (siwake.IsNew)
                    {
                        siwake.IsPrintedSiwakeList = true;
                    }
                    else if (siwake.IsTorikesi || siwake.IsModified(denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber)))
                    {
                        siwake.IsPrintedSiwakeList = false;
                    }
                });
            }

            return this;
        }

        public Denpyou SetRirekiFlag(int rirekiDenpyouSequence)
        {
            this.RirekiNumber = this.DenpyouSequenceNumber;
            this.RirekiDenpyouSequence = rirekiDenpyouSequence;
            return this;
        }

        /// <summary>
        /// 仕訳合計の変動額を取得
        /// </summary>
        /// <param name="isTorikesi"></param>
        /// <returns></returns>
        public decimal GetSiwakeGoukeiExcludeSyokutiFloatingAmount(bool isTorikesi) =>
            this.SiwakeList.Where(siwake => (isTorikesi || !siwake.IsTorikesi)
                && siwake.KarikataKamokuCode != KamokuInnerCodeFormat.SyokutiKicd && siwake.KarikataKamokuCode != KamokuInnerCodeFormat.SikinguriSyokutiKicd
                && siwake.KasikataKamokuCode != KamokuInnerCodeFormat.SyokutiKicd && siwake.KasikataKamokuCode != KamokuInnerCodeFormat.SikinguriSyokutiKicd)
            .Sum(siwake => siwake.Kingaku);

        /// <summary>
        /// 借方諸口合計の変動額を取得
        /// </summary>
        /// <param name="isTorikesi"></param>
        /// <returns></returns>
        public decimal GetKarikataSyokutiGoukeiFloatingAmount(bool isTorikesi) =>
            this.SiwakeList.Where(siwake => (isTorikesi || !siwake.IsTorikesi)
                && (siwake.KarikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd || siwake.KarikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd))
            .Sum(siwake => siwake.Kingaku);

        /// <summary>
        /// 貸方諸口合計の変動額を取得
        /// </summary>
        /// <param name="isTorikesi"></param>
        /// <returns></returns>
        public decimal GetKasikataSyokutiGoukeiFloatingAmount(bool isTorikesi) =>
            this.SiwakeList.Where(siwake => (isTorikesi || !siwake.IsTorikesi)
                && (siwake.KasikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd || siwake.KasikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd))
            .Sum(siwake => siwake.Kingaku);

        /// <summary>
        /// 有効仕訳数を取得
        /// </summary>
        /// <returns></returns>
        public int GetYuukouSiwakeCount() =>
             this.SiwakeList.Count(siwake => !siwake.IsTorikesi);

        /// <summary>
        /// 取消仕訳数を取得
        /// </summary>
        /// <returns></returns>
        public int GetTorikesiSiwakeCount() =>
             this.SiwakeList.Count(siwake => siwake.IsTorikesi);

        /// <summary>
        /// タイムスタンプ付与対象を取得
        /// </summary>
        /// <returns></returns>
        public IList<Edocument> GetTimeStampTarget()
        {
            var timeStampTarget = new List<Edocument>();
            this.LinkInfomationList.Where(linkInfomation => !string.IsNullOrEmpty(linkInfomation.Edoc))
                .ForEachIfNotNull(linkInfomation =>
                {
                    if (linkInfomation.Edocument.NeedTimeStamp)
                    {
                        timeStampTarget.Add(linkInfomation.Edocument);
                    }
                });
            return timeStampTarget;
        }

        /// <summary>
        /// 一括税抜き処理フラグの更新値をセット
        /// </summary>
        /// <param name="syorituki"></param>
        public void SetIsIkkatuZeinukiProcessed(Syorituki syorituki)
        {
            if (!syorituki.ProcessedInfo.IsIkkatuZeinukiProcessed)
            {
                // 更新不要
                return;
            }

            this.SiwakeList.ForEachIfNotNull(siwake =>
            {
                if (siwake.BunriKubun == BunriKubun.NotSet
                    && (siwake.KarikataKazeiKubun == KazeiKubun.税込
                    || siwake.KarikataKazeiKubun == KazeiKubun.課込仕入
                    || siwake.KarikataKazeiKubun == KazeiKubun.課込売上
                    || siwake.KarikataKazeiKubun == KazeiKubun.貸倒回込
                    || siwake.KarikataKazeiKubun == KazeiKubun.貸倒損込
                    || siwake.KasikataKazeiKubun == KazeiKubun.税込
                    || siwake.KasikataKazeiKubun == KazeiKubun.課込仕入
                    || siwake.KasikataKazeiKubun == KazeiKubun.課込売上
                    || siwake.KasikataKazeiKubun == KazeiKubun.貸倒回込
                    || siwake.KasikataKazeiKubun == KazeiKubun.貸倒損込))
                {
                    // 分離仕訳ではない且つ税込系の区分
                    syorituki.ProcessedInfo.IsIkkatuZeinukiProcessed = false;
                }
            });
        }

        /// <summary>
        /// 消費税累積計算処理フラグの更新値をセット
        /// </summary>
        /// <param name="syorituki"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="kamokuList"></param>
        /// <param name="tokuteiSyuunyuuKamokuList"></param>
        public void SetIsSyouhizeiRuisekiKeisanProcessed(Syorituki syorituki, SyouhizeiMaster syouhizeiMaster, IList<Kamoku> kamokuList, IList<TokuteiSyuunyuuKamoku> tokuteiSyuunyuuKamokuList)
        {
            if (!syorituki.ProcessedInfo.IsSyouhizeiRuisekiKeisanProcessed)
            {
                // 更新不要
                return;
            }

            var kamokuDictionary = kamokuList.ToDictionary(kamoku => Tuple.Create(kamoku.Kesn, kamoku.Kicd));
            var tokuteiSyuunyuuKamokuDictionary = tokuteiSyuunyuuKamokuList
                .ToDictionary(tokuteiSyuunyuuKamoku => Tuple.Create(tokuteiSyuunyuuKamoku.Kesn, tokuteiSyuunyuuKamoku.Kicd));

            this.SiwakeList.ForEachIfNotNull(siwake =>
            {
                if (kamokuDictionary.GetValue(Tuple.Create(siwake.Kesn, siwake.KarikataKamokuCode), null)?.SyoriGroup != KamokuSyoriGroup.Taisyougai
                    || kamokuDictionary.GetValue(Tuple.Create(siwake.Kesn, siwake.KasikataKamokuCode), null)?.SyoriGroup != KamokuSyoriGroup.Taisyougai
                    || (syouhizeiMaster.IsTokuteiSyuunyuuTokureiKeisan
                    && (tokuteiSyuunyuuKamokuDictionary.ContainsKey(Tuple.Create(siwake.Kesn, siwake.KarikataKamokuCode))
                    || tokuteiSyuunyuuKamokuDictionary.ContainsKey(Tuple.Create(siwake.Kesn, siwake.KasikataKamokuCode)))))
                {
                    // 処理グループが対象外でない又は特定収入の特例計算をおこなう場合
                    syorituki.ProcessedInfo.IsSyouhizeiRuisekiKeisanProcessed = false;
                }
            });
        }

        /// <summary>
        /// 消込計算処理フラグの更新値をセット
        /// </summary>
        /// <param name="syorituki"></param>
        /// <param name="useKesikomi"></param>
        /// <param name="kesikomiTaisyouKamokuList"></param>
        public void SetIsKesikomiKeisanProcessed(Syorituki syorituki, bool useKesikomi, IList<KesikomiTaisyouKamoku> kesikomiTaisyouKamokuList)
        {
            if (!useKesikomi || !syorituki.ProcessedInfo.IsKesikomiKeisanProcessed)
            {
                // 更新不要
                return;
            }

            var kesikomiTaisyouKamokuDictionary = kesikomiTaisyouKamokuList
                .ToDictionary(kesikomiTaisyouKamoku => Tuple.Create(kesikomiTaisyouKamoku.Kesn, kesikomiTaisyouKamoku.Kicd));

            this.SiwakeList.ForEachIfNotNull(siwake =>
            {
                if (kesikomiTaisyouKamokuDictionary.ContainsKey(Tuple.Create(siwake.Kesn, siwake.KarikataKamokuCode))
                    || kesikomiTaisyouKamokuDictionary.ContainsKey(Tuple.Create(siwake.Kesn, siwake.KasikataKamokuCode)))
                {
                    // 消込対象科目の場合
                    syorituki.ProcessedInfo.IsKesikomiKeisanProcessed = false;
                }
            });
        }

        /// <summary>
        /// 伝票内全仕訳の全承認コメントに経過月、伝票Seq、仕訳Seqをセット
        /// </summary>
        /// <returns></returns>
        public Denpyou SetKeikAndDseqAndSseqToSyouninComment()
        {
            foreach (var siwake in this.SiwakeList)
            {
                siwake.SetKeikAndDseqAndSseqToSyouninComment();
            }

            return this;
        }

        /// <summary>
        /// 伝票合計を取得
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="registerKingakuMinyuryokuSiwake"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        public IList<TannituSiwakeGroupGoukei> CreateTannituSiwakeGroupGoukeiList(SyouhizeiMaster syouhizeiMaster, bool registerKingakuMinyuryokuSiwake)
        {
            var tannituSiwakeGroupGoukeiList = new List<TannituSiwakeGroupGoukei>();
            var tannituSiwakeGroupGoukei = new TannituSiwakeGroupGoukei();

            foreach (var siwake in this.SiwakeList)
            {
                if (!siwake.IsRegistrationTargetSiwake(registerKingakuMinyuryokuSiwake))
                {
                    // 登録対象仕訳でない
                    continue;
                }

                if (tannituSiwakeGroupGoukei.Kaisigyou == 0)
                {
                    // 開始行を設定
                    tannituSiwakeGroupGoukei.Kaisigyou = siwake.LineNo;
                }

                if (!siwake.ShouldCreateTwoSiwake(syouhizeiMaster))
                {
                    switch (siwake.BunriKubun)
                    {
                        case BunriKubun.ZidouBunri:
                            if (siwake.IsInputTaika)
                            {
                                if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                }
                                else
                                {
                                    if (siwake.IsKarikataKamokuSyokutiKamoku)
                                    {
                                        tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                    }

                                    if (siwake.IsKasikataKamokuSyokutiKamoku)
                                    {
                                        tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                    }
                                }
                            }
                            else
                            {
                                if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Kingaku;
                                }
                                else
                                {
                                    if (siwake.IsKarikataKamokuSyokutiKamoku)
                                    {
                                        tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                    }

                                    if (siwake.IsKasikataKamokuSyokutiKamoku)
                                    {
                                        tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                    }
                                }
                            }

                            break;

                        case BunriKubun.HurikaeSakusei:
                            if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                            {
                                tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            }
                            else
                            {
                                tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Syouhizeigaku;
                                if (siwake.IsKarikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                }

                                if (siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                }
                            }

                            break;

                        case BunriKubun.ZeiSakusei:
                            if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                            {
                                tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            }
                            else
                            {
                                if (siwake.IsKarikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                }

                                if (siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                }
                            }

                            break;

                        default:
                            if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                            {
                                tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Kingaku;
                            }
                            else
                            {
                                if (siwake.IsKarikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                }

                                if (siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                }
                            }

                            break;
                    }
                }
                else
                {
                    // 貸方を明示的な諸口とみなす
                    switch (siwake.BunriKubun)
                    {
                        case BunriKubun.ZidouBunri:
                            if (siwake.IsInputTaika)
                            {
                                tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            }
                            else
                            {
                                tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                            }

                            break;

                        case BunriKubun.HurikaeSakusei:
                            // 貸借両仕訳分の税額を加算
                            tannituSiwakeGroupGoukei.SiwakeGoukei += siwake.Syouhizeigaku * 2;
                            tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                            tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                            break;

                        case BunriKubun.ZeiSakusei:
                            tannituSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            tannituSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            break;

                        default:
                            break;
                    }
                }

                if (!tannituSiwakeGroupGoukeiList.Contains(tannituSiwakeGroupGoukei))
                {
                    tannituSiwakeGroupGoukeiList.Add(tannituSiwakeGroupGoukei);
                }

                if (siwake.IsGyoukugiri)
                {
                    tannituSiwakeGroupGoukei = new TannituSiwakeGroupGoukei();
                }
            }

            return tannituSiwakeGroupGoukeiList;
        }

        /// <summary>
        /// 伝票合計を取得
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="registerKingakuMinyuryokuSiwake"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        public IList<HukugouSiwakeGroupGoukei> CreateHukugouSiwakeGroupGoukeiList(SyouhizeiMaster syouhizeiMaster, bool registerKingakuMinyuryokuSiwake)
        {
            var hukugouSiwakeGroupGoukeiList = new List<HukugouSiwakeGroupGoukei>();
            var hukugouSiwakeGroupGoukei = new HukugouSiwakeGroupGoukei();

            foreach (var siwake in this.SiwakeList)
            {
                if (!siwake.IsRegistrationTargetSiwake(registerKingakuMinyuryokuSiwake))
                {
                    // 登録対象仕訳でない
                    continue;
                }

                if (hukugouSiwakeGroupGoukei.Kaisigyou == 0)
                {
                    // 開始行を設定
                    hukugouSiwakeGroupGoukei.Kaisigyou = siwake.LineNo;
                }

                if (siwake.ParentChildFlag == SiwakeParentChildRelated.Nothing)
                {
                    // 分離前仕訳の場合は分離後の金額も考慮する
                    switch (siwake.BunriKubun)
                    {
                        case BunriKubun.ZidouBunri:
                            if (siwake.IsInputTaika)
                            {
                                if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                                {
                                    hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                }

                                if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                                {
                                    hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                                }
                            }
                            else
                            {
                                if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                                {
                                    hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                                }

                                if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                                {
                                    hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                                }
                            }

                            break;

                        case BunriKubun.HurikaeSakusei:
                            hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Syouhizeigaku;
                            hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Syouhizeigaku;

                            if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                            {
                                hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                            }

                            if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                            {
                                hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                            }

                            break;

                        case BunriKubun.ZeiSakusei:
                            if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Kasikata)
                            {
                                hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            }

                            if (siwake.SiwakeTaisyakuZokusei != SiwakeTaisyakuZokusei.Karikata)
                            {
                                hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku + siwake.Syouhizeigaku;
                            }

                            break;

                        default:
                            switch (siwake.SiwakeTaisyakuZokusei)
                            {
                                case SiwakeTaisyakuZokusei.Karikata:
                                    if (siwake.IsKarikataKamokuSyokutiKamoku)
                                    {
                                        hukugouSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                    }
                                    else
                                    {
                                        hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                                    }

                                    break;
                                case SiwakeTaisyakuZokusei.Kasikata:
                                    if (siwake.IsKasikataKamokuSyokutiKamoku)
                                    {
                                        hukugouSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                    }
                                    else
                                    {
                                        hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                                    }

                                    break;
                                case SiwakeTaisyakuZokusei.Taisyaku:
                                default:
                                    if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                                    {
                                        hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                                        hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                                    }
                                    else
                                    {
                                        if (siwake.IsKarikataKamokuSyokutiKamoku)
                                        {
                                            hukugouSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                        }

                                        if (siwake.IsKasikataKamokuSyokutiKamoku)
                                        {
                                            hukugouSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                        }
                                    }

                                    break;
                            }

                            break;
                    }
                }
                else
                {
                    switch (siwake.SiwakeTaisyakuZokusei)
                    {
                        case SiwakeTaisyakuZokusei.Karikata:
                            if (siwake.IsKarikataKamokuSyokutiKamoku)
                            {
                                hukugouSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                            }
                            else
                            {
                                hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                            }

                            break;
                        case SiwakeTaisyakuZokusei.Kasikata:
                            if (siwake.IsKasikataKamokuSyokutiKamoku)
                            {
                                hukugouSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                            }
                            else
                            {
                                hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                            }

                            break;
                        case SiwakeTaisyakuZokusei.Taisyaku:
                        default:
                            if (!siwake.IsKarikataKamokuSyokutiKamoku && !siwake.IsKasikataKamokuSyokutiKamoku)
                            {
                                hukugouSiwakeGroupGoukei.KarikataGoukei += siwake.Kingaku;
                                hukugouSiwakeGroupGoukei.KasikataGoukei += siwake.Kingaku;
                            }
                            else
                            {
                                if (siwake.IsKarikataKamokuSyokutiKamoku)
                                {
                                    hukugouSiwakeGroupGoukei.KarikataSyokutiGoukei += siwake.Kingaku;
                                }

                                if (siwake.IsKasikataKamokuSyokutiKamoku)
                                {
                                    hukugouSiwakeGroupGoukei.KasikataSyokutiGoukei += siwake.Kingaku;
                                }
                            }

                            break;
                    }
                }

                if (!hukugouSiwakeGroupGoukeiList.Contains(hukugouSiwakeGroupGoukei))
                {
                    hukugouSiwakeGroupGoukeiList.Add(hukugouSiwakeGroupGoukei);
                }

                if (siwake.IsGyoukugiri)
                {
                    hukugouSiwakeGroupGoukei = new HukugouSiwakeGroupGoukei();
                }
            }

            return hukugouSiwakeGroupGoukeiList;
        }

        /// <summary>
        /// 掲示板メッセージを送る必要があるか
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        public bool NeedsToSendBbsMessage(Denpyou denpyouOld) =>
            (this.HanteizumiSaizyouiSyouninsyaZyunzyo != denpyouOld.HanteizumiSaizyouiSyouninsyaZyunzyo
            || this.SyouninZyoukyou != denpyouOld.SyouninZyoukyou)
            && (this.SyouninZyoukyou == SyouninStatus.HininSyuusei
            || this.SyouninZyoukyou == SyouninStatus.HininSakuzyo);
        #endregion

        #region private Methods

        /// <summary>
        /// 行番号再付番が未了の相手仕訳を取得
        /// </summary>
        /// <param name="siwake"></param>
        /// <param name="sseqList"></param>
        /// <returns></returns>
        private Siwake FindAiteSiwake(Siwake siwake, IList<int> sseqList) =>
            this.SiwakeList.ToList().Find(aiteSiwake =>
                aiteSiwake.SiwakeSequenceNumber != siwake.SiwakeSequenceNumber
                && aiteSiwake.SiwakeTaisyakuZokusei != siwake.SiwakeTaisyakuZokusei
                && aiteSiwake.LineNo == siwake.LineNo && !sseqList.Contains(aiteSiwake.SiwakeSequenceNumber));

        /// <summary>
        /// 分離子仕訳を取得
        /// Pseq付番後に使用可能
        /// </summary>
        /// <param name="siwake"></param>
        /// <returns></returns>
        private Siwake FindChildSiwakeAfterNumberingPseq(Siwake siwake) =>
            siwake != null && siwake.ParentChildFlag == SiwakeParentChildRelated.Parent
                ? this.SiwakeList.ToList().Find(
                    childSiwake => childSiwake.ParentChildSiwakeSequenceNumber == siwake.SiwakeSequenceNumber
                    && childSiwake.ParentChildFlag == SiwakeParentChildRelated.Child)
                : null;

        /// <summary>
        /// 全仕訳の行変更フラグをセット
        /// 行番号のみの変更が行われた仕訳のみフラグを「1：行変更あり」にします。
        /// 修正がおこなわれると、修正された仕訳と判断するため行変更フラグは「0：行変更なし」にします。
        /// 取消仕訳についても「0：行変更なし」にします。
        /// </summary>
        /// <param name="denpyouOld"></param>
        /// <returns></returns>
        private Denpyou SetIsUpdatedLineToSiwake(Denpyou denpyouOld)
        {
            foreach (var siwake in this.SiwakeList.Where(siwake => siwake.IsPrintedChecklist))
            {
                if (siwake.IsModified(denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber)))
                {
                    siwake.IsUpdatedLine = false;
                }
                else if (siwake.IsTorikesi)
                {
                    siwake.IsUpdatedLine = false;
                }
                else if (siwake.LineNo != denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber).LineNo)
                {
                    siwake.IsUpdatedLine = true;
                }
            }

            return this;
        }

        private bool IsContainsNewSiwake() =>
            this.SiwakeList.FirstOrDefault(siwake => siwake.IsNew) != null;

        private bool IsSiwakeModified(Denpyou denpyouOld) =>
            this.SiwakeList.FirstOrDefault(siwake => !siwake.IsNew &&
                siwake.IsModified(denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber))) != null;

        private bool IsChangeSiwakeLineNo(Denpyou denpyouOld) =>
            this.SiwakeList.FirstOrDefault(siwake => !siwake.IsNew &&
                siwake.LineNo != denpyouOld.SiwakeList.First(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwake.SiwakeSequenceNumber).LineNo) != null;

        private bool IsModifiedDenpyouHeader(Denpyou denpyouOld) =>
            this.DenpyouHizuke != denpyouOld.DenpyouHizuke
            || this.DenpyouNo != denpyouOld.DenpyouNo
            || this.DenpyouKeisiki != denpyouOld.DenpyouKeisiki
            || this.DenpyouInputPatternNumber != denpyouOld.DenpyouInputPatternNumber
            || this.Kihyoubi != denpyouOld.Kihyoubi
            || this.KihyouBumonCode != denpyouOld.KihyouBumonCode
            || this.KihyousyaCode != denpyouOld.KihyousyaCode
            || this.UketukeNo != denpyouOld.UketukeNo
            || this.SyouninGroupNumber != denpyouOld.SyouninGroupNumber
            || this.SyouninZyoukyou != denpyouOld.SyouninZyoukyou
            || this.HeaderField1Code != denpyouOld.HeaderField1Code
            || this.HeaderField2Code != denpyouOld.HeaderField2Code
            || this.HeaderField3Code != denpyouOld.HeaderField3Code
            || this.HeaderField4Code != denpyouOld.HeaderField4Code
            || this.HeaderField5Code != denpyouOld.HeaderField5Code
            || this.HeaderField6Code != denpyouOld.HeaderField6Code
            || this.HeaderField7Code != denpyouOld.HeaderField7Code
            || this.HeaderField8Code != denpyouOld.HeaderField8Code
            || this.HeaderField9Code != denpyouOld.HeaderField9Code
            || this.HeaderField10Code != denpyouOld.HeaderField10Code;

        private IList<ICreatedAndLastUpdatedYmdHmsEntity> GetSyouninCommentUpdateTargetCreatedDateTime()
        {
            var updateTargetList = new List<ICreatedAndLastUpdatedYmdHmsEntity>();

            this.SiwakeList.ForEachIfNotNull(siwake =>
                updateTargetList.AddRange(siwake.SyouninCommentList.Where(syouninComment =>
                    syouninComment.IsNew).ToList()));

            return updateTargetList;
        }

        private bool SiwakeChangedExists(Denpyou oldDenpyou)
        {
            if (this.SiwakeList.Count != oldDenpyou.SiwakeList.Count)
            {
                return true;
            }

            for (int siwakeIndex = 0; siwakeIndex < this.SiwakeList.Count; siwakeIndex++)
            {
                if (this.SiwakeList[siwakeIndex].HasChanged(oldDenpyou.SiwakeList[siwakeIndex]))
                {
                    return true;
                }
            }

            return false;
        }
        #endregion
    }
}