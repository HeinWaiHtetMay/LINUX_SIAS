﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;

    public class TannituSiwakeGroupGoukei
    {
        public int Kaisigyou { get; set; }

        public decimal SiwakeGoukei { get; set; }

        public decimal KarikataSyokutiGoukei { get; set; }

        public decimal KasikataSyokutiGoukei { get; set; }

        public decimal SyokutiSagaku =>
            this.KarikataSyokutiGoukei - this.KasikataSyokutiGoukei;

        public decimal TaisyakuGoukei =>
            this.SiwakeGoukei + (((this.KarikataSyokutiGoukei + this.KasikataSyokutiGoukei) / 2) >= 0
                ? Math.Round((this.KarikataSyokutiGoukei + this.KasikataSyokutiGoukei) / 2)
                : Math.Round((this.KarikataSyokutiGoukei + this.KasikataSyokutiGoukei) / 2) - 0.01m);
    }
}
