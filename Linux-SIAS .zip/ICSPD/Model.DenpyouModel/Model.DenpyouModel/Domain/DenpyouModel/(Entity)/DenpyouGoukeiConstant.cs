﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class DenpyouGoukeiConstant
    {
        public static readonly string NoKingakuString = "*";
    }
}
