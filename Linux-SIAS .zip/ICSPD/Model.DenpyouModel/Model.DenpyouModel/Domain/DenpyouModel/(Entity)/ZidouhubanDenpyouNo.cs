﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class ZidouhubanDenpyouNo
    {
        public ZidouhubanDenpyouNo(int kesn, int keik, int fgno)
        {
            this.Kesn = kesn;
            this.Keik = keik;
            this.Fgno = fgno;
        }

        #region properties

        public int Kesn { get; private set; }

        public int Keik { get; private set; }

        public int Fgno { get; private set; }

        public int Dcno { get; set; }

        public int Fcno { get; set; }
        #endregion
    }
}
