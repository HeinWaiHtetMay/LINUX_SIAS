﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;

    [Serializable]
    public class DenpyouTabaLink
    {
        public DenpyouTabaLink(int kesn, int dkei, int duno, int dymd, int dcno, int fusr)
        {
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.Duno = duno;
            this.Dymd = dymd;
            this.Dcno = dcno;
            this.Fusr = fusr;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei { get; private set; }

        /// <summary>
        /// 受付番号（カラム名：duno）
        /// </summary>
        public int Duno { get; private set; }

        /// <summary>
        /// 伝票日付（カラム名：dymd）
        /// </summary>
        public int Dymd { get; private set; }

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        public int Dcno { get; private set; }

        /// <summary>
        /// 伝票束コード（カラム名：tabacode）
        /// </summary>
        public string TabaCode { get; set; }

        /// <summary>
        /// 伝票入力者（カラム名：fusr）
        /// </summary>
        public int Fusr { get; set; }
        #endregion

        #region public methods
        public DenpyouTabaLink SetDkei(int dkei)
        {
            this.Dkei = dkei;
            return this;
        }

        public DenpyouTabaLink SetDuno(int duno)
        {
            this.Duno = duno;
            return this;
        }

        public DenpyouTabaLink SetDymd(int dymd)
        {
            this.Dymd = dymd;
            return this;
        }

        public DenpyouTabaLink Clone() => (DenpyouTabaLink)this.MemberwiseClone();

        /// <summary>
        /// 伝票番号をセット
        /// 伝票番号無しは0をセット
        /// </summary>
        /// <param name="dcno"></param>
        /// <returns></returns>
        public DenpyouTabaLink SetDcno(int? dcno)
        {
            this.Dcno = dcno ?? 0;
            return this;
        }

        /// <summary>
        /// 変更されているかチェック
        /// </summary>
        /// <param name="oldDenpyouTabaLink"></param>
        /// <returns></returns>
        public bool HasChanged(DenpyouTabaLink oldDenpyouTabaLink) => this.TabaCode != oldDenpyouTabaLink.TabaCode;

        #endregion
    }
}
