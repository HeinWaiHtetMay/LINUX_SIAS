﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class HukugouSiwakeGroupGoukei
    {
        public int Kaisigyou { get; set; }

        public string KaisigyouString =>
            (this.NoKarikataKingaku || this.NoKasikataKingaku ? DenpyouGoukeiConstant.NoKingakuString : " ") + string.Format("{0, 4}", this.Kaisigyou);

        public decimal KarikataGoukei { get; set; }

        public decimal KasikataGoukei { get; set; }

        public decimal TaisyakuSagaku => this.KarikataGoukei - this.KasikataGoukei;

        public decimal KarikataSyokutiGoukei { get; set; }

        public decimal KasikataSyokutiGoukei { get; set; }

        public decimal SyokutiSagaku => this.KarikataSyokutiGoukei - this.KasikataSyokutiGoukei;

        public bool NoKarikataKingaku => this.KarikataGoukei == 0 && this.KarikataSyokutiGoukei == 0;

        public bool NoKasikataKingaku => this.KasikataGoukei == 0 && this.KasikataSyokutiGoukei == 0;
    }
}
