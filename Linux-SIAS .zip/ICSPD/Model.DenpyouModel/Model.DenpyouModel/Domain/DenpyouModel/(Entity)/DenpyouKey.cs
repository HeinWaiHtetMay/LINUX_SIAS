﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class DenpyouKey : IDenpyouKey
    {
        public DenpyouKey(int dkei, int denpyouSequenceNumber)
        {
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = denpyouSequenceNumber;
        }

        /// <summary>
        /// 経過月
        /// </summary>
        public int Dkei { get; private set; }

        /// <summary>
        /// 伝票SEQNo.
        /// </summary>
        public int DenpyouSequenceNumber { get; private set; }
    }
}
