﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class ZidouhubanSyokiSettei
    {
        public ZidouhubanSyokiSettei(int kesn)
        {
            this.Kesn = kesn;
        }

        #region properties

        public int Kesn { get; private set; }

        public ZidouhubanType ZidouhubanType { get; set; }

        public bool IsUseBusyoNyuusyuturyokuZidouHuban { get; set; }

        #endregion
    }
}
