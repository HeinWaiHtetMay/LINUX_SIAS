﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using Icsp.Framework.Core.Serialization;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

    [Serializable]
    public class EdocumentSearchItem
    {
        public EdocumentSearchItem(int kesn, string edoc, int eseq)
        {
            this.Kesn = kesn;
            this.Edoc = edoc;
            this.Eseq = eseq;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// e文書番号（カラム名：edoc）
        /// </summary>
        public string Edoc { get; private set; }

        /// <summary>
        /// seqno.（カラム名：eseq）
        /// </summary>
        public int Eseq { get; private set; }

        /// <summary>
        /// 日付（カラム名：symd）
        /// </summary>
        public int? Symd { get; set; }

        /// <summary>
        /// 金額（カラム名：svalu）
        /// </summary>
        public decimal? Svalu { get; set; }

        /// <summary>
        /// 発行者名称（カラム名：strnam）
        /// </summary>
        public string Strnam { get; set; }

        /// <summary>
        /// 備考（カラム名：biko）
        /// </summary>
        public string Bikou { get; set; }

        /// <summary>
        /// 書類種別（カラム名：syubetsu）
        /// </summary>
        public EdocumentType EdocumentType { get; set; }
        #endregion

        #region public methods

        /// <summary>
        /// e文書検索項目を複製
        /// </summary>
        /// <returns></returns>
        public EdocumentSearchItem CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);

        /// <summary>
        /// 変更が加えられているかチェック
        /// </summary>
        /// <param name="oldEdocumentSearchItem"></param>
        /// <returns></returns>
        public bool HasChanged(EdocumentSearchItem oldEdocumentSearchItem) =>
            oldEdocumentSearchItem == null
            || this.Kesn != oldEdocumentSearchItem.Kesn
            || this.Edoc != oldEdocumentSearchItem.Edoc
            || this.Eseq != oldEdocumentSearchItem.Eseq
            || this.Symd != oldEdocumentSearchItem.Symd
            || this.Svalu != oldEdocumentSearchItem.Svalu
            || this.Strnam != oldEdocumentSearchItem.Strnam
            || this.Bikou != oldEdocumentSearchItem.Bikou
            || this.EdocumentType != oldEdocumentSearchItem.EdocumentType;

        #endregion
    }
}
