﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using Icsp.Framework.Core.Serialization;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.MasterModel;

    [Serializable]
    public class LinkInfomation : ICreatedAndLastUpdatedYmdHmsEntity
    {
        /// <summary>
        /// マスター情報
        /// </summary>
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other) { Use = true, CodeMaxLength = 4, MasterCodeType = MasterCodeType.Numeric };

        /// <summary>
        /// 新規リンク情報
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="lkid"></param>
        /// <param name="denpyouType"></param>
        /// <param name="nyuuryokusyaCode"></param>
        /// <param name="nyuuryokuSyudan"></param>
        internal LinkInfomation(int kesn, int dkei, int dseq, int lkid, DenpyouType denpyouType, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan)
        {
            this.IsNew = true;
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.Dseq = dseq;
            this.Lkid = lkid;
            this.DenpyouType = denpyouType;
            this.Fusr = nyuuryokusyaCode;
            this.Fway = nyuuryokuSyudan;
            this.Lusr = nyuuryokusyaCode;
        }

        /// <summary>
        /// 既存リンク情報
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="lkid"></param>
        /// <param name="denpyouType"></param>
        internal LinkInfomation(int kesn, int dkei, int dseq, int lkid, DenpyouType denpyouType)
        {
            this.IsNew = false;
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.Dseq = dseq;
            this.Lkid = lkid;
            this.DenpyouType = denpyouType;
        }

        #region public properties

        /// <summary>
        /// 新規
        /// </summary>
        public bool IsNew { get; private set; }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei { get; private set; }

        /// <summary>
        /// 伝票seqno.（カラム名：dseq）
        /// </summary>
        public int Dseq { get; private set; }

        /// <summary>
        /// リンクid（カラム名：lkid）
        /// </summary>
        public int Lkid { get; private set; }

        /// <summary>
        /// システム種別（カラム名：styp）
        /// </summary>
        public DenpyouType DenpyouType { get; private set; }

        /// <summary>
        /// リンク名称（カラム名：lnam）
        /// </summary>
        public string Lnam { get; set; }

        /// <summary>
        /// リンク先（カラム名：link）
        /// </summary>
        public string Link { get; set; }

        /// <summary>
        /// リンク形式（カラム名：flg1）
        /// </summary>
        public LinkType LinkType { get; set; }

        /// <summary>
        /// 新規作成者（カラム名：fusr）
        /// </summary>
        public int Fusr { get; set; }

        /// <summary>
        /// 新規作成年月日（カラム名：fmod）
        /// </summary>
        public int Fmod { get; set; }

        /// <summary>
        /// 新規作成時間（カラム名：ftim）
        /// </summary>
        public int Ftim { get; set; }

        /// <summary>
        /// 最終更新者（カラム名：lusr）
        /// </summary>
        public int Lusr { get; set; }

        /// <summary>
        /// 最終更新年月日（カラム名：lmod）
        /// </summary>
        public int Lmod { get; set; }

        /// <summary>
        /// 最終更新時間（カラム名：ltim）
        /// </summary>
        public int Ltim { get; set; }

        /// <summary>
        /// 入力手段（カラム名：fway）
        /// </summary>
        public DenpyouSiwakeWayToCreate Fway { get; set; }

        /// <summary>
        /// e文書番号（カラム名：edoc）
        /// </summary>
        public string Edoc { get; set; }

        /// <summary>
        /// e文書（テーブル名：edoc）
        /// </summary>
        public Edocument Edocument { get; set; }

        #region implements ICreatedAndLastUpdatedYmdHmsEntity
        public int CreatedYmd { get => this.Fmod; set => this.Fmod = value; }

        public int CreatedHms { get => this.Ftim; set => this.Ftim = value; }

        public int LastUpdatedYmd { get => this.Lmod; set => this.Lmod = value; }

        public int LastUpdatedHms { get => this.Ltim; set => this.Ltim = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Second;

        #endregion

        public string Code => this.Lkid.ToString("0000");

        public string Name => this.Lnam;
        #endregion

        #region public methods

        /// <summary>
        /// リンク情報を複製
        /// </summary>
        /// <returns></returns>
        public LinkInfomation CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);

        /// <summary>
        /// Dkeiをセット
        /// </summary>
        /// <param name="dkei"></param>
        /// <returns></returns>
        public LinkInfomation SetDkei(int dkei)
        {
            this.Dkei = dkei;
            return this;
        }

        /// <summary>
        /// Dseqをセット
        /// </summary>
        /// <param name="dseq"></param>
        /// <returns></returns>
        public LinkInfomation SetDseq(int dseq)
        {
            this.Dseq = dseq;
            return this;
        }

        /// <summary>
        /// 伝票タイプをセット
        /// </summary>
        /// <param name="denpyouType"></param>
        public void SetDenpyouType(DenpyouType denpyouType) => this.DenpyouType = denpyouType;

        /// <summary>
        /// 変更が加えられているかチェック
        /// </summary>
        /// <param name="oldlinkInfomation"></param>
        /// <returns></returns>
        public bool HasChanged(LinkInfomation oldlinkInfomation) =>
            oldlinkInfomation == null
            || this.Kesn != oldlinkInfomation.Kesn
            || this.Dkei != oldlinkInfomation.Dkei
            || this.Dseq != oldlinkInfomation.Dseq
            || this.Lkid != oldlinkInfomation.Lkid
            || this.DenpyouType != oldlinkInfomation.DenpyouType
            || this.Lnam != oldlinkInfomation.Lnam
            || this.Link != oldlinkInfomation.Link
            || this.LinkType != oldlinkInfomation.LinkType
            || this.Fusr != oldlinkInfomation.Fusr
            || this.Fmod != oldlinkInfomation.Fmod
            || this.Ftim != oldlinkInfomation.Ftim
            || this.Lusr != oldlinkInfomation.Lusr
            || this.Lmod != oldlinkInfomation.Lmod
            || this.Ltim != oldlinkInfomation.Ltim
            || this.Fway != oldlinkInfomation.Fway
            || this.Edoc != oldlinkInfomation.Edoc
            || (this.Edocument == null && oldlinkInfomation.Edocument != null)
            || (this.Edocument != null && this.Edocument.HasChanged(oldlinkInfomation.Edocument));
        #endregion
    }
}
