﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.Text;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Framework.Core.Serialization;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    [Serializable]
    public class Siwake : ICreatedAndLastUpdatedYmdHmsEntity
    {
        /// <summary>
        /// 既存仕訳
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="sseq"></param>
        internal Siwake(int kesn, int dkei, int dseq, int sseq)
        {
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = dseq;
            this.SiwakeSequenceNumber = sseq;
            this.IsNew = false;
            this.SyouninCommentList = new List<SyouninComment>();
            this.HasCodeSecurity = false;
        }

        /// <summary>
        /// 新規仕訳
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        internal Siwake(int kesn, int dkei, int dseq)
        {
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = 0;
            this.SiwakeSequenceNumber = 0;
            this.IsNew = true;
            this.SyouninCommentList = new List<SyouninComment>();
            this.HasCodeSecurity = false;
        }

        /// <summary>
        /// 新規仕訳
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="nyuuryokusyaCode"></param>
        /// <param name="nyuuryokuSyudan"></param>
        internal Siwake(int kesn, int dkei, int dseq, int nyuuryokusyaCode, DenpyouSiwakeWayToCreate nyuuryokuSyudan)
        {
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.DenpyouSequenceNumber = dseq;
            this.SiwakeSequenceNumber = 0;
            this.IsNew = true;
            this.SyouninCommentList = new List<SyouninComment>();
            this.HasCodeSecurity = false;
        }

        #region public properties

        /// <summary>
        /// 新規
        /// </summary>
        public bool IsNew { get; private set; }

        /// <summary>
        /// 税額
        /// </summary>
        public decimal Syouhizeigaku { get; set; }

        /// <summary>
        /// 外貨税額
        /// </summary>
        public decimal GaikaZeigaku { get; set; }

        /// <summary>
        /// 行区切り
        /// </summary>
        public bool IsGyoukugiri { get; set; }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei { get; private set; }

        /// <summary>
        /// 伝票seqno.（カラム名：dseq）
        /// </summary>
        public int DenpyouSequenceNumber { get; private set; }

        /// <summary>
        /// 仕訳seqno.（カラム名：sseq）
        /// </summary>
        public int SiwakeSequenceNumber { get; private set; }

        /// <summary>
        /// 親仕訳seqno.（カラム名：pseq）
        /// </summary>
        public int ParentChildSiwakeSequenceNumber { get; set; }

        /// <summary>
        /// 親子フラグ（カラム名：pflg）
        /// </summary>
        public SiwakeParentChildRelated ParentChildFlag { get; set; }

        /// <summary>
        /// 分離区分（カラム名：bkbn）
        /// </summary>
        public BunriKubun BunriKubun { get; set; }

        /// <summary>
        /// グループ番号（カラム名：grno）
        /// </summary>
        public int GroupNumber { get; set; }

        /// <summary>
        /// 行番号（カラム名：dlin）
        /// </summary>
        public int LineNo { get; set; }

        /// <summary>
        /// 貸借属性（カラム名：dflg）
        /// </summary>
        public SiwakeTaisyakuZokusei SiwakeTaisyakuZokusei { get; set; }

        /// <summary>
        /// 借方部門（カラム名：rbmn）
        /// </summary>
        public string KarikataBumonCode { get; set; }

        /// <summary>
        /// 借方取引先（カラム名：rtor）
        /// </summary>
        public string KarikataTorihikisakiCode { get; set; }

        /// <summary>
        /// 借方科目（カラム名：rkmk）
        /// </summary>
        public string KarikataKamokuCode { get; set; }

        /// <summary>
        /// 借方枝番（カラム名：reda）
        /// </summary>
        public string KarikataEdabanCode { get; set; }

        /// <summary>
        /// 借方工事ｎｏ（カラム名：rkoj）
        /// </summary>
        public string KarikataKouziCode { get; set; }

        /// <summary>
        /// 借方工種ｎｏ（カラム名：rkos）
        /// </summary>
        public string KarikataKousyuCode { get; set; }

        /// <summary>
        /// 借方ﾌﾟﾛｼﾞｪｸﾄ（カラム名：rprj）
        /// </summary>
        public string KarikataProjectCode { get; set; }

        /// <summary>
        /// 借方セグメント（カラム名：rseg）
        /// </summary>
        public string KarikataSegmentCode { get; set; }

        /// <summary>
        /// 借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1（カラム名：rdm1）
        /// </summary>
        public string KarikataUniversalField1Code { get; set; }

        /// <summary>
        /// 借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2（カラム名：rdm2）
        /// </summary>
        public string KarikataUniversalField2Code { get; set; }

        /// <summary>
        /// 借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3（カラム名：rdm3）
        /// </summary>
        public string KarikataUniversalField3Code { get; set; }

        /// <summary>
        /// 借方摘要（カラム名：rtky）
        /// </summary>
        public string KarikataTekiyou { get; set; }

        /// <summary>
        /// 借方摘要ｺｰﾄﾞ（カラム名：rtno）
        /// </summary>
        public int? KarikataTekiyouCode { get; set; }

        /// <summary>
        /// 借方ｲﾒｰｼﾞno.（カラム名：rimg）
        /// </summary>
        public int KarikataImageNumber { get; set; }

        /// <summary>
        /// 貸方部門（カラム名：sbmn）
        /// </summary>
        public string KasikataBumonCode { get; set; }

        /// <summary>
        /// 貸方取引先（カラム名：stor）
        /// </summary>
        public string KasikataTorihikisakiCode { get; set; }

        /// <summary>
        /// 貸方科目（カラム名：skmk）
        /// </summary>
        public string KasikataKamokuCode { get; set; }

        /// <summary>
        /// 貸方枝番（カラム名：seda）
        /// </summary>
        public string KasikataEdabanCode { get; set; }

        /// <summary>
        /// 貸方工事ｎｏ（カラム名：skoj）
        /// </summary>
        public string KasikataKouziCode { get; set; }

        /// <summary>
        /// 貸方工種ｎｏ（カラム名：skos）
        /// </summary>
        public string KasikataKousyuCode { get; set; }

        /// <summary>
        /// 貸方ﾌﾟﾛｼﾞｪｸﾄ（カラム名：sprj）
        /// </summary>
        public string KasikataProjectCode { get; set; }

        /// <summary>
        /// 貸方セグメント（カラム名：sseg）
        /// </summary>
        public string KasikataSegmentCode { get; set; }

        /// <summary>
        /// "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"（カラム名：sdm1）
        /// </summary>
        public string KasikataUniversalField1Code { get; set; }

        /// <summary>
        /// "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"（カラム名：sdm2）
        /// </summary>
        public string KasikataUniversalField2Code { get; set; }

        /// <summary>
        /// "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"（カラム名：sdm3）
        /// </summary>
        public string KasikataUniversalField3Code { get; set; }

        /// <summary>
        /// 貸方摘要（カラム名：stky）
        /// </summary>
        public string KasikataTekiyou { get; set; }

        /// <summary>
        /// 貸方摘要ｺｰﾄﾞ（カラム名：stno）
        /// </summary>
        public int? KasikataTekiyouCode { get; set; }

        /// <summary>
        /// 貸方ｲﾒｰｼﾞno.（カラム名：simg）
        /// </summary>
        public int KasikataImageNumber { get; set; }

        /// <summary>
        /// 対価入力ﾌﾗｸﾞ（カラム名：tflg）
        /// </summary>
        public bool IsInputTaika { get; set; }

        /// <summary>
        /// 対価金額（カラム名：exvl）
        /// </summary>
        public decimal TaikaKingaku { get; set; }

        /// <summary>
        /// 税込金額（カラム名：zkvl）
        /// </summary>
        public decimal ZeikomiKingaku { get; set; }

        /// <summary>
        /// 金額（カラム名：valu）
        /// </summary>
        public decimal Kingaku { get; set; }

        /// <summary>
        /// 税対象科目 科目（カラム名：zkmk）
        /// </summary>
        public string ZeitaisyouKamokuCode { get; set; }

        /// <summary>
        /// 税対象科目 税率（カラム名：zrit）
        /// </summary>
        public Percentage? ZeitaisyouKamokuZeiritu { get; set; }

        /// <summary>
        /// 税対象科目 課税区分（カラム名：zzkb）
        /// </summary>
        public KazeiKubun ZeitaisyouKamokuKazeiKubun { get; set; }

        /// <summary>
        /// 税対象科目 業種区分（カラム名：zgyo）
        /// </summary>
        public GyousyuKubun ZeitaisyouKamokuGyousyuKubun { get; set; }

        /// <summary>
        /// 税対象科目 仕入区分（カラム名：zsre）
        /// </summary>
        public SiwakeSiireKubun ZeitaisyouKamokuSiireKubun { get; set; }

        /// <summary>
        /// 借方税率（カラム名：rrit）
        /// </summary>
        public Percentage? KarikataZeiritu { get; set; }

        /// <summary>
        /// 貸方税率（カラム名：srit）
        /// </summary>
        public Percentage? KasikataZeiritu { get; set; }

        /// <summary>
        /// 借方課税区分（カラム名：rzkb）
        /// </summary>
        public KazeiKubun KarikataKazeiKubun { get; set; }

        /// <summary>
        /// 借方業種区分（カラム名：rgyo）
        /// </summary>
        public GyousyuKubun KarikataGyousyuKubun { get; set; }

        /// <summary>
        /// 借方仕入区分（カラム名：rsre）
        /// </summary>
        public SiwakeSiireKubun KarikataSiireKubun { get; set; }

        /// <summary>
        /// 貸方課税区分（カラム名：szkb）
        /// </summary>
        public KazeiKubun KasikataKazeiKubun { get; set; }

        /// <summary>
        /// 貸方業種区分（カラム名：sgyo）
        /// </summary>
        public GyousyuKubun KasikataGyousyuKubun { get; set; }

        /// <summary>
        /// 貸方仕入区分（カラム名：ssre）
        /// </summary>
        public SiwakeSiireKubun KasikataSiireKubun { get; set; }

        /// <summary>
        /// 一括税抜仕訳フラグ（カラム名：ifri）
        /// </summary>
        public IkkatuZeinukiSiwakeFlag IkkatuZeinukiSiwakeFlag { get; set; }

        /// <summary>
        /// 支払日（カラム名：symd）
        /// </summary>
        public int Siharaibi { get; set; }

        /// <summary>
        /// 支払区分（カラム名：skbn）
        /// </summary>
        public int? SiharaiKubun { get; set; }

        /// <summary>
        /// 支払期日（カラム名：skiz）
        /// </summary>
        public int SiharaiKizitu { get; set; }

        /// <summary>
        /// 回収日（カラム名：uymd）
        /// </summary>
        public int Kaisyuubi { get; set; }

        /// <summary>
        /// 入金区分（カラム名：ukbn）
        /// </summary>
        public int? NyuukinKubun { get; set; }

        /// <summary>
        /// 回収期日（カラム名：ukiz）
        /// </summary>
        public int KaisyuuKizitu { get; set; }

        /// <summary>
        /// 支払exportﾌﾗｸﾞ（カラム名：sexp）
        /// </summary>
        public bool IsExportSiharai { get; set; }

        /// <summary>
        /// 消込ｺｰﾄﾞ（カラム名：dkec）
        /// </summary>
        public string KesikomiCode { get; set; }

        /// <summary>
        /// 消込抽出ﾌﾗｸﾞ（カラム名：pcsw）
        /// </summary>
        public bool IsKesikomiTyuusyutu { get; set; }

        /// <summary>
        /// 消込更新ﾌﾗｸﾞ（カラム名：upsw）
        /// </summary>
        public bool IsKesikomiUpdate { get; set; }

        /// <summary>
        /// 消込ゼロﾌﾗｸﾞ（カラム名：zrsw）
        /// </summary>
        public bool IsKesikomiZero { get; set; }

        /// <summary>
        /// 消込ｸﾞﾙｰﾌﾟｺｰﾄﾞ（カラム名：gpcd）
        /// </summary>
        public string KesikomiGroupCode { get; set; }

        /// <summary>
        /// 入力年月日（カラム名：fmod）
        /// </summary>
        public int SiwakeSakuseibi { get; set; }

        /// <summary>
        /// 入力時分秒（カラム名：ftim）
        /// </summary>
        public int SiwakeSakuseiZikan { get; set; }

        /// <summary>
        /// 入力者（カラム名：fusr）
        /// </summary>
        public int SiwakeSakuseisyaCode { get; set; }

        /// <summary>
        /// 入力手段（カラム名：fway）
        /// </summary>
        public DenpyouSiwakeWayToCreate SiwakeSakuseiHouhou { get; set; }

        /// <summary>
        /// 最終変更年月日（カラム名：lmod）
        /// </summary>
        public int SiwakeKousinbi { get; set; }

        /// <summary>
        /// 最終変更時分秒（カラム名：ltim）
        /// </summary>
        public int SiwakeKousinZikan { get; set; }

        /// <summary>
        /// 最終変更者（カラム名：lusr）
        /// </summary>
        public int SiwakeKousinsyaCode { get; set; }

        /// <summary>
        /// 最終変更手段（カラム名：lway）
        /// </summary>
        public DenpyouSiwakeWayToCreate SiwakeKousinHouhou { get; set; }

        /// <summary>
        /// 削除ﾌﾗｸﾞ（カラム名：delf）
        /// </summary>
        public bool IsTorikesi { get; set; }

        /// <summary>
        /// 出力ﾌﾗｸﾞ（カラム名：cprt）
        /// </summary>
        public bool IsPrintedChecklist { get; set; }

        /// <summary>
        /// 付箋番号（カラム名：fsen）
        /// </summary>
        public SiwakeHusen SiwakeHusen { get; set; }

        /// <summary>
        /// 承認者編集（カラム名：smnt）
        /// </summary>
        public bool IsSyouninsyaHensyuu { get; set; }

        /// <summary>
        /// odcｲﾝﾎﾟｰﾄ履歴番号（カラム名：idm4）
        /// </summary>
        public int OdcImportRirekiNumber { get; set; }

        /// <summary>
        /// 借方通貨コード（カラム名：rhei_cd）
        /// </summary>
        public string KarikataHeisyuCode { get; set; }

        /// <summary>
        /// 貸方通貨コード（カラム名：shei_cd）
        /// </summary>
        public string KasikataHeisyuCode { get; set; }

        /// <summary>
        /// レート（カラム名：rate）
        /// </summary>
        public decimal Rate { get; set; }

        /// <summary>
        /// 外貨金額（カラム名：gaika）
        /// </summary>
        public decimal GaikaKingaku { get; set; }

        /// <summary>
        /// 外貨対価（カラム名：gexvl）
        /// </summary>
        public decimal GaikaTaikaKingaku { get; set; }

        /// <summary>
        /// 外貨税込金額（カラム名：gzkvl）
        /// </summary>
        public decimal GaikaZeikomiKingaku { get; set; }

        /// <summary>
        /// 債務支払export（カラム名：smexp）
        /// </summary>
        public bool IsExportSaimu { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4（カラム名：rdm4）
        /// </summary>
        public string KarikataUniversalField4Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5（カラム名：rdm5）
        /// </summary>
        public string KarikataUniversalField5Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6（カラム名：rdm6）
        /// </summary>
        public string KarikataUniversalField6Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7（カラム名：rdm7）
        /// </summary>
        public string KarikataUniversalField7Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8（カラム名：rdm8）
        /// </summary>
        public string KarikataUniversalField8Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9（カラム名：rdm9）
        /// </summary>
        public string KarikataUniversalField9Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10（カラム名：rdm10）
        /// </summary>
        public string KarikataUniversalField10Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11（カラム名：rdm11）
        /// </summary>
        public string KarikataUniversalField11Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12（カラム名：rdm12）
        /// </summary>
        public string KarikataUniversalField12Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13（カラム名：rdm13）
        /// </summary>
        public string KarikataUniversalField13Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14（カラム名：rdm14）
        /// </summary>
        public string KarikataUniversalField14Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15（カラム名：rdm15）
        /// </summary>
        public string KarikataUniversalField15Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16（カラム名：rdm16）
        /// </summary>
        public string KarikataUniversalField16Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17（カラム名：rdm17）
        /// </summary>
        public string KarikataUniversalField17Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18（カラム名：rdm18）
        /// </summary>
        public string KarikataUniversalField18Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19（カラム名：rdm19）
        /// </summary>
        public string KarikataUniversalField19Code { get; set; }

        /// <summary>
        /// 借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20（カラム名：rdm20）
        /// </summary>
        public string KarikataUniversalField20Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4（カラム名：sdm4）
        /// </summary>
        public string KasikataUniversalField4Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5（カラム名：sdm5）
        /// </summary>
        public string KasikataUniversalField5Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6（カラム名：sdm6）
        /// </summary>
        public string KasikataUniversalField6Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7（カラム名：sdm7）
        /// </summary>
        public string KasikataUniversalField7Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8（カラム名：sdm8）
        /// </summary>
        public string KasikataUniversalField8Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9（カラム名：sdm9）
        /// </summary>
        public string KasikataUniversalField9Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10（カラム名：sdm10）
        /// </summary>
        public string KasikataUniversalField10Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11（カラム名：sdm11）
        /// </summary>
        public string KasikataUniversalField11Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12（カラム名：sdm12）
        /// </summary>
        public string KasikataUniversalField12Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13（カラム名：sdm13）
        /// </summary>
        public string KasikataUniversalField13Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14（カラム名：sdm14）
        /// </summary>
        public string KasikataUniversalField14Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15（カラム名：sdm15）
        /// </summary>
        public string KasikataUniversalField15Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16（カラム名：sdm16）
        /// </summary>
        public string KasikataUniversalField16Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17（カラム名：sdm17）
        /// </summary>
        public string KasikataUniversalField17Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18（カラム名：sdm18）
        /// </summary>
        public string KasikataUniversalField18Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19（カラム名：sdm19）
        /// </summary>
        public string KasikataUniversalField19Code { get; set; }

        /// <summary>
        /// 貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20（カラム名：sdm20）
        /// </summary>
        public string KasikataUniversalField20Code { get; set; }

        /// <summary>
        /// 借方相手仕訳seqno.（カラム名：rsseqai）
        /// </summary>
        public int KarikataAiteSiwakeSeqNumber { get; set; }

        /// <summary>
        /// 貸方相手仕訳seqno.（カラム名：ssseqai）
        /// </summary>
        public int KasikataAiteSiwakeSeqNumber { get; set; }

        /// <summary>
        /// 貸借摘要フラグ（カラム名：tekiflg）
        /// </summary>
        public bool IsTaisyakubetuTekiyou { get; set; }

        /// <summary>
        /// 否認状況（カラム名：hflg）
        /// </summary>
        public bool IsHininSiwake { get; set; }

        /// <summary>
        /// 行変更フラグ（カラム名：swgflg）
        /// </summary>
        public bool IsUpdatedLine { get; set; }

        /// <summary>
        /// 仕訳一覧フラグ（カラム名：swiflg）
        /// </summary>
        public bool IsPrintedSiwakeList { get; set; }

        /// <summary>
        /// 外貨換算仕訳フラグ（カラム名：fsflg）
        /// </summary>
        public GaikaKanzanSiwakeFlag GaikaKanzanSiwakeFlag { get; set; }

        /// <summary>
        /// 借方軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKarikata { get; set; }

        /// <summary>
        /// 貸方軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKasikata { get; set; }

        /// <summary>
        /// 税対象科目  軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituZeitaisyouKamoku { get; set; }

        /// <summary>
        /// 承認コメント（テーブル名：SNCMT）
        /// </summary>
        public IList<SyouninComment> SyouninCommentList { get; set; }

        #region implements ICreatedAndLastUpdatedYmdHmsEntity
        public int CreatedYmd { get => this.SiwakeSakuseibi; set => this.SiwakeSakuseibi = value; }

        public int CreatedHms { get => this.SiwakeSakuseiZikan; set => this.SiwakeSakuseiZikan = value; }

        public int LastUpdatedYmd { get => this.SiwakeKousinbi; set => this.SiwakeKousinbi = value; }

        public int LastUpdatedHms { get => this.SiwakeKousinZikan; set => this.SiwakeKousinZikan = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Centisecond;
        #endregion

        /// <summary>
        /// 借方を分離するか
        /// </summary>
        public bool IsKarikataBunri => this.BunriKubun != BunriKubun.NotSet && this.IsBunriKubunInputtableKazeiKubun(this.KarikataKazeiKubun);

        /// <summary>
        /// 貸方を分離するか
        /// </summary>
        public bool IsKasikataBunri => this.BunriKubun != BunriKubun.NotSet && this.IsBunriKubunInputtableKazeiKubun(this.KasikataKazeiKubun);

        /// <summary>
        /// 借方科目が諸口科目か
        /// </summary>
        public bool IsKarikataKamokuSyokutiKamoku => this.KarikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd || this.KarikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd;

        /// <summary>
        /// 貸方科目が諸口科目か
        /// </summary>
        public bool IsKasikataKamokuSyokutiKamoku => this.KasikataKamokuCode == KamokuInnerCodeFormat.SyokutiKicd || this.KasikataKamokuCode == KamokuInnerCodeFormat.SikinguriSyokutiKicd;

        /// <summary>
        /// 対価未入力か
        /// HACK Validatorで未入力だったか0か判断できないため
        /// </summary>
        public bool IsTaikaNotInput { get; set; }

        /// <summary>
        /// 外貨未入力か
        /// HACK Validatorで未入力だったか0か判断できないため
        /// </summary>
        public bool IsGaikaKingakuNotInput { get; set; }

        /// <summary>
        /// 外貨対価未入力か
        /// HACK Validatorで未入力だったか0か判断できないため
        /// </summary>
        public bool IsGaikaTaikaKingakuNotInput { get; set; }

        /// <summary>
        /// レート未入力か
        /// HACK Validatorで未入力だったか0か判断できないため
        /// </summary>
        public bool IsRateNotInput { get; set; }

        /// <summary>
        /// チェック対象か
        /// HACK Validatorでチェック対象か判断できないため
        /// </summary>
        public bool HasCodeSecurity { get; set; }

        #endregion

        #region public methods

        /// <summary>
        /// 仕入区分の入力が必要か判断
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="kamoku"></param>
        /// <param name="kazeiKubun"></param>
        /// <returns></returns>
        public bool NeedsSiireKubun(SyouhizeiMaster syouhizeiMaster, Kamoku kamoku, KazeiKubun kazeiKubun)
        {
            if (kamoku == null)
            {
                return false;
            }

            if (syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.HireiHaibun)
            {
                return false;
            }

            switch (kamoku.SyoriGroup)
            {
                case KamokuSyoriGroup.Siire:
                case KamokuSyoriGroup.SiireWaribiki:
                    break;
                default:
                    return false;
            }

            switch (kazeiKubun)
            {
                case KazeiKubun.税込:
                case KazeiKubun.税抜:
                case KazeiKubun.課込仕入:
                case KazeiKubun.課込売上:
                case KazeiKubun.課抜仕入:
                case KazeiKubun.課抜売上:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 業種区分の入力が必要か判断
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="kamoku"></param>
        /// <param name="kazeiKubun"></param>
        /// <returns></returns>
        public bool NeedsGyousyuKubun(SyouhizeiMaster syouhizeiMaster, Kamoku kamoku, KazeiKubun kazeiKubun)
        {
            if (kamoku == null)
            {
                return false;
            }

            if (syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo1
                && syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo2
                && syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo3
                && syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo4
                && syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo4
                && syouhizeiMaster.KazeiHousiki != KazeiHousiki.KaniKazeiZigyouNo6)
            {
                return false;
            }

            switch (kamoku.SyoriGroup)
            {
                case KamokuSyoriGroup.Sisan:
                case KamokuSyoriGroup.Uriage:
                case KamokuSyoriGroup.UriageWaribiki:
                    break;
                default:
                    return false;
            }

            switch (kazeiKubun)
            {
                case KazeiKubun.税込:
                case KazeiKubun.税抜:
                case KazeiKubun.免税:
                case KazeiKubun.課込仕入:
                case KazeiKubun.課込売上:
                case KazeiKubun.課抜仕入:
                case KazeiKubun.課抜売上:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Dkeiをセット
        /// </summary>
        /// <param name="dkei"></param>
        /// <returns></returns>
        public Siwake SetDkei(int dkei)
        {
            this.Dkei = dkei;
            return this;
        }

        /// <summary>
        /// Dseqをセット
        /// </summary>
        /// <param name="dseq"></param>
        /// <returns></returns>
        public Siwake SetDseq(int dseq)
        {
            this.DenpyouSequenceNumber = dseq;
            return this;
        }

        /// <summary>
        /// 最終仕訳SEQをセット
        /// </summary>
        /// <param name="saisyuuSiwakeSequence"></param>
        /// <returns></returns>
        public Siwake SetSseq(int saisyuuSiwakeSequence)
        {
            this.SiwakeSequenceNumber = saisyuuSiwakeSequence;
            return this;
        }

        /// <summary>
        /// 仕訳を複製
        /// </summary>
        /// <returns></returns>
        public Siwake CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);

        /// <summary>
        /// 変更が加えられているか
        /// 承認コメントを含む
        /// </summary>
        /// <param name="oldSiwake"></param>
        /// <returns></returns>
        public bool HasChanged(Siwake oldSiwake) => this.IsModified(oldSiwake)
            || this.SyouninCommentList.Count != oldSiwake.SyouninCommentList.Count;

        /// <summary>
        /// 表示用承認コメントを取得
        /// </summary>
        /// <param name="gengou"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public string GetDisplaySyouninCommentString(Gengou gengou, User user)
        {
            string carriageReturnAndLineFeed = Convert.ToChar(0x000d).ToString() + Convert.ToChar(0x000a).ToString();
            Encoding encoding = Encoding.GetEncoding("Shift_JIS");
            int commentByteCount = 0;

            var displaySyouninCommentStringBuilder = new StringBuilder();
            for (int index = 0; index < this.SyouninCommentList.Count; index++)
            {
                var syouninComment = this.SyouninCommentList[index];
                if (syouninComment.IsNew)
                {
                    // 新規コメントは独立して出力する
                    break;
                }

                var syouninCommentStringBuilder = new StringBuilder();

                // 年月日
                string dateString = new IcspDateTime(syouninComment.Cymd, gengou).GetFormattedYmd("/");
                syouninCommentStringBuilder.Append(dateString);
                syouninCommentStringBuilder.Append(new string(' ', 12 - dateString.Length));

                // 承認判定
                switch (syouninComment.SyouninFlag)
                {
                    case SyouninStatus.Syounin:
                        syouninCommentStringBuilder.Append("承認　　　　　　　");
                        break;

                    case SyouninStatus.HininSyuusei:
                        syouninCommentStringBuilder.Append("否認（修正指示）　");
                        break;

                    case SyouninStatus.HininSakuzyo:
                        syouninCommentStringBuilder.Append("否認（削除指示）　");
                        break;

                    default:
                        syouninCommentStringBuilder.Append("　　　　　　　　　");
                        break;
                }

                syouninCommentStringBuilder.Append(user.Name);
                syouninCommentStringBuilder.Append(carriageReturnAndLineFeed);
                syouninCommentStringBuilder.Append(syouninComment.Comment);
                syouninCommentStringBuilder.Append(carriageReturnAndLineFeed);
                syouninCommentStringBuilder.Append(carriageReturnAndLineFeed);

                commentByteCount += encoding.GetByteCount(syouninCommentStringBuilder.ToString());

                // 30000バイトを超える場合は表示しない
                if (commentByteCount > 30000)
                {
                    break;
                }

                displaySyouninCommentStringBuilder.Append(syouninCommentStringBuilder);
            }

            return displaySyouninCommentStringBuilder.ToString();
        }

        /// <summary>
        /// 1行2仕訳か判断
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <returns></returns>
        public bool ShouldCreateTwoSiwake(SyouhizeiMaster syouhizeiMaster)
        {
            // 貸借ともに自動分離且つ諸口の使用を制限
            if (this.BunriKubun == BunriKubun.ZidouBunri && this.IsKarikataBunri && this.IsKasikataBunri
                && syouhizeiMaster.ZidouBunriSiwakeSyokutiKamokuUsage == ZidouBunriSiwakeSyokutiKamokuUsage.LimitUse)
            {
                return false;
            }

            return this.IsKarikataBunri && this.IsKasikataBunri;
        }

        /// <summary>
        /// 1行から2仕訳を作成
        /// SIAS同様新規仕訳前提の処理
        /// 貸借両分離を想定しているため税対象科目等は考慮していない
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="meisaiKamokuList"></param>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <returns></returns>
        public IList<Siwake> CreateKarikataSiwakeAndKasikataSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList)
        {
            var siwakeList = new List<Siwake>();
            siwakeList.Add(this.CreateKarikataSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList));
            siwakeList.Add(this.CreateKasikataSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList));

            return siwakeList;
        }

        /// <summary>
        /// グループナンバーを作成
        /// グループナンバーは1から連番で行区切りがあるたびにインクリメント
        /// </summary>
        /// <param name="previousSiwake"></param>
        /// <returns></returns>
        public Siwake SetGroupNumber(Siwake previousSiwake)
        {
            this.GroupNumber = previousSiwake == null ? 1 : previousSiwake.GroupNumber + (previousSiwake.IsGyoukugiri ? 1 : 0);
            return this;
        }

        /// <summary>
        /// 分離子仕訳を作成
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="meisaiKamokuList"></param>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public Siwake CreateChildSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, Syoriki syoriki)
        {
            if (this.BunriKubun == BunriKubun.NotSet)
            {
                this.ParentChildFlag = SiwakeParentChildRelated.Nothing;
                return null;
            }

            if (this.ParentChildFlag != SiwakeParentChildRelated.Nothing)
            {
                // 分離子仕訳作成済み
                return null;
            }

            this.ParentChildFlag = SiwakeParentChildRelated.Parent;

            Siwake syouhizeiSiwake;

            // 貸借両分離で諸口を挟まない場合
            if (syouhizeiMaster.ZidouBunriSiwakeSyokutiKamokuUsage == ZidouBunriSiwakeSyokutiKamokuUsage.LimitUse
                && this.BunriKubun == BunriKubun.ZidouBunri && this.KarikataKazeiKubun == this.KasikataKazeiKubun)
            {
                syouhizeiSiwake = this.CreateTaisyakuRyouBunriSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList);
            }

            // 借方分離
            else if (this.KarikataKazeiKubun != KazeiKubun.対象外 && this.KarikataKazeiKubun != KazeiKubun.消費税設定対象外)
            {
                syouhizeiSiwake = this.CreateKarikataBunriSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList, syoriki);
            }

            // 貸方分離
            else
            {
                syouhizeiSiwake = this.CreateKasikataBunriSiwake(syouhizeiMaster, meisaiKamokuList, siharaiNyuukinKamokuList, syoriki);
            }

            if (syouhizeiSiwake.Kingaku == 0 && !syouhizeiMaster.IsCreateSyohizei0YenSiwake)
            {
                // 0円消費税仕訳を作成しない
                return null;
            }

            // HACK セットする位置を再考
            syouhizeiSiwake.SiwakeSakuseisyaCode = this.SiwakeKousinsyaCode;
            syouhizeiSiwake.SiwakeSakuseiHouhou = this.SiwakeKousinHouhou;
            syouhizeiSiwake.SiwakeKousinsyaCode = this.SiwakeKousinsyaCode;
            syouhizeiSiwake.SiwakeKousinHouhou = this.SiwakeKousinHouhou;

            // 消費税仕訳作成後の金額と税込金額を親仕訳にセット
            switch (this.BunriKubun)
            {
                case BunriKubun.ZidouBunri:
                    if (this.IsInputTaika)
                    {
                        this.ZeikomiKingaku = this.TaikaKingaku;
                        this.TaikaKingaku -= this.Syouhizeigaku;
                        this.GaikaZeikomiKingaku = this.GaikaTaikaKingaku;
                        this.GaikaTaikaKingaku -= this.GaikaZeigaku;
                    }
                    else
                    {
                        this.ZeikomiKingaku = this.Kingaku;
                        this.Kingaku -= this.Syouhizeigaku;
                        this.GaikaZeikomiKingaku = this.GaikaKingaku;
                        this.GaikaKingaku -= this.GaikaZeigaku;
                    }

                    break;

                case BunriKubun.HurikaeSakusei:
                    if (this.IsInputTaika)
                    {
                        this.ZeikomiKingaku = this.TaikaKingaku;
                        this.GaikaZeikomiKingaku = this.GaikaTaikaKingaku;
                    }
                    else
                    {
                        this.ZeikomiKingaku = this.Kingaku;
                        this.GaikaZeikomiKingaku = this.GaikaKingaku;
                    }

                    break;

                case BunriKubun.ZeiSakusei:
                    if (this.IsInputTaika)
                    {
                        this.ZeikomiKingaku = this.TaikaKingaku + this.Syouhizeigaku;
                        this.GaikaZeikomiKingaku = this.GaikaTaikaKingaku + this.GaikaZeigaku;
                    }
                    else
                    {
                        this.ZeikomiKingaku = this.Kingaku + this.Syouhizeigaku;
                        this.GaikaZeikomiKingaku = this.GaikaKingaku + this.GaikaZeigaku;
                    }

                    break;
            }

            return syouhizeiSiwake;
        }

        /// <summary>
        /// 分離仕訳作成後の課税区分を取得
        /// </summary>
        /// <param name="bunrimaeKazeikubun"></param>
        /// <param name="bunrikubun"></param>
        /// <returns></returns>
        public KazeiKubun GetBunrigoKazeikubun(KazeiKubun bunrimaeKazeikubun, BunriKubun bunrikubun)
        {
            if (bunrikubun != BunriKubun.ZidouBunri)
            {
                return bunrimaeKazeikubun;
            }

            KazeiKubun bunrigoKazeikubun = bunrimaeKazeikubun;
            switch (bunrimaeKazeikubun)
            {
                case KazeiKubun.税込:
                    bunrigoKazeikubun = KazeiKubun.税抜;
                    break;
                case KazeiKubun.課込仕入:
                    bunrigoKazeikubun = KazeiKubun.課抜仕入;
                    break;
                case KazeiKubun.課込売上:
                    bunrigoKazeikubun = KazeiKubun.課抜売上;
                    break;
                case KazeiKubun.貸倒損込:
                    bunrigoKazeikubun = KazeiKubun.貸倒損抜;
                    break;
                case KazeiKubun.貸倒回込:
                    bunrigoKazeikubun = KazeiKubun.貸倒回抜;
                    break;
            }

            return bunrigoKazeikubun;
        }

        /// <summary>
        /// 仕訳に変更が加えられているかどうか
        /// 承認コメントを除く
        /// </summary>
        /// <param name="oldSiwake"></param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        public bool IsModified(Siwake oldSiwake)
        {
            return this.ParentChildSiwakeSequenceNumber != oldSiwake.ParentChildSiwakeSequenceNumber
                || this.ParentChildFlag != oldSiwake.ParentChildFlag
                || this.BunriKubun != oldSiwake.BunriKubun
                || this.GroupNumber != oldSiwake.GroupNumber
                || this.SiwakeTaisyakuZokusei != oldSiwake.SiwakeTaisyakuZokusei
                || this.KarikataBumonCode != oldSiwake.KarikataBumonCode
                || this.KarikataTorihikisakiCode != oldSiwake.KarikataTorihikisakiCode
                || this.KarikataKamokuCode != oldSiwake.KarikataKamokuCode
                || this.KarikataEdabanCode != oldSiwake.KarikataEdabanCode
                || this.KarikataKouziCode != oldSiwake.KarikataKouziCode
                || this.KarikataKousyuCode != oldSiwake.KarikataKousyuCode
                || this.KarikataProjectCode != oldSiwake.KarikataProjectCode
                || this.KarikataSegmentCode != oldSiwake.KarikataSegmentCode
                || this.KarikataUniversalField1Code != oldSiwake.KarikataUniversalField1Code
                || this.KarikataUniversalField2Code != oldSiwake.KarikataUniversalField2Code
                || this.KarikataUniversalField3Code != oldSiwake.KarikataUniversalField3Code
                || this.KarikataTekiyou != oldSiwake.KarikataTekiyou
                || this.KarikataTekiyouCode != oldSiwake.KarikataTekiyouCode
                || this.KarikataImageNumber != oldSiwake.KarikataImageNumber
                || this.KasikataBumonCode != oldSiwake.KasikataBumonCode
                || this.KasikataTorihikisakiCode != oldSiwake.KasikataTorihikisakiCode
                || this.KasikataKamokuCode != oldSiwake.KasikataKamokuCode
                || this.KasikataEdabanCode != oldSiwake.KasikataEdabanCode
                || this.KasikataKouziCode != oldSiwake.KasikataKouziCode
                || this.KasikataKousyuCode != oldSiwake.KasikataKousyuCode
                || this.KasikataProjectCode != oldSiwake.KasikataProjectCode
                || this.KasikataSegmentCode != oldSiwake.KasikataSegmentCode
                || this.KasikataUniversalField1Code != oldSiwake.KasikataUniversalField1Code
                || this.KasikataUniversalField2Code != oldSiwake.KasikataUniversalField2Code
                || this.KasikataUniversalField3Code != oldSiwake.KasikataUniversalField3Code
                || this.KasikataTekiyou != oldSiwake.KasikataTekiyou
                || this.KasikataTekiyouCode != oldSiwake.KasikataTekiyouCode
                || this.KasikataImageNumber != oldSiwake.KasikataImageNumber
                || this.TaikaKingaku != oldSiwake.TaikaKingaku
                || this.ZeikomiKingaku != oldSiwake.ZeikomiKingaku
                || this.Kingaku != oldSiwake.Kingaku
                || this.ZeitaisyouKamokuCode != oldSiwake.ZeitaisyouKamokuCode
                || this.ZeitaisyouKamokuZeiritu?.GetValue() != oldSiwake.ZeitaisyouKamokuZeiritu?.GetValue()
                || this.ZeitaisyouKamokuKazeiKubun != oldSiwake.ZeitaisyouKamokuKazeiKubun
                || this.ZeitaisyouKamokuGyousyuKubun != oldSiwake.ZeitaisyouKamokuGyousyuKubun
                || this.ZeitaisyouKamokuSiireKubun != oldSiwake.ZeitaisyouKamokuSiireKubun
                || this.KarikataZeiritu?.GetValue() != oldSiwake.KarikataZeiritu?.GetValue()
                || this.KasikataZeiritu?.GetValue() != oldSiwake.KasikataZeiritu?.GetValue()
                || this.KarikataKazeiKubun != oldSiwake.KarikataKazeiKubun
                || this.KarikataGyousyuKubun != oldSiwake.KarikataGyousyuKubun
                || this.KarikataSiireKubun != oldSiwake.KarikataSiireKubun
                || this.KasikataKazeiKubun != oldSiwake.KasikataKazeiKubun
                || this.KasikataGyousyuKubun != oldSiwake.KasikataGyousyuKubun
                || this.KasikataSiireKubun != oldSiwake.KasikataSiireKubun
                || this.Siharaibi != oldSiwake.Siharaibi
                || this.SiharaiKubun != oldSiwake.SiharaiKubun
                || this.SiharaiKizitu != oldSiwake.SiharaiKizitu
                || this.Kaisyuubi != oldSiwake.Kaisyuubi
                || this.NyuukinKubun != oldSiwake.NyuukinKubun
                || this.KaisyuuKizitu != oldSiwake.KaisyuuKizitu
                || this.KesikomiCode != oldSiwake.KesikomiCode
                || this.SiwakeHusen != oldSiwake.SiwakeHusen
                || this.KarikataHeisyuCode != oldSiwake.KarikataHeisyuCode
                || this.KasikataHeisyuCode != oldSiwake.KasikataHeisyuCode
                || this.Rate != oldSiwake.Rate
                || this.GaikaKingaku != oldSiwake.GaikaKingaku
                || this.GaikaTaikaKingaku != oldSiwake.GaikaTaikaKingaku
                || this.GaikaZeikomiKingaku != oldSiwake.GaikaZeikomiKingaku
                || this.KarikataUniversalField4Code != oldSiwake.KarikataUniversalField4Code
                || this.KarikataUniversalField5Code != oldSiwake.KarikataUniversalField5Code
                || this.KarikataUniversalField6Code != oldSiwake.KarikataUniversalField6Code
                || this.KarikataUniversalField7Code != oldSiwake.KarikataUniversalField7Code
                || this.KarikataUniversalField8Code != oldSiwake.KarikataUniversalField8Code
                || this.KarikataUniversalField9Code != oldSiwake.KarikataUniversalField9Code
                || this.KarikataUniversalField10Code != oldSiwake.KarikataUniversalField10Code
                || this.KarikataUniversalField11Code != oldSiwake.KarikataUniversalField11Code
                || this.KarikataUniversalField12Code != oldSiwake.KarikataUniversalField12Code
                || this.KarikataUniversalField13Code != oldSiwake.KarikataUniversalField13Code
                || this.KarikataUniversalField14Code != oldSiwake.KarikataUniversalField14Code
                || this.KarikataUniversalField15Code != oldSiwake.KarikataUniversalField15Code
                || this.KarikataUniversalField16Code != oldSiwake.KarikataUniversalField16Code
                || this.KarikataUniversalField17Code != oldSiwake.KarikataUniversalField17Code
                || this.KarikataUniversalField18Code != oldSiwake.KarikataUniversalField18Code
                || this.KarikataUniversalField19Code != oldSiwake.KarikataUniversalField19Code
                || this.KarikataUniversalField20Code != oldSiwake.KarikataUniversalField20Code
                || this.KasikataUniversalField4Code != oldSiwake.KasikataUniversalField4Code
                || this.KasikataUniversalField5Code != oldSiwake.KasikataUniversalField5Code
                || this.KasikataUniversalField6Code != oldSiwake.KasikataUniversalField6Code
                || this.KasikataUniversalField7Code != oldSiwake.KasikataUniversalField7Code
                || this.KasikataUniversalField8Code != oldSiwake.KasikataUniversalField8Code
                || this.KasikataUniversalField9Code != oldSiwake.KasikataUniversalField9Code
                || this.KasikataUniversalField10Code != oldSiwake.KasikataUniversalField10Code
                || this.KasikataUniversalField11Code != oldSiwake.KasikataUniversalField11Code
                || this.KasikataUniversalField12Code != oldSiwake.KasikataUniversalField12Code
                || this.KasikataUniversalField13Code != oldSiwake.KasikataUniversalField13Code
                || this.KasikataUniversalField14Code != oldSiwake.KasikataUniversalField14Code
                || this.KasikataUniversalField15Code != oldSiwake.KasikataUniversalField15Code
                || this.KasikataUniversalField16Code != oldSiwake.KasikataUniversalField16Code
                || this.KasikataUniversalField17Code != oldSiwake.KasikataUniversalField17Code
                || this.KasikataUniversalField18Code != oldSiwake.KasikataUniversalField18Code
                || this.KasikataUniversalField19Code != oldSiwake.KasikataUniversalField19Code
                || this.KasikataUniversalField20Code != oldSiwake.KasikataUniversalField20Code
                || this.IsTaisyakubetuTekiyou != oldSiwake.IsTaisyakubetuTekiyou
                || this.IsKeigenZeirituKarikata != oldSiwake.IsKeigenZeirituKarikata
                || this.IsKeigenZeirituKasikata != oldSiwake.IsKeigenZeirituKasikata
                || this.IsKeigenZeirituZeitaisyouKamoku != oldSiwake.IsKeigenZeirituZeitaisyouKamoku;
        }

        /// <summary>
        /// 登録対象仕訳か
        /// </summary>
        /// <param name="registerKingakuMinyuryokuSiwake"></param>
        /// <returns></returns>
        public bool IsRegistrationTargetSiwake(bool registerKingakuMinyuryokuSiwake) => this.Kingaku != 0
            || ((string.IsNullOrEmpty(this.KarikataKamokuCode) || string.IsNullOrEmpty(this.KasikataKamokuCode)) && registerKingakuMinyuryokuSiwake);

        /// <summary>
        /// 消費税科目コードを取得
        /// </summary>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="syoriGroup"></param>
        /// <param name="kazeiKubun"></param>
        /// <returns></returns>
        public string GetSyohizeiKamokuCode(SyouhizeiMaster syouhizeiMaster, KamokuSyoriGroup syoriGroup, KazeiKubun kazeiKubun)
        {
            string syouhizeiKamokuCode = null;
            switch (syoriGroup)
            {
                // 仮受系
                case KamokuSyoriGroup.Fusai:

                case KamokuSyoriGroup.Uriage:

                case KamokuSyoriGroup.UriageWaribiki:

                    syouhizeiKamokuCode = syouhizeiMaster.KariukeSyouhizeiKamokuInnerCodeForUriageKamoku;
                    break;

                // 仮払系
                case KamokuSyoriGroup.Siire:

                case KamokuSyoriGroup.SiireWaribiki:
                    syouhizeiKamokuCode = syouhizeiMaster.KaribaraiSyouhizeiKamokuInnerCodeForSiireKamoku;
                    break;

                case KamokuSyoriGroup.Keihi:
                    syouhizeiKamokuCode = syouhizeiMaster.KaribaraiSyouhizeiKamokuInnerCodeForKeihiKamoku;
                    break;

                // 課税区分で判断
                case KamokuSyoriGroup.Konzai:
                    if (kazeiKubun == KazeiKubun.課込仕入 || kazeiKubun == KazeiKubun.課抜仕入)
                    {
                        syouhizeiKamokuCode = syouhizeiMaster.KaribaraiSyouhizeiKamokuInnerCodeForSiireKamoku;
                    }

                    if (kazeiKubun == KazeiKubun.課込売上 || kazeiKubun == KazeiKubun.課抜売上)
                    {
                        syouhizeiKamokuCode = syouhizeiMaster.KariukeSyouhizeiKamokuInnerCodeForUriageKamoku;
                    }

                    break;

                case KamokuSyoriGroup.Sisan:

                case KamokuSyoriGroup.Yuukasyoken:
                    if (kazeiKubun == KazeiKubun.課込仕入 || kazeiKubun == KazeiKubun.課抜仕入)
                    {
                        syouhizeiKamokuCode = syouhizeiMaster.KaribaraiSyouhizeiKamokuInnerCodeForSisanKamoku;
                    }

                    if (kazeiKubun == KazeiKubun.課込売上
                        || kazeiKubun == KazeiKubun.課抜売上
                        || kazeiKubun == KazeiKubun.貸倒損込
                        || kazeiKubun == KazeiKubun.貸倒損抜
                        || kazeiKubun == KazeiKubun.貸倒回込
                        || kazeiKubun == KazeiKubun.貸倒回抜)
                    {
                        syouhizeiKamokuCode = syouhizeiMaster.KariukeSyouhizeiKamokuInnerCodeForSisanKamoku;
                    }

                    break;
            }

            return syouhizeiKamokuCode;
        }

        /// <summary>
        /// 承認コメントに経過月、伝票Seq、仕訳Seqをセット
        /// </summary>
        /// <returns></returns>
        public Siwake SetKeikAndDseqAndSseqToSyouninComment()
        {
            foreach (var syouninComment in this.SyouninCommentList)
            {
                syouninComment.SetKeik(this.Dkei).SetDseq(this.DenpyouSequenceNumber).SetSseq(this.SiwakeSequenceNumber);
            }

            return this;
        }

        /// <summary>
        /// 承認コメントに承認状況をセット
        /// コメントが無い場合は作成する
        /// </summary>
        /// <param name="commentInputUserCode"></param>
        /// <param name="syouninStatus"></param>
        /// <param name="isEditedSyouninsya"></param>
        /// <returns></returns>
        public Siwake SetSyouninStatus(int commentInputUserCode, SyouninStatus syouninStatus, bool isEditedSyouninsya)
        {
            if (this.SyouninCommentList.Count == 0 || !this.SyouninCommentList[this.SyouninCommentList.Count - 1].IsNew)
            {
                this.SyouninCommentList.Add(new SyouninComment(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeSequenceNumber, this.SyouninCommentList.Count + 1));
            }

            var targetSyouninComment = this.SyouninCommentList[this.SyouninCommentList.Count - 1];
            targetSyouninComment.CommentInputUserCode = commentInputUserCode;
            targetSyouninComment.SyouninFlag = syouninStatus;
            targetSyouninComment.IsEditedSyouninsya = isEditedSyouninsya;
            return this;
        }

        /// <summary>
        /// 税込金額をセット
        /// 分離仕訳作成後に使用
        /// 税額が設定されている必要有
        /// </summary>
        /// <returns></returns>
        public Siwake SetZeikomiKingaku()
        {
            if (this.ParentChildFlag == SiwakeParentChildRelated.Parent)
            {
                switch (this.BunriKubun)
                {
                    case BunriKubun.ZidouBunri:
                    case BunriKubun.ZeiSakusei:
                        this.ZeikomiKingaku = this.Kingaku + this.Syouhizeigaku;
                        this.GaikaZeikomiKingaku = this.GaikaKingaku + this.GaikaZeigaku;
                        break;
                    case BunriKubun.HurikaeSakusei:
                        this.ZeikomiKingaku = this.Kingaku;
                        this.GaikaZeikomiKingaku = this.GaikaKingaku;
                        break;
                }
            }
            else
            {
                this.ZeikomiKingaku = 0;
                this.GaikaZeikomiKingaku = 0;
            }

            return this;
        }

        #endregion

        #region private methods

        /// <summary>
        /// 支払区分を付加できるかどうか
        /// </summary>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <param name="kamokuNaibuCode"></param>
        /// <param name="siharaiNyuukinKamokuTaisyakuZokusei"></param>
        /// <returns></returns>
        private bool CanAddSiharaiKubun(IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, string kamokuNaibuCode, SiharaiNyuukinKamokuTaisyakuZokusei siharaiNyuukinKamokuTaisyakuZokusei) =>
            this.ContainsSiharaiNyuukinKamoku(siharaiNyuukinKamokuList, SiharaiNyuukinType.SiharaiKubun, kamokuNaibuCode, siharaiNyuukinKamokuTaisyakuZokusei);

        /// <summary>
        /// 入金区分を付加できるかどうか
        /// </summary>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <param name="kamokuNaibuCode"></param>
        /// <param name="siharaiNyuukinKamokuTaisyakuZokusei"></param>
        /// <returns></returns>
        private bool CanAddNyuukinKubun(IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, string kamokuNaibuCode, SiharaiNyuukinKamokuTaisyakuZokusei siharaiNyuukinKamokuTaisyakuZokusei) =>
            this.ContainsSiharaiNyuukinKamoku(siharaiNyuukinKamokuList, SiharaiNyuukinType.NyuukinKubun, kamokuNaibuCode, siharaiNyuukinKamokuTaisyakuZokusei);

        /// <summary>
        /// 指定した科目が支払入金科目に含まれているか
        /// </summary>
        /// <param name="siharaiNyuukinKamokuList"></param>
        /// <param name="siharaiNyuukinType"></param>
        /// <param name="kamokuNaibuCode"></param>
        /// <param name="siharaiNyuukinKamokuTaisyakuZokusei"></param>
        /// <returns></returns>
        private bool ContainsSiharaiNyuukinKamoku(IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, SiharaiNyuukinType siharaiNyuukinType, string kamokuNaibuCode, SiharaiNyuukinKamokuTaisyakuZokusei siharaiNyuukinKamokuTaisyakuZokusei)
        {
            return siharaiNyuukinKamokuList.Where(
                   siharaiNyuukinKamoku => siharaiNyuukinKamoku.SiharaiNyuukinType == siharaiNyuukinType
                   && siharaiNyuukinKamoku.Kicd == kamokuNaibuCode
                   && (siharaiNyuukinKamoku.TaisyakuZokusei == siharaiNyuukinKamokuTaisyakuZokusei
                   || siharaiNyuukinKamoku.TaisyakuZokusei == SiharaiNyuukinKamokuTaisyakuZokusei.Taisyaku)).FirstOrDefault() != null;
        }

        private Siwake CreateKarikataSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList)
        {
            var siwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeKousinsyaCode, this.SiwakeKousinHouhou);
            siwake.KarikataKamokuCode = this.KarikataKamokuCode;
            siwake.KarikataKazeiKubun = this.KarikataKazeiKubun;
            siwake.KarikataZeiritu = this.KarikataZeiritu;
            siwake.KarikataSiireKubun = this.KarikataSiireKubun;
            siwake.KarikataGyousyuKubun = this.KarikataGyousyuKubun;
            siwake.KarikataBumonCode = this.KarikataBumonCode;
            siwake.KarikataTorihikisakiCode = this.KarikataTorihikisakiCode;
            siwake.KarikataEdabanCode = this.KarikataEdabanCode;
            siwake.KarikataSegmentCode = this.KarikataSegmentCode;
            siwake.KarikataProjectCode = this.KarikataProjectCode;
            siwake.KarikataKouziCode = this.KarikataKouziCode;
            siwake.KarikataKousyuCode = this.KarikataKousyuCode;
            siwake.KarikataTekiyouCode = this.KarikataTekiyouCode;
            siwake.KarikataUniversalField1Code = this.KarikataUniversalField1Code;
            siwake.KarikataUniversalField2Code = this.KarikataUniversalField2Code;
            siwake.KarikataUniversalField3Code = this.KarikataUniversalField3Code;
            siwake.KarikataUniversalField4Code = this.KarikataUniversalField4Code;
            siwake.KarikataUniversalField5Code = this.KarikataUniversalField5Code;
            siwake.KarikataUniversalField6Code = this.KarikataUniversalField6Code;
            siwake.KarikataUniversalField7Code = this.KarikataUniversalField7Code;
            siwake.KarikataUniversalField8Code = this.KarikataUniversalField8Code;
            siwake.KarikataUniversalField9Code = this.KarikataUniversalField9Code;
            siwake.KarikataUniversalField10Code = this.KarikataUniversalField10Code;
            siwake.KarikataUniversalField11Code = this.KarikataUniversalField11Code;
            siwake.KarikataUniversalField12Code = this.KarikataUniversalField12Code;
            siwake.KarikataUniversalField13Code = this.KarikataUniversalField13Code;
            siwake.KarikataUniversalField14Code = this.KarikataUniversalField14Code;
            siwake.KarikataUniversalField15Code = this.KarikataUniversalField15Code;
            siwake.KarikataUniversalField16Code = this.KarikataUniversalField16Code;
            siwake.KarikataUniversalField17Code = this.KarikataUniversalField17Code;
            siwake.KarikataUniversalField18Code = this.KarikataUniversalField18Code;
            siwake.KarikataUniversalField19Code = this.KarikataUniversalField19Code;
            siwake.KarikataUniversalField20Code = this.KarikataUniversalField20Code;

            siwake.KasikataKamokuCode = KamokuInnerCodeFormat.SyokutiKicd;
            siwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;

            if (this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, siwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                siwake.Siharaibi = this.Siharaibi;
                siwake.SiharaiKubun = this.SiharaiKubun;
                siwake.SiharaiKizitu = this.SiharaiKizitu;
            }

            if (this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, siwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                siwake.Kaisyuubi = this.Kaisyuubi;
                siwake.NyuukinKubun = this.NyuukinKubun;
                siwake.KaisyuuKizitu = this.KaisyuuKizitu;
            }

            if (meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == siwake.KarikataKamokuCode).First().AllowUseKesikomiCode)
            {
                siwake.KesikomiCode = this.KesikomiCode;
            }

            siwake.IsInputTaika = this.IsInputTaika;
            siwake.SiwakeHusen = this.SiwakeHusen;

            siwake.Kingaku = this.Kingaku;
            siwake.TaikaKingaku = this.TaikaKingaku;
            siwake.Syouhizeigaku = this.Syouhizeigaku;
            siwake.ZeikomiKingaku = this.ZeikomiKingaku;

            if (string.IsNullOrEmpty(this.KarikataHeisyuCode))
            {
                siwake.KarikataHeisyuCode = this.KarikataHeisyuCode;
                siwake.GaikaKingaku = this.GaikaKingaku;
                siwake.GaikaTaikaKingaku = this.GaikaTaikaKingaku;
                siwake.GaikaZeigaku = this.GaikaZeigaku;
                siwake.GaikaZeikomiKingaku = this.GaikaZeikomiKingaku;
                siwake.Rate = this.Rate;
            }

            siwake.IsTaisyakubetuTekiyou = this.IsTaisyakubetuTekiyou;
            siwake.KarikataTekiyou = this.KarikataTekiyou;

            // 貸借共通摘要の場合は借方と同値
            if (!this.IsTaisyakubetuTekiyou)
            {
                siwake.KasikataTekiyou = siwake.KarikataTekiyou;
            }

            // 行区切りは貸方仕訳にセットする
            siwake.IsGyoukugiri = false;

            return siwake;
        }

        private Siwake CreateKasikataSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList)
        {
            var siwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeKousinsyaCode, this.SiwakeKousinHouhou);
            siwake.KarikataKamokuCode = KamokuInnerCodeFormat.SyokutiKicd;
            siwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;

            siwake.KasikataKamokuCode = this.KasikataKamokuCode;
            siwake.KasikataKazeiKubun = this.KasikataKazeiKubun;
            siwake.KasikataZeiritu = this.KasikataZeiritu;
            siwake.KasikataSiireKubun = this.KasikataSiireKubun;
            siwake.KasikataGyousyuKubun = this.KasikataGyousyuKubun;
            siwake.KasikataBumonCode = this.KasikataBumonCode;
            siwake.KasikataTorihikisakiCode = this.KasikataTorihikisakiCode;
            siwake.KasikataEdabanCode = this.KasikataEdabanCode;
            siwake.KasikataSegmentCode = this.KasikataSegmentCode;
            siwake.KasikataProjectCode = this.KasikataProjectCode;
            siwake.KasikataKouziCode = this.KasikataKouziCode;
            siwake.KasikataKousyuCode = this.KasikataKousyuCode;
            siwake.KasikataTekiyouCode = this.KasikataTekiyouCode;
            siwake.KasikataUniversalField1Code = this.KasikataUniversalField1Code;
            siwake.KasikataUniversalField2Code = this.KasikataUniversalField2Code;
            siwake.KasikataUniversalField3Code = this.KasikataUniversalField3Code;
            siwake.KasikataUniversalField4Code = this.KasikataUniversalField4Code;
            siwake.KasikataUniversalField5Code = this.KasikataUniversalField5Code;
            siwake.KasikataUniversalField6Code = this.KasikataUniversalField6Code;
            siwake.KasikataUniversalField7Code = this.KasikataUniversalField7Code;
            siwake.KasikataUniversalField8Code = this.KasikataUniversalField8Code;
            siwake.KasikataUniversalField9Code = this.KasikataUniversalField9Code;
            siwake.KasikataUniversalField10Code = this.KasikataUniversalField10Code;
            siwake.KasikataUniversalField11Code = this.KasikataUniversalField11Code;
            siwake.KasikataUniversalField12Code = this.KasikataUniversalField12Code;
            siwake.KasikataUniversalField13Code = this.KasikataUniversalField13Code;
            siwake.KasikataUniversalField14Code = this.KasikataUniversalField14Code;
            siwake.KasikataUniversalField15Code = this.KasikataUniversalField15Code;
            siwake.KasikataUniversalField16Code = this.KasikataUniversalField16Code;
            siwake.KasikataUniversalField17Code = this.KasikataUniversalField17Code;
            siwake.KasikataUniversalField18Code = this.KasikataUniversalField18Code;
            siwake.KasikataUniversalField19Code = this.KasikataUniversalField19Code;
            siwake.KasikataUniversalField20Code = this.KasikataUniversalField20Code;

            if (this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, siwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                siwake.Siharaibi = this.Siharaibi;
                siwake.SiharaiKubun = this.SiharaiKubun;
                siwake.SiharaiKizitu = this.SiharaiKizitu;
            }

            if (this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, siwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                siwake.Kaisyuubi = this.Kaisyuubi;
                siwake.NyuukinKubun = this.NyuukinKubun;
                siwake.KaisyuuKizitu = this.KaisyuuKizitu;
            }

            if (meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == siwake.KasikataKamokuCode).First().AllowUseKesikomiCode)
            {
                siwake.KesikomiCode = this.KesikomiCode;
            }

            siwake.IsInputTaika = this.IsInputTaika;
            siwake.SiwakeHusen = this.SiwakeHusen;

            siwake.Kingaku = this.Kingaku;
            siwake.TaikaKingaku = this.TaikaKingaku;
            siwake.Syouhizeigaku = this.Syouhizeigaku;
            siwake.ZeikomiKingaku = this.ZeikomiKingaku;

            if (string.IsNullOrEmpty(this.KasikataHeisyuCode))
            {
                siwake.KasikataHeisyuCode = this.KasikataHeisyuCode;
                siwake.GaikaKingaku = this.GaikaKingaku;
                siwake.GaikaTaikaKingaku = this.GaikaTaikaKingaku;
                siwake.GaikaZeigaku = this.GaikaZeigaku;
                siwake.GaikaZeikomiKingaku = this.GaikaZeikomiKingaku;
                siwake.Rate = this.Rate;
            }

            siwake.IsTaisyakubetuTekiyou = this.IsTaisyakubetuTekiyou;
            siwake.KasikataTekiyou = this.KasikataTekiyou;

            // 貸借共通摘要の場合は貸方と同値
            if (!this.IsTaisyakubetuTekiyou)
            {
                siwake.KarikataTekiyou = siwake.KasikataTekiyou;
            }

            // 行区切りをセット
            siwake.IsGyoukugiri = this.IsGyoukugiri;

            return siwake;
        }

        private Siwake CreateTaisyakuRyouBunriSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList)
        {
            var syouhizeiSiwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeKousinsyaCode, this.SiwakeKousinHouhou);

            syouhizeiSiwake.ParentChildFlag = SiwakeParentChildRelated.Child;
            syouhizeiSiwake.SiwakeTaisyakuZokusei = this.SiwakeTaisyakuZokusei;

            syouhizeiSiwake.BunriKubun = this.BunriKubun;
            syouhizeiSiwake.GroupNumber = this.GroupNumber;

            syouhizeiSiwake.KarikataKamokuCode = this.GetSyohizeiKamokuCode(syouhizeiMaster, meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KarikataKamokuCode).First().SyoriGroup, this.KarikataKazeiKubun);
            this.KarikataKazeiKubun = this.GetBunrigoKazeikubun(this.KarikataKazeiKubun, this.BunriKubun);
            syouhizeiSiwake.KasikataKamokuCode = this.GetSyohizeiKamokuCode(syouhizeiMaster, meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KasikataKamokuCode).First().SyoriGroup, this.KarikataKazeiKubun);
            this.KasikataKazeiKubun = this.GetBunrigoKazeikubun(this.KasikataKazeiKubun, this.BunriKubun);

            // 消費税科目の課税区分を子仕訳にセット
            syouhizeiSiwake.KarikataKazeiKubun = meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == syouhizeiSiwake.KarikataKamokuCode).First().KazeiKubun;
            syouhizeiSiwake.KasikataKazeiKubun = meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == syouhizeiSiwake.KasikataKamokuCode).First().KazeiKubun;

            if (syouhizeiMaster.AddBumonToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataBumonCode = this.KarikataBumonCode;
                syouhizeiSiwake.KasikataBumonCode = this.KasikataBumonCode;
            }

            if (syouhizeiMaster.AddTorihikisakiToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataTorihikisakiCode = this.KarikataTorihikisakiCode;
                syouhizeiSiwake.KasikataTorihikisakiCode = this.KasikataTorihikisakiCode;
            }

            if (syouhizeiMaster.AddEdabanToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataEdabanCode = this.KarikataEdabanCode;
                syouhizeiSiwake.KasikataEdabanCode = this.KasikataEdabanCode;
            }

            if (syouhizeiMaster.AddProjectToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataProjectCode = this.KarikataProjectCode;
                syouhizeiSiwake.KasikataProjectCode = this.KasikataProjectCode;
            }

            if (syouhizeiMaster.AddSegmentToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataSegmentCode = this.KarikataSegmentCode;
                syouhizeiSiwake.KasikataSegmentCode = this.KasikataSegmentCode;
            }

            if (syouhizeiMaster.AddKouziToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataKouziCode = this.KarikataKouziCode;
                syouhizeiSiwake.KasikataKouziCode = this.KasikataKouziCode;
            }

            if (syouhizeiMaster.AddKousyuToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataKousyuCode = this.KarikataKousyuCode;
                syouhizeiSiwake.KasikataKousyuCode = this.KasikataKousyuCode;
            }

            if (syouhizeiMaster.AddUniversalField1ToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataUniversalField1Code = this.KarikataUniversalField1Code;
                syouhizeiSiwake.KasikataUniversalField1Code = this.KasikataUniversalField1Code;
            }

            if (syouhizeiMaster.AddUniversalField2ToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataUniversalField2Code = this.KarikataUniversalField2Code;
                syouhizeiSiwake.KasikataUniversalField2Code = this.KasikataUniversalField2Code;
            }

            if (syouhizeiMaster.AddUniversalField3ToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataUniversalField3Code = this.KarikataUniversalField3Code;
                syouhizeiSiwake.KasikataUniversalField3Code = this.KasikataUniversalField3Code;
            }

            syouhizeiSiwake.KarikataTekiyouCode = this.KarikataTekiyouCode;
            syouhizeiSiwake.KasikataTekiyouCode = this.KasikataTekiyouCode;

            syouhizeiSiwake.KarikataTekiyou = this.KarikataTekiyou;
            syouhizeiSiwake.KasikataTekiyou = this.KasikataTekiyou;

            syouhizeiSiwake.IsTaisyakubetuTekiyou = this.IsTaisyakubetuTekiyou;

            // 貸借両分離の場合は税対象科目の付加を行わない。
            syouhizeiSiwake.ZeitaisyouKamokuCode = null;
            syouhizeiSiwake.ZeitaisyouKamokuZeiritu = null;
            syouhizeiSiwake.IsKeigenZeirituZeitaisyouKamoku = false;
            syouhizeiSiwake.ZeitaisyouKamokuKazeiKubun = KazeiKubun.消費税設定対象外;

            syouhizeiSiwake.ZeitaisyouKamokuGyousyuKubun = GyousyuKubun.None;
            syouhizeiSiwake.ZeitaisyouKamokuSiireKubun = SiwakeSiireKubun.Taisyougai;
            syouhizeiSiwake.Rate = 0;

            if (this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata)
                || this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Kasikata))
            {
                syouhizeiSiwake.Siharaibi = this.Siharaibi;
                syouhizeiSiwake.SiharaiKubun = this.SiharaiKubun;
                syouhizeiSiwake.SiharaiKizitu = this.SiharaiKizitu;
            }

            if (this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata)
                || this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Kasikata))
            {
                syouhizeiSiwake.Kaisyuubi = this.Kaisyuubi;
                syouhizeiSiwake.NyuukinKubun = this.NyuukinKubun;
                syouhizeiSiwake.KaisyuuKizitu = this.KaisyuuKizitu;
            }

            if (meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == syouhizeiSiwake.KarikataKamokuCode).First().AllowUseKesikomiCode
                || meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == syouhizeiSiwake.KasikataKamokuCode).First().AllowUseKesikomiCode)
            {
                syouhizeiSiwake.KesikomiCode = this.KesikomiCode;
            }

            syouhizeiSiwake.KarikataZeiritu = this.KarikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituKarikata = this.IsKeigenZeirituKarikata;
            syouhizeiSiwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
            syouhizeiSiwake.KarikataGyousyuKubun = GyousyuKubun.None;
            syouhizeiSiwake.KarikataSiireKubun = SiwakeSiireKubun.Taisyougai;
            syouhizeiSiwake.KasikataZeiritu = this.KasikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituKasikata = this.IsKeigenZeirituKasikata;
            syouhizeiSiwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
            syouhizeiSiwake.KasikataGyousyuKubun = GyousyuKubun.None;
            syouhizeiSiwake.KasikataSiireKubun = SiwakeSiireKubun.Taisyougai;

            syouhizeiSiwake.SiwakeHusen = this.SiwakeHusen;
            syouhizeiSiwake.Kingaku = this.Syouhizeigaku;
            syouhizeiSiwake.TaikaKingaku = 0;
            syouhizeiSiwake.ZeikomiKingaku = 0;
            syouhizeiSiwake.GaikaKingaku = this.GaikaZeigaku;
            syouhizeiSiwake.GaikaTaikaKingaku = 0;
            syouhizeiSiwake.GaikaZeikomiKingaku = 0;

            return syouhizeiSiwake;
        }

        private Siwake CreateKarikataBunriSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, Syoriki syoriki)
        {
            var syouhizeiSiwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeKousinsyaCode, this.SiwakeKousinHouhou);

            syouhizeiSiwake.ParentChildFlag = SiwakeParentChildRelated.Child;
            syouhizeiSiwake.SiwakeTaisyakuZokusei = this.BunriKubun == BunriKubun.HurikaeSakusei
                ? SiwakeTaisyakuZokusei.Taisyaku
                : this.SiwakeTaisyakuZokusei;

            syouhizeiSiwake.BunriKubun = this.BunriKubun;
            syouhizeiSiwake.GroupNumber = this.GroupNumber;

            // 借方項目は分離区分によらず共通
            syouhizeiSiwake.KarikataKamokuCode = this.GetSyohizeiKamokuCode(syouhizeiMaster, meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KarikataKamokuCode).First().SyoriGroup, this.KarikataKazeiKubun);
            this.KarikataKazeiKubun = this.GetBunrigoKazeikubun(this.KarikataKazeiKubun, this.BunriKubun);

            if (syouhizeiMaster.AddBumonToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataBumonCode = this.KarikataBumonCode;
            }

            if (syouhizeiMaster.AddTorihikisakiToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataTorihikisakiCode = this.KarikataTorihikisakiCode;
            }

            if (syouhizeiMaster.AddEdabanToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataEdabanCode = this.KarikataEdabanCode;
            }

            if (syouhizeiMaster.AddProjectToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataProjectCode = this.KarikataProjectCode;
            }

            if (syouhizeiMaster.AddSegmentToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataSegmentCode = this.KarikataSegmentCode;
            }

            if (syouhizeiMaster.AddKouziToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataKouziCode = this.KarikataKouziCode;
            }

            if (syouhizeiMaster.AddKousyuToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KarikataKousyuCode = this.KarikataKousyuCode;
            }

            if (syouhizeiMaster.AddUniversalField1ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 1).IsCreateMaster)
            {
                syouhizeiSiwake.KarikataUniversalField1Code = this.KarikataUniversalField1Code;
            }

            if (syouhizeiMaster.AddUniversalField2ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 2).IsCreateMaster)
            {
                syouhizeiSiwake.KarikataUniversalField2Code = this.KarikataUniversalField2Code;
            }

            if (syouhizeiMaster.AddUniversalField3ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 3).IsCreateMaster)
            {
                syouhizeiSiwake.KarikataUniversalField3Code = this.KarikataUniversalField3Code;
            }

            syouhizeiSiwake.KarikataTekiyouCode = this.KarikataTekiyouCode;
            syouhizeiSiwake.KarikataTekiyou = this.KarikataTekiyou;

            syouhizeiSiwake.KarikataKazeiKubun = KazeiKubun.消費税設定対象外;
            syouhizeiSiwake.KarikataGyousyuKubun = GyousyuKubun.None;
            syouhizeiSiwake.KarikataSiireKubun = SiwakeSiireKubun.Taisyougai;
            syouhizeiSiwake.KarikataZeiritu = this.KarikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituKarikata = this.IsKeigenZeirituKarikata;
            syouhizeiSiwake.KarikataHeisyuCode = null;

            // 振替作成
            if (this.BunriKubun == BunriKubun.HurikaeSakusei)
            {
                syouhizeiSiwake.KasikataKamokuCode = this.KarikataKamokuCode;
                syouhizeiSiwake.KasikataBumonCode = this.KarikataBumonCode;
                syouhizeiSiwake.KasikataTorihikisakiCode = this.KarikataTorihikisakiCode;
                syouhizeiSiwake.KasikataKamokuCode = this.KarikataKamokuCode;
                syouhizeiSiwake.KasikataEdabanCode = this.KarikataEdabanCode;
                syouhizeiSiwake.KasikataKouziCode = this.KarikataKouziCode;
                syouhizeiSiwake.KasikataKousyuCode = this.KarikataKousyuCode;
                syouhizeiSiwake.KasikataProjectCode = this.KarikataProjectCode;
                syouhizeiSiwake.KasikataSegmentCode = this.KarikataSegmentCode;
                syouhizeiSiwake.KasikataUniversalField1Code = this.KarikataUniversalField1Code;
                syouhizeiSiwake.KasikataUniversalField2Code = this.KarikataUniversalField2Code;
                syouhizeiSiwake.KasikataUniversalField3Code = this.KarikataUniversalField3Code;
                syouhizeiSiwake.KasikataTekiyou = this.KarikataTekiyou;
                syouhizeiSiwake.KasikataTekiyouCode = this.KarikataTekiyouCode;
                syouhizeiSiwake.KasikataUniversalField4Code = this.KarikataUniversalField4Code;
                syouhizeiSiwake.KasikataUniversalField5Code = this.KarikataUniversalField5Code;
                syouhizeiSiwake.KasikataUniversalField6Code = this.KarikataUniversalField6Code;
                syouhizeiSiwake.KasikataUniversalField7Code = this.KarikataUniversalField7Code;
                syouhizeiSiwake.KasikataUniversalField8Code = this.KarikataUniversalField8Code;
                syouhizeiSiwake.KasikataUniversalField9Code = this.KarikataUniversalField9Code;
                syouhizeiSiwake.KasikataUniversalField10Code = this.KarikataUniversalField10Code;
                syouhizeiSiwake.KasikataUniversalField11Code = this.KarikataUniversalField11Code;
                syouhizeiSiwake.KasikataUniversalField12Code = this.KarikataUniversalField12Code;
                syouhizeiSiwake.KasikataUniversalField13Code = this.KarikataUniversalField13Code;
                syouhizeiSiwake.KasikataUniversalField14Code = this.KarikataUniversalField14Code;
                syouhizeiSiwake.KasikataUniversalField15Code = this.KarikataUniversalField15Code;
                syouhizeiSiwake.KasikataUniversalField16Code = this.KarikataUniversalField16Code;
                syouhizeiSiwake.KasikataUniversalField17Code = this.KarikataUniversalField17Code;
                syouhizeiSiwake.KasikataUniversalField18Code = this.KarikataUniversalField18Code;
                syouhizeiSiwake.KasikataUniversalField19Code = this.KarikataUniversalField19Code;
                syouhizeiSiwake.KasikataUniversalField20Code = this.KarikataUniversalField20Code;
                syouhizeiSiwake.KasikataTekiyouCode = this.KarikataTekiyouCode;
                syouhizeiSiwake.KasikataTekiyou = this.KarikataTekiyou;
                syouhizeiSiwake.KasikataKazeiKubun = KazeiKubun.対象外;
                syouhizeiSiwake.KasikataGyousyuKubun = GyousyuKubun.None;
                syouhizeiSiwake.KasikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                syouhizeiSiwake.KasikataZeiritu = null;
                syouhizeiSiwake.IsKeigenZeirituKasikata = false;
                syouhizeiSiwake.KasikataHeisyuCode = this.KarikataHeisyuCode;
                if (meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KarikataKamokuCode).First().AllowUseKesikomiCode)
                {
                    syouhizeiSiwake.KesikomiCode = this.KesikomiCode;
                }
            }

            // 自動分離、税作成
            else
            {
                syouhizeiSiwake.KasikataKamokuCode = this.KasikataKamokuCode;
                syouhizeiSiwake.KasikataBumonCode = this.KasikataBumonCode;
                syouhizeiSiwake.KasikataTorihikisakiCode = this.KasikataTorihikisakiCode;
                syouhizeiSiwake.KasikataKamokuCode = this.KasikataKamokuCode;
                syouhizeiSiwake.KasikataEdabanCode = this.KasikataEdabanCode;
                syouhizeiSiwake.KasikataKouziCode = this.KasikataKouziCode;
                syouhizeiSiwake.KasikataKousyuCode = this.KasikataKousyuCode;
                syouhizeiSiwake.KasikataProjectCode = this.KasikataProjectCode;
                syouhizeiSiwake.KasikataSegmentCode = this.KasikataSegmentCode;
                syouhizeiSiwake.KasikataUniversalField1Code = this.KasikataUniversalField1Code;
                syouhizeiSiwake.KasikataUniversalField2Code = this.KasikataUniversalField2Code;
                syouhizeiSiwake.KasikataUniversalField3Code = this.KasikataUniversalField3Code;
                syouhizeiSiwake.KasikataTekiyou = this.KasikataTekiyou;
                syouhizeiSiwake.KasikataTekiyouCode = this.KasikataTekiyouCode;
                syouhizeiSiwake.KasikataUniversalField4Code = this.KasikataUniversalField4Code;
                syouhizeiSiwake.KasikataUniversalField5Code = this.KasikataUniversalField5Code;
                syouhizeiSiwake.KasikataUniversalField6Code = this.KasikataUniversalField6Code;
                syouhizeiSiwake.KasikataUniversalField7Code = this.KasikataUniversalField7Code;
                syouhizeiSiwake.KasikataUniversalField8Code = this.KasikataUniversalField8Code;
                syouhizeiSiwake.KasikataUniversalField9Code = this.KasikataUniversalField9Code;
                syouhizeiSiwake.KasikataUniversalField10Code = this.KasikataUniversalField10Code;
                syouhizeiSiwake.KasikataUniversalField11Code = this.KasikataUniversalField11Code;
                syouhizeiSiwake.KasikataUniversalField12Code = this.KasikataUniversalField12Code;
                syouhizeiSiwake.KasikataUniversalField13Code = this.KasikataUniversalField13Code;
                syouhizeiSiwake.KasikataUniversalField14Code = this.KasikataUniversalField14Code;
                syouhizeiSiwake.KasikataUniversalField15Code = this.KasikataUniversalField15Code;
                syouhizeiSiwake.KasikataUniversalField16Code = this.KasikataUniversalField16Code;
                syouhizeiSiwake.KasikataUniversalField17Code = this.KasikataUniversalField17Code;
                syouhizeiSiwake.KasikataUniversalField18Code = this.KasikataUniversalField18Code;
                syouhizeiSiwake.KasikataUniversalField19Code = this.KasikataUniversalField19Code;
                syouhizeiSiwake.KasikataUniversalField20Code = this.KasikataUniversalField20Code;
                syouhizeiSiwake.KasikataTekiyouCode = this.KasikataTekiyouCode;
                syouhizeiSiwake.KasikataTekiyou = this.KasikataTekiyou;
                syouhizeiSiwake.KasikataKazeiKubun = this.KasikataKazeiKubun;
                syouhizeiSiwake.KasikataGyousyuKubun = this.KasikataGyousyuKubun;
                syouhizeiSiwake.KasikataSiireKubun = this.KasikataSiireKubun;
                syouhizeiSiwake.KasikataZeiritu = this.KasikataZeiritu;
                syouhizeiSiwake.IsKeigenZeirituKasikata = this.IsKeigenZeirituKasikata;
                syouhizeiSiwake.KasikataHeisyuCode = this.KasikataHeisyuCode;
                if (syouhizeiSiwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku
                    && meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KasikataKamokuCode).First().AllowUseKesikomiCode)
                {
                    syouhizeiSiwake.KesikomiCode = this.KesikomiCode;
                }
            }

            // 貸借共通項目
            syouhizeiSiwake.IsTaisyakubetuTekiyou = this.IsTaisyakubetuTekiyou;
            syouhizeiSiwake.ZeitaisyouKamokuCode = this.KarikataKamokuCode;
            syouhizeiSiwake.ZeitaisyouKamokuKazeiKubun = this.KarikataKazeiKubun;
            syouhizeiSiwake.ZeitaisyouKamokuGyousyuKubun = this.KarikataGyousyuKubun;
            syouhizeiSiwake.ZeitaisyouKamokuSiireKubun = this.KarikataSiireKubun;
            syouhizeiSiwake.ZeitaisyouKamokuZeiritu = this.KarikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituZeitaisyouKamoku = this.IsKeigenZeirituKarikata;
            syouhizeiSiwake.Rate = this.Rate;

            if (this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Kasikata))
            {
                syouhizeiSiwake.Siharaibi = this.Siharaibi;
                syouhizeiSiwake.SiharaiKubun = this.SiharaiKubun;
                syouhizeiSiwake.SiharaiKizitu = this.SiharaiKizitu;
            }

            if (this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KasikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Kasikata))
            {
                syouhizeiSiwake.Kaisyuubi = this.Kaisyuubi;
                syouhizeiSiwake.NyuukinKubun = this.NyuukinKubun;
                syouhizeiSiwake.KaisyuuKizitu = this.KaisyuuKizitu;
            }

            syouhizeiSiwake.SiwakeHusen = this.SiwakeHusen;
            syouhizeiSiwake.Kingaku = this.Syouhizeigaku;
            syouhizeiSiwake.TaikaKingaku = 0;
            syouhizeiSiwake.ZeikomiKingaku = 0;
            syouhizeiSiwake.GaikaKingaku = this.GaikaZeigaku;
            syouhizeiSiwake.GaikaTaikaKingaku = 0;
            syouhizeiSiwake.GaikaZeikomiKingaku = 0;

            return syouhizeiSiwake;
        }

        private Siwake CreateKasikataBunriSiwake(SyouhizeiMaster syouhizeiMaster, IList<Kamoku> meisaiKamokuList, IList<SiharaiNyuukinKamoku> siharaiNyuukinKamokuList, Syoriki syoriki)
        {
            var syouhizeiSiwake = new Siwake(this.Kesn, this.Dkei, this.DenpyouSequenceNumber, this.SiwakeKousinsyaCode, this.SiwakeKousinHouhou);

            syouhizeiSiwake.ParentChildFlag = SiwakeParentChildRelated.Child;
            syouhizeiSiwake.SiwakeTaisyakuZokusei = this.BunriKubun == BunriKubun.HurikaeSakusei
                ? SiwakeTaisyakuZokusei.Taisyaku
                : this.SiwakeTaisyakuZokusei;

            syouhizeiSiwake.BunriKubun = this.BunriKubun;
            syouhizeiSiwake.GroupNumber = this.GroupNumber;

            // 貸方項目は分離区分によらず共通
            syouhizeiSiwake.KasikataKamokuCode = this.GetSyohizeiKamokuCode(syouhizeiMaster, meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KasikataKamokuCode).First().SyoriGroup, this.KasikataKazeiKubun);
            this.KasikataKazeiKubun = this.GetBunrigoKazeikubun(this.KasikataKazeiKubun, this.BunriKubun);

            if (syouhizeiMaster.AddBumonToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataBumonCode = this.KasikataBumonCode;
            }

            if (syouhizeiMaster.AddTorihikisakiToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataTorihikisakiCode = this.KasikataTorihikisakiCode;
            }

            if (syouhizeiMaster.AddEdabanToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataEdabanCode = this.KasikataEdabanCode;
            }

            if (syouhizeiMaster.AddProjectToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataProjectCode = this.KasikataProjectCode;
            }

            if (syouhizeiMaster.AddSegmentToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataSegmentCode = this.KasikataSegmentCode;
            }

            if (syouhizeiMaster.AddKouziToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataKouziCode = this.KasikataKouziCode;
            }

            if (syouhizeiMaster.AddKousyuToSyouhizeiSiwake)
            {
                syouhizeiSiwake.KasikataKousyuCode = this.KasikataKousyuCode;
            }

            if (syouhizeiMaster.AddUniversalField1ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 1).IsCreateMaster)
            {
                syouhizeiSiwake.KasikataUniversalField1Code = this.KasikataUniversalField1Code;
            }

            if (syouhizeiMaster.AddUniversalField2ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 2).IsCreateMaster)
            {
                syouhizeiSiwake.KasikataUniversalField2Code = this.KasikataUniversalField2Code;
            }

            if (syouhizeiMaster.AddUniversalField3ToSyouhizeiSiwake && syoriki.GetUniversalFieldInfo(false, 3).IsCreateMaster)
            {
                syouhizeiSiwake.KasikataUniversalField3Code = this.KasikataUniversalField3Code;
            }

            syouhizeiSiwake.KasikataTekiyouCode = this.KasikataTekiyouCode;
            syouhizeiSiwake.KasikataTekiyou = this.KasikataTekiyou;

            syouhizeiSiwake.KasikataKazeiKubun = KazeiKubun.消費税設定対象外;
            syouhizeiSiwake.KasikataGyousyuKubun = GyousyuKubun.None;
            syouhizeiSiwake.KasikataSiireKubun = SiwakeSiireKubun.Taisyougai;
            syouhizeiSiwake.KasikataZeiritu = this.KasikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituKasikata = this.IsKeigenZeirituKasikata;
            syouhizeiSiwake.KasikataHeisyuCode = null;

            // 振替作成
            if (this.BunriKubun == BunriKubun.HurikaeSakusei)
            {
                syouhizeiSiwake.KarikataKamokuCode = this.KasikataKamokuCode;
                syouhizeiSiwake.KarikataBumonCode = this.KasikataBumonCode;
                syouhizeiSiwake.KarikataTorihikisakiCode = this.KasikataTorihikisakiCode;
                syouhizeiSiwake.KarikataKamokuCode = this.KasikataKamokuCode;
                syouhizeiSiwake.KarikataEdabanCode = this.KasikataEdabanCode;
                syouhizeiSiwake.KarikataKouziCode = this.KasikataKouziCode;
                syouhizeiSiwake.KarikataKousyuCode = this.KasikataKousyuCode;
                syouhizeiSiwake.KarikataProjectCode = this.KasikataProjectCode;
                syouhizeiSiwake.KarikataSegmentCode = this.KasikataSegmentCode;
                syouhizeiSiwake.KarikataUniversalField1Code = this.KasikataUniversalField1Code;
                syouhizeiSiwake.KarikataUniversalField2Code = this.KasikataUniversalField2Code;
                syouhizeiSiwake.KarikataUniversalField3Code = this.KasikataUniversalField3Code;
                syouhizeiSiwake.KarikataTekiyou = this.KasikataTekiyou;
                syouhizeiSiwake.KarikataTekiyouCode = this.KasikataTekiyouCode;
                syouhizeiSiwake.KarikataUniversalField4Code = this.KasikataUniversalField4Code;
                syouhizeiSiwake.KarikataUniversalField5Code = this.KasikataUniversalField5Code;
                syouhizeiSiwake.KarikataUniversalField6Code = this.KasikataUniversalField6Code;
                syouhizeiSiwake.KarikataUniversalField7Code = this.KasikataUniversalField7Code;
                syouhizeiSiwake.KarikataUniversalField8Code = this.KasikataUniversalField8Code;
                syouhizeiSiwake.KarikataUniversalField9Code = this.KasikataUniversalField9Code;
                syouhizeiSiwake.KarikataUniversalField10Code = this.KasikataUniversalField10Code;
                syouhizeiSiwake.KarikataUniversalField11Code = this.KasikataUniversalField11Code;
                syouhizeiSiwake.KarikataUniversalField12Code = this.KasikataUniversalField12Code;
                syouhizeiSiwake.KarikataUniversalField13Code = this.KasikataUniversalField13Code;
                syouhizeiSiwake.KarikataUniversalField14Code = this.KasikataUniversalField14Code;
                syouhizeiSiwake.KarikataUniversalField15Code = this.KasikataUniversalField15Code;
                syouhizeiSiwake.KarikataUniversalField16Code = this.KasikataUniversalField16Code;
                syouhizeiSiwake.KarikataUniversalField17Code = this.KasikataUniversalField17Code;
                syouhizeiSiwake.KarikataUniversalField18Code = this.KasikataUniversalField18Code;
                syouhizeiSiwake.KarikataUniversalField19Code = this.KasikataUniversalField19Code;
                syouhizeiSiwake.KarikataUniversalField20Code = this.KasikataUniversalField20Code;
                syouhizeiSiwake.KarikataTekiyouCode = this.KasikataTekiyouCode;
                syouhizeiSiwake.KarikataTekiyou = this.KasikataTekiyou;
                syouhizeiSiwake.KarikataKazeiKubun = KazeiKubun.対象外;
                syouhizeiSiwake.KarikataGyousyuKubun = GyousyuKubun.None;
                syouhizeiSiwake.KarikataSiireKubun = SiwakeSiireKubun.Taisyougai;
                syouhizeiSiwake.KarikataZeiritu = null;
                syouhizeiSiwake.IsKeigenZeirituKarikata = false;
                syouhizeiSiwake.KarikataHeisyuCode = this.KasikataHeisyuCode;
                if (meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KasikataKamokuCode).First().AllowUseKesikomiCode)
                {
                    syouhizeiSiwake.KesikomiCode = this.KesikomiCode;
                }
            }

            // 自動分離、税作成
            else
            {
                syouhizeiSiwake.KarikataKamokuCode = this.KarikataKamokuCode;
                syouhizeiSiwake.KarikataBumonCode = this.KarikataBumonCode;
                syouhizeiSiwake.KarikataTorihikisakiCode = this.KarikataTorihikisakiCode;
                syouhizeiSiwake.KarikataKamokuCode = this.KarikataKamokuCode;
                syouhizeiSiwake.KarikataEdabanCode = this.KarikataEdabanCode;
                syouhizeiSiwake.KarikataKouziCode = this.KarikataKouziCode;
                syouhizeiSiwake.KarikataKousyuCode = this.KarikataKousyuCode;
                syouhizeiSiwake.KarikataProjectCode = this.KarikataProjectCode;
                syouhizeiSiwake.KarikataSegmentCode = this.KarikataSegmentCode;
                syouhizeiSiwake.KarikataUniversalField1Code = this.KarikataUniversalField1Code;
                syouhizeiSiwake.KarikataUniversalField2Code = this.KarikataUniversalField2Code;
                syouhizeiSiwake.KarikataUniversalField3Code = this.KarikataUniversalField3Code;
                syouhizeiSiwake.KarikataTekiyou = this.KarikataTekiyou;
                syouhizeiSiwake.KarikataTekiyouCode = this.KarikataTekiyouCode;
                syouhizeiSiwake.KarikataUniversalField4Code = this.KarikataUniversalField4Code;
                syouhizeiSiwake.KarikataUniversalField5Code = this.KarikataUniversalField5Code;
                syouhizeiSiwake.KarikataUniversalField6Code = this.KarikataUniversalField6Code;
                syouhizeiSiwake.KarikataUniversalField7Code = this.KarikataUniversalField7Code;
                syouhizeiSiwake.KarikataUniversalField8Code = this.KarikataUniversalField8Code;
                syouhizeiSiwake.KarikataUniversalField9Code = this.KarikataUniversalField9Code;
                syouhizeiSiwake.KarikataUniversalField10Code = this.KarikataUniversalField10Code;
                syouhizeiSiwake.KarikataUniversalField11Code = this.KarikataUniversalField11Code;
                syouhizeiSiwake.KarikataUniversalField12Code = this.KarikataUniversalField12Code;
                syouhizeiSiwake.KarikataUniversalField13Code = this.KarikataUniversalField13Code;
                syouhizeiSiwake.KarikataUniversalField14Code = this.KarikataUniversalField14Code;
                syouhizeiSiwake.KarikataUniversalField15Code = this.KarikataUniversalField15Code;
                syouhizeiSiwake.KarikataUniversalField16Code = this.KarikataUniversalField16Code;
                syouhizeiSiwake.KarikataUniversalField17Code = this.KarikataUniversalField17Code;
                syouhizeiSiwake.KarikataUniversalField18Code = this.KarikataUniversalField18Code;
                syouhizeiSiwake.KarikataUniversalField19Code = this.KarikataUniversalField19Code;
                syouhizeiSiwake.KarikataUniversalField20Code = this.KarikataUniversalField20Code;
                syouhizeiSiwake.KarikataTekiyouCode = this.KarikataTekiyouCode;
                syouhizeiSiwake.KarikataTekiyou = this.KarikataTekiyou;
                syouhizeiSiwake.KarikataKazeiKubun = this.KarikataKazeiKubun;
                syouhizeiSiwake.KarikataGyousyuKubun = this.KarikataGyousyuKubun;
                syouhizeiSiwake.KarikataSiireKubun = this.KarikataSiireKubun;
                syouhizeiSiwake.KarikataZeiritu = this.KarikataZeiritu;
                syouhizeiSiwake.IsKeigenZeirituKarikata = this.IsKeigenZeirituKarikata;
                syouhizeiSiwake.KarikataHeisyuCode = this.KarikataHeisyuCode;
                if (syouhizeiSiwake.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku
                    && meisaiKamokuList.Where(meisaiKamoku => meisaiKamoku.Kicd == this.KarikataKamokuCode).First().AllowUseKesikomiCode)
                {
                    syouhizeiSiwake.KesikomiCode = this.KesikomiCode;
                }
            }

            // 貸借共通項目
            syouhizeiSiwake.IsTaisyakubetuTekiyou = this.IsTaisyakubetuTekiyou;
            syouhizeiSiwake.ZeitaisyouKamokuCode = this.KasikataKamokuCode;
            syouhizeiSiwake.ZeitaisyouKamokuKazeiKubun = this.KasikataKazeiKubun;
            syouhizeiSiwake.ZeitaisyouKamokuGyousyuKubun = this.KasikataGyousyuKubun;
            syouhizeiSiwake.ZeitaisyouKamokuSiireKubun = this.KasikataSiireKubun;
            syouhizeiSiwake.ZeitaisyouKamokuZeiritu = this.KasikataZeiritu;
            syouhizeiSiwake.IsKeigenZeirituZeitaisyouKamoku = this.IsKeigenZeirituKasikata;
            syouhizeiSiwake.Rate = this.Rate;

            if (this.CanAddSiharaiKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                syouhizeiSiwake.Siharaibi = this.Siharaibi;
                syouhizeiSiwake.SiharaiKubun = this.SiharaiKubun;
                syouhizeiSiwake.SiharaiKizitu = this.SiharaiKizitu;
            }

            if (this.CanAddNyuukinKubun(siharaiNyuukinKamokuList, syouhizeiSiwake.KarikataKamokuCode, SiharaiNyuukinKamokuTaisyakuZokusei.Karikata))
            {
                syouhizeiSiwake.Kaisyuubi = this.Kaisyuubi;
                syouhizeiSiwake.NyuukinKubun = this.NyuukinKubun;
                syouhizeiSiwake.KaisyuuKizitu = this.KaisyuuKizitu;
            }

            syouhizeiSiwake.SiwakeHusen = this.SiwakeHusen;
            syouhizeiSiwake.Kingaku = this.Syouhizeigaku;
            syouhizeiSiwake.TaikaKingaku = 0;
            syouhizeiSiwake.ZeikomiKingaku = 0;
            syouhizeiSiwake.GaikaKingaku = this.GaikaZeigaku;
            syouhizeiSiwake.GaikaTaikaKingaku = 0;
            syouhizeiSiwake.GaikaZeikomiKingaku = 0;

            return syouhizeiSiwake;
        }

        private bool IsBunriKubunInputtableKazeiKubun(KazeiKubun kazeiKubun)
        {
            switch (kazeiKubun)
            {
                case KazeiKubun.対象外:
                case KazeiKubun.免税:
                case KazeiKubun.非課税:
                case KazeiKubun.貨国税:
                case KazeiKubun.貨地方税:
                case KazeiKubun.特課仕入:
                case KazeiKubun.控外仕入:
                case KazeiKubun.消費税設定対象外:
                    return false;
            }

            return true;
        }

        #endregion
    }
}
