﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class ZidouhubanGroup
    {
        public ZidouhubanGroup(int kesn, int funo)
        {
            this.Kesn = kesn;
            this.Funo = funo;
        }

        #region properties

        public int Kesn { get; private set; }

        public int Funo { get; private set; }

        public int Fgno { get; set; }
        #endregion
    }
}
