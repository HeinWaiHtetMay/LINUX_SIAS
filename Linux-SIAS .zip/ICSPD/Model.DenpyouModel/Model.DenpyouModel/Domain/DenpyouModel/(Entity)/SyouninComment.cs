﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using Icsp.Open21.Domain.DateTimeModel;

    [Serializable]
    public class SyouninComment : ICreatedAndLastUpdatedYmdHmsEntity
    {
        public SyouninComment(int kesn, int keik, int dseq, int sseq, int cseq)
        {
            this.Kesn = kesn;
            this.Keik = keik;
            this.Dseq = dseq;
            this.Sseq = sseq;
            this.Cseq = cseq;
        }

        #region public properties

        public bool IsNew { get => this.Cymd == 0 && this.Ctim == 0; }

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 経過月（カラム名：keik）
        /// </summary>
        public int Keik { get; private set; }

        /// <summary>
        /// 伝票seq（カラム名：dseq）
        /// </summary>
        public int Dseq { get; private set; }

        /// <summary>
        /// 仕訳seq（カラム名：sseq）
        /// </summary>
        public int Sseq { get; private set; }

        /// <summary>
        /// ｺﾒﾝﾄseq（カラム名：cseq）
        /// </summary>
        public int Cseq { get; private set; }

        /// <summary>
        /// ｺﾒﾝﾄ入力者（カラム名：cuno）
        /// </summary>
        public int CommentInputUserCode { get; set; }

        /// <summary>
        /// 承認ﾌﾗｸﾞ（カラム名：cflg）
        /// </summary>
        public SyouninStatus SyouninFlag { get; set; }

        /// <summary>
        /// 承認者編集（カラム名：cmnt）
        /// </summary>
        public bool IsEditedSyouninsya { get; set; }

        /// <summary>
        /// ｺﾒﾝﾄ入力日（カラム名：cymd）
        /// </summary>
        public int Cymd { get; set; }

        /// <summary>
        /// ｺﾒﾝﾄ入力時分秒（カラム名：ctim）
        /// </summary>
        public int Ctim { get; set; }

        /// <summary>
        /// ｺﾒﾝﾄ1（カラム名：cmt1）
        /// ｺﾒﾝﾄ2（カラム名：cmt2）
        /// ｺﾒﾝﾄ3（カラム名：cmt3）
        /// ｺﾒﾝﾄ4（カラム名：cmt4）
        /// </summary>
        public string Comment { get; set; }

        #region implements ICreatedAndLastUpdatedYmdHmsEntity
        public int CreatedYmd { get => this.Cymd; set => this.Cymd = value; }

        public int CreatedHms { get => this.Ctim; set => this.Ctim = value; }

        public int LastUpdatedYmd { get => this.Cymd; set => this.Cymd = value; }

        public int LastUpdatedHms { get => this.Ctim; set => this.Ctim = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Centisecond;
        #endregion

        #endregion

        public SyouninComment SetKeik(int keik)
        {
            this.Keik = keik;
            return this;
        }

        public SyouninComment SetDseq(int dseq)
        {
            this.Dseq = dseq;
            return this;
        }

        public SyouninComment SetSseq(int sseq)
        {
            this.Sseq = sseq;
            return this;
        }
    }
}