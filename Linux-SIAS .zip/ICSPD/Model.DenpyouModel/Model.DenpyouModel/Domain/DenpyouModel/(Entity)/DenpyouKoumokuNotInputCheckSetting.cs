﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class DenpyouKoumokuNotInputCheckSetting
    {
        public bool IsUseKihyousyaNotInputCheck { get; set; }

        public bool IsUseKihyouBumonNotInputCheck { get; set; }

        public bool IsUseHeaderField1NotInputCheck { get; set; }

        public bool IsUseHeaderField2NotInputCheck { get; set; }

        public bool IsUseHeaderField3NotInputCheck { get; set; }

        public bool IsUseHeaderField4NotInputCheck { get; set; }

        public bool IsUseHeaderField5NotInputCheck { get; set; }

        public bool IsUseHeaderField6NotInputCheck { get; set; }

        public bool IsUseHeaderField7NotInputCheck { get; set; }

        public bool IsUseHeaderField8NotInputCheck { get; set; }

        public bool IsUseHeaderField9NotInputCheck { get; set; }

        public bool IsUseHeaderField10NotInputCheck { get; set; }

        public bool IsUseTaikaNotInputCheck { get; set; }
    }
}
