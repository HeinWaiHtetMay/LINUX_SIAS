﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IEdocumentSearchItemRepository
    {
        /// <summary>
        /// 内部決算期を条件として、e文書検索項目を取得します。
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <returns>e文書検索項目リスト</returns>
        IList<EdocumentSearchItem> FindByKesn(int kesn);

        /// <summary>
        /// e文書に紐づく全検索情報を削除
        /// </summary>
        /// <param name="edocument"></param>
        /// <returns></returns>
        bool Delete(Edocument edocument);

        /// <summary>
        /// e文書に紐づくe文書検索項目を取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="edoc"></param>
        /// <returns></returns>
        IList<EdocumentSearchItem> FindByKesnAndEdocOrderByEseq(int kesn, string edoc);

        /// <summary>
        /// e文書検索項目を追加
        /// </summary>
        /// <param name="edocumentSearchItem"></param>
        /// <returns></returns>
        bool Insert(EdocumentSearchItem edocumentSearchItem);
    }
}