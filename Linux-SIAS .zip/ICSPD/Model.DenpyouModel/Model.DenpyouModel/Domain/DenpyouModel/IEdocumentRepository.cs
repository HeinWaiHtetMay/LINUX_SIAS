﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.SecurityModel;

    public interface IEdocumentRepository
    {
        Edocument FindByKesnAndEdoc(int kesn, string edoc);

        IList<Edocument> FindNotLinkedEdocumentByKesn(int kesn, DenpyouType denpyouType);

        bool GetExistByKesnAndEdoc(int kesn, string edoc);

        /// <summary>
        /// e文書とそれに紐づくe文書項目全件の登録
        /// </summary>
        /// <param name="edocument"></param>
        void Insert(Edocument edocument);

        /// <summary>
        /// e文書とそれに紐づくe文書項目全件の更新
        /// </summary>
        /// <param name="edocument"></param>
        void Update(Edocument edocument);

        /// <summary>
        /// 最終承認者名称を更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="lastSyouninUser">最終承認者</param>
        void UpdateLastSyouninUserName(Denpyou denpyou, User lastSyouninUser);
    }
}