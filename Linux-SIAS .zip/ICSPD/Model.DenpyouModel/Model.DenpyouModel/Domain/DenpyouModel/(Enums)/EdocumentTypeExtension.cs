﻿using Icsp.Open21.Domain.DateTimeModel;
using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class EdocumentTypeExtension
    {
        public static string GetName(this EdocumentType edocumentType)
        {
            switch (edocumentType)
            {
                case EdocumentType.Receipt:
                    return "領収書";

                case EdocumentType.Invoice:
                    return "請求書";

                case EdocumentType.Contract:
                    return "契約書";

                case EdocumentType.DeliverySlip:
                    return "納品書";

                case EdocumentType.PurchaseOrder:
                    return "注文書";

                case EdocumentType.Quotation:
                    return "見積書";

                case EdocumentType.ReceiptCopy:
                    return "領収書控";

                case EdocumentType.InvoiceCopy:
                    return "請求書控";

                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// タイムスタンプ付与が必要な書類種別かチェック
        /// </summary>
        /// <param name="edocumentType"></param>
        /// <param name="timeStampSetting"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool NeedTimeStamp(this EdocumentType edocumentType, TimeStampSetting timeStampSetting, IcspDateTime date)
        {
            IcspDateTime startDate = null;
            IcspDateTime endDate = null;

            switch (edocumentType)
            {
                case EdocumentType.Receipt:
                    startDate = timeStampSetting.ReceiptTimeStampStartDate;
                    endDate = timeStampSetting.ReceiptEdocumentApplicationEndDate;
                    break;
                case EdocumentType.Invoice:
                    startDate = timeStampSetting.InvoiceTimeStampStartDate;
                    endDate = timeStampSetting.InvoiceEdocumentApplicationEndDate;
                    break;
                case EdocumentType.Contract:
                    startDate = timeStampSetting.ContractTimeStampStartDate;
                    endDate = timeStampSetting.ContractEdocumentApplicationEndDate;
                    break;
                case EdocumentType.DeliverySlip:
                    startDate = timeStampSetting.DeliverySlipTimeStampStartDate;
                    endDate = timeStampSetting.DeliverySlipEdocumentApplicationEndDate;
                    break;
                case EdocumentType.PurchaseOrder:
                    startDate = timeStampSetting.PurchaseOrderTimeStampStartDate;
                    endDate = timeStampSetting.PurchaseOrderEdocumentApplicationEndDate;
                    break;
                case EdocumentType.Quotation:
                    startDate = timeStampSetting.QuotationTimeStampStartDate;
                    endDate = timeStampSetting.QuotationEdocumentApplicationEndDate;
                    break;
                case EdocumentType.ReceiptCopy:
                    startDate = timeStampSetting.ReceiptCopyTimeStampStartDate;
                    endDate = timeStampSetting.ReceiptCopyEdocumentApplicationEndDate;
                    break;
                case EdocumentType.InvoiceCopy:
                    startDate = timeStampSetting.InvoiceCopyTimeStampStartDate;
                    endDate = timeStampSetting.InvoiceCopyEdocumentApplicationEndDate;
                    break;
            }

            return startDate != null && startDate.CompareTo(date) < 1 && (endDate == null || endDate.CompareTo(date) == 1);
        }
    }
}
