﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum DenpyouSiwakeWayToCreate
    {
        /// <summary>
        /// 伝票入力
        /// </summary>
        Dinpfri = 2,

        /// <summary>
        /// 部門経費入力
        /// </summary>
        Dinpbkei = 3,

        /// <summary>
        /// 元帳
        /// </summary>
        Ledmain = 101,

        /// <summary>
        /// データスキャン
        /// </summary>
        Dscan = 102,

        /// <summary>
        /// チェックリスト
        /// </summary>
        Chkmain = 103,

        /// <summary>
        /// 仕訳日記帳
        /// </summary>
        Nikkmain = 104,

        /// <summary>
        /// 外貨元帳
        /// </summary>
        Gledmain = 110,

        /// <summary>
        /// 伝票入力(部署)
        /// </summary>
        Sfdinpfri = 202,

        /// <summary>
        /// 部門経費入力(部署)
        /// </summary>
        Sfdinpbkei = 203,

        /// <summary>
        /// 入力確定・チェックリスト
        /// </summary>
        Sfchkmain = 301,

        /// <summary>
        /// 承認処理
        /// </summary>
        Sfsyonin = 302,

        /// <summary>
        /// 財務転記
        /// </summary>
        Sfzaimu = 303,

        /// <summary>
        /// 元帳(未転記データ含む)
        /// </summary>
        Sfledmain = 401,

        /// <summary>
        /// データスキャン(部署)
        /// </summary>
        Sdscan = 402,

        /// <summary>
        /// チェックリスト(部署)
        /// </summary>
        ExChkmain = 403,

        /// <summary>
        /// 仕訳日記帳(部署)
        /// </summary>
        ExNikkmain = 404,

        /// <summary>
        /// 外貨元帳(未転記データ含む)
        /// </summary>
        Sfgledmain = 410,

        /// <summary>
        /// データコミュニケーション
        /// </summary>
        Dtcomin = 601,

        /// <summary>
        /// OpenToOpen
        /// </summary>
        Dtcomlin = 602,

        /// <summary>
        /// データ抽出
        /// </summary>
        Ndpick = 603,

        /// <summary>
        /// インポーター
        /// </summary>
        Import = 604,

        /// <summary>
        /// データ取消
        /// </summary>
        Datadel = 605,

        /// <summary>
        /// データコミュニケーション(部署)
        /// </summary>
        Sfdtcomin = 701,

        /// <summary>
        /// インポーター(部署)
        /// </summary>
        Sfimport = 704,

        /// <summary>
        /// 一括税抜処理
        /// </summary>
        Stznk = 801,

        /// <summary>
        /// 一括税抜取消
        /// </summary>
        Stzdl = 802,

        /// <summary>
        /// 消費税額試算表
        /// </summary>
        Syzdsp = 803,

        /// <summary>
        /// 外貨換算仕訳作成
        /// </summary>
        Gkswk = 810,

        /// <summary>
        /// コンバージョン
        /// </summary>
        Msconv = 901,

        /// <summary>
        /// 固定資産　償却費仕訳
        /// </summary>
        KtSyoukyaku = 2011,

        /// <summary>
        /// 固定資産　除却仕訳
        /// </summary>
        KtJyokyaku = 2012,

        /// <summary>
        /// 固定資産　購入・除適初
        /// </summary>
        KtKounyu = 2021,

        /// <summary>
        /// 固定資産　売却仕訳
        /// </summary>
        KtBaikyaku = 2022,

        /// <summary>
        /// 固定資産　減損仕訳
        /// </summary>
        KtGenson = 2031,

        /// <summary>
        /// 固定資産　除去債務履行仕訳
        /// </summary>
        KtJyokyo = 2041,

        /// <summary>
        /// リース資産仕訳
        /// </summary>
        KtLease = 2051,

        /// <summary>
        /// 固定資産(部署)　償却費仕訳
        /// </summary>
        KtSFSyoukyaku = 2111,

        /// <summary>
        /// 固定資産(部署)　除却仕訳
        /// </summary>
        KtSFJyokyaku = 2112,

        /// <summary>
        /// 固定資産(部署)　購入・除適初
        /// </summary>
        KtSFKounyu = 2121,

        /// <summary>
        /// 固定資産(部署)　売却仕訳
        /// </summary>
        KtSFbaikyaku = 2122,

        /// <summary>
        /// 固定資産(部署)　減損仕訳
        /// </summary>
        KtSFGenson = 2131,

        /// <summary>
        /// 固定資産(部署)除去債務履行
        /// </summary>
        KtSFJyokyo = 2141,

        /// <summary>
        /// リース資産仕訳(部署)
        /// </summary>
        KtSFLease = 2151,

        /// <summary>
        /// 売上計上仕訳
        /// </summary>
        SaSeikyu = 4001,

        /// <summary>
        /// 入金仕訳
        /// </summary>
        SaNyukin = 4011,

        /// <summary>
        /// 消込仕訳
        /// </summary>
        SaKesikm = 4021,

        /// <summary>
        /// 債権　長期前受仕訳
        /// </summary>
        SaTyouki = 4031,

        /// <summary>
        /// 債権　売上計上仕訳(部署)
        /// </summary>
        SaSFSeikyu = 4101,

        /// <summary>
        /// 債権　入金仕訳(部署)
        /// </summary>
        SaSFNyukin = 4111,

        /// <summary>
        /// 債権　消込仕訳(部署)
        /// </summary>
        SaSFKesikm = 4121,

        /// <summary>
        /// 債権　長期前受仕訳(部署)
        /// </summary>
        SaSFTyouki = 4131,

        /// <summary>
        /// ＦＢ自動仕訳
        /// </summary>
        FbAutoData = 5001,

        /// <summary>
        /// ＦＢ自動仕訳(部署)
        /// </summary>
        FbSFAutoData = 5101,

        /// <summary>
        /// 消込自動付番
        /// </summary>
        KsKssFubn = 6001,

        /// <summary>
        /// 消込処理
        /// </summary>
        KsKssInput = 6002,

        /// <summary>
        /// 債務　債務計上仕訳
        /// </summary>
        SmSaimukj = 7001,

        /// <summary>
        /// 債務　支払計上仕訳
        /// </summary>
        SmShiharaikj = 7002,

        /// <summary>
        /// 債務　支払決済仕訳
        /// </summary>
        SmTegatadat = 7004,

        /// <summary>
        /// 債務　手形管理データ入力
        /// </summary>
        SmTegatakbn = 7005,

        /// <summary>
        /// 債務　手形区分変更
        /// </summary>
        SmTegataks = 7006,

        /// <summary>
        /// 債務　手形決済仕訳
        /// </summary>
        SmSFSaimukj = 7101,

        /// <summary>
        /// 債務　債務計上仕訳(部署)
        /// </summary>
        SmSFShiharaikj = 7102,

        /// <summary>
        /// 債務　手形管理ﾃﾞｰﾀ入力(部署)
        /// </summary>
        SmSFTegatadat = 7104,

        /// <summary>
        /// 債務　手形区分変更(部署)
        /// </summary>
        SmSFTegatakbn = 7105,

        /// <summary>
        /// 債務　手形決済仕訳(部署)
        /// </summary>
        SmSFTegataks = 7106,

        /// <summary>
        /// 連結　合算自動仕訳
        /// </summary>
        CsGassan = 8011,

        /// <summary>
        /// 連結　照合相殺自動仕訳
        /// </summary>
        CsSousai = 8012,

        /// <summary>
        /// 連結　照合相殺振戻自動仕訳
        /// </summary>
        CsFurimodoshi = 8013,

        /// <summary>
        /// 人事給与
        /// </summary>
        Kyuyo = 8021,

        /// <summary>
        /// 人事給与(部署)
        /// </summary>
        SfKyuyo = 8022,

        /// <summary>
        /// ワークフロー
        /// </summary>
        WF = 8041,

        /// <summary>
        /// ワークフロー(部署)
        /// </summary>
        SfWF = 8042,

        /// <summary>
        /// BtoB連携
        /// </summary>
        BtoBRenkei = 8051,

        /// <summary>
        /// BtoB連携(部署)
        /// </summary>
        SfBtoBRenkei = 8052,

        /// <summary>
        /// Accontech OCR
        /// </summary>
        AIOCR = 8061,

        /// <summary>
        /// Accontech OCR(部署)
        /// </summary>
        SfAIOCR = 8062,

        /// <summary>
        /// アドオン
        /// </summary>
        Adon = 9001,

        /// <summary>
        /// アドオン(部署)
        /// </summary>
        SfAdon = 9101,

        /// <summary>
        /// 取引明細照合
        /// 伝票修正の起動が可能なのみで伝票の登録は不可能
        /// </summary>
        Cmsyogo = 99999,
    }
}
