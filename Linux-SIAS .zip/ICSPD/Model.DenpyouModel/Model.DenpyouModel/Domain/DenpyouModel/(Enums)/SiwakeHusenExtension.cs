﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Drawing;

    public static class SiwakeHusenExtension
    {
        /// <summary>
        /// 付箋のSystem.Drawing.Colorを取得します
        /// </summary>
        /// <param name="siwakeHusen"></param>
        /// <returns></returns>
        public static Color GetColor(this SiwakeHusen siwakeHusen)
        {
            switch (siwakeHusen)
            {
                case SiwakeHusen.Nothing:
                    return Color.Transparent;
                case SiwakeHusen.Red:
                    return Color.Red;
                case SiwakeHusen.DarkRed:
                    return Color.DarkRed;
                case SiwakeHusen.Magenta:
                    return Color.Magenta;
                case SiwakeHusen.Purple:
                    return Color.Purple;
                case SiwakeHusen.Lime:
                    return Color.Lime;
                case SiwakeHusen.DarkGreen:
                    return Color.DarkGreen;
                case SiwakeHusen.Yellow:
                    return Color.Yellow;
                case SiwakeHusen.Cyan:
                    return Color.Cyan;
                case SiwakeHusen.Blue:
                    return Color.Blue;
                case SiwakeHusen.DarkBlue:
                    return Color.DarkBlue;
                default:
                    return Color.Transparent;
            }
        }

        /// <summary>
        /// 付箋の名称を取得します
        /// </summary>
        /// <param name="siwakeHusen"></param>
        /// <returns></returns>
        public static string GetName(this SiwakeHusen siwakeHusen)
        {
            switch (siwakeHusen)
            {
                case SiwakeHusen.Red:
                    return "赤";
                case SiwakeHusen.DarkRed:
                    return "濃赤";
                case SiwakeHusen.Magenta:
                    return "薄紫";
                case SiwakeHusen.Purple:
                    return "紫";
                case SiwakeHusen.Lime:
                    return "緑";
                case SiwakeHusen.DarkGreen:
                    return "濃緑";
                case SiwakeHusen.Yellow:
                    return "黄";
                case SiwakeHusen.Cyan:
                    return "水";
                case SiwakeHusen.Blue:
                    return "青";
                case SiwakeHusen.DarkBlue:
                    return "濃青";
                default:
                    return string.Empty;
            }
        }
    }
}
