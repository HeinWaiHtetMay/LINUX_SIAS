﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.DenpyouModel
{
    /// <summary>
    /// 仕訳親子関係
    /// </summary>
    public enum SiwakeParentChildRelated
    {
        /// <summary>
        /// なし
        /// </summary>
        Nothing = 0,

        /// <summary>
        /// 親仕訳
        /// </summary>
        Parent = 1,

        /// <summary>
        /// 子仕訳
        /// </summary>
        Child = 2
    }
}
