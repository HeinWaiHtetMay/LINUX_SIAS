﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum EdocumentType
    {
        /// <summary>
        /// 領収書
        /// </summary>
        Receipt = 0,

        /// <summary>
        /// 請求書
        /// </summary>
        Invoice = 1,

        /// <summary>
        /// 契約書
        /// </summary>
        Contract = 2,

        /// <summary>
        /// 納品書
        /// </summary>
        DeliverySlip = 3,

        /// <summary>
        /// 注文書
        /// </summary>
        PurchaseOrder = 4,

        /// <summary>
        /// 見積書
        /// </summary>
        Quotation = 5,

        /// <summary>
        /// 領収書控
        /// </summary>
        ReceiptCopy = 6,

        /// <summary>
        /// 請求書控
        /// </summary>
        InvoiceCopy = 7,
    }
}
