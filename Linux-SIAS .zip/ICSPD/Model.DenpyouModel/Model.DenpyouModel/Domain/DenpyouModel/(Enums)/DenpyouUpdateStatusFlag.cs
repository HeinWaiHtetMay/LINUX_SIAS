﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum DenpyouUpdateStatusFlag
    {
        NoModified = 0,
        Modified = 1,
        ModifiedOnlyLineNo = 2,
        NoOutputTargetData = 3,
    }
}
