﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum PrintedFlag
    {
        NotPrinted = 0,
        Printed = 1,
        UpdatedAfterPrinting = 2,
    }
}
