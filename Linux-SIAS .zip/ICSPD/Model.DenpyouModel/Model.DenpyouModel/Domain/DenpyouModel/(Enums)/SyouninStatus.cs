﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    /// <summary>
    /// 承認判定
    /// </summary>
    public enum SyouninStatus
    {
        /// <summary>
        /// その他
        /// </summary>
        Other = 0,

        /// <summary>
        /// 承認
        /// </summary>
        Syounin = 1,

        /// <summary>
        /// 否認修正
        /// </summary>
        HininSyuusei = 2,

        /// <summary>
        /// 否認削除
        /// </summary>
        HininSakuzyo = 3,
    }
}
