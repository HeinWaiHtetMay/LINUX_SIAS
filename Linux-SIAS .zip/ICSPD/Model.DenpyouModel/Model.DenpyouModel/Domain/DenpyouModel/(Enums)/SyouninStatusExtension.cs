﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class SyouninStatusExtension
    {
        public static string GetSyouninStatusString(this SyouninStatus syouninHantei)
        {
            switch (syouninHantei)
            {
                case SyouninStatus.Syounin:
                    return "承認";

                case SyouninStatus.HininSyuusei:
                    return "否認修正";

                case SyouninStatus.HininSakuzyo:
                    return "否認削除";

                default:
                    return string.Empty;
            }
        }
    }
}
