﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class DenpyouKeisikiExtension
    {
        public static string GetShortName(this DenpyouKeisiki denpyouKeisiki)
        {
            switch (denpyouKeisiki)
            {
                case DenpyouKeisiki.Hukugou:
                    return "複合";
                default:
                    return "単一";
            }
        }

        public static string GetDenpyouName(this DenpyouKeisiki denpyouKeisiki)
        {
            switch (denpyouKeisiki)
            {
                case DenpyouKeisiki.Hukugou:
                    return "複合伝票";
                default:
                    return "単一伝票";
            }
        }

        public static string GetSiwakeName(this DenpyouKeisiki denpyouKeisiki)
        {
            switch (denpyouKeisiki)
            {
                case DenpyouKeisiki.Hukugou:
                    return "複合仕訳";
                default:
                    return "単一仕訳";
            }
        }
    }
}
