﻿using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class DenpyouSiwakeWayToCreateExtension
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        public static string GetName(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate)
        {
            switch (denpyouSiwakeWayToCreate)
            {
                case DenpyouSiwakeWayToCreate.Dinpfri:
                    return "伝票入力";

                case DenpyouSiwakeWayToCreate.Dinpbkei:
                    return "部門経費入力";

                case DenpyouSiwakeWayToCreate.Ledmain:
                    return "元帳";

                case DenpyouSiwakeWayToCreate.Dscan:
                    return "ﾃﾞｰﾀｽｷｬﾝ";

                case DenpyouSiwakeWayToCreate.Chkmain:
                    return "ﾁｪｯｸﾘｽﾄ";

                case DenpyouSiwakeWayToCreate.Nikkmain:
                    return "仕訳日記帳";

                case DenpyouSiwakeWayToCreate.Gledmain:
                    return "外貨元帳";

                case DenpyouSiwakeWayToCreate.Sfdinpfri:
                    return "伝票入力(部署)";

                case DenpyouSiwakeWayToCreate.Sfdinpbkei:
                    return "部門経費入力(部署)";

                case DenpyouSiwakeWayToCreate.Sfchkmain:
                    // 入力確定チェックリスト
                    return "仕訳確定(部署)";

                case DenpyouSiwakeWayToCreate.Sfsyonin:
                    return "承認処理(部署)";

                case DenpyouSiwakeWayToCreate.Sfzaimu:
                    return "財務転記(部署)";

                case DenpyouSiwakeWayToCreate.Sfledmain:
                    return "元帳(部署)";

                case DenpyouSiwakeWayToCreate.Sdscan:
                    return "ﾃﾞｰﾀｽｷｬﾝ(部署)";

                case DenpyouSiwakeWayToCreate.ExChkmain:
                    return "ﾁｪｯｸﾘｽﾄ(部署)";

                case DenpyouSiwakeWayToCreate.ExNikkmain:
                    return "仕訳日記帳(部署)";

                case DenpyouSiwakeWayToCreate.Sfgledmain:
                    return "外貨元帳(部署)";

                case DenpyouSiwakeWayToCreate.Dtcomin:
                    return "ﾃﾞｰﾀｺﾐｭﾆｹｰｼｮﾝ";

                case DenpyouSiwakeWayToCreate.Dtcomlin:
                    return "OpenToOpen";

                case DenpyouSiwakeWayToCreate.Ndpick:
                    return "ﾃﾞｰﾀ抽出";

                case DenpyouSiwakeWayToCreate.Import:
                    return "ｲﾝﾎﾟｰﾀｰ";

                case DenpyouSiwakeWayToCreate.Datadel:
                    return "ﾃﾞｰﾀ取消";

                case DenpyouSiwakeWayToCreate.Sfdtcomin:
                    return "ﾃﾞｰﾀｺﾐｭﾆｹｰｼｮﾝ(部署)";

                case DenpyouSiwakeWayToCreate.Sfimport:
                    return "ｲﾝﾎﾟｰﾀｰ(部署)";

                case DenpyouSiwakeWayToCreate.Stznk:
                    return "一括税抜処理";

                case DenpyouSiwakeWayToCreate.Stzdl:
                    return "一括税抜取消";

                case DenpyouSiwakeWayToCreate.Syzdsp:
                    return "消費税額試算表";

                case DenpyouSiwakeWayToCreate.Gkswk:
                    return "外貨換算仕訳作成";

                case DenpyouSiwakeWayToCreate.Msconv:
                    return "ｺﾝﾊﾞｰｼﾞｮﾝ";

                case DenpyouSiwakeWayToCreate.KtSyoukyaku:
                    return "固定資産　償却費仕訳";

                case DenpyouSiwakeWayToCreate.KtJyokyaku:
                    return "固定資産　除却仕訳";

                case DenpyouSiwakeWayToCreate.KtKounyu:
                    return "固定資産　購入・除適初";

                case DenpyouSiwakeWayToCreate.KtBaikyaku:
                    return "固定資産　売却仕訳";

                case DenpyouSiwakeWayToCreate.KtGenson:
                    return "固定資産　減損仕訳";

                case DenpyouSiwakeWayToCreate.KtJyokyo:
                    return "固定資産　除去債務履行仕訳";

                case DenpyouSiwakeWayToCreate.KtLease:
                    return "リース資産仕訳";

                case DenpyouSiwakeWayToCreate.KtSFSyoukyaku:
                    return "固定資産(部署)　償却費仕訳";

                case DenpyouSiwakeWayToCreate.KtSFJyokyaku:
                    return "固定資産(部署)　除却仕訳";

                case DenpyouSiwakeWayToCreate.KtSFKounyu:
                    return "固定資産(部署)　購入・除適初";

                case DenpyouSiwakeWayToCreate.KtSFbaikyaku:
                    return "固定資産(部署)　売却仕訳";

                case DenpyouSiwakeWayToCreate.KtSFGenson:
                    return "固定資産(部署)　減損仕訳";

                case DenpyouSiwakeWayToCreate.KtSFJyokyo:
                    return "固定資産(部署)除去債務履行";

                case DenpyouSiwakeWayToCreate.KtSFLease:
                    return "リース資産仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SaSeikyu:
                    return "債権　売上計上仕訳";

                case DenpyouSiwakeWayToCreate.SaNyukin:
                    return "債権　入金仕訳";

                case DenpyouSiwakeWayToCreate.SaKesikm:
                    return "債権　消込仕訳";

                case DenpyouSiwakeWayToCreate.SaTyouki:
                    return "債権　長期前受仕訳";

                case DenpyouSiwakeWayToCreate.SaSFSeikyu:
                    return "債権　売上計上仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SaSFNyukin:
                    return "債権　入金仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SaSFKesikm:
                    return "債権　消込仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SaSFTyouki:
                    return "債権　長期前受仕訳(部署)";

                case DenpyouSiwakeWayToCreate.FbAutoData:
                    return "ＦＢ自動仕訳";

                case DenpyouSiwakeWayToCreate.FbSFAutoData:
                    return "ＦＢ自動仕訳(部署)";

                case DenpyouSiwakeWayToCreate.KsKssFubn:
                    return "消込自動付番";

                case DenpyouSiwakeWayToCreate.KsKssInput:
                    return "消込処理";

                case DenpyouSiwakeWayToCreate.SmSaimukj:
                    return "債務　債務計上仕訳";

                case DenpyouSiwakeWayToCreate.SmShiharaikj:
                    return "債務　支払計上仕訳";

                case DenpyouSiwakeWayToCreate.SmTegatadat:
                    return "期日　期日発生仕訳";

                case DenpyouSiwakeWayToCreate.SmTegatakbn:
                    return "期日　期日顛末仕訳";

                case DenpyouSiwakeWayToCreate.SmTegataks:
                    return "期日　期日決済仕訳";

                case DenpyouSiwakeWayToCreate.SmSFSaimukj:
                    return "債務　債務計上仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SmSFShiharaikj:
                    return "債務　支払計上仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SmSFTegatadat:
                    return "期日　期日発生仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SmSFTegatakbn:
                    return "期日　期日顛末仕訳(部署)";

                case DenpyouSiwakeWayToCreate.SmSFTegataks:
                    return "期日　期日決済仕訳(部署)";

                case DenpyouSiwakeWayToCreate.CsGassan:
                    return "連結　合算自動仕訳";

                case DenpyouSiwakeWayToCreate.CsSousai:
                    return "連結　照合相殺自動仕訳";

                case DenpyouSiwakeWayToCreate.CsFurimodoshi:
                    return "連結　照合相殺振戻自動仕訳";

                case DenpyouSiwakeWayToCreate.Kyuyo:
                    return "人事給与";

                case DenpyouSiwakeWayToCreate.SfKyuyo:
                    return "人事給与(部署)";

                case DenpyouSiwakeWayToCreate.BtoBRenkei:
                    return "BtoB連携";

                case DenpyouSiwakeWayToCreate.SfBtoBRenkei:
                    return "BtoB連携(部署)";

                case DenpyouSiwakeWayToCreate.AIOCR:
                    return "Accontech OCR";

                case DenpyouSiwakeWayToCreate.SfAIOCR:
                    return "Accontech OCR(部署)";

                case DenpyouSiwakeWayToCreate.WF:
                    return "ワークフロー";

                case DenpyouSiwakeWayToCreate.SfWF:
                    return "ワークフロー(部署)";

                case DenpyouSiwakeWayToCreate.Adon:
                    return "アドオン";

                case DenpyouSiwakeWayToCreate.SfAdon:
                    return "アドオン(部署)";

                default:
                    return "その他";
            }
        }

        /// <summary>
        /// 通常伝票を扱う部署入出力処理業務か
        /// </summary>
        /// <param name="denpyouSiwakeWayToCreate"></param>
        /// <returns></returns>
        public static bool IsBusyobetuProgramUseTuuzyouDenpyou(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate) =>
            denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfledmain
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sdscan
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfgledmain;

        /// <summary>
        /// 月締めを参照しない業務か
        /// </summary>
        /// <param name="denpyouSiwakeWayToCreate"></param>
        /// <returns></returns>
        public static bool IsTukizimeTaisyougaiProgram(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate) =>
            denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfchkmain
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfsyonin;

        public static DenpyouCreateSystem GetDenpyouCreateSystem(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate)
        {
            switch (denpyouSiwakeWayToCreate)
            {
                case DenpyouSiwakeWayToCreate.Msconv:
                    return DenpyouCreateSystem.Conversion;
                case DenpyouSiwakeWayToCreate.KtLease:
                case DenpyouSiwakeWayToCreate.KtSFLease:
                    return DenpyouCreateSystem.LeasesisanKanriSystem;
                default:
                    var denpyouSiwakeWayToCreateNumber = (int)denpyouSiwakeWayToCreate;
                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.KouziGenkaKanriSystem)
                    {
                        return DenpyouCreateSystem.OtherSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.KoteisisanKanriSystem)
                    {
                        return DenpyouCreateSystem.KouziGenkaKanriSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.SougouSiharaiKanriSystem)
                    {
                        return DenpyouCreateSystem.KoteisisanKanriSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.SaikenSystem)
                    {
                        return DenpyouCreateSystem.SougouSiharaiKanriSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.FarmBankingZidouSiwakeSystem)
                    {
                        return DenpyouCreateSystem.SaikenSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.KesikomiKanriSystem)
                    {
                        return DenpyouCreateSystem.FarmBankingZidouSiwakeSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.SaimuKizituKanriSystem)
                    {
                        return DenpyouCreateSystem.KesikomiKanriSystem;
                    }

                    if (denpyouSiwakeWayToCreateNumber < (int)DenpyouCreateSystem.YosanSikkou)
                    {
                        return DenpyouCreateSystem.SaimuKizituKanriSystem;
                    }

                    return DenpyouCreateSystem.OtherSystem;
            }
        }

        public static bool IsAvailableTourokuKakuninTimingOption(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate) =>
            denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Dscan
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sdscan;

        public static bool IsUseOutputSecurity(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate) =>
            denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfledmain
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sdscan
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.ExChkmain
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.ExNikkmain
            || denpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sfgledmain;

        /// <summary>
        /// 仕訳作成方法の出力有無を取得します。
        /// </summary>
        /// <param name="denpyouSiwakeWayToCreate"></param>
        /// <param name="programId"></param>
        /// <returns></returns>
        public static bool IsCreateWay(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate, string programId)
        {
            switch (denpyouSiwakeWayToCreate)
            {
                case DenpyouSiwakeWayToCreate.Sfzaimu:
                case DenpyouSiwakeWayToCreate.KsKssFubn:
                case DenpyouSiwakeWayToCreate.KsKssInput:
                    return programId == "EXPROPMNT";

                case DenpyouSiwakeWayToCreate.Datadel:
                    return false;

                default:
                    return programId.Contains("SCAN")
                        || programId.Contains("DTCOMEX");
            }
        }

        /// <summary>
        /// 仕訳更新方法の出力有無を取得します。
        /// </summary>
        /// <param name="denpyouSiwakeWayToCreate"></param>
        /// <param name="programId"></param>
        /// <returns></returns>
        public static bool IsUpdateWay(this DenpyouSiwakeWayToCreate denpyouSiwakeWayToCreate, string programId)
        {
            switch (denpyouSiwakeWayToCreate)
            {
                case DenpyouSiwakeWayToCreate.Sfdinpfri:
                case DenpyouSiwakeWayToCreate.Sfdinpbkei:
                case DenpyouSiwakeWayToCreate.Sfchkmain:
                case DenpyouSiwakeWayToCreate.Sfsyonin:
                case DenpyouSiwakeWayToCreate.Sfdtcomin:
                case DenpyouSiwakeWayToCreate.Sfimport:
                case DenpyouSiwakeWayToCreate.KtSFSyoukyaku:
                case DenpyouSiwakeWayToCreate.KtSFJyokyaku:
                case DenpyouSiwakeWayToCreate.KtSFKounyu:
                case DenpyouSiwakeWayToCreate.KtSFbaikyaku:
                case DenpyouSiwakeWayToCreate.KtSFGenson:
                case DenpyouSiwakeWayToCreate.KtSFJyokyo:
                case DenpyouSiwakeWayToCreate.KtSFLease:
                case DenpyouSiwakeWayToCreate.SaSFSeikyu:
                case DenpyouSiwakeWayToCreate.SaSFNyukin:
                case DenpyouSiwakeWayToCreate.SaSFKesikm:
                case DenpyouSiwakeWayToCreate.SaSFTyouki:
                case DenpyouSiwakeWayToCreate.FbSFAutoData:
                case DenpyouSiwakeWayToCreate.SmSFSaimukj:
                case DenpyouSiwakeWayToCreate.SmSFShiharaikj:
                case DenpyouSiwakeWayToCreate.SmSFTegatadat:
                case DenpyouSiwakeWayToCreate.SmSFTegatakbn:
                case DenpyouSiwakeWayToCreate.SmSFTegataks:
                case DenpyouSiwakeWayToCreate.SfKyuyo:
                case DenpyouSiwakeWayToCreate.SfWF:
                case DenpyouSiwakeWayToCreate.SfBtoBRenkei:
                case DenpyouSiwakeWayToCreate.SfAIOCR:
                case DenpyouSiwakeWayToCreate.SfAdon:
                    return programId == "EXPROPMNT"
                        || programId == "SFDSCAN";

                case DenpyouSiwakeWayToCreate.Datadel:
                    return programId == "DRKISCAN";

                default:
                    return programId.Contains("SCAN")
                        || programId.Contains("DTCOMEX");
            }
        }
    }
}
