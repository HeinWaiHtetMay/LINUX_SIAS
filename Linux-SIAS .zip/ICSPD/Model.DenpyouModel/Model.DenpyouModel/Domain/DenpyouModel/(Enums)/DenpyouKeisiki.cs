﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum DenpyouKeisiki
    {
        Unknown = 0,
        Tannitu = 1,
        Hukugou = 2,
    }
}
