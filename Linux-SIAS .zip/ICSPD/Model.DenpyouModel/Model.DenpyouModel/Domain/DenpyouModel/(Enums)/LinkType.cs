﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum LinkType
    {
        Url = 0,
        LinkInfomationOnly = 1,
        Import = 2,
        Edocument = 3,
        //// 原票会計
        //// GenpyouImage = 4,
    }
}
