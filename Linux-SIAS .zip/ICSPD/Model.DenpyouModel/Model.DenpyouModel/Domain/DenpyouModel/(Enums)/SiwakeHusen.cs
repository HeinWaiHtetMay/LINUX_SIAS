﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum SiwakeHusen
    {
        /// <summary>
        /// なし
        /// </summary>
        Nothing = 0,

        /// <summary>
        /// 赤
        /// </summary>
        Red = 1,

        /// <summary>
        /// 濃赤
        /// </summary>
        DarkRed = 2,

        /// <summary>
        /// 薄紫
        /// </summary>
        Magenta = 3,

        /// <summary>
        /// 紫
        /// </summary>
        Purple = 4,

        /// <summary>
        /// 緑
        /// </summary>
        Lime = 5,

        /// <summary>
        /// 濃緑
        /// </summary>
        DarkGreen = 6,

        /// <summary>
        /// 黄
        /// </summary>
        Yellow = 7,

        /// <summary>
        /// 水（色）
        /// </summary>
        Cyan = 8,

        /// <summary>
        /// 青
        /// </summary>
        Blue = 9,

        /// <summary>
        /// 濃青
        /// </summary>
        DarkBlue = 10
    }
}
