﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum GaikaKanzanSiwakeFlag
    {
        TuujyouSiwake = 0,
        HurikaeSiwake = 1,
        HurikaeSiwakeTorikesizumi = 2,
        HurikaeSiwakeTeiseiSiwake = 3,
        HurimodosiSiwake = 4,
        HurimodosiSiwakeTorikesizumi = 5,
        HurimodosiSiwakeTeiseiSiwake = 6,
    }
}
