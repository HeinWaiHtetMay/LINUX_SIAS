﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum ZidouhubanType
    {
        DoNotUse = 0,
        GekkanItii = 1,
        NenkanItii = 2,
        GroupGekkanItii = 3,
        GroupNenkanItii = 4,
    }
}
