﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.DenpyouModel
{
    /// <summary>
    /// 仕訳貸借属性
    /// </summary>
    public enum SiwakeTaisyakuZokusei
    {
        /// <summary>
        /// 貸借
        /// </summary>
        Taisyaku = 0,

        /// <summary>
        /// 借方（借方に入力、貸方は諸口関連科目）
        /// </summary>
        Karikata = 1,

        /// <summary>
        /// 貸方（貸方に入力、借方は諸口関連科目）
        /// </summary>
        Kasikata = 2
    }
}
