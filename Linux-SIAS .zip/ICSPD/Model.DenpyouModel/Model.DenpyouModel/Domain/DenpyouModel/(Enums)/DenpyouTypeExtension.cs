﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public static class DenpyouTypeExtension
    {
        /// <summary>
        /// 自動付番が必要か
        /// </summary>
        /// <param name="denpyouType"></param>
        /// <param name="zidouhubanSyokiSettei"></param>
        /// <returns></returns>
        public static bool NeedsZidouHuban(this DenpyouType denpyouType, ZidouhubanSyokiSettei zidouhubanSyokiSettei) =>
            zidouhubanSyokiSettei != null
            && zidouhubanSyokiSettei.ZidouhubanType != ZidouhubanType.DoNotUse
            && (denpyouType != DenpyouType.Busyo ||
                zidouhubanSyokiSettei.IsUseBusyoNyuusyuturyokuZidouHuban);
    }
}
