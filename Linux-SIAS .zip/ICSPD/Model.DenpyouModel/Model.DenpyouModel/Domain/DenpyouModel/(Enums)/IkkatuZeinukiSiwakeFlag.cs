﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum IkkatuZeinukiSiwakeFlag
    {
        TuuzyouSiwake = 0,
        IkkatuZeinukiSiwakeMihurikae = 1,
        IkkatuZeinukiSiwakeHurikaemotoSiwake = 2,
        IkkatuZeinukiSiwakeHurikaeSiwake = 3,
    }
}
