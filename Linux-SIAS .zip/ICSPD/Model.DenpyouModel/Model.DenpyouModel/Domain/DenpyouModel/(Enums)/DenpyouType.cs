﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum DenpyouType
    {
        TuuzyouDenpyou = 0,
        Busyo = 1,
        Sokyuu = 2
    }
}
