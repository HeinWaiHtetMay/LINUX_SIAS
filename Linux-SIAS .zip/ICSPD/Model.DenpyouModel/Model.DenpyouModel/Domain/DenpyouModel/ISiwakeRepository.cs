﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Collections.Generic;

    public interface ISiwakeRepository
    {
        void Insert(Siwake siwake, DenpyouType denpyouType);

        void Update(Siwake siwake, DenpyouType denpyouType);

        void UpdateLastUpdateInfomationAndTorikesiFlag(Siwake siwake, DenpyouType denpyouType);

        /// <summary>
        /// 取消フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsTorikesi(Siwake siwake, DenpyouType denpyouType);

        /// <summary>
        /// 否認仕訳フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsHininSiwake(Siwake siwake, DenpyouType denpyouType);

        /// <summary>
        /// 出力フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsPrintedChecklist(int kesn, int dkei, int dseq, DenpyouType denpyouType);

        /// <summary>
        /// 出力フラグ、行変更フラグ、仕訳一覧フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsPrintedChecklistAndIsUpdatedLineAndIsPrintedSiwakeList(Siwake siwake, DenpyouType denpyouType);

        IList<Siwake> FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(Denpyou denpyou, DenpyouType denpyouType);
    }
}