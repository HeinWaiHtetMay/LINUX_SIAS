﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IZidouhubanSyokiSetteiRepository
    {
        ZidouhubanSyokiSettei FindByKesn(int kesn);
    }
}