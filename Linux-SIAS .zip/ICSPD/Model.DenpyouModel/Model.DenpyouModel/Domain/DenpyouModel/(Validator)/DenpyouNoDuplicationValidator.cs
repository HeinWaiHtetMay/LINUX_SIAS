﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using Icsp.Framework.Attributes;

    [Service(ServiceType.DomainService)]
    internal class DenpyouNoDuplicationValidator : IDenpyouNoDuplicationValidator
    {
        [AutoInjection]
        private IDenpyouRepository denpyouRepository = null;

        public virtual DenpyouNoDuplicationValidationResult ValidateDenpyouNoDuplication(Denpyou denpyou, DenpyouType denpyouType, ZidouhubanSyokiSettei zidouhubanSyokiSettei)
        {
            if (denpyou.DenpyouNo != null)
            {
                if (this.denpyouRepository.GetExistsYuukouDenpyouWithSpecifiedDenpyouBangou(
                    denpyou.Kesn,
                    denpyou.Dkei,
                    denpyou.DenpyouSequenceNumber,
                    denpyou.DenpyouNo,
                    denpyouType))
                {
                    return new DenpyouNoDuplicationValidationResult(denpyouType);
                }

                // 日次で自動付番且つ部署で自動付番使用しない場合は財務転記時に自動付番されるため部署側のチェックは不要
                // 以下の手順で伝票番号の重複を作り出せるが運用で回避するものとする
                // ①日次で自動付番しない状態で部署で伝票番号を入力して伝票を登録
                // ②日次のみ自動付番する設定に変更し、日次で①の番号で登録
                // ③部署で自動付番する設定に変更し財務転記で①②が重複する
                if (denpyouType == DenpyouType.TuuzyouDenpyou
                    && zidouhubanSyokiSettei != null
                    && zidouhubanSyokiSettei.ZidouhubanType != ZidouhubanType.DoNotUse
                    && !zidouhubanSyokiSettei.IsUseBusyoNyuusyuturyokuZidouHuban)
                {
                    return new DenpyouNoDuplicationValidationResult();
                }

                var checkTargetDenpyouTupe = denpyouType == DenpyouType.TuuzyouDenpyou
                    ? DenpyouType.Busyo
                    : DenpyouType.TuuzyouDenpyou;
                if (this.denpyouRepository.GetExistsYuukouDenpyouWithSpecifiedDenpyouBangou(
                    denpyou.Kesn,
                    denpyou.Dkei,
                    denpyou.DenpyouSequenceNumber,
                    denpyou.DenpyouNo,
                    checkTargetDenpyouTupe))
                {
                    return new DenpyouNoDuplicationValidationResult(checkTargetDenpyouTupe);
                }
            }

            return new DenpyouNoDuplicationValidationResult();
        }
    }
}
