﻿using System.Collections.Generic;
using System.Linq;
using Icsp.Framework.Core.Collections;
using Icsp.Framework.Core.Validation;
using MessageResouce = Icsp.Open21.Properties.Resources;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public class DenpyouValidationResult : IValidationResult
    {
        public DenpyouValidationResult(Denpyou denpyou)
        {
            this.Denpyou = denpyou;
            this.DenpyouInvalidReasonList = new List<DenpyouInvalidReason>();

            this.InvalidDenpyouHeader = new InvalidDenpyouHeader();
            this.InvalidSiwakeList = new List<InvalidSiwake>();
            denpyou.SiwakeList.ForEachIfNotNull(siwake =>
            {
                this.InvalidSiwakeList.Add(new InvalidSiwake(siwake));
            });
        }

        public Denpyou Denpyou { get; private set; }

        /// <summary>
        /// エラー理由
        /// </summary>
        public IList<DenpyouInvalidReason> DenpyouInvalidReasonList { get; set; }

        /// <summary>
        /// エラーメッセージ
        /// </summary>
        public string InvalidMessage { get => this.GetInvalidMessage(); }

        public bool IsValid => !this.InvalidDenpyouHeader.ContainsError
            && this.InvalidSiwakeList.Count(invalidSiwake => invalidSiwake.ContainsError) == 0;

        /// <summary>
        /// エラー伝票ヘッダー
        /// </summary>
        public InvalidDenpyouHeader InvalidDenpyouHeader { get; set; }

        /// <summary>
        /// エラー仕訳
        /// </summary>
        public IList<InvalidSiwake> InvalidSiwakeList { get; set; }

        /// <summary>
        /// エラー情報を追加
        /// 重複する内容は追加しない
        /// </summary>
        /// <param name="denpyouInvalidReason"></param>
        public void AddDenpyouInvalidReason(DenpyouInvalidReason denpyouInvalidReason)
        {
            if (!this.DenpyouInvalidReasonList.Contains(denpyouInvalidReason))
            {
                this.DenpyouInvalidReasonList.Add(denpyouInvalidReason);
            }
        }

        /// <summary>
        /// エラーのない伝票ヘッダーおよび仕訳を取り除く
        /// </summary>
        public void RemoveDenpyouHeaderAndSiwakeWithoutError()
        {
            if (this.InvalidDenpyouHeader != null && !this.InvalidDenpyouHeader.ContainsError)
            {
                this.InvalidDenpyouHeader = null;
            }

            this.InvalidSiwakeList = this.InvalidSiwakeList.Where(invalidSiwake => invalidSiwake.ContainsError)?.ToList();
        }

        /// <summary>
        /// 部門未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        public void ClearBumonUnregisterdErrorFromInvalidSiwake(string bumonCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearBumonUnregisterdError(bumonCode);
            }
        }

        /// <summary>
        /// 部門科目未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearBumonKamokuUnregisterdErrorFromInvalidSiwake(string bumonCode, string kamokuCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearBumonKamokuUnregisterdError(bumonCode, kamokuCode);
            }
        }

        /// <summary>
        /// 部門科目枝番未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="edabanCode"></param>
        public void ClearBumonKamokuEdabanUnregisterdErrorFromInvalidSiwake(string bumonCode, string kamokuCode, string edabanCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearBumonKamokuEdabanUnregisterdError(bumonCode, kamokuCode, edabanCode);
            }
        }

        /// <summary>
        /// 部門科目取引先未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="torihikisakiCode"></param>
        public void ClearBumonKamokuTorihikisakiUnregisterdErrorFromInvalidSiwake(string bumonCode, string kamokuCode, string torihikisakiCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearBumonKamokuTorihikisakiUnregisterdError(bumonCode, kamokuCode, torihikisakiCode);
            }
        }

        /// <summary>
        /// 科目枝番未登録エラーをクリア
        /// </summary>
        /// <param name="kamokuCode"></param>
        /// <param name="edabanCode"></param>
        public void ClearKamokuEdabanUnregisterdErrorFromInvalidSiwake(string kamokuCode, string edabanCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearKamokuEdabanUnregisterdError(kamokuCode, edabanCode);
            }
        }

        /// <summary>
        /// 取引先未登録エラーをクリア
        /// </summary>
        /// <param name="torihikisakiCode"></param>
        public void ClearTorihikisakiUnregisterdErrorFromInvalidSiwake(string torihikisakiCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearTorihikisakiUnregisterdError(torihikisakiCode);
            }
        }

        /// <summary>
        /// 取引先科目未登録エラーをクリア
        /// </summary>
        /// <param name="torihikisakiCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearTorihikisakiKamokuUnregisterdErrorFromInvalidSiwake(string torihikisakiCode, string kamokuCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearTorihikisakiKamokuUnregisterdError(torihikisakiCode, kamokuCode);
            }
        }

        /// <summary>
        /// セグメント未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        public void ClearSegmentUnregisterdErrorFromInvalidSiwake(string segmentCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearSegmentUnregisterdError(segmentCode);
            }
        }

        /// <summary>
        /// セグメント科目未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearSegmentKamokuUnregisterdErrorFromInvalidSiwake(string segmentCode, string kamokuCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearSegmentKamokuUnregisterdError(segmentCode, kamokuCode);
            }
        }

        /// <summary>
        /// セグメント科目取引先未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="torihikisakiCode"></param>
        public void ClearSegmentKamokuTorihikisakiUnregisterdErrorFromInvalidSiwake(string segmentCode, string kamokuCode, string torihikisakiCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearSegmentKamokuTorihikisakiUnregisterdError(segmentCode, kamokuCode, torihikisakiCode);
            }
        }

        /// <summary>
        /// 工事未登録エラーをクリア
        /// </summary>
        /// <param name="kouziCode"></param>
        public void ClearKouziUnregisterdErrorFromInvalidSiwake(string kouziCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearKouziUnregisterdError(kouziCode);
            }
        }

        /// <summary>
        /// 工種未登録エラーをクリア
        /// </summary>
        /// <param name="kousyuCode"></param>
        public void ClearKousyuUnregisterdErrorFromInvalidSiwake(string kousyuCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearKousyuUnregisterdError(kousyuCode);
            }
        }

        /// <summary>
        /// プロジェクト未登録エラーをクリア
        /// </summary>
        /// <param name="projectCode"></param>
        public void ClearProjectUnregisterdErrorFromInvalidSiwake(string projectCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearProjectUnregisterdError(projectCode);
            }
        }

        /// <summary>
        /// ユニバーサルフィールド未登録エラーをクリア
        /// </summary>
        /// <param name="universalFieldNo"></param>
        /// <param name="universalFieldCode"></param>
        public void ClearUniversalFieldUnregisterdErrorFromInvalidSiwake(int universalFieldNo, string universalFieldCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearUniversalFieldUnregisterdError(universalFieldNo, universalFieldCode);
            }
        }

        /// <summary>
        /// ユニバーサルフィールド科目未登録エラーをクリア
        /// </summary>
        /// <param name="universalFieldNo"></param>
        /// <param name="universalFieldCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearUniversalFieldKamokuUnregisterdErrorFromInvalidSiwake(int universalFieldNo, string universalFieldCode, string kamokuCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearUniversalFieldKamokuUnregisterdError(universalFieldNo, universalFieldCode, kamokuCode);
            }
        }

        /// <summary>
        /// 自由摘要未登録エラーをクリア
        /// </summary>
        /// <param name="tekiyouCode"></param>
        public void ClearTekiyouUnregisterdErrorFromInvalidSiwake(int? tekiyouCode)
        {
            foreach (var invalidSiwake in this.InvalidSiwakeList)
            {
                invalidSiwake.ClearTekiyouUnregisterdError(tekiyouCode);
            }
        }

        private string GetInvalidMessage()
        {
            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputDenpyouHizuke))
            {
                return MessageResouce.NotInputDenpyouHizukeMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.IsTukizimeTaisyouSyorituki))
            {
                return MessageResouce.IsTukizimeTaisyouSyoritukiMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotGetUketukeNo))
            {
                return MessageResouce.NotInputUketukeNoMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputDenpyouNo))
            {
                return MessageResouce.NotInputDenpyouNoMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputKihyousya))
            {
                return MessageResouce.NotInputKihyousyaMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputKihyouBumon))
            {
                return MessageResouce.NotInputKihyouBumonMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.CanNotInputDenpyoutabaCodeToTuuzyoutuki))
            {
                return MessageResouce.NotRegstrableDenpyouTabaCodeMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.CanNotInputUnregisteredDenpyoutabaCode))
            {
                return MessageResouce.UnregsterdDenpyouTabaCodeMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotSelectSyouninGroup))
            {
                return MessageResouce.NotInputSyouninGroupMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NothingRegisterableSiwake))
            {
                return MessageResouce.NoRegisterableSiwakeMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.SiwakeChangedByOther))
            {
                return MessageResouce.OtherBySiwakeChangedMessage;
            }

            if (this.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.ElapsedDaysChangeableSiwake))
            {
                return MessageResouce.UnavailableChangeElapsedDaysChangeableSiwakeMessage;
            }

            return string.Empty;
        }
    }
}
