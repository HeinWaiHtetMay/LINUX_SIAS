﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class InvalidDenpyouHeader : InvalidDenpyouItem
    {
        /// <summary>
        /// ヘッダーフィールド未入力エラーを含んでいるか
        /// </summary>
        public bool ContainsHeaderFieldNotInputError => this.HeaderField1NotInput
            || this.HeaderField2NotInput
            || this.HeaderField3NotInput
            || this.HeaderField4NotInput
            || this.HeaderField5NotInput
            || this.HeaderField6NotInput
            || this.HeaderField7NotInput
            || this.HeaderField8NotInput
            || this.HeaderField9NotInput
            || this.HeaderField10NotInput;

        /// <summary>
        /// 伝票日付未入力
        /// </summary>
        public bool DenpyouHizukeNotInput { get; set; }

        /// <summary>
        /// 伝票番号未入力
        /// </summary>
        public bool DenpyouNoNotInput { get; set; }

        /// <summary>
        /// 起票年月日未入力
        /// </summary>
        public bool KihyoubiNotInput { get; set; }

        /// <summary>
        /// 起票部門未入力
        /// </summary>
        public bool KihyouBumonNotInput { get; set; }

        /// <summary>
        /// 起票者未入力
        /// </summary>
        public bool KihyousyaNotInput { get; set; }

        /// <summary>
        /// 受付番号未入力
        /// </summary>
        public bool UketukeNoNotInput { get; set; }

        /// <summary>
        /// 承認ｸﾞﾙｰﾌﾟno未入力
        /// </summary>
        public bool SyouninGroupNumberNotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド1未入力
        /// </summary>
        public bool HeaderField1NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド1未登録
        /// </summary>
        public bool HeaderField1Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド2未入力
        /// </summary>
        public bool HeaderField2NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド2未登録
        /// </summary>
        public bool HeaderField2Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド3未入力
        /// </summary>
        public bool HeaderField3NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド3未登録
        /// </summary>
        public bool HeaderField3Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド4未入力
        /// </summary>
        public bool HeaderField4NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド4未登録
        /// </summary>
        public bool HeaderField4Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド5未入力
        /// </summary>
        public bool HeaderField5NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド5未登録
        /// </summary>
        public bool HeaderField5Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド6未入力
        /// </summary>
        public bool HeaderField6NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド6未登録
        /// </summary>
        public bool HeaderField6Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド7未入力
        /// </summary>
        public bool HeaderField7NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド10未登録
        /// </summary>
        public bool HeaderField7Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド8未入力
        /// </summary>
        public bool HeaderField8NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド8未登録
        /// </summary>
        public bool HeaderField8Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド9未入力
        /// </summary>
        public bool HeaderField9NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド9未登録
        /// </summary>
        public bool HeaderField9Unregistered { get; set; }

        /// <summary>
        /// ヘッダーフィールド10未入力
        /// </summary>
        public bool HeaderField10NotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド10未登録
        /// </summary>
        public bool HeaderField10Unregistered { get; set; }

        /// <summary>
        /// 伝票束コード未登録
        /// </summary>
        public bool DenpyouTabaCodeUnregistered { get; set; }

        /// <summary>
        /// 伝票束コード入力不可
        /// </summary>
        public bool DenpyouTabaCodeUnavailableToInput { get; set; }
    }
}