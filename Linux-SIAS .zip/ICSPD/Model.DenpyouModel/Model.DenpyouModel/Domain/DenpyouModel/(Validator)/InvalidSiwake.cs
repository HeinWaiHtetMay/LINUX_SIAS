﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public class InvalidSiwake : InvalidDenpyouItem
    {
        public InvalidSiwake(Siwake siwake) => this.Siwake = siwake;

        public Siwake Siwake { get; }

        public string KarikataSyouhizeiSiwakeKamokuCode { get; set; }

        public string KasikataSyouhizeiSiwakeKamokuCode { get; set; }

        #region 借方項目

        /// <summary>
        /// 借方科目未入力
        /// </summary>
        public bool KarikataKamokuNotInput { get; set; }

        /// <summary>
        /// 借方部門未入力
        /// </summary>
        public bool KarikataBumonNotInput { get; set; }

        /// <summary>
        /// 借方部門未登録
        /// </summary>
        public bool KarikataBumonUnregistered { get; set; }

        /// <summary>
        /// 借方部門科目未登録
        /// </summary>
        public bool KarikataBumonKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方取引先未入力
        /// </summary>
        public bool KarikataTorihikisakiNotInput { get; set; }

        /// <summary>
        /// 借方取引先未登録
        /// </summary>
        public bool KarikataTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 借方取引先科目未登録
        /// </summary>
        public bool KarikataTorihikisakiKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方部門科目取引先未登録
        /// </summary>
        public bool KarikataBumonKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 借方枝番未入力
        /// </summary>
        public bool KarikataEdabanNotInput { get; set; }

        /// <summary>
        /// 借方枝番未入力
        /// </summary>
        public bool KarikataEdabanUnregistered { get; set; }

        /// <summary>
        /// 借方部門科目枝番未登録
        /// </summary>
        public bool KarikataBumonKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 借方工事未入力
        /// </summary>
        public bool KarikataKouziNotInput { get; set; }

        /// <summary>
        /// 借方工事未登録
        /// </summary>
        public bool KarikataKouziUnregistered { get; set; }

        /// <summary>
        /// 借方工種未入力
        /// </summary>
        public bool KarikataKousyuNotInput { get; set; }

        /// <summary>
        /// 借方工種未登録
        /// </summary>
        public bool KarikataKousyuUnregistered { get; set; }

        /// <summary>
        /// 借方プロジェクト未入力
        /// </summary>
        public bool KarikataProjectNotInput { get; set; }

        /// <summary>
        /// 借方プロジェクト未登録
        /// </summary>
        public bool KarikataProjectUnregistered { get; set; }

        /// <summary>
        /// 借方セグメント未入力
        /// </summary>
        public bool KarikataSegmentNotInput { get; set; }

        /// <summary>
        /// 借方セグメント未登録
        /// </summary>
        public bool KarikataSegmentUnregistered { get; set; }

        /// <summary>
        /// 借方セグメント科目未登録
        /// </summary>
        public bool KarikataSegmentKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方セグメント科目取引先未登録
        /// </summary>
        public bool KarikataSegmentKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド1未入力
        /// </summary>
        public bool KarikataUniversalField1NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド1未登録
        /// </summary>
        public bool KarikataUniversalField1Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド1科目
        /// </summary>
        public bool KarikataUniversalField1KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド2未入力
        /// </summary>
        public bool KarikataUniversalField2NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド2未登録
        /// </summary>
        public bool KarikataUniversalField2Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド2科目未登録
        /// </summary>
        public bool KarikataUniversalField2KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド3未入力
        /// </summary>
        public bool KarikataUniversalField3NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド3未登録
        /// </summary>
        public bool KarikataUniversalField3Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド3科目未登録
        /// </summary>
        public bool KarikataUniversalField3KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド4未入力
        /// </summary>
        public bool KarikataUniversalField4NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド4未登録
        /// </summary>
        public bool KarikataUniversalField4Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド5未入力
        /// </summary>
        public bool KarikataUniversalField5NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド5未登録
        /// </summary>
        public bool KarikataUniversalField5Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド6未入力
        /// </summary>
        public bool KarikataUniversalField6NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド6未登録
        /// </summary>
        public bool KarikataUniversalField6Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド7未入力
        /// </summary>
        public bool KarikataUniversalField7NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド7未登録
        /// </summary>
        public bool KarikataUniversalField7Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド8未入力
        /// </summary>
        public bool KarikataUniversalField8NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド8未登録
        /// </summary>
        public bool KarikataUniversalField8Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド9未入力
        /// </summary>
        public bool KarikataUniversalField9NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド9未登録
        /// </summary>
        public bool KarikataUniversalField9Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド10未入力
        /// </summary>
        public bool KarikataUniversalField10NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド10未登録
        /// </summary>
        public bool KarikataUniversalField10Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド11未入力
        /// </summary>
        public bool KarikataUniversalField11NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド11未登録
        /// </summary>
        public bool KarikataUniversalField11Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド12未入力
        /// </summary>
        public bool KarikataUniversalField12NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド12未登録
        /// </summary>
        public bool KarikataUniversalField12Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド13未入力
        /// </summary>
        public bool KarikataUniversalField13NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド13未登録
        /// </summary>
        public bool KarikataUniversalField13Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド14未入力
        /// </summary>
        public bool KarikataUniversalField14NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド14未登録
        /// </summary>
        public bool KarikataUniversalField14Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド15未入力
        /// </summary>
        public bool KarikataUniversalField15NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド15未登録
        /// </summary>
        public bool KarikataUniversalField15Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド16未入力
        /// </summary>
        public bool KarikataUniversalField16NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド16未登録
        /// </summary>
        public bool KarikataUniversalField16Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド17未入力
        /// </summary>
        public bool KarikataUniversalField17NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド17未登録
        /// </summary>
        public bool KarikataUniversalField17Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド18未入力
        /// </summary>
        public bool KarikataUniversalField18NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド18未登録
        /// </summary>
        public bool KarikataUniversalField18Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド19未入力
        /// </summary>
        public bool KarikataUniversalField19NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド19未登録
        /// </summary>
        public bool KarikataUniversalField19Unregistered { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド20未入力
        /// </summary>
        public bool KarikataUniversalField20NotInput { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド20未登録
        /// </summary>
        public bool KarikataUniversalField20Unregistered { get; set; }

        /// <summary>
        /// 借方摘要コード未入力
        /// </summary>
        public bool KarikataTekiyouCodeNotInput { get; set; }

        /// <summary>
        /// 借方摘要コード未登録
        /// </summary>
        public bool KarikataTekiyouCodeUnregistered { get; set; }

        /// <summary>
        /// 借方税率が入力不可能な税率
        /// </summary>
        public bool KarikataZeirituInvalid { get; set; }

        /// <summary>
        /// 借方部門入力可能期間外
        /// </summary>
        public bool KarikataBumonOutsideInputtablePeriod { get; set; }

        /// <summary>
        /// 借方取引先入力可能期間外
        /// </summary>
        public bool KarikataTorihikisakiOutsideInputtablePeriod { get; set; }

        #endregion

        #region 貸方項目

        /// <summary>
        /// 貸方科目未入力
        /// </summary>
        public bool KasikataKamokuNotInput { get; set; }

        /// <summary>
        /// 貸方部門未入力
        /// </summary>
        public bool KasikataBumonNotInput { get; set; }

        /// <summary>
        /// 貸方部門未登録
        /// </summary>
        public bool KasikataBumonUnregistered { get; set; }

        /// <summary>
        /// 貸方部門科目未登録
        /// </summary>
        public bool KasikataBumonKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方取引先未入力
        /// </summary>
        public bool KasikataTorihikisakiNotInput { get; set; }

        /// <summary>
        /// 貸方取引先未登録
        /// </summary>
        public bool KasikataTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 貸方取引先科目未登録
        /// </summary>
        public bool KasikataTorihikisakiKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方部門科目取引先未登録
        /// </summary>
        public bool KasikataBumonKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 貸方枝番未入力
        /// </summary>
        public bool KasikataEdabanNotInput { get; set; }

        /// <summary>
        /// 貸方枝番未入力
        /// </summary>
        public bool KasikataEdabanUnregistered { get; set; }

        /// <summary>
        /// 貸方部門科目枝番
        /// </summary>
        public bool KasikataBumonKamokuEdabanNotInput { get; set; }

        /// <summary>
        /// 貸方部門科目枝番
        /// </summary>
        public bool KasikataBumonKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 貸方工事未入力
        /// </summary>
        public bool KasikataKouziNotInput { get; set; }

        /// <summary>
        /// 貸方工事未登録
        /// </summary>
        public bool KasikataKouziUnregistered { get; set; }

        /// <summary>
        /// 貸方工種未入力
        /// </summary>
        public bool KasikataKousyuNotInput { get; set; }

        /// <summary>
        /// 貸方工種未登録
        /// </summary>
        public bool KasikataKousyuUnregistered { get; set; }

        /// <summary>
        /// 貸方プロジェクト未入力
        /// </summary>
        public bool KasikataProjectNotInput { get; set; }

        /// <summary>
        /// 貸方プロジェクト未登録
        /// </summary>
        public bool KasikataProjectUnregistered { get; set; }

        /// <summary>
        /// 貸方セグメント未入力
        /// </summary>
        public bool KasikataSegmentNotInput { get; set; }

        /// <summary>
        /// 貸方セグメント未登録
        /// </summary>
        public bool KasikataSegmentUnregistered { get; set; }

        /// <summary>
        /// 貸方セグメント科目未登録
        /// </summary>
        public bool KasikataSegmentKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方セグメント科目取引先未登録
        /// </summary>
        public bool KasikataSegmentKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド1未入力
        /// </summary>
        public bool KasikataUniversalField1NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド1未登録
        /// </summary>
        public bool KasikataUniversalField1Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド1科目
        /// </summary>
        public bool KasikataUniversalField1KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド2未入力
        /// </summary>
        public bool KasikataUniversalField2NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド2未登録
        /// </summary>
        public bool KasikataUniversalField2Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド2科目未登録
        /// </summary>
        public bool KasikataUniversalField2KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド3未入力
        /// </summary>
        public bool KasikataUniversalField3NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド3未登録
        /// </summary>
        public bool KasikataUniversalField3Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド3科目未登録
        /// </summary>
        public bool KasikataUniversalField3KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド4未入力
        /// </summary>
        public bool KasikataUniversalField4NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド4未登録
        /// </summary>
        public bool KasikataUniversalField4Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド5未入力
        /// </summary>
        public bool KasikataUniversalField5NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド5未登録
        /// </summary>
        public bool KasikataUniversalField5Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド6未入力
        /// </summary>
        public bool KasikataUniversalField6NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド6未登録
        /// </summary>
        public bool KasikataUniversalField6Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド7未入力
        /// </summary>
        public bool KasikataUniversalField7NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド7未登録
        /// </summary>
        public bool KasikataUniversalField7Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド8未入力
        /// </summary>
        public bool KasikataUniversalField8NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド8未登録
        /// </summary>
        public bool KasikataUniversalField8Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド9未入力
        /// </summary>
        public bool KasikataUniversalField9NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド9未登録
        /// </summary>
        public bool KasikataUniversalField9Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド10未入力
        /// </summary>
        public bool KasikataUniversalField10NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド10未登録
        /// </summary>
        public bool KasikataUniversalField10Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド11未入力
        /// </summary>
        public bool KasikataUniversalField11NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド11未登録
        /// </summary>
        public bool KasikataUniversalField11Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド12未入力
        /// </summary>
        public bool KasikataUniversalField12NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド12未登録
        /// </summary>
        public bool KasikataUniversalField12Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド13未入力
        /// </summary>
        public bool KasikataUniversalField13NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド13未登録
        /// </summary>
        public bool KasikataUniversalField13Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド14未入力
        /// </summary>
        public bool KasikataUniversalField14NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド14未登録
        /// </summary>
        public bool KasikataUniversalField14Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド15未入力
        /// </summary>
        public bool KasikataUniversalField15NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド15未登録
        /// </summary>
        public bool KasikataUniversalField15Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド16未入力
        /// </summary>
        public bool KasikataUniversalField16NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド16未登録
        /// </summary>
        public bool KasikataUniversalField16Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド17未入力
        /// </summary>
        public bool KasikataUniversalField17NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド17未登録
        /// </summary>
        public bool KasikataUniversalField17Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド18未入力
        /// </summary>
        public bool KasikataUniversalField18NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド18未登録
        /// </summary>
        public bool KasikataUniversalField18Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド19未入力
        /// </summary>
        public bool KasikataUniversalField19NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド19未登録
        /// </summary>
        public bool KasikataUniversalField19Unregistered { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド20未入力
        /// </summary>
        public bool KasikataUniversalField20NotInput { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド20未登録
        /// </summary>
        public bool KasikataUniversalField20Unregistered { get; set; }

        /// <summary>
        /// 貸方摘要コード未入力
        /// </summary>
        public bool KasikataTekiyouCodeNotInput { get; set; }

        /// <summary>
        /// 貸方摘要コード未登録
        /// </summary>
        public bool KasikataTekiyouCodeUnregistered { get; set; }

        /// <summary>
        /// 貸方税率が入力不可能な税率
        /// </summary>
        public bool KasikataZeirituInvalid { get; set; }

        /// <summary>
        /// 貸方部門入力可能期間外
        /// </summary>
        public bool KasikataBumonOutsideInputtablePeriod { get; set; }

        /// <summary>
        /// 貸方取引先入力可能期間外
        /// </summary>
        public bool KasikataTorihikisakiOutsideInputtablePeriod { get; set; }

        #endregion

        #region 共通項目

        /// <summary>
        /// 税対象科目未入力
        /// </summary>
        public bool ZeitaisyouKamokuNotInput { get; set; }

        /// <summary>
        /// 対価金額未入力
        /// </summary>
        public bool TaikaKingakuNotInput { get; set; }

        /// <summary>
        /// 金額未入力
        /// </summary>
        public bool KingakuNotInput { get; set; }

        /// <summary>
        /// 支払日が入力不可能な日付
        /// </summary>
        public bool SiharaibiInvalid { get; set; }

        /// <summary>
        /// 外貨金額未入力
        /// </summary>
        public bool GaikaKingakuNotInput { get; set; }

        /// <summary>
        /// レート未入力
        /// </summary>
        public bool RateNotInput { get; set; }

        /// <summary>
        /// 外貨対価未入力
        /// </summary>
        public bool GaikaTaikaKingakuNotInput { get; set; }

        #endregion

        #region 借方税科目

        /// <summary>
        /// 借方分離科目未入力
        /// </summary>
        public bool KarikataBunriKamokuNotInput { get; set; }

        /// <summary>
        /// 借方税科目部門未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuBumonNotInput { get; set; }

        /// <summary>
        /// 借方税科目部門科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuBumonKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目取引先未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuTorihikisakiNotInput { get; set; }

        /// <summary>
        /// 借方税科目取引先科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuTorihikisakiKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目部門科目取引先未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 借方税科目枝番未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuEdabanNotInput { get; set; }

        /// <summary>
        /// 借方税科目枝番未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 借方税科目部門科目枝番未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuBumonKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 借方税科目工事未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuKouziNotInput { get; set; }

        /// <summary>
        /// 借方税科目工種未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuKousyuNotInput { get; set; }

        /// <summary>
        /// 借方税科目プロジェクト未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuProjectNotInput { get; set; }

        /// <summary>
        /// 借方税科目セグメント未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuSegmentNotInput { get; set; }

        /// <summary>
        /// 借方税科目セグメント科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuSegmentKamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目セグメント科目取引先未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド1未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField1NotInput { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド1科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField1KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド2未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField2NotInput { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド2科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField2KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド3未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField3NotInput { get; set; }

        /// <summary>
        /// 借方税科目ユニバーサルフィールド3科目未登録
        /// </summary>
        public bool KarikataSyouhizeiKamokuUniversalField3KamokuUnregistered { get; set; }

        /// <summary>
        /// 借方税科目摘要コード未入力
        /// </summary>
        public bool KarikataSyouhizeiKamokuTekiyouCodeNotInput { get; set; }

        #endregion

        #region 貸方税科目

        /// <summary>
        /// 貸方分離科目未入力
        /// </summary>
        public bool KasikataBunriKamokuNotInput { get; set; }

        /// <summary>
        /// 貸方税科目部門未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuBumonNotInput { get; set; }

        /// <summary>
        /// 貸方税科目部門科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuBumonKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目取引先未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuTorihikisakiNotInput { get; set; }

        /// <summary>
        /// 貸方税科目取引先科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuTorihikisakiKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目部門科目取引先未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目枝番未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuEdabanNotInput { get; set; }

        /// <summary>
        /// 貸方税科目枝番未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目部門科目枝番未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuBumonKamokuEdabanUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目工事未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuKouziNotInput { get; set; }

        /// <summary>
        /// 貸方税科目工種未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuKousyuNotInput { get; set; }

        /// <summary>
        /// 貸方税科目プロジェクト未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuProjectNotInput { get; set; }

        /// <summary>
        /// 貸方税科目セグメント未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuSegmentNotInput { get; set; }

        /// <summary>
        /// 貸方税科目セグメント科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuSegmentKamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目セグメント科目取引先未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド1未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField1NotInput { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド1科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField1KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド2未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField2NotInput { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド2科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField2KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド3未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField3NotInput { get; set; }

        /// <summary>
        /// 貸方税科目ユニバーサルフィールド3科目未登録
        /// </summary>
        public bool KasikataSyouhizeiKamokuUniversalField3KamokuUnregistered { get; set; }

        /// <summary>
        /// 貸方税科目摘要コード未入力
        /// </summary>
        public bool KasikataSyouhizeiKamokuTekiyouCodeNotInput { get; set; }

        #endregion

        public bool BumonRelatedItemUnregsterd =>
            this.KarikataBumonUnregistered
            || this.KarikataBumonKamokuUnregistered
            || this.KarikataBumonKamokuTorihikisakiUnregistered
            || this.KarikataBumonKamokuEdabanUnregistered
            || this.KarikataSyouhizeiKamokuBumonKamokuUnregistered
            || this.KarikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered
            || this.KarikataSyouhizeiKamokuBumonKamokuEdabanUnregistered
            || this.KasikataBumonUnregistered
            || this.KasikataBumonKamokuUnregistered
            || this.KasikataBumonKamokuTorihikisakiUnregistered
            || this.KasikataBumonKamokuEdabanUnregistered
            || this.KasikataSyouhizeiKamokuBumonKamokuUnregistered
            || this.KasikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered
            || this.KasikataSyouhizeiKamokuBumonKamokuEdabanUnregistered;

        public bool EdabanRelatedItemUnregsterd =>
            this.KarikataEdabanUnregistered
            || this.KarikataBumonKamokuEdabanUnregistered
            || this.KarikataSyouhizeiKamokuEdabanUnregistered
            || this.KarikataSyouhizeiKamokuBumonKamokuEdabanUnregistered
            || this.KasikataEdabanUnregistered
            || this.KasikataBumonKamokuEdabanUnregistered
            || this.KasikataSyouhizeiKamokuEdabanUnregistered
            || this.KasikataSyouhizeiKamokuBumonKamokuEdabanUnregistered;

        public bool TorihikisakiRelatedItemUnregsterd =>
            this.KarikataTorihikisakiUnregistered
            || this.KarikataTorihikisakiKamokuUnregistered
            || this.KarikataSegmentKamokuTorihikisakiUnregistered
            || this.KarikataSyouhizeiKamokuTorihikisakiKamokuUnregistered
            || this.KarikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered
            || this.KasikataTorihikisakiUnregistered
            || this.KasikataTorihikisakiKamokuUnregistered
            || this.KasikataSegmentKamokuTorihikisakiUnregistered
            || this.KasikataSyouhizeiKamokuTorihikisakiKamokuUnregistered
            || this.KasikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered;

        /// <summary>
        /// 部門未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        public void ClearBumonUnregisterdError(string bumonCode)
        {
            if (this.Siwake.KarikataBumonCode == bumonCode)
            {
                this.KarikataBumonUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode)
            {
                this.KasikataBumonUnregistered = false;
            }
        }

        /// <summary>
        /// 部門科目未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearBumonKamokuUnregisterdError(string bumonCode, string kamokuCode)
        {
            if (this.Siwake.KarikataBumonCode == bumonCode && this.Siwake.KarikataKamokuCode == kamokuCode)
            {
                this.KarikataBumonKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode && this.Siwake.KasikataKamokuCode == kamokuCode)
            {
                this.KasikataBumonKamokuUnregistered = false;
            }

            if (this.Siwake.KarikataBumonCode == bumonCode && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KarikataSyouhizeiKamokuBumonKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KasikataSyouhizeiKamokuBumonKamokuUnregistered = false;
            }
        }

        /// <summary>
        /// 部門科目枝番未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="edabanCode"></param>
        public void ClearBumonKamokuEdabanUnregisterdError(string bumonCode, string kamokuCode, string edabanCode)
        {
            if (this.Siwake.KarikataBumonCode == bumonCode
                && this.Siwake.KarikataKamokuCode == kamokuCode
                && this.Siwake.KarikataEdabanCode == edabanCode)
            {
                this.KarikataBumonKamokuEdabanUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode
                && this.Siwake.KasikataKamokuCode == kamokuCode
                && this.Siwake.KasikataEdabanCode == edabanCode)
            {
                this.KasikataBumonKamokuEdabanUnregistered = false;
            }

            if (this.Siwake.KarikataBumonCode == bumonCode
                && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KarikataEdabanCode == edabanCode)
            {
                this.KarikataSyouhizeiKamokuBumonKamokuEdabanUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode
                && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KasikataEdabanCode == edabanCode)
            {
                this.KasikataSyouhizeiKamokuBumonKamokuEdabanUnregistered = false;
            }
        }

        /// <summary>
        /// 部門科目取引先未登録エラーをクリア
        /// </summary>
        /// <param name="bumonCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="torihikisakiCode"></param>
        public void ClearBumonKamokuTorihikisakiUnregisterdError(string bumonCode, string kamokuCode, string torihikisakiCode)
        {
            if (this.Siwake.KarikataBumonCode == bumonCode
                && this.Siwake.KarikataKamokuCode == kamokuCode
                && this.Siwake.KarikataTorihikisakiCode == torihikisakiCode)
            {
                this.KarikataBumonKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode
                && this.Siwake.KasikataKamokuCode == kamokuCode
                && this.Siwake.KasikataTorihikisakiCode == torihikisakiCode)
            {
                this.KasikataBumonKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KarikataBumonCode == bumonCode
                && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KarikataTorihikisakiCode == torihikisakiCode)
            {
                this.KarikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KasikataBumonCode == bumonCode
                && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KasikataTorihikisakiCode == torihikisakiCode)
            {
                this.KasikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered = false;
            }
        }

        /// <summary>
        /// 科目枝番未登録エラーをクリア
        /// </summary>
        /// <param name="kamokuCode"></param>
        /// <param name="edabanCode"></param>
        public void ClearKamokuEdabanUnregisterdError(string kamokuCode, string edabanCode)
        {
            if (this.Siwake.KarikataKamokuCode == kamokuCode && this.Siwake.KarikataEdabanCode == edabanCode)
            {
                this.KarikataEdabanUnregistered = false;
            }

            if (this.Siwake.KasikataKamokuCode == kamokuCode && this.Siwake.KasikataEdabanCode == edabanCode)
            {
                this.KasikataEdabanUnregistered = false;
            }

            if (this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode && this.Siwake.KarikataEdabanCode == edabanCode)
            {
                this.KarikataSyouhizeiKamokuEdabanUnregistered = false;
            }

            if (this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode && this.Siwake.KasikataEdabanCode == edabanCode)
            {
                this.KasikataSyouhizeiKamokuEdabanUnregistered = false;
            }
        }

        /// <summary>
        /// 取引先未登録エラーをクリア
        /// </summary>
        /// <param name="torihikisakiCode"></param>
        public void ClearTorihikisakiUnregisterdError(string torihikisakiCode)
        {
            if (this.Siwake.KarikataTorihikisakiCode == torihikisakiCode)
            {
                this.KarikataTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KasikataTorihikisakiCode == torihikisakiCode)
            {
                this.KasikataTorihikisakiUnregistered = false;
            }
        }

        /// <summary>
        /// 取引先科目未登録エラーをクリア
        /// </summary>
        /// <param name="torihikisakiCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearTorihikisakiKamokuUnregisterdError(string torihikisakiCode, string kamokuCode)
        {
            if (this.Siwake.KarikataTorihikisakiCode == torihikisakiCode && this.Siwake.KarikataKamokuCode == kamokuCode)
            {
                this.KarikataTorihikisakiKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataTorihikisakiCode == torihikisakiCode && this.Siwake.KasikataKamokuCode == kamokuCode)
            {
                this.KasikataTorihikisakiKamokuUnregistered = false;
            }

            if (this.Siwake.KarikataTorihikisakiCode == torihikisakiCode && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KarikataSyouhizeiKamokuTorihikisakiKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataTorihikisakiCode == torihikisakiCode && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KasikataSyouhizeiKamokuTorihikisakiKamokuUnregistered = false;
            }
        }

        /// <summary>
        /// セグメント未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        public void ClearSegmentUnregisterdError(string segmentCode)
        {
            if (this.Siwake.KarikataSegmentCode == segmentCode)
            {
                this.KarikataSegmentUnregistered = false;
            }

            if (this.Siwake.KasikataSegmentCode == segmentCode)
            {
                this.KasikataSegmentUnregistered = false;
            }
        }

        /// <summary>
        /// セグメント科目未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearSegmentKamokuUnregisterdError(string segmentCode, string kamokuCode)
        {
            if (this.Siwake.KarikataSegmentCode == segmentCode && this.Siwake.KarikataKamokuCode == kamokuCode)
            {
                this.KarikataSegmentKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataSegmentCode == segmentCode && this.Siwake.KasikataKamokuCode == kamokuCode)
            {
                this.KasikataSegmentKamokuUnregistered = false;
            }

            if (this.Siwake.KarikataSegmentCode == segmentCode && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KarikataSyouhizeiKamokuSegmentKamokuUnregistered = false;
            }

            if (this.Siwake.KasikataSegmentCode == segmentCode && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
            {
                this.KasikataSyouhizeiKamokuSegmentKamokuUnregistered = false;
            }
        }

        /// <summary>
        /// セグメント科目取引先未登録エラーをクリア
        /// </summary>
        /// <param name="segmentCode"></param>
        /// <param name="kamokuCode"></param>
        /// <param name="torihikisakiCode"></param>
        public void ClearSegmentKamokuTorihikisakiUnregisterdError(string segmentCode, string kamokuCode, string torihikisakiCode)
        {
            if (this.Siwake.KarikataSegmentCode == segmentCode
                && this.Siwake.KarikataKamokuCode == kamokuCode
                && this.Siwake.KarikataTorihikisakiCode == torihikisakiCode)
            {
                this.KarikataSegmentKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KasikataSegmentCode == segmentCode
                && this.Siwake.KasikataKamokuCode == kamokuCode
                && this.Siwake.KasikataTorihikisakiCode == torihikisakiCode)
            {
                this.KasikataSegmentKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KarikataSegmentCode == segmentCode
                && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KarikataTorihikisakiCode == torihikisakiCode)
            {
                this.KarikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered = false;
            }

            if (this.Siwake.KasikataSegmentCode == segmentCode
                && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode
                && this.Siwake.KasikataTorihikisakiCode == torihikisakiCode)
            {
                this.KasikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered = false;
            }
        }

        /// <summary>
        /// 工事未登録エラーをクリア
        /// </summary>
        /// <param name="kouziCode"></param>
        public void ClearKouziUnregisterdError(string kouziCode)
        {
            if (this.Siwake.KarikataKouziCode == kouziCode)
            {
                this.KarikataKouziUnregistered = false;
            }

            if (this.Siwake.KasikataKouziCode == kouziCode)
            {
                this.KasikataKouziUnregistered = false;
            }
        }

        /// <summary>
        /// 工種未登録エラーをクリア
        /// </summary>
        /// <param name="kousyuCode"></param>
        public void ClearKousyuUnregisterdError(string kousyuCode)
        {
            if (this.Siwake.KarikataKousyuCode == kousyuCode)
            {
                this.KarikataKousyuUnregistered = false;
            }

            if (this.Siwake.KasikataKousyuCode == kousyuCode)
            {
                this.KasikataKousyuUnregistered = false;
            }
        }

        /// <summary>
        /// プロジェクト未登録エラーをクリア
        /// </summary>
        /// <param name="projectCode"></param>
        public void ClearProjectUnregisterdError(string projectCode)
        {
            if (this.Siwake.KarikataProjectCode == projectCode)
            {
                this.KarikataProjectUnregistered = false;
            }

            if (this.Siwake.KasikataProjectCode == projectCode)
            {
                this.KasikataProjectUnregistered = false;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド未登録エラーをクリア
        /// </summary>
        /// <param name="universalFieldNo"></param>
        /// <param name="universalFieldCode"></param>
        public void ClearUniversalFieldUnregisterdError(int universalFieldNo, string universalFieldCode)
        {
            switch (universalFieldNo)
            {
                case 1:
                    if (this.Siwake.KarikataUniversalField1Code == universalFieldCode)
                    {
                        this.KarikataUniversalField1Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField1Code == universalFieldCode)
                    {
                        this.KasikataUniversalField1Unregistered = false;
                    }

                    break;
                case 2:
                    if (this.Siwake.KarikataUniversalField2Code == universalFieldCode)
                    {
                        this.KarikataUniversalField2Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField2Code == universalFieldCode)
                    {
                        this.KasikataUniversalField2Unregistered = false;
                    }

                    break;
                case 3:
                    if (this.Siwake.KarikataUniversalField3Code == universalFieldCode)
                    {
                        this.KarikataUniversalField3Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField3Code == universalFieldCode)
                    {
                        this.KasikataUniversalField3Unregistered = false;
                    }

                    break;
                case 4:
                    if (this.Siwake.KarikataUniversalField4Code == universalFieldCode)
                    {
                        this.KarikataUniversalField4Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField4Code == universalFieldCode)
                    {
                        this.KasikataUniversalField4Unregistered = false;
                    }

                    break;
                case 5:
                    if (this.Siwake.KarikataUniversalField5Code == universalFieldCode)
                    {
                        this.KarikataUniversalField5Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField5Code == universalFieldCode)
                    {
                        this.KasikataUniversalField5Unregistered = false;
                    }

                    break;
                case 6:
                    if (this.Siwake.KarikataUniversalField6Code == universalFieldCode)
                    {
                        this.KarikataUniversalField6Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField6Code == universalFieldCode)
                    {
                        this.KasikataUniversalField6Unregistered = false;
                    }

                    break;
                case 7:
                    if (this.Siwake.KarikataUniversalField7Code == universalFieldCode)
                    {
                        this.KarikataUniversalField7Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField7Code == universalFieldCode)
                    {
                        this.KasikataUniversalField7Unregistered = false;
                    }

                    break;
                case 8:
                    if (this.Siwake.KarikataUniversalField8Code == universalFieldCode)
                    {
                        this.KarikataUniversalField8Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField8Code == universalFieldCode)
                    {
                        this.KasikataUniversalField8Unregistered = false;
                    }

                    break;
                case 9:
                    if (this.Siwake.KarikataUniversalField9Code == universalFieldCode)
                    {
                        this.KarikataUniversalField9Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField9Code == universalFieldCode)
                    {
                        this.KasikataUniversalField9Unregistered = false;
                    }

                    break;
                case 10:
                    if (this.Siwake.KarikataUniversalField10Code == universalFieldCode)
                    {
                        this.KarikataUniversalField10Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField10Code == universalFieldCode)
                    {
                        this.KasikataUniversalField10Unregistered = false;
                    }

                    break;
                case 11:
                    if (this.Siwake.KarikataUniversalField11Code == universalFieldCode)
                    {
                        this.KarikataUniversalField11Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField11Code == universalFieldCode)
                    {
                        this.KasikataUniversalField11Unregistered = false;
                    }

                    break;
                case 12:
                    if (this.Siwake.KarikataUniversalField12Code == universalFieldCode)
                    {
                        this.KarikataUniversalField12Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField12Code == universalFieldCode)
                    {
                        this.KasikataUniversalField12Unregistered = false;
                    }

                    break;
                case 13:
                    if (this.Siwake.KarikataUniversalField13Code == universalFieldCode)
                    {
                        this.KarikataUniversalField13Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField13Code == universalFieldCode)
                    {
                        this.KasikataUniversalField13Unregistered = false;
                    }

                    break;
                case 14:
                    if (this.Siwake.KarikataUniversalField14Code == universalFieldCode)
                    {
                        this.KarikataUniversalField14Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField14Code == universalFieldCode)
                    {
                        this.KasikataUniversalField14Unregistered = false;
                    }

                    break;
                case 15:
                    if (this.Siwake.KarikataUniversalField15Code == universalFieldCode)
                    {
                        this.KarikataUniversalField15Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField15Code == universalFieldCode)
                    {
                        this.KasikataUniversalField15Unregistered = false;
                    }

                    break;
                case 16:
                    if (this.Siwake.KarikataUniversalField16Code == universalFieldCode)
                    {
                        this.KarikataUniversalField16Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField16Code == universalFieldCode)
                    {
                        this.KasikataUniversalField16Unregistered = false;
                    }

                    break;
                case 17:
                    if (this.Siwake.KarikataUniversalField17Code == universalFieldCode)
                    {
                        this.KarikataUniversalField17Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField17Code == universalFieldCode)
                    {
                        this.KasikataUniversalField17Unregistered = false;
                    }

                    break;
                case 18:
                    if (this.Siwake.KarikataUniversalField18Code == universalFieldCode)
                    {
                        this.KarikataUniversalField18Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField18Code == universalFieldCode)
                    {
                        this.KasikataUniversalField18Unregistered = false;
                    }

                    break;
                case 19:
                    if (this.Siwake.KarikataUniversalField19Code == universalFieldCode)
                    {
                        this.KarikataUniversalField19Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField19Code == universalFieldCode)
                    {
                        this.KasikataUniversalField19Unregistered = false;
                    }

                    break;
                case 20:
                    if (this.Siwake.KarikataUniversalField20Code == universalFieldCode)
                    {
                        this.KarikataUniversalField20Unregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField20Code == universalFieldCode)
                    {
                        this.KasikataUniversalField20Unregistered = false;
                    }

                    break;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド科目未登録エラーをクリア
        /// </summary>
        /// <param name="universalFieldNo"></param>
        /// <param name="universalFieldCode"></param>
        /// <param name="kamokuCode"></param>
        public void ClearUniversalFieldKamokuUnregisterdError(int universalFieldNo, string universalFieldCode, string kamokuCode)
        {
            switch (universalFieldNo)
            {
                case 1:
                    if (this.Siwake.KarikataUniversalField1Code == universalFieldCode
                        && this.Siwake.KarikataKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField1KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField1Code == universalFieldCode
                        && this.Siwake.KasikataKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField1KamokuUnregistered = false;
                    }

                    if (this.Siwake.KarikataUniversalField1Code == universalFieldCode
                        && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField1KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField1Code == universalFieldCode
                        && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField1KamokuUnregistered = false;
                    }

                    break;
                case 2:
                    if (this.Siwake.KarikataUniversalField2Code == universalFieldCode
                        && this.Siwake.KarikataKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField2KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField2Code == universalFieldCode
                        && this.Siwake.KasikataKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField2KamokuUnregistered = false;
                    }

                    if (this.Siwake.KarikataUniversalField2Code == universalFieldCode
                        && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField2KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField2Code == universalFieldCode
                        && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField2KamokuUnregistered = false;
                    }

                    break;
                case 3:
                    if (this.Siwake.KarikataUniversalField3Code == universalFieldCode
                        && this.Siwake.KarikataKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField3KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField3Code == universalFieldCode
                        && this.Siwake.KasikataKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField3KamokuUnregistered = false;
                    }

                    if (this.Siwake.KarikataUniversalField3Code == universalFieldCode
                        && this.KarikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KarikataUniversalField3KamokuUnregistered = false;
                    }

                    if (this.Siwake.KasikataUniversalField3Code == universalFieldCode
                        && this.KasikataSyouhizeiSiwakeKamokuCode == kamokuCode)
                    {
                        this.KasikataUniversalField3KamokuUnregistered = false;
                    }

                    break;
            }
        }

        /// <summary>
        /// 自由摘要未登録エラーをクリア
        /// </summary>
        /// <param name="tekiyouCode"></param>
        public void ClearTekiyouUnregisterdError(int? tekiyouCode)
        {
            if (this.Siwake.KarikataTekiyouCode == tekiyouCode)
            {
                this.KarikataTekiyouCodeUnregistered = false;
            }

            if (this.Siwake.KasikataTekiyouCode == tekiyouCode)
            {
                this.KasikataTekiyouCodeUnregistered = false;
            }
        }

        /// <summary>
        /// エラーコードを取得
        /// </summary>
        /// <param name="masterType"></param>
        /// <param name="taisyakuZokusei"></param>
        /// <returns></returns>
        public string GetMasterCode(MasterType masterType, SiwakeTaisyakuZokusei taisyakuZokusei)
        {
            switch (masterType)
            {
                case MasterType.Bumon:
                    return taisyakuZokusei == SiwakeTaisyakuZokusei.Karikata
                        ? this.Siwake.KarikataBumonCode
                        : this.Siwake.KasikataBumonCode;
                case MasterType.Torihikisaki:
                default:
                    return taisyakuZokusei == SiwakeTaisyakuZokusei.Karikata
                        ? this.Siwake.KarikataTorihikisakiCode
                        : this.Siwake.KasikataTorihikisakiCode;
            }
        }

        /// <summary>
        /// 入力可能期間外エラーがあるか
        /// </summary>
        /// <param name="masterType"></param>
        /// <param name="taisyakuZokusei"></param>
        /// <returns></returns>
        public bool HasMasterOutsideInputtablePeriodError(MasterType masterType, SiwakeTaisyakuZokusei taisyakuZokusei)
        {
            switch (masterType)
            {
                case MasterType.Bumon:
                    return taisyakuZokusei == SiwakeTaisyakuZokusei.Karikata
                        ? this.KarikataBumonOutsideInputtablePeriod
                        : this.KasikataBumonOutsideInputtablePeriod;
                case MasterType.Torihikisaki:
                default:
                    return taisyakuZokusei == SiwakeTaisyakuZokusei.Karikata
                        ? this.KarikataTorihikisakiOutsideInputtablePeriod
                        : this.KasikataTorihikisakiOutsideInputtablePeriod;
            }
        }
    }
}
