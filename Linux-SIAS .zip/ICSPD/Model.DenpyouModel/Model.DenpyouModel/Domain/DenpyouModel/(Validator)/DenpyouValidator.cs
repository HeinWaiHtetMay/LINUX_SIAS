﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    [Service(ServiceType.DomainService)]
    internal class DenpyouValidator : IDenpyouValidator
    {
        #region Repository
        [AutoInjection]
        private IKessanSeiriSyoriUserRepository kessanSeiriSyoriUserRepository = null;

        [AutoInjection]
        private IDenpyouKoumokuNotInputCheckSettingRepository denpyouKoumokuNotInputCheckSettingRepository = null;

        [AutoInjection]
        private IInputtableUserOnKarisimeSyoritukiRepository inputtableUserOnKarisimeSyoritukiRepository = null;

        [AutoInjection]
        private IDenpyouTabaRepository denpyouTabaRepository = null;

        [AutoInjection]
        private ISyouhizeirituRepository syouhizeirituRepository = null;

        [AutoInjection]
        private IDenpyouRepository denpyouRepository = null;

        [AutoInjection]
        private IDbUtilityDao dbUtilityDao = null;
        #endregion

        public virtual DenpyouValidationResult AllowInsertDenpyou(DenpyouValidatorParameter denpyouValidatorParameter) =>
            this.ValidateBeforeUpdateDenpyou(denpyouValidatorParameter);

        public virtual DenpyouValidationResult ValidateBeforeUpdateDenpyou(DenpyouValidatorParameter denpyouValidatorParameter)
        {
            var masterCacheRepository = new MasterCacheRepository(
                denpyouValidatorParameter.Container,
                denpyouValidatorParameter.UserAndSyorikiSecurityContext,
                SecurityKubun.Input);

            var denpyouValidationResult = this.ValidateBeforeUpdateDenpyou(
                denpyouValidatorParameter,
                masterCacheRepository);

            denpyouValidationResult.RemoveDenpyouHeaderAndSiwakeWithoutError();

            return denpyouValidationResult;
        }

        public virtual DenpyouValidationResult ValidateBeforeDenpyouTorikesi(
            Denpyou denpyou,
            IKaisyaSyoriKikan syorikikan,
            DenpyouType denpyouType,
            SyouhizeiMaster syouhizeiMaster)
        {
            var denpyouValidationResult = new DenpyouValidationResult(denpyou);

            // 電子帳簿保存法
            this.ValidateDensityouboHozon(
                denpyouValidationResult,
                denpyou,
                syorikikan,
                true);

            denpyouValidationResult.RemoveDenpyouHeaderAndSiwakeWithoutError();

            return denpyouValidationResult;
        }

        protected DenpyouValidationResult ValidateBeforeUpdateDenpyou(
            DenpyouValidatorParameter denpyouValidatorParameter,
            MasterCacheRepository masterCacheRepository)
        {
            var denpyouValidationResult = new DenpyouValidationResult(denpyouValidatorParameter.Denpyou);
            if (denpyouValidatorParameter.Denpyou.GetSiwakeCount() == 0)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NothingRegisterableSiwake);
                return denpyouValidationResult;
            }

            // 伝票日付チェック
            this.ValidateDenpyouHizuke(
                denpyouValidationResult,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.DenpyouType,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.UserAndSyorikiSecurityContext.User);

            if (denpyouValidationResult.DenpyouInvalidReasonList.Count > 0)
            {
                return denpyouValidationResult;
            }

            var denpyouKoumokuNotInputCheckSetting = this.denpyouKoumokuNotInputCheckSettingRepository.Find();

            // 伝票ヘッダー未入力チェック
            this.ValidateDenpyouHeaderKoumokuInputted(
                denpyouValidationResult,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.ZidouhubanSyokiSettei,
                denpyouKoumokuNotInputCheckSetting,
                denpyouValidatorParameter.DenpyouValidationOption.ShouldCheckSyouninGroup);

            // 伝票束チェック
            this.ValidateDenpyouTaba(denpyouValidationResult, denpyouValidatorParameter.Denpyou);

            // 伝票合計チェック
            this.ValidateKingakuGoukei(denpyouValidationResult, denpyouValidatorParameter.Denpyou, denpyouValidatorParameter.SyouhizeiMaster);

            // 税率チェック
            this.ValidateZeiritu(denpyouValidationResult, denpyouValidatorParameter.Denpyou);

            if (denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputDenpyouHizuke)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotGetUketukeNo)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputDenpyouNo)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputKihyousya)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotInputKihyouBumon)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.CanNotInputDenpyoutabaCodeToTuuzyoutuki)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.CanNotInputUnregisteredDenpyoutabaCode)
                || denpyouValidationResult.DenpyouInvalidReasonList.Contains(DenpyouInvalidReason.NotSelectSyouninGroup))
            {
                return denpyouValidationResult;
            }

            // 支払日チェック
            this.ValidateSiharaibi(
                denpyouValidationResult,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.DenpyouValidationOption.ShouldCheckSiharaibiDenpyouHizukeBefore);

            // 未入力チェック
            this.ValidateSiwakeKoumokuInputted(
                denpyouValidationResult,
                denpyouValidatorParameter,
                denpyouKoumokuNotInputCheckSetting,
                masterCacheRepository);

            // 未登録チェック
            this.ValidateDenpyouHeaderKoumokuRegistered(
                denpyouValidationResult,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.SyoriKikan,
                masterCacheRepository);

            this.ValidateSiwakeKoumokuRegistered(
                denpyouValidationResult,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.SyouhizeiMaster,
                masterCacheRepository);

            // 部門入力可能期間チェック
            this.ValidatePeriodInputtableBumon(
                denpyouValidationResult,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.DenpyouValidationOption.ShouldCheckPeriodInputtableBumon,
                masterCacheRepository);

            // 取引先入力可能期間チェック
            this.ValidatePeriodInputtableTorihikisaki(
                denpyouValidationResult,
                denpyouValidatorParameter.SyoriKikan,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.DenpyouValidationOption.ShouldCheckPeriodInputtableTorihikisaki,
                masterCacheRepository);

            // 他で伝票が変更されていないかチェック
            this.ValidateKizonDenpyou(
                denpyouValidationResult,
                denpyouValidatorParameter.DenpyouOld,
                denpyouValidatorParameter.DenpyouType);

            // 電子帳簿保存法
            this.ValidateDensityouboHozon(
                denpyouValidationResult,
                denpyouValidatorParameter.Denpyou,
                denpyouValidatorParameter.SyoriKikan,
                false);

            return denpyouValidationResult;
        }

        /// <summary>
        /// 伝票日付チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        /// <param name="syorikikan"></param>
        /// <param name="user"></param>
        protected virtual void ValidateDenpyouHizuke(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyou,
            DenpyouType denpyouType,
            IKaisyaSyoriKikan syorikikan,
            User user)
        {
            if (denpyouValidationResult.InvalidDenpyouHeader.DenpyouHizukeNotInput = denpyou.DenpyouHizuke <= 0)
            {
                denpyouValidationResult.DenpyouInvalidReasonList.Add(DenpyouInvalidReason.NotInputDenpyouHizuke);
                return;
            }

            if (denpyouType != DenpyouType.Sokyuu)
            {
                var syorituki = syorikikan.Syoriki.GetSyorituki(denpyou.Dkei);
                var tukisimeState = syorituki.TukisimeState;
                var isKessanSeiriSyoriUser = this.kessanSeiriSyoriUserRepository.GetUserNoList()?.Contains(user.UserCode) ?? false;

                // 部署且つ決算整理締め且つ決算整理処理ユーザーなら登録可能
                if (!(denpyouType == DenpyouType.Busyo && syorituki.IsKessanSeiriSime && isKessanSeiriSyoriUser)
                    && (tukisimeState == TukisimeState.Honsime
                        || tukisimeState == TukisimeState.Tukisime
                        || (tukisimeState == TukisimeState.Karisime && !this.inputtableUserOnKarisimeSyoritukiRepository.GetIsSiwakeAndZandakaInputtableUser(user.UserCode))))
                {
                    denpyouValidationResult.DenpyouInvalidReasonList.Add(DenpyouInvalidReason.IsTukizimeTaisyouSyorituki);
                    return;
                }
            }
        }

        /// <summary>
        /// 伝票ヘッダー項目未入力チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        /// <param name="syorikikan"></param>
        /// <param name="zidouhubanSyokiSettei"></param>
        /// <param name="denpyouKoumokuNotInputCheckSetting"></param>
        /// <param name="useSyounin"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        protected virtual void ValidateDenpyouHeaderKoumokuInputted(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyou,
            IKaisyaSyoriKikan syorikikan,
            ZidouhubanSyokiSettei zidouhubanSyokiSettei,
            DenpyouKoumokuNotInputCheckSetting denpyouKoumokuNotInputCheckSetting,
            bool useSyounin)
        {
            if (denpyouValidationResult.InvalidDenpyouHeader.UketukeNoNotInput = denpyou.UketukeNo <= 0)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotGetUketukeNo);
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.DenpyouNoNotInput = !syorikikan.Syoriki.AllowDenpyoNoNotInputed
                && zidouhubanSyokiSettei.ZidouhubanType == ZidouhubanType.DoNotUse
                && denpyou.DenpyouNo == null)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotInputDenpyouNo);
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.KihyousyaNotInput =
                syorikikan.Syoriki.UseKihyousya
                && denpyouKoumokuNotInputCheckSetting.IsUseKihyousyaNotInputCheck
                && string.IsNullOrEmpty(denpyou.KihyousyaCode))
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotInputKihyousya);
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.KihyouBumonNotInput =
                syorikikan.Syoriki.UseKihyouBumon
                && denpyouKoumokuNotInputCheckSetting.IsUseKihyouBumonNotInputCheck
                && string.IsNullOrEmpty(denpyou.KihyouBumonCode))
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotInputKihyouBumon);
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.SyouninGroupNumberNotInput = useSyounin && denpyou.SyouninGroupNumber <= 0)
            {
                denpyouValidationResult.DenpyouInvalidReasonList.Add(DenpyouInvalidReason.NotSelectSyouninGroup);
                return;
            }

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField1NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 1).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField1NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField1Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField2NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 2).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField2NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField2Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField3NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 3).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField3NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField3Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField4NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 4).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField4NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField4Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField5NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 5).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField5NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField5Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField6NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 6).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField6NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField6Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField7NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 7).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField7NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField7Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField8NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 1).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField8NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField8Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField9NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 9).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField9NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField9Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField10NotInput =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 10).Use
                && denpyouKoumokuNotInputCheckSetting.IsUseHeaderField10NotInputCheck
                && string.IsNullOrEmpty(denpyou.HeaderField10Code);

            if (denpyouValidationResult.InvalidDenpyouHeader?.ContainsNotInputError ?? false)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotInputDenpyouKoumoku);
            }
        }

        /// <summary>
        /// 伝票束チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        protected virtual void ValidateDenpyouTaba(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyou)
        {
            if (denpyou.DenpyouTabaLink == null)
            {
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.DenpyouTabaCodeUnavailableToInput = denpyou.Dkei % 10 == 0)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.CanNotInputDenpyoutabaCodeToTuuzyoutuki);
                return;
            }

            if (denpyouValidationResult.InvalidDenpyouHeader.DenpyouTabaCodeUnregistered = this.denpyouTabaRepository.FindByCode(denpyou.DenpyouTabaLink.TabaCode) == null)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.CanNotInputUnregisteredDenpyoutabaCode);
            }
        }

        /// <summary>
        /// 仕訳項目未入力チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyouValidatorParameter"></param>
        /// <param name="denpyouKoumokuNotInputCheckSetting"></param>
        /// <param name="masterCacheRepository"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "これ以上の分割不可")]
        protected virtual void ValidateSiwakeKoumokuInputted(
            DenpyouValidationResult denpyouValidationResult,
            DenpyouValidatorParameter denpyouValidatorParameter,
            DenpyouKoumokuNotInputCheckSetting denpyouKoumokuNotInputCheckSetting,
            MasterCacheRepository masterCacheRepository)
        {
            foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList.Where(invalidSiwake => !invalidSiwake.Siwake.HasCodeSecurity))
            {
                var karikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KarikataKamokuCode);
                invalidSiwake.KarikataKamokuNotInput = karikataKamoku == null;
                if (karikataKamoku != null)
                {
                    invalidSiwake.KarikataBumonNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.BumonInfo.Use && karikataKamoku.IsUseBumonNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode);
                    invalidSiwake.KarikataTorihikisakiNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.TorihikisakiInfo.Use && karikataKamoku.IsUseTorihikisakiNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode);
                    invalidSiwake.KarikataTekiyouCodeNotInput = karikataKamoku.IsUseTekiyouCodeNotInputCheck && (invalidSiwake.Siwake.KarikataTekiyouCode == null || invalidSiwake.Siwake.KarikataTekiyouCode == 0);
                    if (denpyouValidatorParameter.DenpyouType != DenpyouType.Sokyuu)
                    {
                        invalidSiwake.KarikataEdabanNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.EdabanInfo.Use && karikataKamoku.IsUseEdabanNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode);
                        invalidSiwake.KarikataSegmentNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.SegmentInfo.Use && karikataKamoku.IsUseSegmentNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode);
                        invalidSiwake.KarikataProjectNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.ProjectInfo.Use && karikataKamoku.IsUseProjectNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataProjectCode);
                        invalidSiwake.KarikataKouziNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.KouziInfo.Use && karikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKouziCode);
                        invalidSiwake.KarikataKousyuNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.KousyuInfo.Use && karikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKousyuCode);
                        invalidSiwake.KarikataUniversalField1NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField1NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField1Code);

                        invalidSiwake.KarikataUniversalField2NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField2NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField2Code);

                        invalidSiwake.KarikataUniversalField3NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField3NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField3Code);

                        invalidSiwake.KarikataUniversalField4NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 4).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField4NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField4Code);

                        invalidSiwake.KarikataUniversalField5NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 5).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField5NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField5Code);

                        invalidSiwake.KarikataUniversalField6NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 6).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField6NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField6Code);

                        invalidSiwake.KarikataUniversalField7NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 7).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField7NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField7Code);

                        invalidSiwake.KarikataUniversalField8NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 8).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField8NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField8Code);

                        invalidSiwake.KarikataUniversalField9NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 9).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField9NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField9Code);

                        invalidSiwake.KarikataUniversalField10NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 10).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField10NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField10Code);

                        invalidSiwake.KarikataUniversalField11NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 11).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField11NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField11Code);

                        invalidSiwake.KarikataUniversalField12NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 12).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField12NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField12Code);

                        invalidSiwake.KarikataUniversalField13NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 13).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField13NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField13Code);

                        invalidSiwake.KarikataUniversalField14NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 14).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField14NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField14Code);

                        invalidSiwake.KarikataUniversalField15NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 15).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField15NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField15Code);

                        invalidSiwake.KarikataUniversalField16NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 16).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField16NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField16Code);

                        invalidSiwake.KarikataUniversalField17NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 17).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField17NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField17Code);

                        invalidSiwake.KarikataUniversalField18NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 18).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField18NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField18Code);

                        invalidSiwake.KarikataUniversalField19NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 19).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField19NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField19Code);

                        invalidSiwake.KarikataUniversalField20NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 20).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField20NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField20Code);
                    }
                }

                var kasikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KasikataKamokuCode);
                invalidSiwake.KasikataKamokuNotInput = kasikataKamoku == null;
                if (kasikataKamoku != null)
                {
                    invalidSiwake.KasikataBumonNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.BumonInfo.Use && kasikataKamoku.IsUseBumonNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode);
                    invalidSiwake.KasikataTorihikisakiNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.TorihikisakiInfo.Use && kasikataKamoku.IsUseTorihikisakiNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode);
                    invalidSiwake.KasikataTekiyouCodeNotInput = kasikataKamoku.IsUseTekiyouCodeNotInputCheck && (invalidSiwake.Siwake.KasikataTekiyouCode == null || invalidSiwake.Siwake.KasikataTekiyouCode == 0);
                    if (denpyouValidatorParameter.DenpyouType != DenpyouType.Sokyuu)
                    {
                        invalidSiwake.KasikataEdabanNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.EdabanInfo.Use && kasikataKamoku.IsUseEdabanNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode);
                        invalidSiwake.KasikataSegmentNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.SegmentInfo.Use && kasikataKamoku.IsUseSegmentNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode);
                        invalidSiwake.KasikataProjectNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.ProjectInfo.Use && kasikataKamoku.IsUseProjectNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataProjectCode);
                        invalidSiwake.KasikataKouziNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.KouziInfo.Use && kasikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKouziCode);
                        invalidSiwake.KasikataKousyuNotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.KousyuInfo.Use && kasikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKousyuCode);
                        invalidSiwake.KasikataUniversalField1NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField1NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField1Code);

                        invalidSiwake.KasikataUniversalField2NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField2NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField2Code);

                        invalidSiwake.KasikataUniversalField3NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField3NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField3Code);

                        invalidSiwake.KasikataUniversalField4NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 4).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField4NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField4Code);

                        invalidSiwake.KasikataUniversalField5NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 5).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField5NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField5Code);

                        invalidSiwake.KasikataUniversalField6NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 6).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField6NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField6Code);

                        invalidSiwake.KasikataUniversalField7NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 7).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField7NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField7Code);

                        invalidSiwake.KasikataUniversalField8NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 8).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField8NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField8Code);

                        invalidSiwake.KasikataUniversalField9NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 9).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField9NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField9Code);

                        invalidSiwake.KasikataUniversalField10NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 10).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField10NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField10Code);

                        invalidSiwake.KasikataUniversalField11NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 11).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField11NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField11Code);

                        invalidSiwake.KasikataUniversalField12NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 12).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField12NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField12Code);

                        invalidSiwake.KasikataUniversalField13NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 13).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField13NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField13Code);

                        invalidSiwake.KasikataUniversalField14NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 14).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField14NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField14Code);

                        invalidSiwake.KasikataUniversalField15NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 15).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField15NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField15Code);

                        invalidSiwake.KasikataUniversalField16NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 16).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField16NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField16Code);

                        invalidSiwake.KasikataUniversalField17NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 17).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField17NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField17Code);

                        invalidSiwake.KasikataUniversalField18NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 18).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField18NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField18Code);

                        invalidSiwake.KasikataUniversalField19NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 19).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField19NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField19Code);

                        invalidSiwake.KasikataUniversalField20NotInput = denpyouValidatorParameter.SyoriKikan.Syoriki.GetUniversalFieldInfo(false, 20).Usage != UniversalFieldUsageType.NotUse
                            && kasikataKamoku.IsUseUniversalField20NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField20Code);
                    }
                }

                invalidSiwake.TaikaKingakuNotInput =
                    denpyouKoumokuNotInputCheckSetting.IsUseTaikaNotInputCheck
                    && invalidSiwake.Siwake.IsInputTaika && invalidSiwake.Siwake.IsTaikaNotInput;

                if (!(string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataHeisyuCode)
                    && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataHeisyuCode)))
                {
                    invalidSiwake.RateNotInput =
                        denpyouValidatorParameter.DenpyouValidationOption.ShuoldCheckRateNotInput
                        && invalidSiwake.Siwake.IsRateNotInput;

                    invalidSiwake.GaikaKingakuNotInput =
                        denpyouValidatorParameter.DenpyouValidationOption.ShuoldCheckGaikaKingakuNotInput
                        && invalidSiwake.Siwake.IsGaikaKingakuNotInput;

                    invalidSiwake.GaikaTaikaKingakuNotInput =
                        denpyouKoumokuNotInputCheckSetting.IsUseTaikaNotInputCheck
                        && invalidSiwake.Siwake.IsInputTaika && invalidSiwake.Siwake.IsGaikaTaikaKingakuNotInput;
                }

                invalidSiwake.ZeitaisyouKamokuNotInput = (!denpyouValidatorParameter.SyouhizeiMaster.AllowSyouhizeiTaisyouKamokuNotInputed && denpyouValidatorParameter.SyouhizeiMaster.ZeigakuKeisanHouhou == ZeigakuKeisanHouhou.税額仕訳から集計)
                    && (string.IsNullOrEmpty(invalidSiwake.Siwake.ZeitaisyouKamokuCode) && (denpyouValidatorParameter.SyouhizeiMaster.SyouhizeiKubun == SyouhizeiKubun.ZeinukiSyori || denpyouValidatorParameter.SyouhizeiMaster.SyouhizeiKubun == SyouhizeiKubun.IkkatuZeinukiSyori)
                    && ((karikataKamoku != null
                        && (karikataKamoku.SyoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || karikataKamoku.SyoriGroup == KamokuSyoriGroup.KariukeSyouhizei)
                        && (karikataKamoku.KazeiKubun == KazeiKubun.貨国税 || karikataKamoku.KazeiKubun == KazeiKubun.貨地方税 || karikataKamoku.KazeiKubun == KazeiKubun.消費税設定対象外))
                    || (kasikataKamoku != null
                        && (kasikataKamoku.SyoriGroup == KamokuSyoriGroup.KaribaraiSyouhizei || kasikataKamoku.SyoriGroup == KamokuSyoriGroup.KariukeSyouhizei)
                        && (kasikataKamoku.KazeiKubun == KazeiKubun.貨国税 || kasikataKamoku.KazeiKubun == KazeiKubun.貨地方税 || kasikataKamoku.KazeiKubun == KazeiKubun.消費税設定対象外))));

                if (invalidSiwake.Siwake.IsNew && invalidSiwake.Siwake.BunriKubun != BunriKubun.NotSet
                    && (invalidSiwake.Siwake.Syouhizeigaku != 0 || denpyouValidatorParameter.SyouhizeiMaster.IsCreateSyohizei0YenSiwake))
                {
                    // 新規仕訳は分離前の状態で分離子仕訳をチェック
                    this.ValidateSyouhizeiSiwakeKoumokuInputted(
                        invalidSiwake,
                        denpyouValidatorParameter.SyoriKikan,
                        denpyouValidatorParameter.SyouhizeiMaster,
                        denpyouKoumokuNotInputCheckSetting,
                        masterCacheRepository);
                }

                if (invalidSiwake.ContainsNotInputError)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.NotInputDenpyouKoumoku);
                }
            }
        }

        /// <summary>
        /// 消費税仕訳項目未入力チェック
        /// </summary>
        /// <param name="invalidSiwake"></param>
        /// <param name="syorikikan"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="denpyouKoumokuNotInputCheckSetting"></param>
        /// <param name="masterCache"></param>
        protected virtual void ValidateSyouhizeiSiwakeKoumokuInputted(
            InvalidSiwake invalidSiwake,
            IKaisyaSyoriKikan syorikikan,
            SyouhizeiMaster syouhizeiMaster,
            DenpyouKoumokuNotInputCheckSetting denpyouKoumokuNotInputCheckSetting,
            MasterCacheRepository masterCache)
        {
            // HACK 入力側で絞り込まれている前提の処理
            if (invalidSiwake.Siwake.KarikataKazeiKubun != KazeiKubun.対象外 && invalidSiwake.Siwake.KarikataKazeiKubun != KazeiKubun.消費税設定対象外)
            {
                var karikataSyouhizeiKamokuCode = invalidSiwake.Siwake.GetSyohizeiKamokuCode(
                    syouhizeiMaster,
                    masterCache.GetKamokuWithSecurity(invalidSiwake.Siwake.KarikataKamokuCode).SyoriGroup,
                    invalidSiwake.Siwake.KarikataKazeiKubun);
                var karikataKamoku = masterCache.GetKamokuWithSecurity(karikataSyouhizeiKamokuCode);
                invalidSiwake.KarikataBunriKamokuNotInput = karikataKamoku == null;
                if (karikataKamoku != null)
                {
                    invalidSiwake.KarikataSyouhizeiKamokuBumonNotInput = syorikikan.Syoriki.BumonInfo.Use && karikataKamoku.IsUseBumonNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode);
                    invalidSiwake.KarikataSyouhizeiKamokuTorihikisakiNotInput = syorikikan.Syoriki.TorihikisakiInfo.Use && karikataKamoku.IsUseTorihikisakiNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode);
                    invalidSiwake.KarikataSyouhizeiKamokuEdabanNotInput = syorikikan.Syoriki.EdabanInfo.Use && karikataKamoku.IsUseEdabanNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode);
                    invalidSiwake.KarikataSyouhizeiKamokuSegmentNotInput = syorikikan.Syoriki.SegmentInfo.Use && karikataKamoku.IsUseSegmentNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode);
                    invalidSiwake.KarikataSyouhizeiKamokuProjectNotInput = syorikikan.Syoriki.ProjectInfo.Use && karikataKamoku.IsUseProjectNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataProjectCode);
                    invalidSiwake.KarikataSyouhizeiKamokuKouziNotInput = syorikikan.Syoriki.KouziInfo.Use && karikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKouziCode);
                    invalidSiwake.KarikataSyouhizeiKamokuKousyuNotInput = syorikikan.Syoriki.KousyuInfo.Use && karikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKousyuCode);
                    invalidSiwake.KarikataSyouhizeiKamokuUniversalField1NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage != UniversalFieldUsageType.NotUse
                            && karikataKamoku.IsUseUniversalField1NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField1Code);

                    invalidSiwake.KarikataSyouhizeiKamokuUniversalField2NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage != UniversalFieldUsageType.NotUse
                        && karikataKamoku.IsUseUniversalField2NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField2Code);

                    invalidSiwake.KarikataSyouhizeiKamokuUniversalField3NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage != UniversalFieldUsageType.NotUse
                        && karikataKamoku.IsUseUniversalField3NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField3Code);
                    invalidSiwake.KarikataSyouhizeiKamokuTekiyouCodeNotInput = karikataKamoku.IsUseTekiyouCodeNotInputCheck && (invalidSiwake.Siwake.KarikataTekiyouCode == null || invalidSiwake.Siwake.KarikataTekiyouCode == 0);
                }
            }

            // HACK 入力側で絞り込まれている前提の処理
            if (invalidSiwake.Siwake.KasikataKazeiKubun != KazeiKubun.対象外 && invalidSiwake.Siwake.KasikataKazeiKubun != KazeiKubun.消費税設定対象外)
            {
                var kasikataSyouhizeiKamokuCode = invalidSiwake.Siwake.GetSyohizeiKamokuCode(
                    syouhizeiMaster,
                    masterCache.GetKamokuWithSecurity(invalidSiwake.Siwake.KasikataKamokuCode).SyoriGroup,
                    invalidSiwake.Siwake.KasikataKazeiKubun);
                var kasikataKamoku = masterCache.GetKamokuWithSecurity(kasikataSyouhizeiKamokuCode);
                invalidSiwake.KasikataBunriKamokuNotInput = kasikataKamoku == null;
                if (kasikataKamoku != null)
                {
                    invalidSiwake.KasikataSyouhizeiKamokuBumonNotInput = syorikikan.Syoriki.BumonInfo.Use && kasikataKamoku.IsUseBumonNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode);
                    invalidSiwake.KasikataSyouhizeiKamokuTorihikisakiNotInput = syorikikan.Syoriki.TorihikisakiInfo.Use && kasikataKamoku.IsUseTorihikisakiNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode);
                    invalidSiwake.KasikataSyouhizeiKamokuEdabanNotInput = syorikikan.Syoriki.EdabanInfo.Use && kasikataKamoku.IsUseEdabanNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode);
                    invalidSiwake.KasikataSyouhizeiKamokuSegmentNotInput = syorikikan.Syoriki.SegmentInfo.Use && kasikataKamoku.IsUseSegmentNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode);
                    invalidSiwake.KasikataSyouhizeiKamokuProjectNotInput = syorikikan.Syoriki.ProjectInfo.Use && kasikataKamoku.IsUseProjectNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataProjectCode);
                    invalidSiwake.KasikataSyouhizeiKamokuKouziNotInput = syorikikan.Syoriki.KouziInfo.Use && kasikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKouziCode);
                    invalidSiwake.KasikataSyouhizeiKamokuKousyuNotInput = syorikikan.Syoriki.KousyuInfo.Use && kasikataKamoku.IsUseKouziNotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKousyuCode);
                    invalidSiwake.KasikataSyouhizeiKamokuUniversalField1NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage != UniversalFieldUsageType.NotUse
                        && kasikataKamoku.IsUseUniversalField1NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField1Code);

                    invalidSiwake.KasikataSyouhizeiKamokuUniversalField2NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage != UniversalFieldUsageType.NotUse
                        && kasikataKamoku.IsUseUniversalField2NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField2Code);

                    invalidSiwake.KasikataSyouhizeiKamokuUniversalField3NotInput = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage != UniversalFieldUsageType.NotUse
                        && kasikataKamoku.IsUseUniversalField3NotInputCheck && string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField3Code);
                    invalidSiwake.KasikataSyouhizeiKamokuTekiyouCodeNotInput = kasikataKamoku.IsUseTekiyouCodeNotInputCheck && (invalidSiwake.Siwake.KasikataTekiyouCode == null || invalidSiwake.Siwake.KasikataTekiyouCode == 0);
                }
            }
        }

        /// <summary>
        /// 伝票ヘッダー項目未登録チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        /// <param name="syorikikan"></param>
        /// <param name="masterCacheRepository"></param>
        protected virtual void ValidateDenpyouHeaderKoumokuRegistered(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyou,
            IKaisyaSyoriKikan syorikikan,
            MasterCacheRepository masterCacheRepository)
        {
            denpyouValidationResult.InvalidDenpyouHeader.HeaderField1Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 1).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField1Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 1), denpyou.HeaderField1Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField2Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 2).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField2Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 2), denpyou.HeaderField2Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField3Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 3).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField3Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 3), denpyou.HeaderField3Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField4Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 4).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField4Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 4), denpyou.HeaderField4Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField5Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 5).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField5Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 5), denpyou.HeaderField5Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField6Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 6).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField6Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 6), denpyou.HeaderField6Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField7Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 7).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField7Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 7), denpyou.HeaderField7Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField8Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 8).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField8Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 8), denpyou.HeaderField8Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField9Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 9).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField9Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 9), denpyou.HeaderField9Code);

            denpyouValidationResult.InvalidDenpyouHeader.HeaderField10Unregistered =
                syorikikan.Syoriki.GetUniversalFieldInfo(true, 10).IsCreateMaster
                && !string.IsNullOrEmpty(denpyou.HeaderField10Code)
                && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(true, 10), denpyou.HeaderField10Code);

            if (denpyouValidationResult.InvalidDenpyouHeader.ContainsUnregisteredError)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.UnregisteredDenpyouKoumoku);
            }

            return;
        }

        /// <summary>
        /// 仕訳項目未登録チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="syorikikan"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="masterCacheRepository"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "これ以上の分割不可")]
        protected virtual void ValidateSiwakeKoumokuRegistered(
            DenpyouValidationResult denpyouValidationResult,
            IKaisyaSyoriKikan syorikikan,
            SyouhizeiMaster syouhizeiMaster,
            MasterCacheRepository masterCacheRepository)
        {
            foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList.Where(invalidSiwake => !invalidSiwake.Siwake.HasCodeSecurity))
            {
                var karikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KarikataKamokuCode);
                if (karikataKamoku == null)
                {
                    // 科目未入力の場合は登録不可
                    return;
                }

                invalidSiwake.KarikataBumonUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonWithSecurity(invalidSiwake.Siwake.KarikataBumonCode);

                invalidSiwake.KarikataBumonKamokuUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonKamokuZandaka(invalidSiwake.Siwake.KarikataBumonCode, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataTorihikisakiUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiWithSecurity(invalidSiwake.Siwake.KarikataTorihikisakiCode);

                invalidSiwake.KarikataTorihikisakiKamokuUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiKamokuZandaka(invalidSiwake.Siwake.KarikataTorihikisakiCode, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataEdabanUnregistered = syorikikan.Syoriki.EdabanInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode)
                    && !masterCacheRepository.GetExistsKamokuEdabanWithSecurity(invalidSiwake.Siwake.KarikataKamokuCode, invalidSiwake.Siwake.KarikataEdabanCode);

                invalidSiwake.KarikataBumonKamokuEdabanUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.EdabanInfo.Use
                    && karikataKamoku.AllowUseBumonKamokuEdaban
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode)
                    && !masterCacheRepository.GetExistsBumonKamokuEdabanZandaka(invalidSiwake.Siwake.KarikataBumonCode, invalidSiwake.Siwake.KarikataKamokuCode, invalidSiwake.Siwake.KarikataEdabanCode);

                invalidSiwake.KarikataBumonKamokuTorihikisakiUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && karikataKamoku.AllowUseBumonTorihikisakiKamoku
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsBumonKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KarikataBumonCode, invalidSiwake.Siwake.KarikataKamokuCode, invalidSiwake.Siwake.KarikataTorihikisakiCode);

                invalidSiwake.KarikataSegmentUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegment(invalidSiwake.Siwake.KarikataSegmentCode);

                invalidSiwake.KarikataSegmentKamokuUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuZandaka(invalidSiwake.Siwake.KarikataSegmentCode, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataSegmentKamokuTorihikisakiUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && karikataKamoku.AllowUseSegmentKamokuTorihikisaki
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KarikataSegmentCode, invalidSiwake.Siwake.KarikataKamokuCode, invalidSiwake.Siwake.KarikataTorihikisakiCode);

                invalidSiwake.KarikataProjectUnregistered = syorikikan.Syoriki.ProjectInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataProjectCode)
                    && !masterCacheRepository.GetExistsProject(invalidSiwake.Siwake.KarikataProjectCode);

                invalidSiwake.KarikataKouziUnregistered = syorikikan.Syoriki.KouziInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKouziCode)
                    && !masterCacheRepository.GetExistsKouzi(invalidSiwake.Siwake.KarikataKouziCode);

                invalidSiwake.KarikataKousyuUnregistered = syorikikan.Syoriki.KousyuInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataKousyuCode)
                    && !masterCacheRepository.GetExistsKousyu(invalidSiwake.Siwake.KarikataKousyuCode);

                invalidSiwake.KarikataUniversalField1Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KarikataUniversalField1Code);

                invalidSiwake.KarikataUniversalField2Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KarikataUniversalField2Code);

                invalidSiwake.KarikataUniversalField3Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KarikataUniversalField3Code);

                invalidSiwake.KarikataUniversalField4Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 4).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField4Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 4), invalidSiwake.Siwake.KarikataUniversalField4Code);

                invalidSiwake.KarikataUniversalField5Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 5).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField5Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 5), invalidSiwake.Siwake.KarikataUniversalField5Code);

                invalidSiwake.KarikataUniversalField6Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 6).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField6Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 6), invalidSiwake.Siwake.KarikataUniversalField6Code);

                invalidSiwake.KarikataUniversalField7Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 7).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField7Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 7), invalidSiwake.Siwake.KarikataUniversalField7Code);

                invalidSiwake.KarikataUniversalField8Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 8).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField8Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 8), invalidSiwake.Siwake.KarikataUniversalField8Code);

                invalidSiwake.KarikataUniversalField9Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 9).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField9Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 9), invalidSiwake.Siwake.KarikataUniversalField9Code);

                invalidSiwake.KarikataUniversalField10Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 10).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField10Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 10), invalidSiwake.Siwake.KarikataUniversalField10Code);

                invalidSiwake.KarikataUniversalField11Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 11).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField11Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 11), invalidSiwake.Siwake.KarikataUniversalField11Code);

                invalidSiwake.KarikataUniversalField12Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 12).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField12Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 12), invalidSiwake.Siwake.KarikataUniversalField12Code);

                invalidSiwake.KarikataUniversalField13Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 13).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField13Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 13), invalidSiwake.Siwake.KarikataUniversalField13Code);

                invalidSiwake.KarikataUniversalField14Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 14).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField14Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 14), invalidSiwake.Siwake.KarikataUniversalField14Code);

                invalidSiwake.KarikataUniversalField15Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 15).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField15Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 15), invalidSiwake.Siwake.KarikataUniversalField15Code);

                invalidSiwake.KarikataUniversalField16Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 16).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField16Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 16), invalidSiwake.Siwake.KarikataUniversalField16Code);

                invalidSiwake.KarikataUniversalField17Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 17).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField17Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 17), invalidSiwake.Siwake.KarikataUniversalField17Code);

                invalidSiwake.KarikataUniversalField18Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 18).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField18Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 18), invalidSiwake.Siwake.KarikataUniversalField18Code);

                invalidSiwake.KarikataUniversalField19Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 19).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField19Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 19), invalidSiwake.Siwake.KarikataUniversalField19Code);

                invalidSiwake.KarikataUniversalField20Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 20).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField20Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 20), invalidSiwake.Siwake.KarikataUniversalField20Code);

                invalidSiwake.KarikataUniversalField1KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KarikataUniversalField1Code, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataUniversalField2KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KarikataUniversalField2Code, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataUniversalField3KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KarikataUniversalField3Code, invalidSiwake.Siwake.KarikataKamokuCode);

                invalidSiwake.KarikataTekiyouCodeUnregistered = invalidSiwake.Siwake.KarikataTekiyouCode != null
                    && !masterCacheRepository.GetExistsZiyuuTekiyou(invalidSiwake.Siwake.KarikataTekiyouCode ?? 0);

                var kasikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KasikataKamokuCode);
                if (kasikataKamoku == null)
                {
                    // 科目未入力の場合は登録不可
                    return;
                }

                invalidSiwake.KasikataBumonUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonWithSecurity(invalidSiwake.Siwake.KasikataBumonCode);

                invalidSiwake.KasikataBumonKamokuUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonKamokuZandaka(invalidSiwake.Siwake.KasikataBumonCode, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataTorihikisakiUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiWithSecurity(invalidSiwake.Siwake.KasikataTorihikisakiCode);

                invalidSiwake.KasikataTorihikisakiKamokuUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiKamokuZandaka(invalidSiwake.Siwake.KasikataTorihikisakiCode, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataEdabanUnregistered = syorikikan.Syoriki.EdabanInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode)
                    && !masterCacheRepository.GetExistsKamokuEdabanWithSecurity(invalidSiwake.Siwake.KasikataKamokuCode, invalidSiwake.Siwake.KasikataEdabanCode);

                invalidSiwake.KasikataBumonKamokuEdabanUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.EdabanInfo.Use
                    && kasikataKamoku.AllowUseBumonKamokuEdaban
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode)
                    && !masterCacheRepository.GetExistsBumonKamokuEdabanZandaka(invalidSiwake.Siwake.KasikataBumonCode, invalidSiwake.Siwake.KasikataKamokuCode, invalidSiwake.Siwake.KasikataEdabanCode);

                invalidSiwake.KasikataBumonKamokuTorihikisakiUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && kasikataKamoku.AllowUseBumonTorihikisakiKamoku
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsBumonKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KasikataBumonCode, invalidSiwake.Siwake.KasikataKamokuCode, invalidSiwake.Siwake.KasikataTorihikisakiCode);

                invalidSiwake.KasikataSegmentUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegment(invalidSiwake.Siwake.KasikataSegmentCode);

                invalidSiwake.KasikataSegmentKamokuUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuZandaka(invalidSiwake.Siwake.KasikataSegmentCode, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataSegmentKamokuTorihikisakiUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && kasikataKamoku.AllowUseSegmentKamokuTorihikisaki
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KasikataSegmentCode, invalidSiwake.Siwake.KasikataKamokuCode, invalidSiwake.Siwake.KasikataTorihikisakiCode);

                invalidSiwake.KasikataProjectUnregistered = syorikikan.Syoriki.ProjectInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataProjectCode)
                    && !masterCacheRepository.GetExistsProject(invalidSiwake.Siwake.KasikataProjectCode);

                invalidSiwake.KasikataKouziUnregistered = syorikikan.Syoriki.KouziInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKouziCode)
                    && !masterCacheRepository.GetExistsKouzi(invalidSiwake.Siwake.KasikataKouziCode);

                invalidSiwake.KasikataKousyuUnregistered = syorikikan.Syoriki.KousyuInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataKousyuCode)
                    && !masterCacheRepository.GetExistsKousyu(invalidSiwake.Siwake.KasikataKousyuCode);

                invalidSiwake.KasikataUniversalField1Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KasikataUniversalField1Code);

                invalidSiwake.KasikataUniversalField2Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KasikataUniversalField2Code);

                invalidSiwake.KasikataUniversalField3Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KasikataUniversalField3Code);

                invalidSiwake.KasikataUniversalField4Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 4).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField4Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 4), invalidSiwake.Siwake.KasikataUniversalField4Code);

                invalidSiwake.KasikataUniversalField5Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 5).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField5Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 5), invalidSiwake.Siwake.KasikataUniversalField5Code);

                invalidSiwake.KasikataUniversalField6Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 6).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField6Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 6), invalidSiwake.Siwake.KasikataUniversalField6Code);

                invalidSiwake.KasikataUniversalField7Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 7).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField7Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 7), invalidSiwake.Siwake.KasikataUniversalField7Code);

                invalidSiwake.KasikataUniversalField8Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 8).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField8Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 8), invalidSiwake.Siwake.KasikataUniversalField8Code);

                invalidSiwake.KasikataUniversalField9Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 9).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField9Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 9), invalidSiwake.Siwake.KasikataUniversalField9Code);

                invalidSiwake.KasikataUniversalField10Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 10).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField10Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 10), invalidSiwake.Siwake.KasikataUniversalField10Code);

                invalidSiwake.KasikataUniversalField11Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 11).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField11Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 11), invalidSiwake.Siwake.KasikataUniversalField11Code);

                invalidSiwake.KasikataUniversalField12Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 12).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField12Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 12), invalidSiwake.Siwake.KasikataUniversalField12Code);

                invalidSiwake.KasikataUniversalField13Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 13).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField13Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 13), invalidSiwake.Siwake.KasikataUniversalField13Code);

                invalidSiwake.KasikataUniversalField14Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 14).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField14Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 14), invalidSiwake.Siwake.KasikataUniversalField14Code);

                invalidSiwake.KasikataUniversalField15Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 15).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField15Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 15), invalidSiwake.Siwake.KasikataUniversalField15Code);

                invalidSiwake.KasikataUniversalField16Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 16).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField16Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 16), invalidSiwake.Siwake.KasikataUniversalField16Code);

                invalidSiwake.KasikataUniversalField17Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 17).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField17Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 17), invalidSiwake.Siwake.KasikataUniversalField17Code);

                invalidSiwake.KasikataUniversalField18Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 18).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField18Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 18), invalidSiwake.Siwake.KasikataUniversalField18Code);

                invalidSiwake.KasikataUniversalField19Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 19).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField19Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 19), invalidSiwake.Siwake.KasikataUniversalField19Code);

                invalidSiwake.KasikataUniversalField20Unregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 20).IsCreateMaster
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField20Code)
                    && !masterCacheRepository.GetExistsUniversalField(syorikikan.Syoriki.GetUniversalFieldInfo(false, 20), invalidSiwake.Siwake.KasikataUniversalField20Code);

                invalidSiwake.KasikataUniversalField1KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KasikataUniversalField1Code, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataUniversalField2KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KasikataUniversalField2Code, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataUniversalField3KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KasikataUniversalField3Code, invalidSiwake.Siwake.KasikataKamokuCode);

                invalidSiwake.KasikataTekiyouCodeUnregistered = invalidSiwake.Siwake.KasikataTekiyouCode != null
                    && !masterCacheRepository.GetExistsZiyuuTekiyou(invalidSiwake.Siwake.KasikataTekiyouCode ?? 0);

                if (invalidSiwake.Siwake.IsNew && invalidSiwake.Siwake.BunriKubun != BunriKubun.NotSet
                    && (invalidSiwake.Siwake.Syouhizeigaku != 0 || syouhizeiMaster.IsCreateSyohizei0YenSiwake))
                {
                    // 新規仕訳は分離前の状態で分離子仕訳をチェック
                    this.ValidateSyouhizeiSiwakeKoumokuRegistered(
                        invalidSiwake,
                        syorikikan,
                        syouhizeiMaster,
                        masterCacheRepository);
                }

                if (invalidSiwake.ContainsUnregisteredError)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.UnregisteredDenpyouKoumoku);
                }
            }
        }

        /// <summary>
        /// 消費税仕訳項目未登録チェック
        /// </summary>
        /// <param name="invalidSiwake"></param>
        /// <param name="syorikikan"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="masterCacheRepository"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "これ以上の分割不可")]
        protected virtual void ValidateSyouhizeiSiwakeKoumokuRegistered(
            InvalidSiwake invalidSiwake,
            IKaisyaSyoriKikan syorikikan,
            SyouhizeiMaster syouhizeiMaster,
            MasterCacheRepository masterCacheRepository)
        {
            // HACK 入力側で絞り込まれている前提の処理
            if (invalidSiwake.Siwake.KarikataKazeiKubun != KazeiKubun.対象外 && invalidSiwake.Siwake.KarikataKazeiKubun != KazeiKubun.消費税設定対象外)
            {
                invalidSiwake.KarikataSyouhizeiSiwakeKamokuCode = invalidSiwake.Siwake.GetSyohizeiKamokuCode(
                    syouhizeiMaster,
                    masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KarikataKamokuCode).SyoriGroup,
                    invalidSiwake.Siwake.KarikataKazeiKubun);
                var karikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.KarikataSyouhizeiSiwakeKamokuCode);
                if (karikataKamoku == null)
                {
                    // 科目未入力の場合は登録不可
                    return;
                }

                invalidSiwake.KarikataSyouhizeiKamokuBumonKamokuUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonKamokuZandaka(invalidSiwake.Siwake.KarikataBumonCode, karikataKamoku.InnerCode);

                invalidSiwake.KarikataSyouhizeiKamokuTorihikisakiKamokuUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiKamokuZandaka(invalidSiwake.Siwake.KarikataTorihikisakiCode, karikataKamoku.InnerCode);

                invalidSiwake.KarikataSyouhizeiKamokuEdabanUnregistered = syorikikan.Syoriki.EdabanInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode)
                    && !masterCacheRepository.GetExistsKamokuEdabanWithSecurity(karikataKamoku.InnerCode, invalidSiwake.Siwake.KarikataEdabanCode);

                invalidSiwake.KarikataSyouhizeiKamokuBumonKamokuEdabanUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.EdabanInfo.Use
                    && karikataKamoku.AllowUseBumonKamokuEdaban
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataEdabanCode)
                    && !masterCacheRepository.GetExistsBumonKamokuEdabanZandaka(invalidSiwake.Siwake.KarikataBumonCode, karikataKamoku.InnerCode, invalidSiwake.Siwake.KarikataEdabanCode);

                invalidSiwake.KarikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && karikataKamoku.AllowUseBumonTorihikisakiKamoku
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsBumonKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KarikataBumonCode, karikataKamoku.InnerCode, invalidSiwake.Siwake.KarikataTorihikisakiCode);

                invalidSiwake.KarikataSyouhizeiKamokuSegmentKamokuUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuZandaka(invalidSiwake.Siwake.KarikataSegmentCode, karikataKamoku.InnerCode);

                invalidSiwake.KarikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && karikataKamoku.AllowUseSegmentKamokuTorihikisaki
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataSegmentCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KarikataSegmentCode, karikataKamoku.InnerCode, invalidSiwake.Siwake.KarikataTorihikisakiCode);

                invalidSiwake.KarikataSyouhizeiKamokuUniversalField1KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KarikataUniversalField1Code, karikataKamoku.InnerCode);

                invalidSiwake.KarikataSyouhizeiKamokuUniversalField2KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KarikataUniversalField2Code, karikataKamoku.InnerCode);

                invalidSiwake.KarikataSyouhizeiKamokuUniversalField3KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KarikataUniversalField3Code, karikataKamoku.InnerCode);
            }

            // HACK 入力側で絞り込まれている前提の処理
            if (invalidSiwake.Siwake.KasikataKazeiKubun != KazeiKubun.対象外 && invalidSiwake.Siwake.KasikataKazeiKubun != KazeiKubun.消費税設定対象外)
            {
                invalidSiwake.KasikataSyouhizeiSiwakeKamokuCode = invalidSiwake.Siwake.GetSyohizeiKamokuCode(
                    syouhizeiMaster,
                    masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.Siwake.KasikataKamokuCode).SyoriGroup,
                    invalidSiwake.Siwake.KasikataKazeiKubun);
                var kasikataKamoku = masterCacheRepository.GetKamokuWithSecurity(invalidSiwake.KasikataSyouhizeiSiwakeKamokuCode);
                if (kasikataKamoku == null)
                {
                    // 科目未入力の場合は登録不可
                    return;
                }

                invalidSiwake.KasikataSyouhizeiKamokuBumonKamokuUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !masterCacheRepository.GetExistsBumonKamokuZandaka(invalidSiwake.Siwake.KasikataBumonCode, kasikataKamoku.InnerCode);

                invalidSiwake.KasikataSyouhizeiKamokuTorihikisakiKamokuUnregistered = syorikikan.Syoriki.TorihikisakiInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsTorihikisakiKamokuZandaka(invalidSiwake.Siwake.KasikataTorihikisakiCode, kasikataKamoku.InnerCode);

                invalidSiwake.KasikataSyouhizeiKamokuEdabanUnregistered = syorikikan.Syoriki.EdabanInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode)
                    && !masterCacheRepository.GetExistsKamokuEdabanWithSecurity(kasikataKamoku.InnerCode, invalidSiwake.Siwake.KasikataEdabanCode);

                invalidSiwake.KasikataSyouhizeiKamokuBumonKamokuEdabanUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.EdabanInfo.Use
                    && kasikataKamoku.AllowUseBumonKamokuEdaban
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataEdabanCode)
                    && !masterCacheRepository.GetExistsBumonKamokuEdabanZandaka(invalidSiwake.Siwake.KasikataBumonCode, kasikataKamoku.InnerCode, invalidSiwake.Siwake.KasikataEdabanCode);

                invalidSiwake.KasikataSyouhizeiKamokuBumonKamokuTorihikisakiUnregistered = syorikikan.Syoriki.BumonInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && kasikataKamoku.AllowUseBumonTorihikisakiKamoku
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsBumonKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KasikataBumonCode, kasikataKamoku.InnerCode, invalidSiwake.Siwake.KasikataTorihikisakiCode);

                invalidSiwake.KasikataSyouhizeiKamokuSegmentKamokuUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuZandaka(invalidSiwake.Siwake.KasikataSegmentCode, kasikataKamoku.InnerCode);

                invalidSiwake.KasikataSyouhizeiKamokuSegmentKamokuTorihikisakiUnregistered = syorikikan.Syoriki.SegmentInfo.Use
                    && syorikikan.Syoriki.TorihikisakiInfo.Use
                    && kasikataKamoku.AllowUseSegmentKamokuTorihikisaki
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataSegmentCode)
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode)
                    && !masterCacheRepository.GetExistsSegmentKamokuTorihikisakiZandaka(invalidSiwake.Siwake.KasikataSegmentCode, kasikataKamoku.InnerCode, invalidSiwake.Siwake.KasikataTorihikisakiCode);

                invalidSiwake.KasikataSyouhizeiKamokuUniversalField1KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 1).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField1Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 1), invalidSiwake.Siwake.KasikataUniversalField1Code, kasikataKamoku.InnerCode);

                invalidSiwake.KasikataSyouhizeiKamokuUniversalField2KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 2).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField2Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 2), invalidSiwake.Siwake.KasikataUniversalField2Code, kasikataKamoku.InnerCode);

                invalidSiwake.KasikataSyouhizeiKamokuUniversalField3KamokuUnregistered = syorikikan.Syoriki.GetUniversalFieldInfo(false, 3).Usage == UniversalFieldUsageType.UseAsZandaka
                    && !string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataUniversalField3Code)
                    && !masterCacheRepository.GetExistsUniversalFieldKamokuZandaka(syorikikan.Syoriki.GetUniversalFieldInfo(false, 3), invalidSiwake.Siwake.KasikataUniversalField3Code, kasikataKamoku.InnerCode);
            }
        }

        /// <summary>
        /// 伝票合計チェック
        /// HACK 登録対象外仕訳は取り除かれている前提の処理
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        /// <param name="syouhizeiMaster"></param>
        protected virtual void ValidateKingakuGoukei(DenpyouValidationResult denpyouValidationResult, Denpyou denpyou, SyouhizeiMaster syouhizeiMaster)
        {
            if (denpyou.DenpyouKeisiki != DenpyouKeisiki.Hukugou)
            {
                var tannituSiwakeGroupGoukeiList = denpyou.CreateTannituSiwakeGroupGoukeiList(syouhizeiMaster, true);
                if (tannituSiwakeGroupGoukeiList.Sum(tannituSiwakeDenpyouGoukei => tannituSiwakeDenpyouGoukei.SyokutiSagaku) != 0)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.TaisyakuGoukeiUnmatch);
                }

                return;
            }

            var hukugouSiwakeGroupGoukeiList = denpyou.CreateHukugouSiwakeGroupGoukeiList(syouhizeiMaster, true);
            if (hukugouSiwakeGroupGoukeiList.Sum(hukugouSiwakeDenpyouGoukei => hukugouSiwakeDenpyouGoukei.TaisyakuSagaku) != 0
                || hukugouSiwakeGroupGoukeiList.Sum(hukugouSiwakeDenpyouGoukei => hukugouSiwakeDenpyouGoukei.SyokutiSagaku) != 0)
            {
                denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.TaisyakuGoukeiUnmatch);
            }

            return;
        }

        /// <summary>
        /// 税率チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        protected virtual void ValidateZeiritu(DenpyouValidationResult denpyouValidationResult, Denpyou denpyou)
        {
            var checkTargetSyouhizeirituList = this.syouhizeirituRepository.FindAllOrderById()
                .Where(syouhizeiritu => syouhizeiritu.Id >= 3 && syouhizeiritu.StartDate.Ymd > denpyou.DenpyouHizuke);
            if (checkTargetSyouhizeirituList.Count() == 0)
            {
                return;
            }

            foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList)
            {
                invalidSiwake.KarikataZeirituInvalid = checkTargetSyouhizeirituList
                    .FirstOrDefault(checkTargetSyouhizeiritu => invalidSiwake.Siwake.KarikataZeiritu == checkTargetSyouhizeiritu.Zeiritu
                        && invalidSiwake.Siwake.IsKeigenZeirituKarikata == checkTargetSyouhizeiritu.IsKeigenzeiritu) != null;
                invalidSiwake.KasikataZeirituInvalid = checkTargetSyouhizeirituList
                    .FirstOrDefault(checkTargetSyouhizeiritu => invalidSiwake.Siwake.KasikataZeiritu == checkTargetSyouhizeiritu.Zeiritu
                        && invalidSiwake.Siwake.IsKeigenZeirituKasikata == checkTargetSyouhizeiritu.IsKeigenzeiritu) != null;
                if (invalidSiwake.KarikataZeirituInvalid || invalidSiwake.KasikataZeirituInvalid)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.InputtedUnavailableZeiritu);
                }
            }
        }

        /// <summary>
        /// 支払日チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="syorikikan"></param>
        /// <param name="denpyou"></param>
        /// <param name="shouldCheckSiharaibi"></param>
        protected virtual void ValidateSiharaibi(
            DenpyouValidationResult denpyouValidationResult,
            IKaisyaSyoriKikan syorikikan,
            Denpyou denpyou,
            bool shouldCheckSiharaibi)
        {
            if (syorikikan.Syoriki.UseSiharaibi && shouldCheckSiharaibi)
            {
                foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList)
                {
                    if (invalidSiwake.SiharaibiInvalid = invalidSiwake.Siwake.Siharaibi != 0
                        && invalidSiwake.Siwake.Siharaibi < denpyou.DenpyouHizuke)
                    {
                        denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.SiharaibiDenpyouhizukeBefore);
                    }
                }
            }
        }

        /// <summary>
        /// 部門入力可能期間チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="syorikikan"></param>
        /// <param name="denpyou"></param>
        /// <param name="shouldCheckPeriodInputtableBumon"></param>
        /// <param name="masterCacheRepository"></param>
        protected virtual void ValidatePeriodInputtableBumon(
            DenpyouValidationResult denpyouValidationResult,
            IKaisyaSyoriKikan syorikikan,
            Denpyou denpyou,
            bool shouldCheckPeriodInputtableBumon,
            MasterCacheRepository masterCacheRepository)
        {
            if (syorikikan.Syoriki.BumonInfo.Use && shouldCheckPeriodInputtableBumon)
            {
                foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList)
                {
                    if (!string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataBumonCode))
                    {
                        var karikataBumon = masterCacheRepository.GetBumonWithSecurity(invalidSiwake.Siwake.KarikataBumonCode);
                        if (karikataBumon != null)
                        {
                            invalidSiwake.KarikataBumonOutsideInputtablePeriod =
                                (karikataBumon.HasInputStartDate && karikataBumon.InputStartDate.Ymd > denpyou.DenpyouHizuke)
                                || (karikataBumon.HasInputEndDate && karikataBumon.InputEndDate.Ymd < denpyou.DenpyouHizuke);
                        }
                    }

                    if (!string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataBumonCode))
                    {
                        var kasikataBumon = masterCacheRepository.GetBumonWithSecurity(invalidSiwake.Siwake.KasikataBumonCode);
                        if (kasikataBumon != null)
                        {
                            invalidSiwake.KasikataBumonOutsideInputtablePeriod =
                                (kasikataBumon.HasInputStartDate && kasikataBumon.InputStartDate.Ymd > denpyou.DenpyouHizuke)
                                || (kasikataBumon.HasInputEndDate && kasikataBumon.InputEndDate.Ymd < denpyou.DenpyouHizuke);
                        }
                    }

                    if (invalidSiwake.KarikataBumonOutsideInputtablePeriod || invalidSiwake.KasikataBumonOutsideInputtablePeriod)
                    {
                        denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.CanNotInputBumonToOutOfInputtablePeriod);
                    }
                }
            }
        }

        /// <summary>
        /// 取引先入力可能期間チェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="syorikikan"></param>
        /// <param name="denpyou"></param>
        /// <param name="shouldCheckPeriodInputtableTorihikisaki"></param>
        /// <param name="masterCacheRepository"></param>
        protected virtual void ValidatePeriodInputtableTorihikisaki(
            DenpyouValidationResult denpyouValidationResult,
            IKaisyaSyoriKikan syorikikan,
            Denpyou denpyou,
            bool shouldCheckPeriodInputtableTorihikisaki,
            MasterCacheRepository masterCacheRepository)
        {
            if (syorikikan.Syoriki.TorihikisakiInfo.Use && shouldCheckPeriodInputtableTorihikisaki)
            {
                foreach (var invalidSiwake in denpyouValidationResult.InvalidSiwakeList)
                {
                    if (!string.IsNullOrEmpty(invalidSiwake.Siwake.KarikataTorihikisakiCode))
                    {
                        var karikataTorihikisaki = masterCacheRepository.GetTorihikisakiWithSecurity(invalidSiwake.Siwake.KarikataTorihikisakiCode);
                        if (karikataTorihikisaki != null)
                        {
                            invalidSiwake.KarikataTorihikisakiOutsideInputtablePeriod =
                                (karikataTorihikisaki.HasInputStartDate && karikataTorihikisaki.InputStartDate.Ymd > denpyou.DenpyouHizuke)
                                || (karikataTorihikisaki.HasInputEndDate && karikataTorihikisaki.InputEndDate.Ymd < denpyou.DenpyouHizuke);
                        }
                    }

                    if (!string.IsNullOrEmpty(invalidSiwake.Siwake.KasikataTorihikisakiCode))
                    {
                        var kasikataTorihikisaki = masterCacheRepository.GetTorihikisakiWithSecurity(invalidSiwake.Siwake.KasikataTorihikisakiCode);
                        if (kasikataTorihikisaki != null)
                        {
                            invalidSiwake.KasikataTorihikisakiOutsideInputtablePeriod =
                                (kasikataTorihikisaki.HasInputStartDate && kasikataTorihikisaki.InputStartDate.Ymd > denpyou.DenpyouHizuke)
                                || (kasikataTorihikisaki.HasInputEndDate && kasikataTorihikisaki.InputEndDate.Ymd < denpyou.DenpyouHizuke);
                        }
                    }

                    if (invalidSiwake.KarikataTorihikisakiOutsideInputtablePeriod || invalidSiwake.KasikataTorihikisakiOutsideInputtablePeriod)
                    {
                        denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.CanNotInputTorihikisakiToOutOfInputtablePeriod);
                    }
                }
            }
        }

        /// <summary>
        /// 伝票が他で変更されていないかチェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyouOld"></param>
        /// <param name="denpyouType"></param>
        protected virtual void ValidateKizonDenpyou(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyouOld,
            DenpyouType denpyouType)
        {
            if (denpyouOld == null)
            {
                return;
            }

            var denpyouDataBaseValue = this.denpyouRepository.FindByKesnAndDkeiAndDseqAndIsTorikesi(
                denpyouOld.Kesn,
                denpyouOld.Dkei,
                denpyouOld.DenpyouSequenceNumber,
                denpyouType);

            if (denpyouOld.DenpyouHizuke != denpyouDataBaseValue.DenpyouHizuke
                || denpyouOld.DenpyouNo != denpyouDataBaseValue.DenpyouNo
                || denpyouOld.DenpyouKeisiki != denpyouDataBaseValue.DenpyouKeisiki
                || denpyouOld.DenpyouKousinbi != denpyouDataBaseValue.DenpyouKousinbi
                || denpyouOld.DenpyouKousinZikan != denpyouDataBaseValue.DenpyouKousinZikan
                || denpyouOld.UketukeNo != denpyouDataBaseValue.UketukeNo
                || denpyouOld.SyouninZyoukyou != denpyouDataBaseValue.SyouninZyoukyou
                || denpyouOld.RirekiNumber != denpyouDataBaseValue.RirekiNumber
                || denpyouOld.RirekiDenpyouSequence != denpyouDataBaseValue.RirekiDenpyouSequence)
            {
                denpyouValidationResult.DenpyouInvalidReasonList.Add(DenpyouInvalidReason.SiwakeChangedByOther);
                return;
            }

            foreach (var siwakeDataBaseValue in denpyouDataBaseValue.SiwakeList)
            {
                if (denpyouOld.SiwakeList.FirstOrDefault(siwakeOld => siwakeOld.SiwakeSequenceNumber == siwakeDataBaseValue.SiwakeSequenceNumber
                    && siwakeOld.GroupNumber == siwakeDataBaseValue.GroupNumber
                    && siwakeOld.LineNo == siwakeDataBaseValue.LineNo
                    && siwakeOld.SiwakeTaisyakuZokusei == siwakeDataBaseValue.SiwakeTaisyakuZokusei
                    && siwakeOld.SiwakeKousinbi == siwakeDataBaseValue.SiwakeKousinbi
                    && siwakeOld.SiwakeKousinZikan == siwakeDataBaseValue.SiwakeKousinZikan) == null)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.SiwakeChangedByOther);
                    return;
                }
            }
        }

        /// <summary>
        /// 電子帳簿保存の特例に関するチェック
        /// </summary>
        /// <param name="denpyouValidationResult"></param>
        /// <param name="denpyou"></param>
        /// <param name="syorikikan"></param>
        /// <param name="isTorikesi"></param>
        protected virtual void ValidateDensityouboHozon(
            DenpyouValidationResult denpyouValidationResult,
            Denpyou denpyou,
            IKaisyaSyoriKikan syorikikan,
            bool isTorikesi)
        {
            if (denpyou.IsNew)
            {
                return;
            }

            if (syorikikan.Syoriki.DensiTyouboHozonUsage != DensiTyouboHozonUsage.LimitEditAndDelteSiwake)
            {
                return;
            }

            // 電子帳簿保存の特例を使用する場合
            var currentTimestamp = this.dbUtilityDao.GetCurrentTimestamp();
            var timeSpan = new TimeSpan(syorikikan.Syoriki.DensiTyouboHozonDays, 0, 0, 0);
            var changeableDate = new IcspDateTime(currentTimestamp - timeSpan);

            foreach (var siwake in denpyou.SiwakeList)
            {
                if (!siwake.IsNew && siwake.SiwakeSakuseibi < changeableDate.Ymd)
                {
                    denpyouValidationResult.AddDenpyouInvalidReason(DenpyouInvalidReason.ElapsedDaysChangeableSiwake);
                    return;
                }
            }
        }
    }
}
