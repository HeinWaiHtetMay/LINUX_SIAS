﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class DenpyouNoDuplicationValidationResult
    {
        public DenpyouNoDuplicationValidationResult() => this.DuplicationDenpyouType = null;

        public DenpyouNoDuplicationValidationResult(DenpyouType? duplicationDenpyouType) =>
            this.DuplicationDenpyouType = duplicationDenpyouType;

        public bool HasDuplication => this.DuplicationDenpyouType != null;

        public DenpyouType? DuplicationDenpyouType { get; }
    }
}
