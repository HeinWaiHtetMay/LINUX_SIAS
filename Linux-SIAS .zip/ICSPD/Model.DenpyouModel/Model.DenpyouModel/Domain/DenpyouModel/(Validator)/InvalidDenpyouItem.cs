﻿using System.Reflection;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public class InvalidDenpyouItem
    {
        private readonly string notInputErrorPropertyNamePartial = "NotInput";
        private readonly string unregisteredErrorPropertyNamePartial = "Unregistered";

        /// <summary>
        /// エラーを含んでいるか
        /// </summary>
        public bool ContainsError
        {
            get
            {
                PropertyInfo[] infoArray = this.GetType().GetProperties();
                foreach (var info in infoArray)
                {
                    if (info.Name != nameof(this.ContainsError)
                        && info.PropertyType == typeof(bool)
                        && (bool)info.GetValue(this))
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// 未入力エラーを含んでいるか
        /// </summary>
        public bool ContainsNotInputError
        {
            get
            {
                PropertyInfo[] infoArray = this.GetType().GetProperties();
                foreach (var info in infoArray)
                {
                    if (info.Name != nameof(this.ContainsNotInputError)
                        && info.Name.Contains(this.notInputErrorPropertyNamePartial)
                        && (bool)info.GetValue(this))
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// 未登録エラーを含んでいるか
        /// </summary>
        public bool ContainsUnregisteredError
        {
            get
            {
                PropertyInfo[] infoArray = this.GetType().GetProperties();
                foreach (var info in infoArray)
                {
                    if (info.Name != nameof(this.ContainsUnregisteredError)
                        && info.Name.Contains(this.unregisteredErrorPropertyNamePartial)
                        && (bool)info.GetValue(this))
                    {
                        return true;
                    }
                }

                return false;
            }
        }
    }
}
