﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IDenpyouNoDuplicationValidator
    {
        DenpyouNoDuplicationValidationResult ValidateDenpyouNoDuplication(Denpyou denpyou, DenpyouType denpyouType, ZidouhubanSyokiSettei zidouhubanSyokiSettei);
    }
}
