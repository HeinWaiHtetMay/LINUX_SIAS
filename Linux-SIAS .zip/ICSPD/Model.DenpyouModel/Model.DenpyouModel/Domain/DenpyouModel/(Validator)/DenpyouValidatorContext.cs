﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public class DenpyouValidatorContext
    {
        public DenpyouValidatorContext(
            InjectionContainer container,
            Denpyou denpyou,
            IKaisyaSyoriKikan syoriKikan,
            DenpyouType denpyouType,
            ZidouhubanSyokiSettei zidouhubanSyokiSettei,
            SyouhizeiMaster syouhizeiMaster,
            UserAndSyorikiSecurityContext userAndSyorikiSecurityContext,
            DenpyouValidationOption denpyouValidationOption)
        {
            this.Container = container;
            this.Denpyou = denpyou;
            this.SyoriKikan = syoriKikan;
            this.DenpyouType = denpyouType;
            this.ZidouhubanSyokiSettei = zidouhubanSyokiSettei;
            this.SyouhizeiMaster = syouhizeiMaster;
            this.UserAndSyorikiSecurityContext = userAndSyorikiSecurityContext;
            this.DenpyouValidationOption = denpyouValidationOption;
        }

        public InjectionContainer Container { get; private set; }

        public Denpyou Denpyou { get; private set; }

        public Denpyou DenpyouOld { get; set; }

        public IKaisyaSyoriKikan SyoriKikan { get; private set; }

        public DenpyouType DenpyouType { get; private set; }

        public ZidouhubanSyokiSettei ZidouhubanSyokiSettei { get; private set; }

        public SyouhizeiMaster SyouhizeiMaster { get; private set; }

        public UserAndSyorikiSecurityContext UserAndSyorikiSecurityContext { get; private set; }

        public DenpyouValidationOption DenpyouValidationOption { get; private set; }
    }
}
