﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public class DenpyouValidationOption
    {
        /// <summary>
        /// 承認グループ未入力チェック
        /// </summary>
        public bool ShouldCheckSyouninGroup { get; set; }

        /// <summary>
        /// 部門入力可能期間をチェックするか
        /// </summary>
        public bool ShouldCheckPeriodInputtableBumon { get; set; }

        /// <summary>
        /// 取引先入力可能期間をチェックするか
        /// </summary>
        public bool ShouldCheckPeriodInputtableTorihikisaki { get; set; }

        /// <summary>
        /// 支払日が伝票日付以降かチェックする
        /// 伝票入力、伝票修正用
        /// </summary>
        public bool ShouldCheckSiharaibiDenpyouHizukeBefore { get; set; }

        /// <summary>
        /// レート未入力をチェックする
        /// 伝票入力、伝票修正用
        /// </summary>
        public bool ShuoldCheckRateNotInput { get; set; }

        /// <summary>
        /// 外貨未入力をチェックする
        /// 伝票入力、伝票修正用
        /// </summary>
        public bool ShuoldCheckGaikaKingakuNotInput { get; set; }
    }
}
