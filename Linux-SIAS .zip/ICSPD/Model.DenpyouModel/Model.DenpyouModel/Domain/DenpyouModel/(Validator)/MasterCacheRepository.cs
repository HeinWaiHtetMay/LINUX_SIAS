﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MasterCacheRepository
    {
        [AutoInjection]
        private IMasterFindServiceWithSecurity masterFindServiceWithSecurity = null;

        [AutoInjection]
        private IProjectRepository projectRepository = null;

        [AutoInjection]
        private ISegmentRepository segmentRepository = null;

        [AutoInjection]
        private IKouziRepository kouziRepository = null;

        [AutoInjection]
        private IKousyuRepository kousyuRepository = null;

        [AutoInjection]
        private IUniversalFieldRepository universalFieldRepository = null;

        [AutoInjection]
        private IBumonKamokuZandakaRepository bumonKamokuZandakaRepository = null;

        [AutoInjection]
        private ITorihikisakiKamokuZandakaRepository torihikisakiKamokuZandakaRepository = null;

        [AutoInjection]
        private IBumonKamokuTorihikisakiZandakaRepository bumonKamokuTorihikisakiZandakaRepository = null;

        [AutoInjection]
        private IBumonKamokuEdabanZandakaRepository bumonKamokuEdabanZandakaRepository = null;

        [AutoInjection]
        private ISegmentKamokuZandakaRepository segmentKamokuZandakaRepository = null;

        [AutoInjection]
        private ISegmentKamokuTorihikisakiZandakaRepository segmentKamokuTorihikisakiZandakaRepository = null;

        [AutoInjection]
        private IUniversalFieldKamokuZandakaRepository universalFieldKamokuZandakaRepository = null;

        [AutoInjection]
        private IZiyuuTekiyouRepository ziyuuTekiyouRepository = null;

        private UserAndSyorikiSecurityContext userAndSyorikiSecurityContext = null;

        private SecurityKubun securityKubun;

        private IDictionary<string, UniversalField> headerField1Dictionary = null;
        private IDictionary<string, UniversalField> headerField2Dictionary = null;
        private IDictionary<string, UniversalField> headerField3Dictionary = null;
        private IDictionary<string, UniversalField> headerField4Dictionary = null;
        private IDictionary<string, UniversalField> headerField5Dictionary = null;
        private IDictionary<string, UniversalField> headerField6Dictionary = null;
        private IDictionary<string, UniversalField> headerField7Dictionary = null;
        private IDictionary<string, UniversalField> headerField8Dictionary = null;
        private IDictionary<string, UniversalField> headerField9Dictionary = null;
        private IDictionary<string, UniversalField> headerField10Dictionary = null;
        private IDictionary<string, Kamoku> kamokuDictionaryWithSecurity = null;
        private IDictionary<string, Bumon> bumonDictionaryWithSecurity = null;
        private IDictionary<string, Torihikisaki> torihikisakiDictionaryWithSecurity = null;
        private IDictionary<string, Kouzi> kouziDictionary = null;
        private IDictionary<string, Kousyu> kousyuDictionary = null;
        private IDictionary<string, Segment> segmentDictionary = null;
        private IDictionary<string, Project> projectDictionary = null;
        private IDictionary<string, UniversalField> universalField1Dictionary = null;
        private IDictionary<string, UniversalField> universalField2Dictionary = null;
        private IDictionary<string, UniversalField> universalField3Dictionary = null;
        private IDictionary<string, UniversalField> universalField4Dictionary = null;
        private IDictionary<string, UniversalField> universalField5Dictionary = null;
        private IDictionary<string, UniversalField> universalField6Dictionary = null;
        private IDictionary<string, UniversalField> universalField7Dictionary = null;
        private IDictionary<string, UniversalField> universalField8Dictionary = null;
        private IDictionary<string, UniversalField> universalField9Dictionary = null;
        private IDictionary<string, UniversalField> universalField10Dictionary = null;
        private IDictionary<string, UniversalField> universalField11Dictionary = null;
        private IDictionary<string, UniversalField> universalField12Dictionary = null;
        private IDictionary<string, UniversalField> universalField13Dictionary = null;
        private IDictionary<string, UniversalField> universalField14Dictionary = null;
        private IDictionary<string, UniversalField> universalField15Dictionary = null;
        private IDictionary<string, UniversalField> universalField16Dictionary = null;
        private IDictionary<string, UniversalField> universalField17Dictionary = null;
        private IDictionary<string, UniversalField> universalField18Dictionary = null;
        private IDictionary<string, UniversalField> universalField19Dictionary = null;
        private IDictionary<string, UniversalField> universalField20Dictionary = null;
        private IDictionary<Tuple<string, string>, IBumonKamokuZandaka> bumonKamokuZandakaDictionary = null;
        private IDictionary<Tuple<string, string>, ITorihikisakiKamokuZandaka> torihikisakiKamokuZandakaDictionary = null;
        private IDictionary<Tuple<string, string, string>, IBumonKamokuTorihikisakiZandaka> bumonKamokuTorihikisakiZandakaDictionary = null;
        private IDictionary<Tuple<string, string, string>, IBumonKamokuEdabanZandaka> bumonKamokuEdabanZandakaDictionary = null;
        private IDictionary<Tuple<string, string>, ISegmentKamokuZandaka> segmentKamokuZandakaDictionary = null;
        private IDictionary<Tuple<string, string, string>, ISegmentKamokuTorihikisakiZandaka> segmentKamokuTorihikisakiZandakaDictionary = null;
        private IDictionary<Tuple<string, string>, IUniversalFieldKamokuZandaka> universalField1KamokuZandakaDictionary = null;
        private IDictionary<Tuple<string, string>, IUniversalFieldKamokuZandaka> universalField2KamokuZandakaDictionary = null;
        private IDictionary<Tuple<string, string>, IUniversalFieldKamokuZandaka> universalField3KamokuZandakaDictionary = null;
        private IDictionary<int, ZiyuuTekiyou> ziyuuTekiyouDictionary = null;

        public MasterCacheRepository(
            InjectionContainer contaier,
            UserAndSyorikiSecurityContext userAndSyorikiSecurityContext,
            SecurityKubun securityKubun)
        {
            contaier.InjectDependeciesToAutoInjectionMembers(this);

            this.userAndSyorikiSecurityContext = userAndSyorikiSecurityContext;
            this.securityKubun = securityKubun;
        }

        public Kamoku GetKamokuWithSecurity(string innerCode)
        {
            if (string.IsNullOrEmpty(innerCode))
            {
                return null;
            }

            if (this.kamokuDictionaryWithSecurity == null)
            {
                this.kamokuDictionaryWithSecurity = this.masterFindServiceWithSecurity.FindKamokuByKesnOrderByKamokuOutputOrderWithSecurity(
                    this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                    KamokuOutputOrder.ByInnerCode,
                    this.securityKubun,
                    this.userAndSyorikiSecurityContext)?.ToDictionary(kamoku => kamoku.Kicd);
            }

            return this.kamokuDictionaryWithSecurity?.GetValue(innerCode, () => null);
        }

        public bool GetExistsBumonWithSecurity(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.bumonDictionaryWithSecurity == null)
            {
                this.bumonDictionaryWithSecurity = this.masterFindServiceWithSecurity.FindBumonByKesnAndBcodRangeWithSecurity(
                    this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                    null,
                    null,
                    BumonFindType.OnlyBumon,
                    this.securityKubun,
                    this.userAndSyorikiSecurityContext)?.ToDictionary(bumon => bumon.Bcod);
            }

            return this.bumonDictionaryWithSecurity.ContainsKey(code);
        }

        public Bumon GetBumonWithSecurity(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return null;
            }

            if (this.bumonDictionaryWithSecurity == null)
            {
                this.bumonDictionaryWithSecurity = this.masterFindServiceWithSecurity.FindBumonByKesnAndBcodRangeWithSecurity(
                    this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                    null,
                    null,
                    BumonFindType.OnlyBumon,
                    this.securityKubun,
                    this.userAndSyorikiSecurityContext)?.ToDictionary(bumon => bumon.Bcod);
            }

            return this.bumonDictionaryWithSecurity.GetValue(code, null);
        }

        public bool GetExistsTorihikisakiWithSecurity(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.torihikisakiDictionaryWithSecurity == null)
            {
                this.torihikisakiDictionaryWithSecurity = this.masterFindServiceWithSecurity.FindTorihikisakiByKesnOrderByTrcdWithSecurity(
                    this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                    this.securityKubun,
                    this.userAndSyorikiSecurityContext)?.ToDictionary(torihikisaki => torihikisaki.Trcd);
            }

            return this.torihikisakiDictionaryWithSecurity.ContainsKey(code);
        }

        public Torihikisaki GetTorihikisakiWithSecurity(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return null;
            }

            if (this.torihikisakiDictionaryWithSecurity == null)
            {
                this.torihikisakiDictionaryWithSecurity = this.masterFindServiceWithSecurity.FindTorihikisakiByKesnOrderByTrcdWithSecurity(
                    this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                    this.securityKubun,
                    this.userAndSyorikiSecurityContext)?.ToDictionary(torihikisaki => torihikisaki.Trcd);
            }

            return this.torihikisakiDictionaryWithSecurity.GetValue(code, null);
        }

        public bool GetExistsKamokuEdabanWithSecurity(string kicd, string ecod) =>
            this.masterFindServiceWithSecurity.FindEdabanByKesnAndKicdAndEcodWithSecurity(
                this.userAndSyorikiSecurityContext.Syoriki.Kesn,
                kicd,
                ecod,
                this.securityKubun,
                this.userAndSyorikiSecurityContext) != null;

        public bool GetExistsKouzi(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.kouziDictionary == null)
            {
                this.kouziDictionary = this.kouziRepository?.FindByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)?.ToDictionary(kouzi => kouzi.Code);
            }

            return this.kouziDictionary.ContainsKey(code);
        }

        public bool GetExistsKousyu(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.kousyuDictionary == null)
            {
                this.kousyuDictionary = this.kousyuRepository?.FindByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)?.ToDictionary(kousyu => kousyu.Code);
            }

            return this.kousyuDictionary.ContainsKey(code);
        }

        public bool GetExistsProject(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.projectDictionary == null)
            {
                this.projectDictionary = this.projectRepository?.FindAll()?.ToDictionary(project => project.Code);
            }

            return this.projectDictionary.ContainsKey(code);
        }

        public bool GetExistsSegment(string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (this.segmentDictionary == null)
            {
                this.segmentDictionary = this.segmentRepository?.FindByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)?.ToDictionary(segment => segment.Code);
            }

            return this.segmentDictionary.ContainsKey(code);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        public bool GetExistsUniversalField(UniversalFieldInfo universalFieldInfo, string code)
        {
            if (string.IsNullOrEmpty(code))
            {
                return false;
            }

            if (universalFieldInfo.IsHeaderField)
            {
                switch (universalFieldInfo.No)
                {
                    case 1:
                        if (this.headerField1Dictionary == null)
                        {
                            this.headerField1Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField1Dictionary.ContainsKey(code);
                    case 2:
                        if (this.headerField2Dictionary == null)
                        {
                            this.headerField2Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField2Dictionary.ContainsKey(code);
                    case 3:
                        if (this.headerField3Dictionary == null)
                        {
                            this.headerField3Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField3Dictionary.ContainsKey(code);
                    case 4:
                        if (this.headerField4Dictionary == null)
                        {
                            this.headerField4Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField4Dictionary.ContainsKey(code);
                    case 5:
                        if (this.headerField5Dictionary == null)
                        {
                            this.headerField5Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField5Dictionary.ContainsKey(code);
                    case 6:
                        if (this.headerField6Dictionary == null)
                        {
                            this.headerField6Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField6Dictionary.ContainsKey(code);
                    case 7:
                        if (this.headerField7Dictionary == null)
                        {
                            this.headerField7Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField7Dictionary.ContainsKey(code);
                    case 8:
                        if (this.headerField8Dictionary == null)
                        {
                            this.headerField8Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField8Dictionary.ContainsKey(code);
                    case 9:
                        if (this.headerField9Dictionary == null)
                        {
                            this.headerField9Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField9Dictionary.ContainsKey(code);

                    case 10:
                    default:
                        if (this.headerField10Dictionary == null)
                        {
                            this.headerField10Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(headerField => headerField.Code);
                        }
                        return this.headerField10Dictionary.ContainsKey(code);
                }
            }
            else
            {
                switch (universalFieldInfo.No)
                {
                    case 1:
                        if (this.universalField1Dictionary == null)
                        {
                            this.universalField1Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField1Dictionary.ContainsKey(code);
                    case 2:
                        if (this.universalField2Dictionary == null)
                        {
                            this.universalField2Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField2Dictionary.ContainsKey(code);
                    case 3:
                        if (this.universalField3Dictionary == null)
                        {
                            this.universalField3Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField3Dictionary.ContainsKey(code);
                    case 4:
                        if (this.universalField4Dictionary == null)
                        {
                            this.universalField4Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField4Dictionary.ContainsKey(code);
                    case 5:
                        if (this.universalField5Dictionary == null)
                        {
                            this.universalField5Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField5Dictionary.ContainsKey(code);
                    case 6:
                        if (this.universalField6Dictionary == null)
                        {
                            this.universalField6Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField6Dictionary.ContainsKey(code);
                    case 7:
                        if (this.universalField7Dictionary == null)
                        {
                            this.universalField7Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField7Dictionary.ContainsKey(code);
                    case 8:
                        if (this.universalField8Dictionary == null)
                        {
                            this.universalField8Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField8Dictionary.ContainsKey(code);
                    case 9:
                        if (this.universalField9Dictionary == null)
                        {
                            this.universalField9Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField9Dictionary.ContainsKey(code);
                    case 10:
                        if (this.universalField10Dictionary == null)
                        {
                            this.universalField10Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField10Dictionary.ContainsKey(code);
                    case 11:
                        if (this.universalField11Dictionary == null)
                        {
                            this.universalField11Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField11Dictionary.ContainsKey(code);
                    case 12:
                        if (this.universalField12Dictionary == null)
                        {
                            this.universalField12Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField12Dictionary.ContainsKey(code);
                    case 13:
                        if (this.universalField13Dictionary == null)
                        {
                            this.universalField13Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField13Dictionary.ContainsKey(code);
                    case 14:
                        if (this.universalField14Dictionary == null)
                        {
                            this.universalField14Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField14Dictionary.ContainsKey(code);
                    case 15:
                        if (this.universalField15Dictionary == null)
                        {
                            this.universalField15Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField15Dictionary.ContainsKey(code);
                    case 16:
                        if (this.universalField16Dictionary == null)
                        {
                            this.universalField16Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField16Dictionary.ContainsKey(code);
                    case 17:
                        if (this.universalField17Dictionary == null)
                        {
                            this.universalField17Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField17Dictionary.ContainsKey(code);
                    case 18:
                        if (this.universalField18Dictionary == null)
                        {
                            this.universalField18Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField18Dictionary.ContainsKey(code);
                    case 19:
                        if (this.universalField19Dictionary == null)
                        {
                            this.universalField19Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField19Dictionary.ContainsKey(code);
                    case 20:
                    default:
                        if (this.universalField20Dictionary == null)
                        {
                            this.universalField20Dictionary = this.universalFieldRepository
                                ?.FindByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                                ?.ToDictionary(universalField => universalField.Code);
                        }
                        return this.universalField20Dictionary.ContainsKey(code);
                }
            }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1131:Use readable conditions", Justification = "見やすさのため")]
        public bool GetExistsZiyuuTekiyou(int tekiyouNumber)
        {
            if (this.ziyuuTekiyouDictionary == null)
            {
                this.ziyuuTekiyouDictionary = this.ziyuuTekiyouRepository?.FindByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    ?.ToDictionary(ziyuuTekiyou => ziyuuTekiyou.Tcod);
            }

            return this.ziyuuTekiyouDictionary.ContainsKey(tekiyouNumber);
        }

        public bool GetExistsBumonKamokuZandaka(string bumonCode, string kamokuCode)
        {
            if (this.bumonKamokuZandakaDictionary == null)
            {
                this.bumonKamokuZandakaDictionary = this.bumonKamokuZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Bcod, zandaka.Kicd));
            }

            return this.bumonKamokuZandakaDictionary.ContainsKey(Tuple.Create(bumonCode, kamokuCode));
        }

        public bool GetExistsTorihikisakiKamokuZandaka(string torihikisakiCode, string kamokuCode)
        {
            if (this.torihikisakiKamokuZandakaDictionary == null)
            {
                this.torihikisakiKamokuZandakaDictionary = this.torihikisakiKamokuZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Trcd, zandaka.Kicd));
            }

            return this.torihikisakiKamokuZandakaDictionary.ContainsKey(Tuple.Create(torihikisakiCode, kamokuCode));
        }

        public bool GetExistsBumonKamokuTorihikisakiZandaka(string bumonCode, string kamokuCode, string torihikisakiCode)
        {
            if (this.bumonKamokuTorihikisakiZandakaDictionary == null)
            {
                this.bumonKamokuTorihikisakiZandakaDictionary = this.bumonKamokuTorihikisakiZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Bcod, zandaka.Kicd, zandaka.Trcd));
            }

            return this.bumonKamokuTorihikisakiZandakaDictionary.ContainsKey(Tuple.Create(bumonCode, kamokuCode, torihikisakiCode));
        }

        public bool GetExistsBumonKamokuEdabanZandaka(string bumonCode, string kamokuCode, string edabanCode)
        {
            if (this.bumonKamokuEdabanZandakaDictionary == null)
            {
                this.bumonKamokuEdabanZandakaDictionary = this.bumonKamokuEdabanZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Bcod, zandaka.Kicd, zandaka.Ecod));
            }

            return this.bumonKamokuEdabanZandakaDictionary.ContainsKey(Tuple.Create(bumonCode, kamokuCode, edabanCode));
        }

        public bool GetExistsSegmentKamokuZandaka(string segmentCode, string kamokuCode)
        {
            if (this.segmentKamokuZandakaDictionary == null)
            {
                this.segmentKamokuZandakaDictionary = this.segmentKamokuZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Sgcd, zandaka.Kicd));
            }

            return this.segmentKamokuZandakaDictionary.ContainsKey(Tuple.Create(segmentCode, kamokuCode));
        }

        public bool GetExistsSegmentKamokuTorihikisakiZandaka(string segmentCode, string kamokuCode, string torihikisakiCode)
        {
            if (this.segmentKamokuTorihikisakiZandakaDictionary == null)
            {
                this.segmentKamokuTorihikisakiZandakaDictionary = this.segmentKamokuTorihikisakiZandakaRepository
                    .FindZandakaByKesn(this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                    .ToDictionary(zandaka => Tuple.Create(zandaka.Sgcd, zandaka.Kicd, zandaka.Trcd));
            }

            return this.segmentKamokuTorihikisakiZandakaDictionary.ContainsKey(Tuple.Create(segmentCode, kamokuCode, torihikisakiCode));
        }

        public bool GetExistsUniversalFieldKamokuZandaka(UniversalFieldInfo universalFieldInfo, string universalFieldCode, string kamokuCode)
        {
            switch (universalFieldInfo.No)
            {
                case 1:
                    if (this.universalField1KamokuZandakaDictionary == null)
                    {
                        this.universalField1KamokuZandakaDictionary = this.universalFieldKamokuZandakaRepository
                            .FindZandakaByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                            .ToDictionary(zandaka => Tuple.Create(zandaka.Code, zandaka.Kicd));
                    }

                    return this.universalField1KamokuZandakaDictionary.ContainsKey(Tuple.Create(universalFieldCode, kamokuCode));
                case 2:
                    if (this.universalField2KamokuZandakaDictionary == null)
                    {
                        this.universalField2KamokuZandakaDictionary = this.universalFieldKamokuZandakaRepository
                            .FindZandakaByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                            .ToDictionary(zandaka => Tuple.Create(zandaka.Code, zandaka.Kicd));
                    }

                    return this.universalField2KamokuZandakaDictionary.ContainsKey(Tuple.Create(universalFieldCode, kamokuCode));
                case 3:
                default:
                    if (this.universalField3KamokuZandakaDictionary == null)
                    {
                        this.universalField3KamokuZandakaDictionary = this.universalFieldKamokuZandakaRepository
                            .FindZandakaByKesn(universalFieldInfo, this.userAndSyorikiSecurityContext.Syoriki.Kesn)
                            .ToDictionary(zandaka => Tuple.Create(zandaka.Code, zandaka.Kicd));
                    }

                    return this.universalField3KamokuZandakaDictionary.ContainsKey(Tuple.Create(universalFieldCode, kamokuCode));
            }
        }
    }
}
