﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public interface IDenpyouValidator
    {
        /// <summary>
        /// 新規伝票登録前検証
        /// </summary>
        /// <param name="denpyouValidatorParameter"></param>
        /// <returns></returns>
        DenpyouValidationResult AllowInsertDenpyou(DenpyouValidatorParameter denpyouValidatorParameter);

        /// <summary>
        /// 既存伝票更新前検証
        /// </summary>
        /// <param name="denpyouValidatorParameter"></param>
        /// <returns></returns>
        DenpyouValidationResult ValidateBeforeUpdateDenpyou(DenpyouValidatorParameter denpyouValidatorParameter);

        /// <summary>
        /// 伝票取消前検証
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="syorikikan"></param>
        /// <param name="denpyouType"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <returns></returns>
        DenpyouValidationResult ValidateBeforeDenpyouTorikesi(
            Denpyou denpyou,
            IKaisyaSyoriKikan syorikikan,
            DenpyouType denpyouType,
            SyouhizeiMaster syouhizeiMaster);
    }
}
