﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public enum DenpyouInvalidReason
    {
        /// <summary>
        /// エラーなし
        /// </summary>
        NoError = 0,

        /// <summary>
        /// 伝票日付未入力エラー
        /// </summary>
        NotInputDenpyouHizuke = -1,

        /// <summary>
        /// 受付番号未取得エラー
        /// </summary>
        NotGetUketukeNo = -2,

        /// <summary>
        /// 伝票番号未入力エラー
        /// </summary>
        NotInputDenpyouNo = -3,

        /// <summary>
        /// 起票者未入力エラー
        /// </summary>
        NotInputKihyousya = -4,

        /// <summary>
        /// 起票部門未入力エラー
        /// </summary>
        NotInputKihyouBumon = -5,

        /// <summary>
        /// 通常月に伝票束コードを入力できません
        /// </summary>
        CanNotInputDenpyoutabaCodeToTuuzyoutuki = -6,

        /// <summary>
        /// 未登録の伝票束コードは入力できません
        /// </summary>
        CanNotInputUnregisteredDenpyoutabaCode = -7,

        /// <summary>
        /// 承認グループが選択されていません
        /// </summary>
        NotSelectSyouninGroup = -8,

        /// <summary>
        /// 登録対象仕訳が存在しません
        /// </summary>
        NothingRegisterableSiwake = -9,

        /// <summary>
        /// 貸借合計がアンマッチです
        /// </summary>
        TaisyakuGoukeiUnmatch = -10,

        /// <summary>
        /// 無効な税率が入力されています
        /// </summary>
        InputtedUnavailableZeiritu = -11,

        /// <summary>
        /// 支払日が伝票日付以前
        /// </summary>
        SiharaibiDenpyouhizukeBefore = -12,

        /// <summary>
        /// 未入力エラー
        /// </summary>
        NotInputDenpyouKoumoku = -13,

        /// <summary>
        /// 未登録エラー
        /// </summary>
        UnregisteredDenpyouKoumoku = -14,

        /// <summary>
        /// 入力可能期間外の取引先は入力できません
        /// </summary>
        CanNotInputTorihikisakiToOutOfInputtablePeriod = -15,

        /// <summary>
        /// 他で仕訳が変更されています
        /// </summary>
        SiwakeChangedByOther = -16,

        /// <summary>
        /// 電子保存で定められた仕訳変更可能日数を経過した仕訳
        /// </summary>
        ElapsedDaysChangeableSiwake = -17,

        /// <summary>
        /// 月締めされている月
        /// </summary>
        IsTukizimeTaisyouSyorituki = -18,

        /// <summary>
        /// 入力可能期間外の部門は入力できません
        /// </summary>
        CanNotInputBumonToOutOfInputtablePeriod = -19,
    }
}
