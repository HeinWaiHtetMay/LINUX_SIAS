﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.SecurityModel;

    public interface IDenpyouRepository
    {
        /// <summary>
        /// 出力フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsPrintedChecklist(int kesn, int dkei, int dseq, DenpyouType denpyouType);

        /// <summary>
        /// 出力フラグ及び伝票状態フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateOutputFlagAndDenpyouStateFlag(int kesn, int dkei, int dseq, DenpyouType denpyouType);

        /// <summary>
        /// 出力フラグ、行変更フラグ、仕訳一覧フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="sseq">仕訳SEQNo.</param>
        void UpdateOutputFlagAndLineChangeFlagAndSiwakeListFlag(int kesn, int dkei, int dseq, int sseq);

        /// <summary>
        /// 出力フラグ、伝票状態フラグ、行変更仕訳存在フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouUpdateStatusFlag">伝票状態フラグ</param>
        /// <param name="isUpdateIsUpdatedLine">行変更仕訳存在フラグを更新するかどうか</param>
        /// <param name="denpyouType">伝票形式</param>
        void UpdateIsPrintedChecklistToTrueAndDenpyouUpdateStatusFlagAndIsUpdatedLineToFalse(int kesn, int dkei, int dseq, DenpyouUpdateStatusFlag denpyouUpdateStatusFlag, bool isUpdateIsUpdatedLine, DenpyouType denpyouType);

        /// <summary>
        /// 承認関連の値を更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="syouninUserNo">承認者コード</param>
        /// <param name="syouninStatus">承認判定</param>
        /// <param name="syouninOrder">承認順序</param>
        void UpdateSyouninRelatedValue(Denpyou denpyou, DenpyouType denpyouType, int syouninUserNo, SyouninStatus syouninStatus, int syouninOrder);

        /// <summary>
        /// 取消フラグを更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="syouninUsage">承認使用状況</param>
        void UpdateIsTorikesi(Denpyou denpyou, DenpyouType denpyouType, SyouninUsage syouninUsage);

        /// <summary>
        /// 入力確定日を一括で更新します
        /// </summary>
        /// <param name="denpyouKeyList">更新対象の伝票キー項目のリスト</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="kesn">内部決算期</param>
        /// <param name="currentDate">現在の日付</param>
        void UpdateNyuuryokuKakuteibi(IList<IDenpyouKey> denpyouKeyList, DenpyouType denpyouType, int kesn, int currentDate);

        /// <summary>
        /// 伝票取消
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        /// <param name="isCreateRireki"></param>
        void StoreTorikesiDenpyou(Denpyou denpyou, DenpyouType denpyouType, bool isCreateRireki);

        /// <summary>
        /// 伝票更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouOld"></param>
        /// <param name="denpyouType"></param>
        void StoreUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld, DenpyouType denpyouType);

        /// <summary>
        /// 新規伝票登録
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        void Insert(Denpyou denpyou, DenpyouType denpyouType);

        /// <summary>
        /// 伝票検索
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="dseq"></param>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        Denpyou FindByKesnAndDkeiAndDseqAndIsTorikesi(int kesn, int dkei, int dseq, DenpyouType denpyouType);

        /// <summary>
        /// 範囲処理月内に、伝票が存在するかどうかを取得します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="startDkei">開始処理月</param>
        /// <param name="endDkei">終了処理月</param>
        /// <returns>伝票が存在するかどうか</returns>
        bool GetYuukouDenpyouExistsByKesnAndDkeiRange(int kesn, int startDkei, int endDkei);

        /// <summary>
        /// 同じ伝票番号をもつ有効伝票が存在するかを取得します
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="dkei"></param>
        /// <param name="denpyouSequenceNumber"></param>
        /// <param name="denpyouNo"></param>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        bool GetExistsYuukouDenpyouWithSpecifiedDenpyouBangou(int kesn, int dkei, int denpyouSequenceNumber, int? denpyouNo, DenpyouType denpyouType);
    }
}