﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IZidouhubanGroupRepository
    {
        ZidouhubanGroup FindByKesnAndFuno(int kesn, int funo);
    }
}