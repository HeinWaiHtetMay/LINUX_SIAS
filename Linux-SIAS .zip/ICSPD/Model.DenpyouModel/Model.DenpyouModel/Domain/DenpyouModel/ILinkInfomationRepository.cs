﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

    public interface ILinkInfomationRepository
    {
        IList<LinkInfomation> FindByKesnAndDkeiAndDseqAndDenpyouTypeOrderByLkid(int kesn, int dkei, int dseq, DenpyouType denpyouType);

        /// <summary>
        /// リンク情報を登録
        /// e文書が紐づいていればe文書についても登録
        /// </summary>
        /// <param name="linkInfomation"></param>
        /// <param name="timeStampSetting"></param>
        void Insert(LinkInfomation linkInfomation, TimeStampSetting timeStampSetting);

        /// <summary>
        /// リンク情報を更新
        /// e文書が紐づいていればe文書についても登録
        /// </summary>
        /// <param name="linkInfomation"></param>
        /// <param name="timeStampSetting"></param>
        void Update(LinkInfomation linkInfomation, TimeStampSetting timeStampSetting);

        /// <summary>
        /// リンク情報を削除
        /// e文書については削除不可であるため削除をおこなわない。
        /// </summary>
        /// <param name="linkInfomation"></param>
        /// <returns></returns>
        bool Delete(LinkInfomation linkInfomation);

        /// <summary>
        /// 指定条件のリンク情報を削除
        /// </summary>
        /// <param name="linkInfomation">削除対象のリンク情報</param>
        /// <returns>削除されたかどうか</returns>
        bool DeleteByKesnAndDkeiAndDseqAndStyp(LinkInfomation linkInfomation);
    }
}