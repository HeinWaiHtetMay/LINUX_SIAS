﻿using Icsp.Open21.Domain.DenpyouModel;

namespace Icsp.Open21.Persistence.DenpyouModel
{
    public interface IDenpyouTabaLinkRepository
    {
        bool Delete(DenpyouTabaLink denpyouTabaLink);

        bool Insert(DenpyouTabaLink denpyouTabaLink);

        DenpyouTabaLink FindByKesnAndDkeiAndDunoAndDymdAndDcno(int kesn, int dkei, int duno, int dymd, int dcno);
    }
}