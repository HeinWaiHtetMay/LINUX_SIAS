﻿using System;
using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IEdocumentFileRepository
    {
        /// <summary>
        /// e文書番号を付番
        /// </summary>
        /// <param name="ccod"></param>
        /// <param name="kesn"></param>
        /// <returns>e文書番号</returns>
        string NumberEdocumentNo(string ccod, int kesn);

        /// <summary>
        /// 一時ファイルをインポート
        /// </summary>
        /// <param name="ccod"></param>
        /// <param name="kesn"></param>
        /// <param name="edocumentNo"></param>
        /// <param name="originalFileFullPath"></param>
        /// <returns>一時ファイル名</returns>
        string ImportTemporaryFile(string ccod, int kesn, string edocumentNo, string originalFileFullPath);

        /// <summary>
        /// タイムスタンプ付与またはファイルコピー処理
        /// </summary>
        /// <param name="ccod"></param>
        /// <param name="edocument"></param>
        /// <param name="errorHanding">
        /// タイムスタンプ付与エラー時に実行する処理
        /// パラメータ：タイムスタンプツールの実行結果
        /// 返送値：
        /// true 再試行する
        /// false 再試行しない
        /// </param>
        /// <returns>エラーコード</returns>
        bool CopyFileOrSetTimeStamp(string ccod, Edocument edocument, Func<TimeStampProcessResult, bool> errorHanding);

        /// <summary>
        /// タイムスタンプ付与またはファイルコピー処理
        /// </summary>
        /// <param name="ccod"></param>
        /// <param name="edocumentList"></param>
        /// <param name="errorHanding">
        /// タイムスタンプ付与エラー時に実行する処理
        /// パラメータ：タイムスタンプツールの実行結果
        /// 返送値：
        /// true 再試行する
        /// false 再試行しない
        /// </param>
        /// <returns></returns>
        bool CopyFileOrSetTimeStamp(string ccod, IList<Edocument> edocumentList, Func<TimeStampProcessResult, bool> errorHanding);

        /// <summary>
        /// PDFファイルに変換
        /// </summary>
        /// <param name="originalPath"></param>
        /// <param name="outputPath"></param>
        /// GrapeCity.PDFについてコメントする【.NetStandard2.1へ移行】
        //void WriteToPDF(string originalPath, string outputPath);
    }
}