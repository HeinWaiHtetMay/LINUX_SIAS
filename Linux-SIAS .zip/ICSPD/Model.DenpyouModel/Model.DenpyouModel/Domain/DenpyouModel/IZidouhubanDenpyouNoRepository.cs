﻿namespace Icsp.Open21.Domain.DenpyouModel
{
    public interface IZidouhubanDenpyouNoRepository
    {
        ZidouhubanDenpyouNo FindByKesnAndKeikAndFgno(int kesn, int keik, int fgno);

        int UpdateDcno(ZidouhubanDenpyouNo row);
    }
}