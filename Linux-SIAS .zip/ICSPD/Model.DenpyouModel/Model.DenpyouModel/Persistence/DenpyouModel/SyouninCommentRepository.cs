﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class SyouninCommentRepository : ISyouninCommentRepository
    {
        private static readonly string TuuzyouSiwakeCommentTableName = "zdcmt";
        private static readonly string BusyoSiwakeCommentTableName = "sncmt";
        private static readonly string SokyuuSiwakeCommentTableName = "skcmt";
        private static readonly string SelectStatement = "SELECT kesn, keik, dseq, sseq, cseq, cuno, cflg, cmnt, cymd, ctim, cmt1, cmt2, cmt3, cmt4, cdm1, cdm2, cdm3, cdm4, idm1, idm2, idm3, idm4 ";
        private static readonly int ColumnSize = 128;
        private static readonly string Bell = Convert.ToChar(0x0007).ToString();
        private static readonly string CarriageReturnAndLineFeed = Convert.ToChar(0x000d).ToString() + Convert.ToChar(0x000a).ToString();
        private static readonly string Space = Convert.ToChar(0x0020).ToString();
        private static readonly string Tab = Convert.ToChar(0x0009).ToString();

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<SyouninComment> FindByKesnOrderByCseqDesc(int kesn, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder(SelectStatement);
            sqlStatementBuilder.AppendLine("FROM ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p ", kesn);
            sqlStatementBuilder.AppendLine("ORDER BY cseq DESC ");
            return this.dbc.QueryForList(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    var keik = (int)(short)values[1];
                    var dseq = (int)values[2];
                    var sseq = (int)values[3];
                    var cseq = (int)values[4];
                    var row = new SyouninComment(kesn, keik, dseq, sseq, cseq);
                    row.CommentInputUserCode = (int)values[5]; // ｺﾒﾝﾄ入力者
                    row.SyouninFlag = (SyouninStatus)(short)values[6]; // 承認ﾌﾗｸﾞ
                    row.IsEditedSyouninsya = (short)values[7] == 1; // 承認者編集
                    row.Cymd = (int)values[8]; // ｺﾒﾝﾄ入力日
                    row.Ctim = (int)values[9]; // ｺﾒﾝﾄ入力時分秒
                    row.Comment =
                        string.Format(
                            "{0}{1}{2}{3}",
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[10], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[11], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[12], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[13], string.Empty))); // ｺﾒﾝﾄ
                    return row;
                },
                () => new List<SyouninComment>(),
                sqlStatementBuilder.GetSqlParameters());
        }

        public virtual IList<SyouninComment> FindByKesnAndKeikAndDseqAndSseqOrderByCseqDesc(int kesn, int keik, int dseq, int sseq, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder(SelectStatement);
            sqlStatementBuilder.AppendLine("FROM ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", kesn);
            sqlStatementBuilder.AppendLine("  keik = :p AND ", keik);
            sqlStatementBuilder.AppendLine("  dseq = :p AND ", dseq);
            sqlStatementBuilder.AppendLine("  sseq = :p ", sseq);
            sqlStatementBuilder.AppendLine("ORDER BY cseq DESC ");
            return this.dbc.QueryForList(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    var cseq = (int)values[4];
                    var row = new SyouninComment(kesn, keik, dseq, sseq, cseq);
                    row.CommentInputUserCode = (int)values[5]; // ｺﾒﾝﾄ入力者
                    row.SyouninFlag = (SyouninStatus)(short)values[6]; // 承認ﾌﾗｸﾞ
                    row.IsEditedSyouninsya = (short)values[7] == 1; // 承認者編集
                    row.Cymd = (int)values[8]; // ｺﾒﾝﾄ入力日
                    row.Ctim = (int)values[9]; // ｺﾒﾝﾄ入力時分秒
                    row.Comment =
                        string.Format(
                            "{0}{1}{2}{3}",
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[10], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[11], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[12], string.Empty)),
                            this.ReplaceBellToCarriageReturnAndLineFeed(DbNullConverter.ToString(values[13], string.Empty))); // ｺﾒﾝﾄ
                    return row;
                },
                () => new List<SyouninComment>(),
                sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// HACK 共通化を検討
        /// </summary>
        /// <param name="syouninComment"></param>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        public virtual bool Insert(SyouninComment syouninComment, DenpyouType denpyouType) =>
            this.Insert(syouninComment, denpyouType, true);

        public virtual bool Insert(SyouninComment syouninComment, DenpyouType denpyouType, bool isHubanCommentSequenceNumber)
        {
            if (this.GetExistsByKesnAndKeikAndDseqAndSseqAndCseq(syouninComment, denpyouType))
            {
                // コメント登録済み
                return false;
            }

            var sqlStatementBuilder = new SqlStatementBuilder("INSERT INTO ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("(");
            sqlStatementBuilder.AppendLine("kesn, keik, dseq, sseq, cseq, cuno, cflg, cmnt, cymd, ctim, ");
            sqlStatementBuilder.AppendLine("cmt1, cmt2, cmt3, cmt4, cdm1, cdm2, cdm3, cdm4, idm1, idm2, ");
            sqlStatementBuilder.AppendLine("idm3, idm4) ");
            sqlStatementBuilder.AppendLine("VALUES (");
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Kesn);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Keik);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Dseq);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Sseq);
            if ((!isHubanCommentSequenceNumber) && syouninComment.Cseq > 0)
            {
                // 付番済みのコメントSeqを使用
                // 経過月を変更しての登録、財務転記を想定
                sqlStatementBuilder.AppendLine(":p, ", syouninComment.Cseq);
            }
            else
            {
                // 1から連番でコメントSeqを付番
                sqlStatementBuilder.AppendLine("(SELECT ");
                sqlStatementBuilder.AppendLine("   COALESCE(MAX(cseq) + 1, 1)");
                sqlStatementBuilder.AppendLine(" FROM ");
                sqlStatementBuilder.AppendFormatAndLine("   {0} ", this.GetTableName(denpyouType));
                sqlStatementBuilder.AppendLine(" WHERE ");
                sqlStatementBuilder.AppendLine("   kesn = :p AND ", syouninComment.Kesn);
                sqlStatementBuilder.AppendLine("   keik = :p AND ", syouninComment.Keik);
                sqlStatementBuilder.AppendLine("   dseq = :p AND ", syouninComment.Dseq);
                sqlStatementBuilder.AppendLine("   sseq = :p", syouninComment.Sseq);
                sqlStatementBuilder.AppendLine(" ), ");
            }

            sqlStatementBuilder.AppendLine(":p, ", syouninComment.CommentInputUserCode);
            sqlStatementBuilder.AppendLine(":p, ", (short)syouninComment.SyouninFlag);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.IsEditedSyouninsya ? 1 : 0);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Cymd);
            sqlStatementBuilder.AppendLine(":p, ", syouninComment.Ctim);

            // 128バイトごとに分割してDBへ格納
            var targetString = this.ReplaceCarriageReturnAndLineFeedToBell(syouninComment.Comment);
            targetString = this.ReplaceTabToSpace(targetString);

            sqlStatementBuilder.AppendLine(":p, ", this.MidB(targetString, 1, ColumnSize));
            sqlStatementBuilder.AppendLine(":p, ", this.MidB(targetString, ColumnSize + 1, ColumnSize));
            sqlStatementBuilder.AppendLine(":p, ", this.MidB(targetString, (ColumnSize * 2) + 1, ColumnSize));
            sqlStatementBuilder.AppendLine(":p, ", this.MidB(targetString, (ColumnSize * 3) + 1, ColumnSize));

            sqlStatementBuilder.AppendLine("null, "); // cdm1
            sqlStatementBuilder.AppendLine("null, "); // cdm2
            sqlStatementBuilder.AppendLine("null, "); // cdm3
            sqlStatementBuilder.AppendLine("null, "); // cdm4
            sqlStatementBuilder.AppendLine("0, "); // idm1
            sqlStatementBuilder.AppendLine("0, "); // idm2
            sqlStatementBuilder.AppendLine("0, "); // idm3
            sqlStatementBuilder.AppendLine("0 "); // idm4
            sqlStatementBuilder.AppendLine(")");

            return this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters()) > 0;
        }

        public virtual bool GetExistsByKesnAndKeikAndDseqAndSseqAndCseq(SyouninComment syouninComment, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.AppendLine("SELECT COUNT(cseq) ");
            sqlStatementBuilder.AppendLine("FROM ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", syouninComment.Kesn);
            sqlStatementBuilder.AppendLine("  keik = :p AND ", syouninComment.Keik);
            sqlStatementBuilder.AppendLine("  dseq = :p AND ", syouninComment.Dseq);
            sqlStatementBuilder.AppendLine("  sseq = :p AND ", syouninComment.Sseq);
            sqlStatementBuilder.AppendLine("  cseq = :p", syouninComment.Cseq);
            return this.dbc.QueryForObject(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    return Convert.ToInt32(values[0]) > 0;
                },
                sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// DB値を表示値に変換
        /// </summary>
        /// <param name="comment"></param>
        /// <returns></returns>
        private string ReplaceBellToCarriageReturnAndLineFeed(string comment) => comment?.Replace(Bell, CarriageReturnAndLineFeed);

        /// <summary>
        /// 文字列の指定されたバイト位置から、指定されたバイト数分の文字列を返す
        /// 文字列サイズ外のバイト位置についてはnullを返す
        /// </summary>
        /// <param name="targetString">
        /// 取り出す元になる文字列
        /// </param>
        /// <param name="startByte">
        /// 取り出しを開始するバイト位置
        /// </param>
        /// <param name="byteSize">
        /// 取り出すバイト数</param>
        /// <returns>
        /// 指定されたバイト位置から指定されたバイト数分の文字列
        /// </returns>
        private string MidB(string targetString, int startByte, int byteSize)
        {
            if (string.IsNullOrEmpty(targetString))
            {
                return null;
            }

            Encoding encoding = Encoding.GetEncoding("Shift_JIS");
            byte[] byteString = encoding.GetBytes(targetString);

            int size = encoding.GetByteCount(targetString);
            if (size < startByte)
            {
                // 開始位置が範囲外
                return null;
            }

            if (size < startByte + byteSize)
            {
                // 終了位置が範囲外
                return encoding.GetString(byteString, startByte - 1, size - startByte + 1);
            }

            return encoding.GetString(byteString, startByte - 1, byteSize);
        }

        /// <summary>
        /// 表示値をDB値に変換
        /// </summary>
        /// <param name="comment"></param>
        /// <returns></returns>
        private string ReplaceCarriageReturnAndLineFeedToBell(string comment) => comment?.Replace(CarriageReturnAndLineFeed, Bell);

        /// <summary>
        /// 表示値をDB値に変換
        /// </summary>
        /// <param name="comment"></param>
        /// <returns></returns>
        private string ReplaceTabToSpace(string comment) => comment?.Replace(Tab, Space);

        /// <summary>
        /// テーブル名を取得
        /// </summary>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        private string GetTableName(DenpyouType denpyouType)
        {
            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    return TuuzyouSiwakeCommentTableName;
                case DenpyouType.Busyo:
                    return BusyoSiwakeCommentTableName;
                case DenpyouType.Sokyuu:
                default:
                    return SokyuuSiwakeCommentTableName;
            }
        }
    }
}