﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using System.IO;
    using System.Linq;
    //using EDOCUMENTLIB;
    //using GrapeCity.PDF;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.IO;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class EdocumentFileRepository : IEdocumentFileRepository
    {
        private static readonly string PdfExtension = ".pdf";
        private static readonly string TemporaryFolderName = "tmp";
        private static readonly string SakuseiCode = "01";

        [AutoInjection]
        private IDbUtilityDao dbUtilityDao = null;

        [AutoInjection]
        private IFileResourceFactory fileResourceFactory = null;

        [AutoInjection]
        private IEdocumentRepository edocumentRepository = null;

        public virtual string NumberEdocumentNo(string ccod, int kesn)
        {
            var retry = true;

            string edocumentNo;
            do
            {
                var dateTime = new IcspDateTime(this.dbUtilityDao.GetCurrentTimestamp());
                var datestring = dateTime.Ymd.ToString("00000000");
                var timestring = dateTime.GetHmsTime(SecondPrecision.Centisecond).ToString("00000000");
                edocumentNo = datestring + SakuseiCode + timestring + "0";

                // 一時ファイルの存在チェック
                var temporaryEdocumentFileResource = this.fileResourceFactory.CreateEdocumentResource(ccod, kesn, TemporaryFolderName + "\\" + edocumentNo + PdfExtension);
                if (!temporaryEdocumentFileResource.Exists())
                {
                    // e文書ファイルの存在チェック
                    var edocumentFileResource = this.fileResourceFactory.CreateEdocumentResource(ccod, kesn, edocumentNo + PdfExtension);
                    if (!edocumentFileResource.Exists())
                    {
                        // DBレコードのチェック
                        retry = this.edocumentRepository.GetExistByKesnAndEdoc(kesn, edocumentNo);
                    }
                }
            }
            while (retry);

            return edocumentNo;
        }

        public virtual string ImportTemporaryFile(string ccod, int kesn, string edocumentNo, string originalFileFullPath)
        {
            var targetFileResource = this.fileResourceFactory.CreateEdocumentResource(ccod, kesn, TemporaryFolderName + "\\" + edocumentNo + PdfExtension);
            if (string.Compare(Path.GetExtension(originalFileFullPath), PdfExtension, true) == 0)
            {
                // PDFならファイルコピー
                File.Copy(originalFileFullPath, targetFileResource.FileFullPath);
            }
            else
            {
                //GrapeCity.PDFについてコメントする【.NetStandard2.1へ移行】
                // PDF以外ならPDFに変換
                //this.WriteToPDF(originalFileFullPath, targetFileResource.FileFullPath);
            }

            return targetFileResource.GetFileName();
        }

        public virtual bool CopyFileOrSetTimeStamp(string ccod, Edocument edocument, Func<TimeStampProcessResult, bool> errorHanding)
        {
            var originalResource = this.fileResourceFactory.CreateEdocumentResource(ccod, edocument.Kesn, TemporaryFolderName + "\\" + edocument.Edoc + PdfExtension);
            var copyTargetResource = this.fileResourceFactory.CreateEdocumentResource(ccod, edocument.Kesn, edocument.Edoc + PdfExtension);

            // コピー先ファイル存在チェック
            if (!File.Exists(copyTargetResource.FileFullPath))
            {
                //e文書についてコメントする【.NetStandard2.1へ移行】
                // 存在しない場合は元ファイルにタイムスタンプが付与されているかチェック
                // 起動パラメータ作成
                var bootParameter = string.Format("\"{0}\" /V ", originalResource.FileFullPath);
                //var pdfTimestamp = new PdfTimestamp();
                //pdfTimestamp.UseDefaultStampSealParameters = false;
                //pdfTimestamp.UseDefaultLisenceInfo = false;

                // 検証
                //var processResult = new TimeStampProcessResult(pdfTimestamp.Start(bootParameter, false));
                //if (processResult.HasErrorCode && processResult.NotExistsTimeStamp)
                //{
                //    // タイムスタンプが付与されていない場合はタイムスタンプ付与
                //    pdfTimestamp.UseDefaultStampSealParameters = true;
                //    pdfTimestamp.UseDefaultLisenceInfo = true;
                //    bootParameter = string.Format(" \"{0}\" \"{1}\" ", originalResource.FileFullPath, copyTargetResource.FileFullPath);
                //    while (true)
                //    {
                //        processResult = new TimeStampProcessResult(pdfTimestamp.Start(bootParameter, false));
                //        if (processResult.HasError)
                //        {
                //            if (!errorHanding(processResult))
                //            {
                //                return false;
                //            }

                //            // 再試行
                //        }
                //        else
                //        {
                //            // タイムスタンプ付与成功
                //            break;
                //        }
                //    }
                //}
                //else
                //{
                //    // タイムスタンプ付与済みの場合は単純コピー
                //    System.IO.File.Copy(originalResource.FileFullPath, copyTargetResource.FileFullPath);
                //}
            }

            return true;
        }

        public virtual bool CopyFileOrSetTimeStamp(string ccod, IList<Edocument> edocumentList, Func<TimeStampProcessResult, bool> errorHanding)
        {
            var affectedEdocumentCount = 0;
            //e文書のためコメントする【.NetStandard2.1へ移行】
            //edocumentList.ForEachIfNotNull(edocument =>
            //affectedEdocumentCount = this.CopyFileOrSetTimeStamp(ccod, edocument, errorHanding) ? 1 : 0);
            return affectedEdocumentCount == edocumentList.Count();
        }

        //GrapeCity.PDFがまだ使わないためコメントする【.NetStandard2.1へ移行】
        //public virtual void WriteToPDF(string originalPath, string outputPath)
        //{
        //    // 1インチ=72ポイント換算
        //    var inchToPoint = 72F;
        //    using (var image = Image.FromFile(originalPath))
        //    {
        //        var sizePoint = new SizeF(image.Width / image.HorizontalResolution * inchToPoint, image.Height / image.VerticalResolution * inchToPoint);
        //        using (var document = new Document())
        //        {
        //            var page = document.Pages.CreatePage();
        //            page.PaperSize = sizePoint;
        //            GrapeCity.PDF.Drawing.Graphics graphics = page.GetGraphics();
        //            graphics.DrawImage(image, 0, 0);
        //            using (var stream = File.OpenWrite(outputPath))
        //            {
        //                Writer.Write(document, stream);
        //            }
        //        }
        //    }
        //}
    }
}
