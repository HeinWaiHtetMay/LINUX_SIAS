﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouTabaLinkRepository : IDenpyouTabaLinkRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual bool Delete(DenpyouTabaLink denpyouTabaLink)
        {
            SqlStatementBuilder deleteQuery = new SqlStatementBuilder();
            deleteQuery.AppendLine("DELETE FROM tabalink ");
            deleteQuery.AppendLine("WHERE kesn = :p ", denpyouTabaLink.Kesn);
            deleteQuery.AppendLine("AND dkei = :p ", denpyouTabaLink.Dkei);
            deleteQuery.AppendLine("AND duno = :p ", denpyouTabaLink.Duno);
            deleteQuery.AppendLine("AND dymd = :p ", denpyouTabaLink.Dymd);
            deleteQuery.AppendLine("AND dcno = :p", denpyouTabaLink.Dcno);
            return this.dbc.Execute(deleteQuery.GetSqlStatement(), deleteQuery.GetSqlParameters()) > 0;
        }

        public virtual bool Insert(DenpyouTabaLink denpyouTabaLink)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("tabalink");
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", denpyouTabaLink.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkei", denpyouTabaLink.Dkei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duno", denpyouTabaLink.Duno);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dymd", denpyouTabaLink.Dymd);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dcno", denpyouTabaLink.Dcno);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tabacode", denpyouTabaLink.TabaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", denpyouTabaLink.Fusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm1", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm2", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm3", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm4", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm1", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm2", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm3", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm4", 0);
            return this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters()) > 0;
        }

        public virtual DenpyouTabaLink FindByKesnAndDkeiAndDunoAndDymdAndDcno(int kesn, int dkei, int duno, int dymd, int dcno)
        {
            return this.dbc.QueryForObject(
                "SELECT kesn, dkei, duno, dymd, dcno, tabacode, fusr, cdm1, cdm2, cdm3, cdm4, idm1, idm2, idm3, idm4 " +
                "FROM tabalink " +
                "WHERE kesn = :p AND dkei = :p AND duno = :p AND dymd = :p AND dcno = :p",
                (values, no) =>
                {
                    var row = new DenpyouTabaLink(kesn, dkei, duno, dymd, dcno, (int)values[6]);
                    row.TabaCode = DbNullConverter.ToString(values[5], null); // 伝票束コード
                    ////row.Cdm1 = DbNullConverter.ToString(values[7], null); // 未使用
                    ////row.Cdm2 = DbNullConverter.ToString(values[8], null); // 未使用
                    ////row.Cdm3 = DbNullConverter.ToString(values[9], null); // 未使用
                    ////row.Cdm4 = DbNullConverter.ToString(values[10], null); // 未使用
                    ////row.Idm1 = (int)(short)values[11]; // 未使用
                    ////row.Idm2 = (int)(short)values[12]; // 未使用
                    ////row.Idm3 = (int)(short)values[13]; // 未使用
                    ////row.Idm4 = (int)(short)values[14]; // 未使用
                    return row;
                },
                kesn,
                dkei,
                duno,
                dymd,
                dcno);
        }
    }
}
