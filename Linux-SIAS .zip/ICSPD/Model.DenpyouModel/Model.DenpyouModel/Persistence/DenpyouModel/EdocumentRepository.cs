﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.SecurityModel;

    /// <summary>
    /// e文書は削除不可
    /// </summary>
    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class EdocumentRepository : IEdocumentRepository
    {
        private static readonly string SelectStatement =
            "SELECT edoc.kesn, edoc.edoc,   edoc.syubetsu, edoc.nusr, edoc.susr, " +
            "       edoc.cmt,  edoc.tsfuyo, edoc.fusr,     edoc.fmod, edoc.ftim, " +
            "       edoc.lusr, edoc.lmod,   edoc.ltim,     edoc.docseq ";

        [AutoInjection]
        private IEdocumentSearchItemRepository edocumentSerchItemRepository = null;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual Edocument FindByKesnAndEdoc(int kesn, string edoc)
        {
            var edocument = this.dbc.QueryForObject(
                SelectStatement +
                "FROM edoc WHERE kesn = :p AND edoc = :p",
                (values, no) => { return this.MapRow(values, no); },
                kesn,
                edoc);

            if (edocument == null)
            {
                return null;
            }

            edocument.EdocumentSearchItemList = this.edocumentSerchItemRepository.FindByKesnAndEdocOrderByEseq(edocument.Kesn, edocument.Edoc);
            return edocument;
        }

        public virtual IList<Edocument> FindNotLinkedEdocumentByKesn(int kesn, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder(SelectStatement);
            sqlStatementBuilder.AppendLine("FROM edoc ");
            sqlStatementBuilder.AppendLine("LEFT outer join dinlink on edoc.kesn = dinlink.kesn and edoc.edoc = dinlink.edoc ");
            sqlStatementBuilder.AppendLine("WHERE edoc.kesn = :p AND dinlink.edoc IS NULL ", kesn);
            if (denpyouType == DenpyouType.TuuzyouDenpyou)
            {
                // 日次の場合は最終承認者が登録されていることが条件
                sqlStatementBuilder.AppendLine("AND edoc.susr IS NOT NULL ");
            }

            var edocumentList = this.dbc.QueryForList(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) => { return this.MapRow(values, no); },
                () => new List<Edocument>(),
                sqlStatementBuilder.GetSqlParameters());

            foreach (var edocument in edocumentList)
            {
                edocument.EdocumentSearchItemList = this.edocumentSerchItemRepository.FindByKesnAndEdocOrderByEseq(edocument.Kesn, edocument.Edoc);
            }

            return edocumentList;
        }

        public virtual bool GetExistByKesnAndEdoc(int kesn, string edoc) =>
            this.dbc.QueryForObject(
                "SELECT COUNT(edoc) FROM edoc WHERE kesn = :p AND edoc = :p",
                (values, no) =>
                {
                    return DbNullConverter.ToInt(values[0], 0) > 0;
                },
                kesn,
                edoc);

        public virtual void Insert(Edocument edocument)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("edoc");
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", edocument.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("edoc", edocument.Edoc);
            insertSqlStatementBuilder.AppendColumnNameAndValue("syubetsu", 0); // 0固定
            insertSqlStatementBuilder.AppendColumnNameAndValue("nusr", edocument.Nusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("susr", edocument.Susr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cmt", edocument.Cmt);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tsfuyo", edocument.NeedTimeStamp ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", edocument.Fusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fmod", edocument.Fmod);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ftim", edocument.Ftim);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", edocument.Lusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", edocument.Lmod);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", edocument.Ltim);
            insertSqlStatementBuilder.AppendColumnNameAndValue("docseq", 0); // 0固定
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());
            this.StoreEdocumentSearchItem(edocument);
        }

        public virtual void Update(Edocument edocument)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE edoc SET ");
            updateQuery.AppendLine("nusr = :p, ", edocument.Nusr);
            updateQuery.AppendLine("susr = :p, ", edocument.Susr);
            updateQuery.AppendLine("cmt = :p, ", edocument.Cmt);
            updateQuery.AppendLine("tsfuyo = :p, ", edocument.NeedTimeStamp ? 1 : 0);
            updateQuery.AppendLine("lusr = :p, ", edocument.Lusr);
            updateQuery.AppendLine("lmod = :p, ", edocument.Lmod);
            updateQuery.AppendLine("ltim = :p", edocument.Ltim);
            updateQuery.AppendLine("WHERE kesn = :p AND ", edocument.Kesn);
            updateQuery.AppendLine("edoc = :p ", edocument.Edoc);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
            this.StoreEdocumentSearchItem(edocument);
        }

        /// <summary>
        /// 最終承認者名称を更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="lastSyouninUser">最終承認者</param>
        public virtual void UpdateLastSyouninUserName(Denpyou denpyou, User lastSyouninUser)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendLine("  edoc ");
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  susr = :p ", string.Format("{0}:{1}", lastSyouninUser.Name, lastSyouninUser.UserCode.ToString("0000")));
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", denpyou.Kesn);
            updateQuery.AppendLine("  AND edoc IN ( ");
            updateQuery.AppendLine("    SELECT ");
            updateQuery.AppendLine("      edoc ");
            updateQuery.AppendLine("    FROM ");
            updateQuery.AppendLine("      dinlink ");
            updateQuery.AppendLine("    WHERE ");
            updateQuery.AppendLine("      kesn = :p ", denpyou.Kesn);
            updateQuery.AppendLine("      AND dkei = :p ", denpyou.Dkei);
            updateQuery.AppendLine("      AND dseq = :p ", denpyou.DenpyouSequenceNumber);
            updateQuery.AppendLine("      AND styp = 1 ");
            updateQuery.AppendLine("  ) ");
            updateQuery.AppendLine("  AND SUBSTRING(edoc, 9, 2) = '01' ");
            updateQuery.AppendLine("  AND susr IS NULL ");
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// e文書検索項目の登録
        /// e文書に紐づくe文書検索項目を全件削除後に全件追加
        /// </summary>
        /// <param name="edocument"></param>
        private void StoreEdocumentSearchItem(Edocument edocument)
        {
            this.edocumentSerchItemRepository.Delete(edocument);
            edocument.EdocumentSearchItemList.ForEachIfNotNull(edocumentSearchItem => this.edocumentSerchItemRepository.Insert(edocumentSearchItem));
        }

        private Edocument MapRow(object[] values, int no) =>
            new Edocument((int)(short)values[0], DbNullConverter.ToString(values[1]))
            {
                Nusr = DbNullConverter.ToString(values[3], null), // 申請者名称
                Susr = DbNullConverter.ToString(values[4], null), // 最終承認者名称
                Cmt = DbNullConverter.ToString(values[5], null), // コメント
                NeedTimeStamp = (short)values[6] == 1, // ﾀｲﾑｽﾀﾝﾌﾟ付与設定
                Fusr = (int)values[7], // 新規作成者
                Fmod = (int)values[8], // 新規作成年月日
                Ftim = (int)values[9], // 新規作成時間
                Lusr = (int)values[10], // 最終更新者
                Lmod = (int)values[11], // 最終更新年月日
                Ltim = (int)values[12], // 最終更新時間
            };
    }
}
