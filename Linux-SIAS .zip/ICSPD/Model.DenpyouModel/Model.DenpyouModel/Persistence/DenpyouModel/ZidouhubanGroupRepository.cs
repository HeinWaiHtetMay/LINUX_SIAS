﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ZidouhubanGroupRepository : IZidouhubanGroupRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual ZidouhubanGroup FindByKesnAndFuno(int kesn, int funo) =>
            this.dbc.QueryForObject(
                "SELECT fgno, cdm1, cdm2, cdm3, cdm4, idm1, idm2, idm3, idm4 " +
                "FROM jfgrp WHERE kesn = :p AND funo = :p ",
                (values, no) =>
                {
                    var row = new ZidouhubanGroup(kesn, funo)
                    {
                        Fgno = (int)values[0],
                        ////Cdm1 = DbNullConverter.ToString(values[1], null),
                        ////Cdm2 = DbNullConverter.ToString(values[2], null),
                        ////Cdm3 = DbNullConverter.ToString(values[3], null),
                        ////Cdm4 = DbNullConverter.ToString(values[4], null),
                        ////Idm1 = (int)values[5],
                        ////Idm2 = (int)values[6],
                        ////Idm3 = (int)values[7],
                        ////Idm4 = (int)values[8]
                    };
                    return row;
                },
                kesn,
                funo);
    }
}
