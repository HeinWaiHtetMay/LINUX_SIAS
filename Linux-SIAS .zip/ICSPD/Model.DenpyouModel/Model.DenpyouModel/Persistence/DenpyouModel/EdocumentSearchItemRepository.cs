﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class EdocumentSearchItemRepository : IEdocumentSearchItemRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<EdocumentSearchItem> FindByKesn(int kesn) =>
            this.dbc.QueryForList(
                "SELECT edoc, eseq FROM edocsrch WHERE kesn = :p ",
                (values, no) =>
                {
                    return new EdocumentSearchItem(kesn, DbNullConverter.ToString(values[0]), (int)values[1]);
                },
                () => new List<EdocumentSearchItem>(),
                kesn);

        public virtual IList<EdocumentSearchItem> FindByKesnAndEdocOrderByEseq(int kesn, string edoc) =>
            this.dbc.QueryForList(
                "SELECT eseq, symd, svalu, strnam, biko, syubetsu " +
                "FROM edocsrch WHERE kesn = :p AND edoc = :p ORDER BY eseq",
                (values, no) =>
                {
                    var eseq = (int)values[0];
                    var row = new EdocumentSearchItem(kesn, edoc, eseq);
                    row.Symd = DbNullConverter.ToNullableInt(values[1]); // 日付
                    row.Svalu = (decimal)values[2]; // 金額
                    row.Strnam = DbNullConverter.ToString(values[3], null); // 発行者名称
                    row.Bikou = DbNullConverter.ToString(values[4], null); // 備考
                    row.EdocumentType = (EdocumentType)(short)values[5];
                    return row;
                },
                () => new List<EdocumentSearchItem>(),
                kesn,
                edoc);

        public bool Insert(EdocumentSearchItem edocumentSearchItem)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("edocsrch");
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", edocumentSearchItem.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("edoc", edocumentSearchItem.Edoc);
            insertSqlStatementBuilder.AppendColumnNameAndValue("eseq", edocumentSearchItem.Eseq);
            insertSqlStatementBuilder.AppendColumnNameAndValue("symd", edocumentSearchItem.Symd);
            insertSqlStatementBuilder.AppendColumnNameAndValue("svalu", edocumentSearchItem.Svalu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("strnam", edocumentSearchItem.Strnam);
            insertSqlStatementBuilder.AppendColumnNameAndValue("biko", edocumentSearchItem.Bikou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("syubetsu", (short)edocumentSearchItem.EdocumentType);
            return this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters()) > 0;
        }

        public virtual bool Delete(Edocument edocument) =>
            this.dbc.Execute(
                "DELETE FROM edocsrch WHERE kesn = :p AND edoc = :p",
                new object[] { edocument.Kesn, edocument.Edoc }) > 0;
    }
}
