﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class LinkInfomationRepository : ILinkInfomationRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private IEdocumentRepository edocumentRepository = null;

        public virtual IList<LinkInfomation> FindByKesnAndDkeiAndDseqAndDenpyouTypeOrderByLkid(int kesn, int dkei, int dseq, DenpyouType denpyouType)
        {
            var linkInfomationList = this.dbc.QueryForList(
                "SELECT lkid, lnam, link, flg1, cdm1, cdm2, sdm1, idm1, fusr, fmod, ftim, lusr, lmod, ltim, fway, edoc " +
                "FROM dinlink " +
                "WHERE kesn = :p AND dkei = :p AND dseq = :p AND styp = :p " +
                "ORDER BY lkid",
                (values, no) =>
                {
                    var lkid = (int)values[0];
                    var row = new LinkInfomation(kesn, dkei, dseq, lkid, denpyouType);
                    row.Lnam = DbNullConverter.ToString(values[1], null); // リンク名称
                    row.Link = DbNullConverter.ToString(values[2], null); // リンク先
                    row.LinkType = (LinkType)(short)values[3]; // リンク形式
                    row.Fusr = (int)values[8]; // 新規作成者
                    row.Fmod = (int)values[9]; // 新規作成年月日
                    row.Ftim = (int)values[10]; // 新規作成時間
                    row.Lusr = (int)values[11]; // 最終更新者
                    row.Lmod = (int)values[12]; // 最終更新年月日
                    row.Ltim = (int)values[13]; // 最終更新時間
                    row.Fway = (DenpyouSiwakeWayToCreate)(int)values[14]; // 入力手段
                    row.Edoc = DbNullConverter.ToString(values[15], null); // e文書番号
                    return row;
                },
                () => new List<LinkInfomation>(),
                kesn,
                dkei,
                dseq,
                (short)denpyouType);

            foreach (var linkInfomation in linkInfomationList)
            {
                if (!string.IsNullOrEmpty(linkInfomation.Edoc))
                {
                    linkInfomation.Edocument = this.edocumentRepository.FindByKesnAndEdoc(linkInfomation.Kesn, linkInfomation.Edoc);
                }
            }

            return linkInfomationList;
        }

        public virtual void Insert(LinkInfomation linkInfomation, TimeStampSetting timeStampSetting)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("dinlink");
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", linkInfomation.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkei", linkInfomation.Dkei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dseq", linkInfomation.Dseq);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lkid", linkInfomation.Lkid);
            insertSqlStatementBuilder.AppendColumnNameAndValue("styp", (short)linkInfomation.DenpyouType);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lnam", linkInfomation.Lnam);
            insertSqlStatementBuilder.AppendColumnNameAndValue("link", linkInfomation.Link);
            insertSqlStatementBuilder.AppendColumnNameAndValue("flg1", (short)linkInfomation.LinkType);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm1", null); // cdm1
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm2", null); // cdm2
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm1", 0); // sdm1
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm1", 0); // idm1
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", linkInfomation.Fusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fmod", linkInfomation.Fmod);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ftim", linkInfomation.Ftim);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", linkInfomation.Lusr);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", linkInfomation.Lmod);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", linkInfomation.Ltim);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fway", (int)linkInfomation.Fway);
            insertSqlStatementBuilder.AppendColumnNameAndValue("edoc", linkInfomation.Edoc);
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());
            if (!string.IsNullOrEmpty(linkInfomation.Edoc))
            {
                this.StoreEdocument(linkInfomation.Edocument, timeStampSetting);
            }
        }

        public virtual void Update(LinkInfomation linkInfomation, TimeStampSetting timeStampSetting)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinlink SET ");
            updateQuery.AppendLine("  lnam = :p, ", linkInfomation.Lnam);
            updateQuery.AppendLine("  link = :p, ", linkInfomation.Link);
            updateQuery.AppendLine("  flg1 = :p, ", (short)linkInfomation.LinkType);
            updateQuery.AppendLine("  lusr = :p, ", linkInfomation.Lusr);
            updateQuery.AppendLine("  lmod = :p, ", linkInfomation.Lmod);
            updateQuery.AppendLine("  ltim = :p, ", linkInfomation.Ltim);
            updateQuery.AppendLine("  edoc = :p ", linkInfomation.Edoc);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p AND ", linkInfomation.Kesn);
            updateQuery.AppendLine("  dkei = :p AND ", linkInfomation.Dkei);
            updateQuery.AppendLine("  dseq = :p AND ", linkInfomation.Dseq);
            updateQuery.AppendLine("  lkid = :p AND ", linkInfomation.Lkid);
            updateQuery.AppendLine("  styp = :p", (short)linkInfomation.DenpyouType);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
            if (!string.IsNullOrEmpty(linkInfomation.Edoc))
            {
                this.StoreEdocument(linkInfomation.Edocument, timeStampSetting);
            }
        }

        public virtual bool Delete(LinkInfomation linkInfomation) =>
            this.dbc.Execute(
                "DELETE FROM dinlink " +
                "WHERE kesn = :p AND dkei = :p AND dseq = :p AND lkid = :p AND styp = :p",
                new object[] { linkInfomation.Kesn, linkInfomation.Dkei, linkInfomation.Dseq, linkInfomation.Lkid, (short)linkInfomation.DenpyouType }) > 0;

        /// <summary>
        /// 指定条件のリンク情報を削除
        /// </summary>
        /// <param name="linkInfomation">削除対象のリンク情報</param>
        /// <returns>削除されたかどうか</returns>
        public virtual bool DeleteByKesnAndDkeiAndDseqAndStyp(LinkInfomation linkInfomation) =>
            this.dbc.Execute(
                "DELETE FROM dinlink " +
                "WHERE kesn = :p AND dkei = :p AND dseq = :p AND styp = :p",
                new object[] { linkInfomation.Kesn, linkInfomation.Dkei, linkInfomation.Dseq, (short)linkInfomation.DenpyouType }) > 0;

        /// <summary>
        /// すでに同一決算期、同一e文書番号があれば更新、なければ追加
        /// </summary>
        /// <param name="edocument"></param>
        /// <param name="timeStampSetting"></param>
        private void StoreEdocument(Edocument edocument, TimeStampSetting timeStampSetting)
        {
            var oldEdocument = this.edocumentRepository.FindByKesnAndEdoc(edocument.Kesn, edocument.Edoc);
            edocument.SetNeedTimeStamp(timeStampSetting, oldEdocument);
            if (oldEdocument == null)
            {
                this.edocumentRepository.Insert(edocument);
            }
            else
            {
                this.edocumentRepository.Update(edocument);
            }
        }
    }
}
