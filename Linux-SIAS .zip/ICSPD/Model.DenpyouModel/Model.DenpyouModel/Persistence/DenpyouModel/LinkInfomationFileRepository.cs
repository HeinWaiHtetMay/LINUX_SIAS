﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.ComponentModel;
    using System.IO;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data.Dao;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.IO;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class LinkInfomationFileRepository : ILinkInfomationFileRepository
    {
        private readonly string dateTimeStringFormat = "00000000";

        [AutoInjection]
        private IDbUtilityDao utilDao = null;

        [AutoInjection]
        private IFileResourceFactory fileResourceFactory = null;

        /// <summary>
        /// ファイルインポート
        /// </summary>
        /// <param name="ccod"></param>
        /// <param name="kesn"></param>
        /// <param name="userCode"></param>
        /// <param name="originalFileFullPath"></param>
        /// <returns>インポート後のファイル名</returns>
        public virtual string FileImport(string ccod, int kesn, string userCode, string originalFileFullPath)
        {
            while (true)
            {
                var dateTime = this.GetCurrentDateTime();
                var stringBuilder = new StringBuilder(userCode);
                stringBuilder = stringBuilder.Append(dateTime.Ymd.ToString(this.dateTimeStringFormat));
                stringBuilder = stringBuilder.Append(dateTime.GetHmsTime(SecondPrecision.Centisecond).ToString(this.dateTimeStringFormat));
                stringBuilder = stringBuilder.Append(Path.GetFileName(originalFileFullPath));
                var linkImportResource = this.fileResourceFactory.CreateLinkImportResource(ccod, kesn, stringBuilder.ToString());
                if (!System.IO.File.Exists(linkImportResource.FileFullPath))
                {
                    // 存在しない場合はファイルコピー
                    System.IO.File.Copy(originalFileFullPath, @linkImportResource.FileFullPath);
                    return stringBuilder.ToString();
                }

                // 存在する場合はファイル名再作成
            }
        }

        private IcspDateTime GetCurrentDateTime() => new IcspDateTime(this.utilDao.GetCurrentTimestamp(), Gengou.ChristianGengou);
    }
}
