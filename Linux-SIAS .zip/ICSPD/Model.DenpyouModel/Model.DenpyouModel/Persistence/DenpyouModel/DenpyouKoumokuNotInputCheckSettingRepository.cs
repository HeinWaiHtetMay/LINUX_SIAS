﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Persistence.OptionModel;

    [Component]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouKoumokuNotInputCheckSettingRepository : IDenpyouKoumokuNotInputCheckSettingRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public virtual DenpyouKoumokuNotInputCheckSetting Find()
        {
            var option1List = this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(
                Data.DataSource.DatabaseType.KaisyaDb,
                "CCINFOMNT",
                "DMNTFRIV");

            var denpyouKoumokuNotInputCheckSetting = new DenpyouKoumokuNotInputCheckSetting();

            denpyouKoumokuNotInputCheckSetting.IsUseKihyousyaNotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "KIHYOSYA_MI", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseKihyouBumonNotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "KIHYOBMN_MI", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField1NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF1", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField2NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF2", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField3NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF3", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField4NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF4", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField5NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF5", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField6NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF6", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField7NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF7", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField8NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF8", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField9NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF9", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseHeaderField10NotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "HDF10", 0, 0) == 1;
            denpyouKoumokuNotInputCheckSetting.IsUseTaikaNotInputCheck =
                this.GetIntDataByKeynm2AndKeyno(option1List, "TAIKA", 0, 0) == 1;

            return denpyouKoumokuNotInputCheckSetting;
        }

        private int GetIntDataByKeynm2AndKeyno(IList<Option1Dto> option1List, string keynm2, int keyno, int defaultValue) =>
            option1List.FirstOrDefault(option1 => option1.Keynm2 == keynm2 && option1.Keyno == keyno)?.Idata ?? defaultValue;
    }
}
