﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SecurityModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouRepository : IDenpyouRepository
    {
        /// <summary>
        /// 通常伝票テーブル名
        /// </summary>
        private static readonly string TuuzyouDenpyouTableName = "zdata_h";

        /// <summary>
        /// 部署伝票テーブル名
        /// </summary>
        private static readonly string BusyoDenpyouTableName = "sjdat_h";

        /// <summary>
        /// 遡及伝票テーブル名
        /// </summary>
        private static readonly string SokyuuDenpyouTableName = "skdat_h";

        [AutoInjection]
        private ISiwakeRepository siwakeRepository = null;

        [AutoInjection]
        private ILinkInfomationRepository linkInfomationRepository = null;

        [AutoInjection]
        private IDenpyouTabaLinkRepository denpyouTabaLinkRepository = null;

        [AutoInjection]
        private ITimeStampSettingRepository timeStampSettingRepository = null;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        /// <summary>
        /// 出力フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsPrintedChecklist(int kesn, int dkei, int dseq, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  cprt = 1 ");
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", kesn);
            updateQuery.AppendLine("  AND dkei = :p ", dkei);
            updateQuery.AppendLine("  AND dseq = :p ", dseq);
            updateQuery.AppendLine("  AND delf = 0 ");
            updateQuery.AppendLine("  AND cprt <> 1 ");
            updateQuery.AppendIfTrue(denpyouType == DenpyouType.Sokyuu, "  AND idm1 = 0 ");
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 出力フラグ及び伝票状態フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateOutputFlagAndDenpyouStateFlag(int kesn, int dkei, int dseq, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.AppendLine("UPDATE ");
            sqlStatementBuilder.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("SET ");
            sqlStatementBuilder.AppendLine("  cprt = 1 ");
            sqlStatementBuilder.AppendLine("  , hsflg = (CASE hgflg WHEN 0 THEN 0 WHEN 1 THEN 2 ELSE hsflg END) ");
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p ", kesn);
            sqlStatementBuilder.AppendLine("  AND dkei = :p ", dkei);
            sqlStatementBuilder.AppendLine("  AND dseq = :p ", dseq);
            this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// 出力フラグ、行変更フラグ、仕訳一覧フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="sseq">仕訳SEQNo.</param>
        public virtual void UpdateOutputFlagAndLineChangeFlagAndSiwakeListFlag(int kesn, int dkei, int dseq, int sseq)
        {
            var sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.AppendLine("UPDATE ");
            sqlStatementBuilder.AppendLine("  zdata ");
            sqlStatementBuilder.AppendLine("SET ");
            sqlStatementBuilder.AppendLine("  cprt = 1 ");
            sqlStatementBuilder.AppendLine("  , swgflg = 0 ");
            sqlStatementBuilder.AppendLine("  , swiflg = 1 ");
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p ", kesn);
            sqlStatementBuilder.AppendLine("  AND dkei = :p ", dkei);
            sqlStatementBuilder.AppendLine("  AND dseq = :p ", dseq);
            sqlStatementBuilder.AppendLine("  AND sseq = :p ", sseq);
            this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// 出力フラグ、伝票状態フラグ、行変更仕訳存在フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouUpdateStatusFlag">伝票状態フラグ</param>
        /// <param name="isUpdateIsUpdatedLine">行変更仕訳存在フラグを更新するかどうか</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsPrintedChecklistToTrueAndDenpyouUpdateStatusFlagAndIsUpdatedLineToFalse(int kesn, int dkei, int dseq, DenpyouUpdateStatusFlag denpyouUpdateStatusFlag, bool isUpdateIsUpdatedLine, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.AppendLine("UPDATE ");
            sqlStatementBuilder.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("SET ");
            sqlStatementBuilder.AppendLine("  cprt = 1 ");
            sqlStatementBuilder.AppendLine("  , hsflg = :p ", (short)denpyouUpdateStatusFlag);
            sqlStatementBuilder.AppendIfTrue(isUpdateIsUpdatedLine, "  , hgflg = 0 ");
            sqlStatementBuilder.AppendLine();
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p ", kesn);
            sqlStatementBuilder.AppendLine("  AND dkei = :p ", dkei);
            sqlStatementBuilder.AppendLine("  AND dseq = :p ", dseq);
            this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// 承認関連の値を更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="syouninUserNo">承認者コード</param>
        /// <param name="syouninStatus">承認判定</param>
        /// <param name="syouninOrder">承認順序</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1131:Use readable conditions", Justification = "見やすさのため")]
        public virtual void UpdateSyouninRelatedValue(Denpyou denpyou, DenpyouType denpyouType, int syouninUserNo, SyouninStatus syouninStatus, int syouninOrder)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  hjno = :p ", (short)denpyou.HanteizumiSaizyouiSyouninsyaZyunzyo);
            updateQuery.AppendLine("  , sflg = :p ", (short)denpyou.SyouninZyoukyou);
            updateQuery.AppendIfTrue(1 <= syouninOrder && syouninOrder <= 10, string.Format("  , sn{0} = :p ", syouninOrder.ToString("00")), syouninUserNo);
            updateQuery.AppendIfTrue(1 <= syouninOrder && syouninOrder <= 10, string.Format("  , sf{0} = :p ", syouninOrder.ToString("00")), (short)syouninStatus);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", denpyou.Kesn);
            updateQuery.AppendLine("  AND dkei = :p ", denpyou.Dkei);
            updateQuery.AppendLine("  AND dseq = :p ", denpyou.DenpyouSequenceNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 取消フラグを更新します
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="syouninUsage">承認使用状況</param>
        public virtual void UpdateIsTorikesi(Denpyou denpyou, DenpyouType denpyouType, SyouninUsage syouninUsage)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  delf = :p ", denpyou.IsTorikesi ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", denpyou.Kesn);
            updateQuery.AppendLine("  AND dkei = :p ", denpyou.Dkei);
            updateQuery.AppendLine("  AND dseq = :p ", denpyou.DenpyouSequenceNumber);
            updateQuery.AppendLine("  AND delf = :p ", denpyou.IsTorikesi ? 0 : 1);
            if (syouninUsage != SyouninUsage.使用しない)
            {
                updateQuery.AppendLine("  AND (kday = 0 OR sflg IN (2, 3)) ");
            }

            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 入力確定日を一括で更新します
        /// </summary>
        /// <param name="denpyouKeyList">更新対象の伝票キー項目のリスト</param>
        /// <param name="denpyouType">伝票形式</param>
        /// <param name="kesn">内部決算期</param>
        /// <param name="currentDate">現在の日付</param>
        public virtual void UpdateNyuuryokuKakuteibi(IList<IDenpyouKey> denpyouKeyList, DenpyouType denpyouType, int kesn, int currentDate)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  kday = :p ", currentDate);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", kesn);
            updateQuery.AppendLine("  AND kday = 0 ");
            updateQuery.AppendLine("  AND sgno > 0 ");
            updateQuery.AppendLine("  AND delf = 0 ");
            var whereQuery = new SqlStatementBuilder();
            foreach (var denpyouKey in denpyouKeyList)
            {
                whereQuery.Append(whereQuery.IsEmpty ? "  AND (" : " OR ");
                whereQuery.Append("(dkei = :p AND dseq = :p)", denpyouKey.Dkei, denpyouKey.DenpyouSequenceNumber);
            }

            whereQuery.AppendLine(") ");
            updateQuery.AppendLine(whereQuery.GetSqlStatement(), whereQuery.GetSqlParameters());
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 伝票取消
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        /// <param name="isCreateRireki"></param>
        public virtual void StoreTorikesiDenpyou(Denpyou denpyou, DenpyouType denpyouType, bool isCreateRireki)
        {
            // 伝票ヘッダを取り消し
            var updateQuery = new SqlStatementBuilder("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  lmod = :p, ", denpyou.DenpyouKousinbi);
            updateQuery.AppendLine("  ltim = :p, ", denpyou.DenpyouKousinZikan);
            updateQuery.AppendLine("  lusr = :p, ", denpyou.DenpyouKousinsyaCode);
            updateQuery.AppendLine("  lway = :p, ", (int)denpyou.DenpyouKousinHouhou);
            updateQuery.AppendLine("  delf = :p, ", denpyou.IsTorikesi ? 1 : 0);
            updateQuery.AppendLine("  idm1 = :p, ", denpyou.RirekiNumber);
            updateQuery.AppendLine("  idm2 = :p, ", denpyou.RirekiDenpyouSequence);
            updateQuery.AppendLine("  idm3 = :p ", isCreateRireki && denpyouType == DenpyouType.TuuzyouDenpyou ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p AND ", denpyou.Kesn);
            updateQuery.AppendLine("  dkei = :p AND ", denpyou.Dkei);
            updateQuery.AppendLine("  dseq = :p ", denpyou.DenpyouSequenceNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());

            // 全仕訳を取り消し
            denpyou.SiwakeList.ForEachIfNotNull(siwake => this.siwakeRepository.UpdateLastUpdateInfomationAndTorikesiFlag(siwake, denpyouType));

            // 全リンク情報を削除
            denpyou.LinkInfomationList.ForEachIfNotNull(linkInfomation => this.linkInfomationRepository.Delete(linkInfomation));

            // 伝票束リンクを削除
            if (denpyou.DenpyouTabaLink != null)
            {
                this.denpyouTabaLinkRepository.Delete(denpyou.DenpyouTabaLink);
            }
        }

        /// <summary>
        /// 伝票クラス内全プロパティの更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouOld"></param>
        /// <param name="denpyouType"></param>
        public virtual void StoreUpdateDenpyou(Denpyou denpyou, Denpyou denpyouOld, DenpyouType denpyouType)
        {
            this.UpdateDenpyouHeader(denpyou, denpyouType);
            this.StoreSiwakeMeisai(denpyou, denpyouType);
            this.StoreLinkInfomationList(denpyou, denpyouType);
            this.StoreDenpyouTabaLink(denpyou, denpyouOld, denpyouType);
        }

        public virtual void Insert(Denpyou denpyou, DenpyouType denpyouType)
        {
            InsertSqlStatementBuilder insertSqlStatementBuilder;
            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    insertSqlStatementBuilder = new InsertSqlStatementBuilder(TuuzyouDenpyouTableName);
                    break;
                case DenpyouType.Busyo:
                    insertSqlStatementBuilder = new InsertSqlStatementBuilder(BusyoDenpyouTableName);
                    break;
                case DenpyouType.Sokyuu:
                default:
                    insertSqlStatementBuilder = new InsertSqlStatementBuilder(SokyuuDenpyouTableName);
                    break;
            }

            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", denpyou.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkei", denpyou.Dkei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dseq", denpyou.DenpyouSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dymd", denpyou.DenpyouHizuke);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dcno", denpyou.DenpyouNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dfuk", (short)denpyou.DenpyouKeisiki);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ijpt", denpyou.DenpyouInputPatternNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kymd", denpyou.Kihyoubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kbmn", denpyou.KihyouBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kusr", denpyou.KihyousyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fmod", denpyou.DenpyouSakuseibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ftim", denpyou.DenpyouSakuseiZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", denpyou.DenpyouSakuseisyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fway", (int)denpyou.DenpyouSakuseiHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", denpyou.DenpyouKousinbi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", denpyou.DenpyouKousinZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", denpyou.DenpyouKousinsyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lway", (int)denpyou.DenpyouKousinHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("delf", denpyou.IsTorikesi ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cprt", denpyou.IsPrintedChecklist ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dprt", (short)denpyou.HurikaeDenpyouPrintedFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duno", denpyou.UketukeNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kday", denpyou.NyuuryokuKakuteibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fprt", (short)denpyou.PrintedDenpyouBeforeSyounin);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgno", denpyou.SyouninGroupNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("hjno", 99);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sflg", (short)denpyou.SyouninZyoukyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("smnt", denpyou.IsSyouninUserUpdate ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn01", denpyou.Dai1SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf01", (short)denpyou.Dai1SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn02", denpyou.Dai2SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf02", (short)denpyou.Dai2SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn03", denpyou.Dai3SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf03", (short)denpyou.Dai3SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn04", denpyou.Dai4SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf04", (short)denpyou.Dai4SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn05", denpyou.Dai5SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf05", (short)denpyou.Dai5SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn06", denpyou.Dai6SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf06", (short)denpyou.Dai6SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn07", denpyou.Dai7SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf07", (short)denpyou.Dai7SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn08", denpyou.Dai8SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf08", (short)denpyou.Dai8SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn09", denpyou.Dai9SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf09", (short)denpyou.Dai9SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sn10", denpyou.Dai10SyouninsyaUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sf10", (short)denpyou.Dai10SyouninStatus);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm1", denpyou.RirekiNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm2", denpyou.RirekiDenpyouSequence);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm3", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf1", denpyou.HeaderField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf2", denpyou.HeaderField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf3", denpyou.HeaderField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf4", denpyou.HeaderField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf5", denpyou.HeaderField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf6", denpyou.HeaderField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf7", denpyou.HeaderField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf8", denpyou.HeaderField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf9", denpyou.HeaderField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf10", denpyou.HeaderField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("bflg", denpyou.IsMikanDenpyou ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("hsflg", (short)denpyou.DenpyouUpdateStatusFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("hgflg", denpyou.IsUpdatedLine ? 1 : 0);
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());

            // 伝票内の全仕訳を登録
            denpyou.SiwakeList.ForEachIfNotNull(siwake => this.siwakeRepository.Insert(siwake, denpyouType));

            // 伝票内の全リンク情報を登録
            denpyou.LinkInfomationList.ForEachIfNotNull(linkInfomation => this.linkInfomationRepository.Insert(linkInfomation, this.timeStampSettingRepository.Find()));

            // 部署入出力処理の場合は伝票束リンクを登録
            if (denpyouType == DenpyouType.Busyo && denpyou.DenpyouTabaLink != null)
            {
                this.denpyouTabaLinkRepository.Insert(denpyou.DenpyouTabaLink);
            }
        }

        public virtual Denpyou FindByKesnAndDkeiAndDseqAndIsTorikesi(int kesn, int dkei, int dseq, DenpyouType denpyouType)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT kesn, dkei, dseq, dymd, dcno, dfuk, ijpt, kymd, kbmn, kusr, " +
                "fmod, ftim, fusr, fway, lmod, ltim, lusr, lway, delf, cprt, " +
                "dprt, duno, kday, fprt, sgno, hjno, sflg, smnt, sn01, sf01, " +
                "sn02, sf02, sn03, sf03, sn04, sf04, sn05, sf05, sn06, sf06, " +
                "sn07, sf07, sn08, sf08, sn09, sf09, sn10, sf10, idm1, idm2, " +
                "idm3, duf1, duf2, duf3, duf4, duf5, duf6, duf7, duf8, duf9, " +
                "duf10, bflg, hsflg, hgflg ");

            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    selectQuery.AppendLine("FROM zdata_h ");
                    break;
                case DenpyouType.Busyo:
                    selectQuery.AppendLine("FROM sjdat_h ");
                    break;
                case DenpyouType.Sokyuu:
                    selectQuery.AppendLine("FROM skdat_h ");
                    break;
            }

            selectQuery.AppendLine("WHERE kesn = :p AND dkei = :p AND dseq = :p And delf = 0 ");

            var denpyou = this.dbc.QueryForObject(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var row = new Denpyou(kesn, dkei, dseq);
                    row.DenpyouHizuke = (int)values[3]; // 伝票日付
                    row.DenpyouNo = DbNullConverter.ToNullableInt(values[4]); // 伝票番号
                    row.DenpyouKeisiki = (DenpyouKeisiki)(int)(short)values[5]; // 複合ﾌﾗｸﾞ
                    row.DenpyouInputPatternNumber = (int)(short)values[6]; // 入力パターン
                    row.Kihyoubi = (int)values[7]; // 起票年月日
                    row.KihyouBumonCode = DbNullConverter.ToString(values[8], null); // 起票部門
                    row.KihyousyaCode = DbNullConverter.ToString(values[9], null); // 起票者
                    row.DenpyouSakuseibi = (int)values[10]; // 入力年月日
                    row.DenpyouSakuseiZikan = (int)values[11]; // 入力時分秒
                    row.DenpyouSakuseisyaCode = (int)values[12]; // 入力者
                    row.DenpyouSakuseiHouhou = (DenpyouSiwakeWayToCreate)(int)values[13]; // 入力手段
                    row.DenpyouKousinbi = (int)values[14]; // 最終変更年月日
                    row.DenpyouKousinZikan = (int)values[15]; // 最終変更時分秒
                    row.DenpyouKousinsyaCode = (int)values[16]; // 最終変更者
                    row.DenpyouKousinHouhou = (DenpyouSiwakeWayToCreate)(int)values[17]; // 最終変更手段
                    row.IsTorikesi = (short)values[18] == 1; // 削除ﾌﾗｸﾞ
                    row.IsPrintedChecklist = (short)values[19] == 1; // 出力ﾌﾗｸﾞ
                    row.HurikaeDenpyouPrintedFlag = (PrintedFlag)(short)values[20]; // 伝票発行済sw
                    row.UketukeNo = (int)values[21]; // 受付番号
                    row.NyuuryokuKakuteibi = (int)values[22]; // 入力確定日
                    row.PrintedDenpyouBeforeSyounin = (PrintedFlag)(short)values[23]; // 承認前伝票発行sw
                    row.SyouninGroupNumber = (int)values[24]; // 承認ｸﾞﾙｰﾌﾟno
                    row.HanteizumiSaizyouiSyouninsyaZyunzyo = (int)(short)values[25]; // 判定済最上位承認者順序
                    row.SyouninZyoukyou = (SyouninStatus)(short)values[26]; // 承認状況
                    row.IsSyouninUserUpdate = (short)values[27] == 1; // 承認者編集
                    row.Dai1SyouninsyaUserCode = (int)values[28]; // 第一承認者
                    row.Dai1SyouninStatus = (SyouninStatus)(short)values[29]; // 第一承認判定
                    row.Dai2SyouninsyaUserCode = (int)values[30]; // 第二承認者
                    row.Dai2SyouninStatus = (SyouninStatus)(short)values[31]; // 第二承認判定
                    row.Dai3SyouninsyaUserCode = (int)values[32]; // 第三承認者
                    row.Dai3SyouninStatus = (SyouninStatus)(short)values[33]; // 第三承認判定
                    row.Dai4SyouninsyaUserCode = (int)values[34]; // 第四承認者
                    row.Dai4SyouninStatus = (SyouninStatus)(short)values[35]; // 第四承認判定
                    row.Dai5SyouninsyaUserCode = (int)values[36]; // 第五承認者
                    row.Dai5SyouninStatus = (SyouninStatus)(short)values[37]; // 第五承認判定
                    row.Dai6SyouninsyaUserCode = (int)values[38]; // 第六承認者
                    row.Dai6SyouninStatus = (SyouninStatus)(short)values[39]; // 第六承認判定
                    row.Dai7SyouninsyaUserCode = (int)values[40]; // 第七承認者
                    row.Dai7SyouninStatus = (SyouninStatus)(short)values[41]; // 第七承認判定
                    row.Dai8SyouninsyaUserCode = (int)values[42]; // 第八承認者
                    row.Dai8SyouninStatus = (SyouninStatus)(short)values[43]; // 第八承認判定
                    row.Dai9SyouninsyaUserCode = (int)values[44]; // 第九承認者
                    row.Dai9SyouninStatus = (SyouninStatus)(short)values[45]; // 第九承認判定
                    row.Dai10SyouninsyaUserCode = (int)values[46]; // 第十承認者
                    row.Dai10SyouninStatus = (SyouninStatus)(short)values[47]; // 第十承認判定
                    row.RirekiNumber = (int)values[48]; // 履歴番号
                    row.RirekiDenpyouSequence = (int)values[49]; // 履歴伝票seqno.
                    // row.Idm3 = (int)vakues[50]; // 履歴伝票削除ﾌﾗｸﾞ
                    row.HeaderField1Code = DbNullConverter.ToString(values[51], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1
                    row.HeaderField2Code = DbNullConverter.ToString(values[52], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2
                    row.HeaderField3Code = DbNullConverter.ToString(values[53], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3
                    row.HeaderField4Code = DbNullConverter.ToString(values[54], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4
                    row.HeaderField5Code = DbNullConverter.ToString(values[55], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5
                    row.HeaderField6Code = DbNullConverter.ToString(values[56], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6
                    row.HeaderField7Code = DbNullConverter.ToString(values[57], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7
                    row.HeaderField8Code = DbNullConverter.ToString(values[58], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8
                    row.HeaderField9Code = DbNullConverter.ToString(values[59], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9
                    row.HeaderField10Code = DbNullConverter.ToString(values[60], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10
                    row.IsMikanDenpyou = (short)values[61] == 1; // 未完伝票ﾌﾗｸﾞ
                    row.DenpyouUpdateStatusFlag = (DenpyouUpdateStatusFlag)(short)values[62]; // 伝票状態フラグ
                    row.IsUpdatedLine = (short)values[63] == 1; // 行変更仕訳存在フラグ
                    return row;
                },
                kesn,
                dkei,
                dseq);
            if (denpyou == null)
            {
                return null;
            }

            denpyou.SiwakeList = this.siwakeRepository.FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(denpyou, denpyouType);

            if (denpyouType == DenpyouType.Busyo)
            {
                denpyou.DenpyouTabaLink = this.denpyouTabaLinkRepository.FindByKesnAndDkeiAndDunoAndDymdAndDcno(denpyou.Kesn, denpyou.Dkei, denpyou.UketukeNo, denpyou.DenpyouHizuke, denpyou.DenpyouNo ?? 0);
            }

            denpyou.LinkInfomationList = this.linkInfomationRepository.FindByKesnAndDkeiAndDseqAndDenpyouTypeOrderByLkid(denpyou.Kesn, denpyou.Dkei, denpyou.DenpyouSequenceNumber, denpyouType);

            return denpyou;
        }

        /// <summary>
        /// 範囲処理月内に、伝票が存在するかどうかを取得します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="startDkei">開始処理月</param>
        /// <param name="endDkei">終了処理月</param>
        /// <returns>伝票が存在するかどうか</returns>
        public virtual bool GetYuukouDenpyouExistsByKesnAndDkeiRange(int kesn, int startDkei, int endDkei)
        {
            return this.dbc.QueryForObject(
                "SELECT dseq FROM sjdat_h WHERE kesn = :p AND dkei BETWEEN :p AND :p AND delf = 0 ",
                (values, no) => true,
                kesn,
                startDkei,
                endDkei);
        }

        public virtual bool GetExistsYuukouDenpyouWithSpecifiedDenpyouBangou(int kesn, int dkei, int denpyouSequenceNumber, int? denpyouNo, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder();
            sqlStatementBuilder.AppendLine("SELECT COUNT(dcno) ");
            sqlStatementBuilder.AppendLine(string.Format("FROM {0} ", this.GetTableName(denpyouType)));
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", kesn);
            sqlStatementBuilder.AppendLine("  dkei = :p AND ", dkei);
            sqlStatementBuilder.AppendLine("  dseq != :p AND ", denpyouSequenceNumber);
            sqlStatementBuilder.AppendLine("  dcno = :p AND ", denpyouNo);
            sqlStatementBuilder.AppendLine("  delf = 0 ");
            return this.dbc.QueryForObject(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    return Convert.ToInt32(values[0]) > 0 ? true : false;
                },
                sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// 伝票ヘッダーの更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        /// <returns></returns>
        private bool UpdateDenpyouHeader(Denpyou denpyou, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder("UPDATE ");
            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    updateQuery.AppendLine(TuuzyouDenpyouTableName);
                    break;
                case DenpyouType.Busyo:
                    updateQuery.AppendLine(BusyoDenpyouTableName);
                    break;
                case DenpyouType.Sokyuu:
                    updateQuery.AppendLine(SokyuuDenpyouTableName);
                    break;
            }

            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("dymd = :p, ", denpyou.DenpyouHizuke);
            updateQuery.AppendLine("dcno = :p, ", denpyou.DenpyouNo);
            updateQuery.AppendLine("dfuk = :p, ", (short)denpyou.DenpyouKeisiki);
            updateQuery.AppendLine("ijpt = :p, ", denpyou.DenpyouInputPatternNumber);
            updateQuery.AppendLine("kymd = :p, ", denpyou.Kihyoubi);
            updateQuery.AppendLine("kbmn = :p, ", denpyou.KihyouBumonCode);
            updateQuery.AppendLine("kusr = :p, ", denpyou.KihyousyaCode);
            updateQuery.AppendLine("lmod = :p, ", denpyou.DenpyouKousinbi);
            updateQuery.AppendLine("ltim = :p, ", denpyou.DenpyouKousinZikan);
            updateQuery.AppendLine("lusr = :p, ", denpyou.DenpyouKousinsyaCode);
            updateQuery.AppendLine("lway = :p, ", (int)denpyou.DenpyouKousinHouhou);
            updateQuery.AppendLine("delf = :p, ", denpyou.IsTorikesi ? 1 : 0);
            updateQuery.AppendLine("cprt = :p, ", denpyou.IsPrintedChecklist ? 1 : 0);
            updateQuery.AppendLine("dprt = :p, ", (short)denpyou.HurikaeDenpyouPrintedFlag);
            updateQuery.AppendLine("duno = :p, ", denpyou.UketukeNo);
            updateQuery.AppendLine("kday = :p, ", denpyou.NyuuryokuKakuteibi);
            updateQuery.AppendLine("fprt = :p, ", (short)denpyou.PrintedDenpyouBeforeSyounin);
            updateQuery.AppendLine("sgno = :p, ", denpyou.SyouninGroupNumber);
            updateQuery.AppendLine("hjno = :p, ", (short)denpyou.HanteizumiSaizyouiSyouninsyaZyunzyo);
            updateQuery.AppendLine("sflg = :p, ", (short)denpyou.SyouninZyoukyou);
            updateQuery.AppendLine("smnt = :p, ", denpyou.IsSyouninUserUpdate ? 1 : 0);
            updateQuery.AppendLine("sn01 = :p, ", denpyou.Dai1SyouninsyaUserCode);
            updateQuery.AppendLine("sf01 = :p, ", (short)denpyou.Dai1SyouninStatus);
            updateQuery.AppendLine("sn02 = :p, ", denpyou.Dai2SyouninsyaUserCode);
            updateQuery.AppendLine("sf02 = :p, ", (short)denpyou.Dai2SyouninStatus);
            updateQuery.AppendLine("sn03 = :p, ", denpyou.Dai3SyouninsyaUserCode);
            updateQuery.AppendLine("sf03 = :p, ", (short)denpyou.Dai3SyouninStatus);
            updateQuery.AppendLine("sn04 = :p, ", denpyou.Dai4SyouninsyaUserCode);
            updateQuery.AppendLine("sf04 = :p, ", (short)denpyou.Dai4SyouninStatus);
            updateQuery.AppendLine("sn05 = :p, ", denpyou.Dai5SyouninsyaUserCode);
            updateQuery.AppendLine("sf05 = :p, ", (short)denpyou.Dai5SyouninStatus);
            updateQuery.AppendLine("sn06 = :p, ", denpyou.Dai6SyouninsyaUserCode);
            updateQuery.AppendLine("sf06 = :p, ", (short)denpyou.Dai6SyouninStatus);
            updateQuery.AppendLine("sn07 = :p, ", denpyou.Dai7SyouninsyaUserCode);
            updateQuery.AppendLine("sf07 = :p, ", (short)denpyou.Dai7SyouninStatus);
            updateQuery.AppendLine("sn08 = :p, ", denpyou.Dai8SyouninsyaUserCode);
            updateQuery.AppendLine("sf08 = :p, ", (short)denpyou.Dai8SyouninStatus);
            updateQuery.AppendLine("sn09 = :p, ", denpyou.Dai9SyouninsyaUserCode);
            updateQuery.AppendLine("sf09 = :p, ", (short)denpyou.Dai9SyouninStatus);
            updateQuery.AppendLine("sn10 = :p, ", denpyou.Dai10SyouninsyaUserCode);
            updateQuery.AppendLine("sf10 = :p, ", (short)denpyou.Dai10SyouninStatus);
            updateQuery.AppendLine("idm1 = :p, ", denpyou.RirekiNumber);
            updateQuery.AppendLine("idm2 = :p, ", denpyou.RirekiDenpyouSequence);
            updateQuery.AppendLine("idm3 = 0, ");
            updateQuery.AppendLine("duf1 = :p, ", denpyou.HeaderField1Code);
            updateQuery.AppendLine("duf2 = :p, ", denpyou.HeaderField2Code);
            updateQuery.AppendLine("duf3 = :p, ", denpyou.HeaderField3Code);
            updateQuery.AppendLine("duf4 = :p, ", denpyou.HeaderField4Code);
            updateQuery.AppendLine("duf5 = :p, ", denpyou.HeaderField5Code);
            updateQuery.AppendLine("duf6 = :p, ", denpyou.HeaderField6Code);
            updateQuery.AppendLine("duf7 = :p, ", denpyou.HeaderField7Code);
            updateQuery.AppendLine("duf8 = :p, ", denpyou.HeaderField8Code);
            updateQuery.AppendLine("duf9 = :p, ", denpyou.HeaderField9Code);
            updateQuery.AppendLine("duf10 = :p, ", denpyou.HeaderField10Code);
            updateQuery.AppendLine("bflg = :p, ", denpyou.IsMikanDenpyou ? 1 : 0);
            updateQuery.AppendLine("hsflg = :p, ", (short)denpyou.DenpyouUpdateStatusFlag);
            updateQuery.AppendLine("hgflg = :p ", denpyou.IsUpdatedLine ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("kesn = :p AND ", denpyou.Kesn);
            updateQuery.AppendLine("dkei = :p AND ", denpyou.Dkei);
            updateQuery.AppendLine("dseq = :p ", denpyou.DenpyouSequenceNumber);
            return this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters()) > 0;
        }

        /// <summary>
        /// 仕訳明細の更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        private void StoreSiwakeMeisai(Denpyou denpyou, DenpyouType denpyouType)
        {
            // 新規仕訳の登録
            denpyou.SiwakeList.ForEach(
                siwake => siwake.IsNew,
                siwake => this.siwakeRepository.Insert(siwake, denpyouType));

            // 既存仕訳(更新有)の更新
            denpyou.SiwakeList.ForEach(
                siwake => !siwake.IsNew,
                siwake => this.siwakeRepository.Update(siwake, denpyouType));
        }

        /// <summary>
        /// リンク情報の更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouType"></param>
        private void StoreLinkInfomationList(Denpyou denpyou, DenpyouType denpyouType)
        {
            var timeStampSetting = this.timeStampSettingRepository.Find();

            // 新規リンク情報の登録
            denpyou.LinkInfomationList.ForEach(
                linkInfomation => linkInfomation.IsNew,
                linkInfomation => this.linkInfomationRepository.Insert(linkInfomation, timeStampSetting));

            // 既存リンク情報の更新
            denpyou.LinkInfomationList.ForEach(
                linkInfomation => !linkInfomation.IsNew,
                linkInfomation => this.linkInfomationRepository.Update(linkInfomation, timeStampSetting));
        }

        /// <summary>
        /// 伝票束リンクの更新
        /// </summary>
        /// <param name="denpyou"></param>
        /// <param name="denpyouOld"></param>
        /// <param name="denpyouType"></param>
        private void StoreDenpyouTabaLink(Denpyou denpyou, Denpyou denpyouOld, DenpyouType denpyouType)
        {
            // 伝票束リンクを削除
            if (denpyouOld.DenpyouTabaLink != null)
            {
                this.denpyouTabaLinkRepository.Delete(denpyouOld.DenpyouTabaLink);
            }

            // 部署入出力処理の場合は伝票束リンクを登録
            if (denpyouType == DenpyouType.Busyo && denpyou.DenpyouTabaLink != null)
            {
                this.denpyouTabaLinkRepository.Insert(denpyou.DenpyouTabaLink);
            }
        }

        private string GetTableName(DenpyouType denpyouType)
        {
            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    return TuuzyouDenpyouTableName;
                case DenpyouType.Busyo:
                    return BusyoDenpyouTableName;
                case DenpyouType.Sokyuu:
                default:
                    return SokyuuDenpyouTableName;
            }
        }
    }
}
