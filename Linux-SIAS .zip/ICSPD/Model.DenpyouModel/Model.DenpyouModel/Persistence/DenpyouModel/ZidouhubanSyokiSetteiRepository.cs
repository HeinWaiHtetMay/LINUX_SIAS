﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ZidouhubanSyokiSetteiRepository : IZidouhubanSyokiSetteiRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual ZidouhubanSyokiSettei FindByKesn(int kesn) =>
            this.dbc.QueryForObject(
                "SELECT juse, cdm1, cdm2, cdm3, cdm4, idm1, idm2, idm3, idm4 " +
                "FROM jfctl WHERE kesn = :p",
                (values, no) =>
                {
                    var row = new ZidouhubanSyokiSettei(kesn)
                    {
                        ZidouhubanType = (ZidouhubanType)(int)(short)values[0],
                        IsUseBusyoNyuusyuturyokuZidouHuban = (int)values[5] == 1 ? true : false,
                    };
                    return row;
                },
                kesn)
                    ?? new ZidouhubanSyokiSettei(kesn)
                    {
                        ZidouhubanType = ZidouhubanType.DoNotUse,
                        IsUseBusyoNyuusyuturyokuZidouHuban = false,
                    };
    }
}
