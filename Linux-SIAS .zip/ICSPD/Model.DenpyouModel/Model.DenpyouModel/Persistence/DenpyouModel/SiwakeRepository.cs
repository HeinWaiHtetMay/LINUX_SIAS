﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class SiwakeRepository : ISiwakeRepository
    {
        private static readonly string TuuzyouSiwakeTableName = "zdata";
        private static readonly string BusyoSiwakeTableName = "sjdat";
        private static readonly string SokyuuSiwakeTableName = "skdat";

        [AutoInjection]
        private ISyouninCommentRepository syouninCommentRepository = null;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual void Insert(Siwake siwake, DenpyouType denpyouType)
        {
            var insertSqlStatementBuilder = this.CreateSiwakeInsertSqlStatementBuilder(siwake, this.GetTableName(denpyouType));
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());

            // 経過月の変更、財務転記による既存コメントの別経過月又は別テーブルへの複製処理であるため付番しない
            this.InsertSyouninComment(siwake, denpyouType, false);
        }

        public virtual void Update(Siwake siwake, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder("UPDATE ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("SET ");
            sqlStatementBuilder.AppendLine("  kesn = :p, ", siwake.Kesn);
            sqlStatementBuilder.AppendLine("  dkei = :p, ", siwake.Dkei);
            sqlStatementBuilder.AppendLine("  dseq = :p, ", siwake.DenpyouSequenceNumber);
            sqlStatementBuilder.AppendLine("  sseq = :p, ", siwake.SiwakeSequenceNumber);
            sqlStatementBuilder.AppendLine("  pseq = :p, ", siwake.ParentChildSiwakeSequenceNumber);
            sqlStatementBuilder.AppendLine("  pflg = :p, ", (short)siwake.ParentChildFlag);
            sqlStatementBuilder.AppendLine("  bkbn = :p, ", (short)siwake.BunriKubun);
            sqlStatementBuilder.AppendLine("  grno = :p, ", siwake.GroupNumber);
            sqlStatementBuilder.AppendLine("  dcpg = 1, ");
            sqlStatementBuilder.AppendLine("  dlin = :p, ", siwake.LineNo);
            sqlStatementBuilder.AppendLine("  dflg = :p, ", (short)siwake.SiwakeTaisyakuZokusei);
            sqlStatementBuilder.AppendLine("  rbmn = :p, ", siwake.KarikataBumonCode);
            sqlStatementBuilder.AppendLine("  rtor = :p, ", siwake.KarikataTorihikisakiCode);
            sqlStatementBuilder.AppendLine("  rkmk = :p, ", siwake.KarikataKamokuCode);
            sqlStatementBuilder.AppendLine("  reda = :p, ", siwake.KarikataEdabanCode);
            sqlStatementBuilder.AppendLine("  rkoj = :p, ", siwake.KarikataKouziCode);
            sqlStatementBuilder.AppendLine("  rkos = :p, ", siwake.KarikataKousyuCode);
            sqlStatementBuilder.AppendLine("  rprj = :p, ", siwake.KarikataProjectCode);
            sqlStatementBuilder.AppendLine("  rseg = :p, ", siwake.KarikataSegmentCode);
            sqlStatementBuilder.AppendLine("  rdm1 = :p, ", siwake.KarikataUniversalField1Code);
            sqlStatementBuilder.AppendLine("  rdm2 = :p, ", siwake.KarikataUniversalField2Code);
            sqlStatementBuilder.AppendLine("  rdm3 = :p, ", siwake.KarikataUniversalField3Code);
            sqlStatementBuilder.AppendLine("  rtky = :p, ", siwake.KarikataTekiyou);
            sqlStatementBuilder.AppendLine("  rtno = :p, ", siwake.KarikataTekiyouCode);
            sqlStatementBuilder.AppendLine("  rimg = :p, ", siwake.KarikataImageNumber);
            sqlStatementBuilder.AppendLine("  sbmn = :p, ", siwake.KasikataBumonCode);
            sqlStatementBuilder.AppendLine("  stor = :p, ", siwake.KasikataTorihikisakiCode);
            sqlStatementBuilder.AppendLine("  skmk = :p, ", siwake.KasikataKamokuCode);
            sqlStatementBuilder.AppendLine("  seda = :p, ", siwake.KasikataEdabanCode);
            sqlStatementBuilder.AppendLine("  skoj = :p, ", siwake.KasikataKouziCode);
            sqlStatementBuilder.AppendLine("  skos = :p, ", siwake.KasikataKousyuCode);
            sqlStatementBuilder.AppendLine("  sprj = :p, ", siwake.KasikataProjectCode);
            sqlStatementBuilder.AppendLine("  sseg = :p, ", siwake.KasikataSegmentCode);
            sqlStatementBuilder.AppendLine("  sdm1 = :p, ", siwake.KasikataUniversalField1Code);
            sqlStatementBuilder.AppendLine("  sdm2 = :p, ", siwake.KasikataUniversalField2Code);
            sqlStatementBuilder.AppendLine("  sdm3 = :p, ", siwake.KasikataUniversalField3Code);
            sqlStatementBuilder.AppendLine("  stky = :p, ", siwake.KasikataTekiyou);
            sqlStatementBuilder.AppendLine("  stno = :p, ", siwake.KasikataTekiyouCode);
            sqlStatementBuilder.AppendLine("  simg = :p, ", siwake.KasikataImageNumber);
            sqlStatementBuilder.AppendLine("  tflg = :p, ", siwake.IsInputTaika ? 1 : 0);
            sqlStatementBuilder.AppendLine("  exvl = :p, ", siwake.TaikaKingaku);
            sqlStatementBuilder.AppendLine("  zkvl = :p, ", siwake.ZeikomiKingaku);
            sqlStatementBuilder.AppendLine("  valu = :p, ", siwake.Kingaku);
            sqlStatementBuilder.AppendLine("  zkmk = :p, ", siwake.ZeitaisyouKamokuCode);
            sqlStatementBuilder.AppendLine("  zrit = :p, ", (int?)(siwake.ZeitaisyouKamokuZeiritu?.GetValue() * 10000));
            sqlStatementBuilder.AppendLine("  zzkb = :p, ", (short)siwake.ZeitaisyouKamokuKazeiKubun);
            sqlStatementBuilder.AppendLine("  zgyo = :p, ", (short)siwake.ZeitaisyouKamokuGyousyuKubun);
            sqlStatementBuilder.AppendLine("  zsre = :p, ", (short)siwake.ZeitaisyouKamokuSiireKubun);
            sqlStatementBuilder.AppendLine("  rrit = :p, ", (int?)(siwake.KarikataZeiritu?.GetValue() * 10000));
            sqlStatementBuilder.AppendLine("  srit = :p, ", (int?)(siwake.KasikataZeiritu?.GetValue() * 10000));
            sqlStatementBuilder.AppendLine("  rzkb = :p, ", (short)siwake.KarikataKazeiKubun);
            sqlStatementBuilder.AppendLine("  rgyo = :p, ", (short)siwake.KarikataGyousyuKubun);
            sqlStatementBuilder.AppendLine("  rsre = :p, ", (short)siwake.KarikataSiireKubun);
            sqlStatementBuilder.AppendLine("  szkb = :p, ", (short)siwake.KasikataKazeiKubun);
            sqlStatementBuilder.AppendLine("  sgyo = :p, ", (short)siwake.KasikataGyousyuKubun);
            sqlStatementBuilder.AppendLine("  ssre = :p, ", (short)siwake.KasikataSiireKubun);
            sqlStatementBuilder.AppendLine("  ifri = :p, ", (short)siwake.IkkatuZeinukiSiwakeFlag);
            sqlStatementBuilder.AppendLine("  symd = :p, ", siwake.Siharaibi);
            sqlStatementBuilder.AppendLine("  skbn = :p, ", siwake.SiharaiKubun);
            sqlStatementBuilder.AppendLine("  skiz = :p, ", siwake.SiharaiKizitu);
            sqlStatementBuilder.AppendLine("  uymd = :p, ", siwake.Kaisyuubi);
            sqlStatementBuilder.AppendLine("  ukbn = :p, ", siwake.NyuukinKubun);
            sqlStatementBuilder.AppendLine("  ukiz = :p, ", siwake.KaisyuuKizitu);
            sqlStatementBuilder.AppendLine("  sexp = :p, ", siwake.IsExportSiharai ? 1 : 0);
            sqlStatementBuilder.AppendLine("  dkec = :p, ", siwake.KesikomiCode);
            sqlStatementBuilder.AppendLine("  pcsw = :p, ", siwake.IsKesikomiTyuusyutu ? 1 : 0);
            sqlStatementBuilder.AppendLine("  upsw = :p, ", siwake.IsKesikomiUpdate ? 1 : 0);
            sqlStatementBuilder.AppendLine("  zrsw = :p, ", siwake.IsKesikomiZero ? 1 : 0);
            sqlStatementBuilder.AppendLine("  gpcd = :p, ", siwake.KesikomiGroupCode);
            sqlStatementBuilder.AppendLine("  fmod = :p, ", siwake.SiwakeSakuseibi);
            sqlStatementBuilder.AppendLine("  ftim = :p, ", siwake.SiwakeSakuseiZikan);
            sqlStatementBuilder.AppendLine("  fusr = :p, ", siwake.SiwakeSakuseisyaCode);
            sqlStatementBuilder.AppendLine("  fway = :p, ", (int)siwake.SiwakeSakuseiHouhou);
            sqlStatementBuilder.AppendLine("  lmod = :p, ", siwake.SiwakeKousinbi);
            sqlStatementBuilder.AppendLine("  ltim = :p, ", siwake.SiwakeKousinZikan);
            sqlStatementBuilder.AppendLine("  lusr = :p, ", siwake.SiwakeKousinsyaCode);
            sqlStatementBuilder.AppendLine("  lway = :p, ", (int)siwake.SiwakeKousinHouhou);
            sqlStatementBuilder.AppendLine("  delf = :p, ", siwake.IsTorikesi ? 1 : 0);
            sqlStatementBuilder.AppendLine("  cprt = :p, ", siwake.IsPrintedChecklist ? 1 : 0);
            sqlStatementBuilder.AppendLine("  fsen = :p, ", (short)siwake.SiwakeHusen);
            sqlStatementBuilder.AppendLine("  smnt = :p, ", siwake.IsSyouninsyaHensyuu ? 1 : 0);
            sqlStatementBuilder.AppendLine("  idm4 = :p, ", siwake.OdcImportRirekiNumber);
            sqlStatementBuilder.AppendLine("  rhei_cd = :p, ", siwake.KarikataHeisyuCode);
            sqlStatementBuilder.AppendLine("  shei_cd = :p, ", siwake.KasikataHeisyuCode);
            sqlStatementBuilder.AppendLine("  rate = :p, ", siwake.Rate);
            sqlStatementBuilder.AppendLine("  gaika = :p, ", siwake.GaikaKingaku);
            sqlStatementBuilder.AppendLine("  gexvl = :p, ", siwake.GaikaTaikaKingaku);
            sqlStatementBuilder.AppendLine("  gzkvl = :p, ", siwake.GaikaZeikomiKingaku);
            sqlStatementBuilder.AppendLine("  smexp = :p, ", siwake.IsExportSaimu ? 1 : 0);
            sqlStatementBuilder.AppendLine("  rdm4 = :p, ", siwake.KarikataUniversalField4Code);
            sqlStatementBuilder.AppendLine("  rdm5 = :p, ", siwake.KarikataUniversalField5Code);
            sqlStatementBuilder.AppendLine("  rdm6 = :p, ", siwake.KarikataUniversalField6Code);
            sqlStatementBuilder.AppendLine("  rdm7 = :p, ", siwake.KarikataUniversalField7Code);
            sqlStatementBuilder.AppendLine("  rdm8 = :p, ", siwake.KarikataUniversalField8Code);
            sqlStatementBuilder.AppendLine("  rdm9 = :p, ", siwake.KarikataUniversalField9Code);
            sqlStatementBuilder.AppendLine("  rdm10 = :p, ", siwake.KarikataUniversalField10Code);
            sqlStatementBuilder.AppendLine("  rdm11 = :p, ", siwake.KarikataUniversalField11Code);
            sqlStatementBuilder.AppendLine("  rdm12 = :p, ", siwake.KarikataUniversalField12Code);
            sqlStatementBuilder.AppendLine("  rdm13 = :p, ", siwake.KarikataUniversalField13Code);
            sqlStatementBuilder.AppendLine("  rdm14 = :p, ", siwake.KarikataUniversalField14Code);
            sqlStatementBuilder.AppendLine("  rdm15 = :p, ", siwake.KarikataUniversalField15Code);
            sqlStatementBuilder.AppendLine("  rdm16 = :p, ", siwake.KarikataUniversalField16Code);
            sqlStatementBuilder.AppendLine("  rdm17 = :p, ", siwake.KarikataUniversalField17Code);
            sqlStatementBuilder.AppendLine("  rdm18 = :p, ", siwake.KarikataUniversalField18Code);
            sqlStatementBuilder.AppendLine("  rdm19 = :p, ", siwake.KarikataUniversalField19Code);
            sqlStatementBuilder.AppendLine("  rdm20 = :p, ", siwake.KarikataUniversalField20Code);
            sqlStatementBuilder.AppendLine("  sdm4 = :p, ", siwake.KasikataUniversalField4Code);
            sqlStatementBuilder.AppendLine("  sdm5 = :p, ", siwake.KasikataUniversalField5Code);
            sqlStatementBuilder.AppendLine("  sdm6 = :p, ", siwake.KasikataUniversalField6Code);
            sqlStatementBuilder.AppendLine("  sdm7 = :p, ", siwake.KasikataUniversalField7Code);
            sqlStatementBuilder.AppendLine("  sdm8 = :p, ", siwake.KasikataUniversalField8Code);
            sqlStatementBuilder.AppendLine("  sdm9 = :p, ", siwake.KasikataUniversalField9Code);
            sqlStatementBuilder.AppendLine("  sdm10 = :p, ", siwake.KasikataUniversalField10Code);
            sqlStatementBuilder.AppendLine("  sdm11 = :p, ", siwake.KasikataUniversalField11Code);
            sqlStatementBuilder.AppendLine("  sdm12 = :p, ", siwake.KasikataUniversalField12Code);
            sqlStatementBuilder.AppendLine("  sdm13 = :p, ", siwake.KasikataUniversalField13Code);
            sqlStatementBuilder.AppendLine("  sdm14 = :p, ", siwake.KasikataUniversalField14Code);
            sqlStatementBuilder.AppendLine("  sdm15 = :p, ", siwake.KasikataUniversalField15Code);
            sqlStatementBuilder.AppendLine("  sdm16 = :p, ", siwake.KasikataUniversalField16Code);
            sqlStatementBuilder.AppendLine("  sdm17 = :p, ", siwake.KasikataUniversalField17Code);
            sqlStatementBuilder.AppendLine("  sdm18 = :p, ", siwake.KasikataUniversalField18Code);
            sqlStatementBuilder.AppendLine("  sdm19 = :p, ", siwake.KasikataUniversalField19Code);
            sqlStatementBuilder.AppendLine("  sdm20 = :p, ", siwake.KasikataUniversalField20Code);
            sqlStatementBuilder.AppendLine("  rsseqai = :p, ", siwake.KarikataAiteSiwakeSeqNumber);
            sqlStatementBuilder.AppendLine("  ssseqai = :p, ", siwake.KasikataAiteSiwakeSeqNumber);
            sqlStatementBuilder.AppendLine("  tekiflg = :p, ", siwake.IsTaisyakubetuTekiyou ? 1 : 0);
            sqlStatementBuilder.AppendLine("  hflg = :p, ", siwake.IsHininSiwake ? 1 : 0);
            sqlStatementBuilder.AppendLine("  swgflg = :p, ", siwake.IsUpdatedLine ? 1 : 0);
            sqlStatementBuilder.AppendLine("  swiflg = :p, ", siwake.IsPrintedSiwakeList ? 1 : 0);
            sqlStatementBuilder.AppendLine("  fsflg = :p, ", (short)siwake.GaikaKanzanSiwakeFlag);
            sqlStatementBuilder.AppendLine("  rkeigen = :p, ", siwake.IsKeigenZeirituKarikata ? 1 : 0);
            sqlStatementBuilder.AppendLine("  skeigen = :p, ", siwake.IsKeigenZeirituKasikata ? 1 : 0);
            sqlStatementBuilder.AppendLine("  zkeigen = :p ", siwake.IsKeigenZeirituZeitaisyouKamoku ? 1 : 0);
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", siwake.Kesn);
            sqlStatementBuilder.AppendLine("  dkei = :p AND ", siwake.Dkei);
            sqlStatementBuilder.AppendLine("  dseq = :p AND ", siwake.DenpyouSequenceNumber);
            sqlStatementBuilder.AppendLine("  sseq = :p ", siwake.SiwakeSequenceNumber);
            this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters());

            // 既存仕訳への新規コメントの追加処理であるため付番する
            this.InsertSyouninComment(siwake, denpyouType, true);
        }

        /// <summary>
        /// 仕訳取消
        /// </summary>
        /// <param name="siwake"></param>
        /// <param name="denpyouType"></param>
        public virtual void UpdateLastUpdateInfomationAndTorikesiFlag(Siwake siwake, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder("UPDATE ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("SET ");
            sqlStatementBuilder.AppendLine("  lmod = :p, ", siwake.SiwakeKousinbi);
            sqlStatementBuilder.AppendLine("  ltim = :p, ", siwake.SiwakeKousinZikan);
            sqlStatementBuilder.AppendLine("  lusr = :p, ", siwake.SiwakeKousinsyaCode);
            sqlStatementBuilder.AppendLine("  lway = :p, ", (int)siwake.SiwakeKousinHouhou);
            sqlStatementBuilder.AppendLine("  delf = :p ", siwake.IsTorikesi ? 1 : 0);
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", siwake.Kesn);
            sqlStatementBuilder.AppendLine("  dkei = :p AND ", siwake.Dkei);
            sqlStatementBuilder.AppendLine("  dseq = :p AND ", siwake.DenpyouSequenceNumber);
            sqlStatementBuilder.AppendLine("  sseq = :p ", siwake.SiwakeSequenceNumber);
            this.dbc.Execute(sqlStatementBuilder.GetSqlStatement(), sqlStatementBuilder.GetSqlParameters());
        }

        /// <summary>
        /// 取消フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsTorikesi(Siwake siwake, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  delf = :p ", siwake.IsTorikesi ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p AND ", siwake.Kesn);
            updateQuery.AppendLine("  dkei = :p AND ", siwake.Dkei);
            updateQuery.AppendLine("  dseq = :p AND ", siwake.DenpyouSequenceNumber);
            updateQuery.AppendLine("  delf = :p ", siwake.IsTorikesi ? 0 : 1);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 否認仕訳フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsHininSiwake(Siwake siwake, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  hflg = :p ", siwake.IsHininSiwake ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", siwake.Kesn);
            updateQuery.AppendLine("  AND dkei = :p ", siwake.Dkei);
            updateQuery.AppendLine("  AND dseq = :p ", siwake.DenpyouSequenceNumber);
            updateQuery.AppendLine("  AND sseq = :p ", siwake.SiwakeSequenceNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 出力フラグを更新します
        /// </summary>
        /// <param name="kesn">内部決算期</param>
        /// <param name="dkei">経過月</param>
        /// <param name="dseq">伝票SEQNo.</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsPrintedChecklist(int kesn, int dkei, int dseq, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  cprt = 1 ");
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", kesn);
            updateQuery.AppendLine("  AND dkei = :p ", dkei);
            updateQuery.AppendLine("  AND dseq = :p ", dseq);
            updateQuery.AppendLine("  AND delf = 0 ");
            updateQuery.AppendLine("  AND cprt <> 1 ");
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        /// <summary>
        /// 出力フラグ、行変更フラグ、仕訳一覧フラグを更新します
        /// </summary>
        /// <param name="siwake">仕訳</param>
        /// <param name="denpyouType">伝票形式</param>
        public virtual void UpdateIsPrintedChecklistAndIsUpdatedLineAndIsPrintedSiwakeList(Siwake siwake, DenpyouType denpyouType)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE ");
            updateQuery.AppendFormatAndLine("  {0} ", this.GetTableName(denpyouType));
            updateQuery.AppendLine("SET ");
            updateQuery.AppendLine("  cprt = 1 ");
            updateQuery.AppendLine("  , swgflg = 0 ");
            updateQuery.AppendLine("  , swiflg = 1 ");
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("  kesn = :p ", siwake.Kesn);
            updateQuery.AppendLine("  AND dkei = :p ", siwake.Dkei);
            updateQuery.AppendLine("  AND dseq = :p ", siwake.DenpyouSequenceNumber);
            updateQuery.AppendLine("  AND lmod = :p ", siwake.SiwakeKousinbi);
            updateQuery.AppendLine("  AND ltim = :p ", siwake.SiwakeKousinZikan);
            updateQuery.AppendLine("  AND sseq = :p ", siwake.SiwakeSequenceNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        public virtual IList<Siwake> FindYuukouSiwakeByKesnAndDkeiAndDseqOrderByDlin(Denpyou denpyou, DenpyouType denpyouType)
        {
            var sqlStatementBuilder = new SqlStatementBuilder("SELECT ");
            sqlStatementBuilder.AppendLine("  kesn,    dkei,    dseq,    sseq,    pseq,    pflg,    bkbn,  grno,   dcpg,   dlin, ");
            sqlStatementBuilder.AppendLine("  dflg,    rbmn,    rtor,    rkmk,    reda,    rkoj,    rkos,  rprj,   rseg,   rdm1, ");
            sqlStatementBuilder.AppendLine("  rdm2,    rdm3,    rtky,    rtno,    rimg,    sbmn,    stor,  skmk,   seda,   skoj, ");
            sqlStatementBuilder.AppendLine("  skos,    sprj,    sseg,    sdm1,    sdm2,    sdm3,    stky,  stno,   simg,   tflg, ");
            sqlStatementBuilder.AppendLine("  exvl,    zkvl,    valu,    zkmk,    zrit,    zzkb,    zgyo,  zsre,   rrit,   srit, ");
            sqlStatementBuilder.AppendLine("  rzkb,    rgyo,    rsre,    szkb,    sgyo,    ssre,    ifri,  symd,   skbn,   skiz, ");
            sqlStatementBuilder.AppendLine("  uymd,    ukbn,    ukiz,    sexp,    dkec,    pcsw,    upsw,  zrsw,   gpcd,   fmod, ");
            sqlStatementBuilder.AppendLine("  ftim,    fusr,    fway,    lmod,    ltim,    lusr,    lway,  delf,   cprt,   fsen, ");
            sqlStatementBuilder.AppendLine("  smnt,    idm4,    rhei_cd, shei_cd, rate,    gaika,   gexvl, gzkvl,  smexp,  rdm4, ");
            sqlStatementBuilder.AppendLine("  rdm5,    rdm6,    rdm7,    rdm8,    rdm9,    rdm10,   rdm11, rdm12,  rdm13,  rdm14, ");
            sqlStatementBuilder.AppendLine("  rdm15,   rdm16,   rdm17,   rdm18,   rdm19,   rdm20,   sdm4,  sdm5,   sdm6,   sdm7, ");
            sqlStatementBuilder.AppendLine("  sdm8,    sdm9,    sdm10,   sdm11,   sdm12,   sdm13,   sdm14, sdm15,  sdm16,  sdm17, ");
            sqlStatementBuilder.AppendLine("  sdm18,   sdm19,   sdm20,   rsseqai, ssseqai, tekiflg, hflg,  swgflg, swiflg, fsflg, ");
            sqlStatementBuilder.AppendLine("  rkeigen, skeigen, zkeigen ");
            sqlStatementBuilder.AppendLine("FROM ");
            sqlStatementBuilder.AppendLine(this.GetTableName(denpyouType));
            sqlStatementBuilder.AppendLine("WHERE ");
            sqlStatementBuilder.AppendLine("  kesn = :p AND ", denpyou.Kesn);
            sqlStatementBuilder.AppendLine("  dkei = :p AND ", denpyou.Dkei);
            sqlStatementBuilder.AppendLine("  dseq = :p AND ", denpyou.DenpyouSequenceNumber);
            sqlStatementBuilder.AppendLine("  delf = 0 ");
            sqlStatementBuilder.AppendLine("ORDER BY dlin");

            var siwakeList = this.dbc.QueryForList(
                sqlStatementBuilder.GetSqlStatement(),
                (values, no) =>
                {
                    var kesn = (int)(short)values[0];
                    var dkei = (int)(short)values[1];
                    var dseq = (int)values[2];
                    var sseq = (int)values[3];
                    var row = new Siwake(kesn, dkei, dseq, sseq);
                    row.ParentChildSiwakeSequenceNumber = (int)values[4]; // 親仕訳seqno.
                    row.ParentChildFlag = (SiwakeParentChildRelated)(short)values[5]; // 親子フラグ
                    row.BunriKubun = (BunriKubun)(short)values[6]; // 分離区分
                    row.GroupNumber = DbNullConverter.ToNullableInt(values[7]) ?? 0; // グループ番号
                    // row.Dcpg = DbNullConverter.ToNullableInt(values[8]); // 伝票頁
                    row.LineNo = DbNullConverter.ToNullableInt(values[9]) ?? 0; // 行番号
                    row.SiwakeTaisyakuZokusei = (SiwakeTaisyakuZokusei)(short)values[10]; // 貸借属性
                    row.KarikataBumonCode = DbNullConverter.ToString(values[11], null); // 借方部門
                    row.KarikataTorihikisakiCode = DbNullConverter.ToString(values[12], null); // 借方取引先
                    row.KarikataKamokuCode = DbNullConverter.ToString(values[13], null); // 借方科目
                    row.KarikataEdabanCode = DbNullConverter.ToString(values[14], null); // 借方枝番
                    row.KarikataKouziCode = DbNullConverter.ToString(values[15], null); // 借方工事ｎｏ
                    row.KarikataKousyuCode = DbNullConverter.ToString(values[16], null); // 借方工種ｎｏ
                    row.KarikataProjectCode = DbNullConverter.ToString(values[17], null); // 借方ﾌﾟﾛｼﾞｪｸﾄ
                    row.KarikataSegmentCode = DbNullConverter.ToString(values[18], null); // 借方セグメント
                    row.KarikataUniversalField1Code = DbNullConverter.ToString(values[19], null); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.KarikataUniversalField2Code = DbNullConverter.ToString(values[20], null); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.KarikataUniversalField3Code = DbNullConverter.ToString(values[21], null); // "借方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.KarikataTekiyou = DbNullConverter.ToString(values[22], null); // 借方摘要
                    row.KarikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[23]); // 借方摘要ｺｰﾄﾞ
                    row.KarikataImageNumber = (int)values[24]; // 借方ｲﾒｰｼﾞno.
                    row.KasikataBumonCode = DbNullConverter.ToString(values[25], null); // 貸方部門
                    row.KasikataTorihikisakiCode = DbNullConverter.ToString(values[26], null); // 貸方取引先
                    row.KasikataKamokuCode = DbNullConverter.ToString(values[27], null); // 貸方科目
                    row.KasikataEdabanCode = DbNullConverter.ToString(values[28], null); // 貸方枝番
                    row.KasikataKouziCode = DbNullConverter.ToString(values[29], null); // 貸方工事ｎｏ
                    row.KasikataKousyuCode = DbNullConverter.ToString(values[30], null); // 貸方工種ｎｏ
                    row.KasikataProjectCode = DbNullConverter.ToString(values[31], null); // 貸方ﾌﾟﾛｼﾞｪｸﾄ
                    row.KasikataSegmentCode = DbNullConverter.ToString(values[32], null); // 貸方セグメント
                    row.KasikataUniversalField1Code = DbNullConverter.ToString(values[33], null); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.KasikataUniversalField2Code = DbNullConverter.ToString(values[34], null); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.KasikataUniversalField3Code = DbNullConverter.ToString(values[35], null); // "貸方 ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.KasikataTekiyou = DbNullConverter.ToString(values[36], null); // 貸方摘要
                    row.KasikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[37]); // 貸方摘要ｺｰﾄﾞ
                    row.KasikataImageNumber = (int)values[38]; // 貸方ｲﾒｰｼﾞno.
                    row.IsInputTaika = (short)values[39] == 1; // 対価入力ﾌﾗｸﾞ
                    row.TaikaKingaku = (decimal)values[40]; // 対価金額
                    row.ZeikomiKingaku = (decimal)values[41]; // 税込金額
                    row.Kingaku = (decimal)values[42]; // 金額
                    row.ZeitaisyouKamokuCode = DbNullConverter.ToString(values[43], null); // 税対象科目 科目
                    row.ZeitaisyouKamokuZeiritu = DBNull.Value.Equals(values[44]) ? (Percentage?)null : new Percentage((decimal)((DbNullConverter.ToNullableInt(values[44]) / 10000) ?? 0)); // 税対象科目 税率
                    row.ZeitaisyouKamokuKazeiKubun = (KazeiKubun)(short)values[45]; // 税対象科目 課税区分
                    row.ZeitaisyouKamokuGyousyuKubun = (GyousyuKubun)(short)values[46]; // 税対象科目 業種区分
                    row.ZeitaisyouKamokuSiireKubun = (SiwakeSiireKubun)(short)values[47]; // 税対象科目 仕入区分
                    row.KarikataZeiritu = DBNull.Value.Equals(values[48]) ? (Percentage?)null : new Percentage((decimal)((DbNullConverter.ToNullableInt(values[48]) / 10000) ?? 0)); // 借方税率
                    row.KasikataZeiritu = DBNull.Value.Equals(values[49]) ? (Percentage?)null : new Percentage((decimal)((DbNullConverter.ToNullableInt(values[49]) / 10000) ?? 0)); // 貸方税率
                    row.KarikataKazeiKubun = (KazeiKubun)(short)values[50]; // 借方課税区分
                    row.KarikataGyousyuKubun = (GyousyuKubun)(short)values[51]; // 借方業種区分
                    row.KarikataSiireKubun = (SiwakeSiireKubun)(short)values[52]; // 借方仕入区分
                    row.KasikataKazeiKubun = (KazeiKubun)(short)values[53]; // 貸方課税区分
                    row.KasikataGyousyuKubun = (GyousyuKubun)(short)values[54]; // 貸方業種区分
                    row.KasikataSiireKubun = (SiwakeSiireKubun)(short)values[55]; // 貸方仕入区分
                    row.IkkatuZeinukiSiwakeFlag = (IkkatuZeinukiSiwakeFlag)(short)values[56]; // "一括税抜仕訳 フラグ"
                    row.Siharaibi = (int)values[57]; // 支払日
                    row.SiharaiKubun = (int?)DbNullConverter.ToNullableShort(values[58]); // 支払区分
                    row.SiharaiKizitu = (int)values[59]; // 支払期日
                    row.Kaisyuubi = (int)values[60]; // 回収日
                    row.NyuukinKubun = (int?)DbNullConverter.ToNullableShort(values[61]); // 入金区分
                    row.KaisyuuKizitu = (int)values[62]; // 回収期日
                    row.IsExportSiharai = (short)values[63] == 1; // 支払exportﾌﾗｸﾞ
                    row.KesikomiCode = DbNullConverter.ToString(values[64], null); // 消込ｺｰﾄﾞ
                    row.IsKesikomiTyuusyutu = (short)values[65] == 1; // 消込抽出ﾌﾗｸﾞ
                    row.IsKesikomiUpdate = (short)values[66] == 1; // 消込更新ﾌﾗｸﾞ
                    row.IsKesikomiZero = (short)values[67] == 1; // 消込ゼロﾌﾗｸﾞ
                    row.KesikomiGroupCode = DbNullConverter.ToString(values[68], null); // 消込ｸﾞﾙｰﾌﾟｺｰﾄﾞ
                    row.SiwakeSakuseibi = (int)values[69]; // 入力年月日
                    row.SiwakeSakuseiZikan = (int)values[70]; // 入力時分秒
                    row.SiwakeSakuseisyaCode = (int)values[71]; // 入力者
                    row.SiwakeSakuseiHouhou = (DenpyouSiwakeWayToCreate)values[72]; // 入力手段
                    row.SiwakeKousinbi = (int)values[73]; // 最終変更年月日
                    row.SiwakeKousinZikan = (int)values[74]; // 最終変更時分秒
                    row.SiwakeKousinsyaCode = (int)values[75]; // 最終変更者
                    row.SiwakeKousinHouhou = (DenpyouSiwakeWayToCreate)values[76]; // 最終変更手段
                    row.IsTorikesi = (short)values[77] == 1; // 削除ﾌﾗｸﾞ
                    row.IsPrintedChecklist = (short)values[78] == 1; // 出力ﾌﾗｸﾞ
                    row.SiwakeHusen = (SiwakeHusen)(short)values[79]; // 付箋番号
                    row.IsSyouninsyaHensyuu = (short)values[80] == 1; // 承認者編集
                    row.OdcImportRirekiNumber = (int)values[81]; // "odcｲﾝﾎﾟｰﾄ履歴番号"
                    row.KarikataHeisyuCode = DbNullConverter.ToString(values[82], null); // 借方通貨コード
                    row.KasikataHeisyuCode = DbNullConverter.ToString(values[83], null); // 貸方通貨コード
                    row.Rate = (decimal)values[84]; // レート
                    row.GaikaKingaku = (decimal)values[85]; // 外貨金額
                    row.GaikaTaikaKingaku = (decimal)values[86]; // 外貨対価
                    row.GaikaZeikomiKingaku = (decimal)values[87]; // 外貨税込金額
                    row.IsExportSaimu = (int)values[88] == 1; // 債務支払export
                    row.KarikataUniversalField4Code = DbNullConverter.ToString(values[89], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.KarikataUniversalField5Code = DbNullConverter.ToString(values[90], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.KarikataUniversalField6Code = DbNullConverter.ToString(values[91], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.KarikataUniversalField7Code = DbNullConverter.ToString(values[92], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.KarikataUniversalField8Code = DbNullConverter.ToString(values[93], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.KarikataUniversalField9Code = DbNullConverter.ToString(values[94], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.KarikataUniversalField10Code = DbNullConverter.ToString(values[95], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.KarikataUniversalField11Code = DbNullConverter.ToString(values[96], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.KarikataUniversalField12Code = DbNullConverter.ToString(values[97], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.KarikataUniversalField13Code = DbNullConverter.ToString(values[98], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.KarikataUniversalField14Code = DbNullConverter.ToString(values[99], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.KarikataUniversalField15Code = DbNullConverter.ToString(values[100], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.KarikataUniversalField16Code = DbNullConverter.ToString(values[101], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.KarikataUniversalField17Code = DbNullConverter.ToString(values[102], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.KarikataUniversalField18Code = DbNullConverter.ToString(values[103], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.KarikataUniversalField19Code = DbNullConverter.ToString(values[104], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.KarikataUniversalField20Code = DbNullConverter.ToString(values[105], null); // "借方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.KasikataUniversalField4Code = DbNullConverter.ToString(values[106], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.KasikataUniversalField5Code = DbNullConverter.ToString(values[107], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.KasikataUniversalField6Code = DbNullConverter.ToString(values[108], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.KasikataUniversalField7Code = DbNullConverter.ToString(values[109], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.KasikataUniversalField8Code = DbNullConverter.ToString(values[110], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.KasikataUniversalField9Code = DbNullConverter.ToString(values[111], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.KasikataUniversalField10Code = DbNullConverter.ToString(values[112], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.KasikataUniversalField11Code = DbNullConverter.ToString(values[113], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.KasikataUniversalField12Code = DbNullConverter.ToString(values[114], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.KasikataUniversalField13Code = DbNullConverter.ToString(values[115], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.KasikataUniversalField14Code = DbNullConverter.ToString(values[116], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.KasikataUniversalField15Code = DbNullConverter.ToString(values[117], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.KasikataUniversalField16Code = DbNullConverter.ToString(values[118], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.KasikataUniversalField17Code = DbNullConverter.ToString(values[119], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.KasikataUniversalField18Code = DbNullConverter.ToString(values[120], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.KasikataUniversalField19Code = DbNullConverter.ToString(values[121], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.KasikataUniversalField20Code = DbNullConverter.ToString(values[122], null); // "貸方 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.KarikataAiteSiwakeSeqNumber = (int)values[123]; // 借方相手仕訳seqno.
                    row.KasikataAiteSiwakeSeqNumber = (int)values[124]; // 貸方相手仕訳seqno.
                    row.IsTaisyakubetuTekiyou = (short)values[125] == 1; // 貸借摘要フラグ
                    row.IsHininSiwake = (short)values[126] == 1; // 否認状況
                    row.IsUpdatedLine = (short)values[127] == 1; // 行変更フラグ
                    row.IsPrintedSiwakeList = (short)values[128] == 1; // 仕訳一覧フラグ
                    row.GaikaKanzanSiwakeFlag = (GaikaKanzanSiwakeFlag)(short)values[129]; // 外貨換算仕訳フラグ
                    row.IsKeigenZeirituKarikata = (short)values[130] == 1; // 借方軽減税率区分
                    row.IsKeigenZeirituKasikata = (short)values[131] == 1; // 貸方軽減税率区分
                    row.IsKeigenZeirituZeitaisyouKamoku = (short)values[132] == 1; // 税対象科目  軽減税率区分

                    return row;
                },
                () => new List<Siwake>(),
                sqlStatementBuilder.GetSqlParameters());

            foreach (var siwake in siwakeList)
            {
                siwake.SyouninCommentList = this.syouninCommentRepository.FindByKesnAndKeikAndDseqAndSseqOrderByCseqDesc(
                    siwake.Kesn,
                    siwake.Dkei,
                    siwake.DenpyouSequenceNumber,
                    siwake.SiwakeSequenceNumber,
                    denpyouType);
            }

            return siwakeList;
        }

        public virtual InsertSqlStatementBuilder CreateSiwakeInsertSqlStatementBuilder(Siwake siwake, string tableName)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder(tableName);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kesn", siwake.Kesn);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkei", siwake.Dkei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dseq", siwake.DenpyouSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sseq", siwake.SiwakeSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pseq", siwake.ParentChildSiwakeSequenceNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pflg", (short)siwake.ParentChildFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("bkbn", (short)siwake.BunriKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("grno", siwake.GroupNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dcpg", 1);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dlin", siwake.LineNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dflg", (short)siwake.SiwakeTaisyakuZokusei);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rbmn", siwake.KarikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtor", siwake.KarikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkmk", siwake.KarikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("reda", siwake.KarikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkoj", siwake.KarikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkos", siwake.KarikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rprj", siwake.KarikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rseg", siwake.KarikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm1", siwake.KarikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm2", siwake.KarikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm3", siwake.KarikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtky", siwake.KarikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtno", siwake.KarikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rimg", siwake.KarikataImageNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sbmn", siwake.KasikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stor", siwake.KasikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skmk", siwake.KasikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("seda", siwake.KasikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skoj", siwake.KasikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skos", siwake.KasikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sprj", siwake.KasikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sseg", siwake.KasikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm1", siwake.KasikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm2", siwake.KasikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm3", siwake.KasikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stky", siwake.KasikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stno", siwake.KasikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("simg", siwake.KasikataImageNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tflg", siwake.IsInputTaika ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("exvl", siwake.TaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zkvl", siwake.ZeikomiKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("valu", siwake.Kingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zkmk", siwake.ZeitaisyouKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zrit", (int?)(siwake.ZeitaisyouKamokuZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("zzkb", (short)siwake.ZeitaisyouKamokuKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zgyo", (short)siwake.ZeitaisyouKamokuGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zsre", (short)siwake.ZeitaisyouKamokuSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rrit", (int?)(siwake.KarikataZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("srit", (int?)(siwake.KasikataZeiritu?.GetValue() * 10000));
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzkb", (short)siwake.KarikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgyo", (short)siwake.KarikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsre", (short)siwake.KarikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szkb", (short)siwake.KasikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgyo", (short)siwake.KasikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssre", (short)siwake.KasikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ifri", (short)siwake.IkkatuZeinukiSiwakeFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("symd", siwake.Siharaibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skbn", siwake.SiharaiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skiz", siwake.SiharaiKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("uymd", siwake.Kaisyuubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ukbn", siwake.NyuukinKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ukiz", siwake.KaisyuuKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sexp", siwake.IsExportSiharai ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dkec", siwake.KesikomiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pcsw", siwake.IsKesikomiTyuusyutu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("upsw", siwake.IsKesikomiUpdate ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zrsw", siwake.IsKesikomiZero ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gpcd", siwake.KesikomiGroupCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fmod", siwake.SiwakeSakuseibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ftim", siwake.SiwakeSakuseiZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fusr", siwake.SiwakeSakuseisyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fway", (int)siwake.SiwakeSakuseiHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", siwake.SiwakeKousinbi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", siwake.SiwakeKousinZikan);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", siwake.SiwakeKousinsyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lway", (int)siwake.SiwakeKousinHouhou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("delf", siwake.IsTorikesi ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cprt", siwake.IsPrintedChecklist ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fsen", (short)siwake.SiwakeHusen);
            insertSqlStatementBuilder.AppendColumnNameAndValue("smnt", siwake.IsSyouninsyaHensyuu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm4", siwake.OdcImportRirekiNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rhei_cd", siwake.KarikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("shei_cd", siwake.KasikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rate", siwake.Rate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gaika", siwake.GaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gexvl", siwake.GaikaTaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gzkvl", siwake.GaikaZeikomiKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("smexp", siwake.IsExportSaimu ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm4", siwake.KarikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm5", siwake.KarikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm6", siwake.KarikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm7", siwake.KarikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm8", siwake.KarikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm9", siwake.KarikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm10", siwake.KarikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm11", siwake.KarikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm12", siwake.KarikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm13", siwake.KarikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm14", siwake.KarikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm15", siwake.KarikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm16", siwake.KarikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm17", siwake.KarikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm18", siwake.KarikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm19", siwake.KarikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm20", siwake.KarikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm4", siwake.KasikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm5", siwake.KasikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm6", siwake.KasikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm7", siwake.KasikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm8", siwake.KasikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm9", siwake.KasikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm10", siwake.KasikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm11", siwake.KasikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm12", siwake.KasikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm13", siwake.KasikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm14", siwake.KasikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm15", siwake.KasikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm16", siwake.KasikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm17", siwake.KasikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm18", siwake.KasikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm19", siwake.KasikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm20", siwake.KasikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsseqai", siwake.KarikataAiteSiwakeSeqNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssseqai", siwake.KasikataAiteSiwakeSeqNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tekiflg", siwake.IsTaisyakubetuTekiyou ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("hflg", siwake.IsHininSiwake ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("swgflg", siwake.IsUpdatedLine ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("swiflg", siwake.IsPrintedSiwakeList ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("fsflg", (short)siwake.GaikaKanzanSiwakeFlag);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkeigen", siwake.IsKeigenZeirituKarikata ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skeigen", siwake.IsKeigenZeirituKasikata ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("zkeigen", siwake.IsKeigenZeirituZeitaisyouKamoku ? 1 : 0);
            return insertSqlStatementBuilder;
        }

        private void InsertSyouninComment(Siwake siwake, DenpyouType denpyouType) =>
            siwake.SyouninCommentList.ForEachIfNotNull(syouninComment => this.syouninCommentRepository.Insert(syouninComment, denpyouType));

        private void InsertSyouninComment(Siwake siwake, DenpyouType denpyouType, bool isHubanCommentSequenceNumber) =>
            siwake.SyouninCommentList.ForEachIfNotNull(syouninComment => this.syouninCommentRepository.Insert(syouninComment, denpyouType, isHubanCommentSequenceNumber));

        private string GetTableName(DenpyouType denpyouType)
        {
            switch (denpyouType)
            {
                case DenpyouType.TuuzyouDenpyou:
                    return TuuzyouSiwakeTableName;
                case DenpyouType.Busyo:
                    return BusyoSiwakeTableName;
                case DenpyouType.Sokyuu:
                default:
                    return SokyuuSiwakeTableName;
            }
        }
    }
}
