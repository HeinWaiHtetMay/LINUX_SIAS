﻿namespace Icsp.Open21.Persistence.DenpyouModel
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class ZidouhubanDenpyouNoRepository : IZidouhubanDenpyouNoRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual ZidouhubanDenpyouNo FindByKesnAndKeikAndFgno(int kesn, int keik, int fgno) =>
            this.dbc.QueryForObject(
                "SELECT dcno, fcno, cdm1, cdm2, cdm3, cdm4, idm1, idm2, idm3, idm4 " +
                "FROM jfdno WHERE kesn = :p AND keik = :p AND fgno = :p ",
                (values, no) =>
                {
                    var row = new ZidouhubanDenpyouNo(kesn, keik, fgno)
                    {
                        Dcno = (int)values[0],
                        Fcno = (int)values[1],
                        ////Cdm1 = DbNullConverter.ToString(values[2], null),
                        ////Cdm2 = DbNullConverter.ToString(values[3], null),
                        ////Cdm3 = DbNullConverter.ToString(values[4], null),
                        ////Cdm4 = DbNullConverter.ToString(values[5], null),
                        ////Idm1 = (int)values[6],
                        ////Idm2 = (int)values[7],
                        ////Idm3 = (int)values[8],
                        ////Idm4 = (int)values[9]
                    };
                    return row;
                },
                kesn,
                keik,
                fgno);

        public virtual int UpdateDcno(ZidouhubanDenpyouNo zidohubanDenpyouNo) =>
            this.dbc.Execute(
                "UPDATE jfdno SET dcno = :p WHERE kesn = :p and keik = :p AND fgno = :p ",
                new object[] { zidohubanDenpyouNo.Dcno, zidohubanDenpyouNo.Kesn, zidohubanDenpyouNo.Keik, zidohubanDenpyouNo.Fgno });
    }
}
