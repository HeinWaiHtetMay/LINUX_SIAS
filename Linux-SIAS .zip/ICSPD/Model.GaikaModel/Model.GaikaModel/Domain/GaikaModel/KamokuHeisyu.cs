﻿namespace Icsp.Open21.Domain.GaikaModel
{
    public class KamokuHeisyu
    {
        public KamokuHeisyu(int kesn, string kicd, string heisyuCode)
        {
            this.Kesn = kesn;
            this.Kicd = kicd;
            this.HeisyuCode = heisyuCode;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 科目内部コード（カラム名：kicd）
        /// </summary>
        public string Kicd { get; private set; }

        /// <summary>
        /// 通貨コード（カラム名：hei_cd）
        /// </summary>
        public string HeisyuCode { get; private set; }

        /// <summary>
        /// 幣種区分（カラム名：heikbn）
        /// </summary>
        public bool IsDefault { get; set; }
        #endregion
    }
}
