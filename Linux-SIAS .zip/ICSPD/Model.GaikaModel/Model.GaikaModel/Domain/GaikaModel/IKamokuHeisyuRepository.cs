﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.GaikaModel
{
    public interface IKamokuHeisyuRepository
    {
        IList<KamokuHeisyu> FindByKesnOrderByKicdAndHeisyuCode(int kesn);

        IList<KamokuHeisyu> FindByKesnAndKicdOrderByHeisyuCode(int kesn, string kicd);
    }
}