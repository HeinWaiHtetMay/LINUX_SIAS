﻿namespace Icsp.Open21.Persistence.GaikaModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.GaikaModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class KamokuHeisyuRepository : IKamokuHeisyuRepository
    {
        private static readonly string SelectAndFromStatement = "SELECT kesn, kicd, hei_cd, heikbn, idm1, idm2, cdm1, cdm2 FROM kmkhei ";

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<KamokuHeisyu> FindByKesnOrderByKicdAndHeisyuCode(int kesn)
        {
            return this.dbc.QueryForList(
                SelectAndFromStatement + "WHERE kesn = :p ORDER BY kicd, hei_cd ",
                (values, no) =>
                {
                    return this.MapRow(values, no);
                },
                () => new List<KamokuHeisyu>(),
                kesn);
        }

        public virtual IList<KamokuHeisyu> FindByKesnAndKicdOrderByHeisyuCode(int kesn, string kicd)
        {
            return this.dbc.QueryForList(
                SelectAndFromStatement + "WHERE kesn = :p AND kicd = :p ORDER BY hei_cd ",
                (values, no) =>
                {
                    return this.MapRow(values, no);
                },
                () => new List<KamokuHeisyu>(),
                kesn,
                kicd);
        }

        private KamokuHeisyu MapRow(object[] values, int no)
        {
            return new KamokuHeisyu(
                (int)(short)values[0],
                values[1].ToString(),
                values[2].ToString())
            {
                IsDefault = (short)values[3] == 1, // 幣種区分
            };
        }
    }
}
