﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Icsp.Framework.Core.Serialization;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputHukusyaOption
    {
        public bool CopyDenpyouHizuke { get; set; }

        public DenpyouInputDenpyouNoHukusyaType CopyDenpyouNo { get; set; }

        public bool CopyKihyoubi { get; set; }

        public bool CopyKihyousya { get; set; }

        public bool CopyKihyouBumon { get; set; }

        public bool CopySyouninGroup { get; set; }

        public bool CopyDenpyouTaba { get; set; }

        public bool CopyHeaderField1 { get; set; }

        public bool CopyHeaderField2 { get; set; }

        public bool CopyHeaderField3 { get; set; }

        public bool CopyHeaderField4 { get; set; }

        public bool CopyHeaderField5 { get; set; }

        public bool CopyHeaderField6 { get; set; }

        public bool CopyHeaderField7 { get; set; }

        public bool CopyHeaderField8 { get; set; }

        public bool CopyHeaderField9 { get; set; }

        public bool CopyHeaderField10 { get; set; }

        /// <summary>
        /// 2仕訳目以降で共通摘要を複写
        /// </summary>
        public DenpyouInputSiwakeHukusyaType CopyCommonTekiyou { get; set; }

        /// <summary>
        /// 1仕訳目での複写有無
        /// </summary>
        public bool CopyFromSaisyuSiwakeToSentouSiwake { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataKamoku { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataBumon { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataTorihikisaki { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataEdaban { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField1 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField2 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField3 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField4 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField5 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField6 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField7 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField8 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField9 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField10 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField11 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField12 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField13 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField14 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField15 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField16 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField17 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField18 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField19 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataUniversalField20 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataProject { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataSegment { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataKouzi { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataKousyu { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataTekiyou { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKarikataTekiyouCode { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataKamoku { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataBumon { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataTorihikisaki { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataEdaban { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField1 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField2 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField3 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField4 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField5 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField6 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField7 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField8 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField9 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField10 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField11 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField12 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField13 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField14 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField15 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField16 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField17 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField18 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField19 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataUniversalField20 { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataProject { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataSegment { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataKouzi { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataKousyu { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataTekiyou { get; set; }

        public DenpyouInputSiwakeHukusyaType CopyKasikataTekiyouCode { get; set; }

        /// <summary>
        /// 複写タイプを取得
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public DenpyouInputSiwakeHukusyaType GetSiwaleItemHukusyaOptionType(DenpyouInputItemType denpyouInputItemType)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.CommonTekiyou:
                    return this.CopyCommonTekiyou;
                case DenpyouInputItemType.KarikataKamoku:
                    return this.CopyKarikataKamoku;
                case DenpyouInputItemType.KarikataBumon:
                    return this.CopyKarikataBumon;
                case DenpyouInputItemType.KarikataTorihikisaki:
                    return this.CopyKarikataTorihikisaki;
                case DenpyouInputItemType.KarikataEdaban:
                    return this.CopyKarikataEdaban;
                case DenpyouInputItemType.KarikataUniversalField1:
                    return this.CopyKarikataUniversalField1;
                case DenpyouInputItemType.KarikataUniversalField2:
                    return this.CopyKarikataUniversalField2;
                case DenpyouInputItemType.KarikataUniversalField3:
                    return this.CopyKarikataUniversalField3;
                case DenpyouInputItemType.KarikataUniversalField4:
                    return this.CopyKarikataUniversalField4;
                case DenpyouInputItemType.KarikataUniversalField5:
                    return this.CopyKarikataUniversalField5;
                case DenpyouInputItemType.KarikataUniversalField6:
                    return this.CopyKarikataUniversalField6;
                case DenpyouInputItemType.KarikataUniversalField7:
                    return this.CopyKarikataUniversalField7;
                case DenpyouInputItemType.KarikataUniversalField8:
                    return this.CopyKarikataUniversalField8;
                case DenpyouInputItemType.KarikataUniversalField9:
                    return this.CopyKarikataUniversalField9;
                case DenpyouInputItemType.KarikataUniversalField10:
                    return this.CopyKarikataUniversalField10;
                case DenpyouInputItemType.KarikataUniversalField11:
                    return this.CopyKarikataUniversalField11;
                case DenpyouInputItemType.KarikataUniversalField12:
                    return this.CopyKarikataUniversalField12;
                case DenpyouInputItemType.KarikataUniversalField13:
                    return this.CopyKarikataUniversalField13;
                case DenpyouInputItemType.KarikataUniversalField14:
                    return this.CopyKarikataUniversalField14;
                case DenpyouInputItemType.KarikataUniversalField15:
                    return this.CopyKarikataUniversalField15;
                case DenpyouInputItemType.KarikataUniversalField16:
                    return this.CopyKarikataUniversalField16;
                case DenpyouInputItemType.KarikataUniversalField17:
                    return this.CopyKarikataUniversalField17;
                case DenpyouInputItemType.KarikataUniversalField18:
                    return this.CopyKarikataUniversalField18;
                case DenpyouInputItemType.KarikataUniversalField19:
                    return this.CopyKarikataUniversalField19;
                case DenpyouInputItemType.KarikataUniversalField20:
                    return this.CopyKarikataUniversalField20;
                case DenpyouInputItemType.KarikataProject:
                    return this.CopyKarikataProject;
                case DenpyouInputItemType.KarikataSegment:
                    return this.CopyKarikataSegment;
                case DenpyouInputItemType.KarikataKouzi:
                    return this.CopyKarikataKouzi;
                case DenpyouInputItemType.KarikataKousyu:
                    return this.CopyKarikataKousyu;
                case DenpyouInputItemType.KarikataTekiyou:
                    return this.CopyKarikataTekiyou;
                case DenpyouInputItemType.KarikataZiyuuTekiyou:
                    return this.CopyKarikataTekiyouCode;
                case DenpyouInputItemType.KasikataKamoku:
                    return this.CopyKasikataKamoku;
                case DenpyouInputItemType.KasikataBumon:
                    return this.CopyKasikataBumon;
                case DenpyouInputItemType.KasikataTorihikisaki:
                    return this.CopyKasikataTorihikisaki;
                case DenpyouInputItemType.KasikataEdaban:
                    return this.CopyKasikataEdaban;
                case DenpyouInputItemType.KasikataUniversalField1:
                    return this.CopyKasikataUniversalField1;
                case DenpyouInputItemType.KasikataUniversalField2:
                    return this.CopyKasikataUniversalField2;
                case DenpyouInputItemType.KasikataUniversalField3:
                    return this.CopyKasikataUniversalField3;
                case DenpyouInputItemType.KasikataUniversalField4:
                    return this.CopyKasikataUniversalField4;
                case DenpyouInputItemType.KasikataUniversalField5:
                    return this.CopyKasikataUniversalField5;
                case DenpyouInputItemType.KasikataUniversalField6:
                    return this.CopyKasikataUniversalField6;
                case DenpyouInputItemType.KasikataUniversalField7:
                    return this.CopyKasikataUniversalField7;
                case DenpyouInputItemType.KasikataUniversalField8:
                    return this.CopyKasikataUniversalField8;
                case DenpyouInputItemType.KasikataUniversalField9:
                    return this.CopyKasikataUniversalField9;
                case DenpyouInputItemType.KasikataUniversalField10:
                    return this.CopyKasikataUniversalField10;
                case DenpyouInputItemType.KasikataUniversalField11:
                    return this.CopyKasikataUniversalField11;
                case DenpyouInputItemType.KasikataUniversalField12:
                    return this.CopyKasikataUniversalField12;
                case DenpyouInputItemType.KasikataUniversalField13:
                    return this.CopyKasikataUniversalField13;
                case DenpyouInputItemType.KasikataUniversalField14:
                    return this.CopyKasikataUniversalField14;
                case DenpyouInputItemType.KasikataUniversalField15:
                    return this.CopyKasikataUniversalField15;
                case DenpyouInputItemType.KasikataUniversalField16:
                    return this.CopyKasikataUniversalField16;
                case DenpyouInputItemType.KasikataUniversalField17:
                    return this.CopyKasikataUniversalField17;
                case DenpyouInputItemType.KasikataUniversalField18:
                    return this.CopyKasikataUniversalField18;
                case DenpyouInputItemType.KasikataUniversalField19:
                    return this.CopyKasikataUniversalField19;
                case DenpyouInputItemType.KasikataUniversalField20:
                    return this.CopyKasikataUniversalField20;
                case DenpyouInputItemType.KasikataProject:
                    return this.CopyKasikataProject;
                case DenpyouInputItemType.KasikataSegment:
                    return this.CopyKasikataSegment;
                case DenpyouInputItemType.KasikataKouzi:
                    return this.CopyKasikataKouzi;
                case DenpyouInputItemType.KasikataKousyu:
                    return this.CopyKasikataKousyu;
                case DenpyouInputItemType.KasikataTekiyou:
                    return this.CopyKasikataTekiyou;
                case DenpyouInputItemType.KasikataZiyuuTekiyou:
                    return this.CopyKasikataTekiyouCode;
                default:
                    return DenpyouInputSiwakeHukusyaType.DoNotCopy;
            }
        }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputHukusyaOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);
    }
}