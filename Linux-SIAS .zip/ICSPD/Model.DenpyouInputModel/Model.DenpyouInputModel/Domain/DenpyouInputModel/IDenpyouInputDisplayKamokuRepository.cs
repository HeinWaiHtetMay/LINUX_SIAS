﻿using System.Collections.Generic;
using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouInputDisplayKamokuRepository
    {
        IList<DenpyouInputDisplayKamoku> FindByKesnAndUserCodeAndPageNumberWithSecurity(int kesn, int userCode, int pageNumber, SecurityKubun securityKubun, UserAndSyorikiSecurityContext securityContext);
    }
}