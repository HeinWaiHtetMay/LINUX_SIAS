﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

    public class DenpyouInputOption
    {
        public DenpyouInputOption(int userCode, string programId)
        {
            this.ProgramId = programId;
            this.UserCode = userCode;

            this.LinkInfomationOption = new LinkInfomationOption();
            this.DenpyouKeisikiAtApplicationBoot = new DenpyouInputDenpyouKeisikiAtApplicationBoot();

            // 定型仕訳関係
            this.CommonPatternSelectionValue = new DenpyouInputTeikeiSiwakeSelectionValue();
            this.PersonalPatternSelectionValue = new DenpyouInputTeikeiSiwakeSelectionValue();

            // オプションダイアログ関係
            this.HukusyaOption = new DenpyouInputHukusyaOption();
            this.MeisyouItiranhyouOption = new DenpyouInputMeisyouItiranhyouOption();
            this.KensakuZidouKidouOption = new DenpyouInputKensakuZidouKidouOption();
            this.NihongoNyuuryokuOption = new DenpyouInputNihongoNyuuryokuOption();
            this.FocusOption = new DenpyouInputFocusOption();
            this.GaikaOption = new DenpyouInputGaikaOption();
            this.OtherOption = new DenpyouInputOtherOption();

            this.DenpyouInputAndSyuuseiOption = new DenpyouInputAndSyuuseiOption();
        }

        #region public property
        public string ProgramId { get; private set; }

        public int UserCode { get; private set; }

        /// <summary>
        /// 業務起動時の伝票形式
        /// </summary>
        public DenpyouInputDenpyouKeisikiAtApplicationBoot DenpyouKeisikiAtApplicationBoot { get; set; }

        /// <summary>
        /// 共通パターンの項目選択値
        /// </summary>
        public DenpyouInputTeikeiSiwakeSelectionValue CommonPatternSelectionValue { get; set; }

        /// <summary>
        /// 個人パターンの項目選択値
        /// </summary>
        public DenpyouInputTeikeiSiwakeSelectionValue PersonalPatternSelectionValue { get; set; }

        /// <summary>
        /// 会社情報設定登録
        /// リンク情報の設定
        /// </summary>
        public LinkInfomationOption LinkInfomationOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// 複写設定
        /// </summary>
        public DenpyouInputHukusyaOption HukusyaOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// 名称一覧表
        /// </summary>
        public DenpyouInputMeisyouItiranhyouOption MeisyouItiranhyouOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// コード以外の文字を入力し５０音検索画面を自動起動
        /// </summary>
        public DenpyouInputKensakuZidouKidouOption KensakuZidouKidouOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// 日本語入力する項目
        /// </summary>
        public DenpyouInputNihongoNyuuryokuOption NihongoNyuuryokuOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// フォーカス設定
        /// </summary>
        public DenpyouInputFocusOption FocusOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// 外貨設定
        /// </summary>
        public DenpyouInputGaikaOption GaikaOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// 伝票入力伝票修正設定
        /// </summary>
        public DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption { get; set; }

        /// <summary>
        /// オプション設定ダイアログ
        /// その他設定
        /// </summary>
        public DenpyouInputOtherOption OtherOption { get; set; }

        /// <summary>
        /// 課税区分等に選択番号を表示する
        /// </summary>
        public bool ShowSelectionNumber { get; set; }

        /// <summary>
        /// 登録前に確認ﾒｯｾｰｼﾞを表示する
        /// </summary>
        public bool ShowConfirmationMessage { get; set; }

        /// <summary>
        /// 支払日が伝票日付以降かどうかをﾁｪｯｸする
        /// </summary>
        public bool CheckSiharaibiIsAfterDenpyouHizuke { get; set; }

        /// <summary>
        /// 自動行区切りモード
        /// </summary>
        public bool AutoGyoukugiriMode { get; set; }
        #endregion

        #region public methods
        public void UpdateTeikeiSiwakeSelectionValue(TeikeiSiwakeType teikeiSiwakeType, DenpyouInputTeikeiSiwakeSelectionValue denpyouInputTeikeisiwakeSelectionValue)
        {
            if (teikeiSiwakeType == TeikeiSiwakeType.CommonPattern)
            {
                this.CommonPatternSelectionValue.Update(denpyouInputTeikeisiwakeSelectionValue);
            }
            else
            {
                this.PersonalPatternSelectionValue.Update(denpyouInputTeikeisiwakeSelectionValue);
            }
        }
        #endregion
    }
}