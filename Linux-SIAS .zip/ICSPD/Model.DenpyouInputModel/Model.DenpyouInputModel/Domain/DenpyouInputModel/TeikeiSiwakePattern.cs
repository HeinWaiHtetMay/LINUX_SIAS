﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System.Collections.Generic;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public class TeikeiSiwakePattern : TeikeiSiwakeHeader
    {
        public TeikeiSiwakePattern(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber)
            : base(teikeiSiwakeSystemType, userCode, patternNumber)
        {
            this.TeikeiSiwakeGyouList = new List<TeikeiSiwakeGyou>();
        }

        #region public properties
        public IList<TeikeiSiwakeGyou> TeikeiSiwakeGyouList { get; set; }
        #endregion

        #region public methods

        /// <summary>
        /// 税率と税額を変換
        /// </summary>
        /// <param name="syouhizeiritu"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="useGaika"></param>
        /// <param name="kamokuHeisyuList"></param>
        /// <param name="heisyuDictionary"></param>
        public void ConvertZeirituAndZeigaku(
            Syouhizeiritu syouhizeiritu,
            SyouhizeiMaster syouhizeiMaster,
            bool useGaika,
            IList<KamokuHeisyu> kamokuHeisyuList,
            IDictionary<string, Heisyu> heisyuDictionary) =>
            this.TeikeiSiwakeGyouList.ForEachIfNotNull(teikeiSiwakeGyou => teikeiSiwakeGyou.ConvertZeirituAndZeigaku(this.DenpyouKeisiki, syouhizeiritu, syouhizeiMaster, useGaika, kamokuHeisyuList, heisyuDictionary));

        #endregion
    }
}
