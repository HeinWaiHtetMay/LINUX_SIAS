﻿using Icsp.Open21.Domain.DenpyouModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class DenpyouInputLayoutItem
    {
        internal DenpyouInputLayoutItem(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno, int pseq)
        {
            this.Kesn = kesn;
            this.DenpyouKeisiki = denpyouKeisiki;
            this.Ptno = ptno;
            this.Pseq = pseq;
        }

        internal DenpyouInputLayoutItem(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno, int pseq, int line, int colm, DenpyouInputItemType denpyouInputItem)
        {
            this.Kesn = kesn;
            this.DenpyouKeisiki = denpyouKeisiki;
            this.Ptno = ptno;
            this.Pseq = pseq;
            this.Line = line;
            this.Column = colm;
            this.DenpyouInputItemType = denpyouInputItem;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 伝票種別（カラム名：dtyp）
        /// </summary>
        public DenpyouKeisiki DenpyouKeisiki { get; private set; }

        /// <summary>
        /// パターンｎｏ（カラム名：ptno）
        /// </summary>
        public int Ptno { get; private set; }

        /// <summary>
        /// ｓｅｑｎｏ（カラム名：pseq）
        /// </summary>
        public int Pseq { get; private set; }

        /// <summary>
        /// 縦位置（カラム名：line）
        /// </summary>
        public int Line { get; set; }

        /// <summary>
        /// 横位置（カラム名：colm）
        /// </summary>
        public int Column { get; set; }

        /// <summary>
        /// アイテム（カラム名：item）
        /// </summary>
        public DenpyouInputItemType DenpyouInputItemType { get; set; }

        #endregion

        #region public methods

        /// <summary>
        /// 追加項目のタイプを取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputItemType GetAdditionalDenpyouInputItemType()
        {
            switch (this.DenpyouInputItemType)
            {
                case DenpyouInputItemType.KarikataKazeiKubun:
                    return DenpyouInputItemType.KarikataZeiritu;
                case DenpyouInputItemType.KarikataBunriKubun:
                    return DenpyouInputItemType.KarikataSiireKubun;
                case DenpyouInputItemType.KarikataZeitaisyouKamokuKazeiKubun:
                    return DenpyouInputItemType.KarikataZeitaisyouKamokuSiireKubun;
                case DenpyouInputItemType.KarikataHusen:
                    return DenpyouInputItemType.KarikataHusenDisplay;
                case DenpyouInputItemType.KasikataKazeiKubun:
                    return DenpyouInputItemType.KasikataZeiritu;
                case DenpyouInputItemType.KasikataBunriKubun:
                    return DenpyouInputItemType.KasikataSiireKubun;
                case DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun:
                    return DenpyouInputItemType.KasikataZeitaisyouKamokuSiireKubun;
                case DenpyouInputItemType.KasikataHusen:
                    return DenpyouInputItemType.KasikataHusenDisplay;
                default:
                    return DenpyouInputItemType.NotUsed;
            }
        }

        /// <summary>
        /// 追加項目を取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputLayoutItem GetAdditionalDenpyouLayoutItem()
            => new DenpyouInputLayoutItem(this.Kesn, this.DenpyouKeisiki, this.Ptno, this.Pseq, this.Line, this.Column, this.GetAdditionalDenpyouInputItemType());
        #endregion
    }
}
