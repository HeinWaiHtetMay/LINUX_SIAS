﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    /// <summary>
    /// 業務起動時の伝票形式
    /// </summary>
    public class DenpyouInputDenpyouKeisikiAtApplicationBoot
    {
        public DenpyouInputFormType DenpyouInputFormType { get; set; } = DenpyouInputFormType.HukugouSiwake;

        public int TannituPattern { get; set; } = 0;

        public int HukugouPattern { get; set; } = 0;
    }
}