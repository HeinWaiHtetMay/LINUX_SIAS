﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class DenpyouInputTeikeiSiwakeSelectionValue
    {
        #region properties

        /// <summary>
        /// 表示順序
        /// </summary>
        public DenpyouInputTeikeiSiwakeDisplayOrder TeikeiSiwakeDisplayOrder { get; set; }

        /// <summary>
        /// 表示パターン
        /// </summary>
        public DenpyouInputTeikeiSiwakeDisplayPattern TeikeiSiwakeDisplayPattern { get; set; }

        /// <summary>
        /// 指定方法
        /// </summary>
        public DenpyouInputTeikeiSiwakeSelectWay TeikeiSiwakeSelectWay { get; set; }

        /// <summary>
        /// 摘要の付加
        /// </summary>
        public bool AddTekiyo { get; set; }

        /// <summary>
        /// 読出方法
        /// </summary>
        public DenpyouInputTeikeiSiwakeReadoutWay TeikeiSiwakeReadoutWay { get; set; }

        /// <summary>
        /// 伝票形式
        /// </summary>
        public bool ReadoutInDenpyouKeisikiAtRegistration { get; set; }

        #endregion

        #region public methods
        public DenpyouInputTeikeiSiwakeSelectionValue Clone() => (DenpyouInputTeikeiSiwakeSelectionValue)this.MemberwiseClone();

        /// <summary>
        /// オプション値を更新
        /// </summary>
        /// <param name="denpyouInputTeikeisiwakeSelectionValue"></param>
        public void Update(DenpyouInputTeikeiSiwakeSelectionValue denpyouInputTeikeisiwakeSelectionValue)
        {
            this.TeikeiSiwakeDisplayOrder = denpyouInputTeikeisiwakeSelectionValue.TeikeiSiwakeDisplayOrder;
            this.TeikeiSiwakeDisplayPattern = denpyouInputTeikeisiwakeSelectionValue.TeikeiSiwakeDisplayPattern;
            this.TeikeiSiwakeSelectWay = denpyouInputTeikeisiwakeSelectionValue.TeikeiSiwakeSelectWay;
            this.AddTekiyo = denpyouInputTeikeisiwakeSelectionValue.AddTekiyo;
            this.TeikeiSiwakeReadoutWay = denpyouInputTeikeisiwakeSelectionValue.TeikeiSiwakeReadoutWay;
            this.ReadoutInDenpyouKeisikiAtRegistration = denpyouInputTeikeisiwakeSelectionValue.ReadoutInDenpyouKeisikiAtRegistration;
        }
        #endregion
    }
}