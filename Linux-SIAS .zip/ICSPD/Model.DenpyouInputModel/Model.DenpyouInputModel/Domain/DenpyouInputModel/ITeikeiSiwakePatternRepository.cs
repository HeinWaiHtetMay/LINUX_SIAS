﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface ITeikeiSiwakePatternRepository
    {
        void Delete(TeikeiSiwakeHeader teikeiSiwakeHeader);

        IList<TeikeiSiwakeHeader> FindTeikeiSiwakeHeaderBySystemTypeAndTeikeiSiwakeTypeAndUserCodeOrderByPatternNumber(TeikeiSiwakeSystemType teikeiSiwakeSystemType, TeikeiSiwakeType teikeiSiwakeType, int userCode, string programId);

        TeikeiSiwakePattern FindTeikeiSiwakePatternBySystemTypeAndTeikeiSiwakeTypeAndUserCodeAndPatternNumber(TeikeiSiwakeSystemType teikeiSiwakeSystemType, TeikeiSiwakeType teikeiSiwakeType, int userCode, string programId, int patternNumber);

        void Store(TeikeiSiwakePattern teikeiSiwakePattern);

        void UpdatePatternNameAndWeightNumberAndTekiyouNumber(TeikeiSiwakeHeader teikeiSiwakeHeader);

        void UpdateUseTimesAndLastUseDateAndLastUseTime(TeikeiSiwakePattern teikeiSiwakePattern);

        void UpdateUseTimeToZeroByTeikeiSiwakeSystemTypeAndUserCode(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode);

        void UpdateZeirituAndZeigaku(TeikeiSiwakePattern teikeiSiwakePattern);
    }
}