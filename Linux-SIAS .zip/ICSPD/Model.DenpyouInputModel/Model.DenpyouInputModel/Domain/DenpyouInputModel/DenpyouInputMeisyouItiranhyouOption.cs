﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using Icsp.Framework.Core.Serialization;
    using Icsp.Open21.Domain.KaisyaModel;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputMeisyouItiranhyouOption
    {
        public bool ShowHeaderField1MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField2MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField3MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField4MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField5MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField6MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField7MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField8MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField9MeisyoItiranhyo { get; set; }

        public bool ShowHeaderField10MeisyoItiranhyo { get; set; }

        public bool ShowKamokuMeisyoItiranhyo { get; set; }

        public bool ShowBumonMeisyoItiranhyo { get; set; }

        public DenpyouInputDisplayContent BumonMeisyouItiranhyosDisplayContent { get; set; }

        public bool ShowTorihikisakiMeisyoItiranhyo { get; set; }

        public DenpyouInputDisplayContent TorihikiMeisyouItiranhyosDisplayContent { get; set; }

        public bool ShowEdabanMeisyoItiranhyo { get; set; }

        public DenpyouInputDisplayContent EdabanMeisyouItiranhyosDisplayContent { get; set; }

        public bool ShowUniversalField1MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField2MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField3MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField4MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField5MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField6MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField7MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField8MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField9MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField10MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField11MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField12MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField13MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField14MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField15MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField16MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField17MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField18MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField19MeisyoItiranhyo { get; set; }

        public bool ShowUniversalField20MeisyoItiranhyo { get; set; }

        public bool ShowProjectMeisyoItiranhyo { get; set; }

        public bool ShowSegmentMeisyoItiranhyo { get; set; }

        public bool ShowKouziMeisyoItiranhyo { get; set; }

        public DenpyouInputDisplayContent KouziMeisyouItiranhyousDisplayContent { get; set; }

        public bool ShowKousyuMeisyoItiranhyo { get; set; }

        public DenpyouInputDisplayContent KousyuMeisyouItiranhyousDisplayContent { get; set; }

        public bool ShowTekiyouMeisyouItiranhyou { get; set; } = true;

        public DenpyouInputDisplayStyle DisplayStyle { get; set; }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputMeisyouItiranhyouOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);

        /// <summary>
        /// 名称一覧表を表示するか
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public bool ShouldShowNameListTable(DenpyouInputItemType denpyouInputItemType, Syoriki syoriki)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.HeaderField1:
                    return this.ShowHeaderField1MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 1).IsCreateMaster;
                case DenpyouInputItemType.HeaderField2:
                    return this.ShowHeaderField2MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 2).IsCreateMaster;
                case DenpyouInputItemType.HeaderField3:
                    return this.ShowHeaderField3MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 3).IsCreateMaster;
                case DenpyouInputItemType.HeaderField4:
                    return this.ShowHeaderField4MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 4).IsCreateMaster;
                case DenpyouInputItemType.HeaderField5:
                    return this.ShowHeaderField5MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 5).IsCreateMaster;
                case DenpyouInputItemType.HeaderField6:
                    return this.ShowHeaderField6MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 6).IsCreateMaster;
                case DenpyouInputItemType.HeaderField7:
                    return this.ShowHeaderField7MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 7).IsCreateMaster;
                case DenpyouInputItemType.HeaderField8:
                    return this.ShowHeaderField8MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 8).IsCreateMaster;
                case DenpyouInputItemType.HeaderField9:
                    return this.ShowHeaderField9MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 9).IsCreateMaster;
                case DenpyouInputItemType.HeaderField10:
                    return this.ShowHeaderField10MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(true, 10).IsCreateMaster;
                case DenpyouInputItemType.KarikataKamoku:
                case DenpyouInputItemType.KasikataKamoku:
                case DenpyouInputItemType.KarikataZeitaisyouKamoku:
                case DenpyouInputItemType.KasikataZeitaisyouKamoku:
                    return this.ShowKamokuMeisyoItiranhyo;
                case DenpyouInputItemType.KarikataBumon:
                case DenpyouInputItemType.KasikataBumon:
                    return this.ShowBumonMeisyoItiranhyo && syoriki.BumonInfo.Use;
                case DenpyouInputItemType.KarikataTorihikisaki:
                case DenpyouInputItemType.KasikataTorihikisaki:
                    return this.ShowTorihikisakiMeisyoItiranhyo && syoriki.TorihikisakiInfo.Use;
                case DenpyouInputItemType.KarikataEdaban:
                case DenpyouInputItemType.KasikataEdaban:
                    return this.ShowEdabanMeisyoItiranhyo && syoriki.EdabanInfo.Use;
                case DenpyouInputItemType.KarikataUniversalField1:
                case DenpyouInputItemType.KasikataUniversalField1:
                    return this.ShowUniversalField1MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 1).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField2:
                case DenpyouInputItemType.KasikataUniversalField2:
                    return this.ShowUniversalField2MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 2).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField3:
                case DenpyouInputItemType.KasikataUniversalField3:
                    return this.ShowUniversalField3MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 3).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField4:
                case DenpyouInputItemType.KasikataUniversalField4:
                    return this.ShowUniversalField4MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 4).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField5:
                case DenpyouInputItemType.KasikataUniversalField5:
                    return this.ShowUniversalField5MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 5).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField6:
                case DenpyouInputItemType.KasikataUniversalField6:
                    return this.ShowUniversalField6MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 6).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField7:
                case DenpyouInputItemType.KasikataUniversalField7:
                    return this.ShowUniversalField7MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 7).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField8:
                case DenpyouInputItemType.KasikataUniversalField8:
                    return this.ShowUniversalField8MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 8).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField9:
                case DenpyouInputItemType.KasikataUniversalField9:
                    return this.ShowUniversalField9MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 9).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField10:
                case DenpyouInputItemType.KasikataUniversalField10:
                    return this.ShowUniversalField10MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 10).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField11:
                case DenpyouInputItemType.KasikataUniversalField11:
                    return this.ShowUniversalField11MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 11).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField12:
                case DenpyouInputItemType.KasikataUniversalField12:
                    return this.ShowUniversalField12MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 12).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField13:
                case DenpyouInputItemType.KasikataUniversalField13:
                    return this.ShowUniversalField13MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 13).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField14:
                case DenpyouInputItemType.KasikataUniversalField14:
                    return this.ShowUniversalField14MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 14).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField15:
                case DenpyouInputItemType.KasikataUniversalField15:
                    return this.ShowUniversalField15MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 15).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField16:
                case DenpyouInputItemType.KasikataUniversalField16:
                    return this.ShowUniversalField16MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 16).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField17:
                case DenpyouInputItemType.KasikataUniversalField17:
                    return this.ShowUniversalField17MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 17).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField18:
                case DenpyouInputItemType.KasikataUniversalField18:
                    return this.ShowUniversalField18MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 18).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField19:
                case DenpyouInputItemType.KasikataUniversalField19:
                    return this.ShowUniversalField19MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 19).IsCreateMaster;
                case DenpyouInputItemType.KarikataUniversalField20:
                case DenpyouInputItemType.KasikataUniversalField20:
                    return this.ShowUniversalField20MeisyoItiranhyo && syoriki.GetUniversalFieldInfo(false, 20).IsCreateMaster;
                case DenpyouInputItemType.KarikataProject:
                case DenpyouInputItemType.KasikataProject:
                    return this.ShowProjectMeisyoItiranhyo && syoriki.ProjectInfo.Use;
                case DenpyouInputItemType.KarikataSegment:
                case DenpyouInputItemType.KasikataSegment:
                    return this.ShowSegmentMeisyoItiranhyo && syoriki.SegmentInfo.Use;
                case DenpyouInputItemType.KarikataKouzi:
                case DenpyouInputItemType.KasikataKouzi:
                    return this.ShowKouziMeisyoItiranhyo && syoriki.KouziInfo.Use;
                case DenpyouInputItemType.KarikataKousyu:
                case DenpyouInputItemType.KasikataKousyu:
                    return this.ShowKousyuMeisyoItiranhyo && syoriki.KousyuInfo.Use;
                case DenpyouInputItemType.KarikataZiyuuTekiyou:
                case DenpyouInputItemType.KasikataZiyuuTekiyou:
                case DenpyouInputItemType.KarikataTekiyou:
                case DenpyouInputItemType.KasikataTekiyou:
                case DenpyouInputItemType.CommonTekiyou:
                case DenpyouInputItemType.KarikataTekiyouInput:
                case DenpyouInputItemType.KasikataTekiyouInput:
                case DenpyouInputItemType.CommonTekiyouInput:
                    return this.ShowTekiyouMeisyouItiranhyou && syoriki.UseRensouTekiyou;
                default:
                    return false;
            }
        }
    }
}