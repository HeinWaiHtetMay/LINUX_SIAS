﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IRensouTekiyouRepository
    {
        IList<RensouTekiyou> FindByKesnAndKicdAndUcodOrderBySeq(int kesn, int ucod, string kicd);
    }
}