﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.DenpyouModel;

    public interface IDenpyouInputLayoutItemRepository
    {
        IList<DenpyouInputLayoutItem> FindByKesnAndDenpyouTypeAndPtnoOrderByPseq(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno);
    }
}