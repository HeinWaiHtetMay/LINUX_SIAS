﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class RensouTekiyou
    {
        public RensouTekiyou(int kesn, int userCode, int pageNumber, int seq)
        {
            this.Kesn = kesn;
            ////this.Tsw0 = tsw0;
            this.UserCode = userCode;
            this.PageNumber = pageNumber;
            this.Seq = seq;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /////// <summary>
        /////// 共通・個別区分（カラム名：tsw0）
        /////// </summary>
        ////public int Tsw0 { get; private set; }

        /// <summary>
        /// ユーザー番号（カラム名：ucod）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// ページ番号（カラム名：rtno）
        /// </summary>
        public int PageNumber { get; private set; }

        /// <summary>
        /// seq（カラム名：seq）
        /// </summary>
        public int Seq { get; private set; }

        /// <summary>
        /// 自由摘要
        /// </summary>
        public ZiyuuTekiyou ZiyuuTekiyou { get; set; }
        #endregion
    }
}
