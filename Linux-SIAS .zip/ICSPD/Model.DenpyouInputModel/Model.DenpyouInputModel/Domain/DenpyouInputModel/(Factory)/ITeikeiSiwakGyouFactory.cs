﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface ITeikeiSiwakGyouFactory
    {
        TeikeiSiwakeGyou CreateTeikeiPattern(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber, int lineNumber);
    }
}