﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouInputTeikeiSiwakeTekiyouRepository
    {
        /// <summary>
        /// 指定パターン番号の摘要文字列を取得
        /// </summary>
        /// <param name="teikeiSiwakeType"></param>
        /// <param name="programId"></param>
        /// <param name="userCode"></param>
        /// <param name="tekiyouNumber"></param>
        /// <returns></returns>
        DenpyouInputTeikeiSiwakeTekiyou FindByProgramIdAndUserNoAndTekiyouNumber(TeikeiSiwakeType teikeiSiwakeType, string programId, int userCode, int tekiyouNumber);

        /// <summary>
        /// 摘要文字列リストを取得
        /// </summary>
        /// <param name="teikeiSiwakeType"></param>
        /// <param name="programId"></param>
        /// <param name="userCode"></param>
        /// <returns></returns>
        IList<DenpyouInputTeikeiSiwakeTekiyou> FindByProgramIdAndUserNoOrderByTekiyouNumber(TeikeiSiwakeType teikeiSiwakeType, string programId, int userCode);

        /// <summary>
        /// 摘要文字列リストを更新
        /// </summary>
        /// <param name="denpyouInputTeikeiSiwakeTekiyouList"></param>
        /// <param name="programId"></param>
        void Store(IList<DenpyouInputTeikeiSiwakeTekiyou> denpyouInputTeikeiSiwakeTekiyouList, string programId);
    }
}