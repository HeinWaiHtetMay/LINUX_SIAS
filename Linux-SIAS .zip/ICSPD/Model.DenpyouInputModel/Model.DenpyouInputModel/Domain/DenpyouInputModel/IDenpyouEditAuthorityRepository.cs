﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouEditAuthorityRepository
    {
        bool GetExistsByUserCode(int userCode);
    }
}