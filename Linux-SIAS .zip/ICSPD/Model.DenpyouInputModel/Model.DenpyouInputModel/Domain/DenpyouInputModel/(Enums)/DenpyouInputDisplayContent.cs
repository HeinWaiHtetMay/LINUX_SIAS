﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputDisplayContent
    {
        Name = 0,
        NameAndCode = 1,
    }
}
