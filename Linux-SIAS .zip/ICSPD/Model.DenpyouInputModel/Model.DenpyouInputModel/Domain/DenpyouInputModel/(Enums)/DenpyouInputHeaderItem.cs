﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputHeaderItem
    {
        UketukeNo = 0x0001,
        DenpyouHizuke = 0x0002,
        Seirituki = 0x0003,
        DenpyouNo = 0x0004,
        Kihyoubi = 0x0005,
        Kihyoubumon = 0x0006,
        Kihyousya = 0x0007,
        SyouninGroup = 0x0008,
        DenpyouTabaCode = 0x0009,
        HeaderField1 = 0x0042,
        HeaderField2 = 0x0043,
        HeaderField3 = 0x0044,
        HeaderField4 = 0x0045,
        HeaderField5 = 0x0046,
        HeaderField6 = 0x0047,
        HeaderField7 = 0x0048,
        HeaderField8 = 0x0049,
        HeaderField9 = 0x004a,
        HeaderField10 = 0x004b,
        LinkButton = 0x004c,
        DenpyouZyouhouButton = 0x004d,

        SiwakeCount = 0x004e,
    }
}