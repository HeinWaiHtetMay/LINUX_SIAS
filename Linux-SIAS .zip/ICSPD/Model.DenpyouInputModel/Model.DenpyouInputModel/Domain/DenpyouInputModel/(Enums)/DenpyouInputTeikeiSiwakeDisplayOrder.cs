﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputTeikeiSiwakeDisplayOrder
    {
        OnToUseFrequency = 0,
        PatternsNoOrder = 1,
        WeightNumberOrder = 2,
    }
}
