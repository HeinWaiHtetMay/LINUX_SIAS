﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum TeikeiSiwakeType
    {
        CommonPattern = 0,
        PersonalPattern = 1,
    }
}
