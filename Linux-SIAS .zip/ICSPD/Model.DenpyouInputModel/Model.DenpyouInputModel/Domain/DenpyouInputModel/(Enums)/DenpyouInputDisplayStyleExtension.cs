﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static class DenpyouInputDisplayStyleExtension
    {
        public static int GetColumnCount(this DenpyouInputDisplayStyle denpyouInputDisplayStyle)
        {
            switch (denpyouInputDisplayStyle)
            {
                case DenpyouInputDisplayStyle.Vertical1Column:
                    return 1;
                case DenpyouInputDisplayStyle.Vertical2Column:
                    return 2;
                case DenpyouInputDisplayStyle.Horizontal:
                default:
                    return 5;
            }
        }

        public static int GetRowCount(this DenpyouInputDisplayStyle denpyouInputDisplayStyle)
        {
            switch (denpyouInputDisplayStyle)
            {
                case DenpyouInputDisplayStyle.Vertical1Column:
                    return 30;
                case DenpyouInputDisplayStyle.Vertical2Column:
                    return 20;
                case DenpyouInputDisplayStyle.Horizontal:
                default:
                    return 8;
            }
        }

        public static int GetKoteiKamokuRowCount(this DenpyouInputDisplayStyle denpyouInputDisplayStyle)
        {
            switch (denpyouInputDisplayStyle)
            {
                case DenpyouInputDisplayStyle.Vertical1Column:
                case DenpyouInputDisplayStyle.Vertical2Column:
                    return 5;
                case DenpyouInputDisplayStyle.Horizontal:
                default:
                    return 2;
            }
        }

        public static int GetItemCount(this DenpyouInputDisplayStyle denpyouInputDisplayStyle)
        {
            switch (denpyouInputDisplayStyle)
            {
                case DenpyouInputDisplayStyle.Vertical1Column:
                    return 30;
                case DenpyouInputDisplayStyle.Vertical2Column:
                    return 40;
                case DenpyouInputDisplayStyle.Horizontal:
                default:
                    return 40;
            }
        }
    }
}
