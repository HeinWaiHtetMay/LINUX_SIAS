﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputDenpyouNoHukusyaType
    {
        DoNotCopy = 0,
        Copy = 1,
        AutoIncrement = 2,
    }
}
