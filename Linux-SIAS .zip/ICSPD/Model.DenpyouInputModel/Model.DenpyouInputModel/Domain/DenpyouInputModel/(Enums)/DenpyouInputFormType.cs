﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputFormType
    {
        HukugouSiwake = 1,
        HukugouSiwakeSiteiKoumoku = 2,
        TannituSiwake = 3,
        TannituSiwakeSiteiKoumoku = 4,
    }
}
