﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum TeikeiSiwakeBunriType
    {
        Nothing = 0,
        KarikataBunri = 1,
        KasikataBunri = 2,
        GyouBunri = 3,
    }
}
