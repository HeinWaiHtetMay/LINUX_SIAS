﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputTourokuKakuninTiming
    {
        SiwakeTanni = 0,
        DenpyouTanni = 1,
    }
}