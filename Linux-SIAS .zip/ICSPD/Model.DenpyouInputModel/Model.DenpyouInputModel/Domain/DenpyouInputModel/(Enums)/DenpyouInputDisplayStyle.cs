﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputDisplayStyle
    {
        /// <summary>
        /// 横表示
        /// </summary>
        Horizontal = 0,

        /// <summary>
        /// 縦1列表示
        /// </summary>
        Vertical1Column = 1,

        /// <summary>
        /// 縦2列表示
        /// </summary>
        Vertical2Column = 2,
    }
}
