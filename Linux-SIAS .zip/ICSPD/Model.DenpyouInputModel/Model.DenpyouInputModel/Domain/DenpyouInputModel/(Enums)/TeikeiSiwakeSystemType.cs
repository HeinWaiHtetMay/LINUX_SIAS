﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum TeikeiSiwakeSystemType
    {
        Tuuzyou = 0,
        Busyo = 1,
        BumonKeihi = 2,
        BusyoBumonKeihi = 3,
    }
}
