﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputTeikeiSiwakeSelectWay
    {
        InputPatternNumber = 0,
        SelectFromList = 1,
    }
}
