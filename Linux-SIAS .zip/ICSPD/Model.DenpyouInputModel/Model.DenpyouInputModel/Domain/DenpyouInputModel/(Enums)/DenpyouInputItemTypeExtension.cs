﻿using Icsp.Open21.Domain.DenpyouModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static class DenpyouInputItemTypeExtension
    {
        private static readonly string KasikataString = "貸方）";

        public static string GetNameForStatsText(this DenpyouInputItemType denpyouInputItemType, bool isCommonItem) =>
            GetNameForStatsText(denpyouInputItemType, isCommonItem, false);

        public static string GetNameForStatsText(this DenpyouInputItemType denpyouInputItemType, bool isCommonItem, bool isRenketuSienMaster)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.DenpyouHizuke:
                    return "伝票日付";
                case DenpyouInputItemType.DenpyouNo:
                    return "伝票番号";
                case DenpyouInputItemType.Kihyoubi:
                    return "伝票の起票日";
                case DenpyouInputItemType.KihyouBumon:
                    return "伝票の起票部門コード";
                case DenpyouInputItemType.Kihyousya:
                    return isRenketuSienMaster ? "伝票区分" : "伝票の起票者（担当者）";
                case DenpyouInputItemType.SyouninGroup:
                    return "承認ルート";
                case DenpyouInputItemType.DenpyouTabaCode:
                    return "伝票束コード";
                case DenpyouInputItemType.KarikataBumon:
                    return "借方）部門コード";
                case DenpyouInputItemType.KarikataTorihikisaki:
                    return "借方）取引先コード";
                case DenpyouInputItemType.KarikataKamoku:
                    return "借方）科目コード";
                case DenpyouInputItemType.KarikataEdaban:
                    return "借方）枝番コード";
                case DenpyouInputItemType.KarikataKouzi:
                    return "借方）工事コード";
                case DenpyouInputItemType.KarikataKousyu:
                    return "借方）工種コード";
                case DenpyouInputItemType.KarikataProject:
                    return "借方）プロジェクトコード";
                case DenpyouInputItemType.KarikataSegment:
                    return "借方）セグメントコード";
                case DenpyouInputItemType.KarikataTekiyou:
                    return "借方）摘要";
                case DenpyouInputItemType.KarikataZiyuuTekiyou:
                case DenpyouInputItemType.KarikataTekiyouInput:
                    return "借方）摘要コード";
                case DenpyouInputItemType.KarikataTaika:
                    return "借方）対価";
                case DenpyouInputItemType.KarikataKingaku:
                    return "借方）金額";
                case DenpyouInputItemType.KarikataZeitaisyouKamoku:
                    return "借方）税対象科目の科目コード";
                case DenpyouInputItemType.KarikataZeitaisyouKamokuKazeiKubun:
                    return "借方）税対象科目の課税区分";
                case DenpyouInputItemType.KarikataZeitaisyouKamokuGyousyuKubun:
                    return "借方）税対象科目の簡易課税の業種区分";
                case DenpyouInputItemType.KarikataZeitaisyouKamokuSiireKubun:
                    return "借方）税対象科目の仕入税額按分法の区分";
                case DenpyouInputItemType.KarikataZeiritu:
                    return "借方）税率";
                case DenpyouInputItemType.KarikataKazeiKubun:
                    return "借方）課税区分";
                case DenpyouInputItemType.KarikataGyousyuKubun:
                    return "借方）簡易課税の業種区分";
                case DenpyouInputItemType.KarikataSiireKubun:
                    return "借方）仕入税額按分法の区分";
                case DenpyouInputItemType.KarikataBunriKubun:
                    return "借方）分離方法";
                case DenpyouInputItemType.KarikataSiharaibi:
                    return "借方）支払日";
                case DenpyouInputItemType.KarikataSiharaiKubun:
                    return "借方）支払区分";
                case DenpyouInputItemType.KarikataSiharaiKizitu:
                    return "借方）支払期日";
                case DenpyouInputItemType.KarikataKaisyuubi:
                    return "借方）回収日";
                case DenpyouInputItemType.KarikataNyuukinKubun:
                    return "借方）入金区分";
                case DenpyouInputItemType.KarikataKaisyuuKizitu:
                    return "借方）回収期日";
                case DenpyouInputItemType.KarikataKesikomiCode:
                    return "借方）消込コード";
                case DenpyouInputItemType.KarikataHusen:
                    return "借方）付箋";
                case DenpyouInputItemType.KarikataRate:
                    return "借方）レート";
                case DenpyouInputItemType.KarikataGaikaKingaku:
                    return "借方）外貨金額";
                case DenpyouInputItemType.KarikataGaikaTaika:
                    return "借方）外貨対価";
                case DenpyouInputItemType.KarikataHeisyuCode:
                    return "借方）幣種";
                case DenpyouInputItemType.KarikataTaisyakubetuTekiyou:
                    return "貸借別摘要";
                case DenpyouInputItemType.KasikataBumon:
                    return "貸方）部門コード";
                case DenpyouInputItemType.KasikataTorihikisaki:
                    return "貸方）取引先コード";
                case DenpyouInputItemType.KasikataKamoku:
                    return "貸方）科目コード";
                case DenpyouInputItemType.KasikataEdaban:
                    return "貸方）枝番コード";
                case DenpyouInputItemType.KasikataKouzi:
                    return "貸方）工事コード";
                case DenpyouInputItemType.KasikataKousyu:
                    return "貸方）工種コード";
                case DenpyouInputItemType.KasikataProject:
                    return "貸方）プロジェクトコード";
                case DenpyouInputItemType.KasikataSegment:
                    return "貸方）セグメントコード";
                case DenpyouInputItemType.KasikataTekiyou:
                    return "貸方）摘要";
                case DenpyouInputItemType.KasikataZiyuuTekiyou:
                case DenpyouInputItemType.KasikataTekiyouInput:
                    return "貸方）摘要コード";
                case DenpyouInputItemType.KasikataTaika:
                    return (isCommonItem ? string.Empty : KasikataString) + "対価";
                case DenpyouInputItemType.KasikataKingaku:
                    return (isCommonItem ? string.Empty : KasikataString) + "金額";
                case DenpyouInputItemType.KasikataZeitaisyouKamoku:
                    return (isCommonItem ? string.Empty : KasikataString) + "税対象科目の科目コード";
                case DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun:
                    return (isCommonItem ? string.Empty : KasikataString) + "税対象科目の課税区分";
                case DenpyouInputItemType.KasikataZeitaisyouKamokuGyousyuKubun:
                    return (isCommonItem ? string.Empty : KasikataString) + "税対象科目の簡易課税の業種区分";
                case DenpyouInputItemType.KasikataZeitaisyouKamokuSiireKubun:
                    return (isCommonItem ? string.Empty : KasikataString) + "税対象科目の仕入税額按分法の区分";
                case DenpyouInputItemType.KasikataZeiritu:
                    return "貸方）税率";
                case DenpyouInputItemType.KasikataKazeiKubun:
                    return "貸方）課税区分";
                case DenpyouInputItemType.KasikataGyousyuKubun:
                    return "貸方）簡易課税の業種区分";
                case DenpyouInputItemType.KasikataSiireKubun:
                    return "貸方）仕入税額按分法の区分";
                case DenpyouInputItemType.KasikataBunriKubun:
                    return "貸方）分離方法";
                case DenpyouInputItemType.KasikataSiharaibi:
                    return (isCommonItem ? string.Empty : KasikataString) + "支払日";
                case DenpyouInputItemType.KasikataSiharaiKubun:
                    return (isCommonItem ? string.Empty : KasikataString) + "支払区分";
                case DenpyouInputItemType.KasikataSiharaiKizitu:
                    return (isCommonItem ? string.Empty : KasikataString) + "支払期日";
                case DenpyouInputItemType.KasikataKaisyuubi:
                    return (isCommonItem ? string.Empty : KasikataString) + "回収日";
                case DenpyouInputItemType.KasikataNyuukinKubun:
                    return (isCommonItem ? string.Empty : KasikataString) + "入金区分";
                case DenpyouInputItemType.KasikataKaisyuuKizitu:
                    return (isCommonItem ? string.Empty : KasikataString) + "回収期日";
                case DenpyouInputItemType.KasikataKesikomiCode:
                    return (isCommonItem ? string.Empty : KasikataString) + "消込コード";
                case DenpyouInputItemType.KasikataHusen:
                    return (isCommonItem ? string.Empty : KasikataString) + "付箋";
                case DenpyouInputItemType.KasikataRate:
                    return (isCommonItem ? string.Empty : KasikataString) + "レート";
                case DenpyouInputItemType.KasikataGaikaKingaku:
                    return (isCommonItem ? string.Empty : KasikataString) + "外貨金額";
                case DenpyouInputItemType.KasikataGaikaTaika:
                    return (isCommonItem ? string.Empty : KasikataString) + "外貨対価";
                case DenpyouInputItemType.KasikataHeisyuCode:
                    return (isCommonItem ? string.Empty : KasikataString) + "幣種";
                case DenpyouInputItemType.KasikataGyouKugiri:
                    return "伝票の行区切り";
                case DenpyouInputItemType.CommonTekiyou:
                    return "摘要";
                case DenpyouInputItemType.CommonTekiyouInput:
                    return "摘要コード";
                default:
                    return null;
            }
        }

        public static SiwakeTaisyakuZokusei GetSiwakeTaisyakuZokusei(this DenpyouInputItemType denpyouInputItemType)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.KarikataBumon:
                case DenpyouInputItemType.KarikataTorihikisaki:
                case DenpyouInputItemType.KarikataKamoku:
                case DenpyouInputItemType.KarikataEdaban:
                case DenpyouInputItemType.KarikataKouzi:
                case DenpyouInputItemType.KarikataKousyu:
                case DenpyouInputItemType.KarikataProject:
                case DenpyouInputItemType.KarikataSegment:
                case DenpyouInputItemType.KarikataUniversalField1:
                case DenpyouInputItemType.KarikataUniversalField2:
                case DenpyouInputItemType.KarikataUniversalField3:
                case DenpyouInputItemType.KarikataTekiyou:
                case DenpyouInputItemType.KarikataZiyuuTekiyou:
                case DenpyouInputItemType.KarikataImageTekiyou:
                case DenpyouInputItemType.KarikataTekiyouInput:
                case DenpyouInputItemType.KarikataTaika:
                case DenpyouInputItemType.KarikataKingaku:
                case DenpyouInputItemType.KarikataZeigaku:
                case DenpyouInputItemType.KarikataZeitaisyouKamoku:
                case DenpyouInputItemType.KarikataZeitaisyouKamokuZeiritu:
                case DenpyouInputItemType.KarikataZeitaisyouKamokuKazeiKubun:
                case DenpyouInputItemType.KarikataZeitaisyouKamokuGyousyuKubun:
                case DenpyouInputItemType.KarikataZeitaisyouKamokuSiireKubun:
                case DenpyouInputItemType.KarikataZeiritu:
                case DenpyouInputItemType.KarikataKazeiKubun:
                case DenpyouInputItemType.KarikataGyousyuKubun:
                case DenpyouInputItemType.KarikataSiireKubun:
                case DenpyouInputItemType.KarikataBunriKubun:
                case DenpyouInputItemType.KarikataSiharaibi:
                case DenpyouInputItemType.KarikataSiharaiKubun:
                case DenpyouInputItemType.KarikataSiharaiKizitu:
                case DenpyouInputItemType.KarikataKaisyuubi:
                case DenpyouInputItemType.KarikataNyuukinKubun:
                case DenpyouInputItemType.KarikataKaisyuuKizitu:
                case DenpyouInputItemType.KarikataKesikomiCode:
                case DenpyouInputItemType.KarikataHusen:
                case DenpyouInputItemType.KarikataHusenDisplay:
                case DenpyouInputItemType.KarikataSyokuti:
                case DenpyouInputItemType.KarikataSyokutiEdaban:
                case DenpyouInputItemType.KarikataRate:
                case DenpyouInputItemType.KarikataGaikaKingaku:
                case DenpyouInputItemType.KarikataGaikaTaika:
                case DenpyouInputItemType.KarikataGaikaZeigaku:
                case DenpyouInputItemType.KarikataHeisyuCode:
                case DenpyouInputItemType.KarikataTaisyakubetuTekiyou:
                case DenpyouInputItemType.KarikataUniversalField4:
                case DenpyouInputItemType.KarikataUniversalField5:
                case DenpyouInputItemType.KarikataUniversalField6:
                case DenpyouInputItemType.KarikataUniversalField7:
                case DenpyouInputItemType.KarikataUniversalField8:
                case DenpyouInputItemType.KarikataUniversalField9:
                case DenpyouInputItemType.KarikataUniversalField10:
                case DenpyouInputItemType.KarikataUniversalField11:
                case DenpyouInputItemType.KarikataUniversalField12:
                case DenpyouInputItemType.KarikataUniversalField13:
                case DenpyouInputItemType.KarikataUniversalField14:
                case DenpyouInputItemType.KarikataUniversalField15:
                case DenpyouInputItemType.KarikataUniversalField16:
                case DenpyouInputItemType.KarikataUniversalField17:
                case DenpyouInputItemType.KarikataUniversalField18:
                case DenpyouInputItemType.KarikataUniversalField19:
                case DenpyouInputItemType.KarikataUniversalField20:
                    return SiwakeTaisyakuZokusei.Karikata;
                case DenpyouInputItemType.KasikataBumon:
                case DenpyouInputItemType.KasikataTorihikisaki:
                case DenpyouInputItemType.KasikataKamoku:
                case DenpyouInputItemType.KasikataEdaban:
                case DenpyouInputItemType.KasikataKouzi:
                case DenpyouInputItemType.KasikataKousyu:
                case DenpyouInputItemType.KasikataProject:
                case DenpyouInputItemType.KasikataSegment:
                case DenpyouInputItemType.KasikataUniversalField1:
                case DenpyouInputItemType.KasikataUniversalField2:
                case DenpyouInputItemType.KasikataUniversalField3:
                case DenpyouInputItemType.KasikataTekiyou:
                case DenpyouInputItemType.KasikataZiyuuTekiyou:
                case DenpyouInputItemType.KasikataImageTekiyou:
                case DenpyouInputItemType.KasikataTekiyouInput:
                case DenpyouInputItemType.KasikataTaika:
                case DenpyouInputItemType.KasikataKingaku:
                case DenpyouInputItemType.KasikataZeigaku:
                case DenpyouInputItemType.KasikataZeitaisyouKamoku:
                case DenpyouInputItemType.KasikataZeitaisyouKamokuZeiritu:
                case DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun:
                case DenpyouInputItemType.KasikataZeitaisyouKamokuGyousyuKubun:
                case DenpyouInputItemType.KasikataZeitaisyouKamokuSiireKubun:
                case DenpyouInputItemType.KasikataZeiritu:
                case DenpyouInputItemType.KasikataKazeiKubun:
                case DenpyouInputItemType.KasikataGyousyuKubun:
                case DenpyouInputItemType.KasikataSiireKubun:
                case DenpyouInputItemType.KasikataBunriKubun:
                case DenpyouInputItemType.KasikataSiharaibi:
                case DenpyouInputItemType.KasikataSiharaiKubun:
                case DenpyouInputItemType.KasikataSiharaiKizitu:
                case DenpyouInputItemType.KasikataKaisyuubi:
                case DenpyouInputItemType.KasikataNyuukinKubun:
                case DenpyouInputItemType.KasikataKaisyuuKizitu:
                case DenpyouInputItemType.KasikataKesikomiCode:
                case DenpyouInputItemType.KasikataHusen:
                case DenpyouInputItemType.KasikataHusenDisplay:
                case DenpyouInputItemType.KasikataSyokuti:
                case DenpyouInputItemType.KasikataSyokutiEdaban:
                case DenpyouInputItemType.KasikataRate:
                case DenpyouInputItemType.KasikataGaikaKingaku:
                case DenpyouInputItemType.KasikataGaikaTaika:
                case DenpyouInputItemType.KasikataGaikaZeigaku:
                case DenpyouInputItemType.KasikataHeisyuCode:
                case DenpyouInputItemType.KasikataTaisyakubetuTekiyou:
                case DenpyouInputItemType.KasikataUniversalField4:
                case DenpyouInputItemType.KasikataUniversalField5:
                case DenpyouInputItemType.KasikataUniversalField6:
                case DenpyouInputItemType.KasikataUniversalField7:
                case DenpyouInputItemType.KasikataUniversalField8:
                case DenpyouInputItemType.KasikataUniversalField9:
                case DenpyouInputItemType.KasikataUniversalField10:
                case DenpyouInputItemType.KasikataUniversalField11:
                case DenpyouInputItemType.KasikataUniversalField12:
                case DenpyouInputItemType.KasikataUniversalField13:
                case DenpyouInputItemType.KasikataUniversalField14:
                case DenpyouInputItemType.KasikataUniversalField15:
                case DenpyouInputItemType.KasikataUniversalField16:
                case DenpyouInputItemType.KasikataUniversalField17:
                case DenpyouInputItemType.KasikataUniversalField18:
                case DenpyouInputItemType.KasikataUniversalField19:
                case DenpyouInputItemType.KasikataUniversalField20:
                    return SiwakeTaisyakuZokusei.Kasikata;
                default:
                    return SiwakeTaisyakuZokusei.Taisyaku;
            }
        }
    }
}
