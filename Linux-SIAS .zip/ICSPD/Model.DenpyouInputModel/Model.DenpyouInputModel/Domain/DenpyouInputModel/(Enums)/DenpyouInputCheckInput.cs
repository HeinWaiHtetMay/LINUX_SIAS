﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputCheckInput
    {
        DisallowNotInput,
        WarnNotInput,
        RegardNotInputAs0,
    }
}
