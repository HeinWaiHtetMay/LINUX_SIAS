﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputTeikeiSiwakeDisplayPattern
    {
        DisplayOnInInputScreen = 0,
        DisplayAllPatterns = 1,
    }
}
