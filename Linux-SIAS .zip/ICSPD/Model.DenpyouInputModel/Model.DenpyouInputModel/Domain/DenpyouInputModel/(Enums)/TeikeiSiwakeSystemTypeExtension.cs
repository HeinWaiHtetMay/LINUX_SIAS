﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static class TeikeiSiwakeSystemTypeExtension
    {
        public static string GetOptionProgramId(this TeikeiSiwakeSystemType teikeiSiwakeSystemType)
        {
            switch (teikeiSiwakeSystemType)
            {
                case TeikeiSiwakeSystemType.Tuuzyou:
                    return "DINPFRI";
                case TeikeiSiwakeSystemType.BumonKeihi:
                    return "DINPBKEI";
                case TeikeiSiwakeSystemType.Busyo:
                    return "SFDINPFRI";
                case TeikeiSiwakeSystemType.BusyoBumonKeihi:
                default:
                    return "SFDINPBKEI";
            }
        }
    }
}
