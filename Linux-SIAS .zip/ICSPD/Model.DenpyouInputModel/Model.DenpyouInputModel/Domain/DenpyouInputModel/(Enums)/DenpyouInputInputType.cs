﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputInputType
    {
        Alphanumeric = 0,
        Hiragana = 1,
        Katakana = 2,
    }
}
