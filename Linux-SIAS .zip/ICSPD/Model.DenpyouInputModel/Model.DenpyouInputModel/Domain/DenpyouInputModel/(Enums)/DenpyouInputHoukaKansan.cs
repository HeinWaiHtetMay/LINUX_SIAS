﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputHoukaKansan
    {
        DoNotConvert = 0,
        Convert = 1,
        ConvertIfKingakuIsBlank = 2,
    }
}
