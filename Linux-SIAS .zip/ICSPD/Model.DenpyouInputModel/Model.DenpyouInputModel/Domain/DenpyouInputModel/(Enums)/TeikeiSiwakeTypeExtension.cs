﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static class TeikeiSiwakeTypeExtension
    {
        public static string GetName(this TeikeiSiwakeType teikeiSiwakeType) =>
            teikeiSiwakeType == TeikeiSiwakeType.CommonPattern ? "共通パターン" : "個人パターン";
    }
}
