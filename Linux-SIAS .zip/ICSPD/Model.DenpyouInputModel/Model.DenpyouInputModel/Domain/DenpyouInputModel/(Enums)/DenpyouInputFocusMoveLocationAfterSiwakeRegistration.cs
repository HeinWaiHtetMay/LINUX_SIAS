﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputFocusMoveLocationAfterSiwakeRegistration
    {
        DenpyouHizuke = 0,
        FirstSiwakeItem = 1,
    }
}
