﻿using System.Drawing;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static class DenpyouInputDefaultColor
    {
        /// <summary>
        /// フォーカス色デフォルト値(BGRコード)
        /// </summary>
        public static readonly Color FocusColor = Color.FromArgb(0xff, 0xeb, 0xa4);

        /// <summary>
        /// 未入力コード警告色(BGRコード)
        /// </summary>
        public static readonly Color NotInputCodeWarningColor = Color.FromArgb(0xff, 0xff, 0x40);
    }
}
