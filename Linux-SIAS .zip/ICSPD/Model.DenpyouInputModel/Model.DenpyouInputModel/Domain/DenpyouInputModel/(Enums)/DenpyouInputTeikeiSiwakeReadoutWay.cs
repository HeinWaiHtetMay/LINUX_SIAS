﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputTeikeiSiwakeReadoutWay
    {
        New = 0,
        Add = 1,
    }
}
