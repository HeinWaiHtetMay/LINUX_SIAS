﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public enum DenpyouInputSiwakeHukusyaType
    {
        DoNotCopy = 0,
        CopyPreviousItemsWhenFocusMoveFromNotInputItems = 1,
        CopyPreviousItemsWhenMoveFocusToSiwake = 2,
    }
}
