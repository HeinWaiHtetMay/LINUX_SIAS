﻿using System.Collections.Generic;
using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouInputDisplayKamokuPageRepository
    {
        IList<DenpyouInputDisplayKamokuPage> FindByKesnAndUserCodeOrderBySeqWithSecurity(int kesn, int userCode, SecurityKubun securityKubun, UserAndSyorikiSecurityContext securityContext);
    }
}