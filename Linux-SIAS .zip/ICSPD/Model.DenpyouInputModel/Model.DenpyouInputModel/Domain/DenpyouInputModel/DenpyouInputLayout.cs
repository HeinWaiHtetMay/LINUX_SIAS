﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;

    public class DenpyouInputLayout : IMasterData
    {
        /// <summary>
        /// マスター情報
        /// </summary>
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other) { Use = true, CodeMaxLength = 2, MasterCodeType = MasterCodeType.Numeric };

        public static readonly int MaxPatternNo = 99;

        public DenpyouInputLayout(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno)
        {
            this.Kesn = kesn;
            this.DenpyouKeisiki = denpyouKeisiki;
            this.Ptno = ptno;

            this.DenpyouLayoutItemList = new List<DenpyouInputLayoutItem>();
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 伝票種別（カラム名：dtyp）
        /// </summary>
        public DenpyouKeisiki DenpyouKeisiki { get; private set; }

        /// <summary>
        /// パターンｎｏ（カラム名：ptno）
        /// </summary>
        public int Ptno { get; private set; }

        /// <summary>
        /// パターン名称（カラム名：pnam）
        /// </summary>
        public string Pnam { get; set; }

        /// <summary>
        /// 1画面当りの仕訳数（カラム名：gcnt）
        /// </summary>
        public int Gcnt { get; set; }

        /// <summary>
        /// 1仕訳あたりの行数（カラム名：scnt）
        /// </summary>
        public int Scnt { get; set; }

        /// <summary>
        /// ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ表示（カラム名：hfflg）
        /// </summary>
        public bool ShowHeaderField { get; set; }

        public IList<DenpyouInputLayoutItem> DenpyouLayoutItemList { get; set; }

        public string Code => this.Ptno.ToString("D2");

        public string Name => this.Pnam;
        #endregion

        #region public methods

        /// <summary>
        /// 貸借別摘要チェックボックスのレイアウト項目を取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateTaisyakubetuTekiyouLayoutItem() =>
            new DenpyouInputLayoutItem(
                this.Kesn,
                this.DenpyouKeisiki,
                this.Ptno,
                this.DenpyouLayoutItemList.Count + 1,
                this.Scnt,
                1,
                DenpyouInputItemType.KarikataTaisyakubetuTekiyou);

        /// <summary>
        /// 手入力摘要のレイアウト項目を取得
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateTekiyouLayoutItem(DenpyouInputItemType denpyouInputItemType)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.KarikataTekiyou:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 2,
                        this.Scnt + 1,
                        1,
                        DenpyouInputItemType.KarikataTekiyou);
                case DenpyouInputItemType.KasikataTekiyou:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 3,
                        this.Scnt + 1,
                        4,
                        DenpyouInputItemType.KasikataTekiyou);
                default:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 2,
                        this.Scnt + 1,
                        2,
                        DenpyouInputItemType.CommonTekiyou);
            }
        }

        /// <summary>
        /// 摘要入力欄のレイアウト項目を取得
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateTekiyouInputLayoutItem(DenpyouInputItemType denpyouInputItemType)
        {
            switch (denpyouInputItemType)
            {
                case DenpyouInputItemType.KarikataTekiyouInput:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 2,
                        this.Scnt + 1,
                        1,
                        DenpyouInputItemType.KarikataTekiyouInput);
                case DenpyouInputItemType.KasikataTekiyouInput:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 3,
                        this.Scnt + 1,
                        4,
                        DenpyouInputItemType.KasikataTekiyouInput);
                default:
                    return new DenpyouInputLayoutItem(
                        this.Kesn,
                        this.DenpyouKeisiki,
                        this.Ptno,
                        this.DenpyouLayoutItemList.Count + 2,
                        this.Scnt + 1,
                        2,
                        DenpyouInputItemType.CommonTekiyouInput);
            }
        }

        /// <summary>
        /// 行区切りチェックボックスのレイアウト項目を取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateGyouKugiriInputLayoutItem() =>
            new DenpyouInputLayoutItem(
                this.Kesn,
                this.DenpyouKeisiki,
                this.Ptno,
                this.DenpyouLayoutItemList.Count + 4,
                this.Scnt,
                6,
                DenpyouInputItemType.KasikataGyouKugiri);

        /// <summary>
        /// 仕訳情報ボタンのレイアウト項目を取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateSiwakeZyouhouButtonInputLayoutItem() =>
            new DenpyouInputLayoutItem(
                this.Kesn,
                this.DenpyouKeisiki,
                this.Ptno,
                this.DenpyouLayoutItemList.Count + 5,
                this.Scnt,
                6,
                DenpyouInputItemType.KasikataSiwakeZyouhouButton);

        /// <summary>
        /// 行番号のレイアウト項目を取得
        /// </summary>
        /// <returns></returns>
        public DenpyouInputLayoutItem CreateLineNoItem() =>
            new DenpyouInputLayoutItem(
                this.Kesn,
                this.DenpyouKeisiki,
                this.Ptno,
                0,
                0,
                0,
                DenpyouInputItemType.LineNo);

        /// <summary>
        /// 指定属性の項目を含んでいるか
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public bool ContainsDenpyouInputItemType(DenpyouInputItemType denpyouInputItemType)
            => this.DenpyouLayoutItemList.FirstOrDefault(denpyouLayoutItem
                => denpyouLayoutItem.DenpyouInputItemType == denpyouInputItemType) != null;

        /// <summary>
        /// 指定属性の項目のタブ順序を取得
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public int GetTabOrder(DenpyouInputItemType denpyouInputItemType)
            => this.DenpyouLayoutItemList.FirstOrDefault(denpyouLayoutItem
                => denpyouLayoutItem.DenpyouInputItemType == denpyouInputItemType)?.Pseq ?? 0;
        #endregion
    }
}
