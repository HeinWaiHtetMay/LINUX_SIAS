﻿using System.Drawing;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouInputSyouninOption
    {
        /// <summary>
        /// [未承認]カラー
        /// </summary>
        Color MisyouninColor { get; }

        /// <summary>
        /// [否承認]カラー
        /// </summary>
        Color HininColor { get; }

        /// <summary>
        /// [承認]カラー
        /// </summary>
        Color SyouninColor { get; }

        /// <summary>
        /// 伝票入力者に否認状況メッセージを送信するかどうか
        /// </summary>
        bool IsSendHininStatusMessageDenpyouInputter { get; }

        /// <summary>
        /// 否認状況メッセージを"重要"として送信するかどうか
        /// </summary>
        bool IsSendAsImportantHininStatusMessage { get; }

        /// <summary>
        /// 否認状況メッセージを下位承認者にも送信するかどうか
        /// </summary>
        bool IsSendLowerSyouninsyaHininStatusMessage { get; }
    }
}
