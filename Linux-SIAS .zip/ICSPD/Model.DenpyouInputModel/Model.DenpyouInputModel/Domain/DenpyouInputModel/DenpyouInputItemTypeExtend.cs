﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public static partial class DenpyouInputItemTypeExtend
    {
        /// <summary>
        /// 項目の属性(ヘッダー、借方、貸方、共通)を取得
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public static DenpyouInputItemType GetDenpyouInputItemZokusei(DenpyouInputItemType denpyouInputItemType)
        {
            if ((denpyouInputItemType & DenpyouInputItemType.Header) != 0)
            {
                return DenpyouInputItemType.Header;
            }
            else if ((denpyouInputItemType & DenpyouInputItemType.Karikata) != 0)
            {
                return DenpyouInputItemType.Karikata;
            }
            else if ((denpyouInputItemType & DenpyouInputItemType.Kasikata) != 0)
            {
                return DenpyouInputItemType.Kasikata;
            }
            else if ((denpyouInputItemType & DenpyouInputItemType.Common) != 0)
            {
                return DenpyouInputItemType.Common;
            }
            else
            {
                return DenpyouInputItemType.NotUsed;
            }
        }

        /// <summary>
        /// 単一仕訳の場合に共通項目か
        /// </summary>
        /// <param name="denpyouInputItemType"></param>
        /// <returns></returns>
        public static bool IsCommonItemIfTannituSiwake(DenpyouInputItemType denpyouInputItemType) =>
            denpyouInputItemType == DenpyouInputItemType.KasikataZeitaisyouKamoku
            || denpyouInputItemType == DenpyouInputItemType.KasikataZeitaisyouKamokuZeiritu
            || denpyouInputItemType == DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun
            || denpyouInputItemType == DenpyouInputItemType.KasikataZeitaisyouKamokuGyousyuKubun
            || denpyouInputItemType == DenpyouInputItemType.KasikataZeitaisyouKamokuSiireKubun
            || denpyouInputItemType == DenpyouInputItemType.KasikataSiharaibi
            || denpyouInputItemType == DenpyouInputItemType.KasikataSiharaiKubun
            || denpyouInputItemType == DenpyouInputItemType.KasikataSiharaiKizitu
            || denpyouInputItemType == DenpyouInputItemType.KasikataKaisyuubi
            || denpyouInputItemType == DenpyouInputItemType.KasikataNyuukinKubun
            || denpyouInputItemType == DenpyouInputItemType.KasikataKaisyuuKizitu
            || denpyouInputItemType == DenpyouInputItemType.KasikataKesikomiCode
            || denpyouInputItemType == DenpyouInputItemType.KasikataHusen
            || denpyouInputItemType == DenpyouInputItemType.KasikataHusenDisplay
            || denpyouInputItemType == DenpyouInputItemType.KasikataTaika
            || denpyouInputItemType == DenpyouInputItemType.KasikataKingaku
            || denpyouInputItemType == DenpyouInputItemType.KasikataZeigaku
            || denpyouInputItemType == DenpyouInputItemType.KasikataRate
            || denpyouInputItemType == DenpyouInputItemType.KasikataGaikaKingaku
            || denpyouInputItemType == DenpyouInputItemType.KasikataGaikaTaika
            || denpyouInputItemType == DenpyouInputItemType.KasikataGaikaZeigaku
            || denpyouInputItemType == DenpyouInputItemType.KasikataHeisyuCode;
    }
}
