﻿using Icsp.Open21.Domain.DenpyouModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IDenpyouInputOptionRepository
    {
        /// <summary>
        /// 伝票入力、伝票修正用オプションを取得
        /// </summary>
        /// <param name="userno"></param>
        /// <param name="optionProgramId"></param>
        /// <param name="callerProgramDenpyouSiwakeWayToCreate"></param>
        /// <returns></returns>
        DenpyouInputOption FindDenpyouInputOptionByUsernoAndProgramId(int userno, string optionProgramId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate);

        /// <summary>
        /// 業務起動時の伝票形式を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreScreenAtOperationBoot(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// 共通パターンの選択値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreCommonPatternSelectionValue(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// 個人パターンの選択値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StorePersonalPatternSelectionValue(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// オプション設定ダイアログの設定値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="optionProgramId"></param>
        /// <param name="callerProgramDenpyouSiwakeWayToCreate"></param>
        void StoreDialogOption(DenpyouInputOption denpyouNyuryokuOption, string optionProgramId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate);

        /// <summary>
        /// 「課税区分等に選択番号を表示する」の設定値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreShowSelectionNumber(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// 「登録前に確認ﾒｯｾｰｼﾞを表示する」の設定値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreShowVerificationMessage(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// 「支払日が伝票日付以降かどうかﾁｪｯｸする」の設定値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreCheckSiharaibi(DenpyouInputOption denpyouNyuryokuOption, string programId);

        /// <summary>
        /// 「自動行区切りモード」の設定値を保存
        /// </summary>
        /// <param name="denpyouNyuryokuOption"></param>
        /// <param name="programId"></param>
        void StoreAutoGyokugiriMode(DenpyouInputOption denpyouNyuryokuOption, string programId);
    }
}
