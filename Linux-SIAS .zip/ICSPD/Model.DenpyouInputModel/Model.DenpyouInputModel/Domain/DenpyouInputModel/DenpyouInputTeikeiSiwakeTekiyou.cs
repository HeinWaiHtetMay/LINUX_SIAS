﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class DenpyouInputTeikeiSiwakeTekiyou
    {
        public bool IsCommon => this.UserCode == 10000;

        public int UserCode { get; set; }

        public string TekiyouCode => string.Format("{0, 2}", this.TekiyouNumber);

        public int TekiyouNumber { get; set; }

        public string TekiyouString { get; set; }

        public bool IsRegistrationTarget => !string.IsNullOrEmpty(this.TekiyouString);
    }
}
