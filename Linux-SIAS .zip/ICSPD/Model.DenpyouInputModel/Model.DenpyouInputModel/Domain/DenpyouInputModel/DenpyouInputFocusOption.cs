﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Icsp.Framework.Core.Serialization;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputFocusOption
    {
        /// <summary>
        /// 伝票番号を移動順序から除外
        /// </summary>
        public bool ExclusionDenpyouNoFromTabOrder { get; set; }

        /// <summary>
        /// 起票日を移動順序から除外
        /// </summary>
        public bool ExclusionKihyoubiFromTabOrder { get; set; }

        /// <summary>
        /// 起票者を移動順序から除外
        /// </summary>
        public bool ExclusionKihyousyaFromTabOrder { get; set; }

        /// <summary>
        /// 起票部門を移動順序から除外
        /// </summary>
        public bool ExclusionKihyouBumonFromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド1を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField1FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド2を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField2FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド3を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField3FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド4を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField4FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド5を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField5FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド6を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField6FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド7を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField7FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド8を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField8FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド9を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField9FromTabOrder { get; set; }

        /// <summary>
        /// ヘッダーフィールド10を移動順序から除外
        /// </summary>
        public bool ExclusionHeaderField10FromTabOrder { get; set; }

        /// <summary>
        /// 伝票束を移動順序から除外
        /// </summary>
        public bool ExclusionDenpyouTabaFromTabOrder { get; set; }

        /// <summary>
        /// 承認グループを移動順序から除外
        /// </summary>
        public bool ExclusionSyouninGroupFromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField1FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField2FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField3FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField4FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField5FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField6FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField7FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField8FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField9FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField10FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField11FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField12FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField13FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField14FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField15FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField16FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField17FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField18FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField19FromTabOrder { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20を移動順序から除外
        /// </summary>
        public bool ExclusionUniversalField20FromTabOrder { get; set; }

        /// <summary>
        /// プロジェクトを移動順序から除外
        /// </summary>
        public bool ExclusionProjectFromTabOrder { get; set; }

        /// <summary>
        /// セグメントを移動順序から除外
        /// </summary>
        public bool ExclusionSegmentFromTabOrder { get; set; }

        /// <summary>
        /// 工事を移動順序から除外
        /// </summary>
        public bool ExclusionKouziFromTabOrder { get; set; }

        /// <summary>
        /// 工種を移動順序から除外
        /// </summary>
        public bool ExclusionKousyuFromTabOrder { get; set; }

        /// <summary>
        /// 摘要コードを移動順序から除外
        /// </summary>
        public bool ExclusionTekiyouCodeFromTabOrder { get; set; }

        /// <summary>
        /// 消込コードを移動順序から除外
        /// </summary>
        public bool ExclusionKesikomiCodeFromTabOrder { get; set; }

        /// <summary>
        /// 付箋を移動順序から除外
        /// </summary>
        public bool ExclusionHusenFromTabOrder { get; set; }

        /// <summary>
        /// 行区切りを移動順序から除外
        /// </summary>
        public bool ExclusionGyoukugiriFromTabOrder { get; set; }

        /// <summary>
        /// 支払日を移動順序から除外
        /// </summary>
        public bool ExclusionSiharaibiFromTabOrder { get; set; }

        /// <summary>
        /// 支払区分を移動順序から除外
        /// </summary>
        public bool ExclusionSiharaiKubunFromTabOrder { get; set; }

        /// <summary>
        /// 支払期日を移動順序から除外
        /// </summary>
        public bool ExclusionSiharaiKizituFromTabOrder { get; set; }

        /// <summary>
        /// 回収日を移動順序から除外
        /// </summary>
        public bool ExclusionKaisyuubiFromTabOrder { get; set; }

        /// <summary>
        /// 入金区分を移動順序から除外
        /// </summary>
        public bool ExclusionNyuukinKubunFromTabOrder { get; set; }

        /// <summary>
        /// 回収期日を移動順序から除外
        /// </summary>
        public bool ExclusionKaisyuuKizituFromTabOrder { get; set; }

        /// <summary>
        /// 貸借別摘要を移動順序から除外
        /// </summary>
        public bool ExclusionTaisyakubetuTekiyoFromTabOrder { get; set; }

        /// <summary>
        /// 情報ボタンを移動順序から除外
        /// </summary>
        public bool ExclusionZyouhouButtonFromTabOrder { get; set; }

        /// <summary>
        /// 入力済み科目と紐付いていない項目を移動順序から除外
        /// </summary>
        public bool ExclusionItemNotAssociatedInKamokuFromTabOrder { get; set; }

        /// <summary>
        /// 科目の次項目が課税区分等、分離区分等の場合に課税区分の次項目へ移動
        /// </summary>
        public bool SkipKazeikubunIfKamokusNextForcusIsKazeikubunEtc { get; set; }

        /// <summary>
        /// 科目の次項目が課税区分等、分離区分等の場合に税率の次項目へ移動
        /// </summary>
        public bool SkipZeirituIfKamokusNextForcusIsKazeikubunEtc { get; set; }

        /// <summary>
        /// 科目の次項目が課税区分等、分離区分等の場合に分離区分の次項目へ移動
        /// </summary>
        public bool SkipBunrikubunIfKamokusNextForcusIsKazeikubunEtc { get; set; }

        /// <summary>
        /// 科目の次項目が課税区分等、分離区分等の場合に個別区分の次項目へ移動
        /// </summary>
        public bool SkipKobetuKubunIfKamokusNextForcusIsKazeikubunEtc { get; set; }

        /// <summary>
        /// 仕訳登録後のフォーカス移動位置
        /// </summary>
        public DenpyouInputFocusMoveLocationAfterSiwakeRegistration FocusMoveLocationAfterSiwakeRegistration { get; set; }

        /// <summary>
        /// 行の最後に摘要を入力する
        /// </summary>
        public bool InputTekiyoLastLine { get; set; }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputFocusOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);
    }
}