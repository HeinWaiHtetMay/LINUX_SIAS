﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Icsp.Framework.Core.Serialization;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputGaikaOption
    {
        public DenpyouInputHoukaKansan HoukaKansan { get; set; }

        public DenpyouInputCheckInput CheckGaikaKingakuInput { get; set; }

        public DenpyouInputCheckInput CheckRateInput { get; set; }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputGaikaOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);
    }
}
