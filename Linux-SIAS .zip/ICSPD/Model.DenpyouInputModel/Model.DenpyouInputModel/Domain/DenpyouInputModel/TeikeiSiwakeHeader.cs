﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public class TeikeiSiwakeHeader : ICreatedAndLastUpdatedYmdHmsEntity
    {
        /////// <summary>
        /////// マスター情報
        /////// </summary>
        ////public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other) { Use = true, CodeMaxLength = 4, MasterCodeType = MasterCodeType.Numeric };

        public TeikeiSiwakeHeader(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber)
        {
            this.TeikeiSiwakeSystemType = teikeiSiwakeSystemType;
            this.UserCode = userCode;
            this.PatternNumber = patternNumber;
        }

        #region public properties

        /// <summary>
        /// システム種別（カラム名：styp）
        /// </summary>
        public TeikeiSiwakeSystemType TeikeiSiwakeSystemType { get; private set; }

        /// <summary>
        /// パターン種別
        /// </summary>
        public TeikeiSiwakeType TeikeiSiwakeType => this.UserCode == 0 ? TeikeiSiwakeType.CommonPattern : TeikeiSiwakeType.PersonalPattern;

        /// <summary>
        /// パターン種別（カラム名：ptyp）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// パターンｎｏ（カラム名：ptno）
        /// </summary>
        public int PatternNumber { get; private set; }

        /// <summary>
        /// "パターン 伝票種別"（カラム名：pdtp）
        /// </summary>
        public DenpyouKeisiki DenpyouKeisiki { get; set; }

        /// <summary>
        /// "入力フォーム テーブルｎｏ"（カラム名：tbno）
        /// </summary>
        public int DenpyouInputLayoutPatternNumber { get; set; }

        /// <summary>
        /// 名称（カラム名：pnam）
        /// </summary>
        public string PatternName { get; set; }

        /// <summary>
        /// 伝票日付（カラム名：dymd）
        /// </summary>
        public int? DenpyouHizuke { get; set; }

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        public int? DenpyouNo { get; set; }

        /// <summary>
        /// 起票日付（カラム名：kymd）
        /// </summary>
        public int? Kihyoubi { get; set; }

        /// <summary>
        /// 起票部門（カラム名：kbmn）
        /// </summary>
        public string KihyouBumonCode { get; set; }

        /// <summary>
        /// 起票者（カラム名：kusr）
        /// </summary>
        public string KihyousyaCode { get; set; }

        /// <summary>
        /// 承認グループ（カラム名：sgno）
        /// </summary>
        public int SyouninGroupNumber { get; set; }

        /// <summary>
        /// 重付番号（カラム名：omno）
        /// </summary>
        public int WeightNumber { get; set; }

        /// <summary>
        /// 使用回数（カラム名：ucnt）
        /// </summary>
        public int UseTimes { get; set; }

        /// <summary>
        /// 最終使用日付（カラム名：umod）
        /// </summary>
        public int LastUseDate { get; set; }

        /// <summary>
        /// 最終使用時間（カラム名：utim）
        /// </summary>
        public int LastUseTime { get; set; }

        /// <summary>
        /// "作成変更 ユーザーno"（カラム名：lusr）
        /// </summary>
        public int UpdateUserCode { get; set; }

        /// <summary>
        /// 作成変更年月日（カラム名：lmod）
        /// </summary>
        public int UpdateDate { get; set; }

        /// <summary>
        /// 作成変更時間（カラム名：ltim）
        /// </summary>
        public int UpdateTime { get; set; }

        /// <summary>
        /// 伝票束コード（カラム名：cdm1）
        /// </summary>
        public string DenpyouTabaCode { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1（カラム名：duf1）
        /// </summary>
        public string HeaderField1Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2（カラム名：duf2）
        /// </summary>
        public string HeaderField2Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3（カラム名：duf3）
        /// </summary>
        public string HeaderField3Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4（カラム名：duf4）
        /// </summary>
        public string HeaderField4Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5（カラム名：duf5）
        /// </summary>
        public string HeaderField5Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6（カラム名：duf6）
        /// </summary>
        public string HeaderField6Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7（カラム名：duf7）
        /// </summary>
        public string HeaderField7Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8（カラム名：duf8）
        /// </summary>
        public string HeaderField8Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9（カラム名：duf9）
        /// </summary>
        public string HeaderField9Code { get; set; }

        /// <summary>
        /// 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10（カラム名：duf10）
        /// </summary>
        public string HeaderField10Code { get; set; }

        /// <summary>
        /// 摘要No
        /// </summary>
        public int? TekiyouNumber { get; set; }

        /// <summary>
        /// 摘要文字列
        /// </summary>
        public string TekiyouString { get; set; }

        public int CreatedYmd
        {
            get => this.UpdateDate;
            set => this.UpdateDate = value;
        }

        public int CreatedHms
        {
            get => this.UpdateTime;
            set => this.UpdateTime = value;
        }

        public int LastUpdatedYmd
        {
            get => this.UpdateDate;
            set => this.UpdateDate = value;
        }

        public int LastUpdatedHms
        {
            get => this.UpdateTime;
            set => this.UpdateTime = value;
        }

        public SecondPrecision SecondPrecision => SecondPrecision.Second;

        public string Code => this.PatternNumber.ToString("0000");

        public string DenpyouKeisikiString => this.DenpyouKeisiki.GetShortName();

        public string WeightNumberString => string.Format("{0, 4}", this.WeightNumber);

        public string Name => this.PatternName;

        public string TekiyouNumberString => string.Format("{0, 2}", this.TekiyouNumber);
        #endregion
    }
}
