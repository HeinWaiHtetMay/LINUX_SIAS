﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface IRensouTekiyouPageRepository
    {
        /// <summary>
        /// 連想摘要を取得
        /// 個人用が取得できなかった場合は共通用を取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="ucod"></param>
        /// <param name="kicd"></param>
        /// <returns></returns>
        RensouTekiyouPage FindByKesnAndUcodAndKicd(int kesn, int ucod, string kicd);
    }
}