﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class RensouTekiyouPage
    {
        private static readonly int CommonUserCode = 10000;

        public RensouTekiyouPage(int kesn, int userCode, int pageNumber)
        {
            this.Kesn = kesn;
            ////this.Tsw0 = tsw0;
            this.UserCode = userCode;
            this.PageNumber = pageNumber;
            this.RensouTekiyouList = new List<RensouTekiyou>();
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /////// <summary>
        /////// 共通・個別区分（カラム名：tsw0）
        /////// </summary>
        ////public int Tsw0 { get; private set; }

        /// <summary>
        /// ユーザー番号（カラム名：ucod）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// ページ番号（カラム名：rtno）
        /// </summary>
        public int PageNumber { get; private set; }

        /// <summary>
        /// ページ名称（カラム名：pnam）
        /// </summary>
        public string PageName { get; set; }

        /// <summary>
        /// 連想摘要
        /// </summary>
        public IList<RensouTekiyou> RensouTekiyouList { get; set; }

        /// <summary>
        /// 個人用か
        /// </summary>
        public bool IsPersonalRensouTekiyou => this.UserCode != CommonUserCode;
        #endregion
    }
}
