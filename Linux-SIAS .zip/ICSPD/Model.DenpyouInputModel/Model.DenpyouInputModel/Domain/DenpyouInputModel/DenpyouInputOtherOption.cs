﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Icsp.Framework.Core.Serialization;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputOtherOption
    {
        /// <summary>
        /// 伝票入力用
        /// 金額未入力仕訳の登録
        /// </summary>
        public bool RegisterKingakuMinyuryokuSiwake { get; set; }

        /// <summary>
        /// 伝票入力用
        /// 伝票登録後、空行削除の実行
        /// </summary>
        public bool RemoveEmptyLineWhenDenpyouRegister { get; set; }

        /// <summary>
        /// 伝票入力用
        /// 登録後のデータクリア
        /// </summary>
        public bool ClearDenpyouAfterRegstration { get; set; }

        /// <summary>
        /// 入力項目の背景色:フォーカス色
        /// </summary>
        public Color FocusColor { get; set; }

        /// <summary>
        /// 入力項目の背景色:フォーカス色
        /// </summary>
        public Color NotInputCodeWarningColor { get; set; }

        /// <summary>
        /// 貸借別摘要区分初期値の設定
        /// </summary>
        public bool MakeTaisyakubetuTekiyoDefaultValue { get; set; }

        /// <summary>
        /// 伝票修正用
        /// 自動生成子仕訳の直接編集の可否
        /// </summary>
        public bool EditableZidouKosiwake { get; set; }

        /// <summary>
        /// 伝票修正用
        /// 自動生成親仕訳を修正時に自動生成子仕訳への連動有無
        /// </summary>
        public bool LinkToZidouKosiwakeWhenEditOyasiwake { get; set; }

        /// <summary>
        /// データスキャン用
        /// 登録確認をおこなうタイミングの設定
        /// </summary>
        public DenpyouInputTourokuKakuninTiming TourokuKakuninTiming { get; set; }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputOtherOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);
    }
}
