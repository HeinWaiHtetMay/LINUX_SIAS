﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class DenpyouInputDisplayKamoku
    {
        public DenpyouInputDisplayKamoku(int kesn, int userCode, int hkpn, int seq)
        {
            this.Kesn = kesn;
            this.UserCode = userCode;
            this.PageNumber = hkpn;
            this.Seq = seq;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// ユーザー番号（カラム名：ucod）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// ページ番号（カラム名：hkpn）
        /// </summary>
        public int PageNumber { get; private set; }

        /// <summary>
        /// ｓｅｑ（カラム名：seq）
        /// </summary>
        public int Seq { get; private set; }

        /// <summary>
        /// 科目内部コード（カラム名：kicd）
        /// </summary>
        public Kamoku DisplayKamoku { get; set; }
        #endregion
    }
}
