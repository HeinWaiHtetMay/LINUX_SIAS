﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public class DenpyouInputDisplayKamokuPage
    {
        private static readonly int CommonUserCode = 10000;

        public DenpyouInputDisplayKamokuPage(int kesn, int userCode, int pageNumber)
        {
            this.Kesn = kesn;
            this.UserCode = userCode;
            this.PageNumber = pageNumber;
            this.DisplayKamokuList = new List<DenpyouInputDisplayKamoku>();
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// ユーザー番号（カラム名：ucod）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// ページ番号（カラム名：hkpn）
        /// </summary>
        public int PageNumber { get; private set; }

        /// <summary>
        /// ページ名称（カラム名：pnam）
        /// </summary>
        public string PageName { get; set; }

        public IList<DenpyouInputDisplayKamoku> DisplayKamokuList { get; set; }

        /// <summary>
        /// 個人用か
        /// </summary>
        public bool IsPersonalDenpyouInputDisplayKamoku => this.UserCode != CommonUserCode;
        #endregion
    }
}
