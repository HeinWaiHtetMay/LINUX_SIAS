﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public class TeikeiSiwakeGyou
    {
        public TeikeiSiwakeGyou(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber, int lineNumber)
        {
            this.TeikeiSiwakeSystemType = teikeiSiwakeSystemType;
            this.UserCode = userCode;
            this.PatternNumber = patternNumber;
            this.LineNo = lineNumber;
        }

        #region public properties

        /// <summary>
        /// システム種別　　（カラム名：styp）
        /// </summary>
        public TeikeiSiwakeSystemType TeikeiSiwakeSystemType { get; private set; }

        /// <summary>
        /// 共通パターンor個人パターン
        /// </summary>
        public TeikeiSiwakeType TeikeiSiwakeType => this.UserCode == 0
            ? TeikeiSiwakeType.CommonPattern
            : TeikeiSiwakeType.PersonalPattern;

        /// <summary>
        /// パターン種別（カラム名：ptyp）
        /// </summary>
        public int UserCode { get; private set; }

        /// <summary>
        /// パターンｎｏ（カラム名：ptno）
        /// </summary>
        public int PatternNumber { get; private set; }

        /// <summary>
        /// 伝票行（カラム名：dlin）
        /// </summary>
        public int LineNo { get; private set; }

        /// <summary>
        /// 行区切（カラム名：gflg）
        /// </summary>
        public bool IsGyouKugiri { get; set; }

        /// <summary>
        /// 自動仕訳行（カラム名：aflg）
        /// </summary>
        public TeikeiSiwakeBunriType BunriType { get; set; }

        /// <summary>
        /// 借）部門（カラム名：rbmn）
        /// </summary>
        public string KarikataBumonCode { get; set; }

        /// <summary>
        /// 借）取引先（カラム名：rtor）
        /// </summary>
        public string KarikataTorihikisakiCode { get; set; }

        /// <summary>
        /// 借）科目（カラム名：rkmk）
        /// </summary>
        public string KarikataKamokuCode { get; set; }

        /// <summary>
        /// 借）枝番（カラム名：reda）
        /// </summary>
        public string KarikataEdabanCode { get; set; }

        /// <summary>
        /// 借）工事（カラム名：rkoj）
        /// </summary>
        public string KarikataKouziCode { get; set; }

        /// <summary>
        /// 借）工種（カラム名：rkos）
        /// </summary>
        public string KarikataKousyuCode { get; set; }

        /// <summary>
        /// 借）ﾌﾟﾛｼﾞｪｸﾄ（カラム名：rprj）
        /// </summary>
        public string KarikataProjectCode { get; set; }

        /// <summary>
        /// 借）ｾｸﾞﾒﾝﾄ（カラム名：rseg）
        /// </summary>
        public string KarikataSegmentCode { get; set; }

        /// <summary>
        /// "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"（カラム名：rdm1）
        /// </summary>
        public string KarikataUniversalField1Code { get; set; }

        /// <summary>
        /// "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"（カラム名：rdm2）
        /// </summary>
        public string KarikataUniversalField2Code { get; set; }

        /// <summary>
        /// "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"（カラム名：rdm3）
        /// </summary>
        public string KarikataUniversalField3Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"（カラム名：rdm4）
        /// </summary>
        public string KarikataUniversalField4Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"（カラム名：rdm5）
        /// </summary>
        public string KarikataUniversalField5Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"（カラム名：rdm6）
        /// </summary>
        public string KarikataUniversalField6Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"（カラム名：rdm7）
        /// </summary>
        public string KarikataUniversalField7Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"（カラム名：rdm8）
        /// </summary>
        public string KarikataUniversalField8Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"（カラム名：rdm9）
        /// </summary>
        public string KarikataUniversalField9Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"（カラム名：rdm10）
        /// </summary>
        public string KarikataUniversalField10Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"（カラム名：rdm11）
        /// </summary>
        public string KarikataUniversalField11Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"（カラム名：rdm12）
        /// </summary>
        public string KarikataUniversalField12Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"（カラム名：rdm13）
        /// </summary>
        public string KarikataUniversalField13Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"（カラム名：rdm14）
        /// </summary>
        public string KarikataUniversalField14Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"（カラム名：rdm15）
        /// </summary>
        public string KarikataUniversalField15Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"（カラム名：rdm16）
        /// </summary>
        public string KarikataUniversalField16Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"（カラム名：rdm17）
        /// </summary>
        public string KarikataUniversalField17Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"（カラム名：rdm18）
        /// </summary>
        public string KarikataUniversalField18Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"（カラム名：rdm19）
        /// </summary>
        public string KarikataUniversalField19Code { get; set; }

        /// <summary>
        /// "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"（カラム名：rdm20）
        /// </summary>
        public string KarikataUniversalField20Code { get; set; }

        /// <summary>
        /// 借）摘要（カラム名：rtky）
        /// </summary>
        public string KarikataTekiyou { get; set; }

        /// <summary>
        /// 借）摘要ｺｰﾄﾞ（カラム名：rtno）
        /// </summary>
        public int? KarikataTekiyouCode { get; set; }

        /// <summary>
        /// 借）ｲﾒｰｼﾞ（カラム名：rimg）
        /// </summary>
        public int KarikataTekiyouImage { get; set; }

        /// <summary>
        /// 借）対価（カラム名：rexv）
        /// </summary>
        public decimal? KarikataTaika { get; set; }

        /// <summary>
        /// 借）金額（カラム名：rval）
        /// </summary>
        public decimal? KarikataKingaku { get; set; }

        /// <summary>
        /// 借）税額（カラム名：rzei）
        /// </summary>
        public decimal? KarikataZeigaku { get; set; }

        /// <summary>
        /// 借）税率（カラム名：rrit）
        /// </summary>
        public int? KarikataZeiritu { get; set; }

        /// <summary>
        /// 借）課税区分（カラム名：rzkb）
        /// </summary>
        public KazeiKubun? KarikataKazeiKubun { get; set; }

        /// <summary>
        /// 借）業種区分（カラム名：rgyo）
        /// </summary>
        public GyousyuKubun? KarikataGyousyuKubun { get; set; }

        /// <summary>
        /// 借）個別区分（カラム名：rsre）
        /// </summary>
        public SiwakeSiireKubun? KarikataSiireKubun { get; set; }

        /// <summary>
        /// 借）分離区分（カラム名：rbkbn）
        /// </summary>
        public BunriKubun? KarikataBunriKubun { get; set; }

        /// <summary>
        /// 借）消込（カラム名：rdkec）
        /// </summary>
        public string KarikataKesikomiCode { get; set; }

        /// <summary>
        /// 借）付箋（カラム名：rfsen）
        /// </summary>
        public SiwakeHusen KarikataHusen { get; set; }

        /// <summary>
        /// 借）諸口区分（カラム名：rsyok）
        /// </summary>
        public int? KarikataSyokutiKubun { get; set; }

        /// <summary>
        /// 借）諸口枝番（カラム名：rsyoe）
        /// </summary>
        public string KarikataSyokutiEdaban { get; set; }

        /// <summary>
        /// 借）支払日（カラム名：rsymd）
        /// </summary>
        public int? KarikataSiharaibi { get; set; }

        /// <summary>
        /// 借）支払区分（カラム名：rskbn）
        /// </summary>
        public int? KarikataSiharaiKubun { get; set; }

        /// <summary>
        /// 借）支払期日（カラム名：rskiz）
        /// </summary>
        public int? KarikataSiharaiKizitu { get; set; }

        /// <summary>
        /// 借）受取日（カラム名：ruymd）
        /// </summary>
        public int? KarikataKaisyuubi { get; set; }

        /// <summary>
        /// 借）受取区分（カラム名：rukbn）
        /// </summary>
        public int? KarikataNyuukinKubun { get; set; }

        /// <summary>
        /// 借）受取期日（カラム名：rukiz）
        /// </summary>
        public int? KarikataKaisyuuKizitu { get; set; }

        /// <summary>
        /// 借）税額－科目（カラム名：rzkmk）
        /// </summary>
        public string KarikataZeitaisyouKamokuCode { get; set; }

        /// <summary>
        /// 借）税額－税率（カラム名：rzrit）
        /// </summary>
        public int? KarikataZeitaisyouKamokuZeiritu { get; set; }

        /// <summary>
        /// "借）税額－ 課税区分"（カラム名：rzzkb）
        /// </summary>
        public KazeiKubun? KarikataZeitaisyouKamokuKazeiKubun { get; set; }

        /// <summary>
        /// "借）税額－ 業種区分"（カラム名：rzgyo）
        /// </summary>
        public GyousyuKubun? KarikataZeitaisyouKamokuGyousyuKubun { get; set; }

        /// <summary>
        /// "借）税額－ 個別区分"（カラム名：rzsre）
        /// </summary>
        public SiwakeSiireKubun? KarikataZeitaisyouKamokuSiireKubun { get; set; }

        /// <summary>
        /// 借）通貨コード（カラム名：rhei_cd）
        /// </summary>
        public string KarikataHeisyuCode { get; set; }

        /// <summary>
        /// 借）レート（カラム名：rrate）
        /// </summary>
        public decimal? KarikataRate { get; set; }

        /// <summary>
        /// 借）外貨金額（カラム名：rgaika）
        /// </summary>
        public decimal? KarikataGaikaKingaku { get; set; }

        /// <summary>
        /// 借）外貨対価（カラム名：rgexvl）
        /// </summary>
        public decimal? KarikataGaikaTaika { get; set; }

        /// <summary>
        /// 借）外貨税額（カラム名：rgzei）
        /// </summary>
        public decimal? KarikataGaikaZeigaku { get; set; }

        /// <summary>
        /// 貸）部門（カラム名：sbmn）
        /// </summary>
        public string KasikataBumonCode { get; set; }

        /// <summary>
        /// 貸）取引先（カラム名：stor）
        /// </summary>
        public string KasikataTorihikisakiCode { get; set; }

        /// <summary>
        /// 貸）科目（カラム名：skmk）
        /// </summary>
        public string KasikataKamokuCode { get; set; }

        /// <summary>
        /// 貸）枝番（カラム名：seda）
        /// </summary>
        public string KasikataEdabanCode { get; set; }

        /// <summary>
        /// 貸）工事（カラム名：skoj）
        /// </summary>
        public string KasikataKouziCode { get; set; }

        /// <summary>
        /// 貸）工種（カラム名：skos）
        /// </summary>
        public string KasikataKousyuCode { get; set; }

        /// <summary>
        /// 貸）ﾌﾟﾛｼﾞｪｸﾄ（カラム名：sprj）
        /// </summary>
        public string KasikataProjectCode { get; set; }

        /// <summary>
        /// 貸）ｾｸﾞﾒﾝﾄ（カラム名：sseg）
        /// </summary>
        public string KasikataSegmentCode { get; set; }

        /// <summary>
        /// "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"（カラム名：sdm1）
        /// </summary>
        public string KasikataUniversalField1Code { get; set; }

        /// <summary>
        /// "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"（カラム名：sdm2）
        /// </summary>
        public string KasikataUniversalField2Code { get; set; }

        /// <summary>
        /// "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"（カラム名：sdm3）
        /// </summary>
        public string KasikataUniversalField3Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"（カラム名：sdm4）
        /// </summary>
        public string KasikataUniversalField4Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"（カラム名：sdm5）
        /// </summary>
        public string KasikataUniversalField5Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"（カラム名：sdm6）
        /// </summary>
        public string KasikataUniversalField6Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"（カラム名：sdm7）
        /// </summary>
        public string KasikataUniversalField7Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"（カラム名：sdm8）
        /// </summary>
        public string KasikataUniversalField8Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"（カラム名：sdm9）
        /// </summary>
        public string KasikataUniversalField9Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"（カラム名：sdm10）
        /// </summary>
        public string KasikataUniversalField10Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"（カラム名：sdm11）
        /// </summary>
        public string KasikataUniversalField11Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"（カラム名：sdm12）
        /// </summary>
        public string KasikataUniversalField12Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"（カラム名：sdm13）
        /// </summary>
        public string KasikataUniversalField13Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"（カラム名：sdm14）
        /// </summary>
        public string KasikataUniversalField14Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"（カラム名：sdm15）
        /// </summary>
        public string KasikataUniversalField15Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"（カラム名：sdm16）
        /// </summary>
        public string KasikataUniversalField16Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"（カラム名：sdm17）
        /// </summary>
        public string KasikataUniversalField17Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"（カラム名：sdm18）
        /// </summary>
        public string KasikataUniversalField18Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"（カラム名：sdm19）
        /// </summary>
        public string KasikataUniversalField19Code { get; set; }

        /// <summary>
        /// "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"（カラム名：sdm20）
        /// </summary>
        public string KasikataUniversalField20Code { get; set; }

        /// <summary>
        /// 貸）摘要（カラム名：stky）
        /// </summary>
        public string KasikataTekiyou { get; set; }

        /// <summary>
        /// 貸）摘要ｺｰﾄﾞ（カラム名：stno）
        /// </summary>
        public int? KasikataTekiyouCode { get; set; }

        /// <summary>
        /// 貸）ｲﾒｰｼﾞ（カラム名：simg）
        /// </summary>
        public int KasikataTekiyouImage { get; set; }

        /// <summary>
        /// 貸）対価（カラム名：sexv）
        /// </summary>
        public decimal? KasikataTaika { get; set; }

        /// <summary>
        /// 貸）金額（カラム名：sval）
        /// </summary>
        public decimal? KasikataKingaku { get; set; }

        /// <summary>
        /// 貸）税額（カラム名：szei）
        /// </summary>
        public decimal? KasikataZeigaku { get; set; }

        /// <summary>
        /// 貸）税率（カラム名：srit）
        /// </summary>
        public int? KasikataZeiritu { get; set; }

        /// <summary>
        /// 貸）課税区分（カラム名：szkb）
        /// </summary>
        public KazeiKubun? KasikataKazeiKubun { get; set; }

        /// <summary>
        /// 貸）業種区分（カラム名：sgyo）
        /// </summary>
        public GyousyuKubun? KasikataGyousyuKubun { get; set; }

        /// <summary>
        /// 貸）個別区分（カラム名：ssre）
        /// </summary>
        public SiwakeSiireKubun? KasikataSiireKubun { get; set; }

        /// <summary>
        /// 貸）分離区分（カラム名：sbkbn）
        /// </summary>
        public BunriKubun? KasikataBunriKubun { get; set; }

        /// <summary>
        /// 貸）消込（カラム名：sdkec）
        /// </summary>
        public string KasikataKesikomiCode { get; set; }

        /// <summary>
        /// 貸）付箋（カラム名：sfsen）
        /// </summary>
        public SiwakeHusen KasikataHusen { get; set; }

        /// <summary>
        /// 貸）諸口区分（カラム名：ssyok）
        /// </summary>
        public int? KasikataSyokutiKubun { get; set; }

        /// <summary>
        /// 貸）諸口枝番（カラム名：ssyoe）
        /// </summary>
        public string KasikataSyokutiEdaban { get; set; }

        /// <summary>
        /// 貸）支払日（カラム名：ssymd）
        /// </summary>
        public int? KasikataSiharaibi { get; set; }

        /// <summary>
        /// 貸）支払区分（カラム名：sskbn）
        /// </summary>
        public int? KasikataSiharaiKubun { get; set; }

        /// <summary>
        /// 貸）支払期日（カラム名：sskiz）
        /// </summary>
        public int? KasikataSiharaiKizitu { get; set; }

        /// <summary>
        /// 貸）受取日（カラム名：suymd）
        /// </summary>
        public int? KasikataKaisyuubi { get; set; }

        /// <summary>
        /// 貸）受取区分（カラム名：sukbn）
        /// </summary>
        public int? KasikataNyuukinKubun { get; set; }

        /// <summary>
        /// 貸）受取期日（カラム名：sukiz）
        /// </summary>
        public int? KasikataKaisyuuKizitu { get; set; }

        /// <summary>
        /// 貸）税額－科目（カラム名：szkmk）
        /// </summary>
        public string KasikataZeitaisyouKamokuCode { get; set; }

        /// <summary>
        /// 貸）税額－税率（カラム名：szrit）
        /// </summary>
        public int? KasikataZeitaisyouKamokuZeiritu { get; set; }

        /// <summary>
        /// "貸）税額－ 課税区分"（カラム名：szzkb）
        /// </summary>
        public KazeiKubun? KasikataZeitaisyouKamokuKazeiKubun { get; set; }

        /// <summary>
        /// "貸）税額－ 業種区分"（カラム名：szgyo）
        /// </summary>
        public GyousyuKubun? KasikataZeitaisyouKamokuGyousyuKubun { get; set; }

        /// <summary>
        /// "貸）税額－ 個別区分"（カラム名：szsre）
        /// </summary>
        public SiwakeSiireKubun? KasikataZeitaisyouKamokuSiireKubun { get; set; }

        /// <summary>
        /// 貸）通貨コード（カラム名：shei_cd）
        /// </summary>
        public string KasikataHeisyuCode { get; set; }

        /// <summary>
        /// 貸）レート（カラム名：srate）
        /// </summary>
        public decimal? KasikataRate { get; set; }

        /// <summary>
        /// 貸）外貨金額（カラム名：sgaika）
        /// </summary>
        public decimal? KasikataGaikaKingaku { get; set; }

        /// <summary>
        /// 貸）外貨対価（カラム名：sgexvl）
        /// </summary>
        public decimal? KasikataGaikaTaika { get; set; }

        /// <summary>
        /// 貸）外貨税額（カラム名：sgzei）
        /// </summary>
        public decimal? KasikataGaikaZeigaku { get; set; }

        /// <summary>
        /// 貸借摘要フラグ（カラム名：tekiflg）
        /// </summary>
        public bool IsTaisyakubetuTekiyou { get; set; }

        /// <summary>
        /// 借）軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKarikata { get; set; }

        /// <summary>
        /// 借）税額－軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKarikataZeitaisyouKamoku { get; set; }

        /// <summary>
        /// 貸）軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKasikata { get; set; }

        /// <summary>
        /// 貸）税額－軽減税率区分
        /// </summary>
        public bool IsKeigenZeirituKasikataZeitaisyouKamoku { get; set; }

        /// <summary>
        /// 借方にデータがあるか
        /// </summary>
        public bool HasKarikataData =>
            !string.IsNullOrEmpty(this.KarikataBumonCode)
            || !string.IsNullOrEmpty(this.KarikataTorihikisakiCode)
            || !string.IsNullOrEmpty(this.KarikataKamokuCode)
            || !string.IsNullOrEmpty(this.KarikataEdabanCode)
            || !string.IsNullOrEmpty(this.KarikataKouziCode)
            || !string.IsNullOrEmpty(this.KarikataKousyuCode)
            || !string.IsNullOrEmpty(this.KarikataProjectCode)
            || !string.IsNullOrEmpty(this.KarikataSegmentCode)
            || !string.IsNullOrEmpty(this.KarikataUniversalField1Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField2Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField3Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField4Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField5Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField6Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField7Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField8Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField9Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField10Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField11Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField12Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField13Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField14Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField15Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField16Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField17Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField18Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField19Code)
            || !string.IsNullOrEmpty(this.KarikataUniversalField20Code)
            || !string.IsNullOrEmpty(this.KarikataTekiyou)
            || this.KarikataTekiyouCode != null
            || this.KarikataTaika != null
            || this.KarikataKingaku != null
            || !string.IsNullOrEmpty(this.KarikataKesikomiCode)
            || this.KarikataHusen != SiwakeHusen.Nothing
            || this.KarikataSyokutiKubun != null
            || !string.IsNullOrEmpty(this.KarikataSyokutiEdaban)
            || this.KarikataSiharaibi != null
            || this.KarikataSiharaiKubun != null
            || this.KarikataSiharaiKizitu != null
            || this.KarikataKaisyuubi != null
            || this.KarikataNyuukinKubun != null
            || this.KarikataKaisyuuKizitu != null
            || !string.IsNullOrEmpty(this.KarikataZeitaisyouKamokuCode)
            || this.KarikataRate != null
            || this.KarikataGaikaKingaku != null
            || this.KarikataGaikaTaika != null;

        /// <summary>
        /// 貸方にデータがあるか
        /// </summary>
        public bool HasKasikataData =>
            !string.IsNullOrEmpty(this.KasikataBumonCode)
            || !string.IsNullOrEmpty(this.KasikataTorihikisakiCode)
            || !string.IsNullOrEmpty(this.KasikataKamokuCode)
            || !string.IsNullOrEmpty(this.KasikataEdabanCode)
            || !string.IsNullOrEmpty(this.KasikataKouziCode)
            || !string.IsNullOrEmpty(this.KasikataKousyuCode)
            || !string.IsNullOrEmpty(this.KasikataProjectCode)
            || !string.IsNullOrEmpty(this.KasikataSegmentCode)
            || !string.IsNullOrEmpty(this.KasikataUniversalField1Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField2Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField3Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField4Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField5Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField6Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField7Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField8Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField9Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField10Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField11Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField12Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField13Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField14Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField15Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField16Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField17Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField18Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField19Code)
            || !string.IsNullOrEmpty(this.KasikataUniversalField20Code)
            || !string.IsNullOrEmpty(this.KasikataTekiyou)
            || this.KasikataTekiyouCode != null
            || this.KasikataTaika != null
            || this.KasikataKingaku != null
            || !string.IsNullOrEmpty(this.KasikataKesikomiCode)
            || this.KasikataHusen != SiwakeHusen.Nothing
            || this.KasikataSyokutiKubun != null
            || !string.IsNullOrEmpty(this.KasikataSyokutiEdaban)
            || this.KasikataSiharaibi != null
            || this.KasikataSiharaiKubun != null
            || this.KasikataSiharaiKizitu != null
            || this.KasikataKaisyuubi != null
            || this.KasikataNyuukinKubun != null
            || this.KasikataKaisyuuKizitu != null
            || !string.IsNullOrEmpty(this.KasikataZeitaisyouKamokuCode)
            || this.KasikataRate != null
            || this.KasikataGaikaKingaku != null
            || this.KasikataGaikaTaika != null;
        #endregion

        #region public methods

        /// <summary>
        /// 借方データをクリア
        /// </summary>
        public void ClearKarikataData()
        {
            this.KarikataBumonCode = null;
            this.KarikataTorihikisakiCode = null;
            this.KarikataKamokuCode = null;
            this.KarikataEdabanCode = null;
            this.KarikataKouziCode = null;
            this.KarikataKousyuCode = null;
            this.KarikataProjectCode = null;
            this.KarikataSegmentCode = null;
            this.KarikataUniversalField1Code = null;
            this.KarikataUniversalField2Code = null;
            this.KarikataUniversalField3Code = null;
            this.KarikataUniversalField4Code = null;
            this.KarikataUniversalField5Code = null;
            this.KarikataUniversalField6Code = null;
            this.KarikataUniversalField7Code = null;
            this.KarikataUniversalField8Code = null;
            this.KarikataUniversalField9Code = null;
            this.KarikataUniversalField10Code = null;
            this.KarikataUniversalField11Code = null;
            this.KarikataUniversalField12Code = null;
            this.KarikataUniversalField13Code = null;
            this.KarikataUniversalField14Code = null;
            this.KarikataUniversalField15Code = null;
            this.KarikataUniversalField16Code = null;
            this.KarikataUniversalField17Code = null;
            this.KarikataUniversalField18Code = null;
            this.KarikataUniversalField19Code = null;
            this.KarikataUniversalField20Code = null;
            this.KarikataTekiyou = null;
            this.KarikataTekiyouCode = null;
            this.KarikataTaika = null;
            this.KarikataKingaku = null;
            this.KarikataZeigaku = null;
            this.KarikataZeiritu = null;
            this.KarikataKazeiKubun = null;
            this.KarikataGyousyuKubun = null;
            this.KarikataSiireKubun = null;
            this.KarikataBunriKubun = null;
            this.KarikataKesikomiCode = null;
            this.KarikataHusen = SiwakeHusen.Nothing;
            this.KarikataSyokutiKubun = null;
            this.KarikataSyokutiEdaban = null;
            this.KarikataSiharaibi = null;
            this.KarikataSiharaiKubun = null;
            this.KarikataSiharaiKizitu = null;
            this.KarikataKaisyuubi = null;
            this.KarikataNyuukinKubun = null;
            this.KarikataKaisyuuKizitu = null;
            this.KarikataZeitaisyouKamokuCode = null;
            this.KarikataZeitaisyouKamokuZeiritu = null;
            this.KarikataZeitaisyouKamokuKazeiKubun = null;
            this.KarikataZeitaisyouKamokuGyousyuKubun = null;
            this.KarikataZeitaisyouKamokuSiireKubun = null;
            this.KarikataHeisyuCode = null;
            this.KarikataRate = null;
            this.KarikataGaikaKingaku = null;
            this.KarikataGaikaZeigaku = null;
            this.KarikataGaikaTaika = null;
            this.IsKeigenZeirituKarikata = false;
            this.IsKeigenZeirituKarikataZeitaisyouKamoku = false;
        }

        /// <summary>
        /// 貸方データをクリア
        /// </summary>
        public void ClearKasikataData()
        {
            this.KasikataBumonCode = null;
            this.KasikataTorihikisakiCode = null;
            this.KasikataKamokuCode = null;
            this.KasikataEdabanCode = null;
            this.KasikataKouziCode = null;
            this.KasikataKousyuCode = null;
            this.KasikataProjectCode = null;
            this.KasikataSegmentCode = null;
            this.KasikataUniversalField1Code = null;
            this.KasikataUniversalField2Code = null;
            this.KasikataUniversalField3Code = null;
            this.KasikataUniversalField4Code = null;
            this.KasikataUniversalField5Code = null;
            this.KasikataUniversalField6Code = null;
            this.KasikataUniversalField7Code = null;
            this.KasikataUniversalField8Code = null;
            this.KasikataUniversalField9Code = null;
            this.KasikataUniversalField10Code = null;
            this.KasikataUniversalField11Code = null;
            this.KasikataUniversalField12Code = null;
            this.KasikataUniversalField13Code = null;
            this.KasikataUniversalField14Code = null;
            this.KasikataUniversalField15Code = null;
            this.KasikataUniversalField16Code = null;
            this.KasikataUniversalField17Code = null;
            this.KasikataUniversalField18Code = null;
            this.KasikataUniversalField19Code = null;
            this.KasikataUniversalField20Code = null;
            this.KasikataTekiyou = null;
            this.KasikataTekiyouCode = null;
            this.KasikataTaika = null;
            this.KasikataKingaku = null;
            this.KasikataZeigaku = null;
            this.KasikataZeiritu = null;
            this.KasikataKazeiKubun = null;
            this.KasikataGyousyuKubun = null;
            this.KasikataSiireKubun = null;
            this.KasikataBunriKubun = null;
            this.KasikataKesikomiCode = null;
            this.KasikataHusen = SiwakeHusen.Nothing;
            this.KasikataSyokutiKubun = null;
            this.KasikataSyokutiEdaban = null;
            this.KasikataSiharaibi = null;
            this.KasikataSiharaiKubun = null;
            this.KasikataSiharaiKizitu = null;
            this.KasikataKaisyuubi = null;
            this.KasikataNyuukinKubun = null;
            this.KasikataKaisyuuKizitu = null;
            this.KasikataZeitaisyouKamokuCode = null;
            this.KasikataZeitaisyouKamokuZeiritu = null;
            this.KasikataZeitaisyouKamokuKazeiKubun = null;
            this.KasikataZeitaisyouKamokuGyousyuKubun = null;
            this.KasikataZeitaisyouKamokuSiireKubun = null;
            this.KasikataHeisyuCode = null;
            this.KasikataRate = null;
            this.KasikataGaikaKingaku = null;
            this.KasikataGaikaZeigaku = null;
            this.KasikataGaikaTaika = null;
            this.IsKeigenZeirituKasikata = false;
            this.IsKeigenZeirituKasikataZeitaisyouKamoku = false;
        }

        /// <summary>
        /// 税率と税額を変換
        /// </summary>
        /// <param name="denpyouKeisiki"></param>
        /// <param name="syouhizeiritu"></param>
        /// <param name="syouhizeiMaster"></param>
        /// <param name="useGaika"></param>
        /// <param name="kamokuHeisyuList"></param>
        /// <param name="heisyuDictionary"></param>
        public void ConvertZeirituAndZeigaku(
            DenpyouKeisiki denpyouKeisiki,
            Syouhizeiritu syouhizeiritu,
            SyouhizeiMaster syouhizeiMaster,
            bool useGaika,
            IList<KamokuHeisyu> kamokuHeisyuList,
            IDictionary<string, Heisyu> heisyuDictionary)
        {
            var zeirituMagnification = 10000;
            var zeirituForRegistration = (int?)syouhizeiritu.Zeiritu.GetValue() * zeirituMagnification;

            var isChangedKarikataZeiritu = false;
            var isChangedKasikataZeiritu = false;

            // 税率設定
            if (this.KarikataZeiritu != null && this.KarikataZeiritu != 0
                && (this.KarikataZeiritu != zeirituForRegistration || this.IsKeigenZeirituKarikata != syouhizeiritu.IsKeigenzeiritu))
            {
                this.KarikataZeiritu = zeirituForRegistration;
                this.IsKeigenZeirituKarikata = syouhizeiritu.IsKeigenzeiritu;
                isChangedKarikataZeiritu = true;
            }

            if (this.KasikataZeiritu != null && this.KasikataZeiritu != 0
                && (this.KasikataZeiritu != zeirituForRegistration || this.IsKeigenZeirituKasikata != syouhizeiritu.IsKeigenzeiritu))
            {
                this.KasikataZeiritu = zeirituForRegistration;
                this.IsKeigenZeirituKasikata = syouhizeiritu.IsKeigenzeiritu;
                isChangedKasikataZeiritu = true;
            }

            if (this.KarikataZeitaisyouKamokuZeiritu != null && this.KarikataZeitaisyouKamokuZeiritu != 0
                && (this.KarikataZeitaisyouKamokuZeiritu != zeirituForRegistration || this.IsKeigenZeirituKarikataZeitaisyouKamoku != syouhizeiritu.IsKeigenzeiritu))
            {
                this.KarikataZeitaisyouKamokuZeiritu = zeirituForRegistration;
                this.IsKeigenZeirituKarikataZeitaisyouKamoku = syouhizeiritu.IsKeigenzeiritu;
            }

            if (this.KasikataZeitaisyouKamokuZeiritu != null && this.KasikataZeitaisyouKamokuZeiritu != 0
                && (this.KasikataZeitaisyouKamokuZeiritu != zeirituForRegistration || this.IsKeigenZeirituKasikataZeitaisyouKamoku != syouhizeiritu.IsKeigenzeiritu))
            {
                this.KasikataZeitaisyouKamokuZeiritu = zeirituForRegistration;
                this.IsKeigenZeirituKasikataZeitaisyouKamoku = syouhizeiritu.IsKeigenzeiritu;
            }

            var shuoldCalculateZeigakuFromKarikata = isChangedKarikataZeiritu
                && (this.KarikataBunriKubun == BunriKubun.ZidouBunri
                || this.KarikataBunriKubun == BunriKubun.HurikaeSakusei
                || this.KarikataBunriKubun == BunriKubun.ZeiSakusei);

            var shuoldCalculateZeigakuFromKasikata = isChangedKasikataZeiritu
                && (this.KasikataBunriKubun == BunriKubun.ZidouBunri
                || this.KasikataBunriKubun == BunriKubun.HurikaeSakusei
                || this.KasikataBunriKubun == BunriKubun.ZeiSakusei);

            if (denpyouKeisiki == DenpyouKeisiki.Hukugou)
            {
                if (shuoldCalculateZeigakuFromKarikata)
                {
                    var calculationPrincipalAmount = this.KarikataTaika ?? this.KarikataKingaku;
                    this.KarikataZeigaku = calculationPrincipalAmount == null
                        ? (decimal?)null
                        : (this.KarikataBunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                            calculationPrincipalAmount ?? 0,
                            syouhizeiritu.Zeiritu,
                            syouhizeiMaster.ZeigakuRoundingType);
                }

                if (shuoldCalculateZeigakuFromKasikata)
                {
                    var calculationPrincipalAmount = this.KasikataTaika ?? this.KasikataKingaku;
                    this.KasikataZeigaku = calculationPrincipalAmount == null
                        ? (decimal?)null
                        : (this.KasikataBunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                            calculationPrincipalAmount ?? 0,
                            syouhizeiritu.Zeiritu,
                            syouhizeiMaster.ZeigakuRoundingType);
                }
            }
            else
            {
                if (isChangedKarikataZeiritu || isChangedKasikataZeiritu)
                {
                    var calculationPrincipalAmount = this.KasikataTaika ?? this.KasikataKingaku;
                    var bunriKubun = isChangedKarikataZeiritu ? this.KarikataBunriKubun : this.KasikataBunriKubun;
                    this.KasikataZeigaku = calculationPrincipalAmount == null
                        ? (decimal?)null
                        : (bunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                            calculationPrincipalAmount ?? 0,
                            syouhizeiritu.Zeiritu,
                            syouhizeiMaster.ZeigakuRoundingType);
                }
            }

            // 外貨の税額計算
            if (useGaika)
            {
                var shuoldCalculateGaikaZeigakuFromKarikata = shuoldCalculateZeigakuFromKarikata
                    && !string.IsNullOrEmpty(this.KarikataHeisyuCode);

                var shuoldCalculateGaikaZeigakuFromKasikata = shuoldCalculateZeigakuFromKasikata
                    && !string.IsNullOrEmpty(this.KasikataHeisyuCode);

                if (denpyouKeisiki == DenpyouKeisiki.Hukugou)
                {
                    if (shuoldCalculateGaikaZeigakuFromKarikata)
                    {
                        var heisyu = this.GetHeisyu(this.KarikataKamokuCode, this.KarikataHeisyuCode, kamokuHeisyuList, heisyuDictionary);
                        if (heisyu != null)
                        {
                            var calculationPrincipalAmount = this.KarikataGaikaTaika ?? this.KasikataGaikaKingaku;
                            var magnification = (decimal)Math.Pow(10, heisyu.DecimalPartLength);

                            // 整数で消費税額を計算後に除算
                            this.KarikataGaikaZeigaku = calculationPrincipalAmount == null
                                ? (decimal?)null
                                : (this.KasikataBunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                                    (calculationPrincipalAmount ?? 0) * magnification,
                                    syouhizeiritu.Zeiritu,
                                    syouhizeiMaster.ZeigakuRoundingType) / magnification;
                        }
                        else
                        {
                            this.KarikataGaikaZeigaku = null;
                        }
                    }

                    if (shuoldCalculateGaikaZeigakuFromKasikata)
                    {
                        var heisyu = this.GetHeisyu(this.KasikataKamokuCode, this.KasikataHeisyuCode, kamokuHeisyuList, heisyuDictionary);
                        if (heisyu != null)
                        {
                            var calculationPrincipalAmount = this.KasikataGaikaTaika ?? this.KasikataGaikaKingaku;
                            var magnification = (decimal)Math.Pow(10, heisyu.DecimalPartLength);

                            // 整数で消費税額を計算後に除算
                            this.KasikataGaikaZeigaku = calculationPrincipalAmount == null
                                ? (decimal?)null
                                : (this.KasikataBunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                                    (calculationPrincipalAmount ?? 0) * magnification,
                                    syouhizeiritu.Zeiritu,
                                    syouhizeiMaster.ZeigakuRoundingType) / magnification;
                        }
                        else
                        {
                            this.KasikataGaikaZeigaku = null;
                        }
                    }
                }
                else
                {
                    if (shuoldCalculateGaikaZeigakuFromKarikata || shuoldCalculateGaikaZeigakuFromKasikata)
                    {
                        var heisyu = shuoldCalculateGaikaZeigakuFromKarikata
                            ? this.GetHeisyu(this.KarikataKamokuCode, this.KarikataHeisyuCode, kamokuHeisyuList, heisyuDictionary)
                            : this.GetHeisyu(this.KasikataKamokuCode, this.KasikataHeisyuCode, kamokuHeisyuList, heisyuDictionary);
                        if (heisyu != null)
                        {
                            var calculationPrincipalAmount = this.KasikataGaikaTaika ?? this.KasikataGaikaKingaku;
                            var magnification = (decimal)Math.Pow(10, heisyu.DecimalPartLength);
                            var bunriKubun = shuoldCalculateGaikaZeigakuFromKarikata ? this.KarikataBunriKubun : this.KasikataBunriKubun;

                            // 整数で消費税額を計算後に除算
                            this.KasikataGaikaZeigaku = calculationPrincipalAmount == null
                                ? (decimal?)null
                                : (bunriKubun ?? BunriKubun.NotSet).GetSyouhizeigakuWithRounding(
                                    (calculationPrincipalAmount ?? 0) * magnification,
                                    syouhizeiritu.Zeiritu,
                                    syouhizeiMaster.ZeigakuRoundingType) / magnification;
                        }
                        else
                        {
                            this.KasikataGaikaZeigaku = null;
                        }
                    }
                }
            }
        }

        #endregion

        /// <summary>
        /// 指定幣種を取得、取得できない場合はデフォルト幣種を取得
        /// </summary>
        /// <param name="kamokuCode"></param>
        /// <param name="heisyuCode"></param>
        /// <param name="kamokuHeisyuList"></param>
        /// <param name="heisyuDictionary"></param>
        /// <returns></returns>
        private Heisyu GetHeisyu(string kamokuCode, string heisyuCode, IList<KamokuHeisyu> kamokuHeisyuList, IDictionary<string, Heisyu> heisyuDictionary)
        {
            var selectTargetKamokuHeisyu =
                kamokuHeisyuList.FirstOrDefault(kamokuHeisyu => kamokuHeisyu.Kicd == kamokuCode && kamokuHeisyu.HeisyuCode == heisyuCode)
                ?? kamokuHeisyuList.FirstOrDefault(kamokuHeisyu => kamokuHeisyu.Kicd == kamokuCode && kamokuHeisyu.IsDefault);

            return selectTargetKamokuHeisyu == null
                ? null
                : heisyuDictionary.GetValue(selectTargetKamokuHeisyu.HeisyuCode, () => null);
        }
    }
}
