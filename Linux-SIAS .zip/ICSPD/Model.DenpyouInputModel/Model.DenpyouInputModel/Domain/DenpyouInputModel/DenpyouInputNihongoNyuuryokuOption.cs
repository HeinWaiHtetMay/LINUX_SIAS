﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;
    using Icsp.Framework.Core.Serialization;
    using PropertyChanged;

    [Serializable]
    [AddINotifyPropertyChangedInterface]
    public class DenpyouInputNihongoNyuuryokuOption
    {
        public bool Kihyousya { get; set; }

        public bool KihyouBumon { get; set; }

        public bool HeaderField1 { get; set; }

        public bool HeaderField2 { get; set; }

        public bool HeaderField3 { get; set; }

        public bool HeaderField4 { get; set; }

        public bool HeaderField5 { get; set; }

        public bool HeaderField6 { get; set; }

        public bool HeaderField7 { get; set; }

        public bool HeaderField8 { get; set; }

        public bool HeaderField9 { get; set; }

        public bool HeaderField10 { get; set; }

        public bool Kamoku { get; set; }

        public bool Bumon { get; set; }

        public bool Torihikisaki { get; set; }

        public bool Edaban { get; set; }

        public bool UniversalField1 { get; set; }

        public bool UniversalField2 { get; set; }

        public bool UniversalField3 { get; set; }

        public bool UniversalField4 { get; set; }

        public bool UniversalField5 { get; set; }

        public bool UniversalField6 { get; set; }

        public bool UniversalField7 { get; set; }

        public bool UniversalField8 { get; set; }

        public bool UniversalField9 { get; set; }

        public bool UniversalField10 { get; set; }

        public bool UniversalField11 { get; set; }

        public bool UniversalField12 { get; set; }

        public bool UniversalField13 { get; set; }

        public bool UniversalField14 { get; set; }

        public bool UniversalField15 { get; set; }

        public bool UniversalField16 { get; set; }

        public bool UniversalField17 { get; set; }

        public bool UniversalField18 { get; set; }

        public bool UniversalField19 { get; set; }

        public bool UniversalField20 { get; set; }

        public bool Project { get; set; }

        public bool Segment { get; set; }

        public bool Kouzi { get; set; }

        public bool Kousyu { get; set; }

        public bool TekiyouCode { get; set; }

        public DenpyouInputInputType Tekiyo { get; set; }

        /// <summary>
        /// オプションを複製
        /// </summary>
        /// <returns></returns>
        public DenpyouInputNihongoNyuuryokuOption CloneAsDeepCopy() =>
            BinaryFormatterSerializer.CloneAsDeepCopy(this);
    }
}