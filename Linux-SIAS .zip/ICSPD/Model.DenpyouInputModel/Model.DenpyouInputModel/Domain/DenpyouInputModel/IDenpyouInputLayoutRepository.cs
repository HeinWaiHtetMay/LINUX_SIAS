﻿namespace Icsp.Open21.Domain.DenpyouInputModel
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.DenpyouModel;

    public interface IDenpyouInputLayoutRepository
    {
        DenpyouInputLayout FindByKesnAndDenpyouTypeAndPtno(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno);

        IList<DenpyouInputLayout> FindByKesnAndDenpyouTypeOrderByPtno(int kesn, DenpyouKeisiki denpyouKeisiki);
    }
}