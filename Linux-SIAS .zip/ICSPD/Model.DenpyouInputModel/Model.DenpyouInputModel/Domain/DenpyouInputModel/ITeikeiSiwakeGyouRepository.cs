﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.DenpyouInputModel
{
    public interface ITeikeiSiwakeGyouRepository
    {
        IList<TeikeiSiwakeGyou> FindByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumberOrderByLineNo(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber);

        void DeleteByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumber(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber);

        void Insert(TeikeiSiwakeGyou teikeiSiwakeGyou);

        void UpdateZeirituAndZeigaku(TeikeiSiwakeGyou teikeiSiwakeGyou);
    }
}