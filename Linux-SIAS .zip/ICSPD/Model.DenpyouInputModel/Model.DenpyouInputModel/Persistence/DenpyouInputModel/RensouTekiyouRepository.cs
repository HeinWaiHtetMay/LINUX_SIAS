﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.MasterModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class RensouTekiyouRepository : IRensouTekiyouRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        /// <summary>
        /// 連想摘要を取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="ucod"></param>
        /// <param name="kicd"></param>
        /// <returns></returns>
        public virtual IList<RensouTekiyou> FindByKesnAndKicdAndUcodOrderBySeq(int kesn, int ucod, string kicd)
        {
            var builder = new SqlStatementBuilder();
            builder.AppendLine("SELECT r.kesn, r.tsw0, r.ucod, r.rtno, r.seq, t.tcod, t.tnld, t.tsgn, t.tnam ");
            builder.AppendLine("FROM zrtpg p ");
            builder.AppendLine("INNER JOIN zrtky r ON r.kesn = p.kesn AND r.tsw0 = p.tsw0 AND r.ucod = p.ucod AND r.rtno = p.rtno ");
            builder.AppendLine("INNER JOIN zmtky t ON t.kesn = r.kesn AND t.tcod = r.tcod ");
            builder.AppendLine("WHERE p.kesn = :p ", kesn);
            builder.AppendLine("AND p.tsw0 = :p ", ucod == 10000 ? 0 : 1);
            builder.AppendLine("AND p.ucod = :p ", ucod);
            builder.AppendLine("AND p.kicd = :p ", kicd);
            return this.dbc.QueryForList(
                builder.GetSqlStatement(),
                (values, no) => this.MapRow(values, no),
                () => new List<RensouTekiyou>(),
                builder.GetSqlParameters());
        }

        protected virtual RensouTekiyou MapRow(object[] values, int no)
        {
            return new RensouTekiyou((int)(short)values[0], (int)values[2], (int)(short)values[3], (int)(short)values[4])
            {
                ZiyuuTekiyou = new ZiyuuTekiyou((short)values[0], (int)(short)values[5])
                {
                    Tnld = DbNullConverter.ToString(values[6], null), // 50音呼び出し
                    Tsgn = (int)(short)values[7], // 消費税識別ﾌﾗｸﾞ
                    Tnam = DbNullConverter.ToString(values[8], null), // 摘要名称
                },
            };
        }
    }
}
