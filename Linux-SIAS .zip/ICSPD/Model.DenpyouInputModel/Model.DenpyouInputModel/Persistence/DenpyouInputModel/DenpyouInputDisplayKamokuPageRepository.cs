﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.SecurityModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputDisplayKamokuPageRepository : IDenpyouInputDisplayKamokuPageRepository
    {
        private static readonly string SelectQuery = "SELECT kesn, tsw0, ucod, hkpn, pnam FROM dnpnm " +
            "WHERE kesn = :p AND tsw0 = :p AND ucod = :p AND hkpn = :p ";

        private static readonly int CommonKubunUserCode = 10000;
        private static readonly int MaxPageCount = 16;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private IDenpyouInputDisplayKamokuRepository denpyouInputDisplayKamokuRepository = null;

        public virtual IList<DenpyouInputDisplayKamokuPage> FindByKesnAndUserCodeOrderBySeqWithSecurity(
            int kesn,
            int userCode,
            SecurityKubun securityKubun,
            UserAndSyorikiSecurityContext securityContext)
        {
            var denpyouInputDisplayKamokuPageList = new List<DenpyouInputDisplayKamokuPage>();
            for (var pageNumber = 1; pageNumber <= MaxPageCount; pageNumber++)
            {
                var denpyouInputDisplayKamokuList = this.denpyouInputDisplayKamokuRepository
                    .FindByKesnAndUserCodeAndPageNumberWithSecurity(
                        kesn,
                        userCode,
                        pageNumber,
                        securityKubun,
                        securityContext);

                if (denpyouInputDisplayKamokuList.Count == 0)
                {
                    // 個人が取得でない場合は共通を取得
                    denpyouInputDisplayKamokuList = this.denpyouInputDisplayKamokuRepository
                    .FindByKesnAndUserCodeAndPageNumberWithSecurity(
                        kesn,
                        CommonKubunUserCode,
                        pageNumber,
                        securityKubun,
                        securityContext);
                }

                var denpyouInputDisplayKamokuPage = denpyouInputDisplayKamokuList.Count > 0
                    ? this.dbc.QueryForObject(
                        SelectQuery,
                        (values, no) =>
                        {
                            var row = new DenpyouInputDisplayKamokuPage(
                                denpyouInputDisplayKamokuList[0].Kesn,
                                denpyouInputDisplayKamokuList[0].UserCode,
                                pageNumber)
                            {
                                PageName = DbNullConverter.ToString(values[4], null),
                                DisplayKamokuList = denpyouInputDisplayKamokuList,
                            };
                            return row;
                        },
                        denpyouInputDisplayKamokuList[0].Kesn,
                        denpyouInputDisplayKamokuList[0].UserCode == CommonKubunUserCode ? 0 : 1,
                        denpyouInputDisplayKamokuList[0].UserCode,
                        pageNumber)
                    : null;
                denpyouInputDisplayKamokuPageList.Add(denpyouInputDisplayKamokuPage);
            }

            return denpyouInputDisplayKamokuPageList;
        }
    }
}
