﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputDisplayKamokuRepository : IDenpyouInputDisplayKamokuRepository
    {
        private static readonly int CommonKubunUserCode = 10000;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private IMasterFindServiceWithSecurity masterFindServiceWithSecurity = null;

        public virtual IList<DenpyouInputDisplayKamoku> FindByKesnAndUserCodeAndPageNumberWithSecurity(
            int kesn,
            int userCode,
            int pageNumber,
            SecurityKubun securityKubun,
            UserAndSyorikiSecurityContext securityContext)
        {
            var kamokuDictionary = this.masterFindServiceWithSecurity.FindKamokuByKesnOrderByKamokuOutputOrderWithSecurity(kesn, KamokuOutputOrder.ByInnerCode, securityKubun, securityContext)?.ToDictionary(kamoku => kamoku.Kicd);
            var builder = new SqlStatementBuilder();
            builder.AppendLine("SELECT kesn, tsw0, ucod, hkpn, seq, kicd FROM dnhkm ");
            builder.AppendLine("WHERE kesn = :p ", kesn);
            builder.AppendLine("AND tsw0 = :p ", userCode == CommonKubunUserCode ? 0 : 1);
            builder.AppendLine("AND ucod = :p ", userCode);
            builder.AppendLine("AND hkpn = :p ", pageNumber);
            builder.AppendLine("ORDER BY seq ");
            return this.dbc.QueryForList(
                builder.GetSqlStatement(),
                (values, no) =>
                {
                    var row = new DenpyouInputDisplayKamoku(kesn, (int)values[2], (int)(short)values[3], (int)(short)values[4]);
                    row.DisplayKamoku = kamokuDictionary.GetValue(DbNullConverter.ToString(values[5]), null);
                    return row;
                },
                () => new List<DenpyouInputDisplayKamoku>(),
                builder.GetSqlParameters());
        }
    }
}
