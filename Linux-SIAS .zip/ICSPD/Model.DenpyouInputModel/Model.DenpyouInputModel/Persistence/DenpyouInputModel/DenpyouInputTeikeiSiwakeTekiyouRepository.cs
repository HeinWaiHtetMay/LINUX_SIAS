﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputTeikeiSiwakeTekiyouRepository : IDenpyouInputTeikeiSiwakeTekiyouRepository
    {
        /// <summary>
        /// 共通パターンの場合にユーザーコード10000ではなく0にて取得しているが旧システムからデータを使用できるよう修正せずに放置
        /// </summary>
        private static readonly int CommonPatternNo = 0;

        private static readonly string KeyString = "TKYLIST";

        /// <summary>
        /// HACK 件数はどこに置くべきか考える
        /// </summary>
        private static readonly int MaximumTekiyouNumber = 20;

        [AutoInjection]
        private IOption1Dao option1Dao = null;

        public IList<DenpyouInputTeikeiSiwakeTekiyou> FindByProgramIdAndUserNoOrderByTekiyouNumber(TeikeiSiwakeType teikeiSiwakeType, string programId, int userCode)
        {
            userCode = teikeiSiwakeType == TeikeiSiwakeType.CommonPattern ? CommonPatternNo : userCode;
            var dtoList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, KeyString);
            var denpyouInputTeikeiSiwakeTekiyouList = new List<DenpyouInputTeikeiSiwakeTekiyou>();

            // 未登録でも20行取得する
            for (int tekiyouNumber = 1; tekiyouNumber <= MaximumTekiyouNumber; tekiyouNumber++)
            {
                denpyouInputTeikeiSiwakeTekiyouList.Add(
                    new DenpyouInputTeikeiSiwakeTekiyou()
                    {
                        UserCode = userCode,
                        TekiyouNumber = tekiyouNumber,
                        TekiyouString = dtoList.GetCdata(KeyString, KeyString, tekiyouNumber, string.Empty),
                    });
            }

            return denpyouInputTeikeiSiwakeTekiyouList;
        }

        public DenpyouInputTeikeiSiwakeTekiyou FindByProgramIdAndUserNoAndTekiyouNumber(TeikeiSiwakeType teikeiSiwakeType, string programId, int userCode, int tekiyouNumber) =>
            this.FindByProgramIdAndUserNoOrderByTekiyouNumber(teikeiSiwakeType, programId, userCode)
                ?.FirstOrDefault(denpyouInputTeikeiSiwakeTekiyou => denpyouInputTeikeiSiwakeTekiyou.TekiyouNumber == tekiyouNumber);

        public void Store(IList<DenpyouInputTeikeiSiwakeTekiyou> denpyouInputTeikeiSiwakeTekiyouList, string programId)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, denpyouInputTeikeiSiwakeTekiyouList[0].UserCode, KeyString);
            var option1DtoList = new List<Option1Dto>();
            denpyouInputTeikeiSiwakeTekiyouList.ForEach(
                denpyouInputTeikeiSiwakeTekiyou => denpyouInputTeikeiSiwakeTekiyou.IsRegistrationTarget,
                denpyouInputTeikeiSiwakeTekiyou =>
                {
                    option1DtoList.Add(new Option1Dto().SetValues(
                        programId,
                        denpyouInputTeikeiSiwakeTekiyou.UserCode,
                        KeyString,
                        KeyString,
                        (short)denpyouInputTeikeiSiwakeTekiyou.TekiyouNumber,
                        denpyouInputTeikeiSiwakeTekiyou.TekiyouString));
                });
            option1DtoList.ForEachIfNotNull(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }
    }
}
