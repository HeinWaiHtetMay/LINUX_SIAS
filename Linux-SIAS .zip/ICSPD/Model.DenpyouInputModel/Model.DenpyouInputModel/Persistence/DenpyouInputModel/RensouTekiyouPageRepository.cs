﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouInputModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class RensouTekiyouPageRepository : IRensouTekiyouPageRepository
    {
        private static readonly int CommonKubunUserCode = 10000;

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private IRensouTekiyouRepository rensouTekiyouRepository = null;

        public virtual RensouTekiyouPage FindByKesnAndUcodAndKicd(int kesn, int ucod, string kicd)
        {
            var query = "SELECT kesn, tsw0, ucod, rtno, pnam FROM zrpnm WHERE kesn = :p AND tsw0 = :p AND ucod = :p AND rtno = :p ";

            // 個人パターン
            var rensouTekiyouList = this.rensouTekiyouRepository.FindByKesnAndKicdAndUcodOrderBySeq(kesn, ucod, kicd);
            if (rensouTekiyouList.Count > 0)
            {
                return this.dbc.QueryForObject(
                    query,
                    (values, no) => this.MapRow(values, rensouTekiyouList),
                    kesn,
                    1,
                    ucod,
                    rensouTekiyouList[0].PageNumber);
            }

            // 共通パターン
            rensouTekiyouList = this.rensouTekiyouRepository.FindByKesnAndKicdAndUcodOrderBySeq(kesn, CommonKubunUserCode, kicd);
            return rensouTekiyouList.Count > 0
                ? this.dbc.QueryForObject(
                    query,
                    (values, no) => this.MapRow(values, rensouTekiyouList),
                    kesn,
                    0,
                    CommonKubunUserCode,
                    rensouTekiyouList[0].PageNumber)
                : null;
        }

        protected virtual RensouTekiyouPage MapRow(object[] values, IList<RensouTekiyou> rensouTekiyouList)
        {
            return new RensouTekiyouPage((int)(short)values[0], (int)values[2], (int)(short)values[3])
            {
                PageName = DbNullConverter.ToString(values[4], null),
                RensouTekiyouList = rensouTekiyouList,
            };
        }
    }
}
