﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputLayoutRepository : IDenpyouInputLayoutRepository
    {
        private static readonly string SelectAndFromStatement = "SELECT kesn, dtyp, ptno, pnam, gcnt, scnt, hfflg FROM dinlyptn ";

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private IDenpyouInputLayoutItemRepository denpyouLayoutItemRepository = null;

        public virtual IList<DenpyouInputLayout> FindByKesnAndDenpyouTypeOrderByPtno(int kesn, DenpyouKeisiki denpyouKeisiki)
        {
            var denpyouLayoutList = this.dbc.QueryForList(
                SelectAndFromStatement +
                "WHERE kesn = :p AND dtyp = :p " +
                "ORDER BY ptno ",
                (values, no) =>
                {
                    return this.MapRow(values, no);
                },
                () => new List<DenpyouInputLayout>(),
                kesn,
                (short)denpyouKeisiki);

            denpyouLayoutList.ForEachIfNotNull(denpyouLayout =>
            denpyouLayout.DenpyouLayoutItemList = this.denpyouLayoutItemRepository.FindByKesnAndDenpyouTypeAndPtnoOrderByPseq(denpyouLayout.Kesn, denpyouLayout.DenpyouKeisiki, denpyouLayout.Ptno));

            return denpyouLayoutList;
        }

        public virtual DenpyouInputLayout FindByKesnAndDenpyouTypeAndPtno(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno)
        {
            if (ptno == 0)
            {
                return this.GetDefaultLayout(kesn, denpyouKeisiki);
            }

            var denpyouLayout = this.dbc.QueryForObject(
                SelectAndFromStatement +
                "WHERE kesn = :p AND dtyp = :p AND ptno = :p ",
                (values, no) =>
                {
                    return this.MapRow(values, no);
                },
                kesn,
                (short)denpyouKeisiki,
                ptno);

            if (denpyouLayout == null)
            {
                return null;
            }

            denpyouLayout.DenpyouLayoutItemList = this.denpyouLayoutItemRepository.FindByKesnAndDenpyouTypeAndPtnoOrderByPseq(denpyouLayout.Kesn, denpyouLayout.DenpyouKeisiki, denpyouLayout.Ptno);
            return denpyouLayout;
        }

        private DenpyouInputLayout MapRow(object[] values, int no) =>
            new DenpyouInputLayout((int)(short)values[0], (DenpyouKeisiki)(short)values[1], (int)(short)values[2])
            {
                Pnam = DbNullConverter.ToString(values[3], null), // パターン名称
                Gcnt = (int)(short)values[4], // 1画面当りの仕訳数
                Scnt = (int)(short)values[5], // 1仕訳あたりの行数
                ShowHeaderField = (short)values[6] == 1, // ﾍｯﾀﾞｰﾌｨｰﾙﾄﾞ表示
            };

        /// <summary>
        /// デフォルト値を設定
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="denpyouKeisiki"></param>
        /// <returns></returns>
        private DenpyouInputLayout GetDefaultLayout(int kesn, DenpyouKeisiki denpyouKeisiki)
        {
            var denpyouLayout = new DenpyouInputLayout(kesn, denpyouKeisiki, 0);
            if (denpyouKeisiki == DenpyouKeisiki.Hukugou)
            {
                // 複合仕訳
                denpyouLayout.Scnt = 11;
                denpyouLayout.Gcnt = 2;
                denpyouLayout.ShowHeaderField = false;
            }
            else
            {
                // 単一仕訳
                denpyouLayout.Scnt = 9;
                denpyouLayout.Gcnt = 2;
                denpyouLayout.ShowHeaderField = false;
            }

            denpyouLayout.DenpyouLayoutItemList = this.denpyouLayoutItemRepository.FindByKesnAndDenpyouTypeAndPtnoOrderByPseq(kesn, denpyouKeisiki, 0);
            return denpyouLayout;
        }
    }
}
