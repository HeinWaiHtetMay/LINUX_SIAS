﻿namespace Icsp.Open21.Persistence.DenpyoNyuryokuOptionModel
{
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Persistence.OptionModel;

    [Repository]
    internal class DenpyouInputOptionRepository : IDenpyouInputOptionRepository
    {
        private static readonly string DenpyouNyuuryokuProgramId = "DINPFRI";
        private static readonly string SokyuuDenpyouNyuuryokuProgramId = "SKDINPFRI";
        private static readonly string DenpyouSyuuseiProgramId = "DMNTFRIV";

        private static readonly int RgbBitMask = 0xFFFFFF;
        private static readonly int RedBitMask = 0xFF0000;
        private static readonly int GreenBitMask = 0x00FF00;
        private static readonly int BlueBitMask = 0x0000FF;
        private static readonly int RedShiftValue = 0x010000;
        private static readonly int GreenShiftValue = 0x000100;

        #region Repository
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        [AutoInjection]
        private IDenpyouInputAndSyuuseiOptionRepository denpyouInputAndSyuuseiOptionRepository = null;

        [AutoInjection]
        private ILinkInfomationOptionRepository linkInfomationOptionRepository = null;
        #endregion

        public DenpyouInputOption FindDenpyouInputOptionByUsernoAndProgramId(
            int userno,
            string optionProgramId,
            DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate)
        {
            var denpyouInputOption = new DenpyouInputOption(userno, optionProgramId);
            var dtoList = this.option1Dao.FindByPrgidAndUsno(DatabaseType.KaisyaDb, optionProgramId, userno);
            if (optionProgramId == SokyuuDenpyouNyuuryokuProgramId && dtoList.Count == 0)
            {
                // 遡及伝票入力の場合、初期値として伝票入力の設定値を使用する
                dtoList = this.option1Dao.FindByPrgidAndUsno(DatabaseType.KaisyaDb, DenpyouNyuuryokuProgramId, userno);
            }

            this.SetOptionsPropertiesFromProgramIdRecord(dtoList, denpyouInputOption, optionProgramId, callerProgramDenpyouSiwakeWayToCreate);

            var dtoListUserShared = this.option1Dao.FindByPrgidForUserShared(DatabaseType.KaisyaDb, optionProgramId);
            this.SetUserSharedOptionsPropertiesFromPrgidDinpfri(dtoListUserShared, denpyouInputOption);

            denpyouInputOption.DenpyouInputAndSyuuseiOption = this.denpyouInputAndSyuuseiOptionRepository.Find();
            denpyouInputOption.LinkInfomationOption = this.linkInfomationOptionRepository.Find();

            return denpyouInputOption;
        }

        public void StoreScreenAtOperationBoot(DenpyouInputOption denpyoNyuryokuOption, string programId)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "FORM");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "FORM", "STA", 0, (int)denpyoNyuryokuOption.DenpyouKeisikiAtApplicationBoot.DenpyouInputFormType),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "FORM", "PTN", 1, denpyoNyuryokuOption.DenpyouKeisikiAtApplicationBoot.TannituPattern),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "FORM", "PTN", 2, denpyoNyuryokuOption.DenpyouKeisikiAtApplicationBoot.HukugouPattern),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        public void StoreCommonPatternSelectionValue(DenpyouInputOption denpyoNyuryokuOption, string programId)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "TEIKEI");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "JYUN", 0, (int)denpyoNyuryokuOption.CommonPatternSelectionValue.TeikeiSiwakeDisplayOrder),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "HYOU", 0, (int)denpyoNyuryokuOption.CommonPatternSelectionValue.TeikeiSiwakeDisplayPattern),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "SEL", 0, (int)denpyoNyuryokuOption.CommonPatternSelectionValue.TeikeiSiwakeSelectWay),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "READ", 0, (int)denpyoNyuryokuOption.CommonPatternSelectionValue.TeikeiSiwakeReadoutWay),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "TKY", 0, denpyoNyuryokuOption.CommonPatternSelectionValue.AddTekiyo ? 1 : 0),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "TEIKEI", "LAY", 0, denpyoNyuryokuOption.CommonPatternSelectionValue.ReadoutInDenpyouKeisikiAtRegistration ? 1 : 0),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        public void StorePersonalPatternSelectionValue(DenpyouInputOption denpyoNyuryokuOption, string programId)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "KOJIN");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "JYUN", 0, (int)denpyoNyuryokuOption.PersonalPatternSelectionValue.TeikeiSiwakeDisplayOrder),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "HYOU", 0, (int)denpyoNyuryokuOption.PersonalPatternSelectionValue.TeikeiSiwakeDisplayPattern),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "SEL", 0, (int)denpyoNyuryokuOption.PersonalPatternSelectionValue.TeikeiSiwakeSelectWay),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "READ", 0, (int)denpyoNyuryokuOption.PersonalPatternSelectionValue.TeikeiSiwakeReadoutWay),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "TKY", 0, denpyoNyuryokuOption.PersonalPatternSelectionValue.AddTekiyo ? 1 : 0),
                new Option1Dto().SetValues(programId, denpyoNyuryokuOption.UserCode, "KOJIN", "LAY", 0, denpyoNyuryokuOption.PersonalPatternSelectionValue.ReadoutInDenpyouKeisikiAtRegistration ? 1 : 0),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        public void StoreDialogOption(DenpyouInputOption denpyoNyuryokuOption, string optionProgramId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate)
        {
            this.StoreHukusyaOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreMeisyouItiranhyouOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreKensakuZidouKidouOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreNihongoNyuuryokuOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreFocusOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreGaikaOption(denpyoNyuryokuOption, optionProgramId);

            this.StoreDenpyouInputOtherOption(denpyoNyuryokuOption, optionProgramId, callerProgramDenpyouSiwakeWayToCreate);
        }

        public void StoreShowSelectionNumber(DenpyouInputOption denpyoNyuryokuOption, string programId) =>
            this.StoreOption(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "CMB", "NODISP", 0, denpyoNyuryokuOption.ShowSelectionNumber ? 1 : 0);

        public void StoreShowVerificationMessage(DenpyouInputOption denpyoNyuryokuOption, string programId) =>
            this.StoreOption(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "OPT", "TRKMSG", 0, denpyoNyuryokuOption.ShowConfirmationMessage ? 1 : 0);

        public void StoreCheckSiharaibi(DenpyouInputOption denpyoNyuryokuOption, string programId) =>
            this.StoreOption(DatabaseType.KaisyaDb, programId, denpyoNyuryokuOption.UserCode, "CHECK_SHIHARAIBI", "CHECK_SHIHARAIBI", 1, denpyoNyuryokuOption.CheckSiharaibiIsAfterDenpyouHizuke ? 1 : 0);

        public void StoreAutoGyokugiriMode(DenpyouInputOption denpyoNyuryokuOption, string programId)
        {
            this.option1Dao.DeleteByPrgidAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, programId, "OPT");
            this.option1Dao.Insert(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programId, 10000, "OPT", "4UCOMP", 0, denpyoNyuryokuOption.AutoGyoukugiriMode ? 1 : 0));
        }

        /// <summary>
        /// 伝票入力ユーザーオプションをEntityにセット
        /// </summary>
        /// <param name="dtoList"></param>
        /// <param name="value"></param>
        /// <param name="programId"></param>
        /// <param name="callerProgramDenpyouSiwakeWayToCreate"></param>
        private void SetOptionsPropertiesFromProgramIdRecord(IList<Option1Dto> dtoList, DenpyouInputOption value, string programId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate)
        {
            value.DenpyouKeisikiAtApplicationBoot.DenpyouInputFormType = (DenpyouInputFormType)dtoList.GetIdata("FORM", "STA", 0, 1);
            value.DenpyouKeisikiAtApplicationBoot.TannituPattern = dtoList.GetIdata("FORM", "PTN", 1, 1);
            value.DenpyouKeisikiAtApplicationBoot.HukugouPattern = dtoList.GetIdata("FORM", "PTN", 2, 1);

            value.CommonPatternSelectionValue.TeikeiSiwakeDisplayOrder = (DenpyouInputTeikeiSiwakeDisplayOrder)dtoList.GetIdata("TEIKEI", "JYUN", 0, 1);
            value.CommonPatternSelectionValue.TeikeiSiwakeDisplayPattern = (DenpyouInputTeikeiSiwakeDisplayPattern)dtoList.GetIdata("TEIKEI", "HYOU", 0, 0);
            value.CommonPatternSelectionValue.TeikeiSiwakeSelectWay = (DenpyouInputTeikeiSiwakeSelectWay)dtoList.GetIdata("TEIKEI", "SEL", 0, 0);
            value.CommonPatternSelectionValue.AddTekiyo = dtoList.GetIdata("TEIKEI", "TKY", 0, 0) == 1;
            value.CommonPatternSelectionValue.TeikeiSiwakeReadoutWay = (DenpyouInputTeikeiSiwakeReadoutWay)dtoList.GetIdata("TEIKEI", "READ", 0, 0);
            value.CommonPatternSelectionValue.ReadoutInDenpyouKeisikiAtRegistration = dtoList.GetIdata("TEIKEI", "LAY", 0, 0) == 1;

            value.PersonalPatternSelectionValue.TeikeiSiwakeDisplayOrder = (DenpyouInputTeikeiSiwakeDisplayOrder)dtoList.GetIdata("KOJIN", "JYUN", 0, 1);
            value.PersonalPatternSelectionValue.TeikeiSiwakeDisplayPattern = (DenpyouInputTeikeiSiwakeDisplayPattern)dtoList.GetIdata("KOJIN", "HYOU", 0, 0);
            value.PersonalPatternSelectionValue.TeikeiSiwakeSelectWay = (DenpyouInputTeikeiSiwakeSelectWay)dtoList.GetIdata("KOJIN", "SEL", 0, 0);
            value.PersonalPatternSelectionValue.AddTekiyo = dtoList.GetIdata("KOJIN", "TKY", 0, 0) == 1;
            value.PersonalPatternSelectionValue.TeikeiSiwakeReadoutWay = (DenpyouInputTeikeiSiwakeReadoutWay)dtoList.GetIdata("KOJIN", "READ", 0, 0);
            value.PersonalPatternSelectionValue.ReadoutInDenpyouKeisikiAtRegistration = dtoList.GetIdata("KOJIN", "LAY", 0, 0) == 1;

            this.SetHukusyaOption(dtoList, value);

            this.SetMeisyouItiranhyouOption(dtoList, value);

            this.SetKensakuZidouKidouOption(dtoList, value);

            this.SetNihongoNyuuryokuOption(dtoList, value);

            this.SetFocusOption(dtoList, value);

            this.SetGaikaOption(dtoList, value);

            this.SetDenpyouInputOtherOption(dtoList, value, programId, callerProgramDenpyouSiwakeWayToCreate);

            value.ShowSelectionNumber = dtoList.GetIdata("CMB", "NODISP", 0, 0) == 1;

            value.ShowConfirmationMessage = dtoList.GetIdata("OPT", "TRKMSG", 0, 0) == 1;

            value.CheckSiharaibiIsAfterDenpyouHizuke = dtoList.GetIdata("CHECK_SHIHARAIBI", "CHECK_SHIHARAIBI", 1, 1) == 1;
        }

        private void SetHukusyaOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.HukusyaOption.CopyDenpyouHizuke = dtoList.GetIdata("HCOPY", "DYMD", 0, 0) == 1;
            value.HukusyaOption.CopyDenpyouNo = (DenpyouInputDenpyouNoHukusyaType)dtoList.GetIdata("HCOPY", "DCNO", 0, 0);
            value.HukusyaOption.CopyKihyoubi = dtoList.GetIdata("HCOPY", "KBMN", 0, 0) == 1;
            value.HukusyaOption.CopyKihyousya = dtoList.GetIdata("HCOPY", "KDAY", 0, 0) == 1;
            value.HukusyaOption.CopyKihyouBumon = dtoList.GetIdata("HCOPY", "KUSR", 0, 0) == 1;
            value.HukusyaOption.CopySyouninGroup = dtoList.GetIdata("HCOPY", "SGNO", 0, 0) == 1;
            value.HukusyaOption.CopyDenpyouTaba = dtoList.GetIdata("HCOPY", "TBCD", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField1 = dtoList.GetIdata("HCOPY", "HF1", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField2 = dtoList.GetIdata("HCOPY", "HF2", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField3 = dtoList.GetIdata("HCOPY", "HF3", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField4 = dtoList.GetIdata("HCOPY", "HF4", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField5 = dtoList.GetIdata("HCOPY", "HF5", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField6 = dtoList.GetIdata("HCOPY", "HF6", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField7 = dtoList.GetIdata("HCOPY", "HF7", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField8 = dtoList.GetIdata("HCOPY", "HF8", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField9 = dtoList.GetIdata("HCOPY", "HF9", 0, 0) == 1;
            value.HukusyaOption.CopyHeaderField10 = dtoList.GetIdata("HCOPY", "HF10", 0, 0) == 1;
            value.HukusyaOption.CopyCommonTekiyou = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TKY", 0, 0);
            value.HukusyaOption.CopyFromSaisyuSiwakeToSentouSiwake = dtoList.GetIdata("DCOPY", "LIN1", 0, 0) == 1;

            value.HukusyaOption.CopyKarikataKamoku = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KAM", 1, 0);
            value.HukusyaOption.CopyKarikataBumon = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "BUM", 1, 0);
            value.HukusyaOption.CopyKarikataTorihikisaki = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TOR", 1, 0);
            value.HukusyaOption.CopyKarikataEdaban = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "EDA", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField1 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM1", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField2 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM2", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField3 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM3", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField4 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF4", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField5 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF5", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField6 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF6", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField7 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF7", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField8 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF8", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField9 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF9", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField10 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF10", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField11 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF11", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField12 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF12", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField13 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF13", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField14 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF14", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField15 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF15", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField16 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF16", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField17 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF17", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField18 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF18", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField19 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF19", 1, 0);
            value.HukusyaOption.CopyKarikataUniversalField20 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF20", 1, 0);
            value.HukusyaOption.CopyKarikataProject = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "PRJ", 1, 0);
            value.HukusyaOption.CopyKarikataSegment = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "SEG", 1, 0);
            value.HukusyaOption.CopyKarikataKouzi = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KOJ", 1, 0);
            value.HukusyaOption.CopyKarikataKousyu = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KOS", 1, 0);
            value.HukusyaOption.CopyKarikataTekiyou = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TKY", 1, 0);
            value.HukusyaOption.CopyKarikataTekiyouCode = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TNO", 1, 0);

            value.HukusyaOption.CopyKasikataKamoku = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KAM", 2, 0);
            value.HukusyaOption.CopyKasikataBumon = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "BUM", 2, 0);
            value.HukusyaOption.CopyKasikataTorihikisaki = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TOR", 2, 0);
            value.HukusyaOption.CopyKasikataEdaban = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "EDA", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField1 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM1", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField2 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM2", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField3 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "DM3", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField4 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF4", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField5 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF5", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField6 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF6", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField7 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF7", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField8 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF8", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField9 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF9", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField10 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF10", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField11 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF11", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField12 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF12", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField13 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF13", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField14 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF14", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField15 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF15", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField16 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF16", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField17 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF17", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField18 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF18", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField19 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF19", 2, 0);
            value.HukusyaOption.CopyKasikataUniversalField20 = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "UF20", 2, 0);
            value.HukusyaOption.CopyKasikataProject = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "PRJ", 2, 0);
            value.HukusyaOption.CopyKasikataSegment = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "SEG", 2, 0);
            value.HukusyaOption.CopyKasikataKouzi = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KOJ", 2, 0);
            value.HukusyaOption.CopyKasikataKousyu = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "KOS", 2, 0);
            value.HukusyaOption.CopyKasikataTekiyou = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TKY", 2, 0);
            value.HukusyaOption.CopyKasikataTekiyouCode = (DenpyouInputSiwakeHukusyaType)dtoList.GetIdata("DCOPY", "TNO", 2, 0);
        }

        private void SetMeisyouItiranhyouOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.MeisyouItiranhyouOption.ShowHeaderField1MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF1", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField2MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF2", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField3MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF3", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField4MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF4", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField5MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF5", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField6MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF6", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField7MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF7", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField8MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF8", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField9MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF9", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowHeaderField10MeisyoItiranhyo = dtoList.GetIdata("LIST", "HF10", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowKamokuMeisyoItiranhyo = dtoList.GetIdata("LIST", "KAM", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowBumonMeisyoItiranhyo = dtoList.GetIdata("LIST", "BUM", 0, 0) == 1;
            value.MeisyouItiranhyouOption.BumonMeisyouItiranhyosDisplayContent = (DenpyouInputDisplayContent)dtoList.GetIdata("LIST", "BUMOP", 0, 0);
            value.MeisyouItiranhyouOption.ShowTorihikisakiMeisyoItiranhyo = dtoList.GetIdata("LIST", "TRI", 0, 0) == 1;
            value.MeisyouItiranhyouOption.TorihikiMeisyouItiranhyosDisplayContent = (DenpyouInputDisplayContent)dtoList.GetIdata("LIST", "TRIOP", 0, 0);
            value.MeisyouItiranhyouOption.ShowEdabanMeisyoItiranhyo = dtoList.GetIdata("LIST", "EDA", 0, 0) == 1;
            value.MeisyouItiranhyouOption.EdabanMeisyouItiranhyosDisplayContent = (DenpyouInputDisplayContent)dtoList.GetIdata("LIST", "EDAOP", 0, 0);
            value.MeisyouItiranhyouOption.ShowUniversalField1MeisyoItiranhyo = dtoList.GetIdata("LIST", "DM1", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField2MeisyoItiranhyo = dtoList.GetIdata("LIST", "DM2", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField3MeisyoItiranhyo = dtoList.GetIdata("LIST", "DM3", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField4MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF4", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField5MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF5", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField6MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF6", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField7MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF7", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField8MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF8", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField9MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF9", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField10MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF10", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField11MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF11", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField12MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF12", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField13MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF13", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField14MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF14", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField15MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF15", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField16MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF16", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField17MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF17", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField18MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF18", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField19MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF19", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowUniversalField20MeisyoItiranhyo = dtoList.GetIdata("LIST", "UF20", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowProjectMeisyoItiranhyo = dtoList.GetIdata("LIST", "PRJ", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowSegmentMeisyoItiranhyo = dtoList.GetIdata("LIST", "SEG", 0, 0) == 1;
            value.MeisyouItiranhyouOption.ShowKouziMeisyoItiranhyo = dtoList.GetIdata("LIST", "KOJ", 0, 0) == 1;
            value.MeisyouItiranhyouOption.KouziMeisyouItiranhyousDisplayContent = (DenpyouInputDisplayContent)dtoList.GetIdata("LIST", "KOJOP", 0, 0);
            value.MeisyouItiranhyouOption.ShowKousyuMeisyoItiranhyo = dtoList.GetIdata("LIST", "KOS", 0, 0) == 1;
            value.MeisyouItiranhyouOption.KousyuMeisyouItiranhyousDisplayContent = (DenpyouInputDisplayContent)dtoList.GetIdata("LIST", "KOSOP", 0, 0);
            value.MeisyouItiranhyouOption.ShowTekiyouMeisyouItiranhyou = dtoList.GetIdata("LIST", "TKY", 0, 1) == 1;
            value.MeisyouItiranhyouOption.DisplayStyle = (DenpyouInputDisplayStyle)dtoList.GetIdata("LIST", "TYPE", 0, 0);
        }

        private void SetKensakuZidouKidouOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.KensakuZidouKidouOption.ZidouKidouMozisuu = dtoList.GetIdata("50AUTO", "MOJISU", 0, 1);
            value.KensakuZidouKidouOption.Kihyousya = dtoList.GetIdata("50AUTO", "KUSR", 0, 0) == 1;
            value.KensakuZidouKidouOption.KihyouBumon = dtoList.GetIdata("50AUTO", "KBMN", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField1 = dtoList.GetIdata("50AUTO", "HF1", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField2 = dtoList.GetIdata("50AUTO", "HF2", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField3 = dtoList.GetIdata("50AUTO", "HF3", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField4 = dtoList.GetIdata("50AUTO", "HF4", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField5 = dtoList.GetIdata("50AUTO", "HF5", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField6 = dtoList.GetIdata("50AUTO", "HF6", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField7 = dtoList.GetIdata("50AUTO", "HF7", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField8 = dtoList.GetIdata("50AUTO", "HF8", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField9 = dtoList.GetIdata("50AUTO", "HF9", 0, 0) == 1;
            value.KensakuZidouKidouOption.HeaderField10 = dtoList.GetIdata("50AUTO", "HF10", 0, 0) == 1;
            value.KensakuZidouKidouOption.Kamoku = dtoList.GetIdata("50AUTO", "KAM", 0, 0) == 1;
            value.KensakuZidouKidouOption.Bumon = dtoList.GetIdata("50AUTO", "BUM", 0, 0) == 1;
            value.KensakuZidouKidouOption.Torihikisaki = dtoList.GetIdata("50AUTO", "TRI", 0, 0) == 1;
            value.KensakuZidouKidouOption.Edaban = dtoList.GetIdata("50AUTO", "EDA", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField1 = dtoList.GetIdata("50AUTO", "DM1", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField2 = dtoList.GetIdata("50AUTO", "DM2", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField3 = dtoList.GetIdata("50AUTO", "DM3", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField4 = dtoList.GetIdata("50AUTO", "UF4", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField5 = dtoList.GetIdata("50AUTO", "UF5", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField6 = dtoList.GetIdata("50AUTO", "UF6", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField7 = dtoList.GetIdata("50AUTO", "UF7", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField8 = dtoList.GetIdata("50AUTO", "UF8", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField9 = dtoList.GetIdata("50AUTO", "UF9", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField10 = dtoList.GetIdata("50AUTO", "UF10", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField11 = dtoList.GetIdata("50AUTO", "UF11", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField12 = dtoList.GetIdata("50AUTO", "UF12", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField13 = dtoList.GetIdata("50AUTO", "UF13", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField14 = dtoList.GetIdata("50AUTO", "UF14", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField15 = dtoList.GetIdata("50AUTO", "UF15", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField16 = dtoList.GetIdata("50AUTO", "UF16", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField17 = dtoList.GetIdata("50AUTO", "UF17", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField18 = dtoList.GetIdata("50AUTO", "UF18", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField19 = dtoList.GetIdata("50AUTO", "UF19", 0, 0) == 1;
            value.KensakuZidouKidouOption.UniversalField20 = dtoList.GetIdata("50AUTO", "UF20", 0, 0) == 1;
            value.KensakuZidouKidouOption.Project = dtoList.GetIdata("50AUTO", "PRJ", 0, 0) == 1;
            value.KensakuZidouKidouOption.Segment = dtoList.GetIdata("50AUTO", "SEG", 0, 0) == 1;
            value.KensakuZidouKidouOption.Kouzi = dtoList.GetIdata("50AUTO", "KOJ", 0, 0) == 1;
            value.KensakuZidouKidouOption.Kousyu = dtoList.GetIdata("50AUTO", "KOS", 0, 0) == 1;
            value.KensakuZidouKidouOption.TekiyouCode = dtoList.GetIdata("50AUTO", "TNO", 0, 0) == 1;
        }

        private void SetNihongoNyuuryokuOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.NihongoNyuuryokuOption.Kihyousya = dtoList.GetIdata("IMEON", "KUSR", 0, 0) == 1;
            value.NihongoNyuuryokuOption.KihyouBumon = dtoList.GetIdata("IMEON", "KBMN", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField1 = dtoList.GetIdata("IMEON", "HF1", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField2 = dtoList.GetIdata("IMEON", "HF2", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField3 = dtoList.GetIdata("IMEON", "HF3", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField4 = dtoList.GetIdata("IMEON", "HF4", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField5 = dtoList.GetIdata("IMEON", "HF5", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField6 = dtoList.GetIdata("IMEON", "HF6", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField7 = dtoList.GetIdata("IMEON", "HF7", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField8 = dtoList.GetIdata("IMEON", "HF8", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField9 = dtoList.GetIdata("IMEON", "HF9", 0, 0) == 1;
            value.NihongoNyuuryokuOption.HeaderField10 = dtoList.GetIdata("IMEON", "HF10", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Kamoku = dtoList.GetIdata("IMEON", "KAM", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Bumon = dtoList.GetIdata("IMEON", "BUM", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Torihikisaki = dtoList.GetIdata("IMEON", "TRI", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Edaban = dtoList.GetIdata("IMEON", "EDA", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField1 = dtoList.GetIdata("IMEON", "DM1", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField2 = dtoList.GetIdata("IMEON", "DM2", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField3 = dtoList.GetIdata("IMEON", "DM3", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField4 = dtoList.GetIdata("IMEON", "UF4", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField5 = dtoList.GetIdata("IMEON", "UF5", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField6 = dtoList.GetIdata("IMEON", "UF6", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField7 = dtoList.GetIdata("IMEON", "UF7", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField8 = dtoList.GetIdata("IMEON", "UF8", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField9 = dtoList.GetIdata("IMEON", "UF9", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField10 = dtoList.GetIdata("IMEON", "UF10", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField11 = dtoList.GetIdata("IMEON", "UF11", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField12 = dtoList.GetIdata("IMEON", "UF12", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField13 = dtoList.GetIdata("IMEON", "UF13", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField14 = dtoList.GetIdata("IMEON", "UF14", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField15 = dtoList.GetIdata("IMEON", "UF15", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField16 = dtoList.GetIdata("IMEON", "UF16", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField17 = dtoList.GetIdata("IMEON", "UF17", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField18 = dtoList.GetIdata("IMEON", "UF18", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField19 = dtoList.GetIdata("IMEON", "UF19", 0, 0) == 1;
            value.NihongoNyuuryokuOption.UniversalField20 = dtoList.GetIdata("IMEON", "UF20", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Project = dtoList.GetIdata("IMEON", "PRJ", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Segment = dtoList.GetIdata("IMEON", "SEG", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Kouzi = dtoList.GetIdata("IMEON", "KOJ", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Kousyu = dtoList.GetIdata("IMEON", "KOS", 0, 0) == 1;
            value.NihongoNyuuryokuOption.TekiyouCode = dtoList.GetIdata("IMEON", "TNO", 0, 0) == 1;
            value.NihongoNyuuryokuOption.Tekiyo = (DenpyouInputInputType)dtoList.GetIdata("IMEON", "TKY", 0, 1);
        }

        private void SetFocusOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.FocusOption.ExclusionDenpyouNoFromTabOrder = dtoList.GetIdata("NOFOC", "DCNO", 0, 0) == 1;
            value.FocusOption.ExclusionKihyoubiFromTabOrder = dtoList.GetIdata("NOFOC", "KDAY", 0, 0) == 1;
            value.FocusOption.ExclusionKihyousyaFromTabOrder = dtoList.GetIdata("NOFOC", "KUSR", 0, 0) == 1;
            value.FocusOption.ExclusionKihyouBumonFromTabOrder = dtoList.GetIdata("NOFOC", "KBMN", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField1FromTabOrder = dtoList.GetIdata("NOFOC", "HF1", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField2FromTabOrder = dtoList.GetIdata("NOFOC", "HF2", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField3FromTabOrder = dtoList.GetIdata("NOFOC", "HF3", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField4FromTabOrder = dtoList.GetIdata("NOFOC", "HF4", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField5FromTabOrder = dtoList.GetIdata("NOFOC", "HF5", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField6FromTabOrder = dtoList.GetIdata("NOFOC", "HF6", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField7FromTabOrder = dtoList.GetIdata("NOFOC", "HF7", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField8FromTabOrder = dtoList.GetIdata("NOFOC", "HF8", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField9FromTabOrder = dtoList.GetIdata("NOFOC", "HF9", 0, 0) == 1;
            value.FocusOption.ExclusionHeaderField10FromTabOrder = dtoList.GetIdata("NOFOC", "HF10", 0, 0) == 1;
            value.FocusOption.ExclusionDenpyouTabaFromTabOrder = dtoList.GetIdata("NOFOC", "KUSR", 0, 0) == 1;
            value.FocusOption.ExclusionSyouninGroupFromTabOrder = dtoList.GetIdata("NOFOC", "SGNO", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField1FromTabOrder = dtoList.GetIdata("NOFOC", "DM1", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField2FromTabOrder = dtoList.GetIdata("NOFOC", "DM2", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField3FromTabOrder = dtoList.GetIdata("NOFOC", "DM3", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField4FromTabOrder = dtoList.GetIdata("NOFOC", "UF4", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField5FromTabOrder = dtoList.GetIdata("NOFOC", "UF5", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField6FromTabOrder = dtoList.GetIdata("NOFOC", "UF6", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField7FromTabOrder = dtoList.GetIdata("NOFOC", "UF7", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField8FromTabOrder = dtoList.GetIdata("NOFOC", "UF8", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField9FromTabOrder = dtoList.GetIdata("NOFOC", "UF9", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField10FromTabOrder = dtoList.GetIdata("NOFOC", "UF10", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField11FromTabOrder = dtoList.GetIdata("NOFOC", "UF11", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField12FromTabOrder = dtoList.GetIdata("NOFOC", "UF12", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField13FromTabOrder = dtoList.GetIdata("NOFOC", "UF13", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField14FromTabOrder = dtoList.GetIdata("NOFOC", "UF14", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField15FromTabOrder = dtoList.GetIdata("NOFOC", "UF15", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField16FromTabOrder = dtoList.GetIdata("NOFOC", "UF16", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField17FromTabOrder = dtoList.GetIdata("NOFOC", "UF17", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField18FromTabOrder = dtoList.GetIdata("NOFOC", "UF18", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField19FromTabOrder = dtoList.GetIdata("NOFOC", "UF19", 0, 0) == 1;
            value.FocusOption.ExclusionUniversalField20FromTabOrder = dtoList.GetIdata("NOFOC", "UF20", 0, 0) == 1;
            value.FocusOption.ExclusionProjectFromTabOrder = dtoList.GetIdata("NOFOC", "PRJ", 0, 0) == 1;
            value.FocusOption.ExclusionSegmentFromTabOrder = dtoList.GetIdata("NOFOC", "SEG", 0, 0) == 1;
            value.FocusOption.ExclusionKouziFromTabOrder = dtoList.GetIdata("NOFOC", "KOJ", 0, 0) == 1;
            value.FocusOption.ExclusionKousyuFromTabOrder = dtoList.GetIdata("NOFOC", "KOS", 0, 0) == 1;
            value.FocusOption.ExclusionTekiyouCodeFromTabOrder = dtoList.GetIdata("NOFOC", "TNO", 0, 0) == 1;
            value.FocusOption.ExclusionKesikomiCodeFromTabOrder = dtoList.GetIdata("NOFOC", "DKEC", 0, 0) == 1;
            value.FocusOption.ExclusionHusenFromTabOrder = dtoList.GetIdata("NOFOC", "FSEN", 0, 0) == 1;
            value.FocusOption.ExclusionGyoukugiriFromTabOrder = dtoList.GetIdata("NOFOC", "GRNO", 0, 1) == 1;
            value.FocusOption.ExclusionSiharaibiFromTabOrder = dtoList.GetIdata("NOFOC", "SYMD", 0, 0) == 1;
            value.FocusOption.ExclusionSiharaiKubunFromTabOrder = dtoList.GetIdata("NOFOC", "SKBN", 0, 0) == 1;
            value.FocusOption.ExclusionSiharaiKizituFromTabOrder = dtoList.GetIdata("NOFOC", "SKIZ", 0, 0) == 1;
            value.FocusOption.ExclusionKaisyuubiFromTabOrder = dtoList.GetIdata("NOFOC", "NYMD", 0, 0) == 1;
            value.FocusOption.ExclusionNyuukinKubunFromTabOrder = dtoList.GetIdata("NOFOC", "NKBN", 0, 0) == 1;
            value.FocusOption.ExclusionKaisyuuKizituFromTabOrder = dtoList.GetIdata("NOFOC", "NKIZ", 0, 0) == 1;
            value.FocusOption.ExclusionTaisyakubetuTekiyoFromTabOrder = dtoList.GetIdata("NOFOC", "BETUTKY", 0, 1) == 1;
            value.FocusOption.ExclusionZyouhouButtonFromTabOrder = dtoList.GetIdata("NOFOC", "SHOW", 0, 1) == 1;
            value.FocusOption.ExclusionItemNotAssociatedInKamokuFromTabOrder = dtoList.GetIdata("NOFOC", "ZANDAKA", 0, 0) == 1;
            value.FocusOption.SkipKazeikubunIfKamokusNextForcusIsKazeikubunEtc = dtoList.GetIdata("ELSE", "SYOSKIP", 0, 1) == 1;
            value.FocusOption.SkipZeirituIfKamokusNextForcusIsKazeikubunEtc = dtoList.GetIdata("ELSE", "ZEISKIP", 0, 1) == 1;
            value.FocusOption.SkipBunrikubunIfKamokusNextForcusIsKazeikubunEtc = dtoList.GetIdata("ELSE", "BUNRISKIP", 0, 1) == 1;
            value.FocusOption.SkipKobetuKubunIfKamokusNextForcusIsKazeikubunEtc = dtoList.GetIdata("ELSE", "KOBETUSKIP", 0, 1) == 1;
            value.FocusOption.FocusMoveLocationAfterSiwakeRegistration = (DenpyouInputFocusMoveLocationAfterSiwakeRegistration)dtoList.GetIdata("ELSE", "STAFOC", 0, 0);
            value.FocusOption.InputTekiyoLastLine = dtoList.GetIdata("ELSE", "TKYENDFOC", 0, 0) == 1;
        }

        private void SetGaikaOption(IList<Option1Dto> dtoList, DenpyouInputOption value)
        {
            value.GaikaOption.HoukaKansan = (DenpyouInputHoukaKansan)dtoList.GetIdata("GAIK", "CHG", 0, 0);
            value.GaikaOption.CheckGaikaKingakuInput = (DenpyouInputCheckInput)dtoList.GetIdata("GAIK", "GINP", 0, 0);
            value.GaikaOption.CheckRateInput = (DenpyouInputCheckInput)dtoList.GetIdata("GAIK", "RINP", 0, 0);
        }

        private void SetDenpyouInputOtherOption(IList<Option1Dto> dtoList, DenpyouInputOption value, string programId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate)
        {
            if (programId == DenpyouSyuuseiProgramId)
            {
                value.OtherOption.EditableZidouKosiwake = dtoList.GetIdata("ELSE", "AUTOMNT", 0, 0) == 1;
                value.OtherOption.LinkToZidouKosiwakeWhenEditOyasiwake = dtoList.GetIdata("ELSE", "AUTOUPD", 0, 1) == 1;
            }
            else
            {
                value.OtherOption.RegisterKingakuMinyuryokuSiwake = dtoList.GetIdata("ELSE", "NOMNY", 0, 1) == 1;
                value.OtherOption.RemoveEmptyLineWhenDenpyouRegister = dtoList.GetIdata("ELSE", "KUGYO", 0, 0) == 1;
                value.OtherOption.ClearDenpyouAfterRegstration = dtoList.GetIdata("ELSE", "INPDAT", 0, 1) == 1;
            }

            value.OtherOption.FocusColor =
                this.ConvertBgrColorCodeToColor(dtoList.GetIdata("ELSE", "INPUTC", 0, this.ConvertColorToBgrColorCode(DenpyouInputDefaultColor.FocusColor)));
            value.OtherOption.NotInputCodeWarningColor =
                this.ConvertBgrColorCodeToColor(dtoList.GetIdata("ELSE", "CHECKC", 0, this.ConvertColorToBgrColorCode(DenpyouInputDefaultColor.NotInputCodeWarningColor)));
            value.OtherOption.MakeTaisyakubetuTekiyoDefaultValue = dtoList.GetIdata("ELSE", "RSTKY", 0, 0) == 1;
            if (this.AvailabeTourokuKakuninTiming(callerProgramDenpyouSiwakeWayToCreate))
            {
                value.OtherOption.TourokuKakuninTiming = (DenpyouInputTourokuKakuninTiming)dtoList.GetIdata("NEXT", string.Empty, 0, 0);
            }
        }

        private void SetUserSharedOptionsPropertiesFromPrgidDinpfri(IList<Option1Dto> dtoList, DenpyouInputOption value) =>
            value.AutoGyoukugiriMode = dtoList.GetIdata("OPT", "4UCOMP", 0, 0) == 1;

        private void StoreHukusyaOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            if (programIdForQuery == DenpyouSyuuseiProgramId)
            {
                // 伝票修正系は複写設定なし
                return;
            }

            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "DYMD", 0, denpyoNyuryokuOption.HukusyaOption.CopyDenpyouHizuke ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "DCNO", 0, (int)denpyoNyuryokuOption.HukusyaOption.CopyDenpyouNo),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "KBMN", 0, denpyoNyuryokuOption.HukusyaOption.CopyKihyoubi ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "KDAY", 0, denpyoNyuryokuOption.HukusyaOption.CopyKihyousya ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "KUSR", 0, denpyoNyuryokuOption.HukusyaOption.CopyKihyouBumon ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "SGNO", 0, denpyoNyuryokuOption.HukusyaOption.CopySyouninGroup ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "TBCD", 0, denpyoNyuryokuOption.HukusyaOption.CopyDenpyouTaba ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF1", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField1 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF2", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField2 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF3", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField3 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF4", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField4 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF5", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField5 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF6", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField6 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF7", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField7 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF8", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField8 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF9", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField9 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "HCOPY", "HF10", 0, denpyoNyuryokuOption.HukusyaOption.CopyHeaderField10 ? 1 : 0),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));

            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TKY", 0, (int)denpyoNyuryokuOption.HukusyaOption.CopyCommonTekiyou),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "LIN1", 0, denpyoNyuryokuOption.HukusyaOption.CopyFromSaisyuSiwakeToSentouSiwake ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KAM", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataKamoku),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "BUM", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataBumon),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TOR", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataTorihikisaki),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "EDA", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataEdaban),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM1", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField1),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM2", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField2),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM3", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField3),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF4", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField4),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF5", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField5),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF6", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField6),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF7", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField7),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF8", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField8),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF9", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField9),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF10", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField10),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF11", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField11),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF12", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField12),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF13", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField13),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF14", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField14),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF15", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField15),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF16", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField16),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF17", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField17),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF18", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField18),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF19", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField19),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF20", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataUniversalField20),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "PRJ", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataProject),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "SEG", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataSegment),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KOJ", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataKouzi),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KOS", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataKousyu),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TKY", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataTekiyou),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TNO", 1, (int)denpyoNyuryokuOption.HukusyaOption.CopyKarikataTekiyouCode),

                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KAM", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataKamoku),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "BUM", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataBumon),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TOR", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataTorihikisaki),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "EDA", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataEdaban),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM1", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField1),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM2", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField2),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "DM3", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField3),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF4", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField4),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF5", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField5),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF6", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField6),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF7", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField7),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF8", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField8),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF9", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField9),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF10", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField10),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF11", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField11),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF12", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField12),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF13", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField13),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF14", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField14),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF15", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField15),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF16", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField16),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF17", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField17),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF18", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField18),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF19", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField19),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "UF20", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataUniversalField20),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "PRJ", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataProject),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "SEG", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataSegment),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KOJ", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataKouzi),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "KOS", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataKousyu),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TKY", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataTekiyou),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "DCOPY", "TNO", 2, (int)denpyoNyuryokuOption.HukusyaOption.CopyKasikataTekiyouCode),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        private void StoreMeisyouItiranhyouOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF1", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField1MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF2", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField2MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF3", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField3MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF4", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField4MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF5", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField5MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF6", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField6MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF7", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField7MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF8", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField8MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF9", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField9MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "HF10", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowHeaderField10MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "KAM", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowKamokuMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "BUM", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowBumonMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "BUMOP", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.BumonMeisyouItiranhyosDisplayContent),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "TRI", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowTorihikisakiMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "TRIOP", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.TorihikiMeisyouItiranhyosDisplayContent),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "EDA", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowEdabanMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "EDAOP", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.EdabanMeisyouItiranhyosDisplayContent),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "DM1", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField1MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "DM2", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField2MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "DM3", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField3MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF4", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField4MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF5", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField5MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF6", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField6MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF7", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField7MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF8", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField8MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF9", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField9MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF10", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField10MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF11", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField11MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF12", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField12MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF13", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField13MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF14", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField14MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF15", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField15MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF16", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField16MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF17", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField17MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF18", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField18MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF19", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField19MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "UF20", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowUniversalField20MeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "PRJ", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowProjectMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "SEG", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowSegmentMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "KOJ", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowKouziMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "KOJOP", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.KouziMeisyouItiranhyousDisplayContent),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "KOS", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowKousyuMeisyoItiranhyo ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "KOSOP", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.KousyuMeisyouItiranhyousDisplayContent),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "TKY", 0, denpyoNyuryokuOption.MeisyouItiranhyouOption.ShowTekiyouMeisyouItiranhyou ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "LIST", "TYPE", 0, (int)denpyoNyuryokuOption.MeisyouItiranhyouOption.DisplayStyle),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        private void StoreKensakuZidouKidouOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "MOJISU", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.ZidouKidouMozisuu),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "KUSR", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Kihyousya ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "KBMN", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.KihyouBumon ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF1", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField1 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF2", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField2 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF3", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField3 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF4", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField4 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF5", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField5 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF6", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField6 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF7", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField7 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF8", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField8 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF9", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField9 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "HF10", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.HeaderField10 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "KAM", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Kamoku ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "BUM", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Bumon ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "TRI", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Torihikisaki ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "EDA", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Edaban ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "DM1", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField1 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "DM2", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField2 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "DM3", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField3 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF4", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField4 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF5", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField5 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF6", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField6 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF7", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField7 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF8", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField8 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF9", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField9 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF10", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField10 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF11", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField11 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF12", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField12 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF13", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField13 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF14", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField14 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF15", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField15 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF16", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField16 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF17", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField17 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF18", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField18 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF19", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField19 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "UF20", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.UniversalField20 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "PRJ", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Project ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "SEG", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Segment ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "KOJ", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Kouzi ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "KOS", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.Kousyu ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "50AUTO", "TNO", 0, denpyoNyuryokuOption.KensakuZidouKidouOption.TekiyouCode ? 1 : 0),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        private void StoreNihongoNyuuryokuOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "KUSR", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Kihyousya ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "KBMN", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.KihyouBumon ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF1", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField1 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF2", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField2 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF3", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField3 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF4", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField4 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF5", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField5 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF6", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField6 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF7", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField7 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF8", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField8 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF9", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField9 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "HF10", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.HeaderField10 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "KAM", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Kamoku ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "BUM", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Bumon ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "TRI", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Torihikisaki ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "EDA", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Edaban ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "DM1", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField1 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "DM2", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField2 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "DM3", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField3 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF4", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField4 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF5", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField5 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF6", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField6 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF7", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField7 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF8", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField8 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF9", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField9 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF10", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField10 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF11", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField11 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF12", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField12 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF13", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField13 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF14", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField14 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF15", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField15 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF16", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField16 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF17", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField17 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF18", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField18 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF19", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField19 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "UF20", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.UniversalField20 ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "PRJ", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Project ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "SEG", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Segment ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "KOJ", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Kouzi ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "KOS", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.Kousyu ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "TNO", 0, denpyoNyuryokuOption.NihongoNyuuryokuOption.TekiyouCode ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "IMEON", "TKY", 0, (int)denpyoNyuryokuOption.NihongoNyuuryokuOption.Tekiyo),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の分割不可")]
        private void StoreFocusOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC");
            var focusOptionList = new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "DCNO", 0, denpyoNyuryokuOption.FocusOption.ExclusionDenpyouNoFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "KDAY", 0, denpyoNyuryokuOption.FocusOption.ExclusionKihyoubiFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "KUSR", 0, denpyoNyuryokuOption.FocusOption.ExclusionKihyousyaFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "KBMN", 0, denpyoNyuryokuOption.FocusOption.ExclusionKihyouBumonFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF1", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField1FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF2", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField2FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF3", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField3FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF4", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField4FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF5", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField5FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF6", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField6FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF7", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField7FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF8", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField8FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF9", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField9FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "HF10", 0, denpyoNyuryokuOption.FocusOption.ExclusionHeaderField10FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "TBCD", 0, denpyoNyuryokuOption.FocusOption.ExclusionDenpyouTabaFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SGNO", 0, denpyoNyuryokuOption.FocusOption.ExclusionSyouninGroupFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "DM1", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField1FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "DM2", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField2FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "DM3", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField3FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF4", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField4FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF5", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField5FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF6", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField6FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF7", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField7FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF8", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField8FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF9", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField9FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF10", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField10FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF11", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField11FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF12", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField12FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF13", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField13FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF14", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField14FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF15", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField15FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF16", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField16FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF17", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField17FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF18", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField18FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF19", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField19FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "UF20", 0, denpyoNyuryokuOption.FocusOption.ExclusionUniversalField20FromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "PRJ", 0, denpyoNyuryokuOption.FocusOption.ExclusionProjectFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SEG", 0, denpyoNyuryokuOption.FocusOption.ExclusionSegmentFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "KOJ", 0, denpyoNyuryokuOption.FocusOption.ExclusionKouziFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "KOS", 0, denpyoNyuryokuOption.FocusOption.ExclusionKousyuFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "TNO", 0, denpyoNyuryokuOption.FocusOption.ExclusionTekiyouCodeFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "DKEC", 0, denpyoNyuryokuOption.FocusOption.ExclusionKesikomiCodeFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "FSEN", 0, denpyoNyuryokuOption.FocusOption.ExclusionHusenFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "GRNO", 0, denpyoNyuryokuOption.FocusOption.ExclusionGyoukugiriFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SYMD", 0, denpyoNyuryokuOption.FocusOption.ExclusionSiharaibiFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SKBN", 0, denpyoNyuryokuOption.FocusOption.ExclusionSiharaiKubunFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SKIZ", 0, denpyoNyuryokuOption.FocusOption.ExclusionSiharaiKizituFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "NYMD", 0, denpyoNyuryokuOption.FocusOption.ExclusionKaisyuubiFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "NKBN", 0, denpyoNyuryokuOption.FocusOption.ExclusionNyuukinKubunFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "NKIZ", 0, denpyoNyuryokuOption.FocusOption.ExclusionKaisyuuKizituFromTabOrder ? 1 : 0),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "BETUTKY", 0, denpyoNyuryokuOption.FocusOption.ExclusionTaisyakubetuTekiyoFromTabOrder ? 1 : 0),
            };
            if (programIdForQuery == DenpyouSyuuseiProgramId)
            {
                focusOptionList.Add(new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "SHOW", 0, denpyoNyuryokuOption.FocusOption.ExclusionZyouhouButtonFromTabOrder ? 1 : 0));
            }

            focusOptionList.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));

            this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "SYOSKIP", 0, denpyoNyuryokuOption.FocusOption.SkipKazeikubunIfKamokusNextForcusIsKazeikubunEtc ? 1 : 0);
            this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "ZEISKIP", 0, denpyoNyuryokuOption.FocusOption.SkipZeirituIfKamokusNextForcusIsKazeikubunEtc ? 1 : 0);
            this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "BUNRISKIP", 0, denpyoNyuryokuOption.FocusOption.SkipBunrikubunIfKamokusNextForcusIsKazeikubunEtc ? 1 : 0);
            this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "KOBETUSKIP", 0, denpyoNyuryokuOption.FocusOption.SkipKobetuKubunIfKamokusNextForcusIsKazeikubunEtc ? 1 : 0);
            this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "TKYENDFOC", 0, denpyoNyuryokuOption.FocusOption.InputTekiyoLastLine ? 1 : 0);

            if (programIdForQuery == DenpyouNyuuryokuProgramId)
            {
                this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "NOFOC", "ZANDAKA", 0, denpyoNyuryokuOption.FocusOption.ExclusionItemNotAssociatedInKamokuFromTabOrder ? 1 : 0);
                this.StoreOption(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "ELSE", "STAFOC", 0, (int)denpyoNyuryokuOption.FocusOption.FocusMoveLocationAfterSiwakeRegistration);
            }
        }

        private void StoreGaikaOption(DenpyouInputOption denpyoNyuryokuOption, string programIdForQuery)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programIdForQuery, denpyoNyuryokuOption.UserCode, "GAIK");
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "GAIK", "CHG", 0, (int)denpyoNyuryokuOption.GaikaOption.HoukaKansan),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "GAIK", "GINP", 0, (int)denpyoNyuryokuOption.GaikaOption.CheckGaikaKingakuInput),
                new Option1Dto().SetValues(programIdForQuery, denpyoNyuryokuOption.UserCode, "GAIK", "RINP", 0, (int)denpyoNyuryokuOption.GaikaOption.CheckRateInput),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        private void StoreDenpyouInputOtherOption(DenpyouInputOption denpyoNyuryokuOption, string optionProgramId, DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate)
        {
            this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "INPUTC", 0, this.ConvertColorToBgrColorCode(denpyoNyuryokuOption.OtherOption.FocusColor));
            this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "CHECKC", 0, this.ConvertColorToBgrColorCode(denpyoNyuryokuOption.OtherOption.NotInputCodeWarningColor));
            this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "RSTKY", 0, denpyoNyuryokuOption.OtherOption.MakeTaisyakubetuTekiyoDefaultValue ? 1 : 0);

            if (optionProgramId == DenpyouNyuuryokuProgramId)
            {
                this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "NOMNY", 0, denpyoNyuryokuOption.OtherOption.RegisterKingakuMinyuryokuSiwake ? 1 : 0);
                this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "INPDAT", 0, denpyoNyuryokuOption.OtherOption.ClearDenpyouAfterRegstration ? 1 : 0);
                this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "KUGYO", 0, denpyoNyuryokuOption.OtherOption.RemoveEmptyLineWhenDenpyouRegister ? 1 : 0);
                return;
            }

            this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "AUTOMNT", 0, denpyoNyuryokuOption.OtherOption.EditableZidouKosiwake ? 1 : 0);
            this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "ELSE", "AUTOUPD", 0, denpyoNyuryokuOption.OtherOption.LinkToZidouKosiwakeWhenEditOyasiwake ? 1 : 0);

            if (this.AvailabeTourokuKakuninTiming(callerProgramDenpyouSiwakeWayToCreate))
            {
                this.StoreOption(DatabaseType.KaisyaDb, optionProgramId, denpyoNyuryokuOption.UserCode, "NEXT", string.Empty, 0, denpyoNyuryokuOption.OtherOption.TourokuKakuninTiming == DenpyouInputTourokuKakuninTiming.SiwakeTanni ? 0 : 1);
            }
        }

        private bool AvailabeTourokuKakuninTiming(DenpyouSiwakeWayToCreate callerProgramDenpyouSiwakeWayToCreate) =>
            callerProgramDenpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Dscan
            || callerProgramDenpyouSiwakeWayToCreate == DenpyouSiwakeWayToCreate.Sdscan;

        /// <summary>
        /// オプションを削除後に追加
        /// </summary>
        /// <param name="databaseType"></param>
        /// <param name="programIdForQuery"></param>
        /// <param name="usno"></param>
        /// <param name="keyNm1"></param>
        /// <param name="keyNm2"></param>
        /// <param name="keyno"></param>
        /// <param name="value"></param>
        private void StoreOption(DatabaseType databaseType, string programIdForQuery, int usno, string keyNm1, string keyNm2, short keyno, int value)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1AndKeyNm2(databaseType, programIdForQuery, usno, keyNm1, keyNm2);
            this.option1Dao.Insert(databaseType, new Option1Dto().SetValues(programIdForQuery, usno, keyNm1, keyNm2, keyno, value));
        }

        /// <summary>
        /// BGRカラーコードをColorに変換
        /// </summary>
        /// <param name="colorCode"></param>
        /// <returns></returns>
        private Color ConvertBgrColorCodeToColor(int colorCode)
        {
            var redValue = colorCode & BlueBitMask;
            var greenValue = (colorCode & GreenBitMask) / GreenShiftValue;
            var blueValue = (colorCode & RedBitMask) / RedShiftValue;
            return Color.FromArgb(redValue, greenValue, blueValue);
        }

        /// <summary>
        /// ColorをBGRカラーコードに変換
        /// </summary>
        /// <param name="color"></param>
        /// <returns></returns>
        private int ConvertColorToBgrColorCode(Color color)
        {
            // 選択された色の取得
            var argbColorCode = color.ToArgb();

            // アルファ情報削除
            var rgbCode = argbColorCode & RgbBitMask;

            // 青赤の位置がＴＤと違うため反転(コンバージョンを想定)
            var redCode = rgbCode & RedBitMask;
            var greenCode = rgbCode & GreenBitMask;
            var blueCode = rgbCode & BlueBitMask;

            return (redCode != 0 ? redCode / RedShiftValue : 0) + greenCode + (blueCode * RedShiftValue);
        }
    }
}