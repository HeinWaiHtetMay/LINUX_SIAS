﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TeikeiSiwakeGyouRepository : ITeikeiSiwakeGyouRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<TeikeiSiwakeGyou> FindByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumberOrderByLineNo(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber) =>
            this.dbc.QueryForList(
                "SELECT styp, ptyp, ptno, dlin, gflg, aflg, rbmn, rtor, rkmk, reda, rkoj, rkos, rprj, rseg, rdm1, rdm2, rdm3, rtky, rtno, rimg, rexv, rval, rzei, rrit, rzkb, rgyo, rsre, rbkbn, rdkec, rfsen, rsyok, rsyoe, rsymd, rskbn, rskiz, ruymd, rukbn, rukiz, rzkmk, rzrit, rzzkb, rzgyo, rzsre, rcdm1, rcdm2, rsdm3, rsdm4, ridm5, ridm6, sbmn, stor, skmk, seda, skoj, skos, sprj, sseg, sdm1, sdm2, sdm3, stky, stno, simg, sexv, sval, szei, srit, szkb, sgyo, ssre, sbkbn, sdkec, sfsen, ssyok, ssyoe, ssymd, sskbn, sskiz, suymd, sukbn, sukiz, szkmk, szrit, szzkb, szgyo, szsre, scdm1, scdm2, ssdm3, ssdm4, sidm5, sidm6, rhei_cd, rrate, rgaika, rgexvl, rgzei, ridm7, shei_cd, srate, sgaika, sgexvl, sgzei, sidm7, rdm4, rdm5, rdm6, rdm7, rdm8, rdm9, rdm10, rdm11, rdm12, rdm13, rdm14, rdm15, rdm16, rdm17, rdm18, rdm19, rdm20, sdm4, sdm5, sdm6, sdm7, sdm8, sdm9, sdm10, sdm11, sdm12, sdm13, sdm14, sdm15, sdm16, sdm17, sdm18, sdm19, sdm20, tekiflg, rkeigen, rzkeigen, skeigen, szkeigen " +
                "FROM dindata " +
                "WHERE styp = :p AND ptyp = :p AND ptno = :p ORDER BY dlin",
                (values, no) =>
                {
                    var row = new TeikeiSiwakeGyou(teikeiSiwakeSystemType, userCode, patternNumber, (int)(short)values[3]);
                    row.IsGyouKugiri = (short)values[4] == 1; // 行区切
                    row.BunriType = (TeikeiSiwakeBunriType)(short)values[5]; // 自動仕訳行
                    row.KarikataBumonCode = DbNullConverter.ToString(values[6], null); // 借）部門
                    row.KarikataTorihikisakiCode = DbNullConverter.ToString(values[7], null); // 借）取引先
                    row.KarikataKamokuCode = DbNullConverter.ToString(values[8], null); // 借）科目
                    row.KarikataEdabanCode = DbNullConverter.ToString(values[9], null); // 借）枝番
                    row.KarikataKouziCode = DbNullConverter.ToString(values[10], null); // 借）工事
                    row.KarikataKousyuCode = DbNullConverter.ToString(values[11], null); // 借）工種
                    row.KarikataProjectCode = DbNullConverter.ToString(values[12], null); // 借）ﾌﾟﾛｼﾞｪｸﾄ
                    row.KarikataSegmentCode = DbNullConverter.ToString(values[13], null); // 借）ｾｸﾞﾒﾝﾄ
                    row.KarikataUniversalField1Code = DbNullConverter.ToString(values[14], null); // "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.KarikataUniversalField2Code = DbNullConverter.ToString(values[15], null); // "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.KarikataUniversalField3Code = DbNullConverter.ToString(values[16], null); // "借） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.KarikataTekiyou = DbNullConverter.ToString(values[17], null); // 借）摘要
                    row.KarikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[18]); // 借）摘要ｺｰﾄﾞ
                    row.KarikataTekiyouImage = (int)values[19]; // 借）ｲﾒｰｼﾞ
                    row.KarikataTaika = DbNullConverter.ToNullableDecimal(values[20]); // 借）対価
                    row.KarikataKingaku = DbNullConverter.ToNullableDecimal(values[21]); // 借）金額
                    row.KarikataZeigaku = DbNullConverter.ToNullableDecimal(values[22]); // 借）税額
                    row.KarikataZeiritu = DbNullConverter.ToNullableInt(values[23]); // 借）税率
                    row.KarikataKazeiKubun = (KazeiKubun?)(int?)DbNullConverter.ToNullableShort(values[24]); // 借）課税区分
                    row.KarikataGyousyuKubun = (GyousyuKubun?)(int?)DbNullConverter.ToNullableShort(values[25]); // 借）業種区分
                    row.KarikataSiireKubun = (SiwakeSiireKubun?)(int?)DbNullConverter.ToNullableShort(values[26]); // 借）個別区分
                    row.KarikataBunriKubun = (BunriKubun?)(int?)DbNullConverter.ToNullableShort(values[27]); // 借）分離区分
                    row.KarikataKesikomiCode = DbNullConverter.ToString(values[28], null); // 借）消込
                    row.KarikataHusen = (SiwakeHusen)((int?)DbNullConverter.ToNullableShort(values[29]) ?? 0); // 借）付箋
                    row.KarikataSyokutiKubun = (int?)DbNullConverter.ToNullableShort(values[30]); // 借）諸口区分
                    row.KarikataSyokutiEdaban = DbNullConverter.ToString(values[31], null); // 借）諸口枝番
                    row.KarikataSiharaibi = DbNullConverter.ToNullableInt(values[32]); // 借）支払日
                    row.KarikataSiharaiKubun = (int?)DbNullConverter.ToNullableShort(values[33]); // 借）支払区分
                    row.KarikataSiharaiKizitu = DbNullConverter.ToNullableInt(values[34]); // 借）支払期日
                    row.KarikataKaisyuubi = DbNullConverter.ToNullableInt(values[35]); // 借）受取日
                    row.KarikataNyuukinKubun = (int?)DbNullConverter.ToNullableShort(values[36]); // 借）受取区分
                    row.KarikataKaisyuuKizitu = DbNullConverter.ToNullableInt(values[37]); // 借）受取期日
                    row.KarikataZeitaisyouKamokuCode = DbNullConverter.ToString(values[38], null); // 借）税額－科目
                    row.KarikataZeitaisyouKamokuZeiritu = DbNullConverter.ToNullableInt(values[39]); // 借）税額－税率
                    row.KarikataZeitaisyouKamokuKazeiKubun = (KazeiKubun?)(int?)DbNullConverter.ToNullableShort(values[40]); // "借）税額－ 課税区分"
                    row.KarikataZeitaisyouKamokuGyousyuKubun = (GyousyuKubun?)(int?)DbNullConverter.ToNullableShort(values[41]); // "借）税額－ 業種区分"
                    row.KarikataZeitaisyouKamokuSiireKubun = (SiwakeSiireKubun?)(int?)DbNullConverter.ToNullableShort(values[42]); // "借）税額－ 個別区分"
                    row.KasikataBumonCode = DbNullConverter.ToString(values[49], null); // 貸）部門
                    row.KasikataTorihikisakiCode = DbNullConverter.ToString(values[50], null); // 貸）取引先
                    row.KasikataKamokuCode = DbNullConverter.ToString(values[51], null); // 貸）科目
                    row.KasikataEdabanCode = DbNullConverter.ToString(values[52], null); // 貸）枝番
                    row.KasikataKouziCode = DbNullConverter.ToString(values[53], null); // 貸）工事
                    row.KasikataKousyuCode = DbNullConverter.ToString(values[54], null); // 貸）工種
                    row.KasikataProjectCode = DbNullConverter.ToString(values[55], null); // 貸）ﾌﾟﾛｼﾞｪｸﾄ
                    row.KasikataSegmentCode = DbNullConverter.ToString(values[56], null); // 貸）ｾｸﾞﾒﾝﾄ
                    row.KasikataUniversalField1Code = DbNullConverter.ToString(values[57], null); // "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1"
                    row.KasikataUniversalField2Code = DbNullConverter.ToString(values[58], null); // "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2"
                    row.KasikataUniversalField3Code = DbNullConverter.ToString(values[59], null); // "貸） ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3"
                    row.KasikataTekiyou = DbNullConverter.ToString(values[60], null); // 貸）摘要
                    row.KasikataTekiyouCode = (int?)DbNullConverter.ToNullableShort(values[61]); // 貸）摘要ｺｰﾄﾞ
                    row.KasikataTekiyouImage = (int)values[62]; // 貸）ｲﾒｰｼﾞ
                    row.KasikataTaika = DbNullConverter.ToNullableDecimal(values[63]); // 貸）対価
                    row.KasikataKingaku = DbNullConverter.ToNullableDecimal(values[64]); // 貸）金額
                    row.KasikataZeigaku = DbNullConverter.ToNullableDecimal(values[65]); // 貸）税額
                    row.KasikataZeiritu = DbNullConverter.ToNullableInt(values[66]); // 貸）税率
                    row.KasikataKazeiKubun = (KazeiKubun?)(int?)DbNullConverter.ToNullableShort(values[67]); // 貸）課税区分
                    row.KasikataGyousyuKubun = (GyousyuKubun?)(int?)DbNullConverter.ToNullableShort(values[68]); // 貸）業種区分
                    row.KasikataSiireKubun = (SiwakeSiireKubun?)(int?)DbNullConverter.ToNullableShort(values[69]); // 貸）個別区分
                    row.KasikataBunriKubun = (BunriKubun?)(int?)DbNullConverter.ToNullableShort(values[70]); // 貸）分離区分
                    row.KasikataKesikomiCode = DbNullConverter.ToString(values[71], null); // 貸）消込
                    row.KasikataHusen = (SiwakeHusen)((int?)DbNullConverter.ToNullableShort(values[72]) ?? 0); // 貸）付箋
                    row.KasikataSyokutiKubun = (int?)DbNullConverter.ToNullableShort(values[73]); // 貸）諸口区分
                    row.KasikataSyokutiEdaban = DbNullConverter.ToString(values[74], null); // 貸）諸口枝番
                    row.KasikataSiharaibi = DbNullConverter.ToNullableInt(values[75]); // 貸）支払日
                    row.KasikataSiharaiKubun = (int?)DbNullConverter.ToNullableShort(values[76]); // 貸）支払区分
                    row.KasikataSiharaiKizitu = DbNullConverter.ToNullableInt(values[77]); // 貸）支払期日
                    row.KasikataKaisyuubi = DbNullConverter.ToNullableInt(values[78]); // 貸）受取日
                    row.KasikataNyuukinKubun = (int?)DbNullConverter.ToNullableShort(values[79]); // 貸）受取区分
                    row.KasikataKaisyuuKizitu = DbNullConverter.ToNullableInt(values[80]); // 貸）受取期日
                    row.KasikataZeitaisyouKamokuCode = DbNullConverter.ToString(values[81], null); // 貸）税額－科目
                    row.KasikataZeitaisyouKamokuZeiritu = DbNullConverter.ToNullableInt(values[82]); // 貸）税額－税率
                    row.KasikataZeitaisyouKamokuKazeiKubun = (KazeiKubun?)(int?)DbNullConverter.ToNullableShort(values[83]); // "貸）税額－ 課税区分"
                    row.KasikataZeitaisyouKamokuGyousyuKubun = (GyousyuKubun?)(int?)DbNullConverter.ToNullableShort(values[84]); // "貸）税額－ 業種区分"
                    row.KasikataZeitaisyouKamokuSiireKubun = (SiwakeSiireKubun?)(int?)DbNullConverter.ToNullableShort(values[85]); // "貸）税額－ 個別区分"
                    row.KarikataHeisyuCode = DbNullConverter.ToString(values[92], null); // 借）通貨コード
                    row.KarikataRate = DbNullConverter.ToNullableDecimal(values[93]); // 借）レート
                    row.KarikataGaikaKingaku = DbNullConverter.ToNullableDecimal(values[94]); // 借）外貨金額
                    row.KarikataGaikaTaika = DbNullConverter.ToNullableDecimal(values[95]); // 借）外貨対価
                    row.KarikataGaikaZeigaku = DbNullConverter.ToNullableDecimal(values[96]); // 借）外貨税額
                    row.KasikataHeisyuCode = DbNullConverter.ToString(values[98], null); // 貸）通貨コード
                    row.KasikataRate = DbNullConverter.ToNullableDecimal(values[99]); // 貸）レート
                    row.KasikataGaikaKingaku = DbNullConverter.ToNullableDecimal(values[100]); // 貸）外貨金額
                    row.KasikataGaikaTaika = DbNullConverter.ToNullableDecimal(values[101]); // 貸）外貨対価
                    row.KasikataGaikaZeigaku = DbNullConverter.ToNullableDecimal(values[102]); // 貸）外貨税額
                    row.KarikataUniversalField4Code = DbNullConverter.ToString(values[104], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.KarikataUniversalField5Code = DbNullConverter.ToString(values[105], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.KarikataUniversalField6Code = DbNullConverter.ToString(values[106], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.KarikataUniversalField7Code = DbNullConverter.ToString(values[107], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.KarikataUniversalField8Code = DbNullConverter.ToString(values[108], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.KarikataUniversalField9Code = DbNullConverter.ToString(values[109], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.KarikataUniversalField10Code = DbNullConverter.ToString(values[110], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.KarikataUniversalField11Code = DbNullConverter.ToString(values[111], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.KarikataUniversalField12Code = DbNullConverter.ToString(values[112], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.KarikataUniversalField13Code = DbNullConverter.ToString(values[113], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.KarikataUniversalField14Code = DbNullConverter.ToString(values[114], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.KarikataUniversalField15Code = DbNullConverter.ToString(values[115], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.KarikataUniversalField16Code = DbNullConverter.ToString(values[116], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.KarikataUniversalField17Code = DbNullConverter.ToString(values[117], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.KarikataUniversalField18Code = DbNullConverter.ToString(values[118], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.KarikataUniversalField19Code = DbNullConverter.ToString(values[119], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.KarikataUniversalField20Code = DbNullConverter.ToString(values[120], null); // "借） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.KasikataUniversalField4Code = DbNullConverter.ToString(values[121], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4"
                    row.KasikataUniversalField5Code = DbNullConverter.ToString(values[122], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5"
                    row.KasikataUniversalField6Code = DbNullConverter.ToString(values[123], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6"
                    row.KasikataUniversalField7Code = DbNullConverter.ToString(values[124], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7"
                    row.KasikataUniversalField8Code = DbNullConverter.ToString(values[125], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8"
                    row.KasikataUniversalField9Code = DbNullConverter.ToString(values[126], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9"
                    row.KasikataUniversalField10Code = DbNullConverter.ToString(values[127], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10"
                    row.KasikataUniversalField11Code = DbNullConverter.ToString(values[128], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ11"
                    row.KasikataUniversalField12Code = DbNullConverter.ToString(values[129], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ12"
                    row.KasikataUniversalField13Code = DbNullConverter.ToString(values[130], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ13"
                    row.KasikataUniversalField14Code = DbNullConverter.ToString(values[131], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ14"
                    row.KasikataUniversalField15Code = DbNullConverter.ToString(values[132], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ15"
                    row.KasikataUniversalField16Code = DbNullConverter.ToString(values[133], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ16"
                    row.KasikataUniversalField17Code = DbNullConverter.ToString(values[134], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ17"
                    row.KasikataUniversalField18Code = DbNullConverter.ToString(values[135], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ18"
                    row.KasikataUniversalField19Code = DbNullConverter.ToString(values[136], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ19"
                    row.KasikataUniversalField20Code = DbNullConverter.ToString(values[137], null); // "貸） 明細ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ20"
                    row.IsTaisyakubetuTekiyou = (short)values[138] == 1; // 貸借摘要フラグ
                    row.IsKeigenZeirituKarikata = (short)values[139] == 1; // 借）軽減税率区分
                    row.IsKeigenZeirituKarikataZeitaisyouKamoku = (short)values[140] == 1; // 借）税額－軽減税率区分
                    row.IsKeigenZeirituKasikata = (short)values[141] == 1; // 貸）軽減税率区分
                    row.IsKeigenZeirituKasikataZeitaisyouKamoku = (short)values[142] == 1; // 貸）税額－軽減税率区分
                    return row;
                },
                () => new List<TeikeiSiwakeGyou>(),
                (short)teikeiSiwakeSystemType,
                userCode,
                patternNumber);

        public virtual void DeleteByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumber(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode, int patternNumber) =>
            this.dbc.Execute(
                "DELETE FROM dindata WHERE styp = :p AND ptyp = :p AND ptno = :p ",
                new object[] { (short)teikeiSiwakeSystemType, (short)userCode, (short)patternNumber });

        public virtual void Insert(TeikeiSiwakeGyou teikeiSiwakeGyou)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("dindata");
            insertSqlStatementBuilder.AppendColumnNameAndValue("styp", (short)teikeiSiwakeGyou.TeikeiSiwakeSystemType);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ptyp", (short)teikeiSiwakeGyou.UserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ptno", (short)teikeiSiwakeGyou.PatternNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dlin", (short)teikeiSiwakeGyou.LineNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("gflg", teikeiSiwakeGyou.IsGyouKugiri ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("aflg", (short)teikeiSiwakeGyou.BunriType);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rbmn", teikeiSiwakeGyou.KarikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtor", teikeiSiwakeGyou.KarikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkmk", teikeiSiwakeGyou.KarikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("reda", teikeiSiwakeGyou.KarikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkoj", teikeiSiwakeGyou.KarikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkos", teikeiSiwakeGyou.KarikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rprj", teikeiSiwakeGyou.KarikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rseg", teikeiSiwakeGyou.KarikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm1", teikeiSiwakeGyou.KarikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm2", teikeiSiwakeGyou.KarikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm3", teikeiSiwakeGyou.KarikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtky", teikeiSiwakeGyou.KarikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rtno", teikeiSiwakeGyou.KarikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rimg", teikeiSiwakeGyou.KarikataTekiyouImage);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rexv", teikeiSiwakeGyou.KarikataTaika);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rval", teikeiSiwakeGyou.KarikataKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzei", teikeiSiwakeGyou.KarikataZeigaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rrit", teikeiSiwakeGyou.KarikataZeiritu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzkb", (short?)teikeiSiwakeGyou.KarikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgyo", (short?)teikeiSiwakeGyou.KarikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsre", (short?)teikeiSiwakeGyou.KarikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rbkbn", (short?)teikeiSiwakeGyou.KarikataBunriKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdkec", teikeiSiwakeGyou.KarikataKesikomiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rfsen", (short?)teikeiSiwakeGyou.KarikataHusen);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsyok", teikeiSiwakeGyou.KarikataSyokutiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsyoe", teikeiSiwakeGyou.KarikataSyokutiEdaban);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsymd", teikeiSiwakeGyou.KarikataSiharaibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rskbn", teikeiSiwakeGyou.KarikataSiharaiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rskiz", teikeiSiwakeGyou.KarikataSiharaiKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ruymd", teikeiSiwakeGyou.KarikataKaisyuubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rukbn", teikeiSiwakeGyou.KarikataNyuukinKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rukiz", teikeiSiwakeGyou.KarikataKaisyuuKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzkmk", teikeiSiwakeGyou.KarikataZeitaisyouKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzrit", teikeiSiwakeGyou.KarikataZeitaisyouKamokuZeiritu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzzkb", (short?)teikeiSiwakeGyou.KarikataZeitaisyouKamokuKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzgyo", (short?)teikeiSiwakeGyou.KarikataZeitaisyouKamokuGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzsre", (short?)teikeiSiwakeGyou.KarikataZeitaisyouKamokuSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rcdm1", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rcdm2", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsdm3", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rsdm4", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ridm5", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ridm6", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sbmn", teikeiSiwakeGyou.KasikataBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stor", teikeiSiwakeGyou.KasikataTorihikisakiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skmk", teikeiSiwakeGyou.KasikataKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("seda", teikeiSiwakeGyou.KasikataEdabanCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skoj", teikeiSiwakeGyou.KasikataKouziCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skos", teikeiSiwakeGyou.KasikataKousyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sprj", teikeiSiwakeGyou.KasikataProjectCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sseg", teikeiSiwakeGyou.KasikataSegmentCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm1", teikeiSiwakeGyou.KasikataUniversalField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm2", teikeiSiwakeGyou.KasikataUniversalField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm3", teikeiSiwakeGyou.KasikataUniversalField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stky", teikeiSiwakeGyou.KasikataTekiyou);
            insertSqlStatementBuilder.AppendColumnNameAndValue("stno", teikeiSiwakeGyou.KasikataTekiyouCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("simg", teikeiSiwakeGyou.KasikataTekiyouImage);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sexv", teikeiSiwakeGyou.KasikataTaika);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sval", teikeiSiwakeGyou.KasikataKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szei", teikeiSiwakeGyou.KasikataZeigaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("srit", teikeiSiwakeGyou.KasikataZeiritu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szkb", (short?)teikeiSiwakeGyou.KasikataKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgyo", (short?)teikeiSiwakeGyou.KasikataGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssre", (short?)teikeiSiwakeGyou.KasikataSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sbkbn", (short?)teikeiSiwakeGyou.KasikataBunriKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdkec", teikeiSiwakeGyou.KasikataKesikomiCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sfsen", (short)teikeiSiwakeGyou.KasikataHusen);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssyok", teikeiSiwakeGyou.KasikataSyokutiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssyoe", teikeiSiwakeGyou.KasikataSyokutiEdaban);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssymd", teikeiSiwakeGyou.KasikataSiharaibi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sskbn", teikeiSiwakeGyou.KasikataSiharaiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sskiz", teikeiSiwakeGyou.KasikataSiharaiKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("suymd", teikeiSiwakeGyou.KasikataKaisyuubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sukbn", teikeiSiwakeGyou.KasikataNyuukinKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sukiz", teikeiSiwakeGyou.KasikataKaisyuuKizitu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szkmk", teikeiSiwakeGyou.KasikataZeitaisyouKamokuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szrit", teikeiSiwakeGyou.KasikataZeitaisyouKamokuZeiritu);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szzkb", (short?)teikeiSiwakeGyou.KasikataZeitaisyouKamokuKazeiKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szgyo", (short?)teikeiSiwakeGyou.KasikataZeitaisyouKamokuGyousyuKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szsre", (short?)teikeiSiwakeGyou.KasikataZeitaisyouKamokuSiireKubun);
            insertSqlStatementBuilder.AppendColumnNameAndValue("scdm1", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("scdm2", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssdm3", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ssdm4", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sidm5", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sidm6", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rhei_cd", teikeiSiwakeGyou.KarikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rrate", teikeiSiwakeGyou.KarikataRate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgaika", teikeiSiwakeGyou.KarikataGaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgexvl", teikeiSiwakeGyou.KarikataGaikaTaika);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rgzei", teikeiSiwakeGyou.KarikataGaikaZeigaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ridm7", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("shei_cd", teikeiSiwakeGyou.KasikataHeisyuCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("srate", teikeiSiwakeGyou.KasikataRate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgaika", teikeiSiwakeGyou.KasikataGaikaKingaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgexvl", teikeiSiwakeGyou.KasikataGaikaTaika);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgzei", teikeiSiwakeGyou.KasikataGaikaZeigaku);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sidm7", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm4", teikeiSiwakeGyou.KarikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm5", teikeiSiwakeGyou.KarikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm6", teikeiSiwakeGyou.KarikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm7", teikeiSiwakeGyou.KarikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm8", teikeiSiwakeGyou.KarikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm9", teikeiSiwakeGyou.KarikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm10", teikeiSiwakeGyou.KarikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm11", teikeiSiwakeGyou.KarikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm12", teikeiSiwakeGyou.KarikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm13", teikeiSiwakeGyou.KarikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm14", teikeiSiwakeGyou.KarikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm15", teikeiSiwakeGyou.KarikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm16", teikeiSiwakeGyou.KarikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm17", teikeiSiwakeGyou.KarikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm18", teikeiSiwakeGyou.KarikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm19", teikeiSiwakeGyou.KarikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rdm20", teikeiSiwakeGyou.KarikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm4", teikeiSiwakeGyou.KasikataUniversalField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm5", teikeiSiwakeGyou.KasikataUniversalField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm6", teikeiSiwakeGyou.KasikataUniversalField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm7", teikeiSiwakeGyou.KasikataUniversalField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm8", teikeiSiwakeGyou.KasikataUniversalField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm9", teikeiSiwakeGyou.KasikataUniversalField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm10", teikeiSiwakeGyou.KasikataUniversalField10Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm11", teikeiSiwakeGyou.KasikataUniversalField11Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm12", teikeiSiwakeGyou.KasikataUniversalField12Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm13", teikeiSiwakeGyou.KasikataUniversalField13Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm14", teikeiSiwakeGyou.KasikataUniversalField14Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm15", teikeiSiwakeGyou.KasikataUniversalField15Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm16", teikeiSiwakeGyou.KasikataUniversalField16Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm17", teikeiSiwakeGyou.KasikataUniversalField17Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm18", teikeiSiwakeGyou.KasikataUniversalField18Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm19", teikeiSiwakeGyou.KasikataUniversalField19Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm20", teikeiSiwakeGyou.KasikataUniversalField20Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tekiflg", teikeiSiwakeGyou.IsTaisyakubetuTekiyou ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rkeigen", teikeiSiwakeGyou.IsKeigenZeirituKarikata ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("rzkeigen", teikeiSiwakeGyou.IsKeigenZeirituKarikataZeitaisyouKamoku ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("skeigen", teikeiSiwakeGyou.IsKeigenZeirituKasikata ? 1 : 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("szkeigen", teikeiSiwakeGyou.IsKeigenZeirituKasikataZeitaisyouKamoku ? 1 : 0);
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());
        }

        public virtual void UpdateZeirituAndZeigaku(TeikeiSiwakeGyou teikeiSiwakeGyou)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dindata SET ");
            updateQuery.AppendLine("rzei = :p, ", teikeiSiwakeGyou.KarikataZeigaku);
            updateQuery.AppendLine("rrit = :p, ", teikeiSiwakeGyou.KarikataZeiritu);
            updateQuery.AppendLine("rzrit = :p, ", teikeiSiwakeGyou.KarikataZeitaisyouKamokuZeiritu);
            updateQuery.AppendLine("szei = :p, ", teikeiSiwakeGyou.KasikataZeigaku);
            updateQuery.AppendLine("srit = :p, ", teikeiSiwakeGyou.KasikataZeiritu);
            updateQuery.AppendLine("szrit = :p, ", teikeiSiwakeGyou.KasikataZeitaisyouKamokuZeiritu);
            updateQuery.AppendLine("rgzei = :p, ", teikeiSiwakeGyou.KarikataGaikaZeigaku);
            updateQuery.AppendLine("sgzei = :p, ", teikeiSiwakeGyou.KasikataGaikaZeigaku);
            updateQuery.AppendLine("rkeigen = :p, ", teikeiSiwakeGyou.IsKeigenZeirituKarikata);
            updateQuery.AppendLine("rzkeigen = :p, ", teikeiSiwakeGyou.IsKeigenZeirituKarikataZeitaisyouKamoku ? 1 : 0);
            updateQuery.AppendLine("skeigen = :p, ", teikeiSiwakeGyou.IsKeigenZeirituKasikata);
            updateQuery.AppendLine("szkeigen = :p ", teikeiSiwakeGyou.IsKeigenZeirituKasikataZeitaisyouKamoku ? 1 : 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakeGyou.TeikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p AND ", teikeiSiwakeGyou.UserCode);
            updateQuery.AppendLine("ptno = :p AND ", teikeiSiwakeGyou.PatternNumber);
            updateQuery.AppendLine("dlin = :p ", teikeiSiwakeGyou.LineNo);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }
    }
}
