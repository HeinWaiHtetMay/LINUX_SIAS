﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TeikeiSiwakePatternRepository : ITeikeiSiwakePatternRepository
    {
        /// <summary>
        /// 共通パターンの場合にユーザーコード10000ではなく0にて取得しているが旧システムからデータを使用できるよう修正せずに放置
        /// </summary>
        private static readonly int CommonPatternNo = 0;

        private static readonly string SelectStatement = "SELECT " +
            "styp, ptyp, ptno, pdtp, tbno, pnam, dymd, dcno, kymd, kbmn, " +
            "kusr, sgno, omno, ucnt, umod, utim, lusr, lmod, ltim, cdm1, " +
            "cdm2, cdm3, cdm4, sdm5, sdm6, idm7, idm8, duf1, duf2, duf3, " +
            "duf4, duf5, duf6, duf7, duf8, duf9, duf10, tekiyou.keyno, tekiyou.cdata ";

        private static readonly string KeyName = "TKYLIST";

        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private ITeikeiSiwakeGyouRepository teikeiSiwakeGyouRepository = null;

        public virtual IList<TeikeiSiwakeHeader> FindTeikeiSiwakeHeaderBySystemTypeAndTeikeiSiwakeTypeAndUserCodeOrderByPatternNumber(
            TeikeiSiwakeSystemType teikeiSiwakeSystemType,
            TeikeiSiwakeType teikeiSiwakeType,
            int userCode,
            string programId)
        {
            userCode = teikeiSiwakeType == TeikeiSiwakeType.CommonPattern ? CommonPatternNo : userCode;
            var teikeiSiwakeHeaderList = this.dbc.QueryForList(
                SelectStatement +
                    "FROM dinhed " +
                    "LEFT OUTER JOIN ( SELECT keyno, cdata FROM option1 WHERE prgid = :p AND usno = :p AND KEYNM1 = :p AND KEYNM2 = :p ) tekiyou " +
                    "ON dinhed.sdm5 = tekiyou.keyno " +
                    "WHERE styp =:p AND ptyp =:p ORDER BY ptno ",
                (values, no) =>
                {
                    return this.MapRow(values, no, new TeikeiSiwakeHeader((TeikeiSiwakeSystemType)(short)values[0], (int)(short)values[1], (int)(short)values[2]));
                },
                () => new List<TeikeiSiwakeHeader>(),
                programId,
                userCode,
                KeyName,
                KeyName,
                (short)teikeiSiwakeSystemType,
                userCode);
            return teikeiSiwakeHeaderList;
        }

        public virtual TeikeiSiwakePattern FindTeikeiSiwakePatternBySystemTypeAndTeikeiSiwakeTypeAndUserCodeAndPatternNumber(
            TeikeiSiwakeSystemType teikeiSiwakeSystemType,
            TeikeiSiwakeType teikeiSiwakeType,
            int userCode,
            string programId,
            int patternNumber)
        {
            userCode = teikeiSiwakeType == TeikeiSiwakeType.CommonPattern ? CommonPatternNo : userCode;
            var teikeiSiwakePattern = this.dbc.QueryForObject(
                SelectStatement +
                    "FROM dinhed " +
                    "LEFT OUTER JOIN ( SELECT keyno, cdata FROM option1 WHERE prgid = :p AND usno = :p AND KEYNM1 = :p AND KEYNM2 = :p ) tekiyou " +
                    "ON dinhed.sdm5 = tekiyou.keyno " +
                    "WHERE styp =:p AND ptyp =:p AND ptno = :p",
                (values, no) =>
                {
                    return this.MapRow(values, no, new TeikeiSiwakePattern((TeikeiSiwakeSystemType)(short)values[0], (int)(short)values[1], (int)(short)values[2]));
                },
                programId,
                userCode,
                KeyName,
                KeyName,
                (short)teikeiSiwakeSystemType,
                userCode,
                patternNumber);

            if (teikeiSiwakePattern == null)
            {
                return null;
            }

            teikeiSiwakePattern.TeikeiSiwakeGyouList.AddRangeIfNotNull(this.teikeiSiwakeGyouRepository.FindByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumberOrderByLineNo(
                teikeiSiwakePattern.TeikeiSiwakeSystemType,
                teikeiSiwakePattern.UserCode,
                teikeiSiwakePattern.PatternNumber));

            return teikeiSiwakePattern;
        }

        public virtual void Delete(TeikeiSiwakeHeader teikeiSiwakeHeader)
        {
            this.dbc.Execute(
                "DELETE FROM dinhed WHERE styp = :p AND ptyp = :p AND ptno = :p ",
                new object[] { (short)teikeiSiwakeHeader.TeikeiSiwakeSystemType, teikeiSiwakeHeader.UserCode, teikeiSiwakeHeader.PatternNumber });

            this.teikeiSiwakeGyouRepository.DeleteByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumber(teikeiSiwakeHeader.TeikeiSiwakeSystemType, teikeiSiwakeHeader.UserCode, teikeiSiwakeHeader.PatternNumber);
        }

        public virtual void UpdateUseTimeToZeroByTeikeiSiwakeSystemTypeAndUserCode(TeikeiSiwakeSystemType teikeiSiwakeSystemType, int userCode)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinhed SET ");
            updateQuery.AppendLine("ucnt = 0 ");
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p ", userCode);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        public virtual void UpdateUseTimesAndLastUseDateAndLastUseTime(TeikeiSiwakePattern teikeiSiwakePattern)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinhed SET ");
            updateQuery.AppendLine("ucnt = :p, ", teikeiSiwakePattern.UseTimes);
            updateQuery.AppendLine("umod = :p, ", teikeiSiwakePattern.LastUseDate);
            updateQuery.AppendLine("utim = :p ", teikeiSiwakePattern.LastUseTime);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakePattern.TeikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p AND ", teikeiSiwakePattern.UserCode);
            updateQuery.AppendLine("ptno = :p ", teikeiSiwakePattern.PatternNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        public virtual void UpdatePatternNameAndWeightNumberAndTekiyouNumber(TeikeiSiwakeHeader teikeiSiwakeHeader)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinhed SET ");
            updateQuery.AppendLine("pnam = :p, ", teikeiSiwakeHeader.PatternName);
            updateQuery.AppendLine("omno = :p, ", teikeiSiwakeHeader.WeightNumber);
            updateQuery.AppendLine("lusr = :p, ", teikeiSiwakeHeader.UpdateUserCode);
            updateQuery.AppendLine("lmod = :p, ", teikeiSiwakeHeader.UpdateDate);
            updateQuery.AppendLine("ltim = :p, ", teikeiSiwakeHeader.UpdateTime);
            updateQuery.AppendLine("sdm5 = :p ", teikeiSiwakeHeader.TekiyouNumber ?? 0);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakeHeader.TeikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p AND ", teikeiSiwakeHeader.UserCode);
            updateQuery.AppendLine("ptno = :p ", teikeiSiwakeHeader.PatternNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());
        }

        public virtual void UpdateZeirituAndZeigaku(TeikeiSiwakePattern teikeiSiwakePattern)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinhed SET ");
            updateQuery.AppendLine("lusr = :p, ", teikeiSiwakePattern.UpdateUserCode);
            updateQuery.AppendLine("lmod = :p, ", teikeiSiwakePattern.UpdateDate);
            updateQuery.AppendLine("ltim = :p ", teikeiSiwakePattern.UpdateTime);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakePattern.TeikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p AND ", teikeiSiwakePattern.UserCode);
            updateQuery.AppendLine("ptno = :p ", teikeiSiwakePattern.PatternNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());

            teikeiSiwakePattern.TeikeiSiwakeGyouList.ForEachIfNotNull(teikeiSiwakeGyou =>
                this.teikeiSiwakeGyouRepository.UpdateZeirituAndZeigaku(teikeiSiwakeGyou));
        }

        public virtual void Store(TeikeiSiwakePattern teikeiSiwakePattern)
        {
            if (this.GetExistsBySiwakeSystemTypeAndUserCodeAndPatternNumber(
                teikeiSiwakePattern.TeikeiSiwakeSystemType,
                teikeiSiwakePattern.UserCode,
                teikeiSiwakePattern.PatternNumber))
            {
                this.Update(teikeiSiwakePattern);
            }
            else
            {
                this.Insert(teikeiSiwakePattern);
            }
        }

        private void Update(TeikeiSiwakePattern teikeiSiwakePattern)
        {
            var updateQuery = new SqlStatementBuilder();
            updateQuery.AppendLine("UPDATE dinhed SET ");
            updateQuery.AppendLine("pdtp = :p, ", (short)teikeiSiwakePattern.DenpyouKeisiki);
            updateQuery.AppendLine("tbno = :p, ", teikeiSiwakePattern.DenpyouInputLayoutPatternNumber);
            updateQuery.AppendLine("pnam = :p, ", teikeiSiwakePattern.PatternName);
            updateQuery.AppendLine("dymd = :p, ", teikeiSiwakePattern.DenpyouHizuke);
            updateQuery.AppendLine("dcno = :p, ", teikeiSiwakePattern.DenpyouNo);
            updateQuery.AppendLine("kymd = :p, ", teikeiSiwakePattern.Kihyoubi);
            updateQuery.AppendLine("kbmn = :p, ", teikeiSiwakePattern.KihyouBumonCode);
            updateQuery.AppendLine("kusr = :p, ", teikeiSiwakePattern.KihyousyaCode);
            updateQuery.AppendLine("sgno = :p, ", teikeiSiwakePattern.SyouninGroupNumber);
            updateQuery.AppendLine("omno = :p, ", teikeiSiwakePattern.WeightNumber);
            updateQuery.AppendLine("ucnt = :p, ", teikeiSiwakePattern.UseTimes);
            updateQuery.AppendLine("umod = :p, ", teikeiSiwakePattern.LastUseDate);
            updateQuery.AppendLine("utim = :p, ", teikeiSiwakePattern.LastUseTime);
            updateQuery.AppendLine("lusr = :p, ", teikeiSiwakePattern.UpdateUserCode);
            updateQuery.AppendLine("lmod = :p, ", teikeiSiwakePattern.UpdateDate);
            updateQuery.AppendLine("ltim = :p, ", teikeiSiwakePattern.UpdateTime);
            updateQuery.AppendLine("cdm1 = :p, ", teikeiSiwakePattern.DenpyouTabaCode);
            updateQuery.AppendLine("sdm5 = :p, ", teikeiSiwakePattern.TekiyouNumber ?? 0);
            updateQuery.AppendLine("duf1 = :p, ", teikeiSiwakePattern.HeaderField1Code);
            updateQuery.AppendLine("duf2 = :p, ", teikeiSiwakePattern.HeaderField2Code);
            updateQuery.AppendLine("duf3 = :p, ", teikeiSiwakePattern.HeaderField3Code);
            updateQuery.AppendLine("duf4 = :p, ", teikeiSiwakePattern.HeaderField4Code);
            updateQuery.AppendLine("duf5 = :p, ", teikeiSiwakePattern.HeaderField5Code);
            updateQuery.AppendLine("duf6 = :p, ", teikeiSiwakePattern.HeaderField6Code);
            updateQuery.AppendLine("duf7 = :p, ", teikeiSiwakePattern.HeaderField7Code);
            updateQuery.AppendLine("duf8 = :p, ", teikeiSiwakePattern.HeaderField8Code);
            updateQuery.AppendLine("duf9 = :p, ", teikeiSiwakePattern.HeaderField9Code);
            updateQuery.AppendLine("duf10 = :p ", teikeiSiwakePattern.HeaderField10Code);
            updateQuery.AppendLine("WHERE ");
            updateQuery.AppendLine("styp = :p AND ", (short)teikeiSiwakePattern.TeikeiSiwakeSystemType);
            updateQuery.AppendLine("ptyp = :p AND ", teikeiSiwakePattern.UserCode);
            updateQuery.AppendLine("ptno = :p ", teikeiSiwakePattern.PatternNumber);
            this.dbc.Execute(updateQuery.GetSqlStatement(), updateQuery.GetSqlParameters());

            this.StoreTeikeiSiwakeGyou(teikeiSiwakePattern);
        }

        private bool GetExistsBySiwakeSystemTypeAndUserCodeAndPatternNumber(
            TeikeiSiwakeSystemType teikeiSiwakeSystemType,
            int userCode,
            int patternNumber)
        {
            return this.dbc.QueryForObject(
                "SELECT COUNT(styp) " +
                "FROM dinhed " +
                "WHERE styp = :p AND ptyp =:p AND ptno = :p ",
                (values, no) =>
                {
                    return Convert.ToInt32(values[0]) > 0 ? true : false;
                },
                (short)teikeiSiwakeSystemType,
                userCode,
                patternNumber);
        }

        private void Insert(TeikeiSiwakePattern teikeiSiwakePattern)
        {
            var insertSqlStatementBuilder = new InsertSqlStatementBuilder("dinhed");
            insertSqlStatementBuilder.AppendColumnNameAndValue("styp", (short)teikeiSiwakePattern.TeikeiSiwakeSystemType);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ptyp", (short)teikeiSiwakePattern.UserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ptno", (short)teikeiSiwakePattern.PatternNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pdtp", (short)teikeiSiwakePattern.DenpyouKeisiki);
            insertSqlStatementBuilder.AppendColumnNameAndValue("tbno", teikeiSiwakePattern.DenpyouInputLayoutPatternNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("pnam", teikeiSiwakePattern.PatternName);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dymd", teikeiSiwakePattern.DenpyouHizuke);
            insertSqlStatementBuilder.AppendColumnNameAndValue("dcno", teikeiSiwakePattern.DenpyouNo);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kymd", teikeiSiwakePattern.Kihyoubi);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kbmn", teikeiSiwakePattern.KihyouBumonCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("kusr", teikeiSiwakePattern.KihyousyaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sgno", teikeiSiwakePattern.SyouninGroupNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("omno", teikeiSiwakePattern.WeightNumber);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ucnt", teikeiSiwakePattern.UseTimes);
            insertSqlStatementBuilder.AppendColumnNameAndValue("umod", teikeiSiwakePattern.LastUseDate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("utim", teikeiSiwakePattern.LastUseTime);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lusr", teikeiSiwakePattern.UpdateUserCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("lmod", teikeiSiwakePattern.UpdateDate);
            insertSqlStatementBuilder.AppendColumnNameAndValue("ltim", teikeiSiwakePattern.UpdateTime);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm1", teikeiSiwakePattern.DenpyouTabaCode);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm2", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm3", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("cdm4", null);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm5", teikeiSiwakePattern.TekiyouNumber ?? 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("sdm6", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm7", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("idm8", 0);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf1", teikeiSiwakePattern.HeaderField1Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf2", teikeiSiwakePattern.HeaderField2Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf3", teikeiSiwakePattern.HeaderField3Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf4", teikeiSiwakePattern.HeaderField4Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf5", teikeiSiwakePattern.HeaderField5Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf6", teikeiSiwakePattern.HeaderField6Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf7", teikeiSiwakePattern.HeaderField7Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf8", teikeiSiwakePattern.HeaderField8Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf9", teikeiSiwakePattern.HeaderField9Code);
            insertSqlStatementBuilder.AppendColumnNameAndValue("duf10", teikeiSiwakePattern.HeaderField10Code);
            this.dbc.Execute(insertSqlStatementBuilder.GetSqlStatement(), insertSqlStatementBuilder.GetSqlParameters());
            this.StoreTeikeiSiwakeGyou(teikeiSiwakePattern);
        }

        private void StoreTeikeiSiwakeGyou(TeikeiSiwakePattern teiekiSiwakePattern)
        {
            this.teikeiSiwakeGyouRepository.DeleteByTeikeiSiwakeSystemTypeAndUserCodeAndPatternNumber(
                teiekiSiwakePattern.TeikeiSiwakeSystemType,
                teiekiSiwakePattern.UserCode,
                teiekiSiwakePattern.PatternNumber);

            teiekiSiwakePattern.TeikeiSiwakeGyouList.ForEachIfNotNull(teikeiSiwakeGyou =>
            this.teikeiSiwakeGyouRepository.Insert(teikeiSiwakeGyou));
        }

        private T MapRow<T>(object[] values, int no, T teikeiSiwakeHeader)
            where T : TeikeiSiwakeHeader
        {
            teikeiSiwakeHeader.DenpyouKeisiki = (DenpyouKeisiki)(short)values[3]; // "パターン 伝票種別"
            teikeiSiwakeHeader.DenpyouInputLayoutPatternNumber = (int)(short)values[4]; // 伝票入力レイアウトパターン番号
            teikeiSiwakeHeader.PatternName = DbNullConverter.ToString(values[5], null); // 名称
            teikeiSiwakeHeader.DenpyouHizuke = DbNullConverter.ToNullableInt(values[6]); // 伝票日付
            teikeiSiwakeHeader.DenpyouNo = DbNullConverter.ToNullableInt(values[7]); // 伝票番号
            teikeiSiwakeHeader.Kihyoubi = DbNullConverter.ToNullableInt(values[8]); // 起票日付
            teikeiSiwakeHeader.KihyouBumonCode = DbNullConverter.ToString(values[9], null); // 起票部門
            teikeiSiwakeHeader.KihyousyaCode = DbNullConverter.ToString(values[10], null); // 起票者
            teikeiSiwakeHeader.SyouninGroupNumber = (int)values[11]; // 承認グループ
            teikeiSiwakeHeader.WeightNumber = (int)values[12]; // 重付番号
            teikeiSiwakeHeader.UseTimes = (int)values[13]; // 使用回数
            teikeiSiwakeHeader.LastUseDate = (int)values[14]; // 最終使用日付
            teikeiSiwakeHeader.LastUseTime = (int)values[15]; // 最終使用時間
            teikeiSiwakeHeader.UpdateUserCode = (int)values[16]; // "作成変更 ユーザーno"
            teikeiSiwakeHeader.UpdateDate = (int)values[17]; // 作成変更年月日
            teikeiSiwakeHeader.UpdateTime = (int)values[18]; // 作成変更時間
            teikeiSiwakeHeader.DenpyouTabaCode = DbNullConverter.ToString(values[19], null); // 伝票束コード
            teikeiSiwakeHeader.TekiyouNumber = (short)values[23] == 0 ? (int?)null : (int?)(short)values[23]; // 摘要No
            teikeiSiwakeHeader.HeaderField1Code = DbNullConverter.ToString(values[27], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ1
            teikeiSiwakeHeader.HeaderField2Code = DbNullConverter.ToString(values[28], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ2
            teikeiSiwakeHeader.HeaderField3Code = DbNullConverter.ToString(values[29], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ3
            teikeiSiwakeHeader.HeaderField4Code = DbNullConverter.ToString(values[30], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ4
            teikeiSiwakeHeader.HeaderField5Code = DbNullConverter.ToString(values[31], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ5
            teikeiSiwakeHeader.HeaderField6Code = DbNullConverter.ToString(values[32], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ6
            teikeiSiwakeHeader.HeaderField7Code = DbNullConverter.ToString(values[33], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ7
            teikeiSiwakeHeader.HeaderField8Code = DbNullConverter.ToString(values[34], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ8
            teikeiSiwakeHeader.HeaderField9Code = DbNullConverter.ToString(values[35], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ9
            teikeiSiwakeHeader.HeaderField10Code = DbNullConverter.ToString(values[36], null); // 伝票ﾕﾆﾊﾞｰｻﾙﾌｨｰﾙﾄﾞ10
            teikeiSiwakeHeader.TekiyouString = DbNullConverter.ToString(values[38], null); // 摘要文字列
            return teikeiSiwakeHeader;
        }
    }
}
