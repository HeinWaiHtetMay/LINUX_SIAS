﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouInputModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    internal class DenpyouEditAuthorityRepository : IDenpyouEditAuthorityRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual bool GetExistsByUserCode(int userCode) =>
            this.dbc.QueryForObject(
                "SELECT COUNT(huno) FROM kdhky WHERE huno = :p ",
                (values, no) =>
                {
                    return Convert.ToInt32(values[0]) > 0 ? true : false;
                },
                userCode);
    }
}
