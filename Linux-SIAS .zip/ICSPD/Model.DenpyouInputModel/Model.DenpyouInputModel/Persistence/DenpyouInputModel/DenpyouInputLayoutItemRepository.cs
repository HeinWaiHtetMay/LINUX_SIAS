﻿namespace Icsp.Open21.Persistence.DenpyouInputModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DenpyouInputLayoutItemRepository : IDenpyouInputLayoutItemRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<DenpyouInputLayoutItem> FindByKesnAndDenpyouTypeAndPtnoOrderByPseq(int kesn, DenpyouKeisiki denpyouKeisiki, int ptno) =>
            ptno == 0
                ? this.GetDefaultLayout(kesn, denpyouKeisiki)
                : this.dbc.QueryForList(
                    "SELECT kesn, dtyp, ptno, pseq, line, colm, item " +
                    "FROM dinlyitm " +
                    "WHERE kesn = :p AND dtyp = :p AND ptno = :p " +
                    "ORDER BY pseq ",
                    (values, no) =>
                    {
                        var row = new DenpyouInputLayoutItem(kesn, denpyouKeisiki, ptno, (int)(short)values[3]);
                        row.Line = (int)(short)values[4]; // 縦位置
                        row.Column = (int)(short)values[5]; // 横位置
                        row.DenpyouInputItemType = (DenpyouInputItemType)(short)values[6]; // アイテム
                        return row;
                    },
                    () => new List<DenpyouInputLayoutItem>(),
                    kesn,
                    (short)denpyouKeisiki,
                    ptno);

        /// <summary>
        /// デフォルト値取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <param name="denpyouKeisiki"></param>
        /// <returns></returns>
        private IList<DenpyouInputLayoutItem> GetDefaultLayout(int kesn, DenpyouKeisiki denpyouKeisiki) =>
            denpyouKeisiki != DenpyouKeisiki.Hukugou ? this.GetTanituDefaultLayout(kesn) : this.GetHukugouDefaultLayout(kesn);

        /// <summary>
        /// 単一形式デフォルト値取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <returns></returns>
        private IList<DenpyouInputLayoutItem> GetTanituDefaultLayout(int kesn)
        {
            return new List<DenpyouInputLayoutItem>()
            {
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 1, 1, 1, DenpyouInputItemType.KarikataKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 2, 2, 1, DenpyouInputItemType.KarikataKazeiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 3, 3, 1, DenpyouInputItemType.KarikataBunriKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 4, 4, 1, DenpyouInputItemType.KarikataBumon),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 5, 5, 1, DenpyouInputItemType.KarikataTorihikisaki),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 6, 6, 1, DenpyouInputItemType.KarikataEdaban),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 7, 7, 1, DenpyouInputItemType.KarikataZiyuuTekiyou),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 8, 1, 2, DenpyouInputItemType.KarikataUniversalField1),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 9, 2, 2, DenpyouInputItemType.KarikataUniversalField2),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 10, 3, 2, DenpyouInputItemType.KarikataUniversalField3),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 11, 4, 2, DenpyouInputItemType.KarikataProject),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 12, 5, 2, DenpyouInputItemType.KarikataSegment),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 13, 6, 2, DenpyouInputItemType.KarikataKouzi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 14, 7, 2, DenpyouInputItemType.KarikataKousyu),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 15, 1, 3, DenpyouInputItemType.KasikataKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 16, 2, 3, DenpyouInputItemType.KasikataKazeiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 17, 3, 3, DenpyouInputItemType.KasikataBunriKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 18, 4, 3, DenpyouInputItemType.KasikataBumon),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 19, 5, 3, DenpyouInputItemType.KasikataTorihikisaki),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 20, 6, 3, DenpyouInputItemType.KasikataEdaban),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 21, 7, 3, DenpyouInputItemType.KasikataZiyuuTekiyou),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 22, 1, 4, DenpyouInputItemType.KasikataUniversalField1),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 23, 2, 4, DenpyouInputItemType.KasikataUniversalField2),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 24, 3, 4, DenpyouInputItemType.KasikataUniversalField3),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 25, 4, 4, DenpyouInputItemType.KasikataProject),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 26, 5, 4, DenpyouInputItemType.KasikataSegment),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 27, 6, 4, DenpyouInputItemType.KasikataKouzi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 28, 7, 4, DenpyouInputItemType.KasikataKousyu),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 29, 1, 5, DenpyouInputItemType.KasikataKesikomiCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 30, 2, 5, DenpyouInputItemType.KasikataSiharaibi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 31, 3, 5, DenpyouInputItemType.KasikataSiharaiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 32, 4, 5, DenpyouInputItemType.KasikataSiharaiKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 33, 5, 5, DenpyouInputItemType.KasikataKaisyuubi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 34, 6, 5, DenpyouInputItemType.KasikataNyuukinKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 35, 7, 5, DenpyouInputItemType.KasikataKaisyuuKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 36, 8, 5, DenpyouInputItemType.KasikataZeitaisyouKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 37, 9, 5, DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 38, 1, 6, DenpyouInputItemType.KasikataKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 39, 2, 6, DenpyouInputItemType.KasikataTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 40, 3, 6, DenpyouInputItemType.KasikataZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 41, 4, 6, DenpyouInputItemType.KasikataGaikaKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 42, 5, 6, DenpyouInputItemType.KasikataGaikaTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 43, 6, 6, DenpyouInputItemType.KasikataGaikaZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 44, 7, 6, DenpyouInputItemType.KasikataHeisyuCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Tannitu, 0, 45, 8, 6, DenpyouInputItemType.KasikataRate),
            };
        }

        /// <summary>
        /// 複合形式デフォルト値取得
        /// </summary>
        /// <param name="kesn"></param>
        /// <returns></returns>
        private IList<DenpyouInputLayoutItem> GetHukugouDefaultLayout(int kesn)
        {
            return new List<DenpyouInputLayoutItem>()
            {
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 1, 1, 2, DenpyouInputItemType.KarikataKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 2, 2, 2, DenpyouInputItemType.KarikataKazeiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 3, 3, 2, DenpyouInputItemType.KarikataBunriKubun),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 4, 1, 1, DenpyouInputItemType.KarikataKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 5, 2, 1, DenpyouInputItemType.KarikataTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 6, 3, 1, DenpyouInputItemType.KarikataZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 7, 4, 1, DenpyouInputItemType.KarikataGaikaKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 8, 5, 1, DenpyouInputItemType.KarikataGaikaTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 9, 6, 1, DenpyouInputItemType.KarikataGaikaZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 10, 7, 1, DenpyouInputItemType.KarikataHeisyuCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 11, 8, 1, DenpyouInputItemType.KarikataRate),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 12, 9, 1, DenpyouInputItemType.KarikataZiyuuTekiyou),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 13, 10, 1, DenpyouInputItemType.KarikataHusen),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 14, 4, 2, DenpyouInputItemType.KarikataBumon),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 15, 5, 2, DenpyouInputItemType.KarikataTorihikisaki),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 16, 6, 2, DenpyouInputItemType.KarikataEdaban),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 17, 7, 2, DenpyouInputItemType.KarikataKouzi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 18, 8, 2, DenpyouInputItemType.KarikataKousyu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 19, 9, 2, DenpyouInputItemType.KarikataUniversalField1),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 20, 10, 2, DenpyouInputItemType.KarikataUniversalField2),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 21, 11, 2, DenpyouInputItemType.KarikataUniversalField3),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 22, 1, 3, DenpyouInputItemType.KarikataProject),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 23, 2, 3, DenpyouInputItemType.KarikataSegment),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 24, 3, 3, DenpyouInputItemType.KarikataKesikomiCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 25, 4, 3, DenpyouInputItemType.KarikataSiharaibi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 26, 5, 3, DenpyouInputItemType.KarikataSiharaiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 27, 6, 3, DenpyouInputItemType.KarikataSiharaiKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 28, 7, 3, DenpyouInputItemType.KarikataKaisyuubi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 29, 8, 3, DenpyouInputItemType.KarikataNyuukinKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 30, 9, 3, DenpyouInputItemType.KarikataKaisyuuKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 31, 10, 3, DenpyouInputItemType.KarikataZeitaisyouKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 32, 11, 3, DenpyouInputItemType.KarikataZeitaisyouKamokuKazeiKubun),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 33, 1, 4, DenpyouInputItemType.KasikataKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 34, 2, 4, DenpyouInputItemType.KasikataKazeiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 35, 3, 4, DenpyouInputItemType.KasikataBunriKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 36, 4, 4, DenpyouInputItemType.KasikataBumon),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 37, 5, 4, DenpyouInputItemType.KasikataTorihikisaki),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 38, 6, 4, DenpyouInputItemType.KasikataEdaban),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 39, 7, 4, DenpyouInputItemType.KasikataKouzi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 40, 8, 4, DenpyouInputItemType.KasikataKousyu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 41, 9, 4, DenpyouInputItemType.KasikataUniversalField1),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 42, 10, 4, DenpyouInputItemType.KasikataUniversalField2),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 43, 11, 4, DenpyouInputItemType.KasikataUniversalField3),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 44, 1, 5, DenpyouInputItemType.KasikataProject),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 45, 2, 5, DenpyouInputItemType.KasikataSegment),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 46, 3, 5, DenpyouInputItemType.KasikataKesikomiCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 47, 4, 5, DenpyouInputItemType.KasikataSiharaibi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 48, 5, 5, DenpyouInputItemType.KasikataSiharaiKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 49, 6, 5, DenpyouInputItemType.KasikataSiharaiKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 50, 7, 5, DenpyouInputItemType.KasikataKaisyuubi),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 51, 8, 5, DenpyouInputItemType.KasikataNyuukinKubun),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 52, 9, 5, DenpyouInputItemType.KasikataKaisyuuKizitu),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 53, 10, 5, DenpyouInputItemType.KasikataZeitaisyouKamoku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 54, 11, 5, DenpyouInputItemType.KasikataZeitaisyouKamokuKazeiKubun),

                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 55, 1, 6, DenpyouInputItemType.KasikataKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 56, 2, 6, DenpyouInputItemType.KasikataTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 57, 3, 6, DenpyouInputItemType.KasikataZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 58, 4, 6, DenpyouInputItemType.KasikataGaikaKingaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 59, 5, 6, DenpyouInputItemType.KasikataGaikaTaika),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 60, 6, 6, DenpyouInputItemType.KasikataGaikaZeigaku),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 61, 7, 6, DenpyouInputItemType.KasikataHeisyuCode),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 62, 8, 6, DenpyouInputItemType.KasikataRate),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 63, 9, 6, DenpyouInputItemType.KasikataZiyuuTekiyou),
                new DenpyouInputLayoutItem(kesn, DenpyouKeisiki.Hukugou, 0, 64, 10, 6, DenpyouInputItemType.KasikataHusen),
            };
        }
    }
}
