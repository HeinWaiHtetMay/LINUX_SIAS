﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    public abstract class AbstractDataScanSiwakeTyouhyouRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        #region public methods

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、部門リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>部門リスト</returns>
        public virtual IList<Bumon> FindBumonListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            if (queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting <= BumonTaniOutputSetting.BumonKobetuSitei)
            {
                //// 部門
                selectQuery.AppendLine("  b.bcod ");
                selectQuery.AppendLine("  , b.bnam ");
                selectQuery.AppendLine("FROM ");
                selectQuery.AppendLine("  bname b ");
            }
            else
            {
                //// 集計部門
                selectQuery.AppendLine("  sb.sbcd ");
                selectQuery.AppendLine("  , b2.bnam ");
                selectQuery.AppendLine("FROM ");
                selectQuery.AppendLine("  bname b ");
                selectQuery.AppendLine("  INNER JOIN sbtbl sb ");
                selectQuery.AppendLine("    ON sb.kesn = b.kesn ");
                selectQuery.AppendLine("    AND sb.bcod = b.bcod ");
                selectQuery.AppendLine("  INNER JOIN bname b2 ");
                selectQuery.AppendLine("    ON b2.kesn = sb.kesn ");
                selectQuery.AppendLine("    AND b2.bcod = sb.sbcd ");
            }

            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  b.kesn = :p ", queryParameter.Kesn);
            selectQuery.AppendLine("  AND b.bflg = :p ", 0);
            selectQuery.AppendLine(this.CreateWhereStatement(queryParameter));
            if (queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting >= BumonTaniOutputSetting.SyuukeiBumonRangeSitei)
            {
                selectQuery.AppendLine("GROUP BY sb.sbcd, b2.bnam ");
            }

            selectQuery.AppendLine("ORDER BY ");
            selectQuery.AppendLine(this.CreateOrderByStatement(queryParameter));

            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    return new Bumon(queryParameter.Kesn, DbNullConverter.ToString(values[0])) { Bnam = DbNullConverter.ToString(values[1]) };
                },
                selectQuery.GetSqlParameters());
        }

        #endregion

        #region private methods

        /// <summary>
        /// WHERE句の条件式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>WHERE句の条件式</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private SqlStatementBuilder CreateWhereStatement(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var whereStatement = new SqlStatementBuilder();

            if (queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.BumonRangeSitei
                || queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.SyuukeiBumonRangeSitei)
            {
                //// 範囲指定
                whereStatement.AppendWhereStatementByCodeRange(
                    queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.BumonRangeSitei ? "b.bcod" : "sb.sbcd",
                    queryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.StartValue,
                    queryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.EndValue,
                    true);
                whereStatement.AppendLine();
            }
            else
            {
                //// 個別指定
                whereStatement.Append("  AND");
                whereStatement.AppendInStatement(
                    queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.BumonKobetuSitei ? "b.bcod" : "sb.sbcd",
                    queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList);
                whereStatement.AppendLine();
            }

            whereStatement.AppendLine("  AND EXISTS ( ");
            whereStatement.AppendLine("    SELECT ");
            whereStatement.AppendLine("      * ");
            whereStatement.AppendLine("    FROM ");
            whereStatement.AppendLine("      zdata z ");
            whereStatement.AppendLine("      INNER JOIN zdata_h zh ");
            whereStatement.AppendLine("        ON z.kesn = zh.kesn ");
            whereStatement.AppendLine("        AND z.dkei = zh.dkei ");
            whereStatement.AppendLine("        AND z.dseq = zh.dseq ");
            whereStatement.AppendLine("    WHERE ");
            whereStatement.AppendLine("      zh.kesn = :p ", queryParameter.Kesn);
            whereStatement.AppendLine("      AND zh.delf = 0 ");
            whereStatement.AppendLine("      AND z.delf = 0 ");
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dkei",
                queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.EndValue,
                true);
            whereStatement.AppendLine();
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dymd",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouDateRangeValue.EndValue?.Ymd,
                true);
            whereStatement.AppendLine();
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dcno",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.EndValue,
                true);
            whereStatement.AppendLine();
            whereStatement.AppendIfTrue(
                queryParameter.SecurityContext.GetUserKaisyabetuSecurity().OthersDenpyoPermission == OthersDenpyouPermission.Disallow,
                "      AND zh.fusr = :p ",
                queryParameter.SecurityContext.User.UserCode);
            whereStatement.AppendLine();
            whereStatement.AppendLine("  AND ((z.rbmn = b.bcod) OR (z.sbmn = b.bcod))) ");

            return whereStatement;
        }

        /// <summary>
        /// ORDERBY句の条件式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>ORDERBY句の条件式</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private SqlStatementBuilder CreateOrderByStatement(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var orderByStatement = new SqlStatementBuilder();

            switch (queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting)
            {
                //// 部門指定
                case BumonTaniOutputSetting.BumonRangeSitei:
                    orderByStatement.AppendLine("  b.bcod ");
                    break;

                //// 部門個別指定
                case BumonTaniOutputSetting.BumonKobetuSitei:
                    orderByStatement.AppendLine("  CASE b.bcod ");
                    for (int i = 0; i < queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList.Count; i++)
                    {
                        orderByStatement.AppendLine("    WHEN :p THEN :p ", queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList[i], i + 1);
                    }
                    orderByStatement.AppendLine("    ELSE :p ", queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList.Count + 1);
                    orderByStatement.AppendLine("    END ");
                    break;

                //// 集計部門範囲指定
                case BumonTaniOutputSetting.SyuukeiBumonRangeSitei:
                    orderByStatement.AppendLine("  sb.sbcd ");
                    break;

                //// 集計部門個別指定
                case BumonTaniOutputSetting.SyuukeiBumonKobetuSitei:
                    orderByStatement.AppendLine("  CASE sb.sbcd ");
                    for (int i = 0; i < queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList.Count; i++)
                    {
                        orderByStatement.AppendLine("    WHEN :p THEN :p ", queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList[i], i + 1);
                    }
                    orderByStatement.AppendLine("    ELSE :p ", queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList.Count + 1);
                    orderByStatement.AppendLine("    END ");
                    break;
            }

            return orderByStatement;
        }

        #endregion
    }
}
