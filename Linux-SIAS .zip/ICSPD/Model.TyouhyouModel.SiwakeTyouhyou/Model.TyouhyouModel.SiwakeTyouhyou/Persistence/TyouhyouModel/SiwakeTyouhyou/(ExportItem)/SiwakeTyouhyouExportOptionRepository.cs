﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.FileExportModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouExportOptionRepository : ISiwakeTyouhyouExportOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        /// <summary>
        /// 指定条件のエクスポートオプション情報を取得します。
        /// </summary>
        /// <param name="kaisya">会社情報</param>
        /// <param name="user">ユーザー情報</param>
        /// <param name="prgid">プログラムID</param>
        /// <returns>エクスポートオプション情報</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        public virtual ExportOption FindByKaisyaAndUserAndPrgid(Kaisya kaisya, User user, string prgid)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "EXPTLIB", user.UserCode, prgid).Where(option => option.Keyno == 0).ToList();
            if (!optionList.Any())
            {
                return null;
            }

            var exportOption = new ExportOption(kaisya, user, prgid, optionList.GetCdata(prgid, "FNAM", 0, string.Empty));
            foreach (var option in optionList)
            {
                switch (option.Keynm2)
                {
                    //// 会社タイトル
                    case "TITL":
                        exportOption.IsOutputKaisyaTitle = option.Idata == 1;
                        break;

                    //// 会社コード
                    case "CCOD":
                        exportOption.IsOutputKaisyaCode = option.Idata == 1;
                        break;

                    //// コメント
                    case "CMNT":
                        exportOption.IsOutputComment = option.Idata == 1;
                        break;

                    //// 整理月情報
                    case "SEIR":
                        exportOption.IsOutputSeiritukiInfo = option.Idata == 1;
                        break;

                    //// オプション選択
                    case "OPSEL":
                        exportOption.SetAdditionalOption(option.Idata);
                        break;

                    //// フォルダ選択
                    case "FMOD":
                        exportOption.IsUserFolder = option.Idata == 0;
                        break;

                    //// フォルダ名
                    case "FLDR":
                        exportOption.FolderName = option.Cdata;
                        break;

                    //// ファイル名
                    case "FNAM":
                        exportOption.FileName = option.Cdata;
                        break;

                    //// 改ページ
                    case "PAGE":
                        exportOption.UsePageBreak = option.Idata == 1;
                        break;
                }
            }

            return exportOption;
        }

        /// <summary>
        /// エクスポートオプション情報を保存します。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="prgid">プログラムID</param>
        /// <param name="usno">ユーザーコード</param>
        public virtual void Store(ExportOption exportOption, string prgid, int usno)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "EXPTLIB", usno, prgid);

            new List<Option1Dto>()
            {
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "TITL", 0, exportOption.IsOutputKaisyaTitle),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "CCOD", 0, exportOption.IsOutputKaisyaCode),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "CMNT", 0, exportOption.IsOutputComment),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "SEIR", 0, exportOption.IsOutputSeiritukiInfo),
                new Option1Dto().SetKeyValuesAndIData("EXPTLIB", usno, prgid, "OPSEL", 0, (int?)exportOption.GetAdditionalOption()),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "FMOD", 0, !exportOption.IsUserFolder),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "FLDR", 0, exportOption.FolderName),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "FNAM", 0, exportOption.FileName),
                new Option1Dto().SetValues("EXPTLIB", usno, prgid, "PAGE", 0, exportOption.UsePageBreak)
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }
    }
}
