﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.IO;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.FileExportModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Properties;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouExportRepository : ISiwakeTyouhyouExportRepository
    {
        [AutoInjection]
        private ICsvExportService csvReadWriter = null;

        [AutoInjection]
        private ITanituSiwakeTyouhyouRowRepository siwakeTyouhyouRowRepository = null;
        [AutoInjection]
        private ITokuteiSyuunyuuKamokuRepository tokuteiSyuunyuuKamokuRepository = null;

        #region public methods

        /// <summary>
        /// CSV形式でのエクスポート処理をおこないます。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>エクスポート処理結果</returns>
        public virtual ExportResultClass ExportCsv(ExportOption exportOption, SiwakeTyouhyouExportItemOption exportItemOption, ISiwakeTyouhyouQueryParameter queryParameter, SiwakeTyouhyouOption siwakeTyouhyouOption, SyouhizeiMaster syouhizeiMaster)
        {
            var itemOption = exportItemOption.Clone(syouhizeiMaster);

            //// ヘッダー項目
            var headerRows = new List<List<string>>();

            headerRows.AddRange(this.CreateHeaderItemList(exportOption, itemOption, queryParameter.KaisyaSyoriKikan));

            var csvConfig =
               new CsvConfig()
               {
                   RowQuoteFieldIndexSet = this.CreateRowQuoteFieldIndexCollection(itemOption.ExportItemSet.ToList(), queryParameter.KaisyaSyoriKikan.Syoriki)
               };

            //// 項目タイトル
            if (itemOption.IsExportItemTitle)
            {
                headerRows.Add(this.CreateItemTitleList(exportOption, itemOption, csvConfig, queryParameter.KaisyaSyoriKikan.Syoriki, queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled, syouhizeiMaster).ToList());
            }

            //// 項目
            var rows = this.siwakeTyouhyouRowRepository.FindSiwakeTyouhyouRowsByQueryParameter(queryParameter);
            var itemRows = new List<List<string>>();
            itemRows.AddRange(this.CreateItemList(exportOption, itemOption, rows, siwakeTyouhyouOption, queryParameter.KaisyaSyoriKikan.Syoriki, queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled, syouhizeiMaster));

            var exportResultClass = new ExportResultClass();

            try
            {
                exportResultClass.ExportContents = this.csvReadWriter.GetCsvContents(csvConfig, itemRows, headerRows, null);
                exportResultClass.ProcessingResult = ExportProcessingResult.Success;
            }
            catch
            {
                exportResultClass.ProcessingResult = ExportProcessingResult.FileMakeFailed;
            }

            return exportResultClass;
        }

        #endregion

        #region private methods

#pragma warning disable SA1131 // Use readable conditions
        /// <summary>
        /// 行で囲み文字を使用するフィールドのインデックスのSetを作成します。
        /// </summary>
        /// <param name="exportItemList">エクスポート項目リスト</param>
        /// <param name="syoriki">処理期情報</param>
        /// <returns>行で囲み文字を使用するフィールドのインデックスのSet</returns>
        private ISet<int> CreateRowQuoteFieldIndexCollection(IList<SiwakeTyouhyouExportItem> exportItemList, Syoriki syoriki)
        {
            var rowQuoteFieldIndexCollection = new HashSet<int>();
            for (int index = 0; index < exportItemList.Count; index++)
            {
                var exportItem = exportItemList[index];
                if (SiwakeTyouhyouExportItem.Dkei <= exportItem && exportItem <= SiwakeTyouhyouExportItem.HeaderField10Name)
                {
                    //// 伝票項目
                    this.AddDenpyouItemRowQuoteFieldIndexCollection(exportItemList, index, rowQuoteFieldIndexCollection, syoriki);
                }
                else if (SiwakeTyouhyouExportItem.KarikataBcod <= exportItem && exportItem <= SiwakeTyouhyouExportItem.KasikataHeisyu)
                {
                    //// 仕訳項目（貸借別）
                    this.AddTaisyakubetuSiwakeItemRowQuoteFieldIndexCollection(exportItemList, index, rowQuoteFieldIndexCollection, syoriki);
                }
                else
                {
                    //// 仕訳項目（貸借共通）
                    this.AddTaisyakuCommonSiwakeItemRowQuoteFieldIndexCollection(exportItemList, index, rowQuoteFieldIndexCollection);
                }
            }

            return rowQuoteFieldIndexCollection;
        }
#pragma warning restore SA1131 // Use readable conditions

        /// <summary>
        /// 伝票項目の行で囲み文字を使用するフィールドのインデックスを追加します。
        /// </summary>
        /// <param name="exportItemList">エクスポート項目リスト</param>
        /// <param name="index">列インデックス</param>
        /// <param name="rowQuoteFieldIndexSet">行で囲み文字を使用するフィールドのインデックスのSet</param>
        /// <param name="syoriki">処理期情報</param>
        private void AddDenpyouItemRowQuoteFieldIndexCollection(IList<SiwakeTyouhyouExportItem> exportItemList, int index, ISet<int> rowQuoteFieldIndexSet, Syoriki syoriki)
        {
            switch (exportItemList[index])
            {
                //// 伝票作成者名
                case SiwakeTyouhyouExportItem.DenpyouCreateUserName:
                //// 伝票更新者名
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserName:
                //// 起票部門コード
                case SiwakeTyouhyouExportItem.KihyouBumonCode:
                //// 起票部門名称
                case SiwakeTyouhyouExportItem.KihyouBumonName:
                //// 起票者コード
                case SiwakeTyouhyouExportItem.KihyouTantousyaCode:
                //// 起票者名
                case SiwakeTyouhyouExportItem.KihyouTantousyaName:
                //// ヘッダーフィールドコード
                case SiwakeTyouhyouExportItem.Hfcd01:
                case SiwakeTyouhyouExportItem.Hfcd02:
                case SiwakeTyouhyouExportItem.Hfcd03:
                case SiwakeTyouhyouExportItem.Hfcd04:
                case SiwakeTyouhyouExportItem.Hfcd05:
                case SiwakeTyouhyouExportItem.Hfcd06:
                case SiwakeTyouhyouExportItem.Hfcd07:
                case SiwakeTyouhyouExportItem.Hfcd08:
                case SiwakeTyouhyouExportItem.Hfcd09:
                case SiwakeTyouhyouExportItem.Hfcd10:
                //// ヘッダーフィールド名称
                case SiwakeTyouhyouExportItem.HeaderField01Name:
                case SiwakeTyouhyouExportItem.HeaderField02Name:
                case SiwakeTyouhyouExportItem.HeaderField03Name:
                case SiwakeTyouhyouExportItem.HeaderField04Name:
                case SiwakeTyouhyouExportItem.HeaderField05Name:
                case SiwakeTyouhyouExportItem.HeaderField06Name:
                case SiwakeTyouhyouExportItem.HeaderField07Name:
                case SiwakeTyouhyouExportItem.HeaderField08Name:
                case SiwakeTyouhyouExportItem.HeaderField09Name:
                case SiwakeTyouhyouExportItem.HeaderField10Name:
                    rowQuoteFieldIndexSet.Add(index);
                    break;

                default:
                    break;
            }
        }

        /// <summary>
        /// 貸借別仕訳項目の行で囲み文字を使用するフィールドのインデックスを追加します。
        /// </summary>
        /// <param name="exportItemList">エクスポート項目リスト</param>
        /// <param name="index">列インデックス</param>
        /// <param name="rowQuoteFieldIndexSet">行で囲み文字を使用するフィールドのインデックスのSet</param>
        /// <param name="syoriki">処理期情報</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        private void AddTaisyakubetuSiwakeItemRowQuoteFieldIndexCollection(IList<SiwakeTyouhyouExportItem> exportItemList, int index, ISet<int> rowQuoteFieldIndexSet, Syoriki syoriki)
        {
            var no = 0;
            switch (exportItemList[index])
            {
                //// ユニバーサルフィールド１コード
                case SiwakeTyouhyouExportItem.KarikataUfcd01:
                case SiwakeTyouhyouExportItem.KasikataUfcd01: no = 1; break;
                //// ユニバーサルフィールド２コード
                case SiwakeTyouhyouExportItem.KarikataUfcd02:
                case SiwakeTyouhyouExportItem.KasikataUfcd02: no = 2; break;
                //// ユニバーサルフィールド３コード
                case SiwakeTyouhyouExportItem.KarikataUfcd03:
                case SiwakeTyouhyouExportItem.KasikataUfcd03: no = 3; break;
                //// ユニバーサルフィールド４コード
                case SiwakeTyouhyouExportItem.KarikataUfcd04:
                case SiwakeTyouhyouExportItem.KasikataUfcd04: no = 4; break;
                //// ユニバーサルフィールド５コード
                case SiwakeTyouhyouExportItem.KarikataUfcd05:
                case SiwakeTyouhyouExportItem.KasikataUfcd05: no = 5; break;
                //// ユニバーサルフィールド６コード
                case SiwakeTyouhyouExportItem.KarikataUfcd06:
                case SiwakeTyouhyouExportItem.KasikataUfcd06: no = 6; break;
                //// ユニバーサルフィールド７コード
                case SiwakeTyouhyouExportItem.KarikataUfcd07:
                case SiwakeTyouhyouExportItem.KasikataUfcd07: no = 7; break;
                //// ユニバーサルフィールド８コード
                case SiwakeTyouhyouExportItem.KarikataUfcd08:
                case SiwakeTyouhyouExportItem.KasikataUfcd08: no = 8; break;
                //// ユニバーサルフィールド９コード
                case SiwakeTyouhyouExportItem.KarikataUfcd09:
                case SiwakeTyouhyouExportItem.KasikataUfcd09: no = 9; break;
                //// ユニバーサルフィールド１０コード
                case SiwakeTyouhyouExportItem.KarikataUfcd10:
                case SiwakeTyouhyouExportItem.KasikataUfcd10: no = 10; break;
                //// ユニバーサルフィールド１１コード
                case SiwakeTyouhyouExportItem.KarikataUfcd11:
                case SiwakeTyouhyouExportItem.KasikataUfcd11: no = 11; break;
                //// ユニバーサルフィールド１２コード
                case SiwakeTyouhyouExportItem.KarikataUfcd12:
                case SiwakeTyouhyouExportItem.KasikataUfcd12: no = 12; break;
                //// ユニバーサルフィールド１３コード
                case SiwakeTyouhyouExportItem.KarikataUfcd13:
                case SiwakeTyouhyouExportItem.KasikataUfcd13: no = 13; break;
                //// ユニバーサルフィールド１４コード
                case SiwakeTyouhyouExportItem.KarikataUfcd14:
                case SiwakeTyouhyouExportItem.KasikataUfcd14: no = 14; break;
                //// ユニバーサルフィールド１５コード
                case SiwakeTyouhyouExportItem.KarikataUfcd15:
                case SiwakeTyouhyouExportItem.KasikataUfcd15: no = 15; break;
                //// ユニバーサルフィールド１６コード
                case SiwakeTyouhyouExportItem.KarikataUfcd16:
                case SiwakeTyouhyouExportItem.KasikataUfcd16: no = 16; break;
                //// ユニバーサルフィールド１７コード
                case SiwakeTyouhyouExportItem.KarikataUfcd17:
                case SiwakeTyouhyouExportItem.KasikataUfcd17: no = 17; break;
                //// ユニバーサルフィールド１８コード
                case SiwakeTyouhyouExportItem.KarikataUfcd18:
                case SiwakeTyouhyouExportItem.KasikataUfcd18: no = 18; break;
                //// ユニバーサルフィールド１９コード
                case SiwakeTyouhyouExportItem.KarikataUfcd19:
                case SiwakeTyouhyouExportItem.KasikataUfcd19: no = 19; break;
                //// ユニバーサルフィールド２０コード
                case SiwakeTyouhyouExportItem.KarikataUfcd20:
                case SiwakeTyouhyouExportItem.KasikataUfcd20: no = 20; break;
                //// 摘要コード
                case SiwakeTyouhyouExportItem.KarikataTekiyouCode:
                case SiwakeTyouhyouExportItem.KasikataTekiyouCode:
                    //// 摘要コードは、囲み文字を使用しない
                    return;
                default:
                    rowQuoteFieldIndexSet.Add(index);
                    return;
            }

            this.AddUniversalFieldRowQuoteFieldIndexCollection(no, index, rowQuoteFieldIndexSet, syoriki);
        }

        /// <summary>
        /// 貸借共通仕訳項目の行で囲み文字を使用するフィールドのインデックスを追加します。
        /// </summary>
        /// <param name="exportItemList">エクスポート項目リスト</param>
        /// <param name="index">列インデックス</param>
        /// <param name="rowQuoteFieldIndexSet">行で囲み文字を使用するフィールドのインデックスのSet</param>
        private void AddTaisyakuCommonSiwakeItemRowQuoteFieldIndexCollection(IList<SiwakeTyouhyouExportItem> exportItemList, int index, ISet<int> rowQuoteFieldIndexSet)
        {
            switch (exportItemList[index])
            {
                //// 消費税対象科目コード
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKcod:
                //// 消費税対象科目名称
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuName:
                //// 消費税対象科目税区分
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuZeiKubun:
                //// 消費税対象科目仕入・業種区分
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                //// 消込コード
                case SiwakeTyouhyouExportItem.KesikomiCode:
                //// 支払区分
                case SiwakeTyouhyouExportItem.SiharaiKubun:
                //// 入金区分
                case SiwakeTyouhyouExportItem.NyuukinKubun:
                //// 仕訳作成者名
                case SiwakeTyouhyouExportItem.SiwakeCreateUserName:
                //// 仕訳更新者名
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserName:
                    rowQuoteFieldIndexSet.Add(index);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドの行で囲み文字を使用するフィールドのインデックスを追加します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="index">列インデックス</param>
        /// <param name="rowQuoteFieldIndexSet">行で囲み文字を使用するフィールドのインデックスのSet</param>
        /// <param name="syoriki">処理期情報</param>
        private void AddUniversalFieldRowQuoteFieldIndexCollection(int no, int index, ISet<int> rowQuoteFieldIndexSet, Syoriki syoriki)
        {
            var universalFieldInfo = syoriki.GetUniversalFieldInfo(false, no);
            if (universalFieldInfo.DataType == UniversalFieldDataType.Numeric
                || universalFieldInfo.DataType == UniversalFieldDataType.Alphanumeric
                || universalFieldInfo.DataType == UniversalFieldDataType.Char)
            {
                //// 数字・英数・文字のみ
                rowQuoteFieldIndexSet.Add(index);
            }
        }

        /// <summary>
        /// ヘッダー項目の出力文字列リストを作成します。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="syoriKikan">処理期間情報</param>
        /// <returns>ヘッダー項目の出力文字列リスト</returns>
        private IList<List<string>> CreateHeaderItemList(ExportOption exportOption, SiwakeTyouhyouExportItemOption exportItemOption, IKaisyaSyoriKikan syoriKikan)
        {
            var headerItemList = new List<List<string>>();

            //// 1行目のヘッダー追加
            if (exportItemOption.IsExportTitleName || exportOption.IsOutputComment)
            {
                var firstLineHeaderItemList = new List<string>();

                //// タイトル
                if (exportItemOption.IsExportTitleName)
                {
                    firstLineHeaderItemList.Add(Resources.仕訳リスト);
                }

                //// コメント
                if (exportOption.IsOutputComment)
                {
                    //// タイトルがない場合は、空のデータを挿入
                    if (!firstLineHeaderItemList.Any())
                    {
                        firstLineHeaderItemList.Add(string.Empty);
                    }

                    firstLineHeaderItemList.Add(exportOption.Comment);
                }

                headerItemList.Add(firstLineHeaderItemList);
            }

            //// 2行目のヘッダー追加
            if (exportItemOption.IsExportCompanyName || exportItemOption.IsExportSyoriKikan)
            {
                var secondLineHeaderItemList = new List<string>();

                //// 会社名
                if (exportItemOption.IsExportCompanyName)
                {
                    var companyString = exportOption.Kaisya.Name;

                    //// 会社コード出力時
                    if (exportOption.IsOutputKaisyaCode)
                    {
                        companyString = string.Format("[{0}]{1}", exportOption.Kaisya.Ccod, companyString);
                    }

                    //// 会社タイトル出力時
                    if (exportOption.IsOutputKaisyaTitle)
                    {
                        companyString = string.Format(Resources.Format0名1, exportOption.OrganizationTypeName, companyString);
                    }

                    secondLineHeaderItemList.Add(companyString);
                }

                //// 処理期間
                if (exportItemOption.IsExportSyoriKikan)
                {
                    //// 会社名がない場合は、空のデータを挿入
                    if (!secondLineHeaderItemList.Any())
                    {
                        secondLineHeaderItemList.Add(string.Empty);
                    }

                    var syoriKikanLabel = syoriKikan.Syoriki.GetSyoriKikan().GetKikanLabel();
                    var syoriKikanString = syoriKikanLabel.Substring(syoriKikanLabel.IndexOf(Resources.自) + 2);
                    secondLineHeaderItemList.Add(syoriKikanString.Replace(Resources.至, "～"));
                }

                headerItemList.Add(secondLineHeaderItemList);
            }

            return headerItemList;
        }

        /// <summary>
        /// 項目タイトルの出力文字列リストを作成します。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="csvConfig">CSVファイルI/O設定</param>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>項目タイトルの出力文字列リスト</returns>
        private IList<string> CreateItemTitleList(ExportOption exportOption, SiwakeTyouhyouExportItemOption exportItemOption, CsvConfig csvConfig, Syoriki syoriki, bool gaikaItemEnabled, SyouhizeiMaster syouhizeiMaster)
        {
            //// 項目タイトルの出力文字列リスト作成
            var itemTitleList = new List<string>();
            var headerRowQuoteFieldIndexCollection = new HashSet<int>() { 0, 1 };
            foreach (var exportItem in exportItemOption.ExportItemSet)
            {
                var itemTitleString = exportItem.GetExportName(exportOption.Kaisya, syoriki, gaikaItemEnabled, syouhizeiMaster);
                if (!string.IsNullOrEmpty(itemTitleString))
                {
                    //// 項目タイトルのインデックス（itemTitleList.Countが現在のインデックス）追加（タイトル用に、事前に２個追加済）
                    if (itemTitleList.Count > 1)
                    {
                        headerRowQuoteFieldIndexCollection.Add(itemTitleList.Count);
                    }

                    itemTitleList.Add(itemTitleString);
                }
            }

            //// ヘッダー行で囲み文字を使用するフィールドのインデックス追加
            csvConfig.AddHeaderRowQuoteFieldIndexCollection(headerRowQuoteFieldIndexCollection);

            return itemTitleList;
        }

#pragma warning disable SA1131 // Use readable conditions
        /// <summary>
        /// 項目の出力文字列リストを作成します。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="rows">単一仕訳帳票の行データリスト</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>項目の出力文字列リスト</returns>
        private IList<List<string>> CreateItemList(ExportOption exportOption, SiwakeTyouhyouExportItemOption exportItemOption, IList<ITanituSiwakeTyouhyouRow> rows, SiwakeTyouhyouOption siwakeTyouhyouOption, Syoriki syoriki, bool gaikaItemEnabled, SyouhizeiMaster syouhizeiMaster)
        {
            var tokuteiSyuunyuuKamokuList = this.tokuteiSyuunyuuKamokuRepository.FindByKesn(syoriki.Kesn);
            var itemRows = new List<List<string>>();
            foreach (var row in rows)
            {
                var itemRow = new List<string>();
                foreach (var exportItem in exportItemOption.ExportItemSet)
                {
                    if (SiwakeTyouhyouExportItem.Dkei <= exportItem && exportItem <= SiwakeTyouhyouExportItem.HeaderField10Name)
                    {
                        //// 伝票項目
                        itemRow.Add(this.GetDenpyouItemString(exportItem, row, syoriki));
                    }
                    else if (SiwakeTyouhyouExportItem.KarikataBcod <= exportItem && exportItem <= SiwakeTyouhyouExportItem.KarikataHeisyu)
                    {
                        //// 仕訳項目（借方）
                        itemRow.Add(this.GetTaisyakubetuSiwakeItemString(exportItem, row, true, siwakeTyouhyouOption, syoriki, syouhizeiMaster, tokuteiSyuunyuuKamokuList));
                    }
                    else if (SiwakeTyouhyouExportItem.KasikataBcod <= exportItem && exportItem <= SiwakeTyouhyouExportItem.KasikataHeisyu)
                    {
                        //// 仕訳項目（貸方）
                        itemRow.Add(this.GetTaisyakubetuSiwakeItemString(exportItem, row, false, siwakeTyouhyouOption, syoriki, syouhizeiMaster, tokuteiSyuunyuuKamokuList));
                    }
                    else
                    {
                        //// 仕訳項目（貸借共通）
                        itemRow.Add(this.GetTaisyakuCommonSiwakeItemString(exportItem, exportOption, row, siwakeTyouhyouOption, gaikaItemEnabled, syouhizeiMaster));
                    }
                }

                itemRows.Add(itemRow);
            }

            return itemRows;
        }
#pragma warning disable SA1131 // Use readable conditions

        /// <summary>
        /// 伝票項目の出力文字列を取得します。
        /// </summary>
        /// <param name="exportItem">エクスポート項目</param>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="syoriki">処理期情報</param>
        /// <returns>伝票項目の出力文字列</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        private string GetDenpyouItemString(SiwakeTyouhyouExportItem exportItem, ITanituSiwakeTyouhyouRow row, Syoriki syoriki)
        {
            //// 下記において!string.IsNullOrEmpty()でチェックしている部分は、
            //// コードが空で名称が存在する場合はないとは思いますが、SIASの記載に合わせています。
            switch (exportItem)
            {
                //// 経過月
                case SiwakeTyouhyouExportItem.Dkei:
                    return row.Dkei.ToString();
                //// 受付番号
                case SiwakeTyouhyouExportItem.UketukeNo:
                    return row.UketukeNo.ToString();
                //// 伝票日付
                case SiwakeTyouhyouExportItem.DenpyouDate:
                    return row.DenpyouDate.GetFormattedYmd(string.Empty);
                //// 伝票番号
                case SiwakeTyouhyouExportItem.DenpyouNo:
                    return row.DenpyouNo?.ToString();
                //// 伝票SEQ
                case SiwakeTyouhyouExportItem.Dseq:
                    return row.Dseq.ToString();
                //// 伝票作成日
                case SiwakeTyouhyouExportItem.DenpyouCreateDate:
                    return row.DenpyouCreateDate.GetFormattedYmd(string.Empty);
                //// 伝票作成者コード
                case SiwakeTyouhyouExportItem.DenpyouCreateUserCode:
                    return row.DenpyouCreateUserCode.ToString();
                //// 伝票作成者名
                case SiwakeTyouhyouExportItem.DenpyouCreateUserName:
                    return row.DenpyouCreateUserName;
                //// 伝票更新日
                case SiwakeTyouhyouExportItem.DenpyouUpdateDate:
                    return row.DenpyouUpdateDate.GetFormattedYmd(string.Empty);
                //// 伝票更新者コード
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserCode:
                    return row.DenpyouUpdateUserCode.ToString();
                //// 伝票更新者名
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserName:
                    return row.DenpyouUpdateUserName;
                //// 起票日
                case SiwakeTyouhyouExportItem.KihyouDate:
                    return row.KihyouDate?.GetFormattedYmd(string.Empty);
                //// 起票部門コード
                case SiwakeTyouhyouExportItem.KihyouBumonCode:
                    return row.KihyouBumonCode;
                //// 起票部門名称
                case SiwakeTyouhyouExportItem.KihyouBumonName:
                    return !string.IsNullOrEmpty(row.KihyouBumonCode) ? row.KihyouBumonName : string.Empty;
                //// 起票者コード
                case SiwakeTyouhyouExportItem.KihyouTantousyaCode:
                    return row.KihyouTantousyaCode;
                //// 起票者名
                case SiwakeTyouhyouExportItem.KihyouTantousyaName:
                    return !string.IsNullOrEmpty(row.KihyouTantousyaCode) ? row.KihyouTantousyaName : string.Empty;
                //// ヘッダーフィールド１コード
                case SiwakeTyouhyouExportItem.Hfcd01:
                    return this.GetUniversalFieldCodeString(row.Hfcd01, true, 1, syoriki);
                //// ヘッダーフィールド１名称
                case SiwakeTyouhyouExportItem.HeaderField01Name:
                    return !string.IsNullOrEmpty(row.Hfcd01) ? row.HeaderField01Name : string.Empty;
                //// ヘッダーフィールド２コード
                case SiwakeTyouhyouExportItem.Hfcd02:
                    return this.GetUniversalFieldCodeString(row.Hfcd02, true, 2, syoriki);
                //// ヘッダーフィールド２名称
                case SiwakeTyouhyouExportItem.HeaderField02Name:
                    return !string.IsNullOrEmpty(row.Hfcd02) ? row.HeaderField02Name : string.Empty;
                //// ヘッダーフィールド３コード
                case SiwakeTyouhyouExportItem.Hfcd03:
                    return this.GetUniversalFieldCodeString(row.Hfcd03, true, 3, syoriki);
                //// ヘッダーフィールド３名称
                case SiwakeTyouhyouExportItem.HeaderField03Name:
                    return !string.IsNullOrEmpty(row.Hfcd03) ? row.HeaderField03Name : string.Empty;
                //// ヘッダーフィールド４コード
                case SiwakeTyouhyouExportItem.Hfcd04:
                    return this.GetUniversalFieldCodeString(row.Hfcd04, true, 4, syoriki);
                //// ヘッダーフィールド４名称
                case SiwakeTyouhyouExportItem.HeaderField04Name:
                    return !string.IsNullOrEmpty(row.Hfcd04) ? row.HeaderField04Name : string.Empty;
                //// ヘッダーフィールド５コード
                case SiwakeTyouhyouExportItem.Hfcd05:
                    return this.GetUniversalFieldCodeString(row.Hfcd05, true, 5, syoriki);
                //// ヘッダーフィールド５名称
                case SiwakeTyouhyouExportItem.HeaderField05Name:
                    return !string.IsNullOrEmpty(row.Hfcd05) ? row.HeaderField05Name : string.Empty;
                //// ヘッダーフィールド６コード
                case SiwakeTyouhyouExportItem.Hfcd06:
                    return this.GetUniversalFieldCodeString(row.Hfcd06, true, 6, syoriki);
                //// ヘッダーフィールド６名称
                case SiwakeTyouhyouExportItem.HeaderField06Name:
                    return !string.IsNullOrEmpty(row.Hfcd06) ? row.HeaderField06Name : string.Empty;
                //// ヘッダーフィールド７コード
                case SiwakeTyouhyouExportItem.Hfcd07:
                    return this.GetUniversalFieldCodeString(row.Hfcd07, true, 7, syoriki);
                //// ヘッダーフィールド７名称
                case SiwakeTyouhyouExportItem.HeaderField07Name:
                    return !string.IsNullOrEmpty(row.Hfcd07) ? row.HeaderField07Name : string.Empty;
                //// ヘッダーフィールド８コード
                case SiwakeTyouhyouExportItem.Hfcd08:
                    return this.GetUniversalFieldCodeString(row.Hfcd08, true, 8, syoriki);
                //// ヘッダーフィールド８名称
                case SiwakeTyouhyouExportItem.HeaderField08Name:
                    return !string.IsNullOrEmpty(row.Hfcd08) ? row.HeaderField08Name : string.Empty;
                //// ヘッダーフィールド９コード
                case SiwakeTyouhyouExportItem.Hfcd09:
                    return this.GetUniversalFieldCodeString(row.Hfcd09, true, 9, syoriki);
                //// ヘッダーフィールド９名称
                case SiwakeTyouhyouExportItem.HeaderField09Name:
                    return !string.IsNullOrEmpty(row.Hfcd09) ? row.HeaderField09Name : string.Empty;
                //// ヘッダーフィールド１０コード
                case SiwakeTyouhyouExportItem.Hfcd10:
                    return this.GetUniversalFieldCodeString(row.Hfcd10, true, 10, syoriki);
                //// ヘッダーフィールド１０名称
                case SiwakeTyouhyouExportItem.HeaderField10Name:
                    return !string.IsNullOrEmpty(row.Hfcd10) ? row.HeaderField10Name : string.Empty;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// 貸借別仕訳項目の出力文字列を取得します。
        /// </summary>
        /// <param name="exportItem">エクスポート項目</param>
        /// <param name="siwakeTyouhyouRow">単一仕訳帳票の行データ</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="tokuteiSyuunyuuKamokuList">特定収入科目リスト</param>
        /// <returns>貸借別仕訳項目の出力文字列</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目省略不可")]
        private string GetTaisyakubetuSiwakeItemString(SiwakeTyouhyouExportItem exportItem, ITanituSiwakeTyouhyouRow siwakeTyouhyouRow, bool isKarikata, SiwakeTyouhyouOption siwakeTyouhyouOption, Syoriki syoriki, SyouhizeiMaster syouhizeiMaster, IList<TokuteiSyuunyuuKamoku> tokuteiSyuunyuuKamokuList)
        {
            var row = isKarikata ? siwakeTyouhyouRow.KarikataDetail : siwakeTyouhyouRow.KasikataDetail;

            //// 下記において!string.IsNullOrEmpty()などでチェックしている部分は、
            //// コードが空で名称が存在する場合はないとは思いますが、SIASの記載に合わせています。
            switch (exportItem)
            {
                //// 部門コード
                case SiwakeTyouhyouExportItem.KarikataBcod:
                case SiwakeTyouhyouExportItem.KasikataBcod:
                    return row.Bcod;
                //// 部門名称
                case SiwakeTyouhyouExportItem.KarikataBumonName:
                case SiwakeTyouhyouExportItem.KasikataBumonName:
                    return !string.IsNullOrEmpty(row.Bcod) ? row.BumonName : string.Empty;
                //// 取引先コード
                case SiwakeTyouhyouExportItem.KarikataTrcd:
                case SiwakeTyouhyouExportItem.KasikataTrcd:
                    return row.Trcd;
                //// 取引先名称
                case SiwakeTyouhyouExportItem.KarikataTorihikisakiName:
                case SiwakeTyouhyouExportItem.KasikataTorihikisakiName:
                    return !string.IsNullOrEmpty(row.Trcd) ? row.TorihikisakiName : string.Empty;
                //// 科目コード
                case SiwakeTyouhyouExportItem.KarikataKcod:
                case SiwakeTyouhyouExportItem.KasikataKcod:
                    return !string.IsNullOrEmpty(row.Kicd) ? row.Kcod : string.Empty;
                //// 科目名称
                case SiwakeTyouhyouExportItem.KarikataKamokuName:
                case SiwakeTyouhyouExportItem.KasikataKamokuName:
                    return !string.IsNullOrEmpty(row.Kicd) ? row.KamokuName : string.Empty;
                //// 枝番コード
                case SiwakeTyouhyouExportItem.KarikataEcod:
                case SiwakeTyouhyouExportItem.KasikataEcod:
                    return row.Ecod;
                //// 枝番名称
                case SiwakeTyouhyouExportItem.KarikataEdabanName:
                case SiwakeTyouhyouExportItem.KasikataEdabanName:
                    return !string.IsNullOrEmpty(row.Ecod) ? row.EdabanName : string.Empty;
                //// 工事コード
                case SiwakeTyouhyouExportItem.KarikataKzcd:
                case SiwakeTyouhyouExportItem.KasikataKzcd:
                    return row.Kzcd;
                //// 工事名称
                case SiwakeTyouhyouExportItem.KarikataKouziName:
                case SiwakeTyouhyouExportItem.KasikataKouziName:
                    return !string.IsNullOrEmpty(row.Kzcd) ? row.KouziName : string.Empty;
                //// 工種コード
                case SiwakeTyouhyouExportItem.KarikataKscd:
                case SiwakeTyouhyouExportItem.KasikataKscd:
                    return row.Kscd;
                //// 工種名称
                case SiwakeTyouhyouExportItem.KarikataKousyuName:
                case SiwakeTyouhyouExportItem.KasikataKousyuName:
                    return !string.IsNullOrEmpty(row.Kscd) ? row.KousyuName : string.Empty;
                //// プロジェクトコード
                case SiwakeTyouhyouExportItem.KarikataPjcd:
                case SiwakeTyouhyouExportItem.KasikataPjcd:
                    return row.Pjcd;
                //// プロジェクト名称
                case SiwakeTyouhyouExportItem.KarikataProjectName:
                case SiwakeTyouhyouExportItem.KasikataProjectName:
                    return !string.IsNullOrEmpty(row.Pjcd) ? row.ProjectName : string.Empty;
                //// セグメントコード
                case SiwakeTyouhyouExportItem.KarikataSgcd:
                case SiwakeTyouhyouExportItem.KasikataSgcd:
                    return row.Sgcd;
                //// セグメント名称
                case SiwakeTyouhyouExportItem.KarikataSegmentName:
                case SiwakeTyouhyouExportItem.KasikataSegmentName:
                    return !string.IsNullOrEmpty(row.Sgcd) ? row.SegmentName : string.Empty;
                //// ユニバーサルフィールド１コード
                case SiwakeTyouhyouExportItem.KarikataUfcd01:
                case SiwakeTyouhyouExportItem.KasikataUfcd01:
                    return this.GetUniversalFieldCodeString(row.Ufcd01, false, 1, syoriki);
                //// ユニバーサルフィールド１名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField01Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField01Name:
                    return !string.IsNullOrEmpty(row.Ufcd01) ? row.UniversalField01Name : string.Empty;
                //// ユニバーサルフィールド２コード
                case SiwakeTyouhyouExportItem.KarikataUfcd02:
                case SiwakeTyouhyouExportItem.KasikataUfcd02:
                    return this.GetUniversalFieldCodeString(row.Ufcd02, false, 2, syoriki);
                //// ユニバーサルフィールド２名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField02Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField02Name:
                    return !string.IsNullOrEmpty(row.Ufcd02) ? row.UniversalField02Name : string.Empty;
                //// ユニバーサルフィールド３コード
                case SiwakeTyouhyouExportItem.KarikataUfcd03:
                case SiwakeTyouhyouExportItem.KasikataUfcd03:
                    return this.GetUniversalFieldCodeString(row.Ufcd03, false, 3, syoriki);
                //// ユニバーサルフィールド３名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField03Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField03Name:
                    return !string.IsNullOrEmpty(row.Ufcd03) ? row.UniversalField03Name : string.Empty;
                //// ユニバーサルフィールド４コード
                case SiwakeTyouhyouExportItem.KarikataUfcd04:
                case SiwakeTyouhyouExportItem.KasikataUfcd04:
                    return this.GetUniversalFieldCodeString(row.Ufcd04, false, 4, syoriki);
                //// ユニバーサルフィールド４名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField04Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField04Name:
                    return !string.IsNullOrEmpty(row.Ufcd04) ? row.UniversalField04Name : string.Empty;
                //// ユニバーサルフィールド５コード
                case SiwakeTyouhyouExportItem.KarikataUfcd05:
                case SiwakeTyouhyouExportItem.KasikataUfcd05:
                    return this.GetUniversalFieldCodeString(row.Ufcd05, false, 5, syoriki);
                //// ユニバーサルフィールド５名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField05Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField05Name:
                    return !string.IsNullOrEmpty(row.Ufcd05) ? row.UniversalField05Name : string.Empty;
                //// ユニバーサルフィールド６コード
                case SiwakeTyouhyouExportItem.KarikataUfcd06:
                case SiwakeTyouhyouExportItem.KasikataUfcd06:
                    return this.GetUniversalFieldCodeString(row.Ufcd06, false, 6, syoriki);
                //// ユニバーサルフィールド６名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField06Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField06Name:
                    return !string.IsNullOrEmpty(row.Ufcd06) ? row.UniversalField06Name : string.Empty;
                //// ユニバーサルフィールド７コード
                case SiwakeTyouhyouExportItem.KarikataUfcd07:
                case SiwakeTyouhyouExportItem.KasikataUfcd07:
                    return this.GetUniversalFieldCodeString(row.Ufcd07, false, 7, syoriki);
                //// ユニバーサルフィールド７名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField07Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField07Name:
                    return !string.IsNullOrEmpty(row.Ufcd07) ? row.UniversalField07Name : string.Empty;
                //// ユニバーサルフィールド８コード
                case SiwakeTyouhyouExportItem.KarikataUfcd08:
                case SiwakeTyouhyouExportItem.KasikataUfcd08:
                    return this.GetUniversalFieldCodeString(row.Ufcd08, false, 8, syoriki);
                //// ユニバーサルフィールド８名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField08Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField08Name:
                    return !string.IsNullOrEmpty(row.Ufcd08) ? row.UniversalField08Name : string.Empty;
                //// ユニバーサルフィールド９コード
                case SiwakeTyouhyouExportItem.KarikataUfcd09:
                case SiwakeTyouhyouExportItem.KasikataUfcd09:
                    return this.GetUniversalFieldCodeString(row.Ufcd09, false, 9, syoriki);
                //// ユニバーサルフィールド９名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField09Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField09Name:
                    return !string.IsNullOrEmpty(row.Ufcd09) ? row.UniversalField09Name : string.Empty;
                //// ユニバーサルフィールド１０コード
                case SiwakeTyouhyouExportItem.KarikataUfcd10:
                case SiwakeTyouhyouExportItem.KasikataUfcd10:
                    return this.GetUniversalFieldCodeString(row.Ufcd10, false, 10, syoriki);
                //// ユニバーサルフィールド１０名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField10Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField10Name:
                    return !string.IsNullOrEmpty(row.Ufcd10) ? row.UniversalField10Name : string.Empty;
                //// ユニバーサルフィールド１１コード
                case SiwakeTyouhyouExportItem.KarikataUfcd11:
                case SiwakeTyouhyouExportItem.KasikataUfcd11:
                    return this.GetUniversalFieldCodeString(row.Ufcd11, false, 11, syoriki);
                //// ユニバーサルフィールド１１名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField11Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField11Name:
                    return !string.IsNullOrEmpty(row.Ufcd11) ? row.UniversalField11Name : string.Empty;
                //// ユニバーサルフィールド１２コード
                case SiwakeTyouhyouExportItem.KarikataUfcd12:
                case SiwakeTyouhyouExportItem.KasikataUfcd12:
                    return this.GetUniversalFieldCodeString(row.Ufcd12, false, 12, syoriki);
                //// ユニバーサルフィールド１２名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField12Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField12Name:
                    return !string.IsNullOrEmpty(row.Ufcd12) ? row.UniversalField12Name : string.Empty;
                //// ユニバーサルフィールド１３コード
                case SiwakeTyouhyouExportItem.KarikataUfcd13:
                case SiwakeTyouhyouExportItem.KasikataUfcd13:
                    return this.GetUniversalFieldCodeString(row.Ufcd13, false, 13, syoriki);
                //// ユニバーサルフィールド１３名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField13Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField13Name:
                    return !string.IsNullOrEmpty(row.Ufcd13) ? row.UniversalField13Name : string.Empty;
                //// ユニバーサルフィールド１４コード
                case SiwakeTyouhyouExportItem.KarikataUfcd14:
                case SiwakeTyouhyouExportItem.KasikataUfcd14:
                    return this.GetUniversalFieldCodeString(row.Ufcd14, false, 14, syoriki);
                //// ユニバーサルフィールド１４名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField14Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField14Name:
                    return !string.IsNullOrEmpty(row.Ufcd14) ? row.UniversalField14Name : string.Empty;
                //// ユニバーサルフィールド１５コード
                case SiwakeTyouhyouExportItem.KarikataUfcd15:
                case SiwakeTyouhyouExportItem.KasikataUfcd15:
                    return this.GetUniversalFieldCodeString(row.Ufcd15, false, 15, syoriki);
                //// ユニバーサルフィールド１５名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField15Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField15Name:
                    return !string.IsNullOrEmpty(row.Ufcd15) ? row.UniversalField15Name : string.Empty;
                //// ユニバーサルフィールド１６コード
                case SiwakeTyouhyouExportItem.KarikataUfcd16:
                case SiwakeTyouhyouExportItem.KasikataUfcd16:
                    return this.GetUniversalFieldCodeString(row.Ufcd16, false, 16, syoriki);
                //// ユニバーサルフィールド１６名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField16Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField16Name:
                    return !string.IsNullOrEmpty(row.Ufcd16) ? row.UniversalField16Name : string.Empty;
                //// ユニバーサルフィールド１７コード
                case SiwakeTyouhyouExportItem.KarikataUfcd17:
                case SiwakeTyouhyouExportItem.KasikataUfcd17:
                    return this.GetUniversalFieldCodeString(row.Ufcd17, false, 17, syoriki);
                //// ユニバーサルフィールド１７名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField17Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField17Name:
                    return !string.IsNullOrEmpty(row.Ufcd17) ? row.UniversalField17Name : string.Empty;
                //// ユニバーサルフィールド１８コード
                case SiwakeTyouhyouExportItem.KarikataUfcd18:
                case SiwakeTyouhyouExportItem.KasikataUfcd18:
                    return this.GetUniversalFieldCodeString(row.Ufcd18, false, 18, syoriki);
                //// ユニバーサルフィールド１８名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField18Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField18Name:
                    return !string.IsNullOrEmpty(row.Ufcd18) ? row.UniversalField18Name : string.Empty;
                //// ユニバーサルフィールド１９コード
                case SiwakeTyouhyouExportItem.KarikataUfcd19:
                case SiwakeTyouhyouExportItem.KasikataUfcd19:
                    return this.GetUniversalFieldCodeString(row.Ufcd19, false, 19, syoriki);
                //// ユニバーサルフィールド１９名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField19Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField19Name:
                    return !string.IsNullOrEmpty(row.Ufcd19) ? row.UniversalField19Name : string.Empty;
                //// ユニバーサルフィールド２０コード
                case SiwakeTyouhyouExportItem.KarikataUfcd20:
                case SiwakeTyouhyouExportItem.KasikataUfcd20:
                    return this.GetUniversalFieldCodeString(row.Ufcd20, false, 20, syoriki);
                //// ユニバーサルフィールド２０名称
                case SiwakeTyouhyouExportItem.KarikataUniversalField20Name:
                case SiwakeTyouhyouExportItem.KasikataUniversalField20Name:
                    return !string.IsNullOrEmpty(row.Ufcd20) ? row.UniversalField20Name : string.Empty;
                //// 摘要
                case SiwakeTyouhyouExportItem.KarikataTekiyou:
                case SiwakeTyouhyouExportItem.KasikataTekiyou:
                    return row.Tekiyou;
                //// 摘要コード
                case SiwakeTyouhyouExportItem.KarikataTekiyouCode:
                case SiwakeTyouhyouExportItem.KasikataTekiyouCode:
                    return row.TekiyouCode != null ? row.TekiyouCode?.ToString("D4") : string.Empty;
                //// 摘要名称
                case SiwakeTyouhyouExportItem.KarikataTekiyouName:
                case SiwakeTyouhyouExportItem.KasikataTekiyouName:
                    return row.TekiyouCode != null ? row.TekiyouName : string.Empty;
                //// 税区分
                case SiwakeTyouhyouExportItem.KarikataZeiKubun:
                case SiwakeTyouhyouExportItem.KasikataZeiKubun:
                    return this.GetZeiKubunString(
                                row.Syouhizeiritu,
                                row.IsLatestSyouhizeirituBeforeDenpyouDate,
                                row.KazeiKubun,
                                siwakeTyouhyouRow.IkkatuZeinukiSiwakeFlag,
                                siwakeTyouhyouOption,
                                syouhizeiMaster,
                                tokuteiSyuunyuuKamokuList.FirstOrDefault(kamoku => kamoku.Kicd == row.Kicd),
                                row.KamokuSyoriGroup);
                //// 仕入・業種区分
                case SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun:
                case SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun:
                    return this.GetGyousyuKubunAndSiireKubunString(row.GyousyuKubun, row.SiwakeSiireKubun, row.KazeiKubun, syouhizeiMaster);
                //// 幣種
                case SiwakeTyouhyouExportItem.KarikataHeisyu:
                case SiwakeTyouhyouExportItem.KasikataHeisyu:
                    return row.HeisyuCode;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// 貸借共通仕訳項目の出力文字列を取得します。
        /// </summary>
        /// <param name="exportItem">エクスポート項目</param>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>貸借共通仕訳項目の出力文字列</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        private string GetTaisyakuCommonSiwakeItemString(SiwakeTyouhyouExportItem exportItem, ExportOption exportOption, ITanituSiwakeTyouhyouRow row, SiwakeTyouhyouOption siwakeTyouhyouOption, bool gaikaItemEnabled, SyouhizeiMaster syouhizeiMaster)
        {
            //// 下記において!string.IsNullOrEmpty()などでチェックしている部分は、
            //// コードが空で名称が存在する場合はないとは思いますが、SIASの記載に合わせています。
            switch (exportItem)
            {
                //// 金額
                case SiwakeTyouhyouExportItem.Kingaku:
                    return row.Kingaku.ToString();
                //// 対価金額
                case SiwakeTyouhyouExportItem.TaikaKingaku:
                    return row.IsInputTaikaKingaku ? row.TaikaKingaku.ToString() : string.Empty;
                //// 税込金額
                case SiwakeTyouhyouExportItem.ZeikomiKingaku:
                    return
                        row.SiwakeParentChildRelated == SiwakeParentChildRelated.Parent
                        && row.BunriKubun == BunriKubun.ZidouBunri
                            ? row.ZeikomiKingaku.ToString()
                            : string.Empty;
                //// 消費税対象科目コード
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKcod:
                    return !string.IsNullOrEmpty(row.SyouhizeiTaisyouKicd) ? row.SyouhizeiTaisyouKcod : string.Empty;
                //// 消費税対象科目名称
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuName:
                    return !string.IsNullOrEmpty(row.SyouhizeiTaisyouKicd) ? row.SyouhizeiTaisyouKamokuName : string.Empty;
                //// 消費税対象科目税区分
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuZeiKubun:
                    return this.GetZeiKubunString(
                            row.SyouhizeiTaisyouKamokuSyouhizeiritu,
                            row.IsLatestSyouhizeiTaisyouKamokuSyouhizeirituBeforeDenpyouDate,
                            row.SyouhizeiTaisyouKamokuKazeiKubun,
                            IkkatuZeinukiSiwakeFlag.TuuzyouSiwake,
                            siwakeTyouhyouOption,
                            syouhizeiMaster,
                            null,
                            row.SyouhizeiTaisyouKamokuSyoriGroup);
                //// 消費税対象科目仕入・業種区分
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                    return this.GetGyousyuKubunAndSiireKubunString(row.SyouhizeiTaisyouKamokuGyousyuKubun, row.SyouhizeiTaisyouKamokuSiireKubun, row.SyouhizeiTaisyouKamokuKazeiKubun, syouhizeiMaster);
                //// 消込コード
                case SiwakeTyouhyouExportItem.KesikomiCode:
                    return row.KesikomiCode;
                //// 支払日
                case SiwakeTyouhyouExportItem.SiharaiDate:
                    return row.SiharaiDate?.GetFormattedYmd(string.Empty);
                //// 支払区分
                case SiwakeTyouhyouExportItem.SiharaiKubun:
                    return row.SiharaiKubunCode != null ? row.SiharaiKubunName : string.Empty;
                //// 支払期日
                case SiwakeTyouhyouExportItem.SiharaiKizitu:
                    return row.SiharaiKizitu?.GetFormattedYmd(string.Empty);
                //// 回収日
                case SiwakeTyouhyouExportItem.KaisyuuDate:
                    return row.KaisyuuDate?.GetFormattedYmd(string.Empty);
                //// 入金区分
                case SiwakeTyouhyouExportItem.NyuukinKubun:
                    return row.NyuukinKubunCode != null ? row.NyuukinKubunName : string.Empty;
                //// 回収期日
                case SiwakeTyouhyouExportItem.KaisyuuKizitu:
                    return row.KaisyuuKizitu?.GetFormattedYmd(string.Empty);
                //// 外貨金額
                case SiwakeTyouhyouExportItem.GaikaKingaku:
                    return this.GetGaikaKingakuString(row.GaikaKingaku, row, gaikaItemEnabled);
                //// 外貨対価金額
                case SiwakeTyouhyouExportItem.GaikaTaikaKingaku:
                    return row.IsInputTaikaKingaku ? this.GetGaikaKingakuString(row.GaikaTaikaKingaku, row, gaikaItemEnabled) : string.Empty;
                //// 外貨税込金額
                case SiwakeTyouhyouExportItem.GaikaZeikomiKingaku:
                    return row.SiwakeParentChildRelated == SiwakeParentChildRelated.Parent && row.BunriKubun == BunriKubun.ZidouBunri
                        ? this.GetGaikaKingakuString(row.GaikaZeikomiKingaku, row, gaikaItemEnabled)
                        : string.Empty;
                //// レート
                case SiwakeTyouhyouExportItem.Rate:
                    return
                        gaikaItemEnabled
                        && (!string.IsNullOrEmpty(row.KarikataDetail.HeisyuCode) || !string.IsNullOrEmpty(row.KasikataDetail.HeisyuCode))
                            ? row.Rate.ToString("#0.00000")
                            : string.Empty;
                //// 仕訳SEQ
                case SiwakeTyouhyouExportItem.Sseq:
                    return row.Sseq.ToString();
                //// 仕訳作成日
                case SiwakeTyouhyouExportItem.SiwakeCreateDate:
                    return row.SiwakeCreateDate.GetFormattedYmd(string.Empty);
                //// 仕訳作成者コード
                case SiwakeTyouhyouExportItem.SiwakeCreateUserCode:
                    return row.SiwakeCreateUserCode.ToString();
                //// 仕訳作成者名
                case SiwakeTyouhyouExportItem.SiwakeCreateUserName:
                    return row.SiwakeCreateUserName;
                //// 仕訳更新日
                case SiwakeTyouhyouExportItem.SiwakeUpdateDate:
                    return row.SiwakeUpdateDate.GetFormattedYmd(string.Empty);
                //// 仕訳更新者コード
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserCode:
                    return row.SiwakeUpdateUserCode.ToString();
                //// 仕訳更新者名
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserName:
                    return row.SiwakeUpdateUserName;
                //// 会社コード
                case SiwakeTyouhyouExportItem.Ccod:
                    return exportOption.Kaisya.Ccod;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドコードの出力文字列を取得します。
        /// </summary>
        /// <param name="universalFieldCode">ユニバーサルフィールドコード</param>
        /// <param name="isHeaderField">ヘッダーフィールドかどうか</param>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="syoriki">処理期情報</param>
        /// <returns>ユニバーサルフィールドコードの出力文字列</returns>
        private string GetUniversalFieldCodeString(string universalFieldCode, bool isHeaderField, int no, Syoriki syoriki)
        {
            var universalFieldInfo = syoriki.GetUniversalFieldInfo(isHeaderField, no);
            if (!string.IsNullOrEmpty(universalFieldCode))
            {
                switch (universalFieldInfo.DataType)
                {
                    //// 金額・小数
                    case UniversalFieldDataType.Money:
                    case UniversalFieldDataType.Decimal:
                        return universalFieldCode.Replace(",", string.Empty);

                    //// 日付
                    case UniversalFieldDataType.Date:
                        return universalFieldCode.Replace("/", string.Empty);

                    //// 数字・英数・文字
                    default:
                        return universalFieldCode;
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// 税区分の出力文字列を取得します。
        /// </summary>
        /// <param name="syouhizeiritu">消費税率</param>
        /// <param name="isLatestSyouhizeirituBeforeDenpyouDate">伝票日付以前の最新税率かどうか</param>
        /// <param name="kazeiKubun">課税区分</param>
        /// <param name="ikkatuZeinukiSiwakeFlag">一括税抜仕訳フラグ</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="tokuteiSyuunyuuKamoku">特定収入科目リスト</param>
        /// <param name="syoriGroup">処理グループ</param>
        /// <returns>税区分の出力文字列</returns>
        private string GetZeiKubunString(Syouhizeiritu syouhizeiritu, bool isLatestSyouhizeirituBeforeDenpyouDate, KazeiKubun? kazeiKubun, IkkatuZeinukiSiwakeFlag ikkatuZeinukiSiwakeFlag, SiwakeTyouhyouOption siwakeTyouhyouOption, SyouhizeiMaster syouhizeiMaster, TokuteiSyuunyuuKamoku tokuteiSyuunyuuKamoku, KamokuSyoriGroup syoriGroup)
        {
            var zeiKubunString =
                string.Format(
                    "{0}{1}",
                    this.GetZeirituString(syouhizeiritu, isLatestSyouhizeirituBeforeDenpyouDate, siwakeTyouhyouOption),
                    this.GetKazeiKubunString(syouhizeiritu, kazeiKubun, ikkatuZeinukiSiwakeFlag, siwakeTyouhyouOption, syouhizeiMaster, tokuteiSyuunyuuKamoku, syoriGroup));
            return zeiKubunString != " " ? zeiKubunString : string.Empty;
        }

        /// <summary>
        /// 税率の出力文字列を取得します。
        /// </summary>
        /// <param name="syouhizeiritu">消費税率</param>
        /// <param name="isLatestSyouhizeirituBeforeDenpyouDate">伝票日付以前の最新税率かどうか</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <returns>税率の出力文字列</returns>
        private string GetZeirituString(Syouhizeiritu syouhizeiritu, bool isLatestSyouhizeirituBeforeDenpyouDate, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var zeiritu = syouhizeiritu?.Zeiritu.GetValue();
            if (zeiritu == null
                || zeiritu <= 0)
            {
                return " ";
            }

            if (syouhizeiritu.IsKeigenzeiritu)
            {
                return string.Format("*{0}", zeiritu?.ToString("#0.#"));
            }

            // すべての税率を出力するか、そうでなければ最新の税率は出力しない（軽減税率は除く）
            return siwakeTyouhyouOption.SiwakeOutputOption.ZeirituOutputType == ZeirituOutputType.OutputAllZeiritu || !isLatestSyouhizeirituBeforeDenpyouDate
                ? zeiritu?.ToString("#0.#")
                : " ";
        }

        /// <summary>
        /// 課税区分の出力文字列を取得します。
        /// </summary>
        /// <param name="syouhizeiritu">消費税率</param>
        /// <param name="kazeiKubun">課税区分</param>
        /// <param name="ikkatuZeinukiSiwakeFlag">一括税抜仕訳フラグ</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="tokuteiSyuunyuuKamoku">特定収入科目リスト</param>
        /// <param name="syoriGroup">処理グループ</param>
        /// <returns>課税区分の出力文字列</returns>
        private string GetKazeiKubunString(Syouhizeiritu syouhizeiritu, KazeiKubun? kazeiKubun, IkkatuZeinukiSiwakeFlag ikkatuZeinukiSiwakeFlag, SiwakeTyouhyouOption siwakeTyouhyouOption, SyouhizeiMaster syouhizeiMaster, TokuteiSyuunyuuKamoku tokuteiSyuunyuuKamoku, KamokuSyoriGroup syoriGroup)
        {
            if (ikkatuZeinukiSiwakeFlag == IkkatuZeinukiSiwakeFlag.TuuzyouSiwake)
            {
                //// 通常仕訳
                if (kazeiKubun == KazeiKubun.消費税設定対象外)
                {
                    return
                        syouhizeiMaster.IsTokuteiSyuunyuuTokureiKeisan
                        && tokuteiSyuunyuuKamoku != null
                        && syoriGroup == KamokuSyoriGroup.Taisyougai
                            ? tokuteiSyuunyuuKamoku.TokuteiSyuunyuuKubun.GetShortName()
                            : string.Empty;
                }
                else
                {
                    return kazeiKubun != null && (kazeiKubun != KazeiKubun.対象外 || siwakeTyouhyouOption.IsOutputTaisyougaiInKazeiKubun)
                        ? this.GetKazeiKubunNameForExport(kazeiKubun ?? default(KazeiKubun))
                        : string.Empty;
                }
            }
            else
            {
                //// 一括税抜仕訳
                return syouhizeiritu?.Zeiritu.GetValue() > 0
                    ? Resources.一括
                    : string.Empty;
            }
        }

        /// <summary>
        /// 課税区分の名称を取得します。
        /// </summary>
        /// <param name="kazeiKubun">課税区分</param>
        /// <returns>課税区分の名称</returns>
        private string GetKazeiKubunNameForExport(KazeiKubun kazeiKubun)
        {
            switch (kazeiKubun)
            {
                case KazeiKubun.非課税仕入:
                case KazeiKubun.非課税売上:
                    return kazeiKubun.ToString().Replace(Resources.税, string.Empty);

                case KazeiKubun.使途不明特定収入:
                    return Resources.不明特収;

                default:
                    return kazeiKubun.ToString().PadRight(4);
            }
        }

        /// <summary>
        /// 業種区分・仕入区分の出力文字列を取得します。
        /// </summary>
        /// <param name="gyousyuKubun">業種区分</param>
        /// <param name="siireKubun">仕入区分</param>
        /// <param name="kazeiKubun">課税区分</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>業種区分・仕入区分の出力文字列</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "条件が多いため、分割困難")]
        private string GetGyousyuKubunAndSiireKubunString(GyousyuKubun? gyousyuKubun, SiwakeSiireKubun? siireKubun, KazeiKubun? kazeiKubun, SyouhizeiMaster syouhizeiMaster)
        {
            if (syouhizeiMaster?.KazeiHousiki >= KazeiHousiki.KaniKazeiZigyouNo1
                && gyousyuKubun != null)
            {
                //// 業種区分
                if (kazeiKubun == KazeiKubun.税込
                    || kazeiKubun == KazeiKubun.税抜
                    || kazeiKubun == KazeiKubun.課込売上
                    || kazeiKubun == KazeiKubun.課抜売上)
                {
                    switch (gyousyuKubun)
                    {
                        case GyousyuKubun.FirstZigyou:
                            return Resources.一種;
                        case GyousyuKubun.SecondZigyou:
                            return Resources.二種;
                        case GyousyuKubun.ThirdZigyou:
                            return Resources.三種;
                        case GyousyuKubun.FourthZigyou:
                            return Resources.四種;
                        case GyousyuKubun.FifthZigyou:
                            return Resources.五種;
                        case GyousyuKubun.SixthZigyou:
                            return Resources.六種;
                    }
                }
            }
            else if (syouhizeiMaster?.KazeiHousiki == KazeiHousiki.TuuzyouKazei
                     && syouhizeiMaster?.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou
                     && siireKubun != null)
            {
                //// 仕入区分
                if (kazeiKubun == KazeiKubun.税込
                    || kazeiKubun == KazeiKubun.税抜
                    || kazeiKubun == KazeiKubun.課込仕入
                    || kazeiKubun == KazeiKubun.課抜仕入
                    || kazeiKubun == KazeiKubun.課税貨物)
                {
                    switch (siireKubun)
                    {
                        case SiwakeSiireKubun.KazeiUriage:
                            return Resources.課売;
                        case SiwakeSiireKubun.HikazeiUriage:
                            return Resources.非売;
                        case SiwakeSiireKubun.KyoutuuUriage:
                            return Resources.共売;
                    }
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// 外貨金額の出力文字列を取得します。
        /// </summary>
        /// <param name="gaikaKingaku">外貨金額</param>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <returns>外貨金額の出力文字列</returns>
        private string GetGaikaKingakuString(decimal gaikaKingaku, ITanituSiwakeTyouhyouRow row, bool gaikaItemEnabled)
        {
            if (gaikaItemEnabled)
            {
                if (!string.IsNullOrEmpty(row.KarikataDetail.HeisyuCode))
                {
                    return row.KarikataDetail.HeisyuDecimalPartKetaCount != null
                        ? gaikaKingaku.ToString(string.Format("F{0}", row.KarikataDetail.HeisyuDecimalPartKetaCount))
                        : gaikaKingaku.ToString("#0.####");
                }
                else if (!string.IsNullOrEmpty(row.KasikataDetail.HeisyuCode))
                {
                    return row.KasikataDetail.HeisyuDecimalPartKetaCount != null
                        ? gaikaKingaku.ToString(string.Format("F{0}", row.KasikataDetail.HeisyuDecimalPartKetaCount))
                        : gaikaKingaku.ToString("#0.####");
                }
            }

            return string.Empty;
        }

        #endregion
    }
}
