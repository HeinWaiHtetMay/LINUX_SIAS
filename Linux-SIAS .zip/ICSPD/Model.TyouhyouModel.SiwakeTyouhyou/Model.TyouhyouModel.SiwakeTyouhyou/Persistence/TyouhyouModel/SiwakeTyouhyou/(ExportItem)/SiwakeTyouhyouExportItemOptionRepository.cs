﻿namespace Icsp.Open21.Model.TyouhyouModel.SiwakeTyouhyou.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouExportItemOptionRepository : ISiwakeTyouhyouExportItemOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        /// <summary>
        /// エクスポート項目ID
        /// </summary>
        private enum SiwakeTyouhyouExportItemId
        {
            /// <summary>
            /// 経過月
            /// </summary>
            Dkei = 1,

            /// <summary>
            /// 仕訳SEQ
            /// </summary>
            Sseq = 2,

            /// <summary>
            /// 伝票日付
            /// </summary>
            DenpyouDate = 3,

            /// <summary>
            /// 伝票番号
            /// </summary>
            DenpyouNo = 4,

            /// <summary>
            /// 受付番号
            /// </summary>
            UketukeNo = 5,

            /// <summary>
            /// 借方部門コード
            /// </summary>
            KarikataBcod = 10,

            /// <summary>
            /// 借方部門名称
            /// </summary>
            KarikataBumonName = 11,

            /// <summary>
            /// 借方取引先コード
            /// </summary>
            KarikataTrcd = 12,

            /// <summary>
            /// 借方取引先名称
            /// </summary>
            KarikataTorihikisakiName = 13,

            /// <summary>
            /// 借方科目コード
            /// </summary>
            KarikataKcod = 14,

            /// <summary>
            /// 借方科目名称
            /// </summary>
            KarikataKamokuName = 15,

            /// <summary>
            /// 借方枝番コード
            /// </summary>
            KarikataEcod = 16,

            /// <summary>
            /// 借方枝番名称
            /// </summary>
            KarikataEdabanName = 17,

            /// <summary>
            /// 借方工事コード
            /// </summary>
            KarikataKzcd = 18,

            /// <summary>
            /// 借方工事名称
            /// </summary>
            KarikataKouziName = 19,

            /// <summary>
            /// 借方工種コード
            /// </summary>
            KarikataKscd = 20,

            /// <summary>
            /// 借方工種名称
            /// </summary>
            KarikataKousyuName = 21,

            /// <summary>
            /// 借方プロジェクトコード
            /// </summary>
            KarikataPjcd = 22,

            /// <summary>
            /// 借方プロジェクト名称
            /// </summary>
            KarikataProjectName = 23,

            /// <summary>
            /// 借方セグメントコード
            /// </summary>
            KarikataSgcd = 24,

            /// <summary>
            /// 借方セグメント名称
            /// </summary>
            KarikataSegmentName = 25,

            /// <summary>
            /// 借方ユニバーサルフィールド１コード
            /// </summary>
            KarikataUfcd01 = 26,

            /// <summary>
            /// 借方ユニバーサルフィールド１名称
            /// </summary>
            KarikataUniversalField01Name = 27,

            /// <summary>
            /// 借方ユニバーサルフィールド２コード
            /// </summary>
            KarikataUfcd02 = 28,

            /// <summary>
            /// 借方ユニバーサルフィールド２名称
            /// </summary>
            KarikataUniversalField02Name = 29,

            /// <summary>
            /// 借方ユニバーサルフィールド３コード
            /// </summary>
            KarikataUfcd03 = 30,

            /// <summary>
            /// 借方ユニバーサルフィールド３名称
            /// </summary>
            KarikataUniversalField03Name = 31,

            /// <summary>
            /// 借方税区分
            /// </summary>
            KarikataZeiKubun = 32,

            /// <summary>
            /// 借方仕入・業種区分
            /// </summary>
            KarikataSiireAndGyousyuKubun = 33,

            /// <summary>
            /// 借方幣種
            /// </summary>
            KarikataHeisyu = 34,

            /// <summary>
            /// 貸方部門コード
            /// </summary>
            KasikataBcod = 40,

            /// <summary>
            /// 貸方部門名称
            /// </summary>
            KasikataBumonName = 41,

            /// <summary>
            /// 貸方取引先コード
            /// </summary>
            KasikataTrcd = 42,

            /// <summary>
            /// 貸方取引先名称
            /// </summary>
            KasikataTorihikisakiName = 43,

            /// <summary>
            /// 貸方科目コード
            /// </summary>
            KasikataKcod = 44,

            /// <summary>
            /// 貸方科目名称
            /// </summary>
            KasikataKamokuName = 45,

            /// <summary>
            /// 貸方枝番コード
            /// </summary>
            KasikataEcod = 46,

            /// <summary>
            /// 貸方枝番名称
            /// </summary>
            KasikataEdabanName = 47,

            /// <summary>
            /// 貸方工事コード
            /// </summary>
            KasikataKzcd = 48,

            /// <summary>
            /// 貸方工事名称
            /// </summary>
            KasikataKouziName = 49,

            /// <summary>
            /// 貸方工種コード
            /// </summary>
            KasikataKscd = 50,

            /// <summary>
            /// 貸方工種名称
            /// </summary>
            KasikataKousyuName = 51,

            /// <summary>
            /// 貸方プロジェクトコード
            /// </summary>
            KasikataPjcd = 52,

            /// <summary>
            /// 貸方プロジェクト名称
            /// </summary>
            KasikataProjectName = 53,

            /// <summary>
            /// 貸方セグメントコード
            /// </summary>
            KasikataSgcd = 54,

            /// <summary>
            /// 貸方セグメント名称
            /// </summary>
            KasikataSegmentName = 55,

            /// <summary>
            /// 貸方ユニバーサルフィールド１コード
            /// </summary>
            KasikataUfcd01 = 56,

            /// <summary>
            /// 貸方ユニバーサルフィールド１名称
            /// </summary>
            KasikataUniversalField01Name = 57,

            /// <summary>
            /// 貸方ユニバーサルフィールド２コード
            /// </summary>
            KasikataUfcd02 = 58,

            /// <summary>
            /// 貸方ユニバーサルフィールド２名称
            /// </summary>
            KasikataUniversalField02Name = 59,

            /// <summary>
            /// 貸方ユニバーサルフィールド３コード
            /// </summary>
            KasikataUfcd03 = 60,

            /// <summary>
            /// 貸方ユニバーサルフィールド３名称
            /// </summary>
            KasikataUniversalField03Name = 61,

            /// <summary>
            /// 貸方税区分
            /// </summary>
            KasikataZeiKubun = 62,

            /// <summary>
            /// 貸方仕入・業種区分
            /// </summary>
            KasikataSiireAndGyousyuKubun = 63,

            /// <summary>
            /// 貸方幣種
            /// </summary>
            KasikataHeisyu = 64,

            /// <summary>
            /// 金額
            /// </summary>
            Kingaku = 72,

            /// <summary>
            /// 対価金額
            /// </summary>
            TaikaKingaku = 73,

            /// <summary>
            /// 税込金額
            /// </summary>
            ZeikomiKingaku = 74,

            /// <summary>
            /// 消費税対象科目コード
            /// </summary>
            SyouhizeiTaisyouKcod = 75,

            /// <summary>
            /// 消費税対象科目名称
            /// </summary>
            SyouhizeiTaisyouKamokuName = 76,

            /// <summary>
            /// 消費税対象科目税区分
            /// </summary>
            SyouhizeiTaisyouKamokuZeiKubun = 77,

            /// <summary>
            /// 消費税対象科目仕入・業種区分
            /// </summary>
            SyouhizeiTaisyouKamokuSiireAndGyousyuKubun = 78,

            /// <summary>
            /// 起票日
            /// </summary>
            KihyouDate = 79,

            /// <summary>
            /// 起票部門コード
            /// </summary>
            KihyouBumonCode = 80,

            /// <summary>
            /// 起票部門名称
            /// </summary>
            KihyouBumonName = 81,

            /// <summary>
            /// 起票者コード
            /// </summary>
            KihyouTantousyaCode = 82,

            /// <summary>
            /// 起票者名
            /// </summary>
            KihyouTantousyaName = 83,

            /// <summary>
            /// 仕訳作成日
            /// </summary>
            SiwakeCreateDate = 84,

            /// <summary>
            /// 仕訳作成者コード
            /// </summary>
            SiwakeCreateUserCode = 85,

            /// <summary>
            /// 仕訳作成者名
            /// </summary>
            SiwakeCreateUserName = 86,

            /// <summary>
            /// 仕訳更新日
            /// </summary>
            SiwakeUpdateDate = 87,

            /// <summary>
            /// 仕訳更新者コード
            /// </summary>
            SiwakeUpdateUserCode = 88,

            /// <summary>
            /// 仕訳更新者名
            /// </summary>
            SiwakeUpdateUserName = 89,

            /// <summary>
            /// 消込コード
            /// </summary>
            KesikomiCode = 91,

            /// <summary>
            /// 支払日
            /// </summary>
            SiharaiDate = 92,

            /// <summary>
            /// 支払区分
            /// </summary>
            SiharaiKubun = 93,

            /// <summary>
            /// 支払期日
            /// </summary>
            SiharaiKizitu = 94,

            /// <summary>
            /// 回収日
            /// </summary>
            KaisyuuDate = 95,

            /// <summary>
            /// 入金区分
            /// </summary>
            NyuukinKubun = 96,

            /// <summary>
            /// 回収期日
            /// </summary>
            KaisyuuKizitu = 97,

            /// <summary>
            /// 外貨金額
            /// </summary>
            GaikaKingaku = 98,

            /// <summary>
            /// 外貨対価金額
            /// </summary>
            GaikaTaikaKingaku = 99,

            /// <summary>
            /// 外貨税込金額
            /// </summary>
            GaikaZeikomiKingaku = 100,

            /// <summary>
            /// レート
            /// </summary>
            Rate = 101,

            /// <summary>
            /// 伝票SEQ
            /// </summary>
            Dseq = 201,

            /// <summary>
            /// 伝票作成日
            /// </summary>
            DenpyouCreateDate = 202,

            /// <summary>
            /// 伝票作成者コード
            /// </summary>
            DenpyouCreateUserCode = 203,

            /// <summary>
            /// 伝票作成者名
            /// </summary>
            DenpyouCreateUserName = 204,

            /// <summary>
            /// 伝票更新日
            /// </summary>
            DenpyouUpdateDate = 205,

            /// <summary>
            /// 伝票更新者コード
            /// </summary>
            DenpyouUpdateUserCode = 206,

            /// <summary>
            /// 伝票更新者名
            /// </summary>
            DenpyouUpdateUserName = 207,

            /// <summary>
            /// ヘッダーフィールド１コード
            /// </summary>
            Hfcd01 = 208,

            /// <summary>
            /// ヘッダーフィールド１名称
            /// </summary>
            HeaderField01Name = 209,

            /// <summary>
            /// ヘッダーフィールド２コード
            /// </summary>
            Hfcd02 = 210,

            /// <summary>
            /// ヘッダーフィールド２名称
            /// </summary>
            HeaderField02Name = 211,

            /// <summary>
            /// ヘッダーフィールド３コード
            /// </summary>
            Hfcd03 = 212,

            /// <summary>
            /// ヘッダーフィールド３名称
            /// </summary>
            HeaderField03Name = 213,

            /// <summary>
            /// ヘッダーフィールド４コード
            /// </summary>
            Hfcd04 = 214,

            /// <summary>
            /// ヘッダーフィールド４名称
            /// </summary>
            HeaderField04Name = 215,

            /// <summary>
            /// ヘッダーフィールド５コード
            /// </summary>
            Hfcd05 = 216,

            /// <summary>
            /// ヘッダーフィールド５名称
            /// </summary>
            HeaderField05Name = 217,

            /// <summary>
            /// ヘッダーフィールド６コード
            /// </summary>
            Hfcd06 = 218,

            /// <summary>
            /// ヘッダーフィールド６名称
            /// </summary>
            HeaderField06Name = 219,

            /// <summary>
            /// ヘッダーフィールド７コード
            /// </summary>
            Hfcd07 = 220,

            /// <summary>
            /// ヘッダーフィールド７名称
            /// </summary>
            HeaderField07Name = 221,

            /// <summary>
            /// ヘッダーフィールド８コード
            /// </summary>
            Hfcd08 = 222,

            /// <summary>
            /// ヘッダーフィールド８名称
            /// </summary>
            HeaderField08Name = 223,

            /// <summary>
            /// ヘッダーフィールド９コード
            /// </summary>
            Hfcd09 = 224,

            /// <summary>
            /// ヘッダーフィールド９名称
            /// </summary>
            HeaderField09Name = 225,

            /// <summary>
            /// ヘッダーフィールド１０コード
            /// </summary>
            Hfcd10 = 226,

            /// <summary>
            /// ヘッダーフィールド１０名称
            /// </summary>
            HeaderField10Name = 227,

            /// <summary>
            /// 借方ユニバーサルフィールド４コード
            /// </summary>
            KarikataUfcd04 = 301,

            /// <summary>
            /// 借方ユニバーサルフィールド４名称
            /// </summary>
            KarikataUniversalField04Name = 302,

            /// <summary>
            /// 借方ユニバーサルフィールド５コード
            /// </summary>
            KarikataUfcd05 = 303,

            /// <summary>
            /// 借方ユニバーサルフィールド５名称
            /// </summary>
            KarikataUniversalField05Name = 304,

            /// <summary>
            /// 借方ユニバーサルフィールド６コード
            /// </summary>
            KarikataUfcd06 = 305,

            /// <summary>
            /// 借方ユニバーサルフィールド６名称
            /// </summary>
            KarikataUniversalField06Name = 306,

            /// <summary>
            /// 借方ユニバーサルフィールド７コード
            /// </summary>
            KarikataUfcd07 = 307,

            /// <summary>
            /// 借方ユニバーサルフィールド７名称
            /// </summary>
            KarikataUniversalField07Name = 308,

            /// <summary>
            /// 借方ユニバーサルフィールド８コード
            /// </summary>
            KarikataUfcd08 = 309,

            /// <summary>
            /// 借方ユニバーサルフィールド８名称
            /// </summary>
            KarikataUniversalField08Name = 310,

            /// <summary>
            /// 借方ユニバーサルフィールド９コード
            /// </summary>
            KarikataUfcd09 = 311,

            /// <summary>
            /// 借方ユニバーサルフィールド９名称
            /// </summary>
            KarikataUniversalField09Name = 312,

            /// <summary>
            /// 借方ユニバーサルフィールド１０コード
            /// </summary>
            KarikataUfcd10 = 313,

            /// <summary>
            /// 借方ユニバーサルフィールド１０名称
            /// </summary>
            KarikataUniversalField10Name = 314,

            /// <summary>
            /// 借方ユニバーサルフィールド１１コード
            /// </summary>
            KarikataUfcd11 = 315,

            /// <summary>
            /// 借方ユニバーサルフィールド１１名称
            /// </summary>
            KarikataUniversalField11Name = 316,

            /// <summary>
            /// 借方ユニバーサルフィールド１２コード
            /// </summary>
            KarikataUfcd12 = 317,

            /// <summary>
            /// 借方ユニバーサルフィールド１２名称
            /// </summary>
            KarikataUniversalField12Name = 318,

            /// <summary>
            /// 借方ユニバーサルフィールド１３コード
            /// </summary>
            KarikataUfcd13 = 319,

            /// <summary>
            /// 借方ユニバーサルフィールド１３名称
            /// </summary>
            KarikataUniversalField13Name = 320,

            /// <summary>
            /// 借方ユニバーサルフィールド１４コード
            /// </summary>
            KarikataUfcd14 = 321,

            /// <summary>
            /// 借方ユニバーサルフィールド１４名称
            /// </summary>
            KarikataUniversalField14Name = 322,

            /// <summary>
            /// 借方ユニバーサルフィールド１５コード
            /// </summary>
            KarikataUfcd15 = 323,

            /// <summary>
            /// 借方ユニバーサルフィールド１５名称
            /// </summary>
            KarikataUniversalField15Name = 324,

            /// <summary>
            /// 借方ユニバーサルフィールド１６コード
            /// </summary>
            KarikataUfcd16 = 325,

            /// <summary>
            /// 借方ユニバーサルフィールド１６名称
            /// </summary>
            KarikataUniversalField16Name = 326,

            /// <summary>
            /// 借方ユニバーサルフィールド１７コード
            /// </summary>
            KarikataUfcd17 = 327,

            /// <summary>
            /// 借方ユニバーサルフィールド１７名称
            /// </summary>
            KarikataUniversalField17Name = 328,

            /// <summary>
            /// 借方ユニバーサルフィールド１８コード
            /// </summary>
            KarikataUfcd18 = 329,

            /// <summary>
            /// 借方ユニバーサルフィールド１８名称
            /// </summary>
            KarikataUniversalField18Name = 330,

            /// <summary>
            /// 借方ユニバーサルフィールド１９コード
            /// </summary>
            KarikataUfcd19 = 331,

            /// <summary>
            /// 借方ユニバーサルフィールド１９名称
            /// </summary>
            KarikataUniversalField19Name = 332,

            /// <summary>
            /// 借方ユニバーサルフィールド２０コード
            /// </summary>
            KarikataUfcd20 = 333,

            /// <summary>
            /// 借方ユニバーサルフィールド２０名称
            /// </summary>
            KarikataUniversalField20Name = 334,

            /// <summary>
            /// 借方摘要
            /// </summary>
            KarikataTekiyou = 335,

            /// <summary>
            /// 借方摘要コード
            /// </summary>
            KarikataTekiyouCode = 336,

            /// <summary>
            /// 借方摘要名称
            /// </summary>
            KarikataTekiyouName = 337,

            /// <summary>
            /// 貸方ユニバーサルフィールド４コード
            /// </summary>
            KasikataUfcd04 = 401,

            /// <summary>
            /// 貸方ユニバーサルフィールド４名称
            /// </summary>
            KasikataUniversalField04Name = 402,

            /// <summary>
            /// 貸方ユニバーサルフィールド５コード
            /// </summary>
            KasikataUfcd05 = 403,

            /// <summary>
            /// 貸方ユニバーサルフィールド５名称
            /// </summary>
            KasikataUniversalField05Name = 404,

            /// <summary>
            /// 貸方ユニバーサルフィールド６コード
            /// </summary>
            KasikataUfcd06 = 405,

            /// <summary>
            /// 貸方ユニバーサルフィールド６名称
            /// </summary>
            KasikataUniversalField06Name = 406,

            /// <summary>
            /// 貸方ユニバーサルフィールド７コード
            /// </summary>
            KasikataUfcd07 = 407,

            /// <summary>
            /// 貸方ユニバーサルフィールド７名称
            /// </summary>
            KasikataUniversalField07Name = 408,

            /// <summary>
            /// 貸方ユニバーサルフィールド８コード
            /// </summary>
            KasikataUfcd08 = 409,

            /// <summary>
            /// 貸方ユニバーサルフィールド８名称
            /// </summary>
            KasikataUniversalField08Name = 410,

            /// <summary>
            /// 貸方ユニバーサルフィールド９コード
            /// </summary>
            KasikataUfcd09 = 411,

            /// <summary>
            /// 貸方ユニバーサルフィールド９名称
            /// </summary>
            KasikataUniversalField09Name = 412,

            /// <summary>
            /// 貸方ユニバーサルフィールド１０コード
            /// </summary>
            KasikataUfcd10 = 413,

            /// <summary>
            /// 貸方ユニバーサルフィールド１０名称
            /// </summary>
            KasikataUniversalField10Name = 414,

            /// <summary>
            /// 貸方ユニバーサルフィールド１１コード
            /// </summary>
            KasikataUfcd11 = 415,

            /// <summary>
            /// 貸方ユニバーサルフィールド１１名称
            /// </summary>
            KasikataUniversalField11Name = 416,

            /// <summary>
            /// 貸方ユニバーサルフィールド１２コード
            /// </summary>
            KasikataUfcd12 = 417,

            /// <summary>
            /// 貸方ユニバーサルフィールド１２名称
            /// </summary>
            KasikataUniversalField12Name = 418,

            /// <summary>
            /// 貸方ユニバーサルフィールド１３コード
            /// </summary>
            KasikataUfcd13 = 419,

            /// <summary>
            /// 貸方ユニバーサルフィールド１３名称
            /// </summary>
            KasikataUniversalField13Name = 420,

            /// <summary>
            /// 貸方ユニバーサルフィールド１４コード
            /// </summary>
            KasikataUfcd14 = 421,

            /// <summary>
            /// 貸方ユニバーサルフィールド１４名称
            /// </summary>
            KasikataUniversalField14Name = 422,

            /// <summary>
            /// 貸方ユニバーサルフィールド１５コード
            /// </summary>
            KasikataUfcd15 = 423,

            /// <summary>
            /// 貸方ユニバーサルフィールド１５名称
            /// </summary>
            KasikataUniversalField15Name = 424,

            /// <summary>
            /// 貸方ユニバーサルフィールド１６コード
            /// </summary>
            KasikataUfcd16 = 425,

            /// <summary>
            /// 貸方ユニバーサルフィールド１６名称
            /// </summary>
            KasikataUniversalField16Name = 426,

            /// <summary>
            /// 貸方ユニバーサルフィールド１７コード
            /// </summary>
            KasikataUfcd17 = 427,

            /// <summary>
            /// 貸方ユニバーサルフィールド１７名称
            /// </summary>
            KasikataUniversalField17Name = 428,

            /// <summary>
            /// 貸方ユニバーサルフィールド１８コード
            /// </summary>
            KasikataUfcd18 = 429,

            /// <summary>
            /// 貸方ユニバーサルフィールド１８名称
            /// </summary>
            KasikataUniversalField18Name = 430,

            /// <summary>
            /// 貸方ユニバーサルフィールド１９コード
            /// </summary>
            KasikataUfcd19 = 431,

            /// <summary>
            /// 貸方ユニバーサルフィールド１９名称
            /// </summary>
            KasikataUniversalField19Name = 432,

            /// <summary>
            /// 貸方ユニバーサルフィールド２０コード
            /// </summary>
            KasikataUfcd20 = 433,

            /// <summary>
            /// 貸方ユニバーサルフィールド２０名称
            /// </summary>
            KasikataUniversalField20Name = 434,

            /// <summary>
            /// 貸方摘要
            /// </summary>
            KasikataTekiyou = 435,

            /// <summary>
            /// 貸方摘要コード
            /// </summary>
            KasikataTekiyouCode = 436,

            /// <summary>
            /// 貸方摘要名称
            /// </summary>
            KasikataTekiyouName = 437,

            /// <summary>
            /// 会社コード
            /// </summary>
            Ccod = 901
        }

        #region public methods

        /// <summary>
        /// プログラムIDとユーザーNoを条件として、エクスポート項目オプションを取得します。
        /// </summary>
        /// <param name="prgid">プログラムID</param>
        /// <param name="usno">ユーザーNo</param>
        /// <returns>エクスポート項目オプション</returns>
        public virtual SiwakeTyouhyouExportItemOption FindByUserCodeAndProgramId(string prgid, int usno)
        {
            var exportItemOption = new SiwakeTyouhyouExportItemOption();
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, prgid, usno, "EXPORT").OrderBy(option => option.Keyno);

            foreach (var option in optionList)
            {
                if (option.Keynm2 == "HEADER")
                {
                    //// ヘッダーに出力する項目
                    switch (option.Keyno)
                    {
                        //// タイトル名
                        case 0:
                            exportItemOption.IsExportTitleName = option.Idata == 1;
                            break;

                        //// 会社名
                        case 1:
                            exportItemOption.IsExportCompanyName = option.Idata == 1;
                            break;

                        //// 処理期間
                        case 2:
                            exportItemOption.IsExportSyoriKikan = option.Idata == 1;
                            break;

                        //// 項目タイトル
                        case 3:
                            exportItemOption.IsExportItemTitle = option.Idata == 1;
                            break;
                    }
                }
                else if (option.Keynm2 == "ITEM")
                {
                    //// エクスポートする項目
                    exportItemOption.ExportItemSet.Add(this.ConvertExportItemIdToExportItemDisplayOrder((SiwakeTyouhyouExportItemId)option.Idata));
                }
            }

            if (exportItemOption.ExportItemSet.Count == 0)
            {
                //// データが存在しない場合、デフォルト値をセット

                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.Sseq);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.DenpyouDate);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.DenpyouNo);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.UketukeNo);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KarikataBcod);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KarikataTrcd);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KarikataKamokuName);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KarikataEcod);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KarikataZeiKubun);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KasikataBcod);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KasikataTrcd);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KasikataKamokuName);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KasikataEcod);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.KasikataZeiKubun);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.Kingaku);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.TaikaKingaku);
                exportItemOption.ExportItemSet.Add(SiwakeTyouhyouExportItem.ZeikomiKingaku);
            }

            return exportItemOption;
        }

        /// <summary>
        /// エクスポート項目を保存します。
        /// </summary>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="usno">ユーザーコード</param>
        public virtual void Store(SiwakeTyouhyouExportItemOption exportItemOption, int usno)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, "DSCAN", usno, "EXPORT", "HEADER");
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, "DSCAN", usno, "EXPORT", "ITEM");

            //// エクスポート項目
            for (int i = 0; i < exportItemOption.ExportItemSet.Count; i++)
            {
                this.option1Dao.Insert(DatabaseType.KaisyaDb, new Option1Dto().SetValues("DSCAN", usno, "EXPORT", "ITEM", (short)i, (int)this.ConvertExportItemDisplayOrderToExportItemId(exportItemOption.ExportItemSet.Skip(i).First())));
            }

            //// ヘッダー項目
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues("DSCAN", usno, "EXPORT", "HEADER", 0, exportItemOption.IsExportTitleName),
                new Option1Dto().SetValues("DSCAN", usno, "EXPORT", "HEADER", 1, exportItemOption.IsExportCompanyName),
                new Option1Dto().SetValues("DSCAN", usno, "EXPORT", "HEADER", 2, exportItemOption.IsExportSyoriKikan),
                new Option1Dto().SetValues("DSCAN", usno, "EXPORT", "HEADER", 3, exportItemOption.IsExportItemTitle),
            }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        #endregion

        #region private methods

        /// <summary>
        /// エクスポート項目ID→エクスポート項目表示順に変換します。
        /// </summary>
        /// <param name="exportItemId">エクスポート項目ID</param>
        /// <returns>エクスポート項目表示順</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多く省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目が多く省略不可")]
        private SiwakeTyouhyouExportItem ConvertExportItemIdToExportItemDisplayOrder(SiwakeTyouhyouExportItemId exportItemId)
        {
            switch (exportItemId)
            {
                case SiwakeTyouhyouExportItemId.Dkei:
                    return SiwakeTyouhyouExportItem.Dkei;
                case SiwakeTyouhyouExportItemId.Sseq:
                    return SiwakeTyouhyouExportItem.Sseq;
                case SiwakeTyouhyouExportItemId.DenpyouDate:
                    return SiwakeTyouhyouExportItem.DenpyouDate;
                case SiwakeTyouhyouExportItemId.DenpyouNo:
                    return SiwakeTyouhyouExportItem.DenpyouNo;
                case SiwakeTyouhyouExportItemId.UketukeNo:
                    return SiwakeTyouhyouExportItem.UketukeNo;
                case SiwakeTyouhyouExportItemId.KarikataBcod:
                    return SiwakeTyouhyouExportItem.KarikataBcod;
                case SiwakeTyouhyouExportItemId.KarikataBumonName:
                    return SiwakeTyouhyouExportItem.KarikataBumonName;
                case SiwakeTyouhyouExportItemId.KarikataTrcd:
                    return SiwakeTyouhyouExportItem.KarikataTrcd;
                case SiwakeTyouhyouExportItemId.KarikataTorihikisakiName:
                    return SiwakeTyouhyouExportItem.KarikataTorihikisakiName;
                case SiwakeTyouhyouExportItemId.KarikataKcod:
                    return SiwakeTyouhyouExportItem.KarikataKcod;
                case SiwakeTyouhyouExportItemId.KarikataKamokuName:
                    return SiwakeTyouhyouExportItem.KarikataKamokuName;
                case SiwakeTyouhyouExportItemId.KarikataEcod:
                    return SiwakeTyouhyouExportItem.KarikataEcod;
                case SiwakeTyouhyouExportItemId.KarikataEdabanName:
                    return SiwakeTyouhyouExportItem.KarikataEdabanName;
                case SiwakeTyouhyouExportItemId.KarikataKzcd:
                    return SiwakeTyouhyouExportItem.KarikataKzcd;
                case SiwakeTyouhyouExportItemId.KarikataKouziName:
                    return SiwakeTyouhyouExportItem.KarikataKouziName;
                case SiwakeTyouhyouExportItemId.KarikataKscd:
                    return SiwakeTyouhyouExportItem.KarikataKscd;
                case SiwakeTyouhyouExportItemId.KarikataKousyuName:
                    return SiwakeTyouhyouExportItem.KarikataKousyuName;
                case SiwakeTyouhyouExportItemId.KarikataPjcd:
                    return SiwakeTyouhyouExportItem.KarikataPjcd;
                case SiwakeTyouhyouExportItemId.KarikataProjectName:
                    return SiwakeTyouhyouExportItem.KarikataProjectName;
                case SiwakeTyouhyouExportItemId.KarikataSgcd:
                    return SiwakeTyouhyouExportItem.KarikataSgcd;
                case SiwakeTyouhyouExportItemId.KarikataSegmentName:
                    return SiwakeTyouhyouExportItem.KarikataSegmentName;
                case SiwakeTyouhyouExportItemId.KarikataUfcd01:
                    return SiwakeTyouhyouExportItem.KarikataUfcd01;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField01Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField01Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd02:
                    return SiwakeTyouhyouExportItem.KarikataUfcd02;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField02Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField02Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd03:
                    return SiwakeTyouhyouExportItem.KarikataUfcd03;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField03Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField03Name;
                case SiwakeTyouhyouExportItemId.KarikataZeiKubun:
                    return SiwakeTyouhyouExportItem.KarikataZeiKubun;
                case SiwakeTyouhyouExportItemId.KarikataSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItemId.KarikataHeisyu:
                    return SiwakeTyouhyouExportItem.KarikataHeisyu;
                case SiwakeTyouhyouExportItemId.KasikataBcod:
                    return SiwakeTyouhyouExportItem.KasikataBcod;
                case SiwakeTyouhyouExportItemId.KasikataBumonName:
                    return SiwakeTyouhyouExportItem.KasikataBumonName;
                case SiwakeTyouhyouExportItemId.KasikataTrcd:
                    return SiwakeTyouhyouExportItem.KasikataTrcd;
                case SiwakeTyouhyouExportItemId.KasikataTorihikisakiName:
                    return SiwakeTyouhyouExportItem.KasikataTorihikisakiName;
                case SiwakeTyouhyouExportItemId.KasikataKcod:
                    return SiwakeTyouhyouExportItem.KasikataKcod;
                case SiwakeTyouhyouExportItemId.KasikataKamokuName:
                    return SiwakeTyouhyouExportItem.KasikataKamokuName;
                case SiwakeTyouhyouExportItemId.KasikataEcod:
                    return SiwakeTyouhyouExportItem.KasikataEcod;
                case SiwakeTyouhyouExportItemId.KasikataEdabanName:
                    return SiwakeTyouhyouExportItem.KasikataEdabanName;
                case SiwakeTyouhyouExportItemId.KasikataKzcd:
                    return SiwakeTyouhyouExportItem.KasikataKzcd;
                case SiwakeTyouhyouExportItemId.KasikataKouziName:
                    return SiwakeTyouhyouExportItem.KasikataKouziName;
                case SiwakeTyouhyouExportItemId.KasikataKscd:
                    return SiwakeTyouhyouExportItem.KasikataKscd;
                case SiwakeTyouhyouExportItemId.KasikataKousyuName:
                    return SiwakeTyouhyouExportItem.KasikataKousyuName;
                case SiwakeTyouhyouExportItemId.KasikataPjcd:
                    return SiwakeTyouhyouExportItem.KasikataPjcd;
                case SiwakeTyouhyouExportItemId.KasikataProjectName:
                    return SiwakeTyouhyouExportItem.KasikataProjectName;
                case SiwakeTyouhyouExportItemId.KasikataSgcd:
                    return SiwakeTyouhyouExportItem.KasikataSgcd;
                case SiwakeTyouhyouExportItemId.KasikataSegmentName:
                    return SiwakeTyouhyouExportItem.KasikataSegmentName;
                case SiwakeTyouhyouExportItemId.KasikataUfcd01:
                    return SiwakeTyouhyouExportItem.KasikataUfcd01;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField01Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField01Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd02:
                    return SiwakeTyouhyouExportItem.KasikataUfcd02;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField02Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField02Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd03:
                    return SiwakeTyouhyouExportItem.KasikataUfcd03;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField03Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField03Name;
                case SiwakeTyouhyouExportItemId.KasikataZeiKubun:
                    return SiwakeTyouhyouExportItem.KasikataZeiKubun;
                case SiwakeTyouhyouExportItemId.KasikataSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItemId.KasikataHeisyu:
                    return SiwakeTyouhyouExportItem.KasikataHeisyu;
                case SiwakeTyouhyouExportItemId.Kingaku:
                    return SiwakeTyouhyouExportItem.Kingaku;
                case SiwakeTyouhyouExportItemId.TaikaKingaku:
                    return SiwakeTyouhyouExportItem.TaikaKingaku;
                case SiwakeTyouhyouExportItemId.ZeikomiKingaku:
                    return SiwakeTyouhyouExportItem.ZeikomiKingaku;
                case SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKcod:
                    return SiwakeTyouhyouExportItem.SyouhizeiTaisyouKcod;
                case SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuName:
                    return SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuName;
                case SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuZeiKubun:
                    return SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuZeiKubun;
                case SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItemId.KihyouDate:
                    return SiwakeTyouhyouExportItem.KihyouDate;
                case SiwakeTyouhyouExportItemId.KihyouBumonCode:
                    return SiwakeTyouhyouExportItem.KihyouBumonCode;
                case SiwakeTyouhyouExportItemId.KihyouBumonName:
                    return SiwakeTyouhyouExportItem.KihyouBumonName;
                case SiwakeTyouhyouExportItemId.KihyouTantousyaCode:
                    return SiwakeTyouhyouExportItem.KihyouTantousyaCode;
                case SiwakeTyouhyouExportItemId.KihyouTantousyaName:
                    return SiwakeTyouhyouExportItem.KihyouTantousyaName;
                case SiwakeTyouhyouExportItemId.SiwakeCreateDate:
                    return SiwakeTyouhyouExportItem.SiwakeCreateDate;
                case SiwakeTyouhyouExportItemId.SiwakeCreateUserCode:
                    return SiwakeTyouhyouExportItem.SiwakeCreateUserCode;
                case SiwakeTyouhyouExportItemId.SiwakeCreateUserName:
                    return SiwakeTyouhyouExportItem.SiwakeCreateUserName;
                case SiwakeTyouhyouExportItemId.SiwakeUpdateDate:
                    return SiwakeTyouhyouExportItem.SiwakeUpdateDate;
                case SiwakeTyouhyouExportItemId.SiwakeUpdateUserCode:
                    return SiwakeTyouhyouExportItem.SiwakeUpdateUserCode;
                case SiwakeTyouhyouExportItemId.SiwakeUpdateUserName:
                    return SiwakeTyouhyouExportItem.SiwakeUpdateUserName;
                case SiwakeTyouhyouExportItemId.KesikomiCode:
                    return SiwakeTyouhyouExportItem.KesikomiCode;
                case SiwakeTyouhyouExportItemId.SiharaiDate:
                    return SiwakeTyouhyouExportItem.SiharaiDate;
                case SiwakeTyouhyouExportItemId.SiharaiKubun:
                    return SiwakeTyouhyouExportItem.SiharaiKubun;
                case SiwakeTyouhyouExportItemId.SiharaiKizitu:
                    return SiwakeTyouhyouExportItem.SiharaiKizitu;
                case SiwakeTyouhyouExportItemId.KaisyuuDate:
                    return SiwakeTyouhyouExportItem.KaisyuuDate;
                case SiwakeTyouhyouExportItemId.NyuukinKubun:
                    return SiwakeTyouhyouExportItem.NyuukinKubun;
                case SiwakeTyouhyouExportItemId.KaisyuuKizitu:
                    return SiwakeTyouhyouExportItem.KaisyuuKizitu;
                case SiwakeTyouhyouExportItemId.GaikaKingaku:
                    return SiwakeTyouhyouExportItem.GaikaKingaku;
                case SiwakeTyouhyouExportItemId.GaikaTaikaKingaku:
                    return SiwakeTyouhyouExportItem.GaikaTaikaKingaku;
                case SiwakeTyouhyouExportItemId.GaikaZeikomiKingaku:
                    return SiwakeTyouhyouExportItem.GaikaZeikomiKingaku;
                case SiwakeTyouhyouExportItemId.Rate:
                    return SiwakeTyouhyouExportItem.Rate;
                case SiwakeTyouhyouExportItemId.Dseq:
                    return SiwakeTyouhyouExportItem.Dseq;
                case SiwakeTyouhyouExportItemId.DenpyouCreateDate:
                    return SiwakeTyouhyouExportItem.DenpyouCreateDate;
                case SiwakeTyouhyouExportItemId.DenpyouCreateUserCode:
                    return SiwakeTyouhyouExportItem.DenpyouCreateUserCode;
                case SiwakeTyouhyouExportItemId.DenpyouCreateUserName:
                    return SiwakeTyouhyouExportItem.DenpyouCreateUserName;
                case SiwakeTyouhyouExportItemId.DenpyouUpdateDate:
                    return SiwakeTyouhyouExportItem.DenpyouUpdateDate;
                case SiwakeTyouhyouExportItemId.DenpyouUpdateUserCode:
                    return SiwakeTyouhyouExportItem.DenpyouUpdateUserCode;
                case SiwakeTyouhyouExportItemId.DenpyouUpdateUserName:
                    return SiwakeTyouhyouExportItem.DenpyouUpdateUserName;
                case SiwakeTyouhyouExportItemId.Hfcd01:
                    return SiwakeTyouhyouExportItem.Hfcd01;
                case SiwakeTyouhyouExportItemId.HeaderField01Name:
                    return SiwakeTyouhyouExportItem.HeaderField01Name;
                case SiwakeTyouhyouExportItemId.Hfcd02:
                    return SiwakeTyouhyouExportItem.Hfcd02;
                case SiwakeTyouhyouExportItemId.HeaderField02Name:
                    return SiwakeTyouhyouExportItem.HeaderField02Name;
                case SiwakeTyouhyouExportItemId.Hfcd03:
                    return SiwakeTyouhyouExportItem.Hfcd03;
                case SiwakeTyouhyouExportItemId.HeaderField03Name:
                    return SiwakeTyouhyouExportItem.HeaderField03Name;
                case SiwakeTyouhyouExportItemId.Hfcd04:
                    return SiwakeTyouhyouExportItem.Hfcd04;
                case SiwakeTyouhyouExportItemId.HeaderField04Name:
                    return SiwakeTyouhyouExportItem.HeaderField04Name;
                case SiwakeTyouhyouExportItemId.Hfcd05:
                    return SiwakeTyouhyouExportItem.Hfcd05;
                case SiwakeTyouhyouExportItemId.HeaderField05Name:
                    return SiwakeTyouhyouExportItem.HeaderField05Name;
                case SiwakeTyouhyouExportItemId.Hfcd06:
                    return SiwakeTyouhyouExportItem.Hfcd06;
                case SiwakeTyouhyouExportItemId.HeaderField06Name:
                    return SiwakeTyouhyouExportItem.HeaderField06Name;
                case SiwakeTyouhyouExportItemId.Hfcd07:
                    return SiwakeTyouhyouExportItem.Hfcd07;
                case SiwakeTyouhyouExportItemId.HeaderField07Name:
                    return SiwakeTyouhyouExportItem.HeaderField07Name;
                case SiwakeTyouhyouExportItemId.Hfcd08:
                    return SiwakeTyouhyouExportItem.Hfcd08;
                case SiwakeTyouhyouExportItemId.HeaderField08Name:
                    return SiwakeTyouhyouExportItem.HeaderField08Name;
                case SiwakeTyouhyouExportItemId.Hfcd09:
                    return SiwakeTyouhyouExportItem.Hfcd09;
                case SiwakeTyouhyouExportItemId.HeaderField09Name:
                    return SiwakeTyouhyouExportItem.HeaderField09Name;
                case SiwakeTyouhyouExportItemId.Hfcd10:
                    return SiwakeTyouhyouExportItem.Hfcd10;
                case SiwakeTyouhyouExportItemId.HeaderField10Name:
                    return SiwakeTyouhyouExportItem.HeaderField10Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd04:
                    return SiwakeTyouhyouExportItem.KarikataUfcd04;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField04Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField04Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd05:
                    return SiwakeTyouhyouExportItem.KarikataUfcd05;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField05Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField05Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd06:
                    return SiwakeTyouhyouExportItem.KarikataUfcd06;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField06Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField06Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd07:
                    return SiwakeTyouhyouExportItem.KarikataUfcd07;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField07Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField07Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd08:
                    return SiwakeTyouhyouExportItem.KarikataUfcd08;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField08Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField08Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd09:
                    return SiwakeTyouhyouExportItem.KarikataUfcd09;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField09Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField09Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd10:
                    return SiwakeTyouhyouExportItem.KarikataUfcd10;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField10Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField10Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd11:
                    return SiwakeTyouhyouExportItem.KarikataUfcd11;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField11Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField11Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd12:
                    return SiwakeTyouhyouExportItem.KarikataUfcd12;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField12Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField12Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd13:
                    return SiwakeTyouhyouExportItem.KarikataUfcd13;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField13Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField13Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd14:
                    return SiwakeTyouhyouExportItem.KarikataUfcd14;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField14Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField14Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd15:
                    return SiwakeTyouhyouExportItem.KarikataUfcd15;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField15Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField15Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd16:
                    return SiwakeTyouhyouExportItem.KarikataUfcd16;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField16Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField16Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd17:
                    return SiwakeTyouhyouExportItem.KarikataUfcd17;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField17Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField17Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd18:
                    return SiwakeTyouhyouExportItem.KarikataUfcd18;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField18Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField18Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd19:
                    return SiwakeTyouhyouExportItem.KarikataUfcd19;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField19Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField19Name;
                case SiwakeTyouhyouExportItemId.KarikataUfcd20:
                    return SiwakeTyouhyouExportItem.KarikataUfcd20;
                case SiwakeTyouhyouExportItemId.KarikataUniversalField20Name:
                    return SiwakeTyouhyouExportItem.KarikataUniversalField20Name;
                case SiwakeTyouhyouExportItemId.KarikataTekiyou:
                    return SiwakeTyouhyouExportItem.KarikataTekiyou;
                case SiwakeTyouhyouExportItemId.KarikataTekiyouCode:
                    return SiwakeTyouhyouExportItem.KarikataTekiyouCode;
                case SiwakeTyouhyouExportItemId.KarikataTekiyouName:
                    return SiwakeTyouhyouExportItem.KarikataTekiyouName;
                case SiwakeTyouhyouExportItemId.KasikataUfcd04:
                    return SiwakeTyouhyouExportItem.KasikataUfcd04;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField04Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField04Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd05:
                    return SiwakeTyouhyouExportItem.KasikataUfcd05;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField05Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField05Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd06:
                    return SiwakeTyouhyouExportItem.KasikataUfcd06;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField06Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField06Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd07:
                    return SiwakeTyouhyouExportItem.KasikataUfcd07;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField07Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField07Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd08:
                    return SiwakeTyouhyouExportItem.KasikataUfcd08;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField08Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField08Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd09:
                    return SiwakeTyouhyouExportItem.KasikataUfcd09;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField09Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField09Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd10:
                    return SiwakeTyouhyouExportItem.KasikataUfcd10;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField10Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField10Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd11:
                    return SiwakeTyouhyouExportItem.KasikataUfcd11;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField11Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField11Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd12:
                    return SiwakeTyouhyouExportItem.KasikataUfcd12;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField12Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField12Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd13:
                    return SiwakeTyouhyouExportItem.KasikataUfcd13;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField13Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField13Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd14:
                    return SiwakeTyouhyouExportItem.KasikataUfcd14;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField14Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField14Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd15:
                    return SiwakeTyouhyouExportItem.KasikataUfcd15;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField15Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField15Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd16:
                    return SiwakeTyouhyouExportItem.KasikataUfcd16;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField16Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField16Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd17:
                    return SiwakeTyouhyouExportItem.KasikataUfcd17;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField17Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField17Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd18:
                    return SiwakeTyouhyouExportItem.KasikataUfcd18;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField18Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField18Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd19:
                    return SiwakeTyouhyouExportItem.KasikataUfcd19;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField19Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField19Name;
                case SiwakeTyouhyouExportItemId.KasikataUfcd20:
                    return SiwakeTyouhyouExportItem.KasikataUfcd20;
                case SiwakeTyouhyouExportItemId.KasikataUniversalField20Name:
                    return SiwakeTyouhyouExportItem.KasikataUniversalField20Name;
                case SiwakeTyouhyouExportItemId.KasikataTekiyou:
                    return SiwakeTyouhyouExportItem.KasikataTekiyou;
                case SiwakeTyouhyouExportItemId.KasikataTekiyouCode:
                    return SiwakeTyouhyouExportItem.KasikataTekiyouCode;
                case SiwakeTyouhyouExportItemId.KasikataTekiyouName:
                    return SiwakeTyouhyouExportItem.KasikataTekiyouName;
                case SiwakeTyouhyouExportItemId.Ccod:
                    return SiwakeTyouhyouExportItem.Ccod;
                default:
                    return default(SiwakeTyouhyouExportItem);
            }
        }

        /// <summary>
        /// エクスポート項目表示順→エクスポート項目IDに変換します。
        /// </summary>
        /// <param name="exportItemDisplayOrder">エクスポート項目表示順</param>
        /// <returns>エクスポート項目ID</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多く省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目が多く省略不可")]
        private SiwakeTyouhyouExportItemId ConvertExportItemDisplayOrderToExportItemId(SiwakeTyouhyouExportItem exportItemDisplayOrder)
        {
            switch (exportItemDisplayOrder)
            {
                case SiwakeTyouhyouExportItem.Dkei:
                    return SiwakeTyouhyouExportItemId.Dkei;
                case SiwakeTyouhyouExportItem.Sseq:
                    return SiwakeTyouhyouExportItemId.Sseq;
                case SiwakeTyouhyouExportItem.DenpyouDate:
                    return SiwakeTyouhyouExportItemId.DenpyouDate;
                case SiwakeTyouhyouExportItem.DenpyouNo:
                    return SiwakeTyouhyouExportItemId.DenpyouNo;
                case SiwakeTyouhyouExportItem.UketukeNo:
                    return SiwakeTyouhyouExportItemId.UketukeNo;
                case SiwakeTyouhyouExportItem.KarikataBcod:
                    return SiwakeTyouhyouExportItemId.KarikataBcod;
                case SiwakeTyouhyouExportItem.KarikataBumonName:
                    return SiwakeTyouhyouExportItemId.KarikataBumonName;
                case SiwakeTyouhyouExportItem.KarikataTrcd:
                    return SiwakeTyouhyouExportItemId.KarikataTrcd;
                case SiwakeTyouhyouExportItem.KarikataTorihikisakiName:
                    return SiwakeTyouhyouExportItemId.KarikataTorihikisakiName;
                case SiwakeTyouhyouExportItem.KarikataKcod:
                    return SiwakeTyouhyouExportItemId.KarikataKcod;
                case SiwakeTyouhyouExportItem.KarikataKamokuName:
                    return SiwakeTyouhyouExportItemId.KarikataKamokuName;
                case SiwakeTyouhyouExportItem.KarikataEcod:
                    return SiwakeTyouhyouExportItemId.KarikataEcod;
                case SiwakeTyouhyouExportItem.KarikataEdabanName:
                    return SiwakeTyouhyouExportItemId.KarikataEdabanName;
                case SiwakeTyouhyouExportItem.KarikataKzcd:
                    return SiwakeTyouhyouExportItemId.KarikataKzcd;
                case SiwakeTyouhyouExportItem.KarikataKouziName:
                    return SiwakeTyouhyouExportItemId.KarikataKouziName;
                case SiwakeTyouhyouExportItem.KarikataKscd:
                    return SiwakeTyouhyouExportItemId.KarikataKscd;
                case SiwakeTyouhyouExportItem.KarikataKousyuName:
                    return SiwakeTyouhyouExportItemId.KarikataKousyuName;
                case SiwakeTyouhyouExportItem.KarikataPjcd:
                    return SiwakeTyouhyouExportItemId.KarikataPjcd;
                case SiwakeTyouhyouExportItem.KarikataProjectName:
                    return SiwakeTyouhyouExportItemId.KarikataProjectName;
                case SiwakeTyouhyouExportItem.KarikataSgcd:
                    return SiwakeTyouhyouExportItemId.KarikataSgcd;
                case SiwakeTyouhyouExportItem.KarikataSegmentName:
                    return SiwakeTyouhyouExportItemId.KarikataSegmentName;
                case SiwakeTyouhyouExportItem.KarikataUfcd01:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd01;
                case SiwakeTyouhyouExportItem.KarikataUniversalField01Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField01Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd02:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd02;
                case SiwakeTyouhyouExportItem.KarikataUniversalField02Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField02Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd03:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd03;
                case SiwakeTyouhyouExportItem.KarikataUniversalField03Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField03Name;
                case SiwakeTyouhyouExportItem.KarikataZeiKubun:
                    return SiwakeTyouhyouExportItemId.KarikataZeiKubun;
                case SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItemId.KarikataSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItem.KarikataHeisyu:
                    return SiwakeTyouhyouExportItemId.KarikataHeisyu;
                case SiwakeTyouhyouExportItem.KasikataBcod:
                    return SiwakeTyouhyouExportItemId.KasikataBcod;
                case SiwakeTyouhyouExportItem.KasikataBumonName:
                    return SiwakeTyouhyouExportItemId.KasikataBumonName;
                case SiwakeTyouhyouExportItem.KasikataTrcd:
                    return SiwakeTyouhyouExportItemId.KasikataTrcd;
                case SiwakeTyouhyouExportItem.KasikataTorihikisakiName:
                    return SiwakeTyouhyouExportItemId.KasikataTorihikisakiName;
                case SiwakeTyouhyouExportItem.KasikataKcod:
                    return SiwakeTyouhyouExportItemId.KasikataKcod;
                case SiwakeTyouhyouExportItem.KasikataKamokuName:
                    return SiwakeTyouhyouExportItemId.KasikataKamokuName;
                case SiwakeTyouhyouExportItem.KasikataEcod:
                    return SiwakeTyouhyouExportItemId.KasikataEcod;
                case SiwakeTyouhyouExportItem.KasikataEdabanName:
                    return SiwakeTyouhyouExportItemId.KasikataEdabanName;
                case SiwakeTyouhyouExportItem.KasikataKzcd:
                    return SiwakeTyouhyouExportItemId.KasikataKzcd;
                case SiwakeTyouhyouExportItem.KasikataKouziName:
                    return SiwakeTyouhyouExportItemId.KasikataKouziName;
                case SiwakeTyouhyouExportItem.KasikataKscd:
                    return SiwakeTyouhyouExportItemId.KasikataKscd;
                case SiwakeTyouhyouExportItem.KasikataKousyuName:
                    return SiwakeTyouhyouExportItemId.KasikataKousyuName;
                case SiwakeTyouhyouExportItem.KasikataPjcd:
                    return SiwakeTyouhyouExportItemId.KasikataPjcd;
                case SiwakeTyouhyouExportItem.KasikataProjectName:
                    return SiwakeTyouhyouExportItemId.KasikataProjectName;
                case SiwakeTyouhyouExportItem.KasikataSgcd:
                    return SiwakeTyouhyouExportItemId.KasikataSgcd;
                case SiwakeTyouhyouExportItem.KasikataSegmentName:
                    return SiwakeTyouhyouExportItemId.KasikataSegmentName;
                case SiwakeTyouhyouExportItem.KasikataUfcd01:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd01;
                case SiwakeTyouhyouExportItem.KasikataUniversalField01Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField01Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd02:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd02;
                case SiwakeTyouhyouExportItem.KasikataUniversalField02Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField02Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd03:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd03;
                case SiwakeTyouhyouExportItem.KasikataUniversalField03Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField03Name;
                case SiwakeTyouhyouExportItem.KasikataZeiKubun:
                    return SiwakeTyouhyouExportItemId.KasikataZeiKubun;
                case SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItemId.KasikataSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItem.KasikataHeisyu:
                    return SiwakeTyouhyouExportItemId.KasikataHeisyu;
                case SiwakeTyouhyouExportItem.Kingaku:
                    return SiwakeTyouhyouExportItemId.Kingaku;
                case SiwakeTyouhyouExportItem.TaikaKingaku:
                    return SiwakeTyouhyouExportItemId.TaikaKingaku;
                case SiwakeTyouhyouExportItem.ZeikomiKingaku:
                    return SiwakeTyouhyouExportItemId.ZeikomiKingaku;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKcod:
                    return SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKcod;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuName:
                    return SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuName;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuZeiKubun:
                    return SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuZeiKubun;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                    return SiwakeTyouhyouExportItemId.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun;
                case SiwakeTyouhyouExportItem.KihyouDate:
                    return SiwakeTyouhyouExportItemId.KihyouDate;
                case SiwakeTyouhyouExportItem.KihyouBumonCode:
                    return SiwakeTyouhyouExportItemId.KihyouBumonCode;
                case SiwakeTyouhyouExportItem.KihyouBumonName:
                    return SiwakeTyouhyouExportItemId.KihyouBumonName;
                case SiwakeTyouhyouExportItem.KihyouTantousyaCode:
                    return SiwakeTyouhyouExportItemId.KihyouTantousyaCode;
                case SiwakeTyouhyouExportItem.KihyouTantousyaName:
                    return SiwakeTyouhyouExportItemId.KihyouTantousyaName;
                case SiwakeTyouhyouExportItem.SiwakeCreateDate:
                    return SiwakeTyouhyouExportItemId.SiwakeCreateDate;
                case SiwakeTyouhyouExportItem.SiwakeCreateUserCode:
                    return SiwakeTyouhyouExportItemId.SiwakeCreateUserCode;
                case SiwakeTyouhyouExportItem.SiwakeCreateUserName:
                    return SiwakeTyouhyouExportItemId.SiwakeCreateUserName;
                case SiwakeTyouhyouExportItem.SiwakeUpdateDate:
                    return SiwakeTyouhyouExportItemId.SiwakeUpdateDate;
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserCode:
                    return SiwakeTyouhyouExportItemId.SiwakeUpdateUserCode;
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserName:
                    return SiwakeTyouhyouExportItemId.SiwakeUpdateUserName;
                case SiwakeTyouhyouExportItem.KesikomiCode:
                    return SiwakeTyouhyouExportItemId.KesikomiCode;
                case SiwakeTyouhyouExportItem.SiharaiDate:
                    return SiwakeTyouhyouExportItemId.SiharaiDate;
                case SiwakeTyouhyouExportItem.SiharaiKubun:
                    return SiwakeTyouhyouExportItemId.SiharaiKubun;
                case SiwakeTyouhyouExportItem.SiharaiKizitu:
                    return SiwakeTyouhyouExportItemId.SiharaiKizitu;
                case SiwakeTyouhyouExportItem.KaisyuuDate:
                    return SiwakeTyouhyouExportItemId.KaisyuuDate;
                case SiwakeTyouhyouExportItem.NyuukinKubun:
                    return SiwakeTyouhyouExportItemId.NyuukinKubun;
                case SiwakeTyouhyouExportItem.KaisyuuKizitu:
                    return SiwakeTyouhyouExportItemId.KaisyuuKizitu;
                case SiwakeTyouhyouExportItem.GaikaKingaku:
                    return SiwakeTyouhyouExportItemId.GaikaKingaku;
                case SiwakeTyouhyouExportItem.GaikaTaikaKingaku:
                    return SiwakeTyouhyouExportItemId.GaikaTaikaKingaku;
                case SiwakeTyouhyouExportItem.GaikaZeikomiKingaku:
                    return SiwakeTyouhyouExportItemId.GaikaZeikomiKingaku;
                case SiwakeTyouhyouExportItem.Rate:
                    return SiwakeTyouhyouExportItemId.Rate;
                case SiwakeTyouhyouExportItem.Dseq:
                    return SiwakeTyouhyouExportItemId.Dseq;
                case SiwakeTyouhyouExportItem.DenpyouCreateDate:
                    return SiwakeTyouhyouExportItemId.DenpyouCreateDate;
                case SiwakeTyouhyouExportItem.DenpyouCreateUserCode:
                    return SiwakeTyouhyouExportItemId.DenpyouCreateUserCode;
                case SiwakeTyouhyouExportItem.DenpyouCreateUserName:
                    return SiwakeTyouhyouExportItemId.DenpyouCreateUserName;
                case SiwakeTyouhyouExportItem.DenpyouUpdateDate:
                    return SiwakeTyouhyouExportItemId.DenpyouUpdateDate;
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserCode:
                    return SiwakeTyouhyouExportItemId.DenpyouUpdateUserCode;
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserName:
                    return SiwakeTyouhyouExportItemId.DenpyouUpdateUserName;
                case SiwakeTyouhyouExportItem.Hfcd01:
                    return SiwakeTyouhyouExportItemId.Hfcd01;
                case SiwakeTyouhyouExportItem.HeaderField01Name:
                    return SiwakeTyouhyouExportItemId.HeaderField01Name;
                case SiwakeTyouhyouExportItem.Hfcd02:
                    return SiwakeTyouhyouExportItemId.Hfcd02;
                case SiwakeTyouhyouExportItem.HeaderField02Name:
                    return SiwakeTyouhyouExportItemId.HeaderField02Name;
                case SiwakeTyouhyouExportItem.Hfcd03:
                    return SiwakeTyouhyouExportItemId.Hfcd03;
                case SiwakeTyouhyouExportItem.HeaderField03Name:
                    return SiwakeTyouhyouExportItemId.HeaderField03Name;
                case SiwakeTyouhyouExportItem.Hfcd04:
                    return SiwakeTyouhyouExportItemId.Hfcd04;
                case SiwakeTyouhyouExportItem.HeaderField04Name:
                    return SiwakeTyouhyouExportItemId.HeaderField04Name;
                case SiwakeTyouhyouExportItem.Hfcd05:
                    return SiwakeTyouhyouExportItemId.Hfcd05;
                case SiwakeTyouhyouExportItem.HeaderField05Name:
                    return SiwakeTyouhyouExportItemId.HeaderField05Name;
                case SiwakeTyouhyouExportItem.Hfcd06:
                    return SiwakeTyouhyouExportItemId.Hfcd06;
                case SiwakeTyouhyouExportItem.HeaderField06Name:
                    return SiwakeTyouhyouExportItemId.HeaderField06Name;
                case SiwakeTyouhyouExportItem.Hfcd07:
                    return SiwakeTyouhyouExportItemId.Hfcd07;
                case SiwakeTyouhyouExportItem.HeaderField07Name:
                    return SiwakeTyouhyouExportItemId.HeaderField07Name;
                case SiwakeTyouhyouExportItem.Hfcd08:
                    return SiwakeTyouhyouExportItemId.Hfcd08;
                case SiwakeTyouhyouExportItem.HeaderField08Name:
                    return SiwakeTyouhyouExportItemId.HeaderField08Name;
                case SiwakeTyouhyouExportItem.Hfcd09:
                    return SiwakeTyouhyouExportItemId.Hfcd09;
                case SiwakeTyouhyouExportItem.HeaderField09Name:
                    return SiwakeTyouhyouExportItemId.HeaderField09Name;
                case SiwakeTyouhyouExportItem.Hfcd10:
                    return SiwakeTyouhyouExportItemId.Hfcd10;
                case SiwakeTyouhyouExportItem.HeaderField10Name:
                    return SiwakeTyouhyouExportItemId.HeaderField10Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd04:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd04;
                case SiwakeTyouhyouExportItem.KarikataUniversalField04Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField04Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd05:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd05;
                case SiwakeTyouhyouExportItem.KarikataUniversalField05Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField05Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd06:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd06;
                case SiwakeTyouhyouExportItem.KarikataUniversalField06Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField06Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd07:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd07;
                case SiwakeTyouhyouExportItem.KarikataUniversalField07Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField07Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd08:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd08;
                case SiwakeTyouhyouExportItem.KarikataUniversalField08Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField08Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd09:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd09;
                case SiwakeTyouhyouExportItem.KarikataUniversalField09Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField09Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd10:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd10;
                case SiwakeTyouhyouExportItem.KarikataUniversalField10Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField10Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd11:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd11;
                case SiwakeTyouhyouExportItem.KarikataUniversalField11Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField11Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd12:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd12;
                case SiwakeTyouhyouExportItem.KarikataUniversalField12Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField12Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd13:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd13;
                case SiwakeTyouhyouExportItem.KarikataUniversalField13Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField13Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd14:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd14;
                case SiwakeTyouhyouExportItem.KarikataUniversalField14Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField14Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd15:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd15;
                case SiwakeTyouhyouExportItem.KarikataUniversalField15Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField15Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd16:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd16;
                case SiwakeTyouhyouExportItem.KarikataUniversalField16Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField16Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd17:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd17;
                case SiwakeTyouhyouExportItem.KarikataUniversalField17Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField17Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd18:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd18;
                case SiwakeTyouhyouExportItem.KarikataUniversalField18Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField18Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd19:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd19;
                case SiwakeTyouhyouExportItem.KarikataUniversalField19Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField19Name;
                case SiwakeTyouhyouExportItem.KarikataUfcd20:
                    return SiwakeTyouhyouExportItemId.KarikataUfcd20;
                case SiwakeTyouhyouExportItem.KarikataUniversalField20Name:
                    return SiwakeTyouhyouExportItemId.KarikataUniversalField20Name;
                case SiwakeTyouhyouExportItem.KarikataTekiyou:
                    return SiwakeTyouhyouExportItemId.KarikataTekiyou;
                case SiwakeTyouhyouExportItem.KarikataTekiyouCode:
                    return SiwakeTyouhyouExportItemId.KarikataTekiyouCode;
                case SiwakeTyouhyouExportItem.KarikataTekiyouName:
                    return SiwakeTyouhyouExportItemId.KarikataTekiyouName;
                case SiwakeTyouhyouExportItem.KasikataUfcd04:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd04;
                case SiwakeTyouhyouExportItem.KasikataUniversalField04Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField04Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd05:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd05;
                case SiwakeTyouhyouExportItem.KasikataUniversalField05Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField05Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd06:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd06;
                case SiwakeTyouhyouExportItem.KasikataUniversalField06Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField06Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd07:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd07;
                case SiwakeTyouhyouExportItem.KasikataUniversalField07Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField07Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd08:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd08;
                case SiwakeTyouhyouExportItem.KasikataUniversalField08Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField08Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd09:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd09;
                case SiwakeTyouhyouExportItem.KasikataUniversalField09Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField09Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd10:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd10;
                case SiwakeTyouhyouExportItem.KasikataUniversalField10Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField10Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd11:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd11;
                case SiwakeTyouhyouExportItem.KasikataUniversalField11Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField11Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd12:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd12;
                case SiwakeTyouhyouExportItem.KasikataUniversalField12Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField12Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd13:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd13;
                case SiwakeTyouhyouExportItem.KasikataUniversalField13Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField13Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd14:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd14;
                case SiwakeTyouhyouExportItem.KasikataUniversalField14Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField14Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd15:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd15;
                case SiwakeTyouhyouExportItem.KasikataUniversalField15Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField15Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd16:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd16;
                case SiwakeTyouhyouExportItem.KasikataUniversalField16Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField16Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd17:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd17;
                case SiwakeTyouhyouExportItem.KasikataUniversalField17Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField17Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd18:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd18;
                case SiwakeTyouhyouExportItem.KasikataUniversalField18Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField18Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd19:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd19;
                case SiwakeTyouhyouExportItem.KasikataUniversalField19Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField19Name;
                case SiwakeTyouhyouExportItem.KasikataUfcd20:
                    return SiwakeTyouhyouExportItemId.KasikataUfcd20;
                case SiwakeTyouhyouExportItem.KasikataUniversalField20Name:
                    return SiwakeTyouhyouExportItemId.KasikataUniversalField20Name;
                case SiwakeTyouhyouExportItem.KasikataTekiyou:
                    return SiwakeTyouhyouExportItemId.KasikataTekiyou;
                case SiwakeTyouhyouExportItem.KasikataTekiyouCode:
                    return SiwakeTyouhyouExportItemId.KasikataTekiyouCode;
                case SiwakeTyouhyouExportItem.KasikataTekiyouName:
                    return SiwakeTyouhyouExportItemId.KasikataTekiyouName;
                case SiwakeTyouhyouExportItem.Ccod:
                    return SiwakeTyouhyouExportItemId.Ccod;
                default:
                    return default(SiwakeTyouhyouExportItemId);
            }
        }

        #endregion
    }
}
