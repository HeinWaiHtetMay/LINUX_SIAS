﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class HukugouSiwakeTyouhyouColumnWidthOptionRepository : IHukugouSiwakeTyouhyouColumnWidthOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        /// <summary>
        /// 複合仕訳帳票の列幅オプションを取得します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <returns>取得した複合仕訳帳票の列幅オプション</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "取得項目数が多いため")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "取得項目数が多いため")]
        public virtual HukugouSiwakeTyouhyouColumnWidthOption FindByUserCodeAndProgramId(int userCode, string programId)
        {
            var columnWidthOption = new HukugouSiwakeTyouhyouColumnWidthOption(programId);
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "DCOLWIDTH");

            foreach (var option in optionList)
            {
                int columnWidth = (int)option.Idata;
                switch (option.Keynm2)
                {
                    // 起票日
                    case "KYMD":
                    case "DKHDATE":
                    case "HKHDATE":
                        columnWidthOption.KihyouDateColumnWidth = columnWidth;
                        break;

                    // 起票者
                    case "KUSR":
                    case "DKHUSER":
                    case "HKHUSER":
                        columnWidthOption.KihyouTantousyaColumnWidth = columnWidth;
                        break;

                    // 起票部門
                    case "KBMN":
                    case "DKHBMN":
                    case "HKHBMN":
                        columnWidthOption.KihyouBumonColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド１
                    case "HF1":
                    case "DHF1":
                    case "HHF1":
                        columnWidthOption.HeaderField01ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド２
                    case "HF2":
                    case "DHF2":
                    case "HHF2":
                        columnWidthOption.HeaderField02ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド３
                    case "HF3":
                    case "DHF3":
                    case "HHF3":
                        columnWidthOption.HeaderField03ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド４
                    case "HF4":
                    case "DHF4":
                    case "HHF4":
                        columnWidthOption.HeaderField04ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド５
                    case "HF5":
                    case "DHF5":
                    case "HHF5":
                        columnWidthOption.HeaderField05ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド６
                    case "HF6":
                    case "DHF6":
                    case "HHF6":
                        columnWidthOption.HeaderField06ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド７
                    case "HF7":
                    case "DHF7":
                    case "HHF7":
                        columnWidthOption.HeaderField07ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド８
                    case "HF8":
                    case "DHF8":
                    case "HHF8":
                        columnWidthOption.HeaderField08ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド９
                    case "HF9":
                    case "DHF9":
                    case "HHF9":
                        columnWidthOption.HeaderField09ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド１０
                    case "HF10":
                    case "DHF10":
                    case "HHF10":
                        columnWidthOption.HeaderField10ColumnWidth = columnWidth;
                        break;

                    // 行番号
                    case "DLIN":
                        columnWidthOption.LineNoColumnWidth = columnWidth;
                        break;

                    // 承認状況
                    case "DSYONIN":
                        columnWidthOption.SyouninStatusColumnWidth = columnWidth;
                        break;

                    // 借方金額
                    case "RMONEY":
                    case "DRVALU":
                    case "DValuR":
                        columnWidthOption.KarikataKingakuColumnWidth = columnWidth;
                        break;

                    // 借方部門／科目／取引先／枝番
                    case "KARI":
                    case "DRKMK":
                    case "DKari":
                        columnWidthOption.KarikataMasterRelatedItemColumnWidth = columnWidth;
                        break;

                    // 借方税区分
                    case "RZEI":
                    case "DRZKBN":
                    case "DKrZei":
                        columnWidthOption.KarikataZeiKubunColumnWidth = columnWidth;
                        break;

                    // 摘要
                    case "TEKIYO":
                    case "DTEKIYO":
                    case "DTkyo":
                        columnWidthOption.TekiyouColumnWidth = columnWidth;
                        break;

                    // 貸方税区分
                    case "SZEI":
                    case "DSZKBN":
                    case "DKsZei":
                        columnWidthOption.KasikataZeiKubunColumnWidth = columnWidth;
                        break;

                    // 貸方部門／科目／取引先／枝番
                    case "KASI":
                    case "DSKMK":
                    case "DKasi":
                        columnWidthOption.KasikataMasterRelatedItemColumnWidth = columnWidth;
                        break;

                    // 貸方金額
                    case "SMONEY":
                    case "DSVALU":
                    case "DValuS":
                        columnWidthOption.KasikataKingakuColumnWidth = columnWidth;
                        break;

                    // 借方セグメント／プロジェクト／工事／工種
                    case "RSGPJKJKS":
                    case "DRSEG":
                    case "DSub1R":
                        columnWidthOption.KarikataMasterRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１～４
                    case "RUF1-4":
                    case "DRUF1":
                        columnWidthOption.KarikataUniversalField01to04ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド５～８
                    case "RUF5-8":
                    case "DRUF5":
                        columnWidthOption.KarikataUniversalField05to08ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド９～１２
                    case "RUF9-12":
                    case "DRUF9":
                        columnWidthOption.KarikataUniversalField09to12ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１３～１６
                    case "RUF13-16":
                    case "DRUF13":
                        columnWidthOption.KarikataUniversalField13to16ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１７～２０
                    case "RUF17-20":
                    case "DRUF17":
                        columnWidthOption.KarikataUniversalField17to20ColumnWidth = columnWidth;
                        break;

                    // 貸方セグメント／プロジェクト／工事／工種
                    case "SSGPJKJKS":
                    case "DSSEG":
                    case "DSub1S":
                        columnWidthOption.KasikataMasterRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１～４
                    case "SUF1-4":
                    case "DSUF1":
                        columnWidthOption.KasikataUniversalField01to04ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド５～８
                    case "SUF5-8":
                    case "DSUF5":
                        columnWidthOption.KasikataUniversalField05to08ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド９～１２
                    case "SUF9-12":
                    case "DSUF9":
                        columnWidthOption.KasikataUniversalField09to12ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１３～１６
                    case "SUF13-16":
                    case "DSUF13":
                        columnWidthOption.KasikataUniversalField13to16ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１７～２０
                    case "SUF17-20":
                    case "DSUF17":
                        columnWidthOption.KasikataUniversalField17to20ColumnWidth = columnWidth;
                        break;

                    // 仕訳作成日／確定日
                    case "DDday":
                        columnWidthOption.SiwakeCreateDateAndKakuteiDateColumnWidth = columnWidth;
                        break;
                }
            }

            return columnWidthOption;
        }

        /// <summary>
        /// 複合仕訳帳票の列幅オプションを保存します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <param name="columnWidthOption">保存する複合仕訳帳票の列幅オプション</param>
        public virtual void Store(int userCode, string programId, HukugouSiwakeTyouhyouColumnWidthOption columnWidthOption)
        {
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "DCOLWIDTH");
            if (programId == "SFCHKMAIN" || programId == "SKCHLSTA" || programId.EndsWith("SYONIN"))
            {
                if (programId == "SFCHKMAIN" || programId == "SKCHLSTA")
                {
                    //// 入力確定・チェックリスト
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKHDATE", 0, columnWidthOption.KihyouDateColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKHUSER", 0, columnWidthOption.KihyouTantousyaColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKHBMN", 0, columnWidthOption.KihyouBumonColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF1", 0, columnWidthOption.HeaderField01ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF2", 0, columnWidthOption.HeaderField02ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF3", 0, columnWidthOption.HeaderField03ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF4", 0, columnWidthOption.HeaderField04ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF5", 0, columnWidthOption.HeaderField05ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF6", 0, columnWidthOption.HeaderField06ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF7", 0, columnWidthOption.HeaderField07ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF8", 0, columnWidthOption.HeaderField08ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF9", 0, columnWidthOption.HeaderField09ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DHF10", 0, columnWidthOption.HeaderField10ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSYONIN", 0, columnWidthOption.SyouninStatusColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRVALU", 0, columnWidthOption.KarikataKingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRKMK", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRZKBN", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DTEKIYO", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSZKBN", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSKMK", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSVALU", 0, columnWidthOption.KasikataKingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRSEG", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSSEG", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth)
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                }
                else
                {
                    //// 承認処理
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HKHDATE", 0, columnWidthOption.KihyouDateColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HKHUSER", 0, columnWidthOption.KihyouTantousyaColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HKHBMN", 0, columnWidthOption.KihyouBumonColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF1", 0, columnWidthOption.HeaderField01ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF2", 0, columnWidthOption.HeaderField02ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF3", 0, columnWidthOption.HeaderField03ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF4", 0, columnWidthOption.HeaderField04ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF5", 0, columnWidthOption.HeaderField05ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF6", 0, columnWidthOption.HeaderField06ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF7", 0, columnWidthOption.HeaderField07ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF8", 0, columnWidthOption.HeaderField08ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF9", 0, columnWidthOption.HeaderField09ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HHF10", 0, columnWidthOption.HeaderField10ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DValuR", 0, columnWidthOption.KarikataKingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKari", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKrZei", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DTkyo", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKsZei", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DKasi", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DValuS", 0, columnWidthOption.KasikataKingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSub1R", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSub1S", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DDday", 0, columnWidthOption.SiwakeCreateDateAndKakuteiDateColumnWidth)
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                }

                if (programId.StartsWith("SF"))
                {
                    //// 部署別のみ、ユニバーサルフィールドの列幅を保存
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRUF1", 0, columnWidthOption.KarikataUniversalField01to04ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRUF5", 0, columnWidthOption.KarikataUniversalField05to08ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRUF9", 0, columnWidthOption.KarikataUniversalField09to12ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRUF13", 0, columnWidthOption.KarikataUniversalField13to16ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DRUF17", 0, columnWidthOption.KarikataUniversalField17to20ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSUF1", 0, columnWidthOption.KasikataUniversalField01to04ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSUF5", 0, columnWidthOption.KasikataUniversalField05to08ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSUF9", 0, columnWidthOption.KasikataUniversalField09to12ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSUF13", 0, columnWidthOption.KasikataUniversalField13to16ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DSUF17", 0, columnWidthOption.KasikataUniversalField17to20ColumnWidth),
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                }
            }
            else
            {
                //// 上記以外
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "KYMD", 0, columnWidthOption.KihyouDateColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "KUSR", 0, columnWidthOption.KihyouTantousyaColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "KBMN", 0, columnWidthOption.KihyouBumonColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF1", 0, columnWidthOption.HeaderField01ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF2", 0, columnWidthOption.HeaderField02ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF3", 0, columnWidthOption.HeaderField03ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF4", 0, columnWidthOption.HeaderField04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF5", 0, columnWidthOption.HeaderField05ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF6", 0, columnWidthOption.HeaderField06ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF7", 0, columnWidthOption.HeaderField07ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF8", 0, columnWidthOption.HeaderField08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF9", 0, columnWidthOption.HeaderField09ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "HF10", 0, columnWidthOption.HeaderField10ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "DLIN", 0, columnWidthOption.LineNoColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RMONEY", 0, columnWidthOption.KarikataKingakuColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "KARI", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RZEI", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "TEKIYO", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SZEI", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "KASI", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SMONEY", 0, columnWidthOption.KasikataKingakuColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RSGPJKJKS", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RUF1-4", 0, columnWidthOption.KarikataUniversalField01to04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RUF5-8", 0, columnWidthOption.KarikataUniversalField05to08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RUF9-12", 0, columnWidthOption.KarikataUniversalField09to12ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RUF13-16", 0, columnWidthOption.KarikataUniversalField13to16ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "RUF17-20", 0, columnWidthOption.KarikataUniversalField17to20ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSGPJKJKS", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUF1-4", 0, columnWidthOption.KasikataUniversalField01to04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUF5-8", 0, columnWidthOption.KasikataUniversalField05to08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUF9-12", 0, columnWidthOption.KasikataUniversalField09to12ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUF13-16", 0, columnWidthOption.KasikataUniversalField13to16ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUF17-20", 0, columnWidthOption.KasikataUniversalField17to20ColumnWidth),
                }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
            }
        }
    }
}
