﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DataScanHukugouSiwakeTyouhyouRepository : AbstractDataScanSiwakeTyouhyouRepository, IDataScanHukugouSiwakeTyouhyouRepository
    {
        [AutoInjection]
        private IHukugouSiwakeTyouhyouRowFactory hukugouSiwakeTyouhyouRowFactory = null;

        [AutoInjection]
        private IKaisyaSubsystemAvailabilityRepository kaisyaSubsystemAvailabilityRepository = null;
        [AutoInjection]
        private ISyouhizeiMasterRepository syouhizeiMasterRepository = null;
        [AutoInjection]
        private ITanituSiwakeTyouhyouRowRepository tanituSiwakeTyouhyouRowRepository = null;

        #region public methods

        /// <summary>
        /// 仕訳帳票問合せパラメータ及び伝票を条件として、複合仕訳帳票を取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="denpyou">伝票</param>
        /// <returns>複合仕訳帳票</returns>
        public virtual DataScanHukugouSiwakeTyouhyou FindByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter, ISiwakeTyouhyouDenpyouRow denpyou)
        {
            var parameter = queryParameter.CloneForHukugouSiwakeTyouhyou(denpyou);
            var gaikaSystemAvailability = this.kaisyaSubsystemAvailabilityRepository.FindByCcodAndSubid(queryParameter.KaisyaSyoriKikan.Syoriki.Ccod, SubsystemId.Gaika);
            queryParameter.SetSiwakeTyouhyouRowItemAvailability(
                gaikaSystemAvailability,
                this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn),
                true);

            var siwakeTyouhyou = new DataScanHukugouSiwakeTyouhyou(parameter);
            siwakeTyouhyou.SiwakeTyouhyouRows = this.hukugouSiwakeTyouhyouRowFactory.CreateHukugouSiwakeTyouhyouRows(this.tanituSiwakeTyouhyouRowRepository.FindSiwakeTyouhyouRowsByQueryParameter(parameter).Select(row => row as TanituSiwakeTyouhyouRow).ToList(), queryParameter);
            return siwakeTyouhyou;
        }

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、伝票リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>伝票リスト</returns>
        public virtual IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var gaikaSystemAvailability = this.kaisyaSubsystemAvailabilityRepository.FindByCcodAndSubid(queryParameter.KaisyaSyoriKikan.Syoriki.Ccod, SubsystemId.Gaika);
            queryParameter.SetSiwakeTyouhyouRowItemAvailability(
                gaikaSystemAvailability,
                this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn),
                false);
            return this.tanituSiwakeTyouhyouRowRepository.FindDenpyouListByQueryParameter(queryParameter);
        }

        #endregion
    }
}
