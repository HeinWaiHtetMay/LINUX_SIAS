﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;
    using Icsp.Open21.Properties;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouOptionRepository : ISiwakeTyouhyouOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        [AutoInjection]
        private IScenarioRepository scenarioRepository = null;
        [AutoInjection]
        private IDenpyouInputAndSyuuseiOptionRepository denpyouInputAndSyuuseiOptionRepository = null;
        [AutoInjection]
        private IPrintPreviewOptionRepository printPreviewOptionRepository = null;
        [AutoInjection]
        private ISiwakeKazeikubunOutputOptionRepository siwakeKazeikubunOutputOptionRepository = null;
        [AutoInjection]
        private ISiwakeOutputOptionRepository siwakeOutputOptionRepository = null;

        /// <summary>
        /// 未入力チェックオプション項目ID
        /// </summary>
        private enum NotInputCheckOptionItemId
        {
            KihyouTantousya = 0,
            KihyouBumon = 1,
            HeaderField01 = 2,
            HeaderField02 = 3,
            HeaderField03 = 4,
            HeaderField04 = 5,
            HeaderField05 = 6,
            HeaderField06 = 7,
            HeaderField07 = 8,
            HeaderField08 = 9,
            HeaderField09 = 10,
            HeaderField10 = 11,
            Bumon = 12,
            Edaban = 13,
            Torihikisaki = 14,
            Segment = 15,
            Project = 16,
            Kouzi = 17,
            Kousyu = 18,
            TekiyouCode = 19,
            UniversalField01 = 20,
            UniversalField02 = 21,
            UniversalField03 = 22,
            UniversalField04 = 23,
            UniversalField05 = 24,
            UniversalField06 = 25,
            UniversalField07 = 26,
            UniversalField08 = 27,
            UniversalField09 = 28,
            UniversalField10 = 29,
            UniversalField11 = 30,
            UniversalField12 = 31,
            UniversalField13 = 32,
            UniversalField14 = 33,
            UniversalField15 = 34,
            UniversalField16 = 35,
            UniversalField17 = 36,
            UniversalField18 = 37,
            UniversalField19 = 38,
            UniversalField20 = 39
        }

        #region public methods

        /// <summary>
        /// 指定条件の仕訳帳表オプションを取得します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="kesn">内部決算期</param>
        /// <param name="programIdForOption">取得に使用するプログラムID</param>
        /// <returns>仕訳帳表オプション</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        public virtual SiwakeTyouhyouOption FindByProgramIdAndUserCode(string programId, int userCode, int kesn, string programIdForOption)
        {
            var siwakeTyouhyouOption = new SiwakeTyouhyouOption(programIdForOption);
            this.SetOption(programIdForOption, userCode, siwakeTyouhyouOption);
            this.SetLastSelectedItemOption(programIdForOption, userCode, siwakeTyouhyouOption);
            this.SetHininStatusMessageOption(programIdForOption, userCode, siwakeTyouhyouOption);
            this.SetDisplaySettingOption(programIdForOption, userCode, siwakeTyouhyouOption);
            siwakeTyouhyouOption.SiwakeOutputOption = this.siwakeOutputOptionRepository.Find();
            siwakeTyouhyouOption.DenpyouInputAndSyuuseiOption = this.denpyouInputAndSyuuseiOptionRepository.Find();
            siwakeTyouhyouOption.IsOutputTaisyougaiInKazeiKubun = this.siwakeKazeikubunOutputOptionRepository.GetOutputKazeiKubunTaisyougaiByKesn(kesn);

            var printPreviewOption = this.printPreviewOptionRepository.Find();
            switch (programId)
            {
                //// チェックリスト
                case "CHKMAIN":
                case "SKCHLSTB":
                    siwakeTyouhyouOption.PrintPreviewOption = printPreviewOption;
                    break;

                //// データスキャン（部署別）
                case "SFDSCAN":
                    this.SetMitenkiDataSearchOption(programIdForOption, userCode, siwakeTyouhyouOption);
                    break;

                //// 入力確定・チェックリスト
                //// 承認処理
                case "SFCHKMAIN":
                case "SFSYONIN":
                case "SKCHLSTA":
                case "SKSYONIN":
                    this.SetSyouninColor(userCode, siwakeTyouhyouOption);
                    if (programId.StartsWith("SF"))
                    {
                        //// 部署別のみ、本支店の印刷設定及び決算整理処理ユーザー関連の項目を取得
                        this.SetHonsitenPrintSetting(userCode, siwakeTyouhyouOption);
                        this.SetKessanSeiriSyoriUserRelatedOption(userCode, siwakeTyouhyouOption);
                    }
                    if (programId.EndsWith("SYONIN"))
                    {
                        //// 承認処理のみ、承認伝票の検索条件を取得
                        this.SetSyouninDenpyouSearchCondition(programId, userCode, siwakeTyouhyouOption);
                    }
                    else
                    {
                        //// 入力確定・チェックリストのみ、印刷済可否の設定を取得
                        siwakeTyouhyouOption.PrintPreviewOption = printPreviewOption;
                    }
                    break;
            }

            return siwakeTyouhyouOption;
        }

        /// <summary>
        /// 仕訳出力時に必要なオプションを設定します。
        /// </summary>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="kesn">内部決算期</param>
        public virtual void SetOptionRequiredWhenSiwakeOutput(SiwakeTyouhyouOption siwakeTyouhyouOption, int kesn)
        {
            siwakeTyouhyouOption.SiwakeOutputOption = this.siwakeOutputOptionRepository.Find();
            siwakeTyouhyouOption.IsOutputTaisyougaiInKazeiKubun = this.siwakeKazeikubunOutputOptionRepository.GetOutputKazeiKubunTaisyougaiByKesn(kesn);
        }

        /// <summary>
        /// 仕訳印刷時に必要なオプションを設定します。
        /// </summary>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        public virtual void SetOptionRequiredWhenSiwakePrint(SiwakeTyouhyouOption siwakeTyouhyouOption)
            => siwakeTyouhyouOption.PrintPreviewOption = this.printPreviewOptionRepository.Find();

        /// <summary>
        /// 仕訳帳表オプションを保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="isKessanSeiriSyoriUser">決算整理処理ユーザーかどうか</param>
        public virtual void Store(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption, string programIdForOption, bool isKessanSeiriSyoriUser)
        {
            this.StoreOption(programId, userCode, siwakeTyouhyouOption, programIdForOption);
            this.StoreLastSelectedItemOption(programIdForOption, userCode, siwakeTyouhyouOption);
            this.StoreDisplaySettingOption(programIdForOption, userCode, siwakeTyouhyouOption);
            if (programIdForOption == "SFCHKMAIN"
                || programIdForOption == "SKCHLSTA"
                || programIdForOption.EndsWith("SYONIN"))
            {
                //// 入力確定・チェックリスト、承認処理のみ保存
                this.StoreSyouninColor(userCode, siwakeTyouhyouOption);
                if (programIdForOption.StartsWith("SF"))
                {
                    //// 入力確定・チェックリスト（部署別）、承認処理（部署別）のみ保存
                    this.StoreHonsitenPrintSetting(userCode, siwakeTyouhyouOption);
                    if (isKessanSeiriSyoriUser)
                    {
                        this.StoreKessanSeiriSyoriUserRelatedOption(userCode, siwakeTyouhyouOption);
                    }
                }

                if (programIdForOption.EndsWith("SYONIN"))
                {
                    //// 承認処理のみ保存
                    this.StoreSyouninDenpyouSearchCondition(programId, userCode, siwakeTyouhyouOption);
                    this.StoreHininStatusMessageOption(programId, userCode, siwakeTyouhyouOption);
                }
            }

            if (programId == "SFDSCAN")
            {
                //// データスキャン（SF系）のみ保存
                this.StoreMitenkiDataSearchOption(programIdForOption, userCode, siwakeTyouhyouOption);
            }
        }

        #endregion

        #region private methods

        #region 取得処理

        /// <summary>
        /// オプション項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目数が多いため、省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private void SetOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, programId.Contains("SYONIN") ? "OPT" : "OPTION");
            foreach (var optionValue in optionList)
            {
                switch (optionValue.Keynm2)
                {
                    // 出力形式
                    case "LAYOUTTYPE":
                    case "OUTPUT":
                        siwakeTyouhyouOption.SiwakeTyouhyouOutputType = (SiwakeTyouhyouOutputType)optionValue.Idata;
                        break;

                    // ソート順
                    case "SORT":
                        if (programId.Contains("SYONIN"))
                        {
                            siwakeTyouhyouOption.OutputOrderSetting = (SiwakeTyouhyouOutputOrderSetting)optionValue.Idata;
                        }
                        else
                        {
                            siwakeTyouhyouOption.SortOrder = (SiwakeTyouhyouSortOrder)optionValue.Idata;
                        }
                        break;

                    // 伝票単位時の伝票並び順
                    case "DSORTTYPE":
                        siwakeTyouhyouOption.HukugouSiwakeDenpyouSortOrder = (SiwakeTyouhyouDenpyouSortOrder)optionValue.Idata;
                        break;

                    // 仕訳一覧時の伝票並び順
                    case "SSORTTYPE":
                    case "SORTTYPE":
                        siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder = (SiwakeTyouhyouDenpyouSortOrder)optionValue.Idata;
                        break;

                    // 仕訳の最大表示数
                    case "DISPLAYLIMIT_SIWAKE":
                        siwakeTyouhyouOption.SiwakeMaxDisplayCount = (int)optionValue.Idata;
                        break;

                    // 整理月の月表示
                    case "SEIMONTH":
                    case "MOJI":
                        siwakeTyouhyouOption.SeiritukiDisplayType = (SiwakeTyouhyouSeiritukiDisplayType)optionValue.Idata;
                        break;

                    // 伝票ごとに合計金額を印刷するかどうか
                    case "GOKEI":
                        siwakeTyouhyouOption.IsPrintTotalKingakuEachDenpyou = optionValue.Idata == 1;
                        break;

                    // コメントの印刷
                    case "COMMENT":
                        siwakeTyouhyouOption.CommentPrintSetting = (SiwakeTyouhyouCommentPrintSetting)optionValue.Idata;
                        break;

                    // 伝票日付の印刷出力設定
                    case "PRNDAY":
                        siwakeTyouhyouOption.DenpyouDatePrintOutputSetting = (SiwakeTyouhyouDenpyouDatePrintOutputSetting)optionValue.Idata;
                        break;

                    // 出力指定の範囲指定で印刷した場合に、伝票を印刷済に設定するかどうか
                    case "SUMIFLG":
                        siwakeTyouhyouOption.IsSetDenpyouOutputed = optionValue.Idata == 1;
                        break;

                    // 伝票単位で通常出力する場合の出力内容の設定
                    case "DOUTTYPE":
                        siwakeTyouhyouOption.HukugouSiwakeNormalOutputSetting = (SiwakeTyouhyouHukugouSiwakeNormalOutputSetting)optionValue.Idata;
                        break;

                    // 貸借とも科目が表示できない仕訳を出力しないかどうか
                    case "HIDEFLAG":
                        siwakeTyouhyouOption.IsNotOutputKamokuNotDisplayedSiwake = optionValue.Idata == 1;
                        break;

                    // 処理月全体での印刷時に、合計を印刷するかどうか
                    case "GOKEIALL":
                        siwakeTyouhyouOption.IsPrintTotalKingakuForAllSyorituki = optionValue.Idata == 1;
                        break;

                    // 処理月全体での印刷時に、諸口チェックを印刷するかどうか
                    case "GOKEIALLSYOKUTI":
                        siwakeTyouhyouOption.IsPrintSyokutiCheckForAllSyorituki = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、合計を印刷するかどうか
                    case "ALLKEI":
                        siwakeTyouhyouOption.IsPrintTotalKingakuForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、伝票件数を印刷するかどうか
                    case "ALLKEIDENCNT":
                        siwakeTyouhyouOption.IsPrintDenpyouCountForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、諸口チェックを印刷するかどうか
                    case "ALLKEISYOKUTI":
                        siwakeTyouhyouOption.IsPrintSyokutiCheckForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、合計を印刷するかどうか
                    case "DENKEI":
                        siwakeTyouhyouOption.IsPrintTotalKingakuForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、１伝票１行でも印刷するかどうか
                    case "DENKEITYPE":
                        siwakeTyouhyouOption.IsPrintRowPerOneDenpyouForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、諸口チェックを印刷するかどうか
                    case "DENKEISYOKUTI":
                        siwakeTyouhyouOption.IsPrintSyokutiCheckForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 未入力チェック
                    case "CODECHECK":
                        this.SetNotInputCheckSettingOption(optionValue, siwakeTyouhyouOption);
                        break;

                    // 印刷レイアウトNo
                    case "LAYOUT":
                        siwakeTyouhyouOption.PrintLayoutNo = (int)optionValue.Idata;
                        break;
                }
            }

            //// 承認処理のみ、別途印刷レイアウトNoを取得
            if (!programId.Contains("SYONIN"))
            {
                return;
            }

            var optionListForSyouninSyori = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "OPTION");
            foreach (var optionValue in optionListForSyouninSyori)
            {
                if (optionValue.Keynm2 == "LAYOUT")
                {
                    // 印刷レイアウトNo
                    siwakeTyouhyouOption.PrintLayoutNo = (int)optionValue.Idata;
                }
            }
        }

        /// <summary>
        /// 未入力チェックダイアログの各項目を設定します。
        /// </summary>
        /// <param name="optionValue">オプション値</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多い")]
        private void SetNotInputCheckSettingOption(Option1Dto optionValue, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            switch ((NotInputCheckOptionItemId)optionValue.Keyno)
            {
                //// 起票者
                case NotInputCheckOptionItemId.KihyouTantousya:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseKihyouTantousyaNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 起票部門
                case NotInputCheckOptionItemId.KihyouBumon:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseKihyouBumonNotInputCheck = optionValue.Idata == 1;
                    break;

                //// ヘッダーフィールド
                case NotInputCheckOptionItemId.HeaderField01:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField01NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField02:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField02NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField03:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField03NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField04:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField04NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField05:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField05NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField06:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField06NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField07:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField07NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField08:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField08NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField09:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField09NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.HeaderField10:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField10NotInputCheck = optionValue.Idata == 1;
                    break;

                //// 部門
                case NotInputCheckOptionItemId.Bumon:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseBumonNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 枝番
                case NotInputCheckOptionItemId.Edaban:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseEdabanNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 取引先
                case NotInputCheckOptionItemId.Torihikisaki:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseTorihikisakiNotInputCheck = optionValue.Idata == 1;
                    break;

                //// セグメント
                case NotInputCheckOptionItemId.Segment:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseSegmentNotInputCheck = optionValue.Idata == 1;
                    break;

                //// プロジェクト
                case NotInputCheckOptionItemId.Project:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseProjectNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 工事
                case NotInputCheckOptionItemId.Kouzi:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseKouziNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 工種
                case NotInputCheckOptionItemId.Kousyu:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseKousyuNotInputCheck = optionValue.Idata == 1;
                    break;

                //// 摘要コード
                case NotInputCheckOptionItemId.TekiyouCode:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseTekiyouCodeNotInputCheck = optionValue.Idata == 1;
                    break;

                //// ユニバーサルフィールド
                case NotInputCheckOptionItemId.UniversalField01:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField01NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField02:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField02NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField03:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField03NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField04:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField04NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField05:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField05NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField06:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField06NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField07:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField07NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField08:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField08NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField09:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField09NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField10:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField10NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField11:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField11NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField12:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField12NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField13:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField13NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField14:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField14NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField15:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField15NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField16:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField16NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField17:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField17NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField18:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField18NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField19:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField19NotInputCheck = optionValue.Idata == 1;
                    break;
                case NotInputCheckOptionItemId.UniversalField20:
                    siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField20NotInputCheck = optionValue.Idata == 1;
                    break;
            }
        }

        /// <summary>
        /// 本支店の印刷設定の各項目を設定します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetHonsitenPrintSetting(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "HONSITEN", userCode, "OPT");
            foreach (var optionValue in optionList)
            {
                //// 本支店展開後の仕訳を印刷するかどうか
                if (optionValue.Keynm2 == "HSPRINT" && optionValue.Keyno == 0)
                {
                    siwakeTyouhyouOption.IsPrintSiwakeAfterHonsitenTenkai = optionValue.Idata == 1;
                }
            }
        }

        /// <summary>
        /// 承認関係の各色を設定します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetSyouninColor(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "SFSYONIN", userCode, "OPT");
            foreach (var optionValue in optionList)
            {
                var color = optionValue.Idata.HasValue ? Color.FromArgb(255, Color.FromArgb(optionValue.Idata.Value)) : Color.Black;
                if (optionValue.Keynm2 == Resources.未承認色)
                {
                    // 「未承認」の色
                    siwakeTyouhyouOption.MisyouninColor = color;
                }
                else if (optionValue.Keynm2 == Resources.否認色)
                {
                    // 「否認」の色
                    siwakeTyouhyouOption.HininColor = color;
                }
                else if (optionValue.Keynm2 == Resources.承認色)
                {
                    // 「承認」の色
                    siwakeTyouhyouOption.SyouninColor = color;
                }
            }
        }

        /// <summary>
        /// 前回の選択内容の各項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetLastSelectedItemOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "SAVEDATA");

            foreach (var optionValue in optionList)
            {
                switch (optionValue.Keynm2)
                {
                    // 印刷レイアウトNo
                    case "LAYOUTNO":
                        siwakeTyouhyouOption.PrintLayoutNo = (int)optionValue.Idata;
                        break;

                    // 摘要文字の分割形式
                    case "TEKIYO2":
                        siwakeTyouhyouOption.TekiyouCharacterDivisionType = (SiwakeTyouhyouTekiyouCharacterDivisionType)optionValue.Idata;
                        break;

                    // データスキャンで最後に表示したタブ
                    case "ACTIVETAB":
                        siwakeTyouhyouOption.DscanLastDisplayedTab = (SiwakeTyouhyouDscanTabType)optionValue.Idata;
                        break;
                }
            }
        }

        /// <summary>
        /// 未転記データ検索設定ダイアログの各項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetMitenkiDataSearchOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "SYONIN");

            foreach (var optionValue in optionList)
            {
                switch (optionValue.Keynm2)
                {
                    case "SYUKEI":
                        bool isContainSiwake = optionValue.Idata == 1;
                        switch (optionValue.Keyno)
                        {
                            // 未転記データ検索対象に、未確定仕訳を含めるかどうか
                            case 1:
                                siwakeTyouhyouOption.IsContainNotKakuteiSiwakeForSearchTarget = isContainSiwake;
                                break;

                            // 未転記データ検索対象に、未承認仕訳を含めるかどうか
                            case 2:
                                siwakeTyouhyouOption.IsContainNotSyouninSiwakeForSearchTarget = isContainSiwake;
                                break;

                            // 未転記データ検索対象に、承認中仕訳を含めるかどうか
                            case 3:
                                siwakeTyouhyouOption.IsContainSyounintyuuSiwakeForSearchTarget = isContainSiwake;
                                break;

                            // 未転記データ検索対象に、承認済仕訳を含めるかどうか
                            case 4:
                                siwakeTyouhyouOption.IsContainSyouninzumiSiwakeForSearchTarget = isContainSiwake;
                                break;

                            // 未転記データ集計対象に、未転記データ含めるかどうか
                            case 11:
                                siwakeTyouhyouOption.IsContainMitenkiDataForSyuukeiTarget = isContainSiwake;
                                break;
                        }

                        break;
                }
            }
        }

        /// <summary>
        /// 表示設定ダイアログの各項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目数が多いため、省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目数が多いため、省略不可")]
        private void SetDisplaySettingOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            foreach (var optionValue in this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "DISPOPT"))
            {
                SiwakeTyouhyouMasterDisplayType displayType = (SiwakeTyouhyouMasterDisplayType)optionValue.Idata;
                switch (optionValue.Keynm2)
                {
                    // 起票日
                    case "KHDATE":
                        siwakeTyouhyouOption.KihyouDateDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // 起票者
                    case "KHUSER":
                        siwakeTyouhyouOption.KihyouTantousyaDisplayTypeValue = displayType;
                        break;

                    // 起票部門
                    case "KHBMN":
                        siwakeTyouhyouOption.KihyouBumonDisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド１
                    case "HF1":
                        siwakeTyouhyouOption.HeaderField01DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド２
                    case "HF2":
                        siwakeTyouhyouOption.HeaderField02DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド３
                    case "HF3":
                        siwakeTyouhyouOption.HeaderField03DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド４
                    case "HF4":
                        siwakeTyouhyouOption.HeaderField04DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド５
                    case "HF5":
                        siwakeTyouhyouOption.HeaderField05DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド６
                    case "HF6":
                        siwakeTyouhyouOption.HeaderField06DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド７
                    case "HF7":
                        siwakeTyouhyouOption.HeaderField07DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド８
                    case "HF8":
                        siwakeTyouhyouOption.HeaderField08DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド９
                    case "HF9":
                        siwakeTyouhyouOption.HeaderField09DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド１０
                    case "HF10":
                        siwakeTyouhyouOption.HeaderField10DisplayTypeValue = displayType;
                        break;

                    // 科目
                    case "KMK":
                        siwakeTyouhyouOption.KamokuDisplayTypeValue = displayType;
                        break;

                    // 部門
                    case "BMN":
                        siwakeTyouhyouOption.BumonDisplayTypeValue = displayType;
                        break;

                    // 枝番
                    case "EDA":
                        siwakeTyouhyouOption.EdabanDisplayTypeValue = displayType;
                        break;

                    // 取引先
                    case "TORI":
                        siwakeTyouhyouOption.TorihikisakiDisplayTypeValue = displayType;
                        break;

                    // セグメント
                    case "SEG":
                        siwakeTyouhyouOption.SegmentDisplayTypeValue = displayType;
                        break;

                    // プロジェクト
                    case "PRJ":
                        siwakeTyouhyouOption.ProjectDisplayTypeValue = displayType;
                        break;

                    // 工事
                    case "KOJI":
                        siwakeTyouhyouOption.KouziDisplayTypeValue = displayType;
                        break;

                    // 工種
                    case "KOSYU":
                        siwakeTyouhyouOption.KousyuDisplayTypeValue = displayType;
                        break;

                    // ユーザー
                    case "USER":
                        siwakeTyouhyouOption.UserDisplayTypeValue = displayType;
                        break;

                    // 消費税対象科目
                    case "ZKMK":
                        siwakeTyouhyouOption.SyouhizeiTaisyouKamokuDisplayTypeValue = displayType;
                        break;

                    // 支払日
                    case "SYMD":
                        siwakeTyouhyouOption.SiharaiDateDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // 消込
                    case "DKEC":
                        siwakeTyouhyouOption.KesikomiDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // ユニバーサルフィールド１
                    case "UF1":
                        siwakeTyouhyouOption.UniversalField01DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド２
                    case "UF2":
                        siwakeTyouhyouOption.UniversalField02DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド３
                    case "UF3":
                        siwakeTyouhyouOption.UniversalField03DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド４
                    case "UF4":
                        siwakeTyouhyouOption.UniversalField04DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド５
                    case "UF5":
                        siwakeTyouhyouOption.UniversalField05DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド６
                    case "UF6":
                        siwakeTyouhyouOption.UniversalField06DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド７
                    case "UF7":
                        siwakeTyouhyouOption.UniversalField07DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド８
                    case "UF8":
                        siwakeTyouhyouOption.UniversalField08DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド９
                    case "UF9":
                        siwakeTyouhyouOption.UniversalField09DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１０
                    case "UF10":
                        siwakeTyouhyouOption.UniversalField10DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１１
                    case "UF11":
                        siwakeTyouhyouOption.UniversalField11DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１２
                    case "UF12":
                        siwakeTyouhyouOption.UniversalField12DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１３
                    case "UF13":
                        siwakeTyouhyouOption.UniversalField13DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１４
                    case "UF14":
                        siwakeTyouhyouOption.UniversalField14DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１５
                    case "UF15":
                        siwakeTyouhyouOption.UniversalField15DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１６
                    case "UF16":
                        siwakeTyouhyouOption.UniversalField16DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１７
                    case "UF17":
                        siwakeTyouhyouOption.UniversalField17DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１８
                    case "UF18":
                        siwakeTyouhyouOption.UniversalField18DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１９
                    case "UF19":
                        siwakeTyouhyouOption.UniversalField19DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド２０
                    case "UF20":
                        siwakeTyouhyouOption.UniversalField20DisplayTypeValue = displayType;
                        break;
                }
            }
        }

        /// <summary>
        ///  否認状況メッセージダイアログの各項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetHininStatusMessageOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            foreach (var optionValue in this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "MSGOPT"))
            {
                switch (optionValue.Keynm2)
                {
                    // 伝票入力者に否認状況メッセージを送信するかどうか
                    case "SEND":
                        siwakeTyouhyouOption.IsSendHininStatusMessageDenpyouInputter = optionValue.Idata == 1;
                        break;

                    // 否認状況メッセージを"重要"として送信するかどうか
                    case "NOTE":
                        siwakeTyouhyouOption.IsSendAsImportantHininStatusMessage = optionValue.Idata == 1;
                        break;

                    // 否認状況メッセージを下位承認者にも送信するかどうか
                    case "CC":
                        siwakeTyouhyouOption.IsSendLowerSyouninsyaHininStatusMessage = optionValue.Idata == 1;
                        break;
                }
            }
        }

        /// <summary>
        /// 承認伝票の検索条件を設定します
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetSyouninDenpyouSearchCondition(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            foreach (var optionValue in this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "CONDITION"))
            {
                //// 承認伝票の検索条件
                if (optionValue.Keynm2 == " ")
                {
                    siwakeTyouhyouOption.SyouninDenpyouSearchCondition = (SyouninDenpyouSearchCondition)optionValue.Idata;
                }
            }
        }

        /// <summary>
        /// 決算整理処理ユーザー関連の各項目を設定します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void SetKessanSeiriSyoriUserRelatedOption(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            foreach (var optionValue in this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "KSNUP", userCode, "OPTION"))
            {
                //// 承認伝票の検索条件
                if (optionValue.Keynm2 == "SNR")
                {
                    siwakeTyouhyouOption.InputedScenario = this.scenarioRepository.FindByCode(optionValue.Cdata);
                }
            }
        }

        #endregion

        #region 保存処理

        /// <summary>
        /// オプション設定の各項目を保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "条件指定が多いため")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private void StoreOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption, string programIdForOption)
        {
            var keynm1String = programId.Contains("SYONIN") ? "OPT" : "OPTION";

            //// 共通
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN") ? "OUTPUT" : "LAYOUTTYPE", 0, (int)siwakeTyouhyouOption.SiwakeTyouhyouOutputType),
                new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption.EndsWith("SYONIN") ? "MOJI" : "SEIMONTH", 0, (int)siwakeTyouhyouOption.SeiritukiDisplayType)
            }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

            if (programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN"))
            {
                //// 入力確定・チェックリスト、承認処理共通
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, "OPTION", "LAYOUT", 0, siwakeTyouhyouOption.PrintLayoutNo),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEI", 0, siwakeTyouhyouOption.IsPrintTotalKingakuEachDenpyou),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "COMMENT", 0, (int)siwakeTyouhyouOption.CommentPrintSetting),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "SORT", 0, programIdForOption.EndsWith("SYONIN") ? (int)siwakeTyouhyouOption.OutputOrderSetting : (int)siwakeTyouhyouOption.SortOrder)
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                if (!programIdForOption.EndsWith("SYONIN"))
                {
                    //// 入力確定・チェックリストのみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEIDENCNT", 0, siwakeTyouhyouOption.IsPrintDenpyouCountForOutputSiwake));
                }
            }
            else
            {
                //// 上記以外
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DSORTTYPE", 0, (int)siwakeTyouhyouOption.HukugouSiwakeDenpyouSortOrder),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption == "DSCAN" ? "SSORTTYPE" : "SORTTYPE", 0, (int)siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder)
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
            }

            if (!programIdForOption.EndsWith("SYONIN"))
            {
                //// 承認処理以外
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "PRNDAY", 0, (int)siwakeTyouhyouOption.DenpyouDatePrintOutputSetting));
                if (programIdForOption != "NIKKMAIN" && programIdForOption != "SKCHLSTB")
                {
                    //// 仕訳日記帳、チェックリスト（遡及）
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEI", 0, siwakeTyouhyouOption.IsPrintTotalKingakuForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEITYPE", 0, siwakeTyouhyouOption.IsPrintRowPerOneDenpyouForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEISYOKUTI", 0, siwakeTyouhyouOption.IsPrintSyokutiCheckForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEI", 0, siwakeTyouhyouOption.IsPrintTotalKingakuForOutputSiwake),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEISYOKUTI", 0, siwakeTyouhyouOption.IsPrintSyokutiCheckForOutputSiwake)
                    }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                    if (programIdForOption != "SFCHKMAIN" && programIdForOption != "SKCHLSTA")
                    {
                        //// 入力確定・チェックリスト
                        new List<Option1Dto>()
                        {
                            new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEIALL", 0, siwakeTyouhyouOption.IsPrintTotalKingakuForAllSyorituki),
                            new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEIALLSYOKUTI", 0, siwakeTyouhyouOption.IsPrintSyokutiCheckForAllSyorituki)
                        }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
                    }
                }
            }

            if (programIdForOption == "DSCAN")
            {
                //// データスキャン
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DISPLAYLIMIT_SIWAKE", 0, siwakeTyouhyouOption.SiwakeMaxDisplayCount));
                if (programId.StartsWith("S"))
                {
                    //// 財務以外のみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "HIDEFLAG", 0, siwakeTyouhyouOption.IsNotOutputKamokuNotDisplayedSiwake));
                }
            }

            if (programIdForOption == "CHKMAIN" || programIdForOption == "SKCHLSTB")
            {
                //// チェックリスト
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "SUMIFLG", 0, siwakeTyouhyouOption.IsSetDenpyouOutputed),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.KihyouTantousya, siwakeTyouhyouOption.NotInputCheckOption.IsUseKihyouTantousyaNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.KihyouBumon, siwakeTyouhyouOption.NotInputCheckOption.IsUseKihyouBumonNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField01, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField01NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField02, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField02NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField03, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField03NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField04, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField04NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField05, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField05NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField06, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField06NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField07, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField07NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField08, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField08NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField09, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField09NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.HeaderField10, siwakeTyouhyouOption.NotInputCheckOption.IsUseHeaderField10NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Bumon, siwakeTyouhyouOption.NotInputCheckOption.IsUseBumonNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Edaban, siwakeTyouhyouOption.NotInputCheckOption.IsUseEdabanNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Torihikisaki, siwakeTyouhyouOption.NotInputCheckOption.IsUseTorihikisakiNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Segment, siwakeTyouhyouOption.NotInputCheckOption.IsUseSegmentNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Project, siwakeTyouhyouOption.NotInputCheckOption.IsUseProjectNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Kouzi, siwakeTyouhyouOption.NotInputCheckOption.IsUseKouziNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.Kousyu, siwakeTyouhyouOption.NotInputCheckOption.IsUseKousyuNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.TekiyouCode, siwakeTyouhyouOption.NotInputCheckOption.IsUseTekiyouCodeNotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField01, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField01NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField02, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField02NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField03, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField03NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField04, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField04NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField05, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField05NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField06, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField06NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField07, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField07NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField08, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField08NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField09, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField09NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField10, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField10NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField11, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField11NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField12, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField12NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField13, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField13NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField14, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField14NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField15, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField15NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField16, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField16NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField17, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField17NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField18, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField18NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField19, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField19NotInputCheck),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "CODECHECK", (int)NotInputCheckOptionItemId.UniversalField20, siwakeTyouhyouOption.NotInputCheckOption.IsUseUniversalField20NotInputCheck)
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                if (programId == "CHKMAIN")
                {
                    //// 財務のみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DOUTTYPE", 0, (int)siwakeTyouhyouOption.HukugouSiwakeNormalOutputSetting));
                }
            }
        }

        /// <summary>
        /// 前回の選択内容の各項目を保存します。
        /// </summary>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreLastSelectedItemOption(string programIdForOption, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            if (programIdForOption != "SFCHKMAIN" && programIdForOption != "SKCHLSTA" && !programIdForOption.EndsWith("SYONIN"))
            {
                //// 入力確定・チェックリスト、承認処理では、印刷レイアウトNoを別メソッドで保存
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, "SAVEDATA", "LAYOUTNO", 0, siwakeTyouhyouOption.PrintLayoutNo));
                if (programIdForOption == "DSCAN")
                {
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programIdForOption, userCode, "SAVEDATA", "TEKIYO2", 0, (int)siwakeTyouhyouOption.TekiyouCharacterDivisionType),
                        new Option1Dto().SetValues(programIdForOption, userCode, "SAVEDATA", "ACTIVETAB", 0, (int)siwakeTyouhyouOption.DscanLastDisplayedTab)
                    }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
                }
            }
        }

        /// <summary>
        /// 未転記データ検索設定ダイアログの各項目を保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreMitenkiDataSearchOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => new List<Option1Dto>()
               {
                    new Option1Dto().SetValues(programId, userCode, "SYONIN", "SYUKEI", 1, siwakeTyouhyouOption.IsContainNotKakuteiSiwakeForSearchTarget),
                    new Option1Dto().SetValues(programId, userCode, "SYONIN", "SYUKEI", 2, siwakeTyouhyouOption.IsContainNotSyouninSiwakeForSearchTarget),
                    new Option1Dto().SetValues(programId, userCode, "SYONIN", "SYUKEI", 3, siwakeTyouhyouOption.IsContainSyounintyuuSiwakeForSearchTarget),
                    new Option1Dto().SetValues(programId, userCode, "SYONIN", "SYUKEI", 4, siwakeTyouhyouOption.IsContainSyouninzumiSiwakeForSearchTarget),
                    new Option1Dto().SetValues(programId, userCode, "SYONIN", "SYUKEI", 11, siwakeTyouhyouOption.IsContainMitenkiDataForSyuukeiTarget)
               }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

        /// <summary>
        /// 表示設定ダイアログの各項目の設定値を保存します。
        /// </summary>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreDisplaySettingOption(string programIdForOption, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
        {
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHDATE", 0, siwakeTyouhyouOption.KihyouDateDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHUSER", 0, (int)siwakeTyouhyouOption.KihyouTantousyaDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHBMN", 0, (int)siwakeTyouhyouOption.KihyouBumonDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF1", 0, (int)siwakeTyouhyouOption.HeaderField01DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF2", 0, (int)siwakeTyouhyouOption.HeaderField02DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF3", 0, (int)siwakeTyouhyouOption.HeaderField03DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF4", 0, (int)siwakeTyouhyouOption.HeaderField04DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF5", 0, (int)siwakeTyouhyouOption.HeaderField05DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF6", 0, (int)siwakeTyouhyouOption.HeaderField06DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF7", 0, (int)siwakeTyouhyouOption.HeaderField07DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF8", 0, (int)siwakeTyouhyouOption.HeaderField08DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF9", 0, (int)siwakeTyouhyouOption.HeaderField09DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF10", 0, (int)siwakeTyouhyouOption.HeaderField10DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KMK", 0, (int)siwakeTyouhyouOption.KamokuDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "BMN", 0, (int)siwakeTyouhyouOption.BumonDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "TORI", 0, (int)siwakeTyouhyouOption.TorihikisakiDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "SEG", 0, (int)siwakeTyouhyouOption.SegmentDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF1", 0, (int)siwakeTyouhyouOption.UniversalField01DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF2", 0, (int)siwakeTyouhyouOption.UniversalField02DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF3", 0, (int)siwakeTyouhyouOption.UniversalField03DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF4", 0, (int)siwakeTyouhyouOption.UniversalField04DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF5", 0, (int)siwakeTyouhyouOption.UniversalField05DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF6", 0, (int)siwakeTyouhyouOption.UniversalField06DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF7", 0, (int)siwakeTyouhyouOption.UniversalField07DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF8", 0, (int)siwakeTyouhyouOption.UniversalField08DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF9", 0, (int)siwakeTyouhyouOption.UniversalField09DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF10", 0, (int)siwakeTyouhyouOption.UniversalField10DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF11", 0, (int)siwakeTyouhyouOption.UniversalField11DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF12", 0, (int)siwakeTyouhyouOption.UniversalField12DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF13", 0, (int)siwakeTyouhyouOption.UniversalField13DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF14", 0, (int)siwakeTyouhyouOption.UniversalField14DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF15", 0, (int)siwakeTyouhyouOption.UniversalField15DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF16", 0, (int)siwakeTyouhyouOption.UniversalField16DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF17", 0, (int)siwakeTyouhyouOption.UniversalField17DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF18", 0, (int)siwakeTyouhyouOption.UniversalField18DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF19", 0, (int)siwakeTyouhyouOption.UniversalField19DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF20", 0, (int)siwakeTyouhyouOption.UniversalField20DisplayTypeValue)
            }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

            //// 以下の項目は、一部の業務のみ保存

            if (programIdForOption == "DSCAN" || programIdForOption == "CHKMAIN" || programIdForOption == "NIKKMAIN" || programIdForOption == "SKCHLSTB")
            {
                //// ユーザーは、データスキャン、チェックリスト、仕訳日記帳でのみ保存
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "USER", 0, (int)siwakeTyouhyouOption.UserDisplayTypeValue));
            }
            else if (programIdForOption == "SFCHKMAIN" || programIdForOption == "SFSYONIN")
            {
                //// 消費税対象科目は、入力確定・チェックリスト、承認処理でのみ保存（遡及は除く）
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "ZKMK", 0, (int)siwakeTyouhyouOption.SyouhizeiTaisyouKamokuDisplayTypeValue));
                if (programIdForOption == "SFSYONIN")
                {
                    //// 支払日及び消込は、承認処理でのみ保存（遡及は除く）
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "SYMD", 0, siwakeTyouhyouOption.SiharaiDateDisplayTypeValue),
                        new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "DKEC", 0, siwakeTyouhyouOption.KesikomiDisplayTypeValue)
                    }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
                }
            }

            if (programIdForOption != "SKCHLSTA" && programIdForOption != "SKSYONIN")
            {
                //// 以下の項目は、入力確定・チェックリスト（遡及）、承認処理（遡及）では保存しない
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "EDA", 0, (int)siwakeTyouhyouOption.EdabanDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "PRJ", 0, (int)siwakeTyouhyouOption.ProjectDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KOJI", 0, (int)siwakeTyouhyouOption.KouziDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KOSYU", 0, (int)siwakeTyouhyouOption.KousyuDisplayTypeValue),
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
            }
        }

        /// <summary>
        /// 本支店の印刷設定の各項目を保存します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreHonsitenPrintSetting(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues("HONSITEN", userCode, "OPT", "HSPRINT", 0, siwakeTyouhyouOption.IsPrintSiwakeAfterHonsitenTenkai));

        /// <summary>
        /// 承認関係の各色を保存します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreSyouninColor(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => new List<Option1Dto>()
               {
                    new Option1Dto().SetValues("SFSYONIN", userCode, "OPT", Resources.未承認色, 0, Color.FromArgb(0, siwakeTyouhyouOption.MisyouninColor.R, siwakeTyouhyouOption.MisyouninColor.G, siwakeTyouhyouOption.MisyouninColor.B).ToArgb()),
                    new Option1Dto().SetValues("SFSYONIN", userCode, "OPT", Resources.否認色, 0, Color.FromArgb(0, siwakeTyouhyouOption.HininColor.R, siwakeTyouhyouOption.HininColor.G, siwakeTyouhyouOption.HininColor.B).ToArgb()),
                    new Option1Dto().SetValues("SFSYONIN", userCode, "OPT", Resources.承認色, 0, Color.FromArgb(0, siwakeTyouhyouOption.SyouninColor.R, siwakeTyouhyouOption.SyouninColor.G, siwakeTyouhyouOption.SyouninColor.B).ToArgb())
               }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

        /// <summary>
        ///  否認状況メッセージダイアログの各項目を保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreHininStatusMessageOption(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => new List<Option1Dto>()
               {
                    new Option1Dto().SetValues(programId, userCode, "MSGOPT", "SEND", 0, siwakeTyouhyouOption.IsSendHininStatusMessageDenpyouInputter),
                    new Option1Dto().SetValues(programId, userCode, "MSGOPT", "NOTE", 0, siwakeTyouhyouOption.IsSendAsImportantHininStatusMessage),
                    new Option1Dto().SetValues(programId, userCode, "MSGOPT", "CC", 0, siwakeTyouhyouOption.IsSendLowerSyouninsyaHininStatusMessage)
               }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

        /// <summary>
        /// 承認伝票の検索条件を保存します
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreSyouninDenpyouSearchCondition(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programId, userCode, "CONDITION", " ", 0, (int)siwakeTyouhyouOption.SyouninDenpyouSearchCondition));

        /// <summary>
        /// 決算整理処理ユーザー関連の各項目を保存します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        private void StoreKessanSeiriSyoriUserRelatedOption(int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption)
            => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues("KSNUP", userCode, "OPTION", "SNR", 0, siwakeTyouhyouOption.InputedScenario?.Code));

        #endregion

        #endregion
    }
}
