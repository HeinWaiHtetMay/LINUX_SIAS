﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouOutputOptionRepository : ISiwakeTyouhyouOutputOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        /// <summary>
        /// 指定条件の仕訳帳表オプションを取得します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">取得に使用するプログラムID</param>
        /// <returns>オプション設定</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目数が多いため、省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        public virtual SiwakeTyouhyouOutputOption FindByProgramIdAndUserCode(int userCode, string programId)
        {
            var siwakeTyouhyouOutputOption = new SiwakeTyouhyouOutputOption(programId);

            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, programId.Contains("SYONIN") ? "OPT" : "OPTION");
            foreach (var optionValue in optionList)
            {
                switch (optionValue.Keynm2)
                {
                    // 出力形式
                    case "LAYOUTTYPE":
                    case "OUTPUT":
                        siwakeTyouhyouOutputOption.SiwakeTyouhyouOutputType = (SiwakeTyouhyouOutputType)optionValue.Idata;
                        break;

                    // ソート順
                    case "SORT":
                        if (programId.Contains("SYONIN"))
                        {
                            siwakeTyouhyouOutputOption.OutputOrderSetting = (SiwakeTyouhyouOutputOrderSetting)optionValue.Idata;
                        }
                        else
                        {
                            siwakeTyouhyouOutputOption.SortOrder = (SiwakeTyouhyouSortOrder)optionValue.Idata;
                        }
                        break;

                    // 伝票単位時の伝票並び順
                    case "DSORTTYPE":
                        siwakeTyouhyouOutputOption.HukugouSiwakeDenpyouSortOrder = (SiwakeTyouhyouDenpyouSortOrder)optionValue.Idata;
                        break;

                    // 仕訳一覧時の伝票並び順
                    case "SSORTTYPE":
                    case "SORTTYPE":
                        siwakeTyouhyouOutputOption.TanituSiwakeDenpyouSortOrder = (SiwakeTyouhyouDenpyouSortOrder)optionValue.Idata;
                        break;

                    // 仕訳の最大表示数
                    case "DISPLAYLIMIT_SIWAKE":
                        siwakeTyouhyouOutputOption.SiwakeMaxDisplayCount = (int)optionValue.Idata;
                        break;

                    // 整理月の月表示
                    case "SEIMONTH":
                    case "MOJI":
                        siwakeTyouhyouOutputOption.SeiritukiDisplayType = (SiwakeTyouhyouSeiritukiDisplayType)optionValue.Idata;
                        break;

                    // 伝票ごとに合計金額を印刷するかどうか
                    case "GOKEI":
                        siwakeTyouhyouOutputOption.IsPrintTotalKingakuEachDenpyou = optionValue.Idata == 1;
                        break;

                    // コメントの印刷
                    case "COMMENT":
                        siwakeTyouhyouOutputOption.CommentPrintSetting = (SiwakeTyouhyouCommentPrintSetting)optionValue.Idata;
                        break;

                    // 伝票日付の印刷出力設定
                    case "PRNDAY":
                        siwakeTyouhyouOutputOption.DenpyouDatePrintOutputSetting = (SiwakeTyouhyouDenpyouDatePrintOutputSetting)optionValue.Idata;
                        break;

                    // 出力指定の範囲指定で印刷した場合に、伝票を印刷済に設定するかどうか
                    case "SUMIFLG":
                        siwakeTyouhyouOutputOption.IsSetDenpyouOutputed = optionValue.Idata == 1;
                        break;

                    // 伝票単位で通常出力する場合の出力内容の設定
                    case "DOUTTYPE":
                        siwakeTyouhyouOutputOption.HukugouSiwakeNormalOutputSetting = (SiwakeTyouhyouHukugouSiwakeNormalOutputSetting)optionValue.Idata;
                        break;

                    // 貸借とも科目が表示できない仕訳を出力しないかどうか
                    case "HIDEFLAG":
                        siwakeTyouhyouOutputOption.IsNotOutputKamokuNotDisplayedSiwake = optionValue.Idata == 1;
                        break;

                    // 処理月全体での印刷時に、合計を印刷するかどうか
                    case "GOKEIALL":
                        siwakeTyouhyouOutputOption.IsPrintTotalKingakuForAllSyorituki = optionValue.Idata == 1;
                        break;

                    // 処理月全体での印刷時に、諸口チェックを印刷するかどうか
                    case "GOKEIALLSYOKUTI":
                        siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForAllSyorituki = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、合計を印刷するかどうか
                    case "ALLKEI":
                        siwakeTyouhyouOutputOption.IsPrintTotalKingakuForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、伝票件数を印刷するかどうか
                    case "ALLKEIDENCNT":
                        siwakeTyouhyouOutputOption.IsPrintDenpyouCountForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 出力された仕訳の印刷時に、諸口チェックを印刷するかどうか
                    case "ALLKEISYOKUTI":
                        siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForOutputSiwake = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、合計を印刷するかどうか
                    case "DENKEI":
                        siwakeTyouhyouOutputOption.IsPrintTotalKingakuForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、１伝票１行でも印刷するかどうか
                    case "DENKEITYPE":
                        siwakeTyouhyouOutputOption.IsPrintRowPerOneDenpyouForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 伝票毎の印刷時に、諸口チェックを印刷するかどうか
                    case "DENKEISYOKUTI":
                        siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForEachDenpyou = optionValue.Idata == 1;
                        break;

                    // 未入力チェック
                    case "CODECHECK":
                        break;

                    // 印刷レイアウトNo
                    case "LAYOUT":
                        siwakeTyouhyouOutputOption.PrintLayoutNo = (int)optionValue.Idata;
                        break;
                }
            }

            //// 承認処理のみ、別途印刷レイアウトNoを取得
            if (!programId.Contains("SYONIN"))
            {
                return siwakeTyouhyouOutputOption;
            }

            var optionListForSyouninSyori = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "OPTION");
            foreach (var optionValue in optionListForSyouninSyori)
            {
                if (optionValue.Keynm2 == "LAYOUT")
                {
                    // 印刷レイアウトNo
                    siwakeTyouhyouOutputOption.PrintLayoutNo = (int)optionValue.Idata;
                }
            }
            return siwakeTyouhyouOutputOption;
        }

        #region 保存処理

        /// <summary>
        /// オプション設定の各項目を保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOutputOption">仕訳帳表オプション</param>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "条件指定が多いため")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        public virtual void Store(string programId, int userCode, SiwakeTyouhyouOutputOption siwakeTyouhyouOutputOption, string programIdForOption)
        {
            var keynm1String = programId.Contains("SYONIN") ? "OPT" : "OPTION";

            //// 共通
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN") ? "OUTPUT" : "LAYOUTTYPE", 0, (int)siwakeTyouhyouOutputOption.SiwakeTyouhyouOutputType),
                new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption.EndsWith("SYONIN") ? "MOJI" : "SEIMONTH", 0, (int)siwakeTyouhyouOutputOption.SeiritukiDisplayType)
            }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

            if (programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN"))
            {
                //// 入力確定・チェックリスト、承認処理共通
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, "OPTION", "LAYOUT", 0, siwakeTyouhyouOutputOption.PrintLayoutNo),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEI", 0, siwakeTyouhyouOutputOption.IsPrintTotalKingakuEachDenpyou),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "COMMENT", 0, (int)siwakeTyouhyouOutputOption.CommentPrintSetting),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "SORT", 0, programIdForOption.EndsWith("SYONIN") ? (int)siwakeTyouhyouOutputOption.OutputOrderSetting : (int)siwakeTyouhyouOutputOption.SortOrder)
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                if (!programIdForOption.EndsWith("SYONIN"))
                {
                    //// 入力確定・チェックリストのみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEIDENCNT", 0, siwakeTyouhyouOutputOption.IsPrintDenpyouCountForOutputSiwake));
                }
            }
            else
            {
                //// 上記以外
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DSORTTYPE", 0, (int)siwakeTyouhyouOutputOption.HukugouSiwakeDenpyouSortOrder),
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, programIdForOption == "DSCAN" ? "SSORTTYPE" : "SORTTYPE", 0, (int)siwakeTyouhyouOutputOption.TanituSiwakeDenpyouSortOrder)
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
            }

            if (!programIdForOption.EndsWith("SYONIN"))
            {
                //// 承認処理以外
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "PRNDAY", 0, (int)siwakeTyouhyouOutputOption.DenpyouDatePrintOutputSetting));
                if (programIdForOption != "NIKKMAIN" && programIdForOption != "SKCHLSTB")
                {
                    //// 仕訳日記帳、チェックリスト（遡及）
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEI", 0, siwakeTyouhyouOutputOption.IsPrintTotalKingakuForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEITYPE", 0, siwakeTyouhyouOutputOption.IsPrintRowPerOneDenpyouForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DENKEISYOKUTI", 0, siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForEachDenpyou),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEI", 0, siwakeTyouhyouOutputOption.IsPrintTotalKingakuForOutputSiwake),
                        new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "ALLKEISYOKUTI", 0, siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForOutputSiwake)
                    }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                    if (programIdForOption != "SFCHKMAIN" && programIdForOption != "SKCHLSTA")
                    {
                        //// 入力確定・チェックリスト
                        new List<Option1Dto>()
                        {
                            new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEIALL", 0, siwakeTyouhyouOutputOption.IsPrintTotalKingakuForAllSyorituki),
                            new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "GOKEIALLSYOKUTI", 0, siwakeTyouhyouOutputOption.IsPrintSyokutiCheckForAllSyorituki)
                        }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
                    }
                }
            }

            if (programIdForOption == "DSCAN")
            {
                //// データスキャン
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DISPLAYLIMIT_SIWAKE", 0, siwakeTyouhyouOutputOption.SiwakeMaxDisplayCount));
                if (programId.StartsWith("S"))
                {
                    //// 財務以外のみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "HIDEFLAG", 0, siwakeTyouhyouOutputOption.IsNotOutputKamokuNotDisplayedSiwake));
                }
            }

            if (programIdForOption == "CHKMAIN" || programIdForOption == "SKCHLSTB")
            {
                //// チェックリスト
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "SUMIFLG", 0, siwakeTyouhyouOutputOption.IsSetDenpyouOutputed),
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

                if (programId == "CHKMAIN")
                {
                    //// 財務のみ保存
                    this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, keynm1String, "DOUTTYPE", 0, (int)siwakeTyouhyouOutputOption.HukugouSiwakeNormalOutputSetting));
                }
            }
        }

        #endregion
    }
}
