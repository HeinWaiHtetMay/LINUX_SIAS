﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.ControlStatements;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class DataScanTanituSiwakeTyouhyouRepository : AbstractDataScanSiwakeTyouhyouRepository, IDataScanTanituSiwakeTyouhyouRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private ITanituSiwakeTyouhyouRowRepository siwakeTyouhyouRowRepository = null;
        [AutoInjection]
        private IKaisyaSubsystemAvailabilityRepository kaisyaSubsystemAvailabilityRepository = null;
        [AutoInjection]
        private ISyouhizeiMasterRepository syouhizeiMasterRepository = null;

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、単一仕訳帳票を取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>単一仕訳帳票</returns>
        public virtual DataScanTanituSiwakeTyouhyou FindByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            if (queryParameter.SiwakeTyouhyouRowItemAvailability == null)
            {
                queryParameter = queryParameter.CloneAsShallowCopy();
                var gaikaSystemAvailability = this.kaisyaSubsystemAvailabilityRepository.FindByCcodAndSubid(queryParameter.KaisyaSyoriKikan.Syoriki.Ccod, SubsystemId.Gaika);
                queryParameter.SetSiwakeTyouhyouRowItemAvailability(
                    gaikaSystemAvailability,
                    this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn),
                    true);
            }

            var siwakeTyouhyou = new DataScanTanituSiwakeTyouhyou(queryParameter);
            siwakeTyouhyou.SiwakeTyouhyouRows = this.siwakeTyouhyouRowRepository.FindSiwakeTyouhyouRowsByQueryParameter(queryParameter);

            if (queryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwake)
            {
                siwakeTyouhyou.MitenkiSiwakeKingakuRelatedValue = this.GetMitenkSiwakeKingakuRelatedValueByQueryParameter(queryParameter);
            }

            //// 行番号指定の場合はリポジトリから行番号範囲外の仕訳を含めて集計、行番号未指定の場合はSiwakeTyouhyouRowsから集計
            if (queryParameter.RequiredSiwakeRowNoRange?.End != null)
            {
                siwakeTyouhyou.KingakuRelatedValue = this.siwakeTyouhyouRowRepository.GetKingakuRelatedValueByQueryParameter(queryParameter);
            }
            else
            {
                siwakeTyouhyou.KingakuRelatedValue.SiwakeTotalKingaku = siwakeTyouhyou.SiwakeTyouhyouRows.Where(row => !row.KarikataDetail.IsSyokutiKamoku && !row.KasikataDetail.IsSyokutiKamoku && !row.IsTorikesiSiwake).Sum(row => row.Kingaku); // 仕訳合計
                siwakeTyouhyou.KingakuRelatedValue.SiwakeKarikataSyokutiTotalKingaku = siwakeTyouhyou.SiwakeTyouhyouRows.Where(row => row.KarikataDetail.IsSyokutiKamoku && !row.IsTorikesiSiwake).Sum(row => row.Kingaku); // 借方諸口合計
                siwakeTyouhyou.KingakuRelatedValue.SiwakeKasikataSyokutiTotalKingaku = siwakeTyouhyou.SiwakeTyouhyouRows.Where(row => row.KasikataDetail.IsSyokutiKamoku && !row.IsTorikesiSiwake).Sum(row => row.Kingaku); // 貸方諸口合計
                siwakeTyouhyou.KingakuRelatedValue.DenpyouCount = siwakeTyouhyou.SiwakeTyouhyouRows.GroupBy(row => new { row.Dkei, row.Dseq }).Count(); // 伝票件数
                siwakeTyouhyou.KingakuRelatedValue.SiwakeCount = siwakeTyouhyou.SiwakeTyouhyouRows.Count(row => !row.IsTorikesiSiwake); // 仕訳件数
            }

            return siwakeTyouhyou;
        }

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、伝票リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>伝票リスト</returns>
        public virtual IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            queryParameter = queryParameter.CloneAsShallowCopy();
            var gaikaSystemAvailability = this.kaisyaSubsystemAvailabilityRepository.FindByCcodAndSubid(queryParameter.KaisyaSyoriKikan.Syoriki.Ccod, SubsystemId.Gaika);
            queryParameter.SetSiwakeTyouhyouRowItemAvailability(
                gaikaSystemAvailability,
                this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn),
                false);
            return this.siwakeTyouhyouRowRepository.FindDenpyouListByQueryParameter(queryParameter);
        }

        private TanituSiwakeTyouhyouKingakuRelatedValue GetMitenkSiwakeKingakuRelatedValueByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      LEFT (z.rkmk, 3) ");
            selectQuery.AppendLine("      WHEN '000' THEN 0 ");
            selectQuery.AppendLine("      ELSE CASE ");
            selectQuery.AppendLine("      LEFT (z.skmk, 3) ");
            selectQuery.AppendLine("      WHEN '000' THEN 0 ");
            selectQuery.AppendLine("      ELSE z.valu ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("    END ");
            selectQuery.AppendLine("  ) AS siwakeTotalKingaku ");
            selectQuery.AppendLine("  , SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      LEFT (z.rkmk, 3) ");
            selectQuery.AppendLine("      WHEN '000' THEN z.valu ");
            selectQuery.AppendLine("      ELSE 0 ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) AS karikataSyokutiTotalKingaku ");
            selectQuery.AppendLine("  , SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      LEFT (z.skmk, 3) ");
            selectQuery.AppendLine("      WHEN '000' THEN z.valu ");
            selectQuery.AppendLine("      ELSE 0 ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) AS kasikataSyokutiTotalKingaku ");
            selectQuery.AppendLine("  , COUNT(sseq) AS siwakeCount ");
            selectQuery.AppendLine("FROM ");
            selectQuery.AppendLine("  sjdat_h zh ");
            selectQuery.AppendLine("  INNER JOIN sjdat z ");
            selectQuery.AppendLine("    ON zh.kesn = z.kesn ");
            selectQuery.AppendLine("    AND zh.dkei = z.dkei ");
            selectQuery.AppendLine("    AND zh.dseq = z.dseq ");
            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);
            selectQuery.AppendLine("  AND zh.dkei >= :p ", queryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei);
            selectQuery.AppendLine("  AND zh.dkei <= :p ", queryParameter.KaisyaSyoriKikan.EndSyorituki.Ckei);
            selectQuery.AppendLine("  AND zh.delf = 0 ");
            selectQuery.AppendLine("  AND zh.bflg = 0 ");
            selectQuery.AppendLine("  AND z.delf = 0 ");
            selectQuery.AppendLine(this.CreateMitenkiDataWhereStatement(queryParameter));

            return this.dbc.QueryForObject(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var value = new TanituSiwakeTyouhyouKingakuRelatedValue();
                    value.SiwakeTotalKingaku = DbNullConverter.ToDecimal(values[0], 0);
                    value.SiwakeKarikataSyokutiTotalKingaku = DbNullConverter.ToDecimal(values[1], 0);
                    value.SiwakeKasikataSyokutiTotalKingaku = DbNullConverter.ToDecimal(values[2], 0);
                    value.SiwakeCount = DbNullConverter.ToInt(values[3], 0);
                    return value;
                },
                selectQuery.GetSqlParameters());
        }

        /// <summary>
        /// 未転記データ取得用の条件式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>未転記データ取得用の条件式</returns>
        private string CreateMitenkiDataWhereStatement(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var whereStatement = new SqlStatementBuilder();

            // 未確定仕訳
            whereStatement.AppendIfTrue(
                queryParameter.MitenkiDataQueryContext.IncludesMikakuteiSiwake,
                "  AND ((zh.kday = 0)");

            // 未承認仕訳
            whereStatement.AppendFormatIfTrue(
                queryParameter.MitenkiDataQueryContext.IncludesMisyouninSiwake,
                whereStatement.IsEmpty ? "  AND ({0}" : " OR {0}",
                "(zh.kday > 0 AND zh.hjno = 99)");

            // 承認中仕訳
            whereStatement.AppendFormatIfTrue(
                queryParameter.MitenkiDataQueryContext.IncludesSyounintyuuSiwake,
                whereStatement.IsEmpty ? "  AND ({0}" : " OR {0}",
                "(zh.kday > 0 AND (zh.hjno BETWEEN 2 AND 10))");

            // 承認済仕訳
            whereStatement.AppendFormatIfTrue(
                queryParameter.MitenkiDataQueryContext.IncludesSyouninzumiSiwake,
                whereStatement.IsEmpty ? "  AND ({0}" : " OR {0}",
                "(zh.kday > 0 AND zh.hjno = 1 AND zh.sflg = 1)");

            whereStatement.AppendIfTrue(!whereStatement.IsEmpty, ") ");

            return whereStatement.GetSqlStatement();
        }
    }
}
