﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class TanituSiwakeTyouhyouColumnWidthOptionRepository : ITanituSiwakeTyouhyouColumnWidthOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        /// <summary>
        /// 単一仕訳帳票の列幅オプションを取得します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <returns>取得した単一仕訳帳票の列幅オプション</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "取得項目数が多いため")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "取得項目数が多いため")]
        public virtual TanituSiwakeTyouhyouColumnWidthOption FindByUserCodeAndProgramId(int userCode, string programId)
        {
            var columnWidthOption = new TanituSiwakeTyouhyouColumnWidthOption(programId);
            var keynm1String = programId == "SFCHKMAIN" || programId == "SKCHLSTA" || programId.EndsWith("SYONIN")
                ? "DCOLWIDTH"
                : "SCOLWIDTH";
            var optionList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, keynm1String);

            foreach (var option in optionList)
            {
                int columnWidth = (int)option.Idata;
                switch (option.Keynm2)
                {
                    // 受付番号
                    case "SDUNO":
                    case "SUran":
                        columnWidthOption.UketukeNoColumnWidth = columnWidth;
                        break;

                    // 伝票SEQ／伝票日付／伝票番号／受付番号
                    case "DENPYO":
                        columnWidthOption.DenpyouRelatedItemColumnWidth = columnWidth;
                        break;

                    // 伝票日付／番号／束
                    case "SDYMD_DCNO":
                    case "SDenp":
                        columnWidthOption.DenpyouRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 起票日／起票者／起票部門
                    case "KIHYO":
                    case "SKHDATE":
                        columnWidthOption.KihyouRelatedItemColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド１～４
                    case "HF1-4":
                    case "SHF1":
                        columnWidthOption.HeaderField01to04ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド５～８
                    case "HF5-8":
                    case "SHF5":
                        columnWidthOption.HeaderField05to08ColumnWidth = columnWidth;
                        break;

                    // ヘッダーフィールド９～１０
                    case "HF9-10":
                    case "SHF9":
                        columnWidthOption.HeaderField09to10ColumnWidth = columnWidth;
                        break;

                    // 仕訳SEQ／行番号／仕訳作成日／仕訳更新日
                    case "SSEQ":
                        columnWidthOption.SiwakeRelatedItemColumnWidth = columnWidth;
                        break;

                    // 仕訳SEQ／行番号／仕訳作成日／確定日
                    case "SSSEQ":
                        columnWidthOption.SiwakeRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 承認状況
                    case "SSYONIN":
                        columnWidthOption.SyouninStatusColumnWidth = columnWidth;
                        break;

                    // 借方部門／科目／取引先／枝番
                    case "KARI":
                    case "SKARI":
                    case "SKari":
                        columnWidthOption.KarikataMasterRelatedItemColumnWidth = columnWidth;
                        break;

                    // 借方税区分
                    case "RZEI":
                    case "SRKBN":
                    case "SKrZei":
                        columnWidthOption.KarikataZeiKubunColumnWidth = columnWidth;
                        break;

                    // 貸方部門／科目／取引先／枝番
                    case "KASI":
                    case "SKASI":
                    case "SKasi":
                        columnWidthOption.KasikataMasterRelatedItemColumnWidth = columnWidth;
                        break;

                    // 貸方税区分
                    case "SZEI":
                    case "SSKBN":
                    case "SKsZei":
                        columnWidthOption.KasikataZeiKubunColumnWidth = columnWidth;
                        break;

                    // 金額
                    case "MONEY":
                    case "SVALU":
                    case "SValu":
                        columnWidthOption.KingakuColumnWidth = columnWidth;
                        break;

                    // 摘要
                    case "TEKIYO":
                    case "STEKIYO":
                    case "STkyo":
                        columnWidthOption.TekiyouColumnWidth = columnWidth;
                        break;

                    // 借方セグメント／プロジェクト／工事／工種
                    case "RSGPJKJKS":
                    case "SSub1R":
                        columnWidthOption.KarikataMasterRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１～４
                    case "RUF1-4":
                    case "SRUF1":
                        columnWidthOption.KarikataUniversalField01to04ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド５～８
                    case "RUF5-8":
                    case "SRUF5":
                        columnWidthOption.KarikataUniversalField05to08ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド９～１２
                    case "RUF9-12":
                    case "SRUF9":
                        columnWidthOption.KarikataUniversalField09to12ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１３～１６
                    case "RUF13-16":
                    case "SRUF13":
                        columnWidthOption.KarikataUniversalField13to16ColumnWidth = columnWidth;
                        break;

                    // 借方ユニバーサルフィールド１７～２０
                    case "RUF17-20":
                    case "SRUF17":
                        columnWidthOption.KarikataUniversalField17to20ColumnWidth = columnWidth;
                        break;

                    // 貸方セグメント／プロジェクト／工事／工種
                    case "SSGPJKJKS":
                    case "SSub1S":
                        columnWidthOption.KasikataMasterRelatedItem2ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１～４
                    case "SUF1-4":
                    case "SSUF1":
                        columnWidthOption.KasikataUniversalField01to04ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド５～８
                    case "SUF5-8":
                    case "SSUF5":
                        columnWidthOption.KasikataUniversalField05to08ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド９～１２
                    case "SUF9-12":
                    case "SSUF9":
                        columnWidthOption.KasikataUniversalField09to12ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１３～１６
                    case "SUF13-16":
                    case "SSUF13":
                        columnWidthOption.KasikataUniversalField13to16ColumnWidth = columnWidth;
                        break;

                    // 貸方ユニバーサルフィールド１７～２０
                    case "SUF17-20":
                    case "SSUF17":
                        columnWidthOption.KasikataUniversalField17to20ColumnWidth = columnWidth;
                        break;

                    // 仕訳作成者／仕訳更新者／その他
                    case "OTHER":
                        columnWidthOption.OtherItemColumnWidth = columnWidth;
                        break;

                    // 税科目／支払日／消込
                    case "SDsk0":
                        columnWidthOption.OtherItem2ColumnWidth = columnWidth;
                        break;

                    // 付箋
                    case "FUSEN":
                        columnWidthOption.HusenColumnWidth = columnWidth;
                        break;

                    // 税対象科目
                    case "SSub2":
                        columnWidthOption.SyouhizeiTaisyouKamokuColumnWidth = columnWidth;
                        break;

                    // 仕訳作成日／確定日
                    case "SDday":
                        columnWidthOption.SiwakeCreateDateAndKakuteiDateColumnWidth = columnWidth;
                        break;
                }
            }

            return columnWidthOption;
        }

        /// <summary>
        /// 単一仕訳帳票の列幅オプションを保存します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <param name="columnWidthOption">保存する単一仕訳帳票の列幅オプション</param>
        public virtual void Store(int userCode, string programId, TanituSiwakeTyouhyouColumnWidthOption columnWidthOption)
        {
            if (programId == "SFCHKMAIN" || programId == "SKCHLSTA" || programId.EndsWith("SYONIN"))
            {
                this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "DCOLWIDTH");

                //// 入力確定・チェックリスト、承認処理共通
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKHDATE", 0, columnWidthOption.KihyouRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SHF1", 0, columnWidthOption.HeaderField01to04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SHF5", 0, columnWidthOption.HeaderField05to08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SHF9", 0, columnWidthOption.HeaderField09to10ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSub1R", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSub1S", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));

                if (programId == "SFCHKMAIN" || programId == "SKCHLSTA")
                {
                    //// 入力確定・チェックリスト
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SDUNO", 0, columnWidthOption.UketukeNoColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SDYMD_DCNO", 0, columnWidthOption.DenpyouRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSSEQ", 0, columnWidthOption.SiwakeRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSYONIN", 0, columnWidthOption.SyouninStatusColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKARI", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRKBN", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKASI", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSKBN", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SVALU", 0, columnWidthOption.KingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "STEKIYO", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSub2", 0, columnWidthOption.SyouhizeiTaisyouKamokuColumnWidth)
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                }
                else
                {
                    //// 承認処理
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SUran", 0, columnWidthOption.UketukeNoColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SDenp", 0, columnWidthOption.DenpyouRelatedItem2ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKari", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKrZei", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKasi", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SKsZei", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SValu", 0, columnWidthOption.KingakuColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "STkyo", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SDday", 0, columnWidthOption.SiwakeCreateDateAndKakuteiDateColumnWidth)
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                }

                if (programId.StartsWith("SF"))
                {
                    //// 部署別のみ、ユニバーサルフィールドの列幅を保存
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRUF1", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRUF5", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRUF9", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRUF13", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SRUF17", 0, columnWidthOption.TekiyouColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSUF1", 0, columnWidthOption.KasikataUniversalField01to04ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSUF5", 0, columnWidthOption.KasikataUniversalField05to08ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSUF9", 0, columnWidthOption.KasikataUniversalField09to12ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSUF13", 0, columnWidthOption.KasikataUniversalField13to16ColumnWidth),
                        new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SSUF17", 0, columnWidthOption.KasikataUniversalField17to20ColumnWidth),
                    }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
                    if (programId == "SFSYONIN")
                    {
                        //// 承認処理（部署別）のみ、その他項目も保存
                        this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programId, userCode, "DCOLWIDTH", "SDsk0", 0, columnWidthOption.OtherItem2ColumnWidth));
                    }
                }
            }
            else
            {
                //// 上記以外
                this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "SCOLWIDTH");
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "DENPYO", 0, columnWidthOption.DenpyouRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "KIHYO", 0, columnWidthOption.KihyouRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "HF1-4", 0, columnWidthOption.HeaderField01to04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "HF5-8", 0, columnWidthOption.HeaderField05to08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "HF9-10", 0, columnWidthOption.HeaderField09to10ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SSEQ", 0, columnWidthOption.SiwakeRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "KARI", 0, columnWidthOption.KarikataMasterRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RZEI", 0, columnWidthOption.KarikataZeiKubunColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "KASI", 0, columnWidthOption.KasikataMasterRelatedItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SZEI", 0, columnWidthOption.KasikataZeiKubunColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "MONEY", 0, columnWidthOption.KingakuColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "TEKIYO", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RSGPJKJKS", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RUF1-4", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RUF5-8", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RUF9-12", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RUF13-16", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "RUF17-20", 0, columnWidthOption.TekiyouColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SSGPJKJKS", 0, columnWidthOption.KarikataMasterRelatedItem2ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SUF1-4", 0, columnWidthOption.KasikataUniversalField01to04ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SUF5-8", 0, columnWidthOption.KasikataUniversalField05to08ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SUF9-12", 0, columnWidthOption.KasikataUniversalField09to12ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SUF13-16", 0, columnWidthOption.KasikataUniversalField13to16ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "SUF17-20", 0, columnWidthOption.KasikataUniversalField17to20ColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "OTHER", 0, columnWidthOption.OtherItemColumnWidth),
                    new Option1Dto().SetValues(programId, userCode, "SCOLWIDTH", "FUSEN", 0, columnWidthOption.HusenColumnWidth)
                }.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
            }
        }
    }
}
