﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    internal class TanituSiwakeTyouhyouRowMasterAndTekiyouSetterWithSecurity
    {
        private int kesn;
        private UserAndSyorikiSecurityContext securityContext;
        private SecurityPermittedCodeRepositoryCache securityPermittedCodeRepositoryCache;
        private MasterNameRepositoryCache masterNameRepositoryCache;

        public TanituSiwakeTyouhyouRowMasterAndTekiyouSetterWithSecurity(int kesn, UserAndSyorikiSecurityContext securityContext, SecurityPermittedCodeRepositoryCache securityPermittedCodeRepositoryCache, MasterNameRepositoryCache masterNameRepositoryCache)
        {
            this.kesn = kesn;
            this.securityContext = securityContext;
            this.securityPermittedCodeRepositoryCache = securityPermittedCodeRepositoryCache;
            this.masterNameRepositoryCache = masterNameRepositoryCache;
        }

        #region プロパティ

        /// <summary>
        /// 借方にセキュリティ不許可のコードが存在するかどうか
        /// </summary>
        public bool HasSecurityNotPermittedCodeOnKarikata { get; private set; }

        /// <summary>
        /// 貸方にセキュリティ不許可のコードが存在するかどうか
        /// </summary>
        public bool HasSecurityNotPermittedCodeOnKasikata { get; private set; }

        /// <summary>
        /// 借方科目が他人仕訳の摘要を出力可能かどうか
        /// </summary>
        public bool EnabledKarikataKamokuTaninSiwakeTekiyouOutput { get; private set; }

        /// <summary>
        /// 貸方科目が他人仕訳の摘要を出力可能かどうか
        /// </summary>
        public bool EnabledKasikataKamokuTaninSiwakeTekiyouOutput { get; private set; }

        #endregion

        #region public methods

        /// <summary>
        /// 科目内部コード・入力コード・名称を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="kamoku">科目データ</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetKamokuKicdAndKcodAndName(TanituSiwakeTyouhyouRow row, Kamoku kamoku, bool isKarikata, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var kicd = string.Empty;

            //// 一旦、科目内部コードを空にする（セキュリティチェック後に再度セット）
            if (isKarikata
                && row.KarikataDetail != null)
            {
                kicd = row.KarikataDetail.Kicd;
                row.KarikataDetail.Kicd = string.Empty;
            }
            else if (!isKarikata
                     && row.KasikataDetail != null)
            {
                kicd = row.KasikataDetail.Kicd;
                row.KasikataDetail.Kicd = string.Empty;
            }

            //// 複合仕訳の諸口は、判定しない
            if (queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake
                || (queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake && !kicd.StartsWith("00")))
            {
                if (isKarikata)
                {
                    this.EnabledKarikataKamokuTaninSiwakeTekiyouOutput = this.securityPermittedCodeRepositoryCache.GetAllowOutputTaninSiwakeTekiyouByKesnAndKicd(this.kesn, kicd);
                }
                else
                {
                    this.EnabledKasikataKamokuTaninSiwakeTekiyouOutput = this.securityPermittedCodeRepositoryCache.GetAllowOutputTaninSiwakeTekiyouByKesnAndKicd(this.kesn, kicd);
                }
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other
                && this.ShouldApplyCodeSecurity(row)
                && this.securityContext.GetUseZaimuKamokuCodeSecurity(SecurityKubun.Output)
                && (this.securityContext.SecurityPattern == null
                    || !this.securityPermittedCodeRepositoryCache.GetAllowUseKamokuByKesnAndKicd(this.kesn, kicd)))
            {
                this.SetHasSecurityNotPermitted(isKarikata, true);
            }
            else
            {
                var detail = this.GetDetail(row, isKarikata);
                detail.Kicd = kicd;
                if (queryParameter.ConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption && this.IsZidouSyokuti(row, detail, isKarikata))
                {
                    detail.Kcod = string.Empty;
                    detail.KamokuName = queryParameter.SiwakeTyouhyouRowItemAvailability.UseKamokuLongName
                        ? queryParameter.SiwakeOutputOption?.SyokutiNameForPrint
                        : queryParameter.SiwakeOutputOption?.SyokutiNameForForm;
                    if (queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuLongNameEnabled)
                    {
                        detail.KamokuLongName = queryParameter.SiwakeOutputOption?.SyokutiNameForPrint;
                    }
                }
                else
                {
                    detail.Kcod = kamoku.Kcod;
                    detail.KamokuName = queryParameter.SiwakeTyouhyouRowItemAvailability.UseKamokuLongName
                        ? kamoku.LongName : kamoku.ShortName;
                    if (queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuLongNameEnabled)
                    {
                        detail.KamokuLongName = kamoku.LongName;
                    }
                }
            }
        }

        /// <summary>
        /// 部門コード・名称を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="bumonCode">部門コード</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetBumonCodeAndName(TanituSiwakeTyouhyouRow row, string bumonCode, bool isKarikata, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 一旦、部門コードを空にする（セキュリティチェック後に再度セット）
            if (isKarikata
                && row.KarikataDetail != null)
            {
                row.KarikataDetail.Bcod = string.Empty;
            }
            else if (!isKarikata
                     && row.KasikataDetail != null)
            {
                row.KasikataDetail.Bcod = string.Empty;
            }

            if (string.IsNullOrEmpty(bumonCode))
            {
                return;
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other
                && this.ShouldApplyCodeSecurity(row)
                && this.securityContext.GetUseZaimuBumonCodeSecurity(SecurityKubun.Output)
                && (this.securityContext.SecurityPattern == null
                    || !this.securityPermittedCodeRepositoryCache.GetAllowUseBumonByKesnAndCode(this.kesn, bumonCode)))
            {
                this.SetHasSecurityNotPermitted(isKarikata, true);
            }
            else
            {
                var detail = this.GetDetail(row, isKarikata);
                detail.Bcod = bumonCode;
                detail.BumonName = this.masterNameRepositoryCache.GetBumonNameByKesnAndCode(this.kesn, bumonCode, BumonFindType.OnlyBumon);
            }
        }

        /// <summary>
        /// 取引先コード・名称を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="torihikisakiCode">取引先コード</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetTorihikisakiCodeAndName(TanituSiwakeTyouhyouRow row, string torihikisakiCode, bool isKarikata, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 一旦、取引先コードを空にする（セキュリティチェック後に再度セット）
            if (isKarikata
                && row.KarikataDetail != null)
            {
                row.KarikataDetail.Trcd = string.Empty;
            }
            else if (!isKarikata
                     && row.KasikataDetail != null)
            {
                row.KasikataDetail.Trcd = string.Empty;
            }

            if (string.IsNullOrEmpty(torihikisakiCode))
            {
                return;
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other
                && this.ShouldApplyCodeSecurity(row)
                && this.securityContext.GetUseZaimuTorihikisakiCodeSecurity(SecurityKubun.Output)
                && (this.securityContext.SecurityPattern == null
                    || !this.securityPermittedCodeRepositoryCache.GetAllowUseTorihikisaiByKesnAndCode(this.kesn, torihikisakiCode)))
            {
                this.SetHasSecurityNotPermitted(isKarikata, true);
            }
            else
            {
                var detail = this.GetDetail(row, isKarikata);
                detail.Trcd = torihikisakiCode;
                detail.TorihikisakiName = this.masterNameRepositoryCache.GetTorihikisakiNameByCode(torihikisakiCode, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseTorihikisakiLongName);
                detail.TorihikisakiLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.TorihikisakiLongNameEnabled
                    ? this.masterNameRepositoryCache.GetTorihikisakiLongNameByCode(torihikisakiCode)
                    : string.Empty;
            }
        }

        /// <summary>
        /// 枝番コード・名称を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="kicd">科目内部コード</param>
        /// <param name="edabanCode">枝番コード</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetEdabanCodeAndName(TanituSiwakeTyouhyouRow row, string kicd, string edabanCode, bool isKarikata, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 一旦、枝番コードを空にする（セキュリティチェック後に再度セット）
            if (isKarikata
                && row.KarikataDetail != null)
            {
                row.KarikataDetail.Ecod = string.Empty;
            }
            else if (!isKarikata
                     && row.KasikataDetail != null)
            {
                row.KasikataDetail.Ecod = string.Empty;
            }

            if (string.IsNullOrEmpty(kicd) || string.IsNullOrEmpty(edabanCode))
            {
                return;
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other
                && this.ShouldApplyCodeSecurity(row)
                && this.securityContext.GetUseZaimuKamokuEdabanCodeSecurity(SecurityKubun.Output)
                && (this.securityContext.SecurityPattern == null
                    || !this.securityPermittedCodeRepositoryCache.GetAllowUseEdabanByKesnAndKicdAndEdabanCode(this.kesn, kicd, edabanCode)))
            {
                this.SetHasSecurityNotPermitted(isKarikata, true);
            }
            else
            {
                var detail = this.GetDetail(row, isKarikata);
                detail.Ecod = edabanCode;
                detail.EdabanName = this.masterNameRepositoryCache.GetEdabanNameByKesnAndKicdAndEdabanCode(this.kesn, kicd, edabanCode);
            }
        }

        /// <summary>
        /// 税対象科目内部コード・名称を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="kamoku">税対象科目データ</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetSyouhizeiTaisyouKamokuKicdAndName(TanituSiwakeTyouhyouRow row, Kamoku kamoku, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 一旦、税対象科目内部コードを空にする（セキュリティチェック後に再度セット）
            var kicd = row.SyouhizeiTaisyouKicd;
            row.SyouhizeiTaisyouKicd = string.Empty;

            if (string.IsNullOrEmpty(kicd))
            {
                return;
            }

            if (this.ShouldApplyCodeSecurity(row)
                && this.securityContext.GetUseZaimuKamokuCodeSecurity(SecurityKubun.Output)
                && !this.securityPermittedCodeRepositoryCache.GetAllowUseKamokuByKesnAndKicd(this.kesn, kicd))
            {
                if (queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake
                    && row.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou)
                {
                    //// 単一仕訳かつ貸借共通摘要の場合、貸借共に摘要非表示
                    this.HasSecurityNotPermittedCodeOnKarikata = true;
                    this.HasSecurityNotPermittedCodeOnKasikata = true;
                }
                else
                {
                    switch (row.SiwakeTaisyakuZokusei)
                    {
                        case SiwakeTaisyakuZokusei.Karikata:
                            this.HasSecurityNotPermittedCodeOnKarikata = true;
                            break;
                        case SiwakeTaisyakuZokusei.Kasikata:
                            this.HasSecurityNotPermittedCodeOnKasikata = true;
                            break;
                        default:
                            //// 借方科目が税対象科目
                            if (row.KarikataDetail.Syouhizeiritu?.Zeiritu.GetValue() > 0 && row.KarikataDetail.KazeiKubun != KazeiKubun.計算外)
                            {
                                this.HasSecurityNotPermittedCodeOnKarikata = true;
                            }

                            //// 貸方科目が税対象科目
                            if (row.KasikataDetail.Syouhizeiritu?.Zeiritu.GetValue() > 0 && row.KasikataDetail.KazeiKubun != KazeiKubun.計算外)
                            {
                                this.HasSecurityNotPermittedCodeOnKasikata = true;
                            }

                            break;
                    }
                }
            }
            else
            {
                row.SyouhizeiTaisyouKicd = kicd;
                row.SyouhizeiTaisyouKamokuName = queryParameter.SiwakeTyouhyouRowItemAvailability.UseKamokuLongName
                    ? kamoku?.LongName : kamoku?.ShortName;
                row.SyouhizeiTaisyouKamokuLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuLongNameEnabled
                    ? kamoku?.LongName : string.Empty;
            }
        }

        /// <summary>
        /// 摘要をセットします、コードセキュリティの影響を受けるため、
        /// 当クラスのメソッドで、各マスターのコードをセットした後で実行する必要があります。
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="karikataTekiyou">借方摘要</param>
        /// <param name="kasikataTekiyou">貸方摘要</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        public void SetTekiyou(TanituSiwakeTyouhyouRow row, string karikataTekiyou, string kasikataTekiyou, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 一旦、摘要を空にする（セキュリティチェック後に再度セット）
            if (row.KarikataDetail != null)
            {
                row.KarikataDetail.Tekiyou = string.Empty;
            }

            if (row.KasikataDetail != null)
            {
                row.KasikataDetail.Tekiyou = string.Empty;
            }

            var isOutputZikoSiwake = row.IsZikoSiwake(this.securityContext.User.UserCode);

            //// 摘要出力セキュリティ未使用時、摘要出力許可
            if ((isOutputZikoSiwake && this.securityContext.SecurityPattern?.UseZikoSiwakeTekiyouOutputSecurity == false)
                || (!isOutputZikoSiwake && this.securityContext.SecurityPattern?.UseTaninSiwakeTekiyouOutputSecurity == false))
            {
                this.SetHasSecurityNotPermitted(true, false);
                this.SetHasSecurityNotPermitted(false, false);
            }

            //// 他人仕訳の摘要取得可能時、摘要出力許可
            if (!isOutputZikoSiwake
                && this.EnabledKarikataKamokuTaninSiwakeTekiyouOutput)
            {
                this.SetHasSecurityNotPermitted(true, false);
                if (row.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou)
                {
                    this.SetHasSecurityNotPermitted(false, false);
                }
            }

            if (!isOutputZikoSiwake
                && this.EnabledKasikataKamokuTaninSiwakeTekiyouOutput)
            {
                this.SetHasSecurityNotPermitted(false, false);
                if (row.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou)
                {
                    this.SetHasSecurityNotPermitted(true, false);
                }
            }

            this.GetDetail(row, true).HasSecurityNotPermittedCode = this.HasSecurityNotPermittedCodeOnKarikata;
            this.GetDetail(row, false).HasSecurityNotPermittedCode = this.HasSecurityNotPermittedCodeOnKasikata;

            var isNotOutputTekiyou = row.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku
               && row.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou
               && (this.HasSecurityNotPermittedCodeOnKarikata || this.HasSecurityNotPermittedCodeOnKasikata);

            //// 借方摘要をセット
            if (!isNotOutputTekiyou && !this.HasSecurityNotPermittedCodeOnKarikata)
            {
                this.GetDetail(row, true).Tekiyou = karikataTekiyou;
            }

            //// 貸方摘要をセット
            if (!isNotOutputTekiyou && !this.HasSecurityNotPermittedCodeOnKasikata)
            {
                this.GetDetail(row, false).Tekiyou = kasikataTekiyou;
            }
        }

        /// <summary>
        /// 表示不可能な仕訳かどうかの値を設定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "チェック項目が多いため")]
        public void SetIsNotDisplayableSiwake(TanituSiwakeTyouhyouRow row)
        {
            //// 残高セキュリティを使用しない場合は、何もしない
            if (this.securityContext.SecurityInitialSetting == null
                || this.securityContext.SecurityInitialSetting?.UseZandakaSecurity == false
                || this.securityContext.SecurityInitialSetting?.UseZandakaSecurityWhenOutputSiwake == false
                || (this.securityContext.SecurityPattern?.AllowOutputKamokuZandaka == true
                    && this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == false))
            {
                return;
            }

            //// 科目残高のチェック
            var allowUseKarikataKamoku = this.securityPermittedCodeRepositoryCache.GetAllowUseKamokuByKesnAndKicd(this.kesn, this.GetDetail(row, true).Kicd);
            var allowUseKasikataKamoku = this.securityPermittedCodeRepositoryCache.GetAllowUseKamokuByKesnAndKicd(this.kesn, this.GetDetail(row, false).Kicd);
            if (this.securityContext.SecurityPattern?.AllowOutputKamokuZandaka == true
                && this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true
                && (allowUseKarikataKamoku
                    || allowUseKasikataKamoku))
            {
                return;
            }

            //// 枝番残高のチェック
            var allowUseKarikataEdaban = this.securityPermittedCodeRepositoryCache.GetAllowUseEdabanByKesnAndKicdAndEdabanCode(this.kesn, this.GetDetail(row, true).Kicd, this.GetDetail(row, true).Ecod);
            var allowUseKasikataEdaban = this.securityPermittedCodeRepositoryCache.GetAllowUseEdabanByKesnAndKicdAndEdabanCode(this.kesn, this.GetDetail(row, false).Kicd, this.GetDetail(row, false).Ecod);
            if (this.securityContext.SecurityPattern?.AllowOutputKamokuEdabanZandaka == true)
            {
                var allowUseKarikataItem = false;
                var allowUseKasikataItem = false;
                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
                {
                    //// 科目出力セキュリティ使用時
                    allowUseKarikataItem = allowUseKarikataKamoku;
                    allowUseKasikataItem = allowUseKasikataKamoku;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuEdabanOutputSecurity == true)
                {
                    //// 枝番出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataEdaban;
                    allowUseKasikataItem &= allowUseKasikataEdaban;
                }

                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            //// 部門残高のチェック
            var allowUseKarikataBumon = this.securityPermittedCodeRepositoryCache.GetAllowUseBumonByKesnAndCode(this.kesn, this.GetDetail(row, true).Bcod);
            var allowUseKasikataBumon = this.securityPermittedCodeRepositoryCache.GetAllowUseBumonByKesnAndCode(this.kesn, this.GetDetail(row, false).Bcod);
            if (this.securityContext.SecurityPattern?.AllowOutputBumonKamokuZandaka == true)
            {
                var allowUseKarikataItem = false;
                var allowUseKasikataItem = false;
                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
                {
                    //// 科目出力セキュリティ使用時
                    allowUseKarikataItem = allowUseKarikataKamoku;
                    allowUseKasikataItem = allowUseKasikataKamoku;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuBumonOutputSecurity == true)
                {
                    //// 部門出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataBumon;
                    allowUseKasikataItem &= allowUseKasikataBumon;
                }

                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            //// 取引先残高のチェック
            var allowUseKarikataTorihikisaki = this.securityPermittedCodeRepositoryCache.GetAllowUseTorihikisaiByKesnAndCode(this.kesn, this.GetDetail(row, true).Trcd);
            var allowUseKasikataTorihikisaki = this.securityPermittedCodeRepositoryCache.GetAllowUseTorihikisaiByKesnAndCode(this.kesn, this.GetDetail(row, false).Trcd);
            if (this.securityContext.SecurityPattern?.AllowOutputKamokuTorihikisakiZandaka == true)
            {
                var allowUseKarikataItem = false;
                var allowUseKasikataItem = false;
                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
                {
                    //// 科目出力セキュリティ使用時
                    allowUseKarikataItem = allowUseKarikataKamoku;
                    allowUseKasikataItem = allowUseKasikataKamoku;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuTorihikisakiOutputSecurity == true)
                {
                    //// 取引先出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataTorihikisaki;
                    allowUseKasikataItem &= allowUseKasikataTorihikisaki;
                }

                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            //// 部門科目枝番残高のチェック
            if (this.securityContext.SecurityPattern?.AllowOutputBumonKamokuEdabanZandaka == true)
            {
                var allowUseKarikataItem = false;
                var allowUseKasikataItem = false;
                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
                {
                    //// 科目出力セキュリティ使用時
                    allowUseKarikataItem = allowUseKarikataKamoku;
                    allowUseKasikataItem = allowUseKasikataKamoku;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuEdabanOutputSecurity == true)
                {
                    //// 枝番出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataEdaban;
                    allowUseKasikataItem &= allowUseKasikataEdaban;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuBumonOutputSecurity == true)
                {
                    //// 部門出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataBumon;
                    allowUseKasikataItem &= allowUseKasikataBumon;
                }

                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            //// 部門科目取引先残高のチェック
            if (this.securityContext.SecurityPattern?.AllowOutputBumonKamokuTorihikisakiZandaka == true)
            {
                var allowUseKarikataItem = false;
                var allowUseKasikataItem = false;
                if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
                {
                    //// 科目出力セキュリティ使用時
                    allowUseKarikataItem = allowUseKarikataKamoku;
                    allowUseKasikataItem = allowUseKasikataKamoku;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuBumonOutputSecurity == true)
                {
                    //// 部門出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataBumon;
                    allowUseKasikataItem &= allowUseKasikataBumon;
                }

                if (this.securityContext.SecurityInitialSetting?.UseZaimuTorihikisakiOutputSecurity == true)
                {
                    //// 取引先出力セキュリティ使用時
                    allowUseKarikataItem &= allowUseKarikataTorihikisaki;
                    allowUseKasikataItem &= allowUseKasikataTorihikisaki;
                }

                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            if (this.securityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == false)
            {
                var allowUseKarikataItem = !string.IsNullOrEmpty(this.GetDetail(row, true).Ecod) || !string.IsNullOrEmpty(this.GetDetail(row, true).Bcod) || !string.IsNullOrEmpty(this.GetDetail(row, true).Trcd);
                var allowUseKasikataItem = !string.IsNullOrEmpty(this.GetDetail(row, false).Ecod) || !string.IsNullOrEmpty(this.GetDetail(row, false).Bcod) || !string.IsNullOrEmpty(this.GetDetail(row, false).Trcd);
                if (allowUseKarikataItem
                    || allowUseKasikataItem)
                {
                    return;
                }
            }

            row.IsNotDisplayableSiwake = true;
        }

        #endregion

        #region private methods

        /// <summary>
        /// セキュリティ不許可のコードかどうかの判定値を設定します
        /// </summary>
        /// <param name="isKarikata">借方かどうか</param>
        /// <param name="hasSecurityNotPermittedCode">セキュリティ不許可のコードかどうか</param>
        private void SetHasSecurityNotPermitted(bool isKarikata, bool hasSecurityNotPermittedCode)
        {
            if (isKarikata)
            {
                this.HasSecurityNotPermittedCodeOnKarikata = hasSecurityNotPermittedCode;
            }
            else
            {
                this.HasSecurityNotPermittedCodeOnKasikata = hasSecurityNotPermittedCode;
            }
        }

        /// <summary>
        /// 貸借別データを取得します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <returns>貸借別データ</returns>
        private TanituSiwakeTyouhyouTaisyakubetuDetail GetDetail(TanituSiwakeTyouhyouRow row, bool isKarikata) => isKarikata ? row.KarikataDetail : row.KasikataDetail;

        /// <summary>
        /// コードセキュリティを適用するかどうか判定します
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <returns>コードセキュリティを適用するかどうか</returns>
        private bool ShouldApplyCodeSecurity(TanituSiwakeTyouhyouRow row)
            => !(this.securityContext.AllowOutputZikoSiwakeWithoutReferenceCodeSecurity && row.IsZikoSiwake(this.securityContext.User.UserCode));

        /// <summary>
        /// 自動諸口かどうかを判定します
        /// </summary>
        /// <param name="row"></param>
        /// <param name="detail"></param>
        /// <param name="isKarikata"></param>
        /// <returns></returns>
        private bool IsZidouSyokuti(TanituSiwakeTyouhyouRow row, TanituSiwakeTyouhyouTaisyakubetuDetail detail, bool isKarikata)
        {
            return detail.IsSyokutiKamoku
                    && ((isKarikata && row.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata)
                        || (!isKarikata && row.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata));
        }

        #endregion
    }
}
