﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.ControlStatements;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TanituSiwakeTyouhyouRowRepository : ITanituSiwakeTyouhyouRowRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        [AutoInjection]
        private InjectionContainer container = null;

        [AutoInjection]
        private IDbReservedWords dbReservedWords = null;

        [AutoInjection]
        private ISyouhizeirituRepository syouhizeirituRepository = null;

        #region public methods

        /// <summary>
        /// 指定条件の単一仕訳帳票の行データリストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得した単一仕訳帳票の行データリスト</returns>
        public virtual IList<ITanituSiwakeTyouhyouRow> FindSiwakeTyouhyouRowsByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var siwakeTyouhyouRows = this.FindByQueryParameter<ITanituSiwakeTyouhyouRow, TanituSiwakeTyouhyouRow>(
                queryParameter,
                false,
                (values, no, parameter, syouhizeirituDictionary) => this.MapRow(values, no, parameter, false, syouhizeirituDictionary),
                () => new List<ITanituSiwakeTyouhyouRow>());
            this.SetMasterAndSecurityRelatedValue(siwakeTyouhyouRows.ToList<object>(), queryParameter);
            GC.Collect();
            return siwakeTyouhyouRows;
        }

        /// <summary>
        /// 指定条件のODC用単一仕訳帳票の行データリストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得したODC用単一仕訳帳票の行データリスト</returns>
        public virtual IList<IOdcTanituSiwakeTyouhyouRow> FindOdcSiwakeTyouhyouRowsByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var siwakeTyouhyouRows = this.FindByQueryParameter<IOdcTanituSiwakeTyouhyouRow, TanituSiwakeTyouhyouRow>(
                queryParameter,
                false,
                (values, no, parameter, syouhizeirituDictionary) => this.MapRow(values, no, parameter, false, syouhizeirituDictionary),
                () => new List<IOdcTanituSiwakeTyouhyouRow>());
            this.SetMasterAndSecurityRelatedValue(siwakeTyouhyouRows.ToList<object>(), queryParameter);
            GC.Collect();
            return siwakeTyouhyouRows;
        }

        /// <summary>
        /// 指定条件の伝票リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得した伝票リスト</returns>
        public virtual IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var siwakeTyouhyouRows = this.FindByQueryParameter<ISiwakeTyouhyouDenpyouRow, TanituSiwakeTyouhyouRow>(
                queryParameter,
                true,
                (values, no, parameter, syouhizeirituDictionary) => this.MapRow(values, no, parameter, true, syouhizeirituDictionary),
                () => new List<ISiwakeTyouhyouDenpyouRow>());
            this.SetMasterAndSecurityRelatedValue(siwakeTyouhyouRows.ToList<object>(), queryParameter);
            GC.Collect();
            return siwakeTyouhyouRows;
        }

        /// <summary>
        /// 指定条件の仕訳が存在するかどうかを取得します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>指定条件の仕訳が存在するかどうか</returns>
        public virtual bool GetExistsByQuertyParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendFormatAndLine("  {0} zh.dkei ", this.dbReservedWords.GetTop(1));
            selectQuery.AppendLine(this.CreateFromStatement(queryParameter, false, false, true));
            selectQuery.AppendLine("WHERE ");
            selectQuery.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);
            var whereStatement = queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake
                ? this.CreateWhereStatementForHukugouSiwakeTyouhyouRows(queryParameter)
                : this.CreateWhereStatement(queryParameter, false);
            selectQuery.Append(whereStatement.GetSqlStatement(), whereStatement.GetSqlParameters());
            selectQuery.AppendLine(this.dbReservedWords.GetLimitAndOffset(1, 0));
            return this.dbc.QueryForObject(
                selectQuery.GetSqlStatement(),
                (values, no) => true,
                selectQuery.GetSqlParameters());
        }

        /// <summary>
        /// 指定条件の金額関係の値を取得します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>指定条件の金額関係の値</returns>
        public virtual TanituSiwakeTyouhyouKingakuRelatedValue GetKingakuRelatedValueByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var selectQuery = new SqlStatementBuilder();
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      WHEN ");
            selectQuery.AppendLine("      LEFT (rkmk, 3) = '000' ");
            selectQuery.AppendLine("      OR ");
            selectQuery.AppendLine("      LEFT (skmk, 3) = '000' ");
            selectQuery.AppendLine("        THEN 0 ");
            selectQuery.AppendLine("      ELSE valu ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) AS siwake_sum ");
            selectQuery.AppendLine("  , SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      WHEN ");
            selectQuery.AppendLine("      LEFT (rkmk, 3) = '000' ");
            selectQuery.AppendLine("        THEN valu ");
            selectQuery.AppendLine("      ELSE 0 ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) AS karikata_syokuti_sum ");
            selectQuery.AppendLine("  , SUM( ");
            selectQuery.AppendLine("    CASE ");
            selectQuery.AppendLine("      WHEN ");
            selectQuery.AppendLine("      LEFT (skmk, 3) = '000' ");
            selectQuery.AppendLine("        THEN valu ");
            selectQuery.AppendLine("      ELSE 0 ");
            selectQuery.AppendLine("      END ");
            selectQuery.AppendLine("  ) AS kasikata_syokuti_sum ");
            selectQuery.AppendLine("  , COUNT(*) AS siwake_count ");
            selectQuery.AppendLine("FROM ( ");

            Func<bool, SqlStatementBuilder> createSelectQuery = isMitenki =>
            {
                var result = new SqlStatementBuilder();
                result.Append("SELECT z.rkmk, z.skmk, z.valu ");
                result.AppendLine(this.CreateFromStatement(queryParameter, isMitenki, false, true));
                result.AppendLine("WHERE ");
                result.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);
                result.AppendLine(this.CreateWhereStatement(queryParameter, isMitenki));
                return result;
            };

            selectQuery.AppendLine(createSelectQuery(false));
            if (queryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwake)
            {
                selectQuery.AppendLine("  UNION ALL ");
                selectQuery.Append(createSelectQuery(true));
            }

            selectQuery.AppendLine(") AS search_result ");

            return this.dbc.QueryForObject(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    var kingakuRelatedValue = new TanituSiwakeTyouhyouKingakuRelatedValue();
                    kingakuRelatedValue.SiwakeTotalKingaku = DbNullConverter.ToDecimal(values[0], 0);
                    kingakuRelatedValue.SiwakeKarikataSyokutiTotalKingaku = DbNullConverter.ToDecimal(values[1], 0);
                    kingakuRelatedValue.SiwakeKasikataSyokutiTotalKingaku = DbNullConverter.ToDecimal(values[2], 0);
                    kingakuRelatedValue.SiwakeCount = DbNullConverter.ToInt(values[3], 0);
                    return kingakuRelatedValue;
                },
                selectQuery.GetSqlParameters());
        }

        #endregion

        #region private methods

        private IList<TValue> FindByQueryParameter<TValue, TValueImpl>(
            ISiwakeTyouhyouQueryParameter queryParameter,
            bool isGetDenpyou,
            Func<object[], int, ISiwakeTyouhyouQueryParameter, SyouhizeirituDictionary, TValueImpl> createRow,
            Func<IList<TValue>> craeteList)
            where TValueImpl : TanituSiwakeTyouhyouRow, TValue
        {
            // 帳票の各行のデータの設定
            var selectQuery = new SqlStatementBuilder();
            var selectQuery1 =
                this.CreateSelectQuery(
                    queryParameter,
                    queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other && !queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication,
                    isGetDenpyou);

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other)
            {
                selectQuery.AppendLine("SELECT ");
                selectQuery.AppendLine("  * ");
                selectQuery.AppendIfTrue(queryParameter.RequiredSiwakeRowNoRange != null, "  , ROW_NUMBER() OVER (ORDER BY r_num)  AS row_number ");
                selectQuery.AppendLine("FROM ( ");
                selectQuery.AppendLine("  SELECT ");
                selectQuery.AppendLine("    * ");
                selectQuery.AppendLine("    , ROW_NUMBER() OVER ( ");
                var orderByStatement = this.CreateOrderByStatement(queryParameter, isGetDenpyou);
                selectQuery.AppendLine(orderByStatement.GetSqlStatement(), orderByStatement.GetSqlParameters());
                selectQuery.AppendLine("      ) AS r_num ");
                selectQuery.AppendLine("  FROM (");
                selectQuery.AppendLine(selectQuery1.GetSqlStatement(), selectQuery1.GetSqlParameters());
                if (queryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwake)
                {
                    // 未転記データを含む設定の場合、財務データと未転記データを結合
                    selectQuery.AppendLine(" UNION ALL ");
                    var selectQuery2 = this.CreateSelectQuery(queryParameter, true, isGetDenpyou);
                    selectQuery.Append(selectQuery2.GetSqlStatement(), selectQuery2.GetSqlParameters());
                }

                selectQuery.AppendLine("  ) AS search_result1 ");
                selectQuery.AppendLine(") AS search_result2 ");
                if (queryParameter.RequiredSiwakeRowNoRange != null)
                {
                    //// 対象行の仕訳のみ取得
                    selectQuery.AppendLine("WHERE ");
                    selectQuery.AppendWhereStatementByIntRange(
                        "r_num",
                        queryParameter.RequiredSiwakeRowNoRange.Start,
                        queryParameter.RequiredSiwakeRowNoRange.End,
                        false);
                }
            }
            else
            {
                selectQuery.AppendLine(selectQuery1.GetSqlStatement(), selectQuery1.GetSqlParameters());
            }

            var syouhizeirituDictionary = this.syouhizeirituRepository.FindAllAsSyouhizeirituDictionary();
            return this.dbc.QueryForList(
                selectQuery.GetSqlStatement(),
                (values, no) =>
                {
                    return createRow(values, no, queryParameter, syouhizeirituDictionary);
                },
                craeteList,
                selectQuery.GetSqlParameters());
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目が多いため、分割困難")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1809:AvoidExcessiveLocals", Justification = "項目が多いため、分割困難")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため、分割困難")]
        private TanituSiwakeTyouhyouRow MapRow(object[] values, int no, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetDenpyou, SyouhizeirituDictionary syouhizeirituDictionary)
        {
            var row = new TanituSiwakeTyouhyouRow(queryParameter.Kesn, (short)values[0], (int)values[1], queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled ? (int)values[2] : 0);
            var i = queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled ? 3 : 2;
            row.DenpyouDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 伝票日付
            i++;
            row.DenpyouNo = DbNullConverter.ToNullableInt(values[i++]); // 伝票番号
            row.UketukeNo = (int)values[i++]; // 受付番号

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouItemEnabled)
            {
                row.IsMikanDenpyou = (short)values[i++] == 1; // 未完伝票かどうか
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouDateEnabled)
            {
                row.KihyouDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 起票日
                i++;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouBumonEnabled)
            {
                row.KihyouBumonCode = DbNullConverter.ToString(values[i++]); // 起票部門コード
                row.DenpyouItemNotInputCheckResult.IsKihyouBumonNotInput = queryParameter.IsUseNotInputCheckOptionForGetSiwakeTyouhyou
                    ? string.IsNullOrEmpty(row.KihyouBumonCode) && queryParameter.DenpyouInputAndSyuuseiOption.CheckKihyoBumonInputted && queryParameter.NotInputCheckOption.IsUseKihyouBumonNotInputCheck
                    : string.IsNullOrEmpty(row.KihyouBumonCode) && queryParameter.NotInputCheckOption.IsUseKihyouBumonNotInputCheck; // 起票部門未入力チェック結果
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouTantousyaEnabled)
            {
                row.KihyouTantousyaCode = DbNullConverter.ToString(values[i++]); // 起票者コード
                row.DenpyouItemNotInputCheckResult.IsKihyouTantousyaNotInput = queryParameter.IsUseNotInputCheckOptionForGetSiwakeTyouhyou
                    ? string.IsNullOrEmpty(row.KihyouTantousyaCode) && queryParameter.DenpyouInputAndSyuuseiOption.CheckKihyosyaInputted && queryParameter.NotInputCheckOption.IsUseKihyouTantousyaNotInputCheck
                    : string.IsNullOrEmpty(row.KihyouTantousyaCode) && queryParameter.NotInputCheckOption.IsUseKihyouTantousyaNotInputCheck; // 起票者未入力チェック結果
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled)
            {
                row.DenpyouCreateDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 伝票作成日
                i++;
                row.DenpyouCreateUserCode = (int)values[i++]; // 伝票作成者コード
                row.DenpyouUpdateDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 伝票更新日
                i++;
                row.DenpyouUpdateUserCode = (int)values[i++]; // 伝票更新者コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled)
            {
                row.InputKakuteiDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 入力確定日
                i++;
                row.SyouninGroupNo = (int)values[i++]; // 承認グループNo
                row.HanteizumiTopSyouninUserOrder = (short)values[i++]; // 判定済最上位承認者順序
                row.SyouninStatus = (SyouninStatus)(short)values[i++]; // 承認状況
                row.Dai1SyouninsyaUserCode = (int)values[i++]; // 第一承認者コード
                row.Dai1SyouninStatus = (SyouninStatus)(short)values[i++]; // 第一承認判定
                row.Dai2SyouninsyaUserCode = (int)values[i++]; // 第二承認者コード
                row.Dai2SyouninStatus = (SyouninStatus)(short)values[i++]; // 第二承認判定
                row.Dai3SyouninsyaUserCode = (int)values[i++]; // 第三承認者コード
                row.Dai3SyouninStatus = (SyouninStatus)(short)values[i++]; // 第三承認判定
                row.Dai4SyouninsyaUserCode = (int)values[i++]; // 第四承認者コード
                row.Dai4SyouninStatus = (SyouninStatus)(short)values[i++]; // 第四承認判定
                row.Dai5SyouninsyaUserCode = (int)values[i++]; // 第五承認者コード
                row.Dai5SyouninStatus = (SyouninStatus)(short)values[i++]; // 第五承認判定
                row.Dai6SyouninsyaUserCode = (int)values[i++]; // 第六承認者コード
                row.Dai6SyouninStatus = (SyouninStatus)(short)values[i++]; // 第六承認判定
                row.Dai7SyouninsyaUserCode = (int)values[i++]; // 第七承認者コード
                row.Dai7SyouninStatus = (SyouninStatus)(short)values[i++]; // 第七承認判定
                row.Dai8SyouninsyaUserCode = (int)values[i++]; // 第八承認者コード
                row.Dai8SyouninStatus = (SyouninStatus)(short)values[i++]; // 第八承認判定
                row.Dai9SyouninsyaUserCode = (int)values[i++]; // 第九承認者コード
                row.Dai9SyouninStatus = (SyouninStatus)(short)values[i++]; // 第九承認判定
                row.Dai10SyouninsyaUserCode = (int)values[i++]; // 第十承認者コード
                row.Dai10SyouninStatus = (SyouninStatus)(short)values[i++]; // 第十承認判定
            }

            //// ヘッダーフィールド
            for (int headerFieldNo = 1; headerFieldNo <= 10; headerFieldNo++)
            {
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetHeaderFieldEnabled(headerFieldNo))
                {
                    row.SetHeaderFieldCode(headerFieldNo, DbNullConverter.ToString(values[i++]));
                }
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled)
            {
                row.SiwakeParentChildRelated = (SiwakeParentChildRelated)(short)values[i++]; // 親子フラグ
                row.BunriKubun = (BunriKubun)(short)values[i++]; // 分離区分
                row.GroupNo = DbNullConverter.ToNullableInt(values[i++]); // グループ番号
                i++; // 伝票頁は取得不要
                row.LineNo = DbNullConverter.ToNullableInt(values[i++]); // 行番号
                row.SiwakeTaisyakuZokusei = (SiwakeTaisyakuZokusei)(short)values[i++]; // 貸借属性
                row.IsInputTaikaKingaku = (short)values[i++] == 1; // 対価入力フラグ
                row.IkkatuZeinukiSiwakeFlag = (IkkatuZeinukiSiwakeFlag)(short)values[i++]; // 一括税抜仕訳フラグ
                row.IsTorikesiSiwake = (short)values[i++] == 1; // 取消仕訳かどうか
                row.TaisyakuTekiyouFlag = (TaisyakuTekiyouFlag)(short)values[i++]; // 貸借摘要フラグ
                row.IsHininSiwake = (short)values[i++] == 1; // 否認仕訳かどうか
            }
            else
            {
                row.TaisyakuTekiyouFlag = TaisyakuTekiyouFlag.TaisyakuCommonTekiyou;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonEnabled)
            {
                row.KarikataDetail.Bcod = DbNullConverter.ToString(values[i++]);  // 借方部門コード
                row.KasikataDetail.Bcod = DbNullConverter.ToString(values[i++]);  // 貸方部門コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TorihikisakiEnabled)
            {
                row.KarikataDetail.Trcd = DbNullConverter.ToString(values[i++]);  // 借方取引先コード
                row.KasikataDetail.Trcd = DbNullConverter.ToString(values[i++]);  // 貸方取引先コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuEnabled)
            {
                row.KarikataDetail.Kicd = DbNullConverter.ToString(values[i++]);  // 借方科目内部コード
                row.KasikataDetail.Kicd = DbNullConverter.ToString(values[i++]);  // 貸方科目内部コード
                row.KarikataDetail.IsSyokutiKamoku = DbNullConverter.ToString(row.KarikataDetail.Kicd)?.StartsWith("000") ?? false; // 借方が諸口科目かどうか
                row.KasikataDetail.IsSyokutiKamoku = DbNullConverter.ToString(row.KasikataDetail.Kicd)?.StartsWith("000") ?? false; // 貸方が諸口科目かどうか
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.EdabanEnabled)
            {
                row.KarikataDetail.Ecod = DbNullConverter.ToString(values[i++]);  // 借方枝番コード
                row.KasikataDetail.Ecod = DbNullConverter.ToString(values[i++]);  // 貸方枝番コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KouziEnabled)
            {
                row.KarikataDetail.Kzcd = DbNullConverter.ToString(values[i++]); // 借方工事コード
                row.KasikataDetail.Kzcd = DbNullConverter.ToString(values[i++]); // 貸方工事コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KousyuEnabled)
            {
                row.KarikataDetail.Kscd = DbNullConverter.ToString(values[i++]); // 借方工種コード
                row.KasikataDetail.Kscd = DbNullConverter.ToString(values[i++]); // 貸方工種コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.ProjectEnabled)
            {
                row.KarikataDetail.Pjcd = DbNullConverter.ToString(values[i++]); // 借方プロジェクトコード
                row.KasikataDetail.Pjcd = DbNullConverter.ToString(values[i++]); // 貸方プロジェクトコード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SegmentEnabled)
            {
                row.KarikataDetail.Sgcd = DbNullConverter.ToString(values[i++]); // 借方セグメントコード
                row.KasikataDetail.Sgcd = DbNullConverter.ToString(values[i++]); // 貸方セグメントコード
            }

            //// ユニバーサルフィールド
            for (int universalFieldNo = 1; universalFieldNo <= 20; universalFieldNo++)
            {
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetUniversalFieldEnabled(universalFieldNo))
                {
                    row.KarikataDetail.SetUniversalFieldCode(universalFieldNo, DbNullConverter.ToString(values[i++]));
                    row.KasikataDetail.SetUniversalFieldCode(universalFieldNo, DbNullConverter.ToString(values[i++]));
                }
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KingakuItemEnabled)
            {
                row.TaikaKingaku = (decimal)values[i++]; // 対価金額
                row.ZeikomiKingaku = (decimal)values[i++]; // 税込金額
                row.Kingaku = (decimal)values[i++]; // 金額
            }

            var latestSyouhizeiritu = syouhizeirituDictionary.GetLatestSyouhizeiritu(row.DenpyouDate, false);
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouhizeiItemEnabled)
            {
                row.SyouhizeiTaisyouKicd = DbNullConverter.ToString(values[i++]);
                if (!string.IsNullOrEmpty(row.SyouhizeiTaisyouKicd))
                {
                    row.SyouhizeiTaisyouKamokuSyouhizeiritu = !DbNullConverter.IsNull(values[i])
                        ? syouhizeirituDictionary.GetValue(new Percentage(DbNullConverter.ToInt(values[i], 0) / 10000), (short)values[i + 1] == 1)
                        : null; // 税対象科目 税率
                    i += 2;
                    row.IsLatestSyouhizeiTaisyouKamokuSyouhizeirituBeforeDenpyouDate = row.SyouhizeiTaisyouKamokuSyouhizeiritu?.Id == latestSyouhizeiritu.Id; // 伝票日付以前の最新の税対象科目税率かどうか
                    row.SyouhizeiTaisyouKamokuKazeiKubun = (KazeiKubun)(short)values[i++]; // 税対象科目 課税区分
                    row.SyouhizeiTaisyouKamokuGyousyuKubun = (GyousyuKubun)(short)values[i++]; // 税対象科目 業種区分
                    row.SyouhizeiTaisyouKamokuSiireKubun = (SiwakeSiireKubun)(short)values[i++]; // 税対象科目 仕入区分
                }
                else
                {
                    //// 税対象科目が空の場合、税区分を設定しない
                    i += 5;
                }
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.ZeiKubunItemEnabled)
            {
                row.KarikataDetail.Syouhizeiritu = !DbNullConverter.IsNull(values[i])
                    ? syouhizeirituDictionary.GetValue(new Percentage(DbNullConverter.ToInt(values[i], 0) / 10000), (short)values[i + 1] == 1)
                    : null; // 借方税率
                i += 2;
                row.KarikataDetail.IsLatestSyouhizeirituBeforeDenpyouDate = row.KarikataDetail.Syouhizeiritu?.Id == latestSyouhizeiritu.Id; // 伝票日付以前の最新の借方税率かどうか
                row.KarikataDetail.KazeiKubun = (KazeiKubun)(short)values[i++]; // 借方課税区分
                row.KarikataDetail.GyousyuKubun = (GyousyuKubun)(short)values[i++]; // 借方業種区分
                row.KarikataDetail.SiwakeSiireKubun = (SiwakeSiireKubun)(short)values[i++]; // 借方仕入区分
                row.KasikataDetail.Syouhizeiritu = !DbNullConverter.IsNull(values[i])
                    ? syouhizeirituDictionary.GetValue(new Percentage(DbNullConverter.ToInt(values[i], 0) / 10000), (short)values[i + 1] == 1)
                    : null; // 貸方税率
                i += 2;
                row.KasikataDetail.IsLatestSyouhizeirituBeforeDenpyouDate = row.KasikataDetail.Syouhizeiritu?.Id == latestSyouhizeiritu.Id; // 伝票日付以前の最新の貸方税率かどうか
                row.KasikataDetail.KazeiKubun = (KazeiKubun)(short)values[i++]; // 貸方課税区分
                row.KasikataDetail.GyousyuKubun = (GyousyuKubun)(short)values[i++]; // 貸方業種区分
                row.KasikataDetail.SiwakeSiireKubun = (SiwakeSiireKubun)(short)values[i++]; // 貸方仕入区分
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled)
            {
                row.KarikataDetail.Tekiyou = DbNullConverter.ToString(values[i++]); // 借方摘要
                row.KasikataDetail.Tekiyou = DbNullConverter.ToString(values[i++]); // 貸方摘要
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled)
            {
                row.KarikataDetail.TekiyouCode = DbNullConverter.ToNullableShort(values[i++]); // 借方摘要コード
                row.KasikataDetail.TekiyouCode = DbNullConverter.ToNullableShort(values[i++]); // 貸方摘要コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiDateEnabled)
            {
                row.SiharaiDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 支払日
                i++;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiKubunEnabled)
            {
                row.SiharaiKubunCode = DbNullConverter.ToNullableShort(values[i++]); // 支払区分コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiKizituEnabled)
            {
                row.SiharaiKizitu = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 支払期日
                i++;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KaisyuuDateEnabled)
            {
                row.KaisyuuDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 回収日
                i++;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.NyuukinKubunEnabled)
            {
                row.NyuukinKubunCode = DbNullConverter.ToNullableShort(values[i++]); // 入金区分コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KaisyuuKizituEnabled)
            {
                row.KaisyuuKizitu = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 回収期日
                i++;
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KesikomiCodeEnabled)
            {
                row.KesikomiCode = DbNullConverter.ToString(values[i++]); // 消込コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled)
            {
                row.SiwakeCreateDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 仕訳作成日
                i++;
                row.SiwakeCreateUserCode = (int)values[i++]; // 仕訳作成者コード
                row.SiwakeUpdateDate = (int)values[i] > 0 ? new IcspDateTime((int)values[i], queryParameter.KaisyaSyoriKikan.Syoriki.Gengou) : null; // 仕訳更新日
                i++;
                row.SiwakeUpdateTime = (int)values[i++]; // 仕訳更新時間
                row.SiwakeUpdateUserCode = (int)values[i++]; // 仕訳更新者コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeHusenEnabled)
            {
                row.SiwakeHusen = (SiwakeHusen)(short)values[i++]; // 仕訳の付箋
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled)
            {
                row.KarikataDetail.HeisyuCode = DbNullConverter.ToString(values[i++]); // 借方通貨コード
                row.KasikataDetail.HeisyuCode = DbNullConverter.ToString(values[i++]); // 貸方通貨コード
                row.Rate = (decimal)values[i++]; // レート
                row.GaikaKingaku = (decimal)values[i++]; // 外貨金額
                row.GaikaTaikaKingaku = (decimal)values[i++]; // 外貨対価金額
                row.GaikaZeikomiKingaku = (decimal)values[i++]; // 外貨税込金額
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaKansanSiwakeFlagEnabled)
                {
                    row.GaikaKansanSiwakeFlag = (GaikaKansanSiwakeFlag)(short)values[i++]; // 外貨換算仕訳フラグ
                }
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled)
            {
                row.DenpyouTabaCode = DbNullConverter.ToString(values[i++]); // 伝票束コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled)
            {
                row.KarikataDetail.Sbcd = DbNullConverter.ToString(values[i++]); // 借方集計部門コード
                row.KasikataDetail.Sbcd = DbNullConverter.ToString(values[i++]); // 貸方集計部門コード
            }

            if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled)
            {
                row.KarikataDetail.HeisyuName = DbNullConverter.ToString(values[i++]); // 借方単位名称
                row.KarikataDetail.HeisyuUsingCountryName = DbNullConverter.ToString(values[i++]); // 借方幣種使用国名
                row.KarikataDetail.HeisyuDecimalPartKetaCount = DbNullConverter.ToNullableShort(values[i++]); // 借方幣種小数部桁数
                row.KasikataDetail.HeisyuName = DbNullConverter.ToString(values[i++]); // 貸方単位名称
                row.KasikataDetail.HeisyuUsingCountryName = DbNullConverter.ToString(values[i++]); // 貸方幣種使用国名
                row.KasikataDetail.HeisyuDecimalPartKetaCount = DbNullConverter.ToNullableShort(values[i++]); // 貸方幣種小数部桁数
            }

            //// その他項目
            row.IsMitenkiData = (int)values[i++] == 1; // 未転記データかどうか
            if (queryParameter.FromHonsitenTenkaiSiwake)
            {
                //// テンポラリテーブルから仕訳取得時、本支店展開関連のカラムも取得
                row.SseqBeforeHonsitenTenkai = (int)values[i++]; // 本支店展開前の仕訳SEQNo.
                row.KarikataDetail.HonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[i++]; // 借方本支店勘定設定フラグ
                row.KarikataDetail.IsInputedBumon = (int)values[i++] == 1; // 借方部門が入力されているかどうか
                row.KarikataDetail.IsRegisteredBumonToHonsitenTenkaiMeisaiTable = (int)values[i++] == 1; // 本支店展開明細テーブル（hstbl_m）に、借方部門が登録されているかどうか
                row.KarikataDetail.IsRegisteredBumonKamokuToBumonKamokuZandakaTable = (int)values[i++] == 1; // 部門科目残高テーブル（bkzan）に、借方部門科目が登録されているかどうか
                row.KasikataDetail.HonsitenKanzyouSetFlag = (HonsitenKanzyouSetFlag)(int)values[i++]; // 貸方本支店勘定設定フラグ
                row.KasikataDetail.IsInputedBumon = (int)values[i++] == 1; // 貸方部門が入力されているかどうか
                row.KasikataDetail.IsRegisteredBumonToHonsitenTenkaiMeisaiTable = (int)values[i++] == 1; // 本支店展開明細テーブル（hstbl_m）に、貸方部門が登録されているかどうか
                row.KasikataDetail.IsRegisteredBumonKamokuToBumonKamokuZandakaTable = (int)values[i++] == 1; // 部門科目残高テーブル（bkzan）に、貸方部門科目が登録されているかどうか
            }

            return row;
        }

        /// <summary>
        /// マスター、及びセキュリティ関連の値を設定します
        /// </summary>
        /// <param name="siwakeTyouhyouRows">仕訳帳票行リスト</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目が多いため、分割困難")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため、分割困難")]
        private void SetMasterAndSecurityRelatedValue(IList<object> siwakeTyouhyouRows, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var securityPermittedCodeRepositoryCache = new SecurityPermittedCodeRepositoryCache(this.container, SecurityKubun.Output, queryParameter.SecurityContext);
            var masterNameRepositoryCache = new MasterNameRepositoryCache(this.container);
            var masterRepositoryCache = new MasterRepositoryCache(this.container);
            foreach (TanituSiwakeTyouhyouRow row in siwakeTyouhyouRows)
            {
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouBumonEnabled)
                {
                    row.KihyouBumonName = masterNameRepositoryCache.GetBumonNameByKesnAndCode(queryParameter.Kesn, row.KihyouBumonCode, BumonFindType.Both); // 起票部門名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouTantousyaEnabled)
                {
                    row.KihyouTantousyaName = masterNameRepositoryCache.GetTantouNameByCode(row.KihyouTantousyaCode); // 起票者名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled)
                {
                    row.DenpyouCreateUserName = masterNameRepositoryCache.GetUserNameByCode(row.DenpyouCreateUserCode); // 伝票作成者名称
                    row.DenpyouUpdateUserName = masterNameRepositoryCache.GetUserNameByCode(row.DenpyouUpdateUserCode); // 伝票更新者名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled)
                {
                    row.Dai1SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai1SyouninsyaUserCode); // 第一承認者名称
                    row.Dai2SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai2SyouninsyaUserCode); // 第二承認者名称
                    row.Dai3SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai3SyouninsyaUserCode); // 第三承認者名称
                    row.Dai4SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai4SyouninsyaUserCode); // 第四承認者名称
                    row.Dai5SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai5SyouninsyaUserCode); // 第五承認者名称
                    row.Dai6SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai6SyouninsyaUserCode); // 第六承認者名称
                    row.Dai7SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai7SyouninsyaUserCode); // 第七承認者名称
                    row.Dai8SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai8SyouninsyaUserCode); // 第八承認者名称
                    row.Dai9SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai9SyouninsyaUserCode); // 第九承認者名称
                    row.Dai10SyouninsyaUserName = masterNameRepositoryCache.GetUserNameByCode(row.Dai10SyouninsyaUserCode); // 第十承認者名称
                }

                //// ヘッダーフィールド
                for (int headerFieldNo = 1; headerFieldNo <= 10; headerFieldNo++)
                {
                    if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetHeaderFieldEnabled(headerFieldNo))
                    {
                        this.SetHeaderFieldValue(row, headerFieldNo, queryParameter, masterNameRepositoryCache);
                    }
                }

                var karikataKamoku = masterRepositoryCache.FindKamokuByKesnAndKicd(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn, row.KarikataDetail?.Kicd);
                var kasikataKamoku = masterRepositoryCache.FindKamokuByKesnAndKicd(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn, row.KasikataDetail?.Kicd);
                var codeAndNameSetterWithSecurity = new TanituSiwakeTyouhyouRowMasterAndTekiyouSetterWithSecurity(queryParameter.Kesn, queryParameter.SecurityContext, securityPermittedCodeRepositoryCache, masterNameRepositoryCache);
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonEnabled)
                {
                    codeAndNameSetterWithSecurity.SetBumonCodeAndName(row, row.KarikataDetail?.Bcod, true, queryParameter);  // 借方部門コード・名称
                    codeAndNameSetterWithSecurity.SetBumonCodeAndName(row, row.KasikataDetail?.Bcod, false, queryParameter);  // 貸方部門コード・名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsBumonNotInput = !string.IsNullOrEmpty(row.KarikataDetail.Kicd) && string.IsNullOrEmpty(row.KarikataDetail.Bcod) && karikataKamoku.IsUseBumonNotInputCheck && queryParameter.NotInputCheckOption.IsUseBumonNotInputCheck; // 借方部門未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsBumonNotInput = !string.IsNullOrEmpty(row.KasikataDetail.Kicd) && string.IsNullOrEmpty(row.KasikataDetail.Bcod) && kasikataKamoku.IsUseBumonNotInputCheck && queryParameter.NotInputCheckOption.IsUseBumonNotInputCheck; // 貸方部門未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.TorihikisakiEnabled)
                {
                    codeAndNameSetterWithSecurity.SetTorihikisakiCodeAndName(row, row.KarikataDetail?.Trcd, true, queryParameter); // 借方取引先コード・名称
                    codeAndNameSetterWithSecurity.SetTorihikisakiCodeAndName(row, row.KasikataDetail?.Trcd, false, queryParameter); // 貸方取引先コード・名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsTorihikisakiNotInput = !string.IsNullOrEmpty(row.KarikataDetail.Kicd) && string.IsNullOrEmpty(row.KarikataDetail.Trcd) && karikataKamoku.IsUseTorihikisakiNotInputCheck && queryParameter.NotInputCheckOption.IsUseTorihikisakiNotInputCheck; // 借方取引先未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsTorihikisakiNotInput = !string.IsNullOrEmpty(row.KasikataDetail.Kicd) && string.IsNullOrEmpty(row.KasikataDetail.Trcd) && kasikataKamoku.IsUseTorihikisakiNotInputCheck && queryParameter.NotInputCheckOption.IsUseTorihikisakiNotInputCheck; // 貸方取引先未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuEnabled)
                {
                    codeAndNameSetterWithSecurity.SetKamokuKicdAndKcodAndName(row, karikataKamoku, true, queryParameter); // 借方科目内部コード・入力コード・名称
                    codeAndNameSetterWithSecurity.SetKamokuKicdAndKcodAndName(row, kasikataKamoku, false, queryParameter); // 貸方科目内部コード・入力コード・名称
                    row.KarikataDetail.KamokuSyoriGroup = karikataKamoku.SyoriGroup; // 借方科目処理グループ
                    row.KasikataDetail.KamokuSyoriGroup = kasikataKamoku.SyoriGroup; // 貸方科目処理グループ
                    row.KarikataDetail.IsInputTaikaKingakuKamoku = karikataKamoku.AllowUseTaika; // 借方科目が対価金額入力可能であるかどうか
                    row.KasikataDetail.IsInputTaikaKingakuKamoku = kasikataKamoku.AllowUseTaika; // 貸方科目が対価金額入力可能であるかどうか
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.EdabanEnabled)
                {
                    codeAndNameSetterWithSecurity.SetEdabanCodeAndName(row, row.KarikataDetail?.Kicd, row.KarikataDetail?.Ecod, true, queryParameter); // 借方枝番コード・名称
                    codeAndNameSetterWithSecurity.SetEdabanCodeAndName(row, row.KasikataDetail?.Kicd, row.KasikataDetail?.Ecod, false, queryParameter); // 貸方枝番コード・名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsEdabanNotInput = !string.IsNullOrEmpty(row.KarikataDetail.Kicd) && string.IsNullOrEmpty(row.KarikataDetail.Ecod) && karikataKamoku.IsUseEdabanNotInputCheck && queryParameter.NotInputCheckOption.IsUseEdabanNotInputCheck; // 借方枝番未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsEdabanNotInput = !string.IsNullOrEmpty(row.KasikataDetail.Kicd) && string.IsNullOrEmpty(row.KasikataDetail.Ecod) && kasikataKamoku.IsUseEdabanNotInputCheck && queryParameter.NotInputCheckOption.IsUseEdabanNotInputCheck; // 貸方枝番未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KouziEnabled)
                {
                    row.KarikataDetail.KouziName = masterNameRepositoryCache.GetKouziNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Kzcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseKouziLongName); // 借方工事名称
                    row.KasikataDetail.KouziName = masterNameRepositoryCache.GetKouziNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Kzcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseKouziLongName); // 貸方工事名称
                    row.KarikataDetail.KouziLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.KouziLongNameEnabled ? masterNameRepositoryCache.GetKouziLongNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Kzcd) : string.Empty; // 借方工事正式名称
                    row.KasikataDetail.KouziLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.KouziLongNameEnabled ? masterNameRepositoryCache.GetKouziLongNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Kzcd) : string.Empty; // 貸方工事正式名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsKouziNotInput = string.IsNullOrEmpty(row.KarikataDetail.Kzcd) && karikataKamoku.IsUseKouziNotInputCheck && queryParameter.NotInputCheckOption.IsUseKouziNotInputCheck; // 借方工事未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsKouziNotInput = string.IsNullOrEmpty(row.KasikataDetail.Kzcd) && kasikataKamoku.IsUseKouziNotInputCheck && queryParameter.NotInputCheckOption.IsUseKouziNotInputCheck; // 貸方工事未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KousyuEnabled)
                {
                    row.KarikataDetail.KousyuName = masterNameRepositoryCache.GetKousyuNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Kscd); // 借方工種名称
                    row.KasikataDetail.KousyuName = masterNameRepositoryCache.GetKousyuNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Kscd); // 貸方工種名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsKousyuNotInput = string.IsNullOrEmpty(row.KarikataDetail.Kscd) && karikataKamoku.IsUseKousyuNotInputCheck && queryParameter.NotInputCheckOption.IsUseKousyuNotInputCheck; // 借方工種未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsKousyuNotInput = string.IsNullOrEmpty(row.KasikataDetail.Kscd) && kasikataKamoku.IsUseKousyuNotInputCheck && queryParameter.NotInputCheckOption.IsUseKousyuNotInputCheck; // 貸方工種未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.ProjectEnabled)
                {
                    row.KarikataDetail.ProjectName = masterNameRepositoryCache.GetProjectNameByCode(row.KarikataDetail.Pjcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseProjectLongName); // 借方プロジェクト名称
                    row.KasikataDetail.ProjectName = masterNameRepositoryCache.GetProjectNameByCode(row.KasikataDetail.Pjcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseProjectLongName); // 貸方プロジェクト名称
                    row.KarikataDetail.ProjectLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.ProjectLongNameEnabled ? masterNameRepositoryCache.GetProjectLongNameByCode(row.KarikataDetail.Pjcd) : string.Empty; // 借方プロジェクト正式名称
                    row.KasikataDetail.ProjectLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.ProjectLongNameEnabled ? masterNameRepositoryCache.GetProjectLongNameByCode(row.KasikataDetail.Pjcd) : string.Empty; // 貸方プロジェクト正式名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsProjectNotInput = string.IsNullOrEmpty(row.KarikataDetail.Pjcd) && karikataKamoku.IsUseProjectNotInputCheck && queryParameter.NotInputCheckOption.IsUseProjectNotInputCheck; // 借方プロジェクト未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsProjectNotInput = string.IsNullOrEmpty(row.KasikataDetail.Pjcd) && kasikataKamoku.IsUseProjectNotInputCheck && queryParameter.NotInputCheckOption.IsUseProjectNotInputCheck; // 貸方プロジェクト未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.SegmentEnabled)
                {
                    row.KarikataDetail.SegmentName = masterNameRepositoryCache.GetSegmentNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Sgcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseSegmentLongName); // 借方セグメント名称
                    row.KasikataDetail.SegmentName = masterNameRepositoryCache.GetSegmentNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Sgcd, !queryParameter.SiwakeTyouhyouRowItemAvailability.UseSegmentLongName); // 貸方セグメント名称
                    row.KarikataDetail.SegmentLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.SegmentLongNameEnabled ? masterNameRepositoryCache.GetSegmentLongNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Sgcd) : string.Empty; // 借方セグメント正式名称
                    row.KasikataDetail.SegmentLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.SegmentLongNameEnabled ? masterNameRepositoryCache.GetSegmentLongNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Sgcd) : string.Empty; // 貸方セグメント正式名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsSegmentNotInput = string.IsNullOrEmpty(row.KarikataDetail.Sgcd) && karikataKamoku.IsUseSegmentNotInputCheck && queryParameter.NotInputCheckOption.IsUseSegmentNotInputCheck; // 借方セグメント未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsSegmentNotInput = string.IsNullOrEmpty(row.KasikataDetail.Sgcd) && kasikataKamoku.IsUseSegmentNotInputCheck && queryParameter.NotInputCheckOption.IsUseSegmentNotInputCheck; // 貸方セグメント未入力チェック結果
                }

                //// ユニバーサルフィールド
                for (int universalFieldNo = 1; universalFieldNo <= 20; universalFieldNo++)
                {
                    if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetUniversalFieldEnabled(universalFieldNo))
                    {
                        this.SetUniversalFieldCodeAndName(row.KarikataDetail, universalFieldNo, queryParameter, masterNameRepositoryCache);
                        this.SetUniversalFieldCodeAndName(row.KasikataDetail, universalFieldNo, queryParameter, masterNameRepositoryCache);
                        row.KarikataDetail.SiwakeItemNotInputCheckResult.SetIsUniversalFieldNotInput(universalFieldNo, row.KarikataDetail.GetUniversalFieldCode(universalFieldNo), karikataKamoku.GetIsUseUniversalFieldNotInputCheck(universalFieldNo), queryParameter.NotInputCheckOption);
                        row.KasikataDetail.SiwakeItemNotInputCheckResult.SetIsUniversalFieldNotInput(universalFieldNo, row.KasikataDetail.GetUniversalFieldCode(universalFieldNo), kasikataKamoku.GetIsUseUniversalFieldNotInputCheck(universalFieldNo), queryParameter.NotInputCheckOption);
                    }
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled)
                {
                    row.KarikataDetail.TekiyouName = row.KarikataDetail.TekiyouCode != null
                        ? masterNameRepositoryCache.GetZiyuuTekiyouNameByKesnAndCode(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn, (int)row.KarikataDetail.TekiyouCode) : default(string); // 借方摘要名称
                    row.KasikataDetail.TekiyouName = row.KasikataDetail.TekiyouCode != null
                        ? masterNameRepositoryCache.GetZiyuuTekiyouNameByKesnAndCode(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn, (int)row.KasikataDetail.TekiyouCode) : default(string); // 貸方摘要名称
                    row.KarikataDetail.SiwakeItemNotInputCheckResult.IsTekiyouCodeNotInput = row.KarikataDetail.TekiyouCode == null && karikataKamoku.IsUseTekiyouCodeNotInputCheck && queryParameter.NotInputCheckOption.IsUseTekiyouCodeNotInputCheck; // 借方摘要コード未入力チェック結果
                    row.KasikataDetail.SiwakeItemNotInputCheckResult.IsTekiyouCodeNotInput = row.KasikataDetail.TekiyouCode == null && kasikataKamoku.IsUseTekiyouCodeNotInputCheck && queryParameter.NotInputCheckOption.IsUseTekiyouCodeNotInputCheck; // 貸方摘要コード未入力チェック結果
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.KesikomiCodeEnabled)
                {
                    row.KarikataDetail.IsKesikomiTaisyouKamoku = karikataKamoku.AllowUseKesikomiCode; // 借方科目が消し込み対象であるかどうか
                    row.KasikataDetail.IsKesikomiTaisyouKamoku = kasikataKamoku.AllowUseKesikomiCode; // 貸方科目が消し込み対象であるかどうか
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouhizeiItemEnabled)
                {
                    var syouhizeiTaisyouKamoku = masterRepositoryCache.FindKamokuByKesnAndKicd(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn, row.SyouhizeiTaisyouKicd);
                    codeAndNameSetterWithSecurity.SetSyouhizeiTaisyouKamokuKicdAndName(row, syouhizeiTaisyouKamoku, queryParameter); // 税対象科目 科目内部コード・名称
                    row.SyouhizeiTaisyouKcod = syouhizeiTaisyouKamoku?.Kcod; // 税対象科目 科目入力コード
                    row.SyouhizeiTaisyouKamokuSyoriGroup = syouhizeiTaisyouKamoku?.SyoriGroup ?? default(KamokuSyoriGroup); // 税対象科目 処理グループ
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled)
                {
                    codeAndNameSetterWithSecurity.SetTekiyou(row, row.KarikataDetail?.Tekiyou, row.KasikataDetail?.Tekiyou, queryParameter); // 借方摘要・貸方摘要
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled)
                {
                    row.SiwakeCreateUserName = masterNameRepositoryCache.GetUserNameByCode(row.SiwakeCreateUserCode); // 仕訳作成者名称
                    row.SiwakeUpdateUserName = masterNameRepositoryCache.GetUserNameByCode(row.SiwakeUpdateUserCode); // 仕訳更新者名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiKubunEnabled)
                {
                    row.SiharaiKubunName = row.SiharaiKubunCode != null
                        ? masterNameRepositoryCache.GetSiharaiNyuukinKubunNameBySiharaiNyuukinTypeAndKubunNo(SiharaiNyuukinType.SiharaiKubun, (int)row.SiharaiKubunCode) : default(string); // 支払区分名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.NyuukinKubunEnabled)
                {
                    row.NyuukinKubunName = row.NyuukinKubunCode != null
                        ? masterNameRepositoryCache.GetSiharaiNyuukinKubunNameBySiharaiNyuukinTypeAndKubunNo(SiharaiNyuukinType.NyuukinKubun, (int)row.NyuukinKubunCode) : default(string); // 入金区分名称
                }

                if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled)
                {
                    row.KarikataDetail.SyuukeiBumonName = masterNameRepositoryCache.GetBumonNameByKesnAndCode(queryParameter.Kesn, row.KarikataDetail.Sbcd, BumonFindType.OnlySyuukeiBumon); // 借方集計部門名称
                    row.KasikataDetail.SyuukeiBumonName = masterNameRepositoryCache.GetBumonNameByKesnAndCode(queryParameter.Kesn, row.KasikataDetail.Sbcd, BumonFindType.OnlySyuukeiBumon); // 貸方集計部門名称
                }

                if (queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake
                    && queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other)
                {
                    codeAndNameSetterWithSecurity.SetIsNotDisplayableSiwake(row);
                }
            }
        }

        /// <summary>
        /// ヘッダーフィールドの値を設定します。
        /// </summary>
        /// <param name="row">単一仕訳帳票の行データ</param>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="masterNameRepositoryCache">マスター名称のリポジトリキャッシュ</param>
        private void SetHeaderFieldValue(TanituSiwakeTyouhyouRow row, int no, ISiwakeTyouhyouQueryParameter queryParameter, MasterNameRepositoryCache masterNameRepositoryCache)
        {
            var headerFieldCodeFormat = new UniversalFieldCodeFormat();
            var hfcd = !string.IsNullOrEmpty(row.GetHeaderFieldCode(no))
                ? headerFieldCodeFormat.GetFormattedIOValue(row.GetHeaderFieldCode(no), queryParameter.KaisyaSyoriKikan.Syoriki.GetUniversalFieldInfo(true, no), queryParameter.KaisyaSyoriKikan.Syoriki.Gengou, true, null)
                : string.Empty;
            var headerFieldName = masterNameRepositoryCache.GetUniversalFieldShortNameByKesnAndCode(queryParameter.KaisyaSyoriKikan.Syoriki.GetUniversalFieldInfo(true, no), queryParameter.Kesn, row.GetHeaderFieldCode(no));

            row.DenpyouItemNotInputCheckResult.SetIsHeaderFieldNotInput(no, row.GetHeaderFieldCode(no), queryParameter);
            switch (no)
            {
                case 1:
                    row.Hfcd01 = hfcd;
                    row.HeaderField01Name = headerFieldName;
                    break;
                case 2:
                    row.Hfcd02 = hfcd;
                    row.HeaderField02Name = headerFieldName;
                    break;
                case 3:
                    row.Hfcd03 = hfcd;
                    row.HeaderField03Name = headerFieldName;
                    break;
                case 4:
                    row.Hfcd04 = hfcd;
                    row.HeaderField04Name = headerFieldName;
                    break;
                case 5:
                    row.Hfcd05 = hfcd;
                    row.HeaderField05Name = headerFieldName;
                    break;
                case 6:
                    row.Hfcd06 = hfcd;
                    row.HeaderField06Name = headerFieldName;
                    break;
                case 7:
                    row.Hfcd07 = hfcd;
                    row.HeaderField07Name = headerFieldName;
                    break;
                case 8:
                    row.Hfcd08 = hfcd;
                    row.HeaderField08Name = headerFieldName;
                    break;
                case 9:
                    row.Hfcd09 = hfcd;
                    row.HeaderField09Name = headerFieldName;
                    break;
                case 10:
                    row.Hfcd10 = hfcd;
                    row.HeaderField10Name = headerFieldName;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドコード及び名称を設定します。
        /// </summary>
        /// <param name="taisyakubetuDetail">単一仕訳帳票の貸借別データ</param>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="masterNameRepositoryCache">マスター名称のリポジトリキャッシュ</param>
        private void SetUniversalFieldCodeAndName(TanituSiwakeTyouhyouTaisyakubetuDetail taisyakubetuDetail, int no, ISiwakeTyouhyouQueryParameter queryParameter, MasterNameRepositoryCache masterNameRepositoryCache)
        {
            var universalFieldName =
                masterNameRepositoryCache.GetUniversalFieldNameByKesnAndCode(
                    queryParameter.KaisyaSyoriKikan.Syoriki.GetUniversalFieldInfo(false, no),
                    queryParameter.Kesn,
                    taisyakubetuDetail.GetUniversalFieldCode(no),
                    !queryParameter.SiwakeTyouhyouRowItemAvailability.GetUseUniversalFieldLongName(no));
            var universalFieldLongName = queryParameter.SiwakeTyouhyouRowItemAvailability.GetUniversalFieldLongNameEnabled(no)
                ? masterNameRepositoryCache.GetUniversalFieldLongNameByKesnAndCode(queryParameter.KaisyaSyoriKikan.Syoriki.GetUniversalFieldInfo(false, no), queryParameter.Kesn, taisyakubetuDetail.GetUniversalFieldCode(no))
                : string.Empty;
            var universalFieldCodeFormat = new UniversalFieldCodeFormat();
            var ufcd = !string.IsNullOrEmpty(taisyakubetuDetail.GetUniversalFieldCode(no))
                ? universalFieldCodeFormat.GetFormattedIOValue(taisyakubetuDetail.GetUniversalFieldCode(no), queryParameter.KaisyaSyoriKikan.Syoriki.GetUniversalFieldInfo(false, no), queryParameter.KaisyaSyoriKikan.Syoriki.Gengou, true, (date) => string.Format("{0}/{1:D2}/{2:D2}", date.Year, date.Month, date.Day))
                : string.Empty;
            switch (no)
            {
                case 1:
                    taisyakubetuDetail.Ufcd01 = ufcd;
                    taisyakubetuDetail.UniversalField01Name = universalFieldName;
                    taisyakubetuDetail.UniversalField01LongName = universalFieldLongName;
                    break;
                case 2:
                    taisyakubetuDetail.Ufcd02 = ufcd;
                    taisyakubetuDetail.UniversalField02Name = universalFieldName;
                    taisyakubetuDetail.UniversalField02LongName = universalFieldLongName;
                    break;
                case 3:
                    taisyakubetuDetail.Ufcd03 = ufcd;
                    taisyakubetuDetail.UniversalField03Name = universalFieldName;
                    taisyakubetuDetail.UniversalField03LongName = universalFieldLongName;
                    break;
                case 4:
                    taisyakubetuDetail.Ufcd04 = ufcd;
                    taisyakubetuDetail.UniversalField04Name = universalFieldName;
                    taisyakubetuDetail.UniversalField04LongName = universalFieldLongName;
                    break;
                case 5:
                    taisyakubetuDetail.Ufcd05 = ufcd;
                    taisyakubetuDetail.UniversalField05Name = universalFieldName;
                    taisyakubetuDetail.UniversalField05LongName = universalFieldLongName;
                    break;
                case 6:
                    taisyakubetuDetail.Ufcd06 = ufcd;
                    taisyakubetuDetail.UniversalField06Name = universalFieldName;
                    taisyakubetuDetail.UniversalField06LongName = universalFieldLongName;
                    break;
                case 7:
                    taisyakubetuDetail.Ufcd07 = ufcd;
                    taisyakubetuDetail.UniversalField07Name = universalFieldName;
                    taisyakubetuDetail.UniversalField07LongName = universalFieldLongName;
                    break;
                case 8:
                    taisyakubetuDetail.Ufcd08 = ufcd;
                    taisyakubetuDetail.UniversalField08Name = universalFieldName;
                    taisyakubetuDetail.UniversalField08LongName = universalFieldLongName;
                    break;
                case 9:
                    taisyakubetuDetail.Ufcd09 = ufcd;
                    taisyakubetuDetail.UniversalField09Name = universalFieldName;
                    taisyakubetuDetail.UniversalField09LongName = universalFieldLongName;
                    break;
                case 10:
                    taisyakubetuDetail.Ufcd10 = ufcd;
                    taisyakubetuDetail.UniversalField10Name = universalFieldName;
                    taisyakubetuDetail.UniversalField10LongName = universalFieldLongName;
                    break;
                case 11:
                    taisyakubetuDetail.Ufcd11 = ufcd;
                    taisyakubetuDetail.UniversalField11Name = universalFieldName;
                    taisyakubetuDetail.UniversalField11LongName = universalFieldLongName;
                    break;
                case 12:
                    taisyakubetuDetail.Ufcd12 = ufcd;
                    taisyakubetuDetail.UniversalField12Name = universalFieldName;
                    taisyakubetuDetail.UniversalField12LongName = universalFieldLongName;
                    break;
                case 13:
                    taisyakubetuDetail.Ufcd13 = ufcd;
                    taisyakubetuDetail.UniversalField13Name = universalFieldName;
                    taisyakubetuDetail.UniversalField13LongName = universalFieldLongName;
                    break;
                case 14:
                    taisyakubetuDetail.Ufcd14 = ufcd;
                    taisyakubetuDetail.UniversalField14Name = universalFieldName;
                    taisyakubetuDetail.UniversalField14LongName = universalFieldLongName;
                    break;
                case 15:
                    taisyakubetuDetail.Ufcd15 = ufcd;
                    taisyakubetuDetail.UniversalField15Name = universalFieldName;
                    taisyakubetuDetail.UniversalField15LongName = universalFieldLongName;
                    break;
                case 16:
                    taisyakubetuDetail.Ufcd16 = ufcd;
                    taisyakubetuDetail.UniversalField16Name = universalFieldName;
                    taisyakubetuDetail.UniversalField16LongName = universalFieldLongName;
                    break;
                case 17:
                    taisyakubetuDetail.Ufcd17 = ufcd;
                    taisyakubetuDetail.UniversalField17Name = universalFieldName;
                    taisyakubetuDetail.UniversalField17LongName = universalFieldLongName;
                    break;
                case 18:
                    taisyakubetuDetail.Ufcd18 = ufcd;
                    taisyakubetuDetail.UniversalField18Name = universalFieldName;
                    taisyakubetuDetail.UniversalField18LongName = universalFieldLongName;
                    break;
                case 19:
                    taisyakubetuDetail.Ufcd19 = ufcd;
                    taisyakubetuDetail.UniversalField19Name = universalFieldName;
                    taisyakubetuDetail.UniversalField19LongName = universalFieldLongName;
                    break;
                case 20:
                    taisyakubetuDetail.Ufcd20 = ufcd;
                    taisyakubetuDetail.UniversalField20Name = universalFieldName;
                    taisyakubetuDetail.UniversalField20LongName = universalFieldLongName;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 単一仕訳帳票の行データ取得用のSQL文を作成します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <returns>単一仕訳帳票の行データ取得用のSQL文及びパラメータ</returns>
        private SqlStatementBuilder CreateSelectQuery(ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake, bool isGetDenpyou)
        {
            var selectQuery = new SqlStatementBuilder();

            //// 単一仕訳[入力確定・チェックリスト]のSQL文を作成
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList
                && queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake)
            {
                //// 伝票SELECT句
                selectQuery.AppendLine("WITH ");
                selectQuery.AppendLine("denpyoudata( dkei, dseq, dcno, duno , sseq ) AS ");
                selectQuery.AppendLine("( ");
                selectQuery.AppendLine("SELECT ");
                selectQuery.AppendLine("  zh.dkei AS dkei ");
                selectQuery.AppendLine("  , zh.dseq AS dseq ");
                selectQuery.AppendLine("  , MIN(zh.dcno) AS dcno  ");
                selectQuery.AppendLine("  , MIN(zh.duno) AS duno  ");
                selectQuery.AppendLine("  , z.sseq AS sseq ");

                //// 伝票FROM句
                var fromStatementForDenpyou = this.CreateFromStatement(queryParameter, isGetMitenkiSiwake, true, false);
                selectQuery.Append(fromStatementForDenpyou.GetSqlStatement(), fromStatementForDenpyou.GetSqlParameters());

                selectQuery.AppendLine("WHERE ");
                selectQuery.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);
                selectQuery.AppendIfTrue(
                    queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication,
                    "  AND zh.idm1 = 0 ");

                //// 伝票WHERE句
                var whereStatementForDenpyou = this.CreateWhereStatement(queryParameter, isGetMitenkiSiwake);
                selectQuery.Append(whereStatementForDenpyou.GetSqlStatement(), whereStatementForDenpyou.GetSqlParameters());
                selectQuery.AppendLine("GROUP BY ");
                selectQuery.AppendLine("  zh.dkei, zh.dseq, zh.dcno, zh.duno , z.sseq ");
                selectQuery.AppendLine(") ");

                //// SELECT句
                this.AppendSelectString(selectQuery, queryParameter, isGetMitenkiSiwake, isGetDenpyou);

                //// FROM句
                var fromStatement = this.CreateFromStatement(queryParameter, isGetMitenkiSiwake, isGetDenpyou, false);
                selectQuery.Append(fromStatement.GetSqlStatement(), fromStatement.GetSqlParameters());

                //// 伝票データとJOIN
                selectQuery.AppendLine("  INNER JOIN denpyoudata denpyou ");
                selectQuery.AppendLine("    ON z.dkei = denpyou.dkei ");
                selectQuery.AppendLine("    AND z.dseq = denpyou.dseq ");
                selectQuery.AppendLine("    AND zh.dcno = denpyou.dcno ");
                selectQuery.AppendLine("    AND zh.duno = denpyou.duno ");
                selectQuery.AppendLine("    AND z.sseq = denpyou.sseq ");

                //// WHERE句
                selectQuery.AppendLine("WHERE ");
                selectQuery.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);

                var orderByStatement = this.CreateOrderByStatement(queryParameter, isGetDenpyou);
                selectQuery.Append(orderByStatement.GetSqlStatement(), orderByStatement.GetSqlParameters());
            }
            else
            {
                //// 入力確定・チェックリスト以外又は複合仕訳[入力確定・チェックリスト]のSQL文を作成
                //// SELECT句
                this.AppendSelectString(selectQuery, queryParameter, isGetMitenkiSiwake, isGetDenpyou);

                //// FROM句
                var fromStatement = this.CreateFromStatement(queryParameter, isGetMitenkiSiwake, isGetDenpyou, false);
                selectQuery.Append(fromStatement.GetSqlStatement(), fromStatement.GetSqlParameters());

                //// WHERE句
                selectQuery.AppendLine("WHERE ");
                selectQuery.AppendLine("  zh.kesn = :p ", queryParameter.Kesn);
                selectQuery.AppendIfTrue(
                    queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication,
                    "  AND zh.idm1 = :p ",
                    queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other ? 1 : 0);
                var whereStatement = queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake && !isGetDenpyou
                    ? this.CreateWhereStatementForHukugouSiwakeTyouhyouRows(queryParameter)
                    : this.CreateWhereStatement(queryParameter, isGetMitenkiSiwake);
                selectQuery.Append(whereStatement.GetSqlStatement(), whereStatement.GetSqlParameters());

                //// 伝票取得時、伝票単位でグループ化
                if (isGetDenpyou)
                {
                    selectQuery.AppendLine("GROUP BY ");
                    if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other)
                    {
                        //// 入力確定・チェックリスト、承認処理では、ORDERBY句と同様の項目でグループ化
                        this.AppendOrderItemString(selectQuery, queryParameter, isGetDenpyou, false);
                    }
                    else
                    {
                        selectQuery.AppendLine("  zh.dkei ");
                        selectQuery.AppendLine("  , zh.dseq ");
                    }
                }

                if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other)
                {
                    var orderByStatement = this.CreateOrderByStatement(queryParameter, isGetDenpyou);
                    selectQuery.Append(orderByStatement.GetSqlStatement(), orderByStatement.GetSqlParameters());
                }
            }

            return selectQuery;
        }

        #region SELECT句

        /// <summary>
        /// SELECT句の文字列を設定します。
        /// </summary>
        /// <param name="selectQuery">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        private void AppendSelectString(SqlStatementBuilder selectQuery, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake, bool isGetDenpyou)
        {
            selectQuery.AppendLine("SELECT ");
            selectQuery.AppendLine("  zh.dkei AS denpyou_dkei ");
            selectQuery.AppendLine("  , zh.dseq AS denpyou_dseq ");
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled)
            {
                selectQuery.AppendLine("  , z.sseq AS siwake_sseq ");
            }

            this.AppendDenpyouItemSelectString(selectQuery, queryParameter, isGetDenpyou);
            this.AppendSiwakeItemSelectString(selectQuery, queryParameter);
            this.AppendOtherItemSelectString(selectQuery, queryParameter, isGetMitenkiSiwake, isGetDenpyou);
            if (queryParameter.FromHonsitenTenkaiSiwake)
            {
                //// テンポラリテーブルから仕訳取得時、本支店展開関連のカラムも取得
                selectQuery.AppendLine("  , z.osseq AS honsiten_siwake_osseq ");
                selectQuery.AppendLine("  , z.rsflg AS honsiten_siwake_rsflg ");
                selectQuery.AppendLine("  , z.rbreg AS honsiten_siwake_rbreg ");
                selectQuery.AppendLine("  , z.rbinp AS honsiten_siwake_rbinp ");
                selectQuery.AppendLine("  , z.rbkinp AS honsiten_siwake_rbkinp ");
                selectQuery.AppendLine("  , z.ssflg AS honsiten_siwake_ssflg ");
                selectQuery.AppendLine("  , z.sbreg AS honsiten_siwake_sbreg ");
                selectQuery.AppendLine("  , z.sbinp AS honsiten_siwake_sbinp ");
                selectQuery.AppendLine("  , z.sbkinp AS honsiten_siwake_sbkinp ");
            }
        }

        /// <summary>
        /// 伝票項目取得用のSELECT句の文字列を設定します。
        /// </summary>
        /// <param name="sqlStatementBuilder">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため、分割困難")]
        private void AppendDenpyouItemSelectString(SqlStatementBuilder sqlStatementBuilder, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetDenpyou)
        {
            sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_dymd ", isGetDenpyou ? "MIN(zh.dymd)" : "zh.dymd");
            sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_dcno ", isGetDenpyou ? "MIN(zh.dcno)" : "zh.dcno");
            sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_duno ", isGetDenpyou ? "MIN(zh.duno)" : "zh.duno");

            //// 伝票項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouItemEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_bflg ", isGetDenpyou ? "MIN(zh.bflg)" : "zh.bflg");
            }

            //// 起票日
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouDateEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_kymd ", isGetDenpyou ? "MIN(zh.kymd)" : "zh.kymd");
            }

            //// 起票部門
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouBumonEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_kbmn ", isGetDenpyou ? "MIN(zh.kbmn)" : "zh.kbmn");
            }

            //// 起票者
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KihyouTantousyaEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_kusr ", isGetDenpyou ? "MIN(zh.kusr)" : "zh.kusr");
            }

            //// 伝票作成・更新項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_fmod ", isGetDenpyou ? "MIN(zh.fmod)" : "zh.fmod");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_fusr ", isGetDenpyou ? "MIN(zh.fusr)" : "zh.fusr");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_lmod ", isGetDenpyou ? "MIN(zh.lmod)" : "zh.lmod");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_lusr ", isGetDenpyou ? "MIN(zh.lusr)" : "zh.lusr");
            }

            //// 承認項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_kday ", isGetDenpyou ? "MIN(zh.kday)" : "zh.kday");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_sgno ", isGetDenpyou ? "MIN(zh.sgno)" : "zh.sgno");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_hjno ", isGetDenpyou ? "MIN(zh.hjno)" : "zh.hjno");
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_sflg ", isGetDenpyou ? "MIN(zh.sflg)" : "zh.sflg");
                for (int syouninUserNo = 1; syouninUserNo <= 10; syouninUserNo++)
                {
                    sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_sn{1} ", string.Format(isGetDenpyou ? "MIN(zh.sn{0})" : "zh.sn{0}", syouninUserNo.ToString("D2")), syouninUserNo.ToString("D2"));
                    sqlStatementBuilder.AppendFormatAndLine("  , {0} AS denpyou_sf{1} ", string.Format(isGetDenpyou ? "MIN(zh.sf{0})" : "zh.sf{0}", syouninUserNo.ToString("D2")), syouninUserNo.ToString("D2"));
                }
            }

            //// ヘッダーフィールド
            for (int headerFieldNo = 1; headerFieldNo <= 10; headerFieldNo++)
            {
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetHeaderFieldEnabled(headerFieldNo))
                {
                    sqlStatementBuilder.AppendFormatAndLine(isGetDenpyou ? "  , MIN(zh.duf{0}) AS denpyou_duf{0} " : "  , zh.duf{0} AS denpyou_duf{0} ", headerFieldNo);
                }
            }
        }

        /// <summary>
        /// 仕訳項目取得用のSELECT句の文字列を設定します。
        /// </summary>
        /// <param name="sqlStatementBuilder">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため、分割困難")]
        private void AppendSiwakeItemSelectString(SqlStatementBuilder sqlStatementBuilder, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 仕訳項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.pflg AS siwake_pflg ");
                sqlStatementBuilder.AppendLine("  , z.bkbn AS siwake_bkbn ");
                sqlStatementBuilder.AppendLine("  , z.grno AS siwake_grno ");
                sqlStatementBuilder.AppendLine("  , z.dcpg AS siwake_dcpg ");
                sqlStatementBuilder.AppendLine("  , z.dlin AS siwake_dlin ");
                sqlStatementBuilder.AppendLine("  , z.dflg AS siwake_dflg ");
                sqlStatementBuilder.AppendLine("  , z.tflg AS siwake_tflg ");
                sqlStatementBuilder.AppendLine("  , z.ifri AS siwake_ifri ");
                sqlStatementBuilder.AppendLine("  , z.delf AS siwake_delf ");
                sqlStatementBuilder.AppendLine("  , z.tekiflg AS siwake_tekiflg ");
                sqlStatementBuilder.AppendLine("  , z.hflg AS siwake_hflg ");
            }

            //// 部門
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rbmn AS siwake_rbmn ");
                sqlStatementBuilder.AppendLine("  , z.sbmn AS siwake_sbmn ");
            }

            //// 取引先
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TorihikisakiEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rtor AS siwake_rtor ");
                sqlStatementBuilder.AppendLine("  , z.stor AS siwake_stor ");
            }

            //// 科目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KamokuEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rkmk AS siwake_rkmk ");
                sqlStatementBuilder.AppendLine("  , z.skmk AS siwake_skmk ");
            }

            //// 枝番
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.EdabanEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.reda AS siwake_reda ");
                sqlStatementBuilder.AppendLine("  , z.seda AS siwake_seda ");
            }

            //// 工事
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KouziEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rkoj AS siwake_rkoj ");
                sqlStatementBuilder.AppendLine("  , z.skoj AS siwake_skoj ");
            }

            //// 工種
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KousyuEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rkos AS siwake_rkos ");
                sqlStatementBuilder.AppendLine("  , z.skos AS siwake_skos ");
            }

            //// プロジェクト
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.ProjectEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rprj AS siwake_rprj ");
                sqlStatementBuilder.AppendLine("  , z.sprj AS siwake_sprj ");
            }

            //// セグメント
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SegmentEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rseg AS siwake_rseg ");
                sqlStatementBuilder.AppendLine("  , z.sseg AS siwake_sseg ");
            }

            //// ユニバーサルフィールド
            for (int universalFieldNo = 1; universalFieldNo <= 20; universalFieldNo++)
            {
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GetUniversalFieldEnabled(universalFieldNo))
                {
                    sqlStatementBuilder.AppendFormatAndLine("  , z.rdm{0} AS siwake_rdm{0} ", universalFieldNo);
                    sqlStatementBuilder.AppendFormatAndLine("  , z.sdm{0} AS siwake_sdm{0} ", universalFieldNo);
                }
            }

            //// 金額項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KingakuItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.exvl AS siwake_exvl ");
                sqlStatementBuilder.AppendLine("  , z.zkvl AS siwake_zkvl ");
                sqlStatementBuilder.AppendLine("  , z.valu AS siwake_valu ");
            }

            //// 消費税項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SyouhizeiItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.zkmk AS siwake_zkmk ");
                sqlStatementBuilder.AppendLine("  , z.zrit AS siwake_zrit ");
                sqlStatementBuilder.AppendLine("  , z.zkeigen AS siwake_zkeigen ");
                sqlStatementBuilder.AppendLine("  , z.zzkb AS siwake_zzkb ");
                sqlStatementBuilder.AppendLine("  , z.zgyo AS siwake_zgyo ");
                sqlStatementBuilder.AppendLine("  , z.zsre AS siwake_zsre ");
            }

            //// 税区分項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.ZeiKubunItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rrit AS siwake_rrit ");
                sqlStatementBuilder.AppendLine("  , z.rkeigen AS siwake_rkeigen ");
                sqlStatementBuilder.AppendLine("  , z.rzkb AS siwake_rzkb ");
                sqlStatementBuilder.AppendLine("  , z.rgyo AS siwake_rgyo ");
                sqlStatementBuilder.AppendLine("  , z.rsre AS siwake_rsre ");
                sqlStatementBuilder.AppendLine("  , z.srit AS siwake_srit ");
                sqlStatementBuilder.AppendLine("  , z.skeigen AS siwake_skeigen ");
                sqlStatementBuilder.AppendLine("  , z.szkb AS siwake_szkb ");
                sqlStatementBuilder.AppendLine("  , z.sgyo AS siwake_sgyo ");
                sqlStatementBuilder.AppendLine("  , z.ssre AS siwake_ssre ");
            }

            //// 摘要
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rtky AS siwake_rtky ");
                sqlStatementBuilder.AppendLine("  , z.stky AS siwake_stky ");
            }

            //// 摘要コード
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rtno AS siwake_rtno ");
                sqlStatementBuilder.AppendLine("  , z.stno AS siwake_stno ");
            }

            //// 支払日
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiDateEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.symd AS siwake_symd ");
            }

            //// 支払区分
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiKubunEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.skbn AS siwake_skbn ");
            }

            //// 支払期日
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiharaiKizituEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.skiz AS siwake_skiz ");
            }

            //// 回収日
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KaisyuuDateEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.uymd AS siwake_uymd ");
            }

            //// 入金区分
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.NyuukinKubunEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.ukbn AS siwake_ukbn ");
            }

            //// 回収期日
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KaisyuuKizituEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.ukiz AS siwake_ukiz ");
            }

            //// 消込
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.KesikomiCodeEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.dkec AS siwake_dkec ");
            }

            //// 仕訳作成・更新項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.fmod AS siwake_fmod ");
                sqlStatementBuilder.AppendLine("  , z.fusr AS siwake_fusr ");
                sqlStatementBuilder.AppendLine("  , z.lmod AS siwake_lmod ");
                sqlStatementBuilder.AppendLine("  , z.ltim AS siwake_ltim ");
                sqlStatementBuilder.AppendLine("  , z.lusr AS siwake_lusr ");
            }

            //// 付箋
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.SiwakeHusenEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.fsen AS siwake_fsen ");
            }

            //// 外貨項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , z.rhei_cd AS siwake_rhei_cd ");
                sqlStatementBuilder.AppendLine("  , z.shei_cd AS siwake_shei_cd ");
                sqlStatementBuilder.AppendLine("  , z.rate AS siwake_rate ");
                sqlStatementBuilder.AppendLine("  , z.gaika AS siwake_gaika ");
                sqlStatementBuilder.AppendLine("  , z.gexvl AS siwake_gexvl ");
                sqlStatementBuilder.AppendLine("  , z.gzkvl AS siwake_gzkvl ");
                //// 外貨換算仕訳フラグ
                if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaKansanSiwakeFlagEnabled)
                {
                    sqlStatementBuilder.AppendLine("  , z.fsflg AS siwake_fsflg ");
                }
            }
        }

        /// <summary>
        /// その他項目取得用のSELECT句の文字列を設定します。
        /// </summary>
        /// <param name="sqlStatementBuilder">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        private void AppendOtherItemSelectString(SqlStatementBuilder sqlStatementBuilder, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake, bool isGetDenpyou)
        {
            //// 伝票束コード
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled)
            {
                sqlStatementBuilder.AppendFormatAndLine("  , {0} AS tabalink_tabacode ", isGetDenpyou ? "MIN(taba.tabacode)" : "taba.tabacode");
            }

            //// 集計部門コード
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled)
            {
                sqlStatementBuilder.AppendLine("  , rsb.sbcd AS karikata_sbtbl_sbcd ");
                sqlStatementBuilder.AppendLine("  , ssb.sbcd AS kasikata_sbtbl_sbcd ");
            }

            //// 外貨項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled)
            {
                sqlStatementBuilder.AppendLine("  , rhei.tani_nm AS karikata_usehei_tani_nm ");
                sqlStatementBuilder.AppendLine("  , rhei.cntry AS karikata_usehei_cntry ");
                sqlStatementBuilder.AppendLine("  , rhei.syosu AS karikata_usehei_syosu ");
                sqlStatementBuilder.AppendLine("  , shei.tani_nm AS kasikata_usehei_tani_nm ");
                sqlStatementBuilder.AppendLine("  , shei.cntry AS kasikata_usehei_cntry ");
                sqlStatementBuilder.AppendLine("  , shei.syosu AS kasikata_usehei_syosu ");
            }

            sqlStatementBuilder.AppendLine(isGetMitenkiSiwake ? "  , 1 AS mitenki" : "  , 0 AS mitenki ");
        }

        #endregion

        #region FROM句（JOIN句も含む）

        /// <summary>
        /// FROM句の式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <param name="selectOnlyDenpyouAndSiwakeTableColumns">伝票・仕訳テーブルの列のみのSELECTかどうか、trueの場合はLEFT OUTER JOINを追加しない</param>
        /// <returns>FROM句の式</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため、分割困難")]
        private SqlStatementBuilder CreateFromStatement(ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake, bool isGetDenpyou, bool selectOnlyDenpyouAndSiwakeTableColumns)
        {
            var fromStatement = new SqlStatementBuilder();

            fromStatement.AppendLine("FROM ");

            if (isGetMitenkiSiwake)
            {
                //// 未転記仕訳
                var tableName = queryParameter.FromHonsitenTenkaiSiwake ? queryParameter.HonsitenTenkaiServiceResult.HonsitenTenkaiSiwakeTemporaryTableName : "sjdat";
                fromStatement.AppendLine("  sjdat_h zh ");
                fromStatement.AppendFormatAndLine("  INNER JOIN {0} z ", tableName);
            }
            else if (queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication)
            {
                //// 遡及仕訳
                var tableName = queryParameter.FromHonsitenTenkaiSiwake ? queryParameter.HonsitenTenkaiServiceResult.HonsitenTenkaiSiwakeTemporaryTableName : "skdat";
                fromStatement.AppendLine("  skdat_h zh ");
                fromStatement.AppendFormatAndLine("  INNER JOIN {0} z ", tableName);
            }
            else
            {
                //// 財務仕訳
                fromStatement.AppendLine("  zdata_h zh ");
                fromStatement.AppendLine("  INNER JOIN zdata z ");
            }

            fromStatement.AppendLine("    ON zh.kesn = z.kesn ");
            fromStatement.AppendLine("    AND zh.dkei = z.dkei ");
            fromStatement.AppendLine("    AND zh.dseq = z.dseq ");

            //// 科目（入力確定・チェックリスト及び承認処理以外は、WHERE句で設定）
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other
                && (queryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuRangeValue.StartValue != null
                    || queryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuRangeValue.EndValue != null))
            {
                fromStatement.AppendLine("  INNER JOIN ( ");
                fromStatement.AppendLine("    SELECT DISTINCT ");
                fromStatement.AppendLine("      zh.dkei AS zh_dkei ");
                fromStatement.AppendLine("      , zh.dseq AS zh_dseq ");
                fromStatement.AppendLine("    FROM ");
                fromStatement.AppendFormatAndLine("      {0} z ", isGetMitenkiSiwake ? "sjdat" : "skdat");
                fromStatement.AppendFormatAndLine("      INNER JOIN {0} zh ", isGetMitenkiSiwake ? "sjdat_h" : "skdat_h");
                fromStatement.AppendLine("        ON zh.kesn = z.kesn ");
                fromStatement.AppendLine("        AND zh.dkei = z.dkei ");
                fromStatement.AppendLine("        AND zh.dseq = z.dseq ");
                fromStatement.AppendLine("    WHERE ");
                fromStatement.AppendLine("      z.delf = 0 ");
                this.AppendTaisyakuCommonKamokuWhereString(fromStatement, queryParameter.SiwakeTyouhyouQueryOption);
                fromStatement.AppendLine("  ) denpyou2 ");
                fromStatement.AppendLine("    ON zh.dkei = denpyou2.zh_dkei ");
                fromStatement.AppendLine("    AND zh.dseq = denpyou2.zh_dseq ");
            }

            //// 伝票束
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled && !selectOnlyDenpyouAndSiwakeTableColumns)
            {
                fromStatement.AppendLine("  LEFT OUTER JOIN tabalink taba ");
                fromStatement.AppendLine("    ON zh.kesn = taba.kesn ");
                fromStatement.AppendLine("    AND zh.dkei = taba.dkei ");
                fromStatement.AppendLine("    AND zh.duno = taba.duno ");
                fromStatement.AppendLine("    AND zh.dymd = taba.dymd ");
                fromStatement.AppendLine("    AND taba.dcno = COALESCE(zh.dcno, 0) ");
            }

            //// 部門指定の部門
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled && !selectOnlyDenpyouAndSiwakeTableColumns)
            {
                fromStatement.AppendLine("  LEFT OUTER JOIN sbtbl rsb ");
                fromStatement.AppendLine("    ON zh.kesn = rsb.kesn ");
                fromStatement.AppendLine("    AND z.rbmn = rsb.bcod ");
                this.AppendFromStatementForBumon(queryParameter, fromStatement, true);
                fromStatement.AppendLine("  LEFT OUTER JOIN sbtbl ssb ");
                fromStatement.AppendLine("    ON zh.kesn = ssb.kesn ");
                fromStatement.AppendLine("    AND z.sbmn = ssb.bcod ");
                this.AppendFromStatementForBumon(queryParameter, fromStatement, false);
            }

            //// 外貨項目
            if (queryParameter.SiwakeTyouhyouRowItemAvailability.GaikaItemEnabled && !selectOnlyDenpyouAndSiwakeTableColumns)
            {
                fromStatement.AppendLine("  LEFT OUTER JOIN usehei rhei ");
                fromStatement.AppendLine("    ON zh.kesn = rhei.kesn ");
                fromStatement.AppendLine("    AND z.rhei_cd = rhei.hei_cd ");
                fromStatement.AppendLine("  LEFT OUTER JOIN usehei shei ");
                fromStatement.AppendLine("    ON zh.kesn = shei.kesn ");
                fromStatement.AppendLine("    AND z.shei_cd = shei.hei_cd ");
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other)
            {
                if (!string.IsNullOrEmpty(queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.StartValue))
                {
                    fromStatement.AppendLine("  LEFT OUTER JOIN snrlink snl ");
                    fromStatement.AppendLine("    ON taba.tabacode = snl.tabacode ");
                }

                if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.SyouninSyori
                    && queryParameter.SecurityContext.GetUseZaimuKamokuCodeSecurity(SecurityKubun.Input)
                    && queryParameter.SecurityContext.SecurityPattern?.PatternNo > 0
                    && (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList
                    && isGetDenpyou))
                {
                    //// 科目入力セキュリティ使用時、セキュリティ財務科目テーブルも結合
                    fromStatement.AppendLine("  INNER JOIN sczkm szk ");
                    if (queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication)
                    {
                        //// 遡及処理では、当期の承認グループを参照
                        fromStatement.AppendLine("    ON szk.kesn = :p ", queryParameter.Kaisya.ToukiKesn);
                    }
                    else
                    {
                        fromStatement.AppendLine("    ON zh.kesn = szk.kesn ");
                    }

                    fromStatement.AppendLine("    AND szk.skbn = 1 ");
                    fromStatement.AppendLine("    AND szk.sptn = :p ", queryParameter.SecurityContext.SecurityPattern.PatternNo);
                    fromStatement.AppendLine("    AND (z.rkmk = szk.szkm OR z.skmk = szk.szkm) ");
                }
            }

            return fromStatement;
        }

        /// <summary>
        /// 部門指定用のFROM句の式を追加します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="fromStatement">FROM句の式（追加前）</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <returns>FROM句の式（追加後）</returns>
        private SqlStatementBuilder AppendFromStatementForBumon(ISiwakeTyouhyouQueryParameter queryParameter, SqlStatementBuilder fromStatement, bool isKarikata)
        {
            switch (queryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting)
            {
                // 集計部門単位（範囲）
                case BumonTaniOutputSetting.SyuukeiBumonRangeSitei:
                    fromStatement.AppendWhereStatementByCodeRange(isKarikata ? "rsb.sbcd" : "ssb.sbcd", queryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.StartValue, queryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.EndValue, true);
                    break;

                // 集計部門単位（個別）
                case BumonTaniOutputSetting.SyuukeiBumonKobetuSitei:
                    fromStatement.AppendInStatement("AND", isKarikata ? "rsb.sbcd" : "ssb.sbcd", queryParameter.SiwakeTyouhyouQueryOption.BcodKobetuSiteiList);
                    break;
            }

            return fromStatement;
        }

        #endregion

        #region WHERE句

        /// <summary>
        /// WHERE句の条件式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        /// <returns>WHERE句の条件式</returns>
        private SqlStatementBuilder CreateWhereStatement(ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake)
        {
            var whereStatement = new SqlStatementBuilder();

            //// 伝票項目
            this.AppendDenpyouItemWhereStatement(whereStatement, queryParameter, isGetMitenkiSiwake);

            //// 仕訳項目
            this.AppendSiwakeItemWhereStatement(whereStatement, queryParameter);

            //// 未入力チェック
            if (queryParameter.IsUseNotInputCheckOptionForGetSiwakeTyouhyou)
            {
                var notInputCheckWhereStatement = new SqlStatementBuilder();
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.kusr", queryParameter.DenpyouInputAndSyuuseiOption.CheckKihyosyaInputted && queryParameter.NotInputCheckOption.IsUseKihyouTantousyaNotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.kbmn", queryParameter.DenpyouInputAndSyuuseiOption.CheckKihyoBumonInputted && queryParameter.NotInputCheckOption.IsUseKihyouBumonNotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf1", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(1) && queryParameter.NotInputCheckOption.IsUseHeaderField01NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf2", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(2) && queryParameter.NotInputCheckOption.IsUseHeaderField02NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf3", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(3) && queryParameter.NotInputCheckOption.IsUseHeaderField03NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf4", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(4) && queryParameter.NotInputCheckOption.IsUseHeaderField04NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf5", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(5) && queryParameter.NotInputCheckOption.IsUseHeaderField05NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf6", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(6) && queryParameter.NotInputCheckOption.IsUseHeaderField06NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf7", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(7) && queryParameter.NotInputCheckOption.IsUseHeaderField07NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf8", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(8) && queryParameter.NotInputCheckOption.IsUseHeaderField08NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf9", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(9) && queryParameter.NotInputCheckOption.IsUseHeaderField09NotInputCheck);
                this.AppendNotInputCheckDenpyouItemWhereStatement(notInputCheckWhereStatement, "zh.duf10", queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(10) && queryParameter.NotInputCheckOption.IsUseHeaderField10NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rbmn", "z.sbmn", "kb02", queryParameter.NotInputCheckOption.IsUseBumonNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.reda", "z.seda", "ke02", queryParameter.NotInputCheckOption.IsUseEdabanNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rtor", "z.stor", "kt02", queryParameter.NotInputCheckOption.IsUseTorihikisakiNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rseg", "z.sseg", "sg02", queryParameter.NotInputCheckOption.IsUseSegmentNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rprj", "z.sprj", "pj02", queryParameter.NotInputCheckOption.IsUseProjectNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rkoj", "z.skoj", "kj02", queryParameter.NotInputCheckOption.IsUseKouziNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rkos", "z.skos", "ks02", queryParameter.NotInputCheckOption.IsUseKousyuNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rtno", "z.stno", "tk02", queryParameter.NotInputCheckOption.IsUseTekiyouCodeNotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm1", "z.sdm1", "dm12", queryParameter.NotInputCheckOption.IsUseUniversalField01NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm2", "z.sdm2", "dm22", queryParameter.NotInputCheckOption.IsUseUniversalField02NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm3", "z.sdm3", "dm32", queryParameter.NotInputCheckOption.IsUseUniversalField03NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm4", "z.sdm4", "dm42", queryParameter.NotInputCheckOption.IsUseUniversalField04NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm5", "z.sdm5", "dm52", queryParameter.NotInputCheckOption.IsUseUniversalField05NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm6", "z.sdm6", "dm62", queryParameter.NotInputCheckOption.IsUseUniversalField06NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm7", "z.sdm7", "dm72", queryParameter.NotInputCheckOption.IsUseUniversalField07NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm8", "z.sdm8", "dm82", queryParameter.NotInputCheckOption.IsUseUniversalField08NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm9", "z.sdm9", "dm92", queryParameter.NotInputCheckOption.IsUseUniversalField09NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm10", "z.sdm10", "dm102", queryParameter.NotInputCheckOption.IsUseUniversalField10NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm11", "z.sdm11", "dm112", queryParameter.NotInputCheckOption.IsUseUniversalField11NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm12", "z.sdm12", "dm122", queryParameter.NotInputCheckOption.IsUseUniversalField12NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm13", "z.sdm13", "dm132", queryParameter.NotInputCheckOption.IsUseUniversalField13NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm14", "z.sdm14", "dm142", queryParameter.NotInputCheckOption.IsUseUniversalField14NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm15", "z.sdm15", "dm152", queryParameter.NotInputCheckOption.IsUseUniversalField15NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm16", "z.sdm16", "dm162", queryParameter.NotInputCheckOption.IsUseUniversalField16NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm17", "z.sdm17", "dm172", queryParameter.NotInputCheckOption.IsUseUniversalField17NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm18", "z.sdm18", "dm182", queryParameter.NotInputCheckOption.IsUseUniversalField18NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm19", "z.sdm19", "dm192", queryParameter.NotInputCheckOption.IsUseUniversalField19NotInputCheck);
                this.AppendNotInputCheckSiwakeItemWhereStatement(notInputCheckWhereStatement, queryParameter.Kesn, "z.rdm20", "z.sdm20", "dm202", queryParameter.NotInputCheckOption.IsUseUniversalField20NotInputCheck);
                notInputCheckWhereStatement.AppendLineIfCurrentSqlStatementIsNotEmpty(") ");
                whereStatement.AppendLine(notInputCheckWhereStatement.GetSqlStatement(), notInputCheckWhereStatement.GetSqlParameters());
            }

            //// 部門単位出力
            this.AppendBumonTaniOutputSettingWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// セキュリティ関連
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.SyouninSyori)
            {
                this.AppendSecurityRelatedWhereStatement(whereStatement, queryParameter);
            }

            return whereStatement;
        }

        /// <summary>
        /// 複合仕訳帳票の行データ取得用のWHERE句の式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns></returns>
        private SqlStatementBuilder CreateWhereStatementForHukugouSiwakeTyouhyouRows(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var whereStatement = new SqlStatementBuilder();

            whereStatement.AppendLine("  AND z.dkei = :p ", queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.StartValue);
            whereStatement.AppendLine("  AND z.dseq = :p ", queryParameter.SiwakeTyouhyouQueryOption.DseqRangeValue.StartValue);
            whereStatement.AppendLine("  AND zh.duno = :p ", queryParameter.SiwakeTyouhyouQueryOption.UketukeNoRangeValue.StartValue);
            whereStatement.AppendLine("  AND zh.delf = 0 ");
            whereStatement.AppendLine("  AND z.delf = 0 ");
            if (queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.StartValue != null)
            {
                whereStatement.AppendLine("  AND zh.dcno = :p ", queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.StartValue);
            }

            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputOnlyNotPrintedSiwake)
            {
                switch (queryParameter.HukugouSiwakeNormalOutputSetting)
                {
                    //// 修正仕訳のみ（行変更を含む）
                    case SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.ContainingLineChangedSiwake:
                        whereStatement.AppendLine("  AND (z.cprt = 0 OR (z.cprt = 1 AND z.swgflg = 1)) ");
                        break;

                    //// 修正仕訳のみ（行変更を含まない）
                    case SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.NotContainingLineChangedSiwake:
                        whereStatement.AppendLine("  AND z.cprt = 0 ");
                        break;

                    default:
                        break;
                }
            }

            return whereStatement;
        }

        /// <summary>
        /// 伝票項目の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目省略不可")]
        private void AppendDenpyouItemWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetMitenkiSiwake)
        {
            //// 経過月
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dkei",
                queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.EndValue,
                true);

            //// 伝票SEQ
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dseq",
                queryParameter.SiwakeTyouhyouQueryOption.DseqRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.DseqRangeValue.EndValue,
                true);

            //// 伝票日付
            whereStatement.AppendWhereStatementByIntRange(
                "zh.dymd",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouDateRangeValue.EndValue?.Ymd,
                true);

            //// 伝票番号
            this.AppendDenpyouNoWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 受付番号
            whereStatement.AppendWhereStatementByIntRange(
                "zh.duno",
                queryParameter.SiwakeTyouhyouQueryOption.UketukeNoRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.UketukeNoRangeValue.EndValue,
                true);

            //// 伝票形式
            this.AppendDenpyouTypeWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// e文書番号
            this.AppendEdocumentWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption, isGetMitenkiSiwake);

            //// 伝票作成者
            if (!isGetMitenkiSiwake
                || queryParameter.SecurityContext.GetUserKaisyabetuSecurity()?.OthersDenpyoPermission != OthersDenpyouPermission.Disallow
                || queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other)
            {
                whereStatement.AppendWhereStatementByIntRange(
                    "zh.fusr",
                    queryParameter.SiwakeTyouhyouQueryOption.DenpyouCreateUserCodeRangeValue.StartValue,
                    queryParameter.SiwakeTyouhyouQueryOption.DenpyouCreateUserCodeRangeValue.EndValue,
                    true);
            }

            //// 伝票作成日
            whereStatement.AppendWhereStatementByIntRange(
                "zh.fmod",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouCreateDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouCreateDateRangeValue.EndValue?.Ymd,
                true);

            //// 伝票更新者
            whereStatement.AppendWhereStatementByIntRange(
                "zh.lusr",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouUpdateUserCodeRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouUpdateUserCodeRangeValue.EndValue,
                true);

            //// 伝票更新日
            whereStatement.AppendWhereStatementByIntRange(
                "zh.lmod",
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouUpdateDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.DenpyouUpdateDateRangeValue.EndValue?.Ymd,
                true);

            //// 起票日
            whereStatement.AppendWhereStatementByIntRange(
                "zh.kymd",
                queryParameter.SiwakeTyouhyouQueryOption.KihyouDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.KihyouDateRangeValue.EndValue?.Ymd,
                true);

            //// 起票者
            this.AppendKihyouTantousyaWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 起票部門
            this.AppendKihyouBumonWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// ヘッダーフィールド
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd01RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd01RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd01RangeValue.EndValue?.ToString(), 1, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd02RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd02RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd02RangeValue.EndValue?.ToString(), 2, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd03RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd03RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd03RangeValue.EndValue?.ToString(), 3, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd04RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd03RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd04RangeValue.EndValue?.ToString(), 4, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd05RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd05RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd05RangeValue.EndValue?.ToString(), 5, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd06RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd06RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd06RangeValue.EndValue?.ToString(), 6, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd07RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd07RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd07RangeValue.EndValue?.ToString(), 7, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd08RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd08RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd08RangeValue.EndValue?.ToString(), 8, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd09RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd09RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd09RangeValue.EndValue?.ToString(), 9, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendHeaderFieldWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption.Hfcd10RangeValue.IsSearchWithFullMatch, queryParameter.SiwakeTyouhyouQueryOption.Hfcd10RangeValue.StartValue?.ToString(), queryParameter.SiwakeTyouhyouQueryOption.Hfcd10RangeValue.EndValue?.ToString(), 10, queryParameter.KaisyaSyoriKikan.Syoriki);

            //// シナリオ
            this.AppendScenarioWhereStatement(whereStatement, queryParameter);

            //// 伝票束
            this.AppendDenpyouTabaCodeWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 承認グループ
            if (queryParameter.SiwakeTyouhyouQueryOption.SyouninGroup?.GroupNo > 0)
            {
                whereStatement.AppendLine("  AND zh.sgno = :p ", queryParameter.SiwakeTyouhyouQueryOption.SyouninGroup.GroupNo);
            }

            //// 印刷が済んでいない伝票のみ出力するかどうか
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputOnlyNotPrintedDenpyou)
            {
                whereStatement.AppendLine("  AND zh.cprt = 0 ");
                whereStatement.AppendLine("  AND z.cprt = 0 ");
            }

            //// 未転記データ用の条件
            if (isGetMitenkiSiwake
                && queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other)
            {
                this.AppendMitenkiDataWhereStatement(whereStatement, queryParameter);
            }

            //// 未完伝票の設定
            this.AppendMikanDenpyouWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 確定日付
            whereStatement.AppendWhereStatementByIntRange(
                "zh.kday",
                queryParameter.SiwakeTyouhyouQueryOption.InputKakuteiDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.InputKakuteiDateRangeValue.EndValue?.Ymd,
                true);

            //// 業務毎
            switch (queryParameter.SiwakeTyouhyouQueryOption.SyoriType)
            {
                //// 入力確定・チェックリスト
                case SyoriType.CheckList:
                    this.AppendCheckListWhereStatement(whereStatement, queryParameter);
                    break;

                //// 承認処理
                case SyoriType.SyouninSyori:
                    this.AppendSyouninSyoriWhereStatement(whereStatement, queryParameter);
                    break;
            }
        }

        /// <summary>
        /// 伝票番号の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendDenpyouNoWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.DenpyouNoRangeValue.IsOutputNotInputOnly)
            {
                //// 未入力のみ
                whereStatement.AppendLine("  AND zh.dcno IS NULL ");
            }
            else
            {
                whereStatement.AppendWhereStatementByIntRange(
                    "zh.dcno",
                    queryOption.DenpyouNoRangeValue.StartValue,
                    queryOption.DenpyouNoRangeValue.EndValue,
                    true);
            }
        }

        /// <summary>
        /// 伝票形式の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendDenpyouTypeWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            switch (queryOption.DenpyouType)
            {
                //// 複合形式
                case DenpyouTypeSearchType.HukugouType:
                    whereStatement.AppendLine("  AND zh.dfuk = 2 ");
                    break;

                //// 単一形式
                case DenpyouTypeSearchType.TanituType:
                    whereStatement.AppendLine("  AND zh.dfuk IN (0, 1) ");
                    break;
            }
        }

        /// <summary>
        /// e文書番号の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        /// <param name="isGetMitenkiSiwake">未転記仕訳を取得するかどうか</param>
        private void AppendEdocumentWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption, bool isGetMitenkiSiwake)
        {
            if (queryOption.LinkInformation != LinkInfomationSearchType.None
                || !string.IsNullOrEmpty(queryOption.EDocumentNoRangeValue.StartValue)
                || !string.IsNullOrEmpty(queryOption.EDocumentNoRangeValue.EndValue))
            {
                if (queryOption.LinkInformation == LinkInfomationSearchType.OnlyDenpyouHasLinkInformation
                    || !string.IsNullOrEmpty(queryOption.EDocumentNoRangeValue.StartValue)
                    || !string.IsNullOrEmpty(queryOption.EDocumentNoRangeValue.EndValue))
                {
                    // リンク情報ありのみ
                    whereStatement.Append("  AND ");
                }
                else
                {
                    // リンク情報なしのみ
                    whereStatement.Append("  AND NOT ");
                }

                whereStatement.Append(
                    "EXISTS (SELECT dl.kesn FROM dinlink dl WHERE dl.kesn = :p AND dl.dkei = zh.dkei AND dl.dseq = zh.dseq AND dl.styp = :p ",
                    queryOption.KaisyaSyoriKikan.Syoriki.Kesn,
                    isGetMitenkiSiwake ? 1 : 0);
                whereStatement.AppendWhereStatementByCodeRange(
                    "dl.edoc",
                    queryOption.EDocumentNoRangeValue.StartValue,
                    queryOption.EDocumentNoRangeValue.EndValue,
                    true);
                whereStatement.AppendLine(") ");
            }
        }

        /// <summary>
        /// 起票者の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendKihyouTantousyaWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.KihyouTantousyaCodeRangeValue.IsOutputNotInputOnly)
            {
                //// 未入力のみ
                whereStatement.AppendLine("  AND zh.kusr IS NULL ");
            }
            else
            {
                whereStatement.AppendWhereStatementByCodeRange(
                    "zh.kusr",
                    queryOption.KihyouTantousyaCodeRangeValue.StartValue,
                    queryOption.KihyouTantousyaCodeRangeValue.EndValue,
                    true);
            }
        }

        /// <summary>
        /// 起票部門の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendKihyouBumonWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.KihyouBumonCodeRangeValue.IsOutputNotInputOnly)
            {
                //// 未入力のみ
                whereStatement.AppendLine("  AND zh.kbmn IS NULL ");
            }
            else
            {
                whereStatement.AppendWhereStatementByCodeRange(
                    "zh.kbmn",
                    queryOption.KihyouBumonCodeRangeValue.StartValue,
                    queryOption.KihyouBumonCodeRangeValue.EndValue,
                    true);
            }
        }

        /// <summary>
        /// ヘッダーフィールドの条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="isSearchWithFullMatch">HFを完全一致で検索するかどうか</param>
        /// <param name="startCode">開始コード</param>
        /// <param name="endCode">終了コード</param>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <param name="syoriki">処理期情報</param>
        private void AppendHeaderFieldWhereStatement(SqlStatementBuilder whereStatement, bool isSearchWithFullMatch, string startCode, string endCode, int headerFieldNo, Syoriki syoriki)
        {
            switch (syoriki.GetUniversalFieldInfo(true, headerFieldNo).DataType)
            {
                // 文字
                case UniversalFieldDataType.Char:
                    // 完全一致
                    if (isSearchWithFullMatch)
                    {
                        whereStatement.AppendFormat("  AND zh.duf{0} ", headerFieldNo);
                        if (string.IsNullOrEmpty(startCode))
                        {
                            whereStatement.AppendLine("IS NULL ");
                        }
                        else
                        {
                            whereStatement.AppendLine("= :p ", startCode);
                        }
                    }
                    else if (!string.IsNullOrEmpty(startCode))
                    {
                        whereStatement
                            .AppendFormatAndLine("  AND{0}> 0 ", this.dbReservedWords.GetCharIndexFunction("UPPER(:p)", string.Format("UPPER(zh.duf{0})", headerFieldNo)))
                            .AddSqlParameter(startCode);
                    }

                    break;

                default:
                    whereStatement.AppendWhereStatementByCodeRange(string.Format("zh.duf{0}", headerFieldNo), startCode, endCode, true);
                    break;
            }
        }

        /// <summary>
        /// シナリオの条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendScenarioWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other
                && !string.IsNullOrEmpty(queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.StartValue))
            {
                //// シナリオ指定されている場合
                whereStatement.AppendLine("  AND snl.tabacode IS NOT NULL ");
                whereStatement.AppendLine("  AND snl.snrcode = :p ", queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.StartValue);
                return;
            }

            if (!string.IsNullOrEmpty(queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.StartValue)
                || !string.IsNullOrEmpty(queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.EndValue))
            {
                whereStatement.Append(
                    "  AND EXISTS (SELECT tl.kesn FROM tabalink tl WHERE tl.kesn = :p AND tl.dkei = zh.dkei AND tl.duno = zh.duno AND tl.dymd = zh.dymd AND tl.dcno = COALESCE(zh.dcno, 0) AND tabacode IN (SELECT tabacode FROM snrlink WHERE ",
                    queryParameter.Kesn);
                whereStatement.AppendWhereStatementByCodeRange(
                    "snrcode",
                    queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.StartValue,
                    queryParameter.SiwakeTyouhyouQueryOption.ScenarioRangeValue.EndValue,
                    false);
                whereStatement.AppendLine(")) ");
            }
        }

        /// <summary>
        /// 伝票束の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendDenpyouTabaCodeWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (!string.IsNullOrEmpty(queryOption.DenpyouTabaCodeRangeValue.StartValue)
                || !string.IsNullOrEmpty(queryOption.DenpyouTabaCodeRangeValue.EndValue))
            {
                whereStatement.Append(
                    "  AND EXISTS (SELECT tl.kesn FROM tabalink tl WHERE tl.kesn = :p AND tl.dkei = zh.dkei AND tl.duno = zh.duno AND tl.dymd = zh.dymd AND tl.dcno = COALESCE(zh.dcno, 0) ",
                    queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
                whereStatement.AppendWhereStatementByCodeRange(
                    "tabacode",
                    queryOption.DenpyouTabaCodeRangeValue.StartValue,
                    queryOption.DenpyouTabaCodeRangeValue.EndValue,
                    true);
                whereStatement.AppendLine(") ");
            }
        }

        /// <summary>
        /// 未転記データ用の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendMitenkiDataWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            if (queryParameter.MitenkiDataQueryContext.IncludesMitenkiSiwake)
            {
                // 未転記データの取得対象は、自分作成の仕訳のみ
                whereStatement.AppendLine("  AND zh.fusr = :p ", queryParameter.SecurityContext.User.UserCode);
            }
            else
            {
                whereStatement.Append("  AND (");
                var shouldAppendOrSentence = false;
                var commonWhereStatement = new SqlStatementBuilder();
                commonWhereStatement.Append("(zh.fusr = :p OR zh.sgno IN (SELECT sgno FROM sngrp WHERE kesn = :p AND (suno = :p OR duno = :p)))", queryParameter.SecurityContext.User.UserCode, queryParameter.Kesn, queryParameter.SecurityContext.User.UserCode, queryParameter.SecurityContext.User.UserCode);

                shouldAppendOrSentence |= LambdaStatement.TryInvokeIfTrue(
                    queryParameter.MitenkiDataQueryContext.IncludesMikakuteiSiwake,
                    () =>
                    {
                        // 未確定仕訳を取得
                        whereStatement.Append("(zh.kday = 0 AND ");
                        whereStatement.Append(commonWhereStatement.GetSqlStatement(), commonWhereStatement.GetSqlParameters());
                        whereStatement.Append(")");
                    });

                shouldAppendOrSentence |= LambdaStatement.TryInvokeIfTrue(
                    queryParameter.MitenkiDataQueryContext.IncludesMisyouninSiwake,
                    () =>
                    {
                        // 未承認仕訳を取得
                        whereStatement.AppendIfTrue(shouldAppendOrSentence, " OR ");
                        whereStatement.Append("(zh.kday > 0 AND zh.hjno = 99 AND ");
                        whereStatement.Append(commonWhereStatement.GetSqlStatement(), commonWhereStatement.GetSqlParameters());
                        whereStatement.Append(")");
                    });

                shouldAppendOrSentence |= LambdaStatement.TryInvokeIfTrue(
                    queryParameter.MitenkiDataQueryContext.IncludesSyounintyuuSiwake,
                    () =>
                    {
                        // 承認中仕訳を取得
                        whereStatement.AppendIfTrue(shouldAppendOrSentence, " OR ");
                        whereStatement.Append("(zh.kday > 0 AND (zh.hjno BETWEEN 2 AND 10) AND zh.sflg = 1 AND ");
                        whereStatement.Append(commonWhereStatement.GetSqlStatement(), commonWhereStatement.GetSqlParameters());
                        whereStatement.Append(")");
                    });

                shouldAppendOrSentence |= LambdaStatement.TryInvokeIfTrue(
                    queryParameter.MitenkiDataQueryContext.IncludesSyouninzumiSiwake,
                    () =>
                    {
                        // 承認済仕訳を取得
                        whereStatement.AppendIfTrue(shouldAppendOrSentence, " OR ");
                        whereStatement.Append("(zh.kday > 0 AND zh.hjno = 1 AND zh.sflg = 1 AND ");
                        whereStatement.Append(commonWhereStatement.GetSqlStatement(), commonWhereStatement.GetSqlParameters());
                        whereStatement.Append(")");
                    });

                whereStatement.AppendLine(") ");
            }
        }

        /// <summary>
        /// 未完伝票の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendMikanDenpyouWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.MikanDenpyouSearchSetting == MikanDenpyouSearchSetting.MikanDenpyouOnly)
            {
                whereStatement.AppendFormatAndLine("  AND zh.bflg = 1 ");
            }
        }

        /// <summary>
        /// 入力確定・チェックリスト用の条件式を追加します。
        /// </summary>
        /// <param name="whereStatement">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendCheckListWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var checkListSqlStatementBuilder = new SqlStatementBuilder();

            //// 未確定
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputNotKakuteiDenpyou)
            {
                checkListSqlStatementBuilder.AppendLine("    (zh.kday = 0) ");
            }

            //// 未承認
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputNotSyouninDenpyou)
            {
                checkListSqlStatementBuilder.AppendIfCurrentSqlStatementIsNotEmpty("    OR ");
                checkListSqlStatementBuilder.AppendLine("    (zh.kday > 0 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.hjno = 99) ");
            }

            //// 承認中
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputSyounintyuuDenpyou)
            {
                checkListSqlStatementBuilder.AppendIfCurrentSqlStatementIsNotEmpty("    OR ");
                checkListSqlStatementBuilder.AppendLine("    (zh.kday > 0 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.hjno BETWEEN 2 AND 10 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.sflg = 1) ");
            }

            //// 承認済
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputSyouninzumiDenpyou)
            {
                checkListSqlStatementBuilder.AppendIfCurrentSqlStatementIsNotEmpty("    OR ");
                checkListSqlStatementBuilder.AppendLine("    (zh.kday > 0 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.hjno = 1 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.sflg = 1) ");
            }

            //// 否認（修正）
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputHininSyuuseiDenpyou)
            {
                checkListSqlStatementBuilder.AppendIfCurrentSqlStatementIsNotEmpty("    OR ");
                checkListSqlStatementBuilder.AppendLine("    (zh.kday > 0 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.sflg = 2) ");
            }

            //// 否認（削除）
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputHininDeleteDenpyou)
            {
                checkListSqlStatementBuilder.AppendIfCurrentSqlStatementIsNotEmpty("    OR ");
                checkListSqlStatementBuilder.AppendLine("    (zh.kday > 0 ");
                checkListSqlStatementBuilder.AppendLine("    AND zh.sflg = 3) ");
            }

            if (!string.IsNullOrEmpty(checkListSqlStatementBuilder.GetSqlStatement()))
            {
                whereStatement.AppendLine("  AND ( ");
                whereStatement.AppendLine(checkListSqlStatementBuilder.GetSqlStatement(), checkListSqlStatementBuilder.GetSqlParameters());
                whereStatement.AppendLine("  ) ");
            }

            //// 自分が作成した伝票のみ出力
            if (!queryParameter.SiwakeTyouhyouQueryOption.IsOutputAllDenpyou)
            {
                whereStatement.AppendLine("  AND zh.fusr = :p ", queryParameter.SecurityContext.User.UserCode);
            }

            //// セキュリティ関連（科目入力セキュリティ使用時のみ）
            if (queryParameter.SecurityContext.GetUseZaimuKamokuCodeSecurity(SecurityKubun.Input)
                && queryParameter.SecurityContext.SecurityPattern?.PatternNo > 0)
            {
                this.AppendKamokuSecurityWhereString(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);
            }
        }

        /// <summary>
        /// 承認処理用の条件式を追加します。
        /// </summary>
        /// <param name="whereStatement">SQL文</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendSyouninSyoriWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            if (queryParameter.SyouninDenpyouSearchCondition == SyouninDenpyouSearchCondition.OnlyNotKakuteiDenpyou)
            {
                //// 未確定伝票のみ
                whereStatement.AppendLine("  AND zh.kday = 0 ");
                whereStatement.AppendLine("  AND EXISTS (SELECT sng.kesn FROM sngrp sng WHERE sng.kesn = zh.kesn AND sng.sgno = zh.sgno AND (sng.suno = :p OR sng.duno = :p)) ", queryParameter.SecurityContext.User.UserCode, queryParameter.SecurityContext.User.UserCode);
            }
            else
            {
                whereStatement.AppendLine("  AND zh.kday > 0 ");
                whereStatement.Append("  AND EXISTS (SELECT sng.kesn FROM sngrp sng WHERE sng.kesn = zh.kesn AND sng.sgno = zh.sgno AND ((sng.sksw = 0 AND sng.suno = :p) OR (sng.sksw = 1 AND sng.duno = :p)) ", queryParameter.SecurityContext.User.UserCode, queryParameter.SecurityContext.User.UserCode);
            }

            switch (queryParameter.SyouninDenpyouSearchCondition)
            {
                //// 未承認伝票（新規承認のみ）
                case SyouninDenpyouSearchCondition.OnlyNewSyouninDenpyou:
                    whereStatement.AppendLine("AND ((zh.hjno = 99 AND sng.slsw = 1) OR ((zh.hjno - 1) = sng.sjno AND zh.sflg = 1))) ");
                    break;

                //// 未承認伝票（下位未承認のみ）
                case SyouninDenpyouSearchCondition.OnlyLowerNotSyouninDenpyou:
                    whereStatement.AppendLine("AND ((zh.hjno = 99 AND sng.slsw = 0) OR ((zh.hjno - 2) >= sng.sjno AND zh.sflg = 1))) ");
                    break;

                //// 承認済伝票
                case SyouninDenpyouSearchCondition.SyouninCompletedDenpyou:
                    whereStatement.AppendLine("AND zh.hjno <= sng.sjno) ");
                    break;

                //// 指定無し（確定伝票のみ）
                case SyouninDenpyouSearchCondition.OnlyKakuteiDenpyou:
                    whereStatement.AppendLine("AND (((zh.hjno = 99 AND sng.slsw = 1) OR ((zh.hjno - 1) = sng.sjno AND zh.sflg = 1)) OR ((zh.hjno = 99 AND sng.slsw = 0) OR ((zh.hjno - 2) >= sng.sjno AND zh.sflg = 1)) OR zh.hjno <= sng.sjno)) ");
                    break;
            }
        }

        /// <summary>
        /// 仕訳項目の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多いため")]
        private void AppendSiwakeItemWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 仕訳SEQ
            whereStatement.AppendWhereStatementByIntRange(
                "z.sseq",
                queryParameter.SiwakeTyouhyouQueryOption.SseqRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.SseqRangeValue.EndValue,
                true);

            //// 仕訳作成者
            whereStatement.AppendWhereStatementByIntRange(
                "z.fusr",
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeCreateUserCodeRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeCreateUserCodeRangeValue.EndValue,
                true);

            //// 仕訳作成日
            whereStatement.AppendWhereStatementByIntRange(
                "z.fmod",
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeCreateDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeCreateDateRangeValue.EndValue?.Ymd,
                true);

            //// 仕訳更新者
            whereStatement.AppendWhereStatementByIntRange(
                "z.lusr",
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeUpdateUserCodeRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeUpdateUserCodeRangeValue.EndValue,
                true);

            //// 仕訳更新日
            whereStatement.AppendWhereStatementByIntRange(
                "z.lmod",
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeUpdateDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeUpdateDateRangeValue.EndValue?.Ymd,
                true);

            //// 金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.valu",
                queryParameter.SiwakeTyouhyouQueryOption.KingakuRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.KingakuRangeValue.EndValue,
                true);

            //// 対価金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.exvl",
                queryParameter.SiwakeTyouhyouQueryOption.TaikaKingakuRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.TaikaKingakuRangeValue.EndValue,
                true);
            if (queryParameter.SiwakeTyouhyouQueryOption.TaikaKingakuRangeValue.StartValue != null
                || queryParameter.SiwakeTyouhyouQueryOption.TaikaKingakuRangeValue.EndValue != null)
            {
                whereStatement.AppendLine("  AND z.tflg = 1 ");
            }

            //// 税込金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.zkvl",
                queryParameter.SiwakeTyouhyouQueryOption.ZeikomiKingakuRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.ZeikomiKingakuRangeValue.EndValue,
                true);
            if (queryParameter.SiwakeTyouhyouQueryOption.ZeikomiKingakuRangeValue.StartValue != null
                || queryParameter.SiwakeTyouhyouQueryOption.ZeikomiKingakuRangeValue.EndValue != null)
            {
                whereStatement.AppendLine("  AND z.pflg = 1 ");
                whereStatement.AppendLine("  AND z.bkbn = 1 ");
            }

            //// 税対象科目
            this.AppendSyouhizeiTaisyouKamokuWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 仕訳作成方法
            this.AppendSiwakeWayToCreateWhereStatement(
                whereStatement,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeWayToCreateSiteiMethod,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeWayToCreateList,
                "z.fway");

            //// 仕訳更新方法
            this.AppendSiwakeWayToCreateWhereStatement(
                whereStatement,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeWayToUpdateSiteiMethod,
                queryParameter.SiwakeTyouhyouQueryOption.SiwakeWayToUpdateList,
                "z.lway");

            //// 消込
            whereStatement.AppendWhereStatementByCodeRange(
                "z.dkec",
                queryParameter.SiwakeTyouhyouQueryOption.KesikomiCodeRangeValue.StartValue,
                queryParameter.SiwakeTyouhyouQueryOption.KesikomiCodeRangeValue.EndValue,
                true);

            //// 付箋
            if (queryParameter.SiwakeTyouhyouQueryOption.SiwakeHusen != null)
            {
                whereStatement.AppendLine("  AND z.fsen = :p ", (int)queryParameter.SiwakeTyouhyouQueryOption.SiwakeHusen);
            }

            //// 支払日
            whereStatement.AppendWhereStatementByIntRange(
                "z.symd",
                queryParameter.SiwakeTyouhyouQueryOption.SiharaiDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.SiharaiDateRangeValue.EndValue?.Ymd,
                true);

            //// 支払期日
            whereStatement.AppendWhereStatementByIntRange(
                "z.skiz",
                queryParameter.SiwakeTyouhyouQueryOption.SiharaiKizituRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.SiharaiKizituRangeValue.EndValue?.Ymd,
                true);

            //// 支払区分
            if (queryParameter.SiwakeTyouhyouQueryOption.SiharaiKubun != null)
            {
                whereStatement.AppendLine("  AND z.skbn = :p ", queryParameter.SiwakeTyouhyouQueryOption.SiharaiKubun.KubunNo);
            }

            //// 回収日
            whereStatement.AppendWhereStatementByIntRange(
                "z.uymd",
                queryParameter.SiwakeTyouhyouQueryOption.KaisyuuDateRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.KaisyuuDateRangeValue.EndValue?.Ymd,
                true);

            //// 回収期日
            whereStatement.AppendWhereStatementByIntRange(
                "z.ukiz",
                queryParameter.SiwakeTyouhyouQueryOption.KaisyuuKizituRangeValue.StartValue?.Ymd,
                queryParameter.SiwakeTyouhyouQueryOption.KaisyuuKizituRangeValue.EndValue?.Ymd,
                true);

            //// 入金区分
            if (queryParameter.SiwakeTyouhyouQueryOption.NyuukinKubun != null)
            {
                whereStatement.AppendLine("  AND z.ukbn = :p ", queryParameter.SiwakeTyouhyouQueryOption.NyuukinKubun.KubunNo);
            }

            // 外貨使用時、外貨関連の項目の条件式も追加
            this.AppendGaikaItemWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption);

            //// 未印刷の仕訳のみを出力
            if (queryParameter.SiwakeTyouhyouQueryOption.IsOutputOnlyNotPrintedSiwake)
            {
                if (queryParameter.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake)
                {
                    whereStatement.AppendLine("  AND z.swiflg = 0 ");
                }
                else
                {
                    switch (queryParameter.HukugouSiwakeNormalOutputSetting)
                    {
                        //// 修正仕訳を含む伝票
                        case SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.AllSiwakeOutput:
                            whereStatement.AppendLine("  AND (zh.cprt = 0 OR z.cprt = 0) ");
                            break;

                        //// 修正仕訳のみ（行変更を含む）
                        case SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.ContainingLineChangedSiwake:
                            whereStatement.AppendLine("  AND ((zh.cprt = 0 AND zh.hsflg != 3) OR (zh.cprt = 1 AND zh.hsflg = 2) OR (z.cprt = 0) OR (z.cprt = 1 AND z.swgflg = 1)) ");
                            break;

                        //// 修正仕訳のみ（行変更を含まない）
                        case SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.NotContainingLineChangedSiwake:
                            whereStatement.AppendLine("  AND ((zh.cprt = 0 AND zh.hsflg < 2) OR (z.cprt = 0)) ");
                            break;
                    }
                }
            }

            //// 取消仕訳を結果に含めない
            if (!queryParameter.SiwakeTyouhyouQueryOption.IsContainTorikesiSiwake)
            {
                whereStatement.AppendLine("  AND zh.delf = 0 ");
                whereStatement.AppendLine("  AND z.delf = 0 ");
            }

            //// 借方項目
            var karikataWhereStatement = this.CreateTaisyakubetuItemWhereStatement(queryParameter, true, "r");

            //// 貸方項目
            var kasikataWhereStatement = this.CreateTaisyakubetuItemWhereStatement(queryParameter, !queryParameter.SiwakeTyouhyouQueryOption.IsSetConditionEachTaisyaku, "s");

            whereStatement
                .AppendFormatIfTrue(
                    !karikataWhereStatement.IsEmpty || !kasikataWhereStatement.IsEmpty,
                    "  AND ({0}{1}{2}) ",
                    karikataWhereStatement.GetSqlStatement(),
                    !karikataWhereStatement.IsEmpty && !kasikataWhereStatement.IsEmpty ? (queryParameter.SiwakeTyouhyouQueryOption.IsSetConditionEachTaisyaku ? " AND " : " OR ") : string.Empty,
                    kasikataWhereStatement.GetSqlStatement())
                .AddSqlParameters(karikataWhereStatement.GetSqlParameters())
                .AddSqlParameters(kasikataWhereStatement.GetSqlParameters());
        }

        /// <summary>
        /// 税対象科目の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の省略不可")]
        private void AppendSyouhizeiTaisyouKamokuWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.SyouhizeiTaisyouKamokuRangeValue.IsOutputNotInputOnly)
            {
                //// 未入力のみ
                whereStatement.AppendLine("  AND z.zkmk IS NULL ");
                whereStatement.Append("  AND (((z.rzkb != 99 OR z.rzkb != 61 OR z.rzkb != 62) AND ");
                whereStatement.Append(
                    "EXISTS (SELECT kmk.kesn FROM kname kmk WHERE kmk.kesn = :p AND kmk.sy01 IN (21, 22) AND kmk.kicd = z.rkmk)) OR ",
                    queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
                whereStatement.Append("(((z.szkb != 99 OR z.szkb != 61 OR z.szkb != 62) AND ");
                whereStatement.AppendLine(
                    "EXISTS (SELECT kmk.kesn FROM kname kmk WHERE kmk.kesn = :p AND kmk.sy01 IN (21, 22) AND kmk.kicd = z.skmk))) ",
                    queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
            }
            else
            {
                //// 科目
                if (queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue != null
                    || queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue != null)
                {
                    // 開始＝終了の場合
                    if (queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue?.Kicd == queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue?.Kicd)
                    {
                        whereStatement.AppendLine("  AND z.zkmk = :p ", queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue.Kicd);
                    }
                    else
                    {
                        switch (queryOption.KaisyaSyoriKikan.Syoriki.KamokuOutputOrder)
                        {
                            // 出力コード順
                            case KamokuOutputOrder.ByOutputOrderCode:
                                // 開始
                                if (queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue != null)
                                {
                                    whereStatement.Append("  AND z.zkmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = z.kesn AND kmk.bkbn = 5 AND ");
                                    whereStatement.AppendLine(
                                        "(kmk.kocd > :p OR (kmk.kocd = :p AND kmk.kcod >= :p))) ",
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue.OutputOrder,
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue.OutputOrder,
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue.Kcod);
                                }

                                // 終了
                                if (queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue != null)
                                {
                                    whereStatement.Append("  AND z.zkmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = z.kesn AND kmk.bkbn = 5 AND ");
                                    whereStatement.AppendLine(
                                        "(kmk.kocd > :p OR (kmk.kocd = :p AND kmk.kcod >= :p))) ",
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue.OutputOrder,
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue.OutputOrder,
                                        queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue.Kcod);
                                }

                                break;

                            // 入力コード順
                            case KamokuOutputOrder.ByInputCode:
                                whereStatement.Append(
                                    "  AND z.zkmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = :p AND kmk.bkbn = 5",
                                    queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
                                whereStatement.AppendWhereStatementByCodeRange(
                                    "kmk.kcod",
                                    queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue?.Kcod,
                                    queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue?.Kcod,
                                    true);
                                whereStatement.AppendLine(") ");
                                break;

                            // 内部コード順
                            case KamokuOutputOrder.ByInnerCode:
                                whereStatement.AppendWhereStatementByCodeRange(
                                    "z.zkmk",
                                    queryOption.SyouhizeiTaisyouKamokuRangeValue.StartValue?.Kicd,
                                    queryOption.SyouhizeiTaisyouKamokuRangeValue.EndValue?.Kicd,
                                    true);
                                break;
                        }
                    }
                }

                //// 税率
                if (queryOption.SyouhizeiTaisyouKamokuSyouhizeiritu?.Zeiritu.GetValue() > 0)
                {
                    whereStatement.AppendLine(
                        "  AND z.zrit = :p ",
                        queryOption.SyouhizeiTaisyouKamokuSyouhizeiritu.Zeiritu.GetValue() * 10000);
                    whereStatement.AppendLine(
                        "  AND z.zkeigen = :p ",
                        queryOption.SyouhizeiTaisyouKamokuSyouhizeiritu.IsKeigenzeiritu ? 1 : 0);
                }

                //// 課税区分
                switch (queryOption.SyouhizeiTaisyouKamokuKazeiKubun)
                {
                    case KazeiKubunSearchType.指定なし:
                    case KazeiKubunSearchType.対象外:
                        break;

                    case KazeiKubunSearchType.税込系:
                        whereStatement.AppendLine("  AND z.zzkb IN (1, 11, 12) ");
                        break;

                    case KazeiKubunSearchType.税抜系:
                        whereStatement.AppendLine("  AND z.zzkb IN (2, 13, 14) ");
                        break;

                    case KazeiKubunSearchType.非課税系:
                        whereStatement.AppendLine("  AND z.zzkb IN (4, 41, 42) ");
                        break;

                    default:
                        whereStatement.AppendLine("  AND z.zzkb = :p ", (int)queryOption.SyouhizeiTaisyouKamokuKazeiKubun);
                        break;
                }

                //// 業種区分
                if (queryOption.SyouhizeiTaisyouKamokuGyousyuKubun != null)
                {
                    whereStatement.AppendLine("  AND z.zgyo = :p ", (int)queryOption.SyouhizeiTaisyouKamokuGyousyuKubun);
                }

                //// 仕入区分
                if (queryOption.SyouhizeiTaisyouKamokuSiireKubun != null)
                {
                    whereStatement.AppendLine("  AND z.zsre = :p ", (int)queryOption.SyouhizeiTaisyouKamokuSiireKubun);
                }
            }
        }

        /// <summary>
        /// 仕訳作成（更新）方法の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="siwakeCreateAndUpdateWaySiteiMethod">仕訳作成（更新）方法の指定方法</param>
        /// <param name="siwakeWayToCreateList">仕訳作成（更新）方法リスト</param>
        /// <param name="columnName">列名</param>
        private void AppendSiwakeWayToCreateWhereStatement(SqlStatementBuilder whereStatement, SiwakeWayToCreateSiteiMethod siwakeCreateAndUpdateWaySiteiMethod, IList<DenpyouSiwakeWayToCreateSearchType> siwakeWayToCreateList, string columnName)
        {
            switch (siwakeCreateAndUpdateWaySiteiMethod)
            {
                // 指定された作成方法
                case SiwakeWayToCreateSiteiMethod.SiteiMethodOnly:
                    whereStatement.AppendInStatement("  AND", columnName, siwakeWayToCreateList.Select(siwakeWayToCreate => (int)siwakeWayToCreate));
                    break;

                // 指定された作成方法以外
                case SiwakeWayToCreateSiteiMethod.NotSiteiMethodOnly:
                    whereStatement.AppendInStatement("  AND NOT", columnName, siwakeWayToCreateList.Select(siwakeWayToCreate => (int)siwakeWayToCreate));
                    break;
            }
        }

        /// <summary>
        /// 外貨項目の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendGaikaItemWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            //// 外貨金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.gaika",
                queryOption.GaikaKingakuRangeValue.StartValue,
                queryOption.GaikaKingakuRangeValue.EndValue,
                true);

            //// 外貨対価金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.gexvl",
                queryOption.GaikaTaikaKingakuRangeValue.StartValue,
                queryOption.GaikaTaikaKingakuRangeValue.EndValue,
                true);
            if ((queryOption.GaikaTaikaKingakuRangeValue.StartValue != null
                    || queryOption.GaikaTaikaKingakuRangeValue.EndValue != null)
                 && queryOption.TaikaKingakuRangeValue.StartValue == null
                 && queryOption.TaikaKingakuRangeValue.EndValue == null)
            {
                whereStatement.AppendLine("  AND z.tflg = 1 ");
            }

            //// 外貨税込金額
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.gzkvl",
                queryOption.GaikaZeikomiKingakuRangeValue.StartValue,
                queryOption.GaikaZeikomiKingakuRangeValue.EndValue,
                true);
            if ((queryOption.GaikaZeikomiKingakuRangeValue.StartValue != null
                    || queryOption.GaikaZeikomiKingakuRangeValue.EndValue != null)
                 && queryOption.ZeikomiKingakuRangeValue.StartValue == null
                 && queryOption.ZeikomiKingakuRangeValue.EndValue == null)
            {
                whereStatement.AppendLine("  AND z.pflg = 1 ");
                whereStatement.AppendLine("  AND z.bkbn = 1 ");
            }

            //// レート
            whereStatement.AppendWhereStatementByDecimalRange(
                "z.rate",
                queryOption.RateRangeValue.StartValue,
                queryOption.RateRangeValue.EndValue,
                true);

            //// 幣種
            if (queryOption.Heisyu == null)
            {
                // 外貨項目の条件式が追加されている場合のみ、幣種の条件式を追加
                if (queryOption.GaikaKingakuRangeValue.StartValue != null
                    || queryOption.GaikaKingakuRangeValue.EndValue != null
                    || queryOption.GaikaTaikaKingakuRangeValue.StartValue != null
                    || queryOption.GaikaTaikaKingakuRangeValue.EndValue != null
                    || queryOption.GaikaZeikomiKingakuRangeValue.StartValue != null
                    || queryOption.GaikaZeikomiKingakuRangeValue.EndValue != null
                    || queryOption.RateRangeValue.StartValue != null
                    || queryOption.RateRangeValue.EndValue != null)
                {
                    whereStatement.AppendLine("  AND (z.rhei_cd IS NOT NULL OR z.shei_cd IS NOT NULL) ");
                }
            }
            else
            {
                whereStatement.AppendLine("  AND (z.rhei_cd = :p OR z.shei_cd = :p) ", queryOption.Heisyu.Code, queryOption.Heisyu.Code);
            }
        }

        /// <summary>
        /// 貸借共通の科目の条件式を追加します。
        /// </summary>
        /// <param name="whereStatement">SQL文</param>
        /// <param name="queryOption">仕訳帳表問合せオプション</param>
        private void AppendTaisyakuCommonKamokuWhereString(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            var startKamoku = queryOption.KarikataQueryOption.KamokuRangeValue.StartValue;
            var endKamoku = queryOption.KarikataQueryOption.KamokuRangeValue.EndValue;
            var kamokuRangeWhereStatement = new SqlStatementBuilder();
            kamokuRangeWhereStatement.AppendLine("        SELECT ");
            kamokuRangeWhereStatement.AppendLine("          k.kicd ");
            kamokuRangeWhereStatement.AppendLine("        FROM ");
            kamokuRangeWhereStatement.AppendLine("          kname k ");
            kamokuRangeWhereStatement.AppendLine("        WHERE ");
            kamokuRangeWhereStatement.AppendLine("          k.kesn = zh.kesn ");
            kamokuRangeWhereStatement.AppendLine("          AND k.bkbn = 5 ");

            switch (queryOption.KaisyaSyoriKikan.Syoriki.KamokuOutputOrder)
            {
                //// 出力コード順
                case KamokuOutputOrder.ByOutputOrderCode:
                    if (!string.IsNullOrEmpty(startKamoku.Kcod))
                    {
                        kamokuRangeWhereStatement.AppendLine("          AND (k.kocd > :p OR (k.kocd = :p AND k.kcod >= :p)) ", startKamoku.OutputOrder, startKamoku.OutputOrder, startKamoku.Kcod);
                    }

                    if (!string.IsNullOrEmpty(endKamoku.Kcod))
                    {
                        kamokuRangeWhereStatement.AppendLine("          AND (k.kocd < :p OR (k.kocd = :p AND k.kcod <= :p) ) ", endKamoku.OutputOrder, endKamoku.OutputOrder, endKamoku.Kcod);
                    }

                    whereStatement.AppendLine("  AND ((z.rkmk IN ( ");
                    whereStatement.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                    whereStatement.AppendLine("      )) OR (z.skmk IN ( ");
                    whereStatement.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                    whereStatement.AppendLine("      ))) ");
                    break;

                //// 入力コード順
                case KamokuOutputOrder.ByInputCode:
                    kamokuRangeWhereStatement.AppendWhereStatementByCodeRange("k.kcod", startKamoku.Kcod, endKamoku.Kcod, true);

                    whereStatement.AppendLine("  AND ((z.rkmk IN ( ");
                    whereStatement.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                    whereStatement.AppendLine("      )) OR (z.skmk IN ( ");
                    whereStatement.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                    whereStatement.AppendLine("      ))) ");
                    break;

                //// 内部コード順
                case KamokuOutputOrder.ByInnerCode:
                    whereStatement.Append("  AND (( ");
                    whereStatement.AppendWhereStatementByCodeRange(
                        "z.rkmk",
                        startKamoku?.Kicd,
                        endKamoku?.Kicd,
                        false);
                    whereStatement.Append(" ) OR ( ");
                    whereStatement.AppendWhereStatementByCodeRange(
                        "z.skmk",
                        startKamoku?.Kicd,
                        endKamoku?.Kicd,
                        false);
                    whereStatement.AppendLine(" )) ");
                    break;
            }
        }

        /// <summary>
        /// 貸借別の各項目の条件式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isUseKarikataQueryOption">借方側の条件指定オプションを使用するかどうか</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        /// <returns>貸借別の各項目の条件式</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "これ以上の省略不可")]
        private SqlStatementBuilder CreateTaisyakubetuItemWhereStatement(ISiwakeTyouhyouQueryParameter queryParameter, bool isUseKarikataQueryOption, string columnHeaderString)
        {
            var queryOption = isUseKarikataQueryOption
                ? queryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption
                : queryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption;
            var whereStatement = new SqlStatementBuilder();

            //// 税率
            if (queryOption.Syouhizeiritu?.Zeiritu.GetValue() > 0)
            {
                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                whereStatement
                    .AppendFormatAndLine("z.{0}rit = :p ", columnHeaderString)
                    .AddSqlParameter(queryOption.Syouhizeiritu.Zeiritu.GetValue() * 10000);
                whereStatement
                    .AppendFormatAndLine("  AND z.{0}keigen = :p ", columnHeaderString)
                    .AddSqlParameter(queryOption.Syouhizeiritu.IsKeigenzeiritu ? 1 : 0);
            }

            //// 課税区分
            this.AppendKazeiKubunWhereStatement(whereStatement, queryOption, columnHeaderString);

            //// 業種区分
            if (queryOption.GyousyuKubun != null)
            {
                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                whereStatement
                    .AppendFormatAndLine("z.{0}gyo = :p ", columnHeaderString)
                    .AddSqlParameter((int)queryOption.GyousyuKubun);
            }

            //// 仕入区分
            if (queryOption.SiireKubun != null)
            {
                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                whereStatement
                    .AppendFormatAndLine("z.{0}sre = :p ", columnHeaderString)
                    .AddSqlParameter((int)queryOption.SiireKubun);
            }

            //// 科目（入力確定・チェックリスト及び承認処理は貸借共通での設定）
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.Other)
            {
                this.AppendKamokuWhereStatement(whereStatement, queryParameter.SiwakeTyouhyouQueryOption, queryOption, columnHeaderString);
            }

            //// マスター
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}bmn", columnHeaderString), queryOption.BcodRangeValue.StartValue, queryOption.BcodRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}tor", columnHeaderString), queryOption.TrcdRangeValue.StartValue, queryOption.TrcdRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}eda", columnHeaderString), queryOption.EcodRangeValue.StartValue, queryOption.EcodRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}seg", columnHeaderString), queryOption.SgcdRangeValue.StartValue, queryOption.SgcdRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}prj", columnHeaderString), queryOption.PjcdRangeValue.StartValue, queryOption.PjcdRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}koj", columnHeaderString), queryOption.KzcdRangeValue.StartValue, queryOption.KzcdRangeValue.EndValue, !whereStatement.IsEmpty);
            whereStatement.AppendWhereStatementByCodeRange(string.Format("z.{0}kos", columnHeaderString), queryOption.KscdRangeValue.StartValue, queryOption.KscdRangeValue.EndValue, !whereStatement.IsEmpty);

            //// ユニバーサルフィールド
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd01RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm1", columnHeaderString), queryOption.Ufcd01RangeValue.StartValue, queryOption.Ufcd01RangeValue.EndValue, 1, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd02RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm2", columnHeaderString), queryOption.Ufcd02RangeValue.StartValue, queryOption.Ufcd02RangeValue.EndValue, 2, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd03RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm3", columnHeaderString), queryOption.Ufcd03RangeValue.StartValue, queryOption.Ufcd03RangeValue.EndValue, 3, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd04RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm4", columnHeaderString), queryOption.Ufcd04RangeValue.StartValue, queryOption.Ufcd04RangeValue.EndValue, 4, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd05RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm5", columnHeaderString), queryOption.Ufcd05RangeValue.StartValue, queryOption.Ufcd05RangeValue.EndValue, 5, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd06RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm6", columnHeaderString), queryOption.Ufcd06RangeValue.StartValue, queryOption.Ufcd06RangeValue.EndValue, 6, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd07RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm7", columnHeaderString), queryOption.Ufcd07RangeValue.StartValue, queryOption.Ufcd07RangeValue.EndValue, 7, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd08RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm8", columnHeaderString), queryOption.Ufcd08RangeValue.StartValue, queryOption.Ufcd08RangeValue.EndValue, 8, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd09RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm9", columnHeaderString), queryOption.Ufcd09RangeValue.StartValue, queryOption.Ufcd09RangeValue.EndValue, 9, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd10RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm10", columnHeaderString), queryOption.Ufcd10RangeValue.StartValue, queryOption.Ufcd10RangeValue.EndValue, 10, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd11RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm11", columnHeaderString), queryOption.Ufcd11RangeValue.StartValue, queryOption.Ufcd11RangeValue.EndValue, 11, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd12RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm12", columnHeaderString), queryOption.Ufcd12RangeValue.StartValue, queryOption.Ufcd12RangeValue.EndValue, 12, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd13RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm13", columnHeaderString), queryOption.Ufcd13RangeValue.StartValue, queryOption.Ufcd13RangeValue.EndValue, 13, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd14RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm14", columnHeaderString), queryOption.Ufcd14RangeValue.StartValue, queryOption.Ufcd14RangeValue.EndValue, 14, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd15RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm15", columnHeaderString), queryOption.Ufcd15RangeValue.StartValue, queryOption.Ufcd15RangeValue.EndValue, 15, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd16RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm16", columnHeaderString), queryOption.Ufcd16RangeValue.StartValue, queryOption.Ufcd16RangeValue.EndValue, 16, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd17RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm17", columnHeaderString), queryOption.Ufcd17RangeValue.StartValue, queryOption.Ufcd17RangeValue.EndValue, 17, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd18RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm18", columnHeaderString), queryOption.Ufcd18RangeValue.StartValue, queryOption.Ufcd18RangeValue.EndValue, 18, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd19RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm19", columnHeaderString), queryOption.Ufcd19RangeValue.StartValue, queryOption.Ufcd19RangeValue.EndValue, 19, queryParameter.KaisyaSyoriKikan.Syoriki);
            this.AppendUniversalFieldWhereStatement(whereStatement, queryOption.Ufcd20RangeValue.IsSearchWithFullMatch, string.Format("z.{0}dm20", columnHeaderString), queryOption.Ufcd20RangeValue.StartValue, queryOption.Ufcd20RangeValue.EndValue, 20, queryParameter.KaisyaSyoriKikan.Syoriki);

            //// 摘要
            this.AppendTekiyouWhereStatement(whereStatement, queryParameter, queryOption, columnHeaderString);

            //// 摘要コード
            whereStatement.AppendWhereStatementByIntRange(
                string.Format("z.{0}tno", columnHeaderString),
                queryOption.TekiyouCodeRangeValue.StartValue,
                queryOption.TekiyouCodeRangeValue.EndValue,
                !whereStatement.IsEmpty);

            return new SqlStatementBuilder()
                .AppendFormatIfTrue(
                    !whereStatement.IsEmpty,
                    "({0})",
                    whereStatement.GetSqlStatement())
                .AddSqlParameters(whereStatement.GetSqlParameters());
        }

        /// <summary>
        /// 課税区分の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="siwakeTyouhyouTaisyakubetuQueryOption">仕訳帳票貸借別条件指定オプション</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        private void AppendKazeiKubunWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouTaisyakubetuQueryOption siwakeTyouhyouTaisyakubetuQueryOption, string columnHeaderString)
        {
            switch (siwakeTyouhyouTaisyakubetuQueryOption.KazeiKubun)
            {
                case KazeiKubunSearchType.指定なし:
                    break;

                case KazeiKubunSearchType.税込系:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine("z.{0}zkb IN (1, 11, 12) ", columnHeaderString);
                    break;

                case KazeiKubunSearchType.税抜系:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine("z.{0}zkb IN (2, 13, 14) ", columnHeaderString);
                    break;

                case KazeiKubunSearchType.非課税系:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine("z.{0}zkb IN (4, 41, 42) ", columnHeaderString);
                    break;

                case KazeiKubunSearchType.特定収系:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine(
                        "z.{0}zkb IN (SELECT kmk.sy03 FROM tskname tsk INNER JOIN kname kmk ON tsk.kesn = kmk.kesn AND tsk.kicd = kmk.kicd WHERE kmk.kesn = z.kesn AND kmk.kicd = z.{0}kmk AND kmk.sy01 = 1 AND (tsk.tkbn = 1 OR tsk.tkbn = 2 OR tsk.tkbn = 0) AND z.{0}zkb = 100)) ",
                        columnHeaderString);
                    break;

                case KazeiKubunSearchType.対象外:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendLine("z.ifri = 0 ");
                    break;

                case KazeiKubunSearchType.特定収入:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine(
                        "z.{0}zkb IN (SELECT kmk.sy03 FROM tskname tsk INNER JOIN kname kmk ON tsk.kesn = kmk.kesn AND tsk.kicd = kmk.kicd WHERE kmk.kesn = z.kesn AND kmk.kicd = z.{0}kmk AND kmk.sy01 = 1 AND tsk.tkbn = 1 AND z.{0}zkb = 100)) ",
                        columnHeaderString);

                    break;

                case KazeiKubunSearchType.不特定収:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement.AppendFormatAndLine(
                        "z.{0}zkb IN (SELECT kmk.sy03 FROM tskname tsk INNER JOIN kname kmk ON tsk.kesn = kmk.kesn AND tsk.kicd = kmk.kicd WHERE kmk.kesn = z.kesn AND kmk.kicd = z.{0}kmk AND kmk.sy01 = 1 AND tsk.tkbn = 2 AND z.{0}zkb = 100)) ",
                        columnHeaderString);
                    break;

                default:
                    whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                    whereStatement
                        .AppendFormatAndLine("z.{0}zkb  = :p ", columnHeaderString)
                        .AddSqlParameter((int)siwakeTyouhyouTaisyakubetuQueryOption.KazeiKubun.ConvertKazeiKubunSearchTypeToKazeiKubun());
                    break;
            }
        }

        /// <summary>
        /// 科目の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        /// <param name="siwakeTyouhyouTaisyakubetuQueryOption">貸借別の仕訳帳票問合せオプション</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private void AppendKamokuWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption, SiwakeTyouhyouTaisyakubetuQueryOption siwakeTyouhyouTaisyakubetuQueryOption, string columnHeaderString)
        {
            switch (queryOption.KamokuSiteiMethod)
            {
                // 単一指定
                case KamokuSiteiMethod.TanituSitei:
                    if (siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue != null)
                    {
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement
                            .AppendFormatAndLine("z.{0}kmk = :p ", columnHeaderString)
                            .AddSqlParameter(siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue.Kicd);
                    }
                    break;

                // 範囲指定
                case KamokuSiteiMethod.RangeSitei:
                    switch (queryOption.KaisyaSyoriKikan.Syoriki.KamokuOutputOrder)
                    {
                        // 出力コード順
                        case KamokuOutputOrder.ByOutputOrderCode:
                            if (siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue != null)
                            {
                                // 開始
                                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                                whereStatement
                                    .AppendFormatAndLine("z.{0}kmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = z.kesn AND kmk.bkbn = 5 AND (kmk.kocd > :p OR (kmk.kocd = :p AND kmk.kcod >= :p))) ", columnHeaderString)
                                    .AddSqlParameters(
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue.OutputOrder,
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue.OutputOrder,
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue.Kcod);
                            }
                            if (siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue != null)
                            {
                                // 終了
                                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                                whereStatement
                                    .AppendFormatAndLine("z.{0}kmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = z.kesn AND kmk.bkbn = 5 AND (kmk.kocd < :p OR (kmk.kocd = :p AND kmk.kcod <= :p))) ", columnHeaderString)
                                    .AddSqlParameters(
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue.OutputOrder,
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue.OutputOrder,
                                        siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue.Kcod);
                            }
                            break;

                        // 入力コード順
                        case KamokuOutputOrder.ByInputCode:
                            if (siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue != null
                                || siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue != null)
                            {
                                whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                                whereStatement.AppendFormatAndLine("z.{0}kmk IN (SELECT kmk.kicd FROM kname kmk WHERE kmk.kesn = z.kesn AND kmk.bkbn = 5 ", columnHeaderString);
                                whereStatement.AppendWhereStatementByCodeRange(
                                    "kmk.kcod",
                                    siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue?.Kcod,
                                    siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue?.Kcod,
                                    true);
                                whereStatement.AppendLine(") ");
                            }
                            break;

                        // 内部コード順
                        case KamokuOutputOrder.ByInnerCode:
                            whereStatement.AppendWhereStatementByCodeRange(
                                string.Format("z.{0}kmk", columnHeaderString),
                                siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.StartValue?.Kicd,
                                siwakeTyouhyouTaisyakubetuQueryOption.KamokuRangeValue.EndValue?.Kicd,
                                !whereStatement.IsEmpty);
                            break;
                    }
                    break;

                // 個別指定
                case KamokuSiteiMethod.KobetuSitei:
                    if (siwakeTyouhyouTaisyakubetuQueryOption.KamokuKobetuSiteiList.Any())
                    {
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        this.AppendKamokuKobetuSiteiWhereStatement(whereStatement, queryOption, columnHeaderString);
                    }
                    break;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドの条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="isSearchWithFullMatch">ユニバーサルフィールドを完全一致で検索するかどうか</param>
        /// <param name="columnName">列名</param>
        /// <param name="startCode">開始コード</param>
        /// <param name="endCode">終了コード</param>
        /// <param name="universalFieldNo">ユニバーサルフィールドNo</param>
        /// <param name="syoriki">処理期情報</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private void AppendUniversalFieldWhereStatement(SqlStatementBuilder whereStatement, bool isSearchWithFullMatch, string columnName, object startCode, object endCode, int universalFieldNo, Syoriki syoriki)
        {
            var universalFieldInfo = syoriki.GetUniversalFieldInfo(false, universalFieldNo);
            switch (universalFieldInfo.DataType)
            {
                // 日付
                case UniversalFieldDataType.Date:
                    whereStatement.AppendWhereStatementByCodeRange(
                        columnName,
                        (startCode as IcspDateTime)?.Ymd.ToString(),
                        (endCode as IcspDateTime)?.Ymd.ToString(),
                        !whereStatement.IsEmpty);
                    break;

                // 文字
                case UniversalFieldDataType.Char:
                    if (isSearchWithFullMatch)
                    {
                        // 完全一致
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement.AppendFormat("{0} ", columnName);
                        if (startCode == null)
                        {
                            whereStatement.AppendLine("IS NULL ");
                        }
                        else
                        {
                            whereStatement.AppendLine("= :p ", startCode);
                        }
                    }
                    else if (startCode != null)
                    {
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement
                            .AppendFormatAndLine("{0}> 0 ", this.dbReservedWords.GetCharIndexFunction("UPPER(:p)", string.Format("UPPER({0})", columnName)))
                            .AddSqlParameter(startCode?.ToString());
                    }
                    break;

                default:
                    var universalFieldCodeFormat = new UniversalFieldCodeFormat();
                    whereStatement.AppendWhereStatementByCodeRange(
                        columnName,
                        universalFieldCodeFormat.GetCodeFromIOValue(startCode?.ToString(), universalFieldInfo, syoriki.Gengou, string.Empty),
                        universalFieldCodeFormat.GetCodeFromIOValue(endCode?.ToString(), universalFieldInfo, syoriki.Gengou, string.Empty),
                        !whereStatement.IsEmpty);
                    break;
            }
        }

        /// <summary>
        /// 摘要の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="siwakeTyouhyouTaisyakubetuQueryOption">貸借別の仕訳帳票問合せオプションパターン</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目・条件が多いため、分割困難")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private void AppendTekiyouWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter, SiwakeTyouhyouTaisyakubetuQueryOption siwakeTyouhyouTaisyakubetuQueryOption, string columnHeaderString)
        {
            var tekiyouStringList = !string.IsNullOrEmpty(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue)
                ? siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue.Replace("　", " ").Split(' ').ToList()
                : new List<string>();
            switch (queryParameter.TekiyouCharacterDivisionType)
            {
                // 分割しない
                case SiwakeTyouhyouTekiyouCharacterDivisionType.None:
                    if (siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition <= TekiyouSearchCondition.NotContain)
                    {
                        // 完全一致で検索しない場合（「含む」、または「含まない」）
                        if (!string.IsNullOrEmpty(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue))
                        {
                            whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                            whereStatement.AppendIfTrue(
                                siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain,
                                "NOT EXISTS (SELECT kesn FROM zdata WHERE ");
                            whereStatement
                                .AppendFormatAndLine("{0}> 0{1} ", this.dbReservedWords.GetCharIndexFunction("UPPER(:p)", string.Format("UPPER(z.{0}tky)", columnHeaderString)), siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain ? ")" : string.Empty)
                                .AddSqlParameter(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue);
                            whereStatement.AppendLine(" AND z.dflg IN (0, :p) ", columnHeaderString == "r" ? 1 : 2);
                        }
                    }
                    else
                    {
                        // 完全一致で検索する場合（「等しい」、または「等しくない」）
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement.AppendIfTrue(
                            !string.IsNullOrEmpty(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue) && siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotEqual,
                            "NOT EXISTS (SELECT kesn FROM zdata WHERE ");
                        whereStatement.AppendFormat("z.{0}tky ", columnHeaderString);
                        if (string.IsNullOrEmpty(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue))
                        {
                            whereStatement.AppendFormatAndLine("IS{0} NULL ", siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotEqual ? " NOT" : string.Empty);
                        }
                        else
                        {
                            whereStatement
                                .AppendFormatAndLine("= :p{0} ", siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotEqual ? ")" : string.Empty)
                                .AddSqlParameter(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouRangeValue.StartValue);
                        }
                        whereStatement.AppendLine(" AND z.dflg IN (0, :p) ", columnHeaderString == "r" ? 1 : 2);
                    }
                    break;

                // OR条件で検索
                case SiwakeTyouhyouTekiyouCharacterDivisionType.OrZyoukenSearch:
                    if (siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition <= TekiyouSearchCondition.NotContain)
                    {
                        // 完全一致で検索しない場合（「含む」、または「含まない」）
                        if (tekiyouStringList.Any())
                        {
                            whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                            whereStatement.Append("(");
                            whereStatement.AppendIfTrue(
                                siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain,
                                "NOT EXISTS (SELECT kesn FROM zdata WHERE ");
                            var isAddWhereString = false;
                            foreach (var tekiyouString in tekiyouStringList)
                            {
                                if (!string.IsNullOrEmpty(tekiyouString))
                                {
                                    if (isAddWhereString)
                                    {
                                        whereStatement.Append("OR");
                                    }
                                    whereStatement
                                        .AppendFormatAndLine("{0}> 0 ", this.dbReservedWords.GetCharIndexFunction("UPPER(:p)", string.Format("UPPER(z.{0}tky)", columnHeaderString)))
                                        .AddSqlParameter(tekiyouString);
                                    isAddWhereString = true;
                                }
                            }
                            whereStatement.AppendIfTrue(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain, ")");
                            whereStatement.AppendLine(") AND z.dflg IN (0, :p) ", columnHeaderString == "r" ? 1 : 2);
                        }
                    }
                    else
                    {
                        // 完全一致で検索する場合（「等しい」、または「等しくない」）
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement.Append("(");
                        whereStatement.AppendIfTrue(
                            siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotEqual,
                            "NOT EXISTS (SELECT kesn FROM zdata WHERE ");
                        if (tekiyouStringList.Any())
                        {
                            var isAddWhereString = false;
                            foreach (var tekiyouString in tekiyouStringList)
                            {
                                if (isAddWhereString)
                                {
                                    whereStatement.Append(" OR ");
                                }
                                whereStatement.AppendFormat("z.{0}tky ", columnHeaderString);
                                if (string.IsNullOrEmpty(tekiyouString))
                                {
                                    whereStatement.Append("IS NULL ");
                                }
                                else
                                {
                                    whereStatement.Append("= :p ", tekiyouString);
                                }
                                isAddWhereString = true;
                            }
                        }
                        else
                        {
                            whereStatement.AppendFormat("z.{0}tky IS NULL ", columnHeaderString);
                        }
                        whereStatement.AppendIfTrue(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotEqual, ")");
                        whereStatement.AppendLine(") AND z.dflg IN (0, :p) ", columnHeaderString == "r" ? 1 : 2);
                    }
                    break;

                // AND条件で検索
                case SiwakeTyouhyouTekiyouCharacterDivisionType.AndZyoukenSearch:
                    if (siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition <= TekiyouSearchCondition.NotContain
                        && tekiyouStringList.Any())
                    {
                        // 完全一致で検索しない場合（「含む」、または「含まない」）
                        whereStatement.AppendIfCurrentSqlStatementIsNotEmpty("  AND ");
                        whereStatement.Append("(");
                        whereStatement.AppendIfTrue(
                            siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain,
                            "NOT EXISTS (SELECT kesn FROM zdata WHERE ");
                        var isAddWhereString = false;
                        foreach (var tekiyouString in tekiyouStringList)
                        {
                            if (!string.IsNullOrEmpty(tekiyouString))
                            {
                                if (isAddWhereString)
                                {
                                    whereStatement.Append(" AND ");
                                }
                                whereStatement
                                    .AppendFormatAndLine("{0}> 0 ", this.dbReservedWords.GetCharIndexFunction("UPPER(:p)", string.Format("UPPER(z.{0}tky)", columnHeaderString)))
                                    .AddSqlParameter(tekiyouString);
                                isAddWhereString = true;
                            }
                        }
                        whereStatement.AppendIfTrue(siwakeTyouhyouTaisyakubetuQueryOption.TekiyouSearchCondition == TekiyouSearchCondition.NotContain, ")");
                        whereStatement.AppendLine(") AND z.dflg IN (0, :p) ", columnHeaderString == "r" ? 1 : 2);
                    }
                    break;
            }
        }

        /// <summary>
        /// 伝票項目未入力チェックの条件式を追加します
        /// </summary>
        /// <param name="notInputCheckWhereStatement">条件式（追加前）</param>
        /// <param name="columnName">列名</param>
        /// <param name="isUseNotInputCheck">未入力チェックをおこなうかどうか</param>
        private void AppendNotInputCheckDenpyouItemWhereStatement(SqlStatementBuilder notInputCheckWhereStatement, string columnName, bool isUseNotInputCheck)
        {
            if (isUseNotInputCheck)
            {
                if (notInputCheckWhereStatement.IsEmpty)
                {
                    notInputCheckWhereStatement.Append("  AND (");
                }
                else
                {
                    notInputCheckWhereStatement.Append(" OR ");
                }

                notInputCheckWhereStatement.AppendFormat("{0} IS NULL", columnName);
            }
        }

        /// <summary>
        /// 仕訳項目未入力チェックの条件式を追加します
        /// </summary>
        /// <param name="notInputCheckWhereStatement">条件式（追加前）</param>
        /// <param name="kesn">内部決算期</param>
        /// <param name="karikataColumnName">借方列の名称</param>
        /// <param name="kasikataColumnName">貸方列の名称</param>
        /// <param name="notInputCheckColumnName">未入力チェック列の名称</param>
        /// <param name="isUseNotInputCheck">未入力チェックをおこなうかどうか</param>
        private void AppendNotInputCheckSiwakeItemWhereStatement(SqlStatementBuilder notInputCheckWhereStatement, int kesn, string karikataColumnName, string kasikataColumnName, string notInputCheckColumnName, bool isUseNotInputCheck)
        {
            if (isUseNotInputCheck)
            {
                if (notInputCheckWhereStatement.IsEmpty)
                {
                    notInputCheckWhereStatement.Append("  AND (");
                }
                else
                {
                    notInputCheckWhereStatement.Append(" OR ");
                }

                notInputCheckWhereStatement
                    .AppendFormat(
                        "({0} IS NULL AND EXISTS (SELECT rk.kesn FROM kname rk WHERE rk.kesn = :p AND rk.{1} = 1 AND rk.kicd = z.rkmk)) OR ",
                        karikataColumnName,
                        notInputCheckColumnName)
                    .AddSqlParameter(kesn);
                notInputCheckWhereStatement
                    .AppendFormat(
                        "({0} IS NULL AND EXISTS (SELECT sk.kesn FROM kname sk WHERE sk.kesn = :p AND sk.{1} = 1 AND sk.kicd = z.skmk))",
                        kasikataColumnName,
                        notInputCheckColumnName)
                    .AddSqlParameter(kesn);
            }
        }

        /// <summary>
        /// 部門単位出力の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳票問合せオプション</param>
        private void AppendBumonTaniOutputSettingWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption)
        {
            switch (queryOption.BumonTaniOutputSetting)
            {
                // 部門単位（範囲）
                case BumonTaniOutputSetting.BumonRangeSitei:
                    if (!string.IsNullOrEmpty(queryOption.BcodRangeValue.StartValue)
                        || !string.IsNullOrEmpty(queryOption.BcodRangeValue.EndValue))
                    {
                        whereStatement.Append("  AND ((");
                        whereStatement.AppendWhereStatementByCodeRange("z.rbmn", queryOption.BcodRangeValue.StartValue, queryOption.BcodRangeValue.EndValue, false);
                        whereStatement.Append(") OR (");
                        whereStatement.AppendWhereStatementByCodeRange("z.sbmn", queryOption.BcodRangeValue.StartValue, queryOption.BcodRangeValue.EndValue, false);
                        whereStatement.AppendLine(")) ");
                    }

                    break;

                // 部門単位（個別）
                case BumonTaniOutputSetting.BumonKobetuSitei:
                    if (queryOption.BcodKobetuSiteiList.Count != 0)
                    {
                        whereStatement.Append("  AND ((");
                        this.AppendBumonKobetuSiteiWhereStatement(whereStatement, queryOption, queryOption.BcodKobetuSiteiList, "z.rbmn");
                        whereStatement.Append(") OR (");
                        this.AppendBumonKobetuSiteiWhereStatement(whereStatement, queryOption, queryOption.BcodKobetuSiteiList, "z.sbmn");
                        whereStatement.AppendLine(")) ");
                    }

                    break;

                // 集計部門単位（範囲）
                case BumonTaniOutputSetting.SyuukeiBumonRangeSitei:
                    if (!string.IsNullOrEmpty(queryOption.BcodRangeValue.StartValue)
                        || !string.IsNullOrEmpty(queryOption.BcodRangeValue.EndValue))
                    {
                        whereStatement.Append(
                            "  AND ((z.rbmn IN (SELECT bcod FROM sbtbl WHERE kesn = :p AND sbcd BETWEEN :p AND :p)) ",
                            queryOption.KaisyaSyoriKikan.Syoriki.Kesn,
                            queryOption.BcodRangeValue.StartValue,
                            queryOption.BcodRangeValue.EndValue);
                        whereStatement.AppendLine(
                            "OR (z.sbmn IN (SELECT bcod FROM sbtbl WHERE kesn = :p AND sbcd BETWEEN :p AND :p))) ",
                            queryOption.KaisyaSyoriKikan.Syoriki.Kesn,
                            queryOption.BcodRangeValue.StartValue,
                            queryOption.BcodRangeValue.EndValue);
                    }

                    break;

                // 集計部門単位（個別）
                case BumonTaniOutputSetting.SyuukeiBumonKobetuSitei:
                    whereStatement.Append("  AND ((z.rbmn IN (SELECT bcod FROM sbtbl WHERE kesn = :p ", queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
                    if (queryOption.BcodKobetuSiteiList.Count != 0)
                    {
                        whereStatement.Append("AND (");
                        this.AppendBumonKobetuSiteiWhereStatement(whereStatement, queryOption, queryOption.BcodKobetuSiteiList, "sbcd");
                        whereStatement.Append(")");
                    }

                    whereStatement.Append(")) OR (z.sbmn IN (SELECT bcod FROM sbtbl WHERE kesn = :p ", queryOption.KaisyaSyoriKikan.Syoriki.Kesn);
                    if (queryOption.BcodKobetuSiteiList.Count != 0)
                    {
                        whereStatement.Append("AND (");
                        this.AppendBumonKobetuSiteiWhereStatement(whereStatement, queryOption, queryOption.BcodKobetuSiteiList, "sbcd");
                        whereStatement.Append(")");
                    }

                    whereStatement.AppendLine("))) ");
                    break;
            }
        }

        /// <summary>
        /// 科目個別指定の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳表条件指定オプション</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        private void AppendKamokuKobetuSiteiWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption, string columnHeaderString)
        {
            if (queryOption.IsSetConditionEachTaisyaku)
            {
                //// 貸借別では、借方側で纏めて条件式を追加
                if (columnHeaderString == "s")
                {
                    return;
                }

                whereStatement.Append("(");
                for (int i = 0; i < queryOption.KarikataQueryOption.KamokuKobetuSiteiList.Count; i++)
                {
                    whereStatement.AppendIfTrue(i >= 1, "OR ");
                    whereStatement.Append("(");
                    whereStatement.AppendIfTrue(!string.IsNullOrEmpty(queryOption.KarikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd), "z.rkmk = :p ", queryOption.KarikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd);
                    whereStatement.AppendIfTrue(!string.IsNullOrEmpty(queryOption.KarikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd) && !string.IsNullOrEmpty(queryOption.KasikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd), "AND ");
                    whereStatement.AppendIfTrue(!string.IsNullOrEmpty(queryOption.KasikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd), "z.skmk = :p ", queryOption.KasikataQueryOption.KamokuKobetuSiteiList[i]?.Kicd);
                    whereStatement.Append(") ");
                }

                whereStatement.AppendLine(") ");
            }
            else
            {
                var kamokuKobetuSiteiList = columnHeaderString == "r"
                    ? queryOption.KarikataQueryOption.KamokuKobetuSiteiList.Where(kamoku => kamoku != null).Select(kamoku => kamoku.Kicd)
                    : queryOption.KasikataQueryOption.KamokuKobetuSiteiList.Where(kamoku => kamoku != null).Select(kamoku => kamoku.Kicd);
                whereStatement.AppendInStatement(string.Format("z.{0}kmk", columnHeaderString), kamokuKobetuSiteiList);
            }
        }

        /// <summary>
        /// 部門個別指定の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryOption">仕訳帳表条件指定オプション</param>
        /// <param name="bumonKobetuSiteiList">部門個別指定リスト</param>
        /// <param name="columnName">列名</param>
        private void AppendBumonKobetuSiteiWhereStatement(SqlStatementBuilder whereStatement, SiwakeTyouhyouQueryOption queryOption, IList<string> bumonKobetuSiteiList, string columnName)
            => whereStatement.AppendInStatement(columnName, bumonKobetuSiteiList);

        /// <summary>
        /// セキュリティ関連の条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendSecurityRelatedWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            // 貸借とも科目が出力できない仕訳を除外
            if (queryParameter.SiwakeTyouhyouQueryOption.IsUseSecurity
                && queryParameter.SecurityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true
                && queryParameter.IsNotOutputKamokuNotDisplayedSiwake)
            {
                if (queryParameter.SecurityContext.IsZikosiwakeOutputPermittedUser)
                {
                    // 自己仕訳に対するセキュリティ解除時、権限を伝票作成者で判断
                    whereStatement.Append("  AND ((zh.fusr = :p) OR ", queryParameter.SecurityContext.GetUserKaisyabetuSecurity().UserCode);
                }
                else
                {
                    whereStatement.Append("  AND (");
                }

                whereStatement.Append("EXISTS (SELECT sk.kesn FROM sczkm sk WHERE sk.kesn = z.kesn AND sk.skbn = :p AND sk.sptn = :p AND (sk.szkm = z.rkmk OR sk.szkm = z.skmk))) ", queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList ? 1 : 0, queryParameter.SecurityContext.SecurityPattern.PatternNo);
            }

            if (queryParameter.SecurityContext.SecurityInitialSetting?.UseZandakaSecurity == true
                && queryParameter.SecurityContext.SecurityInitialSetting?.UseZandakaSecurityWhenOutputSiwake == true
                && (queryParameter.SecurityContext.SecurityPattern?.AllowOutputKamokuZandaka == false
                    || queryParameter.SecurityContext.SecurityInitialSetting?.UseZaimuKamokuOutputSecurity == true))
            {
                this.AppendZandakaSecurityWhereStatement(whereStatement, queryParameter);
            }
        }

        /// <summary>
        /// 残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="whereStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        private void AppendZandakaSecurityWhereStatement(SqlStatementBuilder whereStatement, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            //// 入力確定・チェックリストは入力セキュリティを参照、別のことは出力セキュリティを参照
            var karikataKamokuSecurityWhereStatement = new SqlStatementBuilder("z.rkmk IN (SELECT sck.szkm FROM sczkm sck WHERE sck.kesn = :p AND sck.sptn = :p AND sck.szkm = z.rkmk AND sck.skbn = :p)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo, queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList ? 1 : 0);
            var kasikataKamokuSecurityWhereStatement = new SqlStatementBuilder("z.skmk IN (SELECT sck.szkm FROM sczkm sck WHERE sck.kesn = :p AND sck.sptn = :p AND sck.szkm = z.skmk AND sck.skbn = :p)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo, queryParameter.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList ? 1 : 0);
            var zandakaSecurityWhereStatement = new SqlStatementBuilder();

            //// 科目残高
            if (queryParameter.SecurityContext.SecurityPattern.AllowOutputKamokuZandaka
                && queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuKamokuOutputSecurity)
            {
                zandakaSecurityWhereStatement.Append("(");
                zandakaSecurityWhereStatement.Append(karikataKamokuSecurityWhereStatement.GetSqlStatement(), karikataKamokuSecurityWhereStatement.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(" OR ");
                zandakaSecurityWhereStatement.Append(kasikataKamokuSecurityWhereStatement.GetSqlStatement(), kasikataKamokuSecurityWhereStatement.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(")");
            }

            //// 入力確定・チェックリスト以外のみチェック
            if (queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.CheckList)
            {
                var karikataKamokuEdabanSecurityWhereStatement = new SqlStatementBuilder("z.reda IN (SELECT sce.szed FROM sczed sce WHERE sce.kesn = :p AND sce.sptn = :p AND sce.szed = z.reda AND sce.skbn = 0 AND sce.szkm = z.rkmk)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var kasikataKamokuEdabanSecurityWhereStatement = new SqlStatementBuilder("z.seda IN (SELECT sce.szed FROM sczed sce WHERE sce.kesn = :p AND sce.sptn = :p AND sce.szed = z.seda AND sce.skbn = 0 AND sce.szkm = z.skmk)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var karikataBumonSecurityWhereStatement = new SqlStatementBuilder("z.rbmn IN (SELECT scb.szbm FROM sczbm scb WHERE scb.kesn = :p AND scb.sptn = :p AND scb.szbm = z.rbmn AND scb.skbn = 0)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var kasikataBumonSecurityWhereStatement = new SqlStatementBuilder("z.sbmn IN (SELECT scb.szbm FROM sczbm scb WHERE scb.kesn = :p AND scb.sptn = :p AND scb.szbm = z.sbmn AND scb.skbn = 0)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var karikataTorihikisakiSecurityWhereStatement = new SqlStatementBuilder("z.rtor IN (SELECT sct.sztr FROM scztr sct WHERE sct.kesn = :p AND sct.sptn = :p AND sct.sztr = z.rtor AND sct.skbn = 0)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var kasikataTorihikisakiSecurityWhereStatement = new SqlStatementBuilder("z.stor IN (SELECT sct.sztr FROM scztr sct WHERE sct.kesn = :p AND sct.sptn = :p AND sct.sztr = z.stor AND sct.skbn = 0)", queryParameter.Kesn, queryParameter.SecurityContext.SecurityPattern.PatternNo);
                var karikataBumonKamokuEdabanSecurityWhereStatement = new SqlStatementBuilder("z.rkmk IN (SELECT bke.kicd FROM bkezan bke WHERE bke.kesn = :p AND bke.bcod = z.rbmn AND bke.ecod = z.reda)", queryParameter.Kesn);
                var kasikataBumonKamokuEdabanSecurityWhereStatement = new SqlStatementBuilder("z.skmk IN (SELECT bke.kicd FROM bkezan bke WHERE bke.kesn = :p AND bke.bcod = z.sbmn AND bke.ecod = z.seda)", queryParameter.Kesn);
                var karikataBumonKamokuTorihikisakiSecurityWhereStatement = new SqlStatementBuilder("z.rkmk IN (SELECT btk.kicd FROM btkzan btk WHERE btk.kesn = :p AND btk.bcod = z.rbmn AND btk.trcd = z.rtor)", queryParameter.Kesn);
                var kasikataBumonKamokuTorihikisakiSecurityWhereStatement = new SqlStatementBuilder("z.skmk IN (SELECT btk.kicd FROM btkzan btk WHERE btk.kesn = :p AND btk.bcod = z.sbmn AND btk.trcd = z.stor)", queryParameter.Kesn);

                //// 枝番残高
                if (queryParameter.SecurityContext.SecurityPattern.AllowOutputKamokuEdabanZandaka)
                {
                    zandakaSecurityWhereStatement.AppendIfCurrentSqlStatementIsNotEmpty(" OR ");
                    zandakaSecurityWhereStatement.Append("(");
                    this.AppendKamokuEdabanZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, karikataKamokuSecurityWhereStatement, karikataKamokuEdabanSecurityWhereStatement, "r", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(" OR ");
                    this.AppendKamokuEdabanZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, kasikataKamokuSecurityWhereStatement, kasikataKamokuEdabanSecurityWhereStatement, "s", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(")");
                }

                //// 部門残高
                if (queryParameter.SecurityContext.SecurityPattern.AllowOutputBumonKamokuZandaka)
                {
                    zandakaSecurityWhereStatement.AppendIfCurrentSqlStatementIsNotEmpty(" OR ");
                    zandakaSecurityWhereStatement.Append("(");
                    this.AppendBumonKamokuZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, karikataBumonSecurityWhereStatement, karikataKamokuSecurityWhereStatement, "r", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(" OR ");
                    this.AppendBumonKamokuZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, kasikataBumonSecurityWhereStatement, kasikataKamokuSecurityWhereStatement, "s", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(")");
                }

                //// 取引先残高
                if (queryParameter.SecurityContext.SecurityPattern.AllowOutputKamokuTorihikisakiZandaka)
                {
                    zandakaSecurityWhereStatement.AppendIfCurrentSqlStatementIsNotEmpty(" OR ");
                    zandakaSecurityWhereStatement.Append("(");
                    this.AppendKamokuTorihikisakiZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, karikataKamokuSecurityWhereStatement, karikataTorihikisakiSecurityWhereStatement, "r", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(" OR ");
                    this.AppendKamokuTorihikisakiZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, kasikataKamokuSecurityWhereStatement, kasikataTorihikisakiSecurityWhereStatement, "s", queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(")");
                }

                //// 部門科目枝番残高
                if (queryParameter.SecurityContext.SecurityPattern.AllowOutputBumonKamokuEdabanZandaka
                    && (queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuKamokuOutputSecurity == true
                    || queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuKamokuEdabanOutputSecurity == true
                    || queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuBumonOutputSecurity == true))
                {
                    zandakaSecurityWhereStatement.AppendIfCurrentSqlStatementIsNotEmpty(" OR ");
                    zandakaSecurityWhereStatement.Append("(");
                    this.AppendBumonKamokuEdabanZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, karikataBumonSecurityWhereStatement, karikataKamokuSecurityWhereStatement, karikataKamokuEdabanSecurityWhereStatement, karikataBumonKamokuEdabanSecurityWhereStatement, queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(" OR ");
                    this.AppendBumonKamokuEdabanZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, kasikataBumonSecurityWhereStatement, kasikataKamokuSecurityWhereStatement, kasikataKamokuEdabanSecurityWhereStatement, kasikataBumonKamokuEdabanSecurityWhereStatement, queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(")");
                }

                //// 部門科目取引先残高
                if (queryParameter.SecurityContext.SecurityPattern.AllowOutputBumonKamokuTorihikisakiZandaka
                    && (queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuKamokuOutputSecurity == true
                    || queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuBumonOutputSecurity == true
                    || queryParameter.SecurityContext.SecurityInitialSetting.UseZaimuTorihikisakiOutputSecurity == true))
                {
                    zandakaSecurityWhereStatement.AppendIfCurrentSqlStatementIsNotEmpty(" OR ");
                    zandakaSecurityWhereStatement.Append("(");
                    this.AppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, karikataBumonSecurityWhereStatement, karikataKamokuSecurityWhereStatement, karikataTorihikisakiSecurityWhereStatement, karikataBumonKamokuTorihikisakiSecurityWhereStatement, queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(" OR ");
                    this.AppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement(zandakaSecurityWhereStatement, kasikataBumonSecurityWhereStatement, kasikataKamokuSecurityWhereStatement, kasikataTorihikisakiSecurityWhereStatement, kasikataBumonKamokuTorihikisakiSecurityWhereStatement, queryParameter.SecurityContext.SecurityInitialSetting);
                    zandakaSecurityWhereStatement.Append(")");
                }
            }

            if (!zandakaSecurityWhereStatement.IsEmpty)
            {
                whereStatement.Append("  AND (");
                whereStatement.Append(zandakaSecurityWhereStatement.GetSqlStatement(), zandakaSecurityWhereStatement.GetSqlParameters());
                whereStatement.AppendLine(") ");
            }
        }

        /// <summary>
        /// 科目枝番残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="zandakaSecurityWhereStatement">残高セキュリティの条件式（追加前）</param>
        /// <param name="kamokuSecuritySqlStatementBuilder">科目セキュリティの条件式</param>
        /// <param name="kamokuEdabanSecuritySqlStatementBuilder">科目枝番セキュリティの条件式</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        /// <param name="securityInitialSetting">セキュリティ初期設定情報</param>
        private void AppendKamokuEdabanZandakaSecurityWhereStatement(SqlStatementBuilder zandakaSecurityWhereStatement, SqlStatementBuilder kamokuSecuritySqlStatementBuilder, SqlStatementBuilder kamokuEdabanSecuritySqlStatementBuilder, string columnHeaderString, SecurityInitialSetting securityInitialSetting)
        {
            if (securityInitialSetting?.UseZaimuKamokuOutputSecurity == true
                && securityInitialSetting?.UseZaimuKamokuEdabanOutputSecurity == true)
            {
                zandakaSecurityWhereStatement.Append("(");
                zandakaSecurityWhereStatement.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(" AND ");
                zandakaSecurityWhereStatement.Append(kamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), kamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(")");
            }
            else if (securityInitialSetting?.UseZaimuKamokuOutputSecurity == true)
            {
                zandakaSecurityWhereStatement.AppendFormat("(z.{0}eda IS NOT NULL AND ", columnHeaderString);
                zandakaSecurityWhereStatement.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(")");
            }
            else if (securityInitialSetting?.UseZaimuKamokuEdabanOutputSecurity == true)
            {
                zandakaSecurityWhereStatement.Append(kamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), kamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
            }
            else
            {
                zandakaSecurityWhereStatement.AppendFormat("z.{0}eda IS NOT NULL", columnHeaderString);
            }
        }

        /// <summary>
        /// 部門科目残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="zandakaSecurityWhereStatement">残高セキュリティの条件式（追加前）</param>
        /// <param name="bumonSecuritySqlStatementBuilder">部門セキュリティの条件式</param>
        /// <param name="kamokuSecuritySqlStatementBuilder">科目セキュリティの条件式</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        /// <param name="securityInitialSetting">セキュリティ初期設定情報</param>
        private void AppendBumonKamokuZandakaSecurityWhereStatement(SqlStatementBuilder zandakaSecurityWhereStatement, SqlStatementBuilder bumonSecuritySqlStatementBuilder, SqlStatementBuilder kamokuSecuritySqlStatementBuilder, string columnHeaderString, SecurityInitialSetting securityInitialSetting)
        {
            if (securityInitialSetting.UseZaimuKamokuOutputSecurity
                && securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                zandakaSecurityWhereStatement.Append("(");
                zandakaSecurityWhereStatement.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(" AND ");
                zandakaSecurityWhereStatement.Append(bumonSecuritySqlStatementBuilder.GetSqlStatement(), bumonSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(")");
            }
            else if (securityInitialSetting.UseZaimuKamokuOutputSecurity)
            {
                zandakaSecurityWhereStatement.AppendFormat("(z.{0}bmn IS NOT NULL AND ", columnHeaderString);
                zandakaSecurityWhereStatement.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecurityWhereStatement.Append(")");
            }
            else if (securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                zandakaSecurityWhereStatement.Append(bumonSecuritySqlStatementBuilder.GetSqlStatement(), bumonSecuritySqlStatementBuilder.GetSqlParameters());
            }
            else
            {
                zandakaSecurityWhereStatement.AppendFormat("z.{0}bmn IS NOT NULL", columnHeaderString);
            }
        }

        /// <summary>
        /// 科目取引先残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="zandakaSecuritySqlStatementBuilder">残高セキュリティの条件式（追加前）</param>
        /// <param name="kamokuSecuritySqlStatementBuilder">科目セキュリティの条件式</param>
        /// <param name="torihikisakiSecuritySqlStatementBuilder">取引先セキュリティの条件式</param>
        /// <param name="columnHeaderString">列名の頭に付加する文字列</param>
        /// <param name="securityInitialSetting">セキュリティ初期設定情報</param>
        private void AppendKamokuTorihikisakiZandakaSecurityWhereStatement(SqlStatementBuilder zandakaSecuritySqlStatementBuilder, SqlStatementBuilder kamokuSecuritySqlStatementBuilder, SqlStatementBuilder torihikisakiSecuritySqlStatementBuilder, string columnHeaderString, SecurityInitialSetting securityInitialSetting)
        {
            if (securityInitialSetting.UseZaimuKamokuOutputSecurity
                && securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(torihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), torihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
            }
            else if (securityInitialSetting.UseZaimuKamokuOutputSecurity)
            {
                zandakaSecuritySqlStatementBuilder.AppendFormat("(z.{0}tor IS NOT NULL AND ", columnHeaderString);
                zandakaSecuritySqlStatementBuilder.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
            }
            else if (securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                zandakaSecuritySqlStatementBuilder.Append(torihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), torihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
            }
            else
            {
                zandakaSecuritySqlStatementBuilder.AppendFormat("z.{0}tor IS NOT NULL", columnHeaderString);
            }
        }

        /// <summary>
        /// 部門科目枝番残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="zandakaSecuritySqlStatementBuilder">残高セキュリティの条件式（追加前）</param>
        /// <param name="bumonSecuritySqlStatementBuilder">部門セキュリティの条件式</param>
        /// <param name="kamokuSecuritySqlStatementBuilder">科目セキュリティの条件式</param>
        /// <param name="kamokuEdabanSecuritySqlStatementBuilder">科目枝番セキュリティの条件式</param>
        /// <param name="bumonKamokuEdabanSecuritySqlStatementBuilder">部門科目枝番セキュリティの条件式</param>
        /// <param name="securityInitialSetting">セキュリティ初期設定情報</param>
        private void AppendBumonKamokuEdabanZandakaSecurityWhereStatement(SqlStatementBuilder zandakaSecuritySqlStatementBuilder, SqlStatementBuilder bumonSecuritySqlStatementBuilder, SqlStatementBuilder kamokuSecuritySqlStatementBuilder, SqlStatementBuilder kamokuEdabanSecuritySqlStatementBuilder, SqlStatementBuilder bumonKamokuEdabanSecuritySqlStatementBuilder, SecurityInitialSetting securityInitialSetting)
        {
            var isAppendBumonKamokuEdabanZandakaSecurityWhereStatement = false;

            //// 科目セキュリティ
            if (securityInitialSetting.UseZaimuKamokuOutputSecurity)
            {
                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
                isAppendBumonKamokuEdabanZandakaSecurityWhereStatement = true;
            }

            //// 枝番セキュリティ
            if (securityInitialSetting.UseZaimuKamokuEdabanOutputSecurity)
            {
                if (isAppendBumonKamokuEdabanZandakaSecurityWhereStatement)
                {
                    zandakaSecuritySqlStatementBuilder.Append(" AND ");
                }

                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(kamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), kamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
                isAppendBumonKamokuEdabanZandakaSecurityWhereStatement = true;
            }

            //// 部門セキュリティ
            if (securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                if (isAppendBumonKamokuEdabanZandakaSecurityWhereStatement)
                {
                    zandakaSecuritySqlStatementBuilder.Append(" AND ");
                }

                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuEdabanSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(bumonSecuritySqlStatementBuilder.GetSqlStatement(), bumonSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
            }
        }

        /// <summary>
        /// 部門科目取引先残高セキュリティの条件式を追加します
        /// </summary>
        /// <param name="zandakaSecuritySqlStatementBuilder">残高セキュリティの条件式（追加前）</param>
        /// <param name="bumonSecuritySqlStatementBuilder">部門セキュリティの条件式</param>
        /// <param name="kamokuSecuritySqlStatementBuilder">科目セキュリティの条件式</param>
        /// <param name="torihikisakiSecuritySqlStatementBuilder">取引先セキュリティの条件式</param>
        /// <param name="bumonKamokuTorihikisakiSecuritySqlStatementBuilder">部門科目取引先セキュリティの条件式</param>
        /// <param name="securityInitialSetting">セキュリティ初期設定情報</param>
        private void AppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement(SqlStatementBuilder zandakaSecuritySqlStatementBuilder, SqlStatementBuilder bumonSecuritySqlStatementBuilder, SqlStatementBuilder kamokuSecuritySqlStatementBuilder, SqlStatementBuilder torihikisakiSecuritySqlStatementBuilder, SqlStatementBuilder bumonKamokuTorihikisakiSecuritySqlStatementBuilder, SecurityInitialSetting securityInitialSetting)
        {
            var isAppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement = false;

            //// 科目セキュリティ
            if (securityInitialSetting.UseZaimuKamokuOutputSecurity)
            {
                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(kamokuSecuritySqlStatementBuilder.GetSqlStatement(), kamokuSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
                isAppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement = true;
            }

            //// 部門セキュリティ
            if (securityInitialSetting.UseZaimuBumonOutputSecurity)
            {
                if (isAppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement)
                {
                    zandakaSecuritySqlStatementBuilder.Append(" AND ");
                }

                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(bumonSecuritySqlStatementBuilder.GetSqlStatement(), bumonSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
                isAppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement = true;
            }

            //// 取引先セキュリティ
            if (securityInitialSetting.UseZaimuTorihikisakiOutputSecurity)
            {
                if (isAppendBumonKamokuTorihikisakiZandakaSecurityWhereStatement)
                {
                    zandakaSecuritySqlStatementBuilder.Append(" AND ");
                }

                zandakaSecuritySqlStatementBuilder.Append("(");
                zandakaSecuritySqlStatementBuilder.Append(bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), bumonKamokuTorihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(" AND ");
                zandakaSecuritySqlStatementBuilder.Append(torihikisakiSecuritySqlStatementBuilder.GetSqlStatement(), torihikisakiSecuritySqlStatementBuilder.GetSqlParameters());
                zandakaSecuritySqlStatementBuilder.Append(")");
            }
        }

        /// <summary>
        /// 科目セキュリティの条件式を追加します。
        /// </summary>
        /// <param name="sqlStatementBuilder">SQL文</param>
        /// <param name="queryOption">部署別仕訳帳表条件指定オプション</param>
        private void AppendKamokuSecurityWhereString(SqlStatementBuilder sqlStatementBuilder, SiwakeTyouhyouQueryOption queryOption)
        {
            if (queryOption.KarikataQueryOption.KamokuRangeValue.StartValue == null
                && queryOption.KarikataQueryOption.KamokuRangeValue.EndValue == null)
            {
                return;
            }

            var kamokuRangeWhereStatement = new SqlStatementBuilder();
            kamokuRangeWhereStatement.AppendLine("        SELECT ");
            kamokuRangeWhereStatement.AppendLine("          k.kicd ");
            kamokuRangeWhereStatement.AppendLine("        FROM ");
            kamokuRangeWhereStatement.AppendLine("          kname k ");
            kamokuRangeWhereStatement.AppendLine("        WHERE ");
            kamokuRangeWhereStatement.AppendLine("          k.kesn = zh.kesn ");
            kamokuRangeWhereStatement.AppendLine("          AND k.bkbn = 5 ");

            var startKamoku = queryOption.KarikataQueryOption.KamokuRangeValue.StartValue;
            var endKamoku = queryOption.KarikataQueryOption.KamokuRangeValue.EndValue;
            switch (queryOption.KaisyaSyoriKikan.Syoriki.KamokuOutputOrder)
            {
                //// 出力コード順
                case KamokuOutputOrder.ByOutputOrderCode:
                    if (!string.IsNullOrEmpty(startKamoku?.Kcod)
                        || !string.IsNullOrEmpty(endKamoku?.Kcod))
                    {
                        if (!string.IsNullOrEmpty(startKamoku?.Kcod))
                        {
                            kamokuRangeWhereStatement.AppendLine("          AND (k.kocd > :p OR (k.kocd = :p AND k.kcod >= :p)) ", startKamoku.OutputOrder, startKamoku.OutputOrder, startKamoku.Kcod);
                        }

                        if (!string.IsNullOrEmpty(endKamoku?.Kcod))
                        {
                            kamokuRangeWhereStatement.AppendLine("          AND (k.kocd < :p OR (k.kocd = :p AND k.kcod <= :p)) ", endKamoku.OutputOrder, endKamoku.OutputOrder, endKamoku.Kcod);
                        }

                        sqlStatementBuilder.AppendLine("  AND (szk.szkm IN ( ");
                        sqlStatementBuilder.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                        sqlStatementBuilder.AppendLine("      )) ");
                    }

                    break;

                //// 入力コード順
                case KamokuOutputOrder.ByInputCode:
                    if (!string.IsNullOrEmpty(startKamoku?.Kcod)
                        || !string.IsNullOrEmpty(endKamoku?.Kcod))
                    {
                        kamokuRangeWhereStatement.AppendWhereStatementByCodeRange("k.kcod", startKamoku?.Kcod, endKamoku?.Kcod, true);
                        sqlStatementBuilder.AppendLine("  AND (szk.szkm IN ( ");
                        sqlStatementBuilder.AppendLine(kamokuRangeWhereStatement.GetSqlStatement(), kamokuRangeWhereStatement.GetSqlParameters());
                        sqlStatementBuilder.AppendLine("      )) ");
                    }

                    break;

                //// 内部コード順
                case KamokuOutputOrder.ByInnerCode:
                    sqlStatementBuilder.Append("  AND (( ");
                    sqlStatementBuilder.AppendWhereStatementByCodeRange(
                        "szk.szkm",
                        startKamoku?.Kicd,
                        endKamoku?.Kicd,
                        false);
                    sqlStatementBuilder.Append(" ) OR ( ");
                    sqlStatementBuilder.AppendWhereStatementByCodeRange(
                        "szk.szkm",
                        startKamoku?.Kicd,
                        endKamoku?.Kicd,
                        false);
                    sqlStatementBuilder.AppendLine(" )) ");
                    break;
            }
        }

        #endregion

        /// <summary>
        /// ORDERBY句の式を作成します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <returns>ORDERBY句の式</returns>
        private SqlStatementBuilder CreateOrderByStatement(ISiwakeTyouhyouQueryParameter queryParameter, bool isGetDenpyou)
        {
            var orderByStatement = new SqlStatementBuilder();
            orderByStatement.AppendLine("ORDER BY ");
            this.AppendOrderItemString(orderByStatement, queryParameter, isGetDenpyou, true);
            return orderByStatement;
        }

        /// <summary>
        /// 仕訳帳票並び順の式を追加します
        /// </summary>
        /// <param name="orderByStatement">条件式（追加前）</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <param name="isOrderBy">ORDERBY句かどうか</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多い")]
        private void AppendOrderItemString(SqlStatementBuilder orderByStatement, ISiwakeTyouhyouQueryParameter queryParameter, bool isGetDenpyou, bool isOrderBy)
        {
            orderByStatement.AppendFormatAndLine("  {0}", isOrderBy ? "denpyou_dkei" : "zh.dkei");
            foreach (var orderItem in queryParameter.CreateSiwakeTyouhyouOrderItemSet(isGetDenpyou))
            {
                switch (orderItem)
                {
                    //// 伝票SEQ
                    case SiwakeTyouhyouOrderItem.Dseq:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "denpyou_dseq" : "zh.dseq");
                        break;
                    //// 伝票日付
                    case SiwakeTyouhyouOrderItem.DenpyouDate:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "denpyou_dymd" : "zh.dymd");
                        break;
                    //// 伝票番号
                    case SiwakeTyouhyouOrderItem.DenpyouNo:
                        orderByStatement.AppendFormatAndLine("  , {0} {1}", isOrderBy ? "denpyou_dcno" : "zh.dcno", this.dbReservedWords.GetNullsFirst());
                        break;
                    //// 伝票入力者
                    case SiwakeTyouhyouOrderItem.DenpyouCreateUser:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "denpyou_fusr" : "zh.fusr");
                        break;
                    //// 受付番号
                    case SiwakeTyouhyouOrderItem.UketukeNo:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "denpyou_duno" : "zh.duno");
                        break;
                    //// 仕訳SEQ
                    case SiwakeTyouhyouOrderItem.Sseq:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "siwake_sseq" : "z.sseq");
                        break;
                    //// グループ番号
                    case SiwakeTyouhyouOrderItem.GroupNo:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "siwake_grno" : "z.grno");
                        break;
                    //// 伝票頁
                    case SiwakeTyouhyouOrderItem.DenpyouPage:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "siwake_dcpg" : "z.dcpg");
                        break;
                    //// 行番号
                    case SiwakeTyouhyouOrderItem.LineNo:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "siwake_dlin" : "z.dlin");
                        break;
                    //// 貸借属性
                    case SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "siwake_dflg" : "z.dflg");
                        break;
                    //// 承認グループ
                    case SiwakeTyouhyouOrderItem.SyouninGroup:
                        orderByStatement.AppendFormatAndLine("  , {0}", isOrderBy ? "denpyou_sgno" : "zh.sgno");
                        break;
                    //// 財務→未転記
                    case SiwakeTyouhyouOrderItem.ZaimuToMitenki:
                        orderByStatement.AppendLine("  , mitenki");
                        break;
                }
            }
        }

        #endregion
    }
}
