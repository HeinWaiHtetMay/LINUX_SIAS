﻿namespace Icsp.Open21.Persistence.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Drawing;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Persistence.OptionModel;
    using Icsp.Open21.Properties;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class SiwakeTyouhyouDisplayOptionRepository : ISiwakeTyouhyouDisplayOptionRepository
    {
        [AutoInjection]
        private IOption1Dao option1Dao = null;

        [AutoInjection]
        private IScenarioRepository scenarioRepository = null;
        [AutoInjection]
        private IDenpyouInputAndSyuuseiOptionRepository denpyouInputAndSyuuseiOptionRepository = null;
        [AutoInjection]
        private IPrintPreviewOptionRepository printPreviewOptionRepository = null;
        [AutoInjection]
        private ISiwakeKazeikubunOutputOptionRepository siwakeKazeikubunOutputOptionRepository = null;
        [AutoInjection]
        private ISiwakeOutputOptionRepository siwakeOutputOptionRepository = null;

        #region public methods

        #region 取得処理

        /// <summary>
        /// 表示設定の各項目を設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouDisplayOption">仕訳帳表表示オプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目数が多いため、省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目数が多いため、省略不可")]
        public void SetDisplaySettingOption(string programId, int userCode, SiwakeTyouhyouDisplayOption siwakeTyouhyouDisplayOption)
        {
            foreach (var optionValue in this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, programId, userCode, "DISPOPT"))
            {
                SiwakeTyouhyouMasterDisplayType displayType = (SiwakeTyouhyouMasterDisplayType)optionValue.Idata;
                switch (optionValue.Keynm2)
                {
                    // 起票日
                    case "KHDATE":
                        siwakeTyouhyouDisplayOption.KihyouDateDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // 起票者
                    case "KHUSER":
                        siwakeTyouhyouDisplayOption.KihyouTantousyaDisplayTypeValue = displayType;
                        break;

                    // 起票部門
                    case "KHBMN":
                        siwakeTyouhyouDisplayOption.KihyouBumonDisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド１
                    case "HF1":
                        siwakeTyouhyouDisplayOption.HeaderField01DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド２
                    case "HF2":
                        siwakeTyouhyouDisplayOption.HeaderField02DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド３
                    case "HF3":
                        siwakeTyouhyouDisplayOption.HeaderField03DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド４
                    case "HF4":
                        siwakeTyouhyouDisplayOption.HeaderField04DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド５
                    case "HF5":
                        siwakeTyouhyouDisplayOption.HeaderField05DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド６
                    case "HF6":
                        siwakeTyouhyouDisplayOption.HeaderField06DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド７
                    case "HF7":
                        siwakeTyouhyouDisplayOption.HeaderField07DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド８
                    case "HF8":
                        siwakeTyouhyouDisplayOption.HeaderField08DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド９
                    case "HF9":
                        siwakeTyouhyouDisplayOption.HeaderField09DisplayTypeValue = displayType;
                        break;

                    // ヘッダーフィールド１０
                    case "HF10":
                        siwakeTyouhyouDisplayOption.HeaderField10DisplayTypeValue = displayType;
                        break;

                    // 科目
                    case "KMK":
                        siwakeTyouhyouDisplayOption.KamokuDisplayTypeValue = displayType;
                        break;

                    // 部門
                    case "BMN":
                        siwakeTyouhyouDisplayOption.BumonDisplayTypeValue = displayType;
                        break;

                    // 枝番
                    case "EDA":
                        siwakeTyouhyouDisplayOption.EdabanDisplayTypeValue = displayType;
                        break;

                    // 取引先
                    case "TORI":
                        siwakeTyouhyouDisplayOption.TorihikisakiDisplayTypeValue = displayType;
                        break;

                    // セグメント
                    case "SEG":
                        siwakeTyouhyouDisplayOption.SegmentDisplayTypeValue = displayType;
                        break;

                    // プロジェクト
                    case "PRJ":
                        siwakeTyouhyouDisplayOption.ProjectDisplayTypeValue = displayType;
                        break;

                    // 工事
                    case "KOJI":
                        siwakeTyouhyouDisplayOption.KouziDisplayTypeValue = displayType;
                        break;

                    // 工種
                    case "KOSYU":
                        siwakeTyouhyouDisplayOption.KousyuDisplayTypeValue = displayType;
                        break;

                    // ユーザー
                    case "USER":
                        siwakeTyouhyouDisplayOption.UserDisplayTypeValue = displayType;
                        break;

                    // 消費税対象科目
                    case "ZKMK":
                        siwakeTyouhyouDisplayOption.SyouhizeiTaisyouKamokuDisplayTypeValue = displayType;
                        break;

                    // 支払日
                    case "SYMD":
                        siwakeTyouhyouDisplayOption.SiharaiDateDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // 消込
                    case "DKEC":
                        siwakeTyouhyouDisplayOption.KesikomiDisplayTypeValue = optionValue.Idata == 1;
                        break;

                    // ユニバーサルフィールド１
                    case "UF1":
                        siwakeTyouhyouDisplayOption.UniversalField01DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド２
                    case "UF2":
                        siwakeTyouhyouDisplayOption.UniversalField02DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド３
                    case "UF3":
                        siwakeTyouhyouDisplayOption.UniversalField03DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド４
                    case "UF4":
                        siwakeTyouhyouDisplayOption.UniversalField04DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド５
                    case "UF5":
                        siwakeTyouhyouDisplayOption.UniversalField05DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド６
                    case "UF6":
                        siwakeTyouhyouDisplayOption.UniversalField06DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド７
                    case "UF7":
                        siwakeTyouhyouDisplayOption.UniversalField07DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド８
                    case "UF8":
                        siwakeTyouhyouDisplayOption.UniversalField08DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド９
                    case "UF9":
                        siwakeTyouhyouDisplayOption.UniversalField09DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１０
                    case "UF10":
                        siwakeTyouhyouDisplayOption.UniversalField10DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１１
                    case "UF11":
                        siwakeTyouhyouDisplayOption.UniversalField11DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１２
                    case "UF12":
                        siwakeTyouhyouDisplayOption.UniversalField12DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１３
                    case "UF13":
                        siwakeTyouhyouDisplayOption.UniversalField13DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１４
                    case "UF14":
                        siwakeTyouhyouDisplayOption.UniversalField14DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１５
                    case "UF15":
                        siwakeTyouhyouDisplayOption.UniversalField15DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１６
                    case "UF16":
                        siwakeTyouhyouDisplayOption.UniversalField16DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１７
                    case "UF17":
                        siwakeTyouhyouDisplayOption.UniversalField17DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１８
                    case "UF18":
                        siwakeTyouhyouDisplayOption.UniversalField18DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド１９
                    case "UF19":
                        siwakeTyouhyouDisplayOption.UniversalField19DisplayTypeValue = displayType;
                        break;

                    // ユニバーサルフィールド２０
                    case "UF20":
                        siwakeTyouhyouDisplayOption.UniversalField20DisplayTypeValue = displayType;
                        break;
                }
            }
        }

        #endregion

        #region 保存処理

        /// <summary>
        /// 表示設定の各項目の設定値を保存します。
        /// </summary>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouDisplayOption">仕訳帳表表示オプション</param>
        public void StoreDisplaySettingOption(string programIdForOption, int userCode, SiwakeTyouhyouDisplayOption siwakeTyouhyouDisplayOption)
        {
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHDATE", 0, siwakeTyouhyouDisplayOption.KihyouDateDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHUSER", 0, (int)siwakeTyouhyouDisplayOption.KihyouTantousyaDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KHBMN", 0, (int)siwakeTyouhyouDisplayOption.KihyouBumonDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF1", 0, (int)siwakeTyouhyouDisplayOption.HeaderField01DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF2", 0, (int)siwakeTyouhyouDisplayOption.HeaderField02DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF3", 0, (int)siwakeTyouhyouDisplayOption.HeaderField03DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF4", 0, (int)siwakeTyouhyouDisplayOption.HeaderField04DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF5", 0, (int)siwakeTyouhyouDisplayOption.HeaderField05DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF6", 0, (int)siwakeTyouhyouDisplayOption.HeaderField06DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF7", 0, (int)siwakeTyouhyouDisplayOption.HeaderField07DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF8", 0, (int)siwakeTyouhyouDisplayOption.HeaderField08DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF9", 0, (int)siwakeTyouhyouDisplayOption.HeaderField09DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "HF10", 0, (int)siwakeTyouhyouDisplayOption.HeaderField10DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KMK", 0, (int)siwakeTyouhyouDisplayOption.KamokuDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "BMN", 0, (int)siwakeTyouhyouDisplayOption.BumonDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "TORI", 0, (int)siwakeTyouhyouDisplayOption.TorihikisakiDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "SEG", 0, (int)siwakeTyouhyouDisplayOption.SegmentDisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF1", 0, (int)siwakeTyouhyouDisplayOption.UniversalField01DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF2", 0, (int)siwakeTyouhyouDisplayOption.UniversalField02DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF3", 0, (int)siwakeTyouhyouDisplayOption.UniversalField03DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF4", 0, (int)siwakeTyouhyouDisplayOption.UniversalField04DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF5", 0, (int)siwakeTyouhyouDisplayOption.UniversalField05DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF6", 0, (int)siwakeTyouhyouDisplayOption.UniversalField06DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF7", 0, (int)siwakeTyouhyouDisplayOption.UniversalField07DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF8", 0, (int)siwakeTyouhyouDisplayOption.UniversalField08DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF9", 0, (int)siwakeTyouhyouDisplayOption.UniversalField09DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF10", 0, (int)siwakeTyouhyouDisplayOption.UniversalField10DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF11", 0, (int)siwakeTyouhyouDisplayOption.UniversalField11DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF12", 0, (int)siwakeTyouhyouDisplayOption.UniversalField12DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF13", 0, (int)siwakeTyouhyouDisplayOption.UniversalField13DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF14", 0, (int)siwakeTyouhyouDisplayOption.UniversalField14DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF15", 0, (int)siwakeTyouhyouDisplayOption.UniversalField15DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF16", 0, (int)siwakeTyouhyouDisplayOption.UniversalField16DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF17", 0, (int)siwakeTyouhyouDisplayOption.UniversalField17DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF18", 0, (int)siwakeTyouhyouDisplayOption.UniversalField18DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF19", 0, (int)siwakeTyouhyouDisplayOption.UniversalField19DisplayTypeValue),
                new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "UF20", 0, (int)siwakeTyouhyouDisplayOption.UniversalField20DisplayTypeValue)
            }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));

            //// 以下の項目は、一部の業務のみ保存

            if (programIdForOption == "DSCAN" || programIdForOption == "CHKMAIN" || programIdForOption == "NIKKMAIN" || programIdForOption == "SKCHLSTB")
            {
                //// ユーザーは、データスキャン、チェックリスト、仕訳日記帳でのみ保存
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "USER", 0, (int)siwakeTyouhyouDisplayOption.UserDisplayTypeValue));
            }
            else if (programIdForOption == "SFCHKMAIN" || programIdForOption == "SFSYONIN")
            {
                //// 消費税対象科目は、入力確定・チェックリスト、承認処理でのみ保存（遡及は除く）
                this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "ZKMK", 0, (int)siwakeTyouhyouDisplayOption.SyouhizeiTaisyouKamokuDisplayTypeValue));
                if (programIdForOption == "SFSYONIN")
                {
                    //// 支払日及び消込は、承認処理でのみ保存（遡及は除く）
                    new List<Option1Dto>()
                    {
                        new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "SYMD", 0, siwakeTyouhyouDisplayOption.SiharaiDateDisplayTypeValue),
                        new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "DKEC", 0, siwakeTyouhyouDisplayOption.KesikomiDisplayTypeValue)
                    }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
                }
            }

            if (programIdForOption != "SKCHLSTA" && programIdForOption != "SKSYONIN")
            {
                //// 以下の項目は、入力確定・チェックリスト（遡及）、承認処理（遡及）では保存しない
                new List<Option1Dto>()
                {
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "EDA", 0, (int)siwakeTyouhyouDisplayOption.EdabanDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "PRJ", 0, (int)siwakeTyouhyouDisplayOption.ProjectDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KOJI", 0, (int)siwakeTyouhyouDisplayOption.KouziDisplayTypeValue),
                    new Option1Dto().SetValues(programIdForOption, userCode, "DISPOPT", "KOSYU", 0, (int)siwakeTyouhyouDisplayOption.KousyuDisplayTypeValue),
                }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
            }
        }
        #endregion

        #endregion
    }
}
