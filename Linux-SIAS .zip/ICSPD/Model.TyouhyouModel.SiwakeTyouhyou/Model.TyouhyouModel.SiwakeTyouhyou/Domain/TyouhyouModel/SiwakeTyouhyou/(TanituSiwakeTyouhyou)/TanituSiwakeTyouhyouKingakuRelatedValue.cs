﻿using System;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 単一仕訳帳票の金額関係の値（仕訳サマリー）
    /// </summary>
    public class TanituSiwakeTyouhyouKingakuRelatedValue
    {
        /// <summary>
        /// 仕訳合計
        /// </summary>
        public decimal SiwakeTotalKingaku { get; set; }

        /// <summary>
        /// 借方諸口合計
        /// </summary>
        public decimal SiwakeKarikataSyokutiTotalKingaku { get; set; }

        /// <summary>
        /// 貸方諸口合計
        /// </summary>
        public decimal SiwakeKasikataSyokutiTotalKingaku { get; set; }

        /// <summary>
        /// 貸借合計
        /// </summary>
        public decimal SiwakeTaisyakuTotalKingaku
        {
            get
            {
                return this.SiwakeKarikataSyokutiTotalKingaku == this.SiwakeKasikataSyokutiTotalKingaku
                    ? this.SiwakeTotalKingaku + this.SiwakeKarikataSyokutiTotalKingaku
                    : Math.Abs(this.SiwakeKarikataSyokutiTotalKingaku - this.SiwakeKasikataSyokutiTotalKingaku);
            }
        }

        /// <summary>
        /// 仕訳件数
        /// </summary>
        public int SiwakeCount { get; set; }

        /// <summary>
        /// 伝票件数
        /// </summary>
        public int DenpyouCount { get; set; }
    }
}
