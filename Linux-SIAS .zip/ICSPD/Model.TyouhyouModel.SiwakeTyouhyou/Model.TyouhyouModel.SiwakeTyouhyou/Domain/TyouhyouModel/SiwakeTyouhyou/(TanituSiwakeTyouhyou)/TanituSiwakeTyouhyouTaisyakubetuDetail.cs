﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 単一仕訳帳票の貸借別データ
    /// </summary>
    public class TanituSiwakeTyouhyouTaisyakubetuDetail
    {
        #region プロパティ

        #region 仕訳項目

        /// <summary>
        /// 部門コード（カラム名：rbmn, sbmn）
        /// </summary>
        public string Bcod { get; set; }

        /// <summary>
        /// 取引先コード（カラム名：rtor, stor）
        /// </summary>
        public string Trcd { get; set; }

        /// <summary>
        /// 科目内部コード（カラム名：rkmk, skmk）
        /// </summary>
        public string Kicd { get; set; }

        /// <summary>
        /// 枝番コード（カラム名：reda, seda）
        /// </summary>
        public string Ecod { get; set; }

        /// <summary>
        /// 工事コード（カラム名：rkoj, skoj）
        /// </summary>
        public string Kzcd { get; set; }

        /// <summary>
        /// 工種コード（カラム名：rkos, skos）
        /// </summary>
        public string Kscd { get; set; }

        /// <summary>
        /// プロジェクトコード（カラム名：rprj, sprj）
        /// </summary>
        public string Pjcd { get; set; }

        /// <summary>
        /// セグメントコード（カラム名：rseg, sseg）
        /// </summary>
        public string Sgcd { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1コード（カラム名：rdm1, sdm1）
        /// </summary>
        public string Ufcd01 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2コード（カラム名：rdm2, sdm2）
        /// </summary>
        public string Ufcd02 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3コード（カラム名：rdm3, sdm3）
        /// </summary>
        public string Ufcd03 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4コード（カラム名：rdm4, sdm4）
        /// </summary>
        public string Ufcd04 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5コード（カラム名：rdm5, sdm5）
        /// </summary>
        public string Ufcd05 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6コード（カラム名：rdm6, sdm6）
        /// </summary>
        public string Ufcd06 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7コード（カラム名：rdm7, sdm7）
        /// </summary>
        public string Ufcd07 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8コード（カラム名：rdm8, sdm8）
        /// </summary>
        public string Ufcd08 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9コード（カラム名：rdm9, sdm9）
        /// </summary>
        public string Ufcd09 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10コード（カラム名：rdm10, sdm10）
        /// </summary>
        public string Ufcd10 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11コード（カラム名：rdm11, sdm11）
        /// </summary>
        public string Ufcd11 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12コード（カラム名：rdm12, sdm12）
        /// </summary>
        public string Ufcd12 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13コード（カラム名：rdm13, sdm13）
        /// </summary>
        public string Ufcd13 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14コード（カラム名：rdm14, sdm14）
        /// </summary>
        public string Ufcd14 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15コード（カラム名：rdm15, sdm15）
        /// </summary>
        public string Ufcd15 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16コード（カラム名：rdm16, sdm16）
        /// </summary>
        public string Ufcd16 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17コード（カラム名：rdm17, sdm17）
        /// </summary>
        public string Ufcd17 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18コード（カラム名：rdm18, sdm18）
        /// </summary>
        public string Ufcd18 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19コード（カラム名：rdm19, sdm19）
        /// </summary>
        public string Ufcd19 { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20コード（カラム名：rdm20, sdm20）
        /// </summary>
        public string Ufcd20 { get; set; }

        /// <summary>
        /// 摘要（カラム名：rtky, stky）
        /// </summary>
        public string Tekiyou { get; set; }

        /// <summary>
        /// 摘要コード（カラム名：rtno, stno）
        /// </summary>
        public int? TekiyouCode { get; set; }

        /// <summary>
        /// 税率（カラム名：rrit, rkeigen, srit, skeigen）（未設定の場合はnull）
        /// </summary>
        public Syouhizeiritu Syouhizeiritu { get; set; }

        /// <summary>
        /// 課税区分（カラム名：rzkb, szkb）
        /// </summary>
        public KazeiKubun? KazeiKubun { get; set; }

        /// <summary>
        /// 業種区分（カラム名：rgyo, sgyo）
        /// </summary>
        public GyousyuKubun? GyousyuKubun { get; set; }

        /// <summary>
        /// 仕入区分（カラム名：rsre, ssre）
        /// </summary>
        public SiwakeSiireKubun? SiwakeSiireKubun { get; set; }

        /// <summary>
        /// 通貨コード（カラム名：rhei_cd, shei_cd）
        /// </summary>
        public string HeisyuCode { get; set; }

        #endregion

        #region 本支店項目

        /// <summary>
        /// 本支店勘定設定フラグ（カラム名：rsflg, ssflg）
        /// </summary>
        public HonsitenKanzyouSetFlag HonsitenKanzyouSetFlag { get; set; }

        /// <summary>
        /// 部門が入力されているかどうか（カラム名：rbreg, sbreg）
        /// </summary>
        public bool IsInputedBumon { get; set; }

        /// <summary>
        /// 本支店展開明細テーブル（hstbl_m）に、部門が登録されているかどうか（カラム名：rbinp, sbinp）
        /// </summary>
        public bool IsRegisteredBumonToHonsitenTenkaiMeisaiTable { get; set; }

        /// <summary>
        /// 部門科目残高テーブル（bkzan）に、部門科目が登録されているかどうか（カラム名：rbkinp, sbkinp）
        /// </summary>
        public bool IsRegisteredBumonKamokuToBumonKamokuZandakaTable { get; set; }

        #endregion

        #region その他項目

        /// <summary>
        /// 部門名称
        /// </summary>
        public string BumonName { get; set; }

        /// <summary>
        /// 取引先名称
        /// </summary>
        public string TorihikisakiName { get; set; }

        /// <summary>
        /// 取引先正式名称
        /// </summary>
        public string TorihikisakiLongName { get; set; }

        /// <summary>
        /// 科目入力コード
        /// </summary>
        public string Kcod { get; set; }

        /// <summary>
        /// 処理グループ
        /// </summary>
        public KamokuSyoriGroup KamokuSyoriGroup { get; set; }

        /// <summary>
        /// 科目が対価金額入力可能であるかどうか
        /// </summary>
        public bool IsInputTaikaKingakuKamoku { get; set; }

        /// <summary>
        /// 科目が消込対象であるかどうか
        /// </summary>
        public bool IsKesikomiTaisyouKamoku { get; set; }

        /// <summary>
        /// 科目名称
        /// </summary>
        public string KamokuName { get; set; }

        /// <summary>
        /// 科目正式名称
        /// </summary>
        public string KamokuLongName { get; set; }

        /// <summary>
        /// 枝番名称
        /// </summary>
        public string EdabanName { get; set; }

        /// <summary>
        /// 工事名称
        /// </summary>
        public string KouziName { get; set; }

        /// <summary>
        /// 工事正式名称
        /// </summary>
        public string KouziLongName { get; set; }

        /// <summary>
        /// 工種名称
        /// </summary>
        public string KousyuName { get; set; }

        /// <summary>
        /// プロジェクト名称
        /// </summary>
        public string ProjectName { get; set; }

        /// <summary>
        /// プロジェクト正式名称
        /// </summary>
        public string ProjectLongName { get; set; }

        /// <summary>
        /// セグメント名称
        /// </summary>
        public string SegmentName { get; set; }

        /// <summary>
        /// セグメント正式名称
        /// </summary>
        public string SegmentLongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1名称
        /// </summary>
        public string UniversalField01Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2名称
        /// </summary>
        public string UniversalField02Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3名称
        /// </summary>
        public string UniversalField03Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4名称
        /// </summary>
        public string UniversalField04Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5名称
        /// </summary>
        public string UniversalField05Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6名称
        /// </summary>
        public string UniversalField06Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7名称
        /// </summary>
        public string UniversalField07Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8名称
        /// </summary>
        public string UniversalField08Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9名称
        /// </summary>
        public string UniversalField09Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10名称
        /// </summary>
        public string UniversalField10Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11名称
        /// </summary>
        public string UniversalField11Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12名称
        /// </summary>
        public string UniversalField12Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13名称
        /// </summary>
        public string UniversalField13Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14名称
        /// </summary>
        public string UniversalField14Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15名称
        /// </summary>
        public string UniversalField15Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16名称
        /// </summary>
        public string UniversalField16Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17名称
        /// </summary>
        public string UniversalField17Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18名称
        /// </summary>
        public string UniversalField18Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19名称
        /// </summary>
        public string UniversalField19Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20名称
        /// </summary>
        public string UniversalField20Name { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1正式名称
        /// </summary>
        public string UniversalField01LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2正式名称
        /// </summary>
        public string UniversalField02LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3正式名称
        /// </summary>
        public string UniversalField03LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4正式名称
        /// </summary>
        public string UniversalField04LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5正式名称
        /// </summary>
        public string UniversalField05LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6正式名称
        /// </summary>
        public string UniversalField06LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7正式名称
        /// </summary>
        public string UniversalField07LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8正式名称
        /// </summary>
        public string UniversalField08LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9正式名称
        /// </summary>
        public string UniversalField09LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10正式名称
        /// </summary>
        public string UniversalField10LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11正式名称
        /// </summary>
        public string UniversalField11LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12正式名称
        /// </summary>
        public string UniversalField12LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13正式名称
        /// </summary>
        public string UniversalField13LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14正式名称
        /// </summary>
        public string UniversalField14LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15正式名称
        /// </summary>
        public string UniversalField15LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16正式名称
        /// </summary>
        public string UniversalField16LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17正式名称
        /// </summary>
        public string UniversalField17LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18正式名称
        /// </summary>
        public string UniversalField18LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19正式名称
        /// </summary>
        public string UniversalField19LongName { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20正式名称
        /// </summary>
        public string UniversalField20LongName { get; set; }

        /// <summary>
        /// 摘要名称
        /// </summary>
        public string TekiyouName { get; set; }

        /// <summary>
        /// 単位名称
        /// </summary>
        public string HeisyuName { get; set; }

        /// <summary>
        /// 幣種使用国名
        /// </summary>
        public string HeisyuUsingCountryName { get; set; }

        /// <summary>
        /// 幣種小数部桁数
        /// </summary>
        public int? HeisyuDecimalPartKetaCount { get; set; }

        /// <summary>
        /// 集計部門コード
        /// </summary>
        public string Sbcd { get; set; }

        /// <summary>
        /// 集計部門名称
        /// </summary>
        public string SyuukeiBumonName { get; set; }

        /// <summary>
        /// 仕訳項目未入力チェック結果
        /// </summary>
        public SiwakeItemNotInputCheckResult SiwakeItemNotInputCheckResult { get; set; } = new SiwakeItemNotInputCheckResult();

        /// <summary>
        /// 諸口科目かどうか
        /// </summary>
        public bool IsSyokutiKamoku { get; set; }

        /// <summary>
        /// セキュリティ不許可のコードが存在するかどうか
        /// </summary>
        public bool HasSecurityNotPermittedCode { get; set; }

        /// <summary>
        /// 伝票日付以前の最新税率かどうか
        /// </summary>
        public bool IsLatestSyouhizeirituBeforeDenpyouDate { get; set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// ユニバーサルフィールドコードを取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールドコード</returns>
        public string GetUniversalFieldCode(int no)
        {
            switch (no)
            {
                case 1:
                    return this.Ufcd01;
                case 2:
                    return this.Ufcd02;
                case 3:
                    return this.Ufcd03;
                case 4:
                    return this.Ufcd04;
                case 5:
                    return this.Ufcd05;
                case 6:
                    return this.Ufcd06;
                case 7:
                    return this.Ufcd07;
                case 8:
                    return this.Ufcd08;
                case 9:
                    return this.Ufcd09;
                case 10:
                    return this.Ufcd10;
                case 11:
                    return this.Ufcd11;
                case 12:
                    return this.Ufcd12;
                case 13:
                    return this.Ufcd13;
                case 14:
                    return this.Ufcd14;
                case 15:
                    return this.Ufcd15;
                case 16:
                    return this.Ufcd16;
                case 17:
                    return this.Ufcd17;
                case 18:
                    return this.Ufcd18;
                case 19:
                    return this.Ufcd19;
                case 20:
                    return this.Ufcd20;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド名称を取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド名称</returns>
        public string GetUniversalFieldName(int no)
        {
            switch (no)
            {
                case 1:
                    return this.UniversalField01Name;
                case 2:
                    return this.UniversalField02Name;
                case 3:
                    return this.UniversalField03Name;
                case 4:
                    return this.UniversalField04Name;
                case 5:
                    return this.UniversalField05Name;
                case 6:
                    return this.UniversalField06Name;
                case 7:
                    return this.UniversalField07Name;
                case 8:
                    return this.UniversalField08Name;
                case 9:
                    return this.UniversalField09Name;
                case 10:
                    return this.UniversalField10Name;
                case 11:
                    return this.UniversalField11Name;
                case 12:
                    return this.UniversalField12Name;
                case 13:
                    return this.UniversalField13Name;
                case 14:
                    return this.UniversalField14Name;
                case 15:
                    return this.UniversalField15Name;
                case 16:
                    return this.UniversalField16Name;
                case 17:
                    return this.UniversalField17Name;
                case 18:
                    return this.UniversalField18Name;
                case 19:
                    return this.UniversalField19Name;
                case 20:
                    return this.UniversalField20Name;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド正式名称を取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド正式名称</returns>
        public string GetUniversalFieldLongName(int no)
        {
            switch (no)
            {
                case 1:
                    return this.UniversalField01LongName;
                case 2:
                    return this.UniversalField02LongName;
                case 3:
                    return this.UniversalField03LongName;
                case 4:
                    return this.UniversalField04LongName;
                case 5:
                    return this.UniversalField05LongName;
                case 6:
                    return this.UniversalField06LongName;
                case 7:
                    return this.UniversalField07LongName;
                case 8:
                    return this.UniversalField08LongName;
                case 9:
                    return this.UniversalField09LongName;
                case 10:
                    return this.UniversalField10LongName;
                case 11:
                    return this.UniversalField11LongName;
                case 12:
                    return this.UniversalField12LongName;
                case 13:
                    return this.UniversalField13LongName;
                case 14:
                    return this.UniversalField14LongName;
                case 15:
                    return this.UniversalField15LongName;
                case 16:
                    return this.UniversalField16LongName;
                case 17:
                    return this.UniversalField17LongName;
                case 18:
                    return this.UniversalField18LongName;
                case 19:
                    return this.UniversalField19LongName;
                case 20:
                    return this.UniversalField20LongName;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドコードを設定します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="code">設定するユニバーサルフィールドコード</param>
        public void SetUniversalFieldCode(int no, string code)
        {
            switch (no)
            {
                case 1:
                    this.Ufcd01 = code;
                    break;
                case 2:
                    this.Ufcd02 = code;
                    break;
                case 3:
                    this.Ufcd03 = code;
                    break;
                case 4:
                    this.Ufcd04 = code;
                    break;
                case 5:
                    this.Ufcd05 = code;
                    break;
                case 6:
                    this.Ufcd06 = code;
                    break;
                case 7:
                    this.Ufcd07 = code;
                    break;
                case 8:
                    this.Ufcd08 = code;
                    break;
                case 9:
                    this.Ufcd09 = code;
                    break;
                case 10:
                    this.Ufcd10 = code;
                    break;
                case 11:
                    this.Ufcd11 = code;
                    break;
                case 12:
                    this.Ufcd12 = code;
                    break;
                case 13:
                    this.Ufcd13 = code;
                    break;
                case 14:
                    this.Ufcd14 = code;
                    break;
                case 15:
                    this.Ufcd15 = code;
                    break;
                case 16:
                    this.Ufcd16 = code;
                    break;
                case 17:
                    this.Ufcd17 = code;
                    break;
                case 18:
                    this.Ufcd18 = code;
                    break;
                case 19:
                    this.Ufcd19 = code;
                    break;
                case 20:
                    this.Ufcd20 = code;
                    break;
            }
        }

        #endregion
    }
}
