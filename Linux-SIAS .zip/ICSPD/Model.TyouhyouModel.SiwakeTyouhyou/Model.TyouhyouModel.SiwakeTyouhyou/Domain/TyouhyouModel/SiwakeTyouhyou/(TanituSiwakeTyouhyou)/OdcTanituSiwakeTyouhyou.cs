﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// ODC単一仕訳帳票
    /// </summary>
    public class OdcTanituSiwakeTyouhyou
    {
        /// <summary>
        /// ODC単一仕訳帳票行リスト
        /// </summary>
        public IList<IOdcTanituSiwakeTyouhyouRow> TanituSiwakeTyouhyouRows { get; set; } = new List<IOdcTanituSiwakeTyouhyouRow>();
    }
}
