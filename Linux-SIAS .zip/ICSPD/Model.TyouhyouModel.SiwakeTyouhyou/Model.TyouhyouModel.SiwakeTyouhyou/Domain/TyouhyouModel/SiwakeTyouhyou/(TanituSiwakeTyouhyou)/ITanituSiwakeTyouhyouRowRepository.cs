﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ITanituSiwakeTyouhyouRowRepository
    {
        /// <summary>
        /// 指定条件の単一仕訳帳票の行データリストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得した単一仕訳帳票の行データリスト</returns>
        IList<ITanituSiwakeTyouhyouRow> FindSiwakeTyouhyouRowsByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 指定条件のODC用単一仕訳帳票の行データリストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得したODC用単一仕訳帳票の行データリスト</returns>
        IList<IOdcTanituSiwakeTyouhyouRow> FindOdcSiwakeTyouhyouRowsByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 指定条件の伝票リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>取得した伝票リスト</returns>
        IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 指定条件の金額関連の値を取得します
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        TanituSiwakeTyouhyouKingakuRelatedValue GetKingakuRelatedValueByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 指定条件の仕訳が存在するかどうかを取得します
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>指定条件の仕訳が存在するかどうか</returns>
        bool GetExistsByQuertyParameter(ISiwakeTyouhyouQueryParameter queryParameter);
    }
}