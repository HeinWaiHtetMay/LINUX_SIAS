﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;

    /// <summary>
    /// データスキャン単一仕訳帳票
    /// </summary>
    public class DataScanTanituSiwakeTyouhyou
    {
        /// <summary>
        /// 仕訳の最大表示可能件数
        /// </summary>
        public static readonly int SiwakeMaxDisplayableCount = 100000;

        public DataScanTanituSiwakeTyouhyou(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            this.QueryParameter = queryParameter;
        }

        /// <summary>
        /// 仕訳帳票の金額関係の値
        /// </summary>
        public TanituSiwakeTyouhyouKingakuRelatedValue KingakuRelatedValue { get; set; } = new TanituSiwakeTyouhyouKingakuRelatedValue();

        /// <summary>
        /// 未転記仕訳帳票の金額関係の値
        /// </summary>
        public TanituSiwakeTyouhyouKingakuRelatedValue MitenkiSiwakeKingakuRelatedValue { get; set; } = new TanituSiwakeTyouhyouKingakuRelatedValue();

        /// <summary>
        /// 単一仕訳帳票行リスト
        /// </summary>
        public IList<ITanituSiwakeTyouhyouRow> SiwakeTyouhyouRows { get; set; } = new List<ITanituSiwakeTyouhyouRow>();

        /// <summary>
        /// 仕訳帳票問合せパラメータ
        /// </summary>
        public ISiwakeTyouhyouQueryParameter QueryParameter { get; set; }
    }
}
