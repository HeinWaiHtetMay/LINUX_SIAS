﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 単一仕訳帳票の行データ
    /// </summary>
    public class TanituSiwakeTyouhyouRow : IOdcTanituSiwakeTyouhyouRow, ITanituSiwakeTyouhyouRow, ISiwakeTyouhyouDenpyouRow
    {
        public TanituSiwakeTyouhyouRow(int kesn, int dkei, int dseq, int sseq)
        {
            this.Kesn = kesn;
            this.Dkei = dkei;
            this.Dseq = dseq;
            this.Sseq = sseq;
        }

        #region プロパティ

        #region 伝票項目

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei { get; private set; }

        /// <summary>
        /// 伝票SEQNo.（カラム名：dseq）
        /// </summary>
        public int Dseq { get; private set; }

        public int DenpyouSequenceNumber => this.Dseq;

        /// <summary>
        /// 伝票日付（カラム名：dymd）
        /// </summary>
        public IcspDateTime DenpyouDate { get; set; }

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        public int? DenpyouNo { get; set; }

        /// <summary>
        /// 起票日（カラム名：kymd）
        /// </summary>
        public IcspDateTime KihyouDate { get; set; }

        /// <summary>
        /// 起票部門コード（カラム名：kbmn）
        /// </summary>
        public string KihyouBumonCode { get; set; }

        /// <summary>
        /// 起票者コード（カラム名：kusr）
        /// </summary>
        public string KihyouTantousyaCode { get; set; }

        /// <summary>
        /// 伝票作成日（カラム名：fmod）
        /// </summary>
        public IcspDateTime DenpyouCreateDate { get; set; }

        /// <summary>
        /// 伝票作成者コード（カラム名：fusr）
        /// </summary>
        public int DenpyouCreateUserCode { get; set; }

        /// <summary>
        /// 伝票更新日（カラム名：lmod）
        /// </summary>
        public IcspDateTime DenpyouUpdateDate { get; set; }

        /// <summary>
        /// 伝票更新者コード（カラム名：lusr）
        /// </summary>
        public int DenpyouUpdateUserCode { get; set; }

        /// <summary>
        /// 受付番号（カラム名：duno）
        /// </summary>
        public int UketukeNo { get; set; }

        /// <summary>
        /// 入力確定日（カラム名：kday）
        /// </summary>
        public IcspDateTime InputKakuteiDate { get; set; }

        /// <summary>
        /// 承認グループNo（カラム名：sgno）
        /// </summary>
        public int SyouninGroupNo { get; set; }

        /// <summary>
        /// 判定済最上位承認者順序（カラム名：hjno）
        /// </summary>
        public int HanteizumiTopSyouninUserOrder { get; set; }

        /// <summary>
        /// 承認状況（カラム名：sflg）
        /// </summary>
        public SyouninStatus SyouninStatus { get; set; }

        /// <summary>
        /// 第一承認者（カラム名：sn01）
        /// </summary>
        public int Dai1SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第一承認判定（カラム名：sf01）
        /// </summary>
        public SyouninStatus Dai1SyouninStatus { get; set; }

        /// <summary>
        /// 第二承認者（カラム名：sn02）
        /// </summary>
        public int Dai2SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第二承認判定（カラム名：sf02）
        /// </summary>
        public SyouninStatus Dai2SyouninStatus { get; set; }

        /// <summary>
        /// 第三承認者（カラム名：sn03）
        /// </summary>
        public int Dai3SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第三承認判定（カラム名：sf03）
        /// </summary>
        public SyouninStatus Dai3SyouninStatus { get; set; }

        /// <summary>
        /// 第四承認者（カラム名：sn04）
        /// </summary>
        public int Dai4SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第四承認判定（カラム名：sf04）
        /// </summary>
        public SyouninStatus Dai4SyouninStatus { get; set; }

        /// <summary>
        /// 第五承認者（カラム名：sn05）
        /// </summary>
        public int Dai5SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第五承認判定（カラム名：sf05）
        /// </summary>
        public SyouninStatus Dai5SyouninStatus { get; set; }

        /// <summary>
        /// 第六承認者（カラム名：sn06）
        /// </summary>
        public int Dai6SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第六承認判定（カラム名：sf06）
        /// </summary>
        public SyouninStatus Dai6SyouninStatus { get; set; }

        /// <summary>
        /// 第七承認者（カラム名：sn07）
        /// </summary>
        public int Dai7SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第七承認判定（カラム名：sf07）
        /// </summary>
        public SyouninStatus Dai7SyouninStatus { get; set; }

        /// <summary>
        /// 第八承認者（カラム名：sn08）
        /// </summary>
        public int Dai8SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第八承認判定（カラム名：sf08）
        /// </summary>
        public SyouninStatus Dai8SyouninStatus { get; set; }

        /// <summary>
        /// 第九承認者（カラム名：sn09）
        /// </summary>
        public int Dai9SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第九承認判定（カラム名：sf09）
        /// </summary>
        public SyouninStatus Dai9SyouninStatus { get; set; }

        /// <summary>
        /// 第十承認者（カラム名：sn10）
        /// </summary>
        public int Dai10SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第十承認判定（カラム名：sf10）
        /// </summary>
        public SyouninStatus Dai10SyouninStatus { get; set; }

        /// <summary>
        /// ヘッダーフィールド1コード（カラム名：duf1）
        /// </summary>
        public string Hfcd01 { get; set; }

        /// <summary>
        /// ヘッダーフィールド2コード（カラム名：duf2）
        /// </summary>
        public string Hfcd02 { get; set; }

        /// <summary>
        /// ヘッダーフィールド3コード（カラム名：duf3）
        /// </summary>
        public string Hfcd03 { get; set; }

        /// <summary>
        /// ヘッダーフィールド4コード（カラム名：duf4）
        /// </summary>
        public string Hfcd04 { get; set; }

        /// <summary>
        /// ヘッダーフィールド5コード（カラム名：duf5）
        /// </summary>
        public string Hfcd05 { get; set; }

        /// <summary>
        /// ヘッダーフィールド6コード（カラム名：duf6）
        /// </summary>
        public string Hfcd06 { get; set; }

        /// <summary>
        /// ヘッダーフィールド7コード（カラム名：duf7）
        /// </summary>
        public string Hfcd07 { get; set; }

        /// <summary>
        /// ヘッダーフィールド8コード（カラム名：duf8）
        /// </summary>
        public string Hfcd08 { get; set; }

        /// <summary>
        /// ヘッダーフィールド9コード（カラム名：duf9）
        /// </summary>
        public string Hfcd09 { get; set; }

        /// <summary>
        /// ヘッダーフィールド10コード（カラム名：duf10）
        /// </summary>
        public string Hfcd10 { get; set; }

        /// <summary>
        /// 未完伝票かどうか（カラム名：bflg）
        /// </summary>
        public bool IsMikanDenpyou { get; set; }

        #endregion

        #region 仕訳項目

        /// <summary>
        /// 仕訳SEQNo.（カラム名：sseq）
        /// </summary>
        public int Sseq { get; private set; }

        /// <summary>
        /// 親子フラグ（カラム名：pflg）
        /// </summary>
        public SiwakeParentChildRelated SiwakeParentChildRelated { get; set; }

        /// <summary>
        /// 分離区分（カラム名：bkbn）
        /// </summary>
        public BunriKubun BunriKubun { get; set; }

        /// <summary>
        /// グループ番号（カラム名：grno）
        /// </summary>
        public int? GroupNo { get; set; }

        /// <summary>
        /// 行番号（カラム名：dlin）
        /// </summary>
        public int? LineNo { get; set; }

        /// <summary>
        /// 貸借属性（カラム名：dflg）
        /// </summary>
        public SiwakeTaisyakuZokusei SiwakeTaisyakuZokusei { get; set; }

        /// <summary>
        /// 仕訳帳票の借方データ
        /// </summary>
        public TanituSiwakeTyouhyouTaisyakubetuDetail KarikataDetail { get; set; } = new TanituSiwakeTyouhyouTaisyakubetuDetail();

        /// <summary>
        /// 仕訳帳票の貸方データ
        /// </summary>
        public TanituSiwakeTyouhyouTaisyakubetuDetail KasikataDetail { get; set; } = new TanituSiwakeTyouhyouTaisyakubetuDetail();

        /// <summary>
        /// 対価金額の入力があるかどうか（カラム名：tflg）
        /// </summary>
        public bool IsInputTaikaKingaku { get; set; }

        /// <summary>
        /// 対価金額（カラム名：exvl）
        /// </summary>
        public decimal TaikaKingaku { get; set; }

        /// <summary>
        /// 税込金額（カラム名：zkvl）
        /// </summary>
        public decimal ZeikomiKingaku { get; set; }

        /// <summary>
        /// 金額（カラム名：valu）
        /// </summary>
        public decimal Kingaku { get; set; }

        /// <summary>
        /// 税対象科目 科目内部コード（カラム名：zkmk）
        /// </summary>
        public string SyouhizeiTaisyouKicd { get; set; }

        /// <summary>
        /// 税対象科目 税率（カラム名：zrit, zkeigen）（未設定の場合はnull）
        /// </summary>
        public Syouhizeiritu SyouhizeiTaisyouKamokuSyouhizeiritu { get; set; }

        /// <summary>
        /// 税対象科目 課税区分（カラム名：zzkb）
        /// </summary>
        public KazeiKubun? SyouhizeiTaisyouKamokuKazeiKubun { get; set; }

        /// <summary>
        /// 税対象科目 業種区分（カラム名：zgyo）
        /// </summary>
        public GyousyuKubun? SyouhizeiTaisyouKamokuGyousyuKubun { get; set; }

        /// <summary>
        /// 税対象科目 仕入区分（カラム名：zsre）
        /// </summary>
        public SiwakeSiireKubun? SyouhizeiTaisyouKamokuSiireKubun { get; set; }

        /// <summary>
        /// 一括税抜仕訳フラグ（カラム名：ifri）
        /// </summary>
        public IkkatuZeinukiSiwakeFlag IkkatuZeinukiSiwakeFlag { get; set; }

        /// <summary>
        /// 支払日（カラム名：symd）
        /// </summary>
        public IcspDateTime SiharaiDate { get; set; }

        /// <summary>
        /// 支払区分コード（カラム名：skbn）
        /// </summary>
        public int? SiharaiKubunCode { get; set; }

        /// <summary>
        /// 支払期日（カラム名：skiz）
        /// </summary>
        public IcspDateTime SiharaiKizitu { get; set; }

        /// <summary>
        /// 回収日（カラム名：uymd）
        /// </summary>
        public IcspDateTime KaisyuuDate { get; set; }

        /// <summary>
        /// 入金区分コード（カラム名：ukbn）
        /// </summary>
        public int? NyuukinKubunCode { get; set; }

        /// <summary>
        /// 回収期日（カラム名：ukiz）
        /// </summary>
        public IcspDateTime KaisyuuKizitu { get; set; }

        /// <summary>
        /// 消込コード（カラム名：dkec）
        /// </summary>
        public string KesikomiCode { get; set; }

        /// <summary>
        /// 仕訳作成日（カラム名：fmod）
        /// </summary>
        public IcspDateTime SiwakeCreateDate { get; set; }

        /// <summary>
        /// 仕訳作成者コード（カラム名：fusr）
        /// </summary>
        public int SiwakeCreateUserCode { get; set; }

        /// <summary>
        /// 仕訳更新日（カラム名：lmod）
        /// </summary>
        public IcspDateTime SiwakeUpdateDate { get; set; }

        /// <summary>
        /// 仕訳更新時間（カラム名：ltim）
        /// </summary>
        public int SiwakeUpdateTime { get; set; }

        /// <summary>
        /// 仕訳更新者コード（カラム名：lusr）
        /// </summary>
        public int SiwakeUpdateUserCode { get; set; }

        /// <summary>
        /// 取消仕訳かどうか（カラム名：delf）
        /// </summary>
        public bool IsTorikesiSiwake { get; set; }

        /// <summary>
        /// 仕訳の付箋（カラム名：fsen）
        /// </summary>
        public SiwakeHusen SiwakeHusen { get; set; }

        /// <summary>
        /// レート（カラム名：rate）
        /// </summary>
        public decimal Rate { get; set; }

        /// <summary>
        /// 外貨金額（カラム名：gaika）
        /// </summary>
        public decimal GaikaKingaku { get; set; }

        /// <summary>
        /// 外貨対価金額（カラム名：gexvl）
        /// </summary>
        public decimal GaikaTaikaKingaku { get; set; }

        /// <summary>
        /// 外貨税込金額（カラム名：gzkvl）
        /// </summary>
        public decimal GaikaZeikomiKingaku { get; set; }

        /// <summary>
        /// 貸借摘要フラグ（カラム名：tekiflg）
        /// </summary>
        public TaisyakuTekiyouFlag TaisyakuTekiyouFlag { get; set; }

        /// <summary>
        /// 否認仕訳かどうか（カラム名：hflg）
        /// </summary>
        public bool IsHininSiwake { get; set; }

        /// <summary>
        /// 外貨換算仕訳フラグ
        /// </summary>
        public GaikaKansanSiwakeFlag GaikaKansanSiwakeFlag { get; set; }

        #endregion

        #region 本支店項目

        /// <summary>
        /// 本支店展開前の仕訳SEQNo.（カラム名：osseq）
        /// </summary>
        public int SseqBeforeHonsitenTenkai { get; set; }

        #endregion

        #region その他項目

        /// <summary>
        /// 起票部門名称
        /// </summary>
        public string KihyouBumonName { get; set; }

        /// <summary>
        /// 起票者名称
        /// </summary>
        public string KihyouTantousyaName { get; set; }

        /// <summary>
        /// 伝票作成者名称
        /// </summary>
        public string DenpyouCreateUserName { get; set; }

        /// <summary>
        /// 伝票更新者名称
        /// </summary>
        public string DenpyouUpdateUserName { get; set; }

        /// <summary>
        /// 第一承認者名称
        /// </summary>
        public string Dai1SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第二承認者名称
        /// </summary>
        public string Dai2SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第三承認者名称
        /// </summary>
        public string Dai3SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第四承認者名称
        /// </summary>
        public string Dai4SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第五承認者名称
        /// </summary>
        public string Dai5SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第六承認者名称
        /// </summary>
        public string Dai6SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第七承認者名称
        /// </summary>
        public string Dai7SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第八承認者名称
        /// </summary>
        public string Dai8SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第九承認者名称
        /// </summary>
        public string Dai9SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第十承認者名称
        /// </summary>
        public string Dai10SyouninsyaUserName { get; set; }

        /// <summary>
        /// ヘッダーフィールド1名称
        /// </summary>
        public string HeaderField01Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド2名称
        /// </summary>
        public string HeaderField02Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド3名称
        /// </summary>
        public string HeaderField03Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド4名称
        /// </summary>
        public string HeaderField04Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド5名称
        /// </summary>
        public string HeaderField05Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド6名称
        /// </summary>
        public string HeaderField06Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド7名称
        /// </summary>
        public string HeaderField07Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド8名称
        /// </summary>
        public string HeaderField08Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド9名称
        /// </summary>
        public string HeaderField09Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド10名称
        /// </summary>
        public string HeaderField10Name { get; set; }

        /// <summary>
        /// 伝票項目未入力チェック結果
        /// </summary>
        public DenpyouItemNotInputCheckResult DenpyouItemNotInputCheckResult { get; set; } = new DenpyouItemNotInputCheckResult();

        /// <summary>
        /// 伝票束コード
        /// </summary>
        public string DenpyouTabaCode { get; set; }

        /// <summary>
        /// 税対象科目 科目入力コード
        /// </summary>
        public string SyouhizeiTaisyouKcod { get; set; }

        /// <summary>
        /// 税対象科目 科目名称
        /// </summary>
        public string SyouhizeiTaisyouKamokuName { get; set; }

        /// <summary>
        /// 税対象科目 科目正式名称
        /// </summary>
        public string SyouhizeiTaisyouKamokuLongName { get; set; }

        /// <summary>
        /// 税対象科目 処理グループ
        /// </summary>
        public KamokuSyoriGroup SyouhizeiTaisyouKamokuSyoriGroup { get; set; }

        /// <summary>
        /// 支払区分名称
        /// </summary>
        public string SiharaiKubunName { get; set; }

        /// <summary>
        /// 入金区分名称
        /// </summary>
        public string NyuukinKubunName { get; set; }

        /// <summary>
        /// 仕訳作成者名称
        /// </summary>
        public string SiwakeCreateUserName { get; set; }

        /// <summary>
        /// 仕訳更新者名称
        /// </summary>
        public string SiwakeUpdateUserName { get; set; }

        /// <summary>
        /// 未転記データかどうか
        /// </summary>
        public bool IsMitenkiData { get; set; }

        /// <summary>
        /// 整理月かどうか
        /// </summary>
        public bool IsSeirituki { get; set; }

        /// <summary>
        /// 仕訳を確定するかどうか
        /// </summary>
        public bool IsSiwakeKakutei { get; set; }

        /// <summary>
        /// コメントが入力されているかどうか
        /// </summary>
        public bool IsInputedComment { get; set; }

        /// <summary>
        /// 表示不可能な仕訳かどうか
        /// </summary>
        public bool IsNotDisplayableSiwake { get; set; }

        /// <summary>
        /// 伝票日付以前の最新の税対象科目税率かどうか
        /// </summary>
        public bool IsLatestSyouhizeiTaisyouKamokuSyouhizeirituBeforeDenpyouDate { get; set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールドコードを取得します。
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールドコード</returns>
        public string GetHeaderFieldCode(int no)
        {
            switch (no)
            {
                case 1:
                    return this.Hfcd01;
                case 2:
                    return this.Hfcd02;
                case 3:
                    return this.Hfcd03;
                case 4:
                    return this.Hfcd04;
                case 5:
                    return this.Hfcd05;
                case 6:
                    return this.Hfcd06;
                case 7:
                    return this.Hfcd07;
                case 8:
                    return this.Hfcd08;
                case 9:
                    return this.Hfcd09;
                case 10:
                    return this.Hfcd10;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ヘッダーフィールド名称を取得します
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールド名称</returns>
        public string GetHeaderFieldName(int no)
        {
            switch (no)
            {
                case 1:
                    return this.HeaderField01Name;
                case 2:
                    return this.HeaderField02Name;
                case 3:
                    return this.HeaderField03Name;
                case 4:
                    return this.HeaderField04Name;
                case 5:
                    return this.HeaderField05Name;
                case 6:
                    return this.HeaderField06Name;
                case 7:
                    return this.HeaderField07Name;
                case 8:
                    return this.HeaderField08Name;
                case 9:
                    return this.HeaderField09Name;
                case 10:
                    return this.HeaderField10Name;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ヘッダーフィールドコードを設定します。
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <param name="code">設定するヘッダーフィールドコード</param>
        public void SetHeaderFieldCode(int no, string code)
        {
            switch (no)
            {
                case 1:
                    this.Hfcd01 = code;
                    break;
                case 2:
                    this.Hfcd02 = code;
                    break;
                case 3:
                    this.Hfcd03 = code;
                    break;
                case 4:
                    this.Hfcd04 = code;
                    break;
                case 5:
                    this.Hfcd05 = code;
                    break;
                case 6:
                    this.Hfcd06 = code;
                    break;
                case 7:
                    this.Hfcd07 = code;
                    break;
                case 8:
                    this.Hfcd08 = code;
                    break;
                case 9:
                    this.Hfcd09 = code;
                    break;
                case 10:
                    this.Hfcd10 = code;
                    break;
            }
        }

        /// <summary>
        /// 自己仕訳かどうかを取得します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <returns>自己仕訳かどうか</returns>
        public bool IsZikoSiwake(int userCode)
        {
            return this.DenpyouCreateUserCode == userCode;
        }

        #endregion
    }
}
