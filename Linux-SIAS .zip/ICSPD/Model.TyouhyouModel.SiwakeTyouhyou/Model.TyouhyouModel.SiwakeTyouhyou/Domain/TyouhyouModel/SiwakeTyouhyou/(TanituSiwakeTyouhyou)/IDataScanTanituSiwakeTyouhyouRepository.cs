﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public interface IDataScanTanituSiwakeTyouhyouRepository
    {
        /// <summary>
        /// 仕訳帳票問合せパラメータ及び部門を条件として、単一仕訳帳票を取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>単一仕訳帳票</returns>
        DataScanTanituSiwakeTyouhyou FindByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、部門リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>部門リスト</returns>
        IList<Bumon> FindBumonListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);
    }
}