﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// ODC用単一仕訳帳票行
    /// </summary>
    public interface IOdcTanituSiwakeTyouhyouRow : ITanituSiwakeTyouhyouRow
    {
        GaikaKansanSiwakeFlag GaikaKansanSiwakeFlag { get; set; }
    }
}
