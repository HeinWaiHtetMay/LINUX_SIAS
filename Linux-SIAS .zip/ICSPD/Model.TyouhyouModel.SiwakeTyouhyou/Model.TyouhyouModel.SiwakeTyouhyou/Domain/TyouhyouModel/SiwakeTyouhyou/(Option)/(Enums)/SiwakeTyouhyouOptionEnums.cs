﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 承認伝票の検索条件
    /// </summary>
    public enum SyouninDenpyouSearchCondition
    {
        /// <summary>
        /// 未承認伝票（新規承認のみ）
        /// </summary>
        OnlyNewSyouninDenpyou = 0,

        /// <summary>
        /// 未承認伝票（下位未承認のみ）
        /// </summary>
        OnlyLowerNotSyouninDenpyou = 1,

        /// <summary>
        /// 承認済伝票
        /// </summary>
        SyouninCompletedDenpyou = 2,

        /// <summary>
        /// 指定無し（確定伝票のみ）
        /// </summary>
        OnlyKakuteiDenpyou = 3,

        /// <summary>
        /// 未確定伝票のみ
        /// </summary>
        OnlyNotKakuteiDenpyou = 4
    }

    /// <summary>
    /// マスターの表示形式（起票日以外で使用）
    /// </summary>
    public enum SiwakeTyouhyouMasterDisplayType
    {
        /// <summary>
        /// コード
        /// </summary>
        Code = 0,

        /// <summary>
        /// 名称
        /// </summary>
        Name = 1,

        /// <summary>
        /// 表示しない
        /// </summary>
        NotDisplayed = 2
    }

    /// <summary>
    /// 帳票の出力形式
    /// </summary>
    public enum SiwakeTyouhyouOutputType
    {
        /// <summary>
        /// 単一仕訳
        /// </summary>
        TanituSiwake = 0,

        /// <summary>
        /// 複合仕訳
        /// </summary>
        HukugouSiwake = 1
    }

    /// <summary>
    /// 伝票並び順
    /// </summary>
    public enum SiwakeTyouhyouDenpyouSortOrder
    {
        /// <summary>
        /// 仕訳SEQ順
        /// </summary>
        Sseq = 0,

        /// <summary>
        /// 伝票日付順
        /// </summary>
        DenpyouDate = 1,

        /// <summary>
        /// 伝票番号順
        /// </summary>
        DenpyouNo = 2,

        /// <summary>
        /// 受付番号順
        /// </summary>
        UketukeNo = 3,

        /// <summary>
        /// 伝票SEQ順
        /// </summary>
        Dseq = 4
    }

    /// <summary>
    /// ソート順
    /// </summary>
    public enum SiwakeTyouhyouSortOrder
    {
        /// <summary>
        /// 受付番号
        /// </summary>
        UketukeNo = 0,

        /// <summary>
        /// 伝票日付→受付番号
        /// </summary>
        DenpyouDateAndUketukeNo = 1,

        /// <summary>
        /// 伝票番号→受付番号
        /// </summary>
        DenpyouNoAndUketukeNo = 2,
    }

    /// <summary>
    /// 整理月の表示形式
    /// </summary>
    public enum SiwakeTyouhyouSeiritukiDisplayType
    {
        /// <summary>
        /// 数字
        /// </summary>
        Suuji = 0,

        /// <summary>
        /// 丸囲み文字
        /// </summary>
        CircleKakomiCharacter = 1
    }

    /// <summary>
    /// コメントの印刷設定
    /// </summary>
    public enum SiwakeTyouhyouCommentPrintSetting
    {
        /// <summary>
        /// 印刷しない
        /// </summary>
        NotPrint = 0,

        /// <summary>
        /// 横並びで印刷する
        /// </summary>
        PrintInHorizontal = 1,

        /// <summary>
        /// 縦並びで印刷する
        /// </summary>
        PrintInVertical = 2
    }

    /// <summary>
    /// 伝票日付の印刷出力設定
    /// </summary>
    public enum SiwakeTyouhyouDenpyouDatePrintOutputSetting
    {
        /// <summary>
        /// 同一日付単位で出力
        /// </summary>
        SameDateTani = 0,

        /// <summary>
        /// 仕訳行単位で出力
        /// </summary>
        SiwakeRowTani = 1
    }

    /// <summary>
    /// 伝票単位で通常出力する場合の出力内容の設定
    /// </summary>
    public enum SiwakeTyouhyouHukugouSiwakeNormalOutputSetting
    {
        /// <summary>
        /// 修正仕訳を含む伝票
        /// </summary>
        AllSiwakeOutput = 1,

        /// <summary>
        /// 修正仕訳のみ（行変更を含む）
        /// </summary>
        ContainingLineChangedSiwake = 2,

        /// <summary>
        /// 修正仕訳のみ（行変更を含まない）
        /// </summary>
        NotContainingLineChangedSiwake = 3
    }

    /// <summary>
    /// 出力順序の設定
    /// </summary>
    public enum SiwakeTyouhyouOutputOrderSetting
    {
        /// <summary>
        /// 受付番号順
        /// </summary>
        UketukeNo = 0,

        /// <summary>
        /// 承認グループ／伝票入力者／受付番号順
        /// </summary>
        SgnoAndDenpyouCreateUserAndUketukeNo = 1,

        /// <summary>
        /// 承認グループ／受付番号順
        /// </summary>
        SgnoAndUketukeNo = 2,

        /// <summary>
        /// 伝票日付／受付番号順
        /// </summary>
        DenpyouDateAndUketukeNo = 3
    }

    /// <summary>
    /// 摘要文字の分割形式
    /// </summary>
    public enum SiwakeTyouhyouTekiyouCharacterDivisionType
    {
        /// <summary>
        /// 分割しない
        /// </summary>
        None = 0,

        /// <summary>
        /// OR条件で検索
        /// </summary>
        OrZyoukenSearch = 1,

        /// <summary>
        /// AND条件で検索
        /// </summary>
        AndZyoukenSearch = 2
    }

    /// <summary>
    /// データスキャンで表示するタブ
    /// </summary>
    public enum SiwakeTyouhyouDscanTabType
    {
        /// <summary>
        /// 伝票項目
        /// </summary>
        DenpyouItem = 0,

        /// <summary>
        /// 仕訳項目１
        /// </summary>
        SiwakeItem1 = 1,

        /// <summary>
        /// 仕訳項目２
        /// </summary>
        SiwakeItem2 = 2,

        /// <summary>
        /// 仕訳項目３
        /// </summary>
        SiwakeItem3 = 3
    }
}
