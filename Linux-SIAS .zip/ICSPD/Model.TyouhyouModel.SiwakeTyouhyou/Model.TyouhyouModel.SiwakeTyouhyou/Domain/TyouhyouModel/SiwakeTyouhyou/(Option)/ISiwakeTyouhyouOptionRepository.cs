﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouOptionRepository
    {
        /// <summary>
        /// 指定条件の仕訳帳表オプションを取得します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="kesn">内部決算期</param>
        /// <param name="programIdForOption">取得に使用するプログラムID</param>
        /// <returns>仕訳帳表オプション</returns>
        SiwakeTyouhyouOption FindByProgramIdAndUserCode(string programId, int userCode, int kesn, string programIdForOption);

        /// <summary>
        /// 仕訳出力時に必要なオプションを設定します。
        /// </summary>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="kesn">内部決算期</param>
        void SetOptionRequiredWhenSiwakeOutput(SiwakeTyouhyouOption siwakeTyouhyouOption, int kesn);

        /// <summary>
        /// 仕訳印刷時に必要なオプションを設定します。
        /// </summary>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        void SetOptionRequiredWhenSiwakePrint(SiwakeTyouhyouOption siwakeTyouhyouOption);

        /// <summary>
        /// 仕訳帳表オプションを保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳表オプション</param>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="isKessanSeiriSyoriUser">決算整理処理ユーザーかどうか</param>
        void Store(string programId, int userCode, SiwakeTyouhyouOption siwakeTyouhyouOption, string programIdForOption, bool isKessanSeiriSyoriUser);
    }
}
