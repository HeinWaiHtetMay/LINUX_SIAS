﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Drawing;
    using Icsp.Open21.Domain.DenpyouInputModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;

    /// <summary>
    /// 仕訳帳表オプション
    /// </summary>
    public class SiwakeTyouhyouOption : IDenpyouInputSyouninOption
    {
        public SiwakeTyouhyouOption(string programIdForOption)
        {
            this.SiwakeTyouhyouOutputType = programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN")
                ? SiwakeTyouhyouOutputType.HukugouSiwake
                : SiwakeTyouhyouOutputType.TanituSiwake;

            this.TanituSiwakeDenpyouSortOrder = programIdForOption == "DSCAN" || programIdForOption == "NIKKMAIN"
                ? SiwakeTyouhyouDenpyouSortOrder.DenpyouDate
                : SiwakeTyouhyouDenpyouSortOrder.Sseq;

            this.SeiritukiDisplayType = programIdForOption.EndsWith("SYONIN")
                ? SiwakeTyouhyouSeiritukiDisplayType.Suuji
                : SiwakeTyouhyouSeiritukiDisplayType.CircleKakomiCharacter;

            this.IsPrintTotalKingakuEachDenpyou =
            this.IsPrintSyokutiCheckForEachDenpyou = programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA";
        }

        #region プロパティ

        #region オプション設定ダイアログの各設定項目

        /// <summary>
        /// 出力形式
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; set; }

        /// <summary>
        /// 伝票単位時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder { get; set; } = SiwakeTyouhyouDenpyouSortOrder.DenpyouDate;

        /// <summary>
        /// 仕訳一覧時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder { get; set; }

        /// <summary>
        /// ソート順
        /// </summary>
        public SiwakeTyouhyouSortOrder SortOrder { get; set; }

        /// <summary>
        /// 仕訳の最大表示数
        /// </summary>
        public int SiwakeMaxDisplayCount { get; set; } = 100000;

        /// <summary>
        /// 整理月の月表示
        /// </summary>
        public SiwakeTyouhyouSeiritukiDisplayType SeiritukiDisplayType { get; set; }

        /// <summary>
        /// 伝票ごとに合計金額を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuEachDenpyou { get; set; }

        /// <summary>
        /// 仕訳帳票のコメントの印刷
        /// </summary>
        public SiwakeTyouhyouCommentPrintSetting CommentPrintSetting { get; set; }

        /// <summary>
        /// 本支店展開後の仕訳を印刷するかどうか
        /// </summary>
        public bool IsPrintSiwakeAfterHonsitenTenkai { get; set; }

        /// <summary>
        /// 「未承認」の色
        /// </summary>
        public Color MisyouninColor { get; set; } = Color.FromArgb(222, 67, 1);

        /// <summary>
        /// 「否認」の色
        /// </summary>
        public Color HininColor { get; set; } = Color.FromArgb(255, 0, 0);

        /// <summary>
        /// 「承認」の色
        /// </summary>
        public Color SyouninColor { get; set; } = Color.FromArgb(0, 85, 0);

        /// <summary>
        /// 伝票日付の印刷出力設定
        /// </summary>
        public SiwakeTyouhyouDenpyouDatePrintOutputSetting DenpyouDatePrintOutputSetting { get; set; } = SiwakeTyouhyouDenpyouDatePrintOutputSetting.SiwakeRowTani;

        /// <summary>
        /// 出力指定の範囲指定で印刷した場合に、伝票を印刷済に設定するかどうか
        /// </summary>
        public bool IsSetDenpyouOutputed { get; set; }

        /// <summary>
        /// 伝票単位で通常出力する場合の出力内容の設定
        /// </summary>
        public SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting { get; set; } = SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.AllSiwakeOutput;

        /// <summary>
        /// 貸借とも科目が表示できない仕訳を出力しないかどうか
        /// </summary>
        public bool IsNotOutputKamokuNotDisplayedSiwake { get; set; }

        /// <summary>
        /// 処理月全体での印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForAllSyorituki { get; set; }

        /// <summary>
        /// 処理月全体での印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForAllSyorituki { get; set; }

        /// <summary>
        /// 出力された仕訳の印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForOutputSiwake { get; set; } = true;

        /// <summary>
        /// 出力された仕訳の印刷時に、伝票件数を印刷するかどうか
        /// </summary>
        public bool IsPrintDenpyouCountForOutputSiwake { get; set; }

        /// <summary>
        /// 出力された仕訳の印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForOutputSiwake { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForEachDenpyou { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、１伝票１行でも印刷するかどうか
        /// </summary>
        public bool IsPrintRowPerOneDenpyouForEachDenpyou { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForEachDenpyou { get; set; }

        #endregion

        #region 未入力チェックダイアログの各設定項目

        /// <summary>
        /// 未入力チェックオプション
        /// </summary>
        public NotInputCheckOption NotInputCheckOption { get; set; } = new NotInputCheckOption();

        #endregion

        #region 出力順序の設定ダイアログの各設定項目

        /// <summary>
        /// 出力順序の設定
        /// </summary>
        public SiwakeTyouhyouOutputOrderSetting OutputOrderSetting { get; set; }

        #endregion

        #region 前回の選択内容の各設定項目

        /// <summary>
        /// 印刷レイアウトNo
        /// </summary>
        public int PrintLayoutNo { get; set; }

        /// <summary>
        /// 摘要文字の分割形式
        /// </summary>
        public SiwakeTyouhyouTekiyouCharacterDivisionType TekiyouCharacterDivisionType { get; set; }

        /// <summary>
        /// すべてのユーザーを対象に出力するかどうか
        /// </summary>
        public bool IsAllUserOutputTarget { get; set; }

        /// <summary>
        /// 未完伝票のみを検索するかどうか
        /// </summary>
        public bool IsMikanDenpyouOnlySearch { get; set; }

        /// <summary>
        /// データスキャンで最後に表示したタブ
        /// </summary>
        public SiwakeTyouhyouDscanTabType DscanLastDisplayedTab { get; set; }

        #endregion

        #region 未転記データ検索設定ダイアログの各設定項目

        /// <summary>
        /// 未転記データ検索対象に、未確定仕訳を含めるかどうか
        /// </summary>
        public bool IsContainNotKakuteiSiwakeForSearchTarget { get; set; }

        /// <summary>
        /// 未転記データ検索対象に、未承認仕訳を含めるかどうか
        /// </summary>
        public bool IsContainNotSyouninSiwakeForSearchTarget { get; set; }

        /// <summary>
        /// 未転記データ検索対象に、承認中仕訳を含めるかどうか
        /// </summary>
        public bool IsContainSyounintyuuSiwakeForSearchTarget { get; set; }

        /// <summary>
        /// 未転記データ検索対象に、承認済仕訳を含めるかどうか
        /// </summary>
        public bool IsContainSyouninzumiSiwakeForSearchTarget { get; set; }

        /// <summary>
        /// 未転記データ集計対象に、未転記データ含めるかどうか
        /// </summary>
        public bool IsContainMitenkiDataForSyuukeiTarget { get; set; }

        #endregion

        #region 表示設定ダイアログの各設定項目

        /// <summary>
        /// 起票日の表示形式の設定値
        /// </summary>
        public bool KihyouDateDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// 起票者の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KihyouTantousyaDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 起票部門の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KihyouBumonDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField01DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField02DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField03DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField04DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField05DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField06DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField07DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField08DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField09DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド１０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField10DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 科目の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KamokuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 部門の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType BumonDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 枝番の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType EdabanDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 取引先の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType TorihikisakiDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// セグメントの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType SegmentDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// プロジェクトの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType ProjectDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 工事の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KouziDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 工種の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KousyuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユーザーの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UserDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 消費税対象科目の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType SyouhizeiTaisyouKamokuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 支払日の表示形式の設定値
        /// </summary>
        public bool SiharaiDateDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// 消込の表示形式の設定値
        /// </summary>
        public bool KesikomiDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// ユニバーサルフィールド１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField01DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField02DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField03DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField04DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField05DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField06DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField07DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField08DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField09DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField10DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField11DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField12DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField13DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField14DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField15DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField16DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField17DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField18DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField19DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド２０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField20DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        #endregion

        #region 否認状況メッセージダイアログの各設定項目

        /// <summary>
        /// 伝票入力者に否認状況メッセージを送信するかどうか
        /// </summary>
        public bool IsSendHininStatusMessageDenpyouInputter { get; set; }

        /// <summary>
        /// 否認状況メッセージを"重要"として送信するかどうか
        /// </summary>
        public bool IsSendAsImportantHininStatusMessage { get; set; }

        /// <summary>
        /// 否認状況メッセージを下位承認者にも送信するかどうか
        /// </summary>
        public bool IsSendLowerSyouninsyaHininStatusMessage { get; set; }

        #endregion

        #region 会社情報設定登録の帳表関係の各設定項目

        /// <summary>
        /// 課税区分「対象外」を出力するかどうか（仕訳の税区分出力設定）
        /// </summary>
        public bool IsOutputTaisyougaiInKazeiKubun { get; set; } = true;

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）
        /// </summary>
        public SiwakeOutputOption SiwakeOutputOption { get; set; } = new SiwakeOutputOption();

        /// <summary>
        /// 伝票入力修正オプション（伝票入力修正設定）
        /// </summary>
        public DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption { get; set; } = new DenpyouInputAndSyuuseiOption();

        /// <summary>
        /// 印刷プレビューオプション（印刷プレビュー設定）
        /// </summary>
        public PrintPreviewOption PrintPreviewOption { get; set; } = new PrintPreviewOption();

        #endregion

        #region その他項目

        /// <summary>
        /// 承認伝票の検索条件
        /// </summary>
        public SyouninDenpyouSearchCondition SyouninDenpyouSearchCondition { get; set; }

        /// <summary>
        /// 入力済のシナリオ
        /// </summary>
        public Scenario InputedScenario { get; set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールド未入力チェックをおこなうかどうかの設定値を取得します
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールド未入力チェックをおこなうかどうかの設定値</returns>
        public bool GetHeaderFieldNotInputCheck(int headerFieldNo)
        {
            switch (headerFieldNo)
            {
                case 1:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField1Inputted;
                case 2:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField2Inputted;
                case 3:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField3Inputted;
                case 4:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField4Inputted;
                case 5:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField5Inputted;
                case 6:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField6Inputted;
                case 7:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField7Inputted;
                case 8:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField8Inputted;
                case 9:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField9Inputted;
                case 10:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField10Inputted;
                default:
                    return false;
            }
        }

        /// <summary>
        /// エクスポート用に、オブジェクトを複製します。
        /// </summary>
        /// <returns>複製済みのオブジェクト</returns>
        public SiwakeTyouhyouOption CloneForExport()
        {
            var siwakeTyouhyouOption = this.MemberwiseClone() as SiwakeTyouhyouOption;
            siwakeTyouhyouOption.SiwakeTyouhyouOutputType = SiwakeTyouhyouOutputType.TanituSiwake;
            return siwakeTyouhyouOption;
        }

        /// <summary>
        /// 印刷用に、オブジェクトを複製します。
        /// </summary>
        /// <returns>複製済みのオブジェクト</returns>
        public SiwakeTyouhyouOption CloneForPrint()
        {
            var siwakeTyouhyouOption = this.MemberwiseClone() as SiwakeTyouhyouOption;
            siwakeTyouhyouOption.IsPrintTotalKingakuForEachDenpyou &= siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder != SiwakeTyouhyouDenpyouSortOrder.Sseq;
            siwakeTyouhyouOption.IsPrintRowPerOneDenpyouForEachDenpyou &= siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder != SiwakeTyouhyouDenpyouSortOrder.Sseq;
            siwakeTyouhyouOption.IsPrintSyokutiCheckForEachDenpyou &= siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder != SiwakeTyouhyouDenpyouSortOrder.Sseq;
            return siwakeTyouhyouOption;
        }

        /// <summary>
        /// 承認状況の色を取得します
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public Color GetSyouninStatusColor(SyouninStatus status)
        {
            switch (status)
            {
                //// 未承認
                case SyouninStatus.Other:
                    return this.MisyouninColor;
                //// 承認
                case SyouninStatus.Syounin:
                    return this.SyouninColor;
                //// 否認（修正）
                //// 否認（削除）
                case SyouninStatus.HininSyuusei:
                case SyouninStatus.HininSakuzyo:
                    return this.HininColor;
                default:
                    return Color.Black;
            }
        }

        #endregion
    }
}
