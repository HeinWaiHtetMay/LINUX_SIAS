﻿using Icsp.Open21.Domain.SyouhizeiModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 伝票形式
    /// </summary>
    public enum DenpyouTypeSearchType
    {
        /// <summary>
        /// 指定なし
        /// </summary>
        None = 0,

        /// <summary>
        /// 複合形式
        /// </summary>
        HukugouType = 1,

        /// <summary>
        /// 単一形式
        /// </summary>
        TanituType = 2
    }

    /// <summary>
    /// リンク情報
    /// </summary>
    public enum LinkInfomationSearchType
    {
        /// <summary>
        /// 指定なし
        /// </summary>
        None = 0,

        /// <summary>
        /// リンク情報ありのみ
        /// </summary>
        OnlyDenpyouHasLinkInformation = 1,

        /// <summary>
        /// リンク情報なしのみ
        /// </summary>
        OnlyDenpyouHasNotLinkInformation = 2
    }

    /// <summary>
    /// 未完伝票の設定
    /// </summary>
    public enum MikanDenpyouSearchSetting
    {
        /// <summary>
        /// 指定なし
        /// </summary>
        None = 0,

        /// <summary>
        /// 未完伝票のみ
        /// </summary>
        MikanDenpyouOnly = 1,

        /// <summary>
        /// 未完伝票以外
        /// </summary>
        NoMikanDenpyou = 2,
    }

    /// <summary>
    /// 科目指定方法
    /// </summary>
    public enum KamokuSiteiMethod
    {
        /// <summary>
        /// 単一指定
        /// </summary>
        TanituSitei = 0,

        /// <summary>
        /// 範囲指定
        /// </summary>
        RangeSitei = 1,

        /// <summary>
        /// 個別指定
        /// </summary>
        KobetuSitei = 2
    }

    /// <summary>
    /// 課税区分（検索用）
    /// </summary>
    public enum KazeiKubunSearchType
    {
        指定なし = 0,
        税込系 = 1,
        税抜系 = 2,
        非課税系 = 3,
        特定収系 = 4,
        対象外 = KazeiKubun.対象外 + 5,
        税込 = KazeiKubun.税込 + 5,
        税抜 = KazeiKubun.税抜 + 5,
        免税 = KazeiKubun.免税 + 5,
        非課税 = KazeiKubun.非課税 + 5,
        課込仕入 = KazeiKubun.課込仕入 + 5,
        課込売上 = KazeiKubun.課込売上 + 5,
        課抜仕入 = KazeiKubun.課抜仕入 + 5,
        課抜売上 = KazeiKubun.課抜売上 + 5,
        貸倒損込 = KazeiKubun.貸倒損込 + 5,
        貸倒損抜 = KazeiKubun.貸倒損抜 + 5,
        貸倒回込 = KazeiKubun.貸倒回込 + 5,
        貸倒回抜 = KazeiKubun.貸倒回抜 + 5,
        課税貨物 = KazeiKubun.課税貨物 + 5,
        貨国税 = KazeiKubun.貨国税 + 5,
        貨地方税 = KazeiKubun.貨地方税 + 5,
        非課仕入 = KazeiKubun.非課税仕入 + 5,
        非課売上 = KazeiKubun.非課税売上 + 5,
        特定収入 = KazeiKubun.特定収入 + 5,
        不特定収 = KazeiKubun.使途不明特定収入 + 5,
        外特定収 = KazeiKubun.使途不明特定収入 + 6,
        特課仕入 = KazeiKubun.特課仕入 + 5,
        控外仕入 = KazeiKubun.控外仕入 + 5,
        計算外 = KazeiKubun.計算外 + 5,
    }

    /// <summary>
    /// 仕訳作成（更新）方法の指定方法
    /// </summary>
    public enum SiwakeWayToCreateSiteiMethod
    {
        /// <summary>
        /// 指定なし
        /// </summary>
        None = 0,

        /// <summary>
        /// 指定方法のみ
        /// </summary>
        SiteiMethodOnly = 1,

        /// <summary>
        /// 指定方法以外
        /// </summary>
        NotSiteiMethodOnly = 2
    }

    /// <summary>
    /// 仕訳作成（更新）方法
    /// </summary>
    public enum DenpyouSiwakeWayToCreateSearchType
    {
        Dinpfri = 2,
        Dinpbkei = 3,
        Ledmain = 101,
        Dscan = 102,
        Chkmain = 103,
        Nikkmain = 104,
        Gledmain = 110,
        Sfdinpfri = 202,
        Sfdinpbkei = 203,
        Sfchkmain = 301,
        Sfsyonin = 302,
        Sfzaimu = 303,
        Sfledmain = 401,
        Sdscan = 402,
        Sfgledmain = 410,
        Dtcomin = 601,
        Dtcomlin = 602,
        Ndpick = 603,
        Import = 604,
        Datadel = 605,
        Sfdtcomin = 701,
        Sfimport = 704,
        Stznk = 801,
        Stzdl = 802,
        Syzdsp = 803,
        Gkswk = 810,
        Msconv = 901,
        KtSyoukyaku = 2011,
        KtJyokyaku = 2012,
        KtKounyu = 2021,
        KtBaikyaku = 2022,
        KtGenson = 2031,
        KtJyokyo = 2041,
        KtLease = 2051,
        KtSFSyoukyaku = 2111,
        KtSFJyokyaku = 2112,
        KtSFKounyu = 2121,
        KtSFbaikyaku = 2122,
        KtSFGenson = 2131,
        KtSFJyokyo = 2141,
        KtSFLease = 2151,
        SaSeikyu = 4001,
        SaNyukin = 4011,
        SaKesikm = 4021,
        SaTyouki = 4031,
        SaSFSeikyu = 4101,
        SaSFNyukin = 4111,
        SaSFKesikm = 4121,
        SaSFTyouki = 4131,
        FbAutoData = 5001,
        FbSFAutoData = 5101,
        KsKssFubn = 6001,
        KsKssInput = 6002,
        SmSaimukj = 7001,
        SmShiharaikj = 7002,
        SmTegatadat = 7004,
        SmTegatakbn = 7005,
        SmTegataks = 7006,
        SmSFSaimukj = 7101,
        SmSFShiharaikj = 7102,
        SmSFTegatadat = 7104,
        SmSFTegatakbn = 7105,
        SmSFTegataks = 7106,
        CsGassan = 8011,
        CsSousai = 8012,
        CsHurimodosi = 8013,
        Kyuyo = 8021,
        SfKyuyo = 8022,
        WF = 8041,
        SfWF = 8042,
        BtoBRenkei = 8051,
        SfBtoBRenkei = 8052,
        AIOCR = 8061,
        SfAIOCR = 8062,
        Adon = 9001,
        SfAdon = 9101,
        Other = 9999
    }

    /// <summary>
    /// 処理区分
    /// </summary>
    public enum SyoriType
    {
        /// <summary>
        /// 入力確定・チェックリスト
        /// </summary>
        CheckList = 0,

        /// <summary>
        /// 承認処理
        /// </summary>
        SyouninSyori = 1,

        /// <summary>
        /// その他
        /// </summary>
        Other = 2
    }

    /// <summary>
    /// 出力選択
    /// </summary>
    public enum CheckListOutputSelectType
    {
        /// <summary>
        /// 通常（未印刷（印刷済フラグがOFF）の仕訳が対象）
        /// </summary>
        NotPrintedSiwake = 0,

        /// <summary>
        /// 範囲指定（範囲指定内の仕訳が対象（指定がなければ全仕訳が対象））
        /// </summary>
        HaniSiteiSiwake = 1
    }
}
