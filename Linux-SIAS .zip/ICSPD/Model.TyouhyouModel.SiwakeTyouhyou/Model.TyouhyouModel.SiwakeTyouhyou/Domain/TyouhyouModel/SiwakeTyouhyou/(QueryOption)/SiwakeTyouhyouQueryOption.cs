﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 仕訳帳票問合せオプション
    /// </summary>
    public class SiwakeTyouhyouQueryOption
    {
        private readonly bool isOutputOnlyDenpyouHasLinkInformation;

        public SiwakeTyouhyouQueryOption(IKaisyaSyoriKikan kaisyaSyoriKikan, bool isUseSecurity, bool isSokyuuApplication, bool isDenpyouUpdateUserTanituSitei)
        {
            //// 共通項目
            this.KaisyaSyoriKikan = kaisyaSyoriKikan;
            this.IsUseSecurity = isUseSecurity;
            this.IsSokyuuApplication = isSokyuuApplication;

            //// 伝票項目
            this.isOutputOnlyDenpyouHasLinkInformation =
                this.LinkInformation == LinkInfomationSearchType.OnlyDenpyouHasLinkInformation
                || !string.IsNullOrEmpty(this.EDocumentNoRangeValue.StartValue)
                || !string.IsNullOrEmpty(this.EDocumentNoRangeValue.EndValue);
            this.IsDenpyouUpdateUserTanituSitei = isDenpyouUpdateUserTanituSitei;
        }

        #region 共通項目

        /// <summary>
        /// 処理期間情報
        /// </summary>
        public IKaisyaSyoriKikan KaisyaSyoriKikan { get; private set; }

        /// <summary>
        /// セキュリティを参照するかどうか
        /// </summary>
        public bool IsUseSecurity { get; private set; }

        /// <summary>
        /// 過年度遡及のアプリケーションかどうか
        /// </summary>
        public bool IsSokyuuApplication { get; private set; }

        /// <summary>
        /// 部門単位出力
        /// </summary>
        public BumonTaniOutputSetting BumonTaniOutputSetting { get; set; } = BumonTaniOutputSetting.Normal;

        #endregion

        #region 伝票項目

        /// <summary>
        /// 経過月の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> DkeiRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 伝票SEQの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> DseqRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 伝票日付の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> DenpyouDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 伝票番号の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> DenpyouNoRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 受付番号の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> UketukeNoRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 確定日付の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> InputKakuteiDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 伝票形式
        /// </summary>
        public DenpyouTypeSearchType DenpyouType { get; set; }

        /// <summary>
        /// リンク情報
        /// </summary>
        public LinkInfomationSearchType LinkInformation { get; set; }

        /// <summary>
        /// e文書番号の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> EDocumentNoRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// リンク情報ありの伝票のみを出力するかどうか
        /// </summary>
        public bool IsOutputOnlyDenpyouHasLinkInformation => this.isOutputOnlyDenpyouHasLinkInformation;

        /// <summary>
        /// 伝票作成者の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> DenpyouCreateUserCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 伝票作成日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> DenpyouCreateDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 伝票更新者の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> DenpyouUpdateUserCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 伝票更新者が単一指定されているかどうか
        /// </summary>
        public bool IsDenpyouUpdateUserTanituSitei { get; private set; }

        /// <summary>
        /// 伝票更新日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> DenpyouUpdateDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 起票日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> KihyouDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 起票者の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> KihyouTantousyaCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 起票部門の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> KihyouBumonCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// ヘッダーフィールド１の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd01RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド２の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd02RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド３の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd03RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド４の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd04RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド５の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd05RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド６の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd06RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド７の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd07RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド８の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd08RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド９の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd09RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ヘッダーフィールド１０の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Hfcd10RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// シナリオの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> ScenarioRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 伝票束の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> DenpyouTabaCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 承認グループ
        /// </summary>
        public SyouninGroup SyouninGroup { get; set; }

        /// <summary>
        /// 未完伝票の設定
        /// </summary>
        public MikanDenpyouSearchSetting MikanDenpyouSearchSetting { get; set; } = MikanDenpyouSearchSetting.None;

        #endregion

        #region 仕訳項目

        #region 貸借共通項目

        /// <summary>
        /// 貸借ごとに条件を指定するかどうか
        /// </summary>
        public bool IsSetConditionEachTaisyaku { get; set; }

        /// <summary>
        /// 科目指定方法
        /// </summary>
        public KamokuSiteiMethod KamokuSiteiMethod { get; set; } = KamokuSiteiMethod.TanituSitei;

        /// <summary>
        /// 仕訳SEQの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> SseqRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 仕訳作成者の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> SiwakeCreateUserCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 仕訳作成日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> SiwakeCreateDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 仕訳更新者の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> SiwakeUpdateUserCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// 仕訳更新日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> SiwakeUpdateDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> KingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 対価金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> TaikaKingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 税込金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> ZeikomiKingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 税対象科目の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<Kamoku> SyouhizeiTaisyouKamokuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<Kamoku>();

        /// <summary>
        /// 税対象科目 課税区分
        /// </summary>
        public KazeiKubunSearchType SyouhizeiTaisyouKamokuKazeiKubun { get; set; }

        /// <summary>
        /// 税対象科目 税率
        /// </summary>
        public Syouhizeiritu SyouhizeiTaisyouKamokuSyouhizeiritu { get; set; }

        /// <summary>
        /// 税対象科目 業種区分
        /// </summary>
        public GyousyuKubun? SyouhizeiTaisyouKamokuGyousyuKubun { get; set; }

        /// <summary>
        /// 税対象科目 仕入区分
        /// </summary>
        public SiwakeSiireKubun? SyouhizeiTaisyouKamokuSiireKubun { get; set; }

        /// <summary>
        /// 付箋
        /// </summary>
        public SiwakeHusen? SiwakeHusen { get; set; }

        /// <summary>
        /// 支払日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> SiharaiDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 支払期日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> SiharaiKizituRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 支払区分
        /// </summary>
        public SiharaiNyuukinKubun SiharaiKubun { get; set; }

        /// <summary>
        /// 回収日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> KaisyuuDateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 回収期日の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime> KaisyuuKizituRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<IcspDateTime>();

        /// <summary>
        /// 入金区分
        /// </summary>
        public SiharaiNyuukinKubun NyuukinKubun { get; set; }

        /// <summary>
        /// 消込の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> KesikomiCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 外貨金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> GaikaKingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 外貨対価金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> GaikaTaikaKingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 外貨税込金額の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> GaikaZeikomiKingakuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// レートの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<decimal?> RateRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<decimal?>();

        /// <summary>
        /// 幣種
        /// </summary>
        public Heisyu Heisyu { get; set; }

        /// <summary>
        /// 仕訳作成方法の指定方法
        /// </summary>
        public SiwakeWayToCreateSiteiMethod SiwakeWayToCreateSiteiMethod { get; set; } = SiwakeWayToCreateSiteiMethod.None;

        /// <summary>
        /// 仕訳作成方法リスト
        /// </summary>
        public IList<DenpyouSiwakeWayToCreateSearchType> SiwakeWayToCreateList { get; set; } = new List<DenpyouSiwakeWayToCreateSearchType>();

        /// <summary>
        /// 仕訳更新方法の指定方法
        /// </summary>
        public SiwakeWayToCreateSiteiMethod SiwakeWayToUpdateSiteiMethod { get; set; } = SiwakeWayToCreateSiteiMethod.None;

        /// <summary>
        /// 仕訳更新方法リスト
        /// </summary>
        public IList<DenpyouSiwakeWayToCreateSearchType> SiwakeWayToUpdateList { get; set; } = new List<DenpyouSiwakeWayToCreateSearchType>();

        /// <summary>
        /// 取消仕訳を結果に含めるかどうか
        /// </summary>
        public bool IsContainTorikesiSiwake { get; set; }

        /// <summary>
        /// 未印刷の仕訳のみを出力するかどうか
        /// </summary>
        public bool IsOutputOnlyNotPrintedSiwake { get; set; }

        /// <summary>
        /// 部門（個別指定）
        /// </summary>
        public IList<string> BcodKobetuSiteiList { get; set; } = new List<string>();

        /// <summary>
        /// 部門の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> BcodRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        #endregion

        #region 貸借別項目

        /// <summary>
        /// 借方側の仕訳帳票問合せオプション
        /// </summary>
        public SiwakeTyouhyouTaisyakubetuQueryOption KarikataQueryOption { get; private set; } = new SiwakeTyouhyouTaisyakubetuQueryOption();

        /// <summary>
        /// 貸方側の仕訳帳票問合せオプション
        /// </summary>
        public SiwakeTyouhyouTaisyakubetuQueryOption KasikataQueryOption { get; private set; } = new SiwakeTyouhyouTaisyakubetuQueryOption();

        #endregion

        #endregion

        #region その他項目

        /// <summary>
        /// 印刷が済んでいない伝票のみ出力するかどうか
        /// </summary>
        public bool IsOutputOnlyNotPrintedDenpyou { get; set; }

        /// <summary>
        /// 未確定の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputNotKakuteiDenpyou { get; set; } = true;

        /// <summary>
        /// 未承認の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputNotSyouninDenpyou { get; set; }

        /// <summary>
        /// 承認中の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputSyounintyuuDenpyou { get; set; }

        /// <summary>
        /// 承認済の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputSyouninzumiDenpyou { get; set; }

        /// <summary>
        /// 否認（修正）の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputHininSyuuseiDenpyou { get; set; } = true;

        /// <summary>
        /// 否認（削除）の伝票を出力するかどうか
        /// </summary>
        public bool IsOutputHininDeleteDenpyou { get; set; } = true;

        /// <summary>
        /// すべての伝票を出力するかどうか
        /// </summary>
        public bool IsOutputAllDenpyou { get; set; }

        /// <summary>
        /// 処理区分
        /// </summary>
        public SyoriType SyoriType { get; set; } = SyoriType.Other;

        /// <summary>
        /// 出力指定
        /// </summary>
        public CheckListOutputSelectType CheckListOutputSelectType { get; set; }

        #endregion
    }
}
