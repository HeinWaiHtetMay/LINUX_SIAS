﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票問合せオプションの範囲値
    /// </summary>
    /// <typeparam name="T">データの型</typeparam>
    public class SiwakeTyouhyouQueryOptionRangeValue<T>
    {
        #region プロパティ

        /// <summary>
        /// 開始値
        /// </summary>
        public T StartValue { get; set; }

        /// <summary>
        /// 終了値
        /// </summary>
        public T EndValue { get; set; }

        /// <summary>
        /// 未入力の項目のみ出力するかどうか
        /// </summary>
        public bool IsOutputNotInputOnly { get; set; }

        /// <summary>
        /// 完全一致で検索するかどうか
        /// </summary>
        public bool IsSearchWithFullMatch { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// 各値を設定します。
        /// </summary>
        /// <param name="startValue">開始値</param>
        /// <param name="endValue">終了値</param>
        /// <param name="isOutputNotInputOnly">未入力の項目のみ出力するかどうか</param>
        /// <param name="isSearchWithFullMatch">完全一致で検索するかどうか</param>
        public void SetValue(T startValue, T endValue, bool isOutputNotInputOnly, bool isSearchWithFullMatch)
        {
            this.StartValue = startValue;
            this.EndValue = endValue;
            this.IsOutputNotInputOnly = isOutputNotInputOnly;
            this.IsSearchWithFullMatch = isSearchWithFullMatch;
        }

        #endregion
    }
}
