﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 仕訳帳票貸借別問合せオプション
    /// </summary>
    public class SiwakeTyouhyouTaisyakubetuQueryOption
    {
        /// <summary>
        /// 科目の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<Kamoku> KamokuRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<Kamoku>();

        /// <summary>
        /// 科目個別指定リスト
        /// </summary>
        public IList<Kamoku> KamokuKobetuSiteiList { get; set; } = new List<Kamoku>();

        /// <summary>
        /// 課税区分
        /// </summary>
        public KazeiKubunSearchType KazeiKubun { get; set; }

        /// <summary>
        /// 税率
        /// </summary>
        public Syouhizeiritu Syouhizeiritu { get; set; }

        /// <summary>
        /// 業種区分
        /// </summary>
        public GyousyuKubun? GyousyuKubun { get; set; }

        /// <summary>
        /// 仕入区分
        /// </summary>
        public SiwakeSiireKubun? SiireKubun { get; set; }

        /// <summary>
        /// 部門の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> BcodRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 取引先の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> TrcdRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 枝番の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> EcodRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// セグメントの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> SgcdRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// プロジェクトの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> PjcdRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 工事の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> KzcdRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 工種の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> KscdRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 摘要の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<string> TekiyouRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<string>();

        /// <summary>
        /// 摘要の検索条件
        /// </summary>
        public TekiyouSearchCondition TekiyouSearchCondition { get; set; }

        /// <summary>
        /// 摘要コードの範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<int?> TekiyouCodeRangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<int?>();

        /// <summary>
        /// ユニバーサルフィールド１の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd01RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド２の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd02RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド３の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd03RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド４の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd04RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド５の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd05RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド６の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd06RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド７の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd07RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド８の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd08RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド９の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd09RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１０の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd10RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１１の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd11RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１２の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd12RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１３の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd13RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１４の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd14RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１５の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd15RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１６の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd16RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１７の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd17RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１８の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd18RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド１９の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd19RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();

        /// <summary>
        /// ユニバーサルフィールド２０の範囲値
        /// </summary>
        public SiwakeTyouhyouQueryOptionRangeValue<object> Ufcd20RangeValue { get; set; } = new SiwakeTyouhyouQueryOptionRangeValue<object>();
    }
}
