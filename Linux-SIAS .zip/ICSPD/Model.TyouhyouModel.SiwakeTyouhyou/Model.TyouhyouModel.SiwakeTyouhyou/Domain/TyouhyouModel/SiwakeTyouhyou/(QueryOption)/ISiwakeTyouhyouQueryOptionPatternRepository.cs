﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public interface ISiwakeTyouhyouQueryOptionPatternRepository
    {
        /// <summary>
        /// ユーザーNoを条件として、仕訳帳票問合せパターンを取得します。
        /// </summary>
        /// <param name="usno">ユーザーNo</param>
        /// <returns>仕訳帳票問合せパターンリスト</returns>
        IList<IMasterData> FindByUsnoOrderByPtno(int usno);

        /// <summary>
        /// ユーザーNo・パターンを条件として、仕訳帳票問合せオプションを取得します。
        /// </summary>
        /// <param name="usno">ユーザーNo</param>
        /// <param name="ptno">パターン</param>
        /// <param name="syoriKikan">処理期間情報</param>
        /// <param name="isUseSecurity">セキュリティを参照するかどうか</param>
        /// <param name="option">仕訳帳票オプション</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="gaikaInitialSetting">外貨初期設定</param>
        /// <returns>仕訳帳票問合せオプション</returns>
        SiwakeTyouhyouQueryOption FindByUsnoAndPtnoOrderByIdno(
            int usno,
            int ptno,
            IKaisyaSyoriKikan syoriKikan,
            bool isUseSecurity,
            SiwakeTyouhyouOption option,
            SyouhizeiMaster syouhizeiMaster,
            GaikaInitialSetting gaikaInitialSetting);

        /// <summary>
        /// ユーザーNo・パターンを条件として、仕訳帳票問合せパターンの存在可否チェック結果を取得します。
        /// </summary>
        /// <param name="usno">ユーザーNo</param>
        /// <param name="ptno">パターン</param>
        /// <returns>仕訳帳票問合せパターンの存在可否チェック結果</returns>
        bool GetExistsByUsnoAndPtno(int usno, int ptno);

        /// <summary>
        /// 仕訳帳票問合せオプションパターンを保存します。
        /// </summary>
        /// <param name="queryOptionPattern">仕訳帳票問合せオプションパターン</param>
        /// <param name="option">仕訳帳票オプション</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="gaikaInitialSetting">外貨初期設定</param>
        /// <param name="securityType">セキュリティ区分</param>
        /// <param name="syouninUsage">承認使用状況</param>
        void Store(
            SiwakeTyouhyouQueryOptionPattern queryOptionPattern,
            SiwakeTyouhyouOption option,
            int userCode,
            SyouhizeiMaster syouhizeiMaster,
            GaikaInitialSetting gaikaInitialSetting,
            ApplicationSecurityType securityType,
            SyouninUsage syouninUsage);

        /// <summary>
        /// ユーザーNo・パターンを条件として、仕訳帳票問合せオプションパターンを削除します。
        /// </summary>
        /// <param name="usno">ユーザーNo</param>
        /// <param name="ptno">パターン</param>
        void DeleteByUsnoAndPtno(int usno, int ptno);
    }
}
