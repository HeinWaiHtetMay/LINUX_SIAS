﻿using Icsp.Open21.Domain.SyouhizeiModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class KazeiKubunSearchTypeExtension
    {
        /// <summary>
        /// 課税区分（検索用）→課税区分に変換します。
        /// </summary>
        /// <param name="kazeiKubun">課税区分（検索用）</param>
        /// <returns>課税区分</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多く省略不可")]
        public static KazeiKubun ConvertKazeiKubunSearchTypeToKazeiKubun(this KazeiKubunSearchType kazeiKubun)
        {
            return (KazeiKubun)((int)kazeiKubun - 5);
        }

        /// <summary>
        /// 特定収入系の課税区分かどうかを判定します。
        /// </summary>
        /// <param name="kazeiKubun">課税区分</param>
        /// <returns>特定収入系の課税区分かどうか</returns>
        public static bool IsTokuteiSyuunyuu(this KazeiKubunSearchType kazeiKubun)
        {
            return kazeiKubun == KazeiKubunSearchType.特定収系
                || kazeiKubun == KazeiKubunSearchType.特定収入
                || kazeiKubun == KazeiKubunSearchType.不特定収
                || kazeiKubun == KazeiKubunSearchType.外特定収;
        }
    }
}
