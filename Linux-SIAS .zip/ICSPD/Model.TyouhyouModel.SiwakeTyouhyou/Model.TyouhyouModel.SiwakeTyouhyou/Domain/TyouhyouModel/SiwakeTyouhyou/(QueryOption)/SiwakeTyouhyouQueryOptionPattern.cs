﻿using System;
using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票問合せオプションパターン
    /// </summary>
    public class SiwakeTyouhyouQueryOptionPattern : IMasterData
    {
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other, MasterCodeType.Numeric, 2);

        public SiwakeTyouhyouQueryOptionPattern(int patternNo)
        {
            this.PatternNo = patternNo;
        }

        /// <summary>
        /// パターンNo
        /// </summary>
        public int PatternNo { get; private set; }

        /// <summary>
        /// パターン名称
        /// </summary>
        public string PatternName { get; set; }

        /// <summary>
        /// 仕訳帳票問合せオプション
        /// </summary>
        public SiwakeTyouhyouQueryOption SiwakeTyouhyouQueryOption { get; set; }

        public string Code => MasterInfo.GetFormattedCode(this.PatternNo.ToString());

        public string Name => this.PatternName;
    }
}
