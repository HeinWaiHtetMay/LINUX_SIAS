﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouDisplayOptionRepository
    {
        /// <summary>
        /// 仕訳帳表表示オプションを設定します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouDisplayOption">仕訳帳表表示オプション</param>
        void SetDisplaySettingOption(string programId, int userCode, SiwakeTyouhyouDisplayOption siwakeTyouhyouDisplayOption);

        /// <summary>
        /// 表示設定の各項目の設定値を保存します。
        /// </summary>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouDisplayOption">仕訳帳表表示オプション</param>
        void StoreDisplaySettingOption(string programIdForOption, int userCode, SiwakeTyouhyouDisplayOption siwakeTyouhyouDisplayOption);
    }
}