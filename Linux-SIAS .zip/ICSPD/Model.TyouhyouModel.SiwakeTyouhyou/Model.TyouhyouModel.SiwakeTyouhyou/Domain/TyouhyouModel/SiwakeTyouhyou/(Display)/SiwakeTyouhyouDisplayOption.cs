﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 表示設定の各設定項目
    /// </summary>
    public class SiwakeTyouhyouDisplayOption
    {
        #region プロパティ

        /// <summary>
        /// 起票日の表示形式の設定値
        /// </summary>
        public bool KihyouDateDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// 起票者の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KihyouTantousyaDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 起票部門の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KihyouBumonDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField01DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField02DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField03DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField04DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField05DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField06DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField07DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField08DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField09DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ヘッダーフィールド１０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType HeaderField10DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 科目の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KamokuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 部門の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType BumonDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 枝番の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType EdabanDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 取引先の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType TorihikisakiDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// セグメントの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType SegmentDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// プロジェクトの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType ProjectDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 工事の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KouziDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 工種の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType KousyuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユーザーの表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UserDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 消費税対象科目の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType SyouhizeiTaisyouKamokuDisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// 支払日の表示形式の設定値
        /// </summary>
        public bool SiharaiDateDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// 消込の表示形式の設定値
        /// </summary>
        public bool KesikomiDisplayTypeValue { get; set; } = true;

        /// <summary>
        /// ユニバーサルフィールド１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField01DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField02DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField03DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField04DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField05DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField06DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField07DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField08DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField09DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField10DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１１の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField11DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１２の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField12DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１３の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField13DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１４の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField14DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１５の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField15DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１６の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField16DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１７の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField17DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１８の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField18DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド１９の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField19DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        /// <summary>
        /// ユニバーサルフィールド２０の表示形式の設定値
        /// </summary>
        public SiwakeTyouhyouMasterDisplayType UniversalField20DisplayTypeValue { get; set; } = SiwakeTyouhyouMasterDisplayType.Name;

        #endregion

    }
}
