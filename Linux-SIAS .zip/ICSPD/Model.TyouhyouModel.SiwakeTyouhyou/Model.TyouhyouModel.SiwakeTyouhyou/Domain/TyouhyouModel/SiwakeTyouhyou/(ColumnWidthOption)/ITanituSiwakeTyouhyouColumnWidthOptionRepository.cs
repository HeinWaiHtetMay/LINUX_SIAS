﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ITanituSiwakeTyouhyouColumnWidthOptionRepository
    {
        /// <summary>
        /// 単一仕訳帳票の列幅オプションを取得します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <returns>取得した単一仕訳帳票の列幅オプション</returns>
        TanituSiwakeTyouhyouColumnWidthOption FindByUserCodeAndProgramId(int userCode, string programId);

        /// <summary>
        /// 単一仕訳帳票の列幅オプションを保存します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <param name="columnWidthOption">保存する単一仕訳帳票の列幅オプション</param>
        void Store(int userCode, string programId, TanituSiwakeTyouhyouColumnWidthOption columnWidthOption);
    }
}
