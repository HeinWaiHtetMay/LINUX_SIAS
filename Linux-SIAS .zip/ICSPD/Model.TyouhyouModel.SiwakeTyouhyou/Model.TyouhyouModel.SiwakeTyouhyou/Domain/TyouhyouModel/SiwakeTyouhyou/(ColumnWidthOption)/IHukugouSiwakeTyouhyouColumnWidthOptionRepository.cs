﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface IHukugouSiwakeTyouhyouColumnWidthOptionRepository
    {
        /// <summary>
        /// 複合仕訳帳票の列幅オプションを取得します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <returns>取得した複合仕訳帳票の列幅オプション</returns>
        HukugouSiwakeTyouhyouColumnWidthOption FindByUserCodeAndProgramId(int userCode, string programId);

        /// <summary>
        /// 複合仕訳帳票の列幅オプションを保存します
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">プログラムID</param>
        /// <param name="columnWidthOption">保存する複合仕訳帳票の列幅オプション</param>
        void Store(int userCode, string programId, HukugouSiwakeTyouhyouColumnWidthOption columnWidthOption);
    }
}
