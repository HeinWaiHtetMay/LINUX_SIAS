﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 複合仕訳帳票の列幅オプション
    /// </summary>
    public class HukugouSiwakeTyouhyouColumnWidthOption
    {
        private const int KihyouDateColumnDefaultWidth = 80;
        private const int KihyouTantousyaColumnDefaultWidth = 152;
        private const int KihyouBumonColumnDefaultWidth = 152;
        private const int HeaderFieldColumnDefaultWidth = 152;
        private const int LineNoColumnDefaultWidth = 24;
        private const int SyouninStatusColumnDefaultWidth = 66;
        private const int KingakuColumnDefaultWidth = 129;
        private const int MasterRelatedItemColumnDefaultWidth = 156;
        private const int ZeiKubunColumnDefaultWidth = 38;
        private const int TekiyouColumnDefaultWidth = 290;
        private const int MasterRelatedItem2ColumnDefaultWidth = 187;
        private const int UniversalFieldColumnDefaultWidth = 290;
        private const int SiwakeCreateDateAndKakuteiDateColumnDefaultWidth = 79;

        public HukugouSiwakeTyouhyouColumnWidthOption(string programId)
        {
            if (programId == "SFCHKMAIN" || programId == "SKCHLSTA")
            {
                //// 入力確定・チェックリスト
                this.KihyouTantousyaColumnWidth = KihyouTantousyaColumnDefaultWidth + 6;
                this.KihyouBumonColumnWidth = KihyouBumonColumnDefaultWidth + 6;
                this.HeaderField01ColumnWidth =
                this.HeaderField02ColumnWidth =
                this.HeaderField03ColumnWidth =
                this.HeaderField04ColumnWidth =
                this.HeaderField05ColumnWidth =
                this.HeaderField06ColumnWidth =
                this.HeaderField07ColumnWidth =
                this.HeaderField08ColumnWidth =
                this.HeaderField09ColumnWidth =
                this.HeaderField10ColumnWidth = HeaderFieldColumnDefaultWidth + 6;

                this.KarikataKingakuColumnWidth =
                this.KasikataKingakuColumnWidth = KingakuColumnDefaultWidth + 14;
                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth + 2;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth + 1;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth - 62;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth - 3;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth - 4;
            }
            else if (programId == "SFSYONIN" || programId == "SKSYONIN")
            {
                //// 承認処理
                this.KihyouTantousyaColumnWidth = KihyouTantousyaColumnDefaultWidth - 42;
                this.KihyouBumonColumnWidth = KihyouBumonColumnDefaultWidth - 3;
                this.HeaderField01ColumnWidth =
                this.HeaderField02ColumnWidth =
                this.HeaderField03ColumnWidth =
                this.HeaderField04ColumnWidth =
                this.HeaderField05ColumnWidth =
                this.HeaderField06ColumnWidth =
                this.HeaderField07ColumnWidth =
                this.HeaderField08ColumnWidth =
                this.HeaderField09ColumnWidth =
                this.HeaderField10ColumnWidth = HeaderFieldColumnDefaultWidth - 3;

                this.KarikataKingakuColumnWidth =
                this.KasikataKingakuColumnWidth = KingakuColumnDefaultWidth + 46;
                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth + 2;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth + 6;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth - 65;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth - 36;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth - 139;
            }
            else
            {
                //// 上記以外
                this.KihyouTantousyaColumnWidth = KihyouTantousyaColumnDefaultWidth;
                this.KihyouBumonColumnWidth = KihyouBumonColumnDefaultWidth;
                this.HeaderField01ColumnWidth =
                this.HeaderField02ColumnWidth =
                this.HeaderField03ColumnWidth =
                this.HeaderField04ColumnWidth =
                this.HeaderField05ColumnWidth =
                this.HeaderField06ColumnWidth =
                this.HeaderField07ColumnWidth =
                this.HeaderField08ColumnWidth =
                this.HeaderField09ColumnWidth =
                this.HeaderField10ColumnWidth = HeaderFieldColumnDefaultWidth;

                this.KarikataKingakuColumnWidth =
                this.KasikataKingakuColumnWidth = KingakuColumnDefaultWidth;
                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth;
            }
        }

        #region 伝票ヘッダー

        /// <summary>
        /// 起票日の列幅
        /// </summary>
        public int KihyouDateColumnWidth { get; set; } = KihyouDateColumnDefaultWidth;

        /// <summary>
        /// 起票者の列幅
        /// </summary>
        public int KihyouTantousyaColumnWidth { get; set; }

        /// <summary>
        /// 起票部門の列幅
        /// </summary>
        public int KihyouBumonColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド１の列幅
        /// </summary>
        public int HeaderField01ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド２の列幅
        /// </summary>
        public int HeaderField02ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド３の列幅
        /// </summary>
        public int HeaderField03ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド４の列幅
        /// </summary>
        public int HeaderField04ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド５の列幅
        /// </summary>
        public int HeaderField05ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド６の列幅
        /// </summary>
        public int HeaderField06ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド７の列幅
        /// </summary>
        public int HeaderField07ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド８の列幅
        /// </summary>
        public int HeaderField08ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド９の列幅
        /// </summary>
        public int HeaderField09ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド１０の列幅
        /// </summary>
        public int HeaderField10ColumnWidth { get; set; }

        #endregion

        #region 仕訳明細

        /// <summary>
        /// 行番号の列幅
        /// </summary>
        public int LineNoColumnWidth { get; set; } = LineNoColumnDefaultWidth;

        /// <summary>
        /// 承認状況の列幅
        /// </summary>
        public int SyouninStatusColumnWidth { get; set; } = SyouninStatusColumnDefaultWidth;

        /// <summary>
        /// 借方金額の列幅
        /// </summary>
        public int KarikataKingakuColumnWidth { get; set; }

        /// <summary>
        /// 借方マスタ関連項目（部門／科目／取引先／枝番）の列幅
        /// </summary>
        public int KarikataMasterRelatedItemColumnWidth { get; set; }

        /// <summary>
        /// 借方税区分の列幅
        /// </summary>
        public int KarikataZeiKubunColumnWidth { get; set; }

        /// <summary>
        /// 摘要の列幅
        /// </summary>
        public int TekiyouColumnWidth { get; set; }

        /// <summary>
        /// 貸方税区分の列幅
        /// </summary>
        public int KasikataZeiKubunColumnWidth { get; set; }

        /// <summary>
        /// 貸方マスタ関連項目（部門／科目／取引先／枝番）の列幅
        /// </summary>
        public int KasikataMasterRelatedItemColumnWidth { get; set; }

        /// <summary>
        /// 貸方金額の列幅
        /// </summary>
        public int KasikataKingakuColumnWidth { get; set; }

        /// <summary>
        /// 借方マスタ関連項目（セグメント／プロジェクト／工事／工種）の列幅
        /// </summary>
        public int KarikataMasterRelatedItem2ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１～４の列幅
        /// </summary>
        public int KarikataUniversalField01to04ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド５～８の列幅
        /// </summary>
        public int KarikataUniversalField05to08ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド９～１２の列幅
        /// </summary>
        public int KarikataUniversalField09to12ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１３～１６の列幅
        /// </summary>
        public int KarikataUniversalField13to16ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１７～２０の列幅
        /// </summary>
        public int KarikataUniversalField17to20ColumnWidth { get; set; }

        /// <summary>
        /// 貸方マスタ関連項目（セグメント／プロジェクト／工事／工種）の列幅
        /// </summary>
        public int KasikataMasterRelatedItem2ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１～４の列幅
        /// </summary>
        public int KasikataUniversalField01to04ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド５～８の列幅
        /// </summary>
        public int KasikataUniversalField05to08ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド９～１２の列幅
        /// </summary>
        public int KasikataUniversalField09to12ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１３～１６の列幅
        /// </summary>
        public int KasikataUniversalField13to16ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１７～２０の列幅
        /// </summary>
        public int KasikataUniversalField17to20ColumnWidth { get; set; }

        /// <summary>
        /// 仕訳作成日／確定日の列幅
        /// </summary>
        public int SiwakeCreateDateAndKakuteiDateColumnWidth { get; set; } = SiwakeCreateDateAndKakuteiDateColumnDefaultWidth;

        #endregion
    }
}
