﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 単一仕訳帳票の列幅オプション
    /// </summary>
    public class TanituSiwakeTyouhyouColumnWidthOption
    {
        private const int UketukeNoColumnDefaultWidth = 64;
        private const int DenpyouRelatedItemColumnDefaultWidth = 130;
        private const int DenpyouRelatedItem2ColumnDefaultWidth = 90;
        private const int KihyouRelatedItemColumnDefaultWidth = 64;
        private const int HeaderFieldColumnDefaultWidth = 64;
        private const int SiwakeRelatedItemColumnDefaultWidth = 154;
        private const int SiwakeRelatedItem2ColumnDefaultWidth = 158;
        private const int SyouninStatusColumnDefaultWidth = 67;
        private const int MasterRelatedItemColumnDefaultWidth = 156;
        private const int ZeiKubunColumnDefaultWidth = 38;
        private const int KingakuColumnDefaultWidth = 142;
        private const int TekiyouColumnDefaultWidth = 290;
        private const int MasterRelatedItem2ColumnDefaultWidth = 187;
        private const int UniversalFieldColumnDefaultWidth = 290;
        private const int OtherItemColumnDefaultWidth = 206;
        private const int OtherItem2ColumnDefaultWidth = 175;
        private const int HusenColumnDefaultWidth = 24;
        private const int SyouhizeiTaisyouKamokuColumnDefaultWidth = 109;
        private const int SiwakeCreateDateAndKakuteiDateColumnDefaultWidth = 79;

        public TanituSiwakeTyouhyouColumnWidthOption(string programId)
        {
            if (programId == "SFCHKMAIN" || programId == "SKCHLSTA")
            {
                //// 入力確定・チェックリスト
                this.KihyouRelatedItemColumnWidth = KihyouRelatedItemColumnDefaultWidth - 4;
                this.HeaderField01to04ColumnWidth =
                this.HeaderField05to08ColumnWidth =
                this.HeaderField09to10ColumnWidth = HeaderFieldColumnDefaultWidth - 4;

                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth + 2;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth + 1;
                this.KingakuColumnWidth = KingakuColumnDefaultWidth + 16;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth - 62;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth - 1;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth - 4;
            }
            else if (programId == "SFSYONIN" || programId == "SKSYONIN")
            {
                //// 承認処理
                this.KihyouRelatedItemColumnWidth = KihyouRelatedItemColumnDefaultWidth + 85;
                this.HeaderField01to04ColumnWidth =
                this.HeaderField05to08ColumnWidth =
                this.HeaderField09to10ColumnWidth = HeaderFieldColumnDefaultWidth + 85;

                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth + 2;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth + 6;
                this.KingakuColumnWidth = KingakuColumnDefaultWidth + 33;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth - 65;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth - 36;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth - 139;
            }
            else
            {
                //// 上記以外
                this.KihyouRelatedItemColumnWidth = KihyouRelatedItemColumnDefaultWidth;
                this.HeaderField01to04ColumnWidth =
                this.HeaderField05to08ColumnWidth =
                this.HeaderField09to10ColumnWidth = HeaderFieldColumnDefaultWidth;

                this.KarikataMasterRelatedItemColumnWidth =
                this.KasikataMasterRelatedItemColumnWidth = MasterRelatedItemColumnDefaultWidth;
                this.KarikataZeiKubunColumnWidth =
                this.KasikataZeiKubunColumnWidth = ZeiKubunColumnDefaultWidth;
                this.KingakuColumnWidth = KingakuColumnDefaultWidth;
                this.TekiyouColumnWidth = TekiyouColumnDefaultWidth;
                this.KarikataMasterRelatedItem2ColumnWidth =
                this.KasikataMasterRelatedItem2ColumnWidth = MasterRelatedItem2ColumnDefaultWidth;
                this.KarikataUniversalField01to04ColumnWidth =
                this.KarikataUniversalField05to08ColumnWidth =
                this.KarikataUniversalField09to12ColumnWidth =
                this.KarikataUniversalField13to16ColumnWidth =
                this.KarikataUniversalField17to20ColumnWidth =
                this.KasikataUniversalField01to04ColumnWidth =
                this.KasikataUniversalField05to08ColumnWidth =
                this.KasikataUniversalField09to12ColumnWidth =
                this.KasikataUniversalField13to16ColumnWidth =
                this.KasikataUniversalField17to20ColumnWidth = UniversalFieldColumnDefaultWidth;
            }
        }

        /// <summary>
        /// 受付番号の列幅
        /// </summary>
        public int UketukeNoColumnWidth { get; set; } = UketukeNoColumnDefaultWidth;

        /// <summary>
        /// 伝票関連項目（伝票SEQ／伝票日付／伝票番号／受付番号）の列幅
        /// </summary>
        public int DenpyouRelatedItemColumnWidth { get; set; } = DenpyouRelatedItemColumnDefaultWidth;

        /// <summary>
        /// 伝票関連項目（伝票日付／番号／束）の列幅
        /// </summary>
        public int DenpyouRelatedItem2ColumnWidth { get; set; } = DenpyouRelatedItem2ColumnDefaultWidth;

        /// <summary>
        /// 起票関連項目（起票日／起票者／起票部門）の列幅
        /// </summary>
        public int KihyouRelatedItemColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド１～４の列幅
        /// </summary>
        public int HeaderField01to04ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド５～８の列幅
        /// </summary>
        public int HeaderField05to08ColumnWidth { get; set; }

        /// <summary>
        /// ヘッダーフィールド９～１０の列幅
        /// </summary>
        public int HeaderField09to10ColumnWidth { get; set; }

        /// <summary>
        /// 仕訳関連項目（仕訳SEQ／行番号／仕訳作成日／仕訳更新日）の列幅
        /// </summary>
        public int SiwakeRelatedItemColumnWidth { get; set; } = SiwakeRelatedItemColumnDefaultWidth;

        /// <summary>
        /// 仕訳関連項目（仕訳SEQ／行番号／仕訳作成日／確定日）の列幅
        /// </summary>
        public int SiwakeRelatedItem2ColumnWidth { get; set; } = SiwakeRelatedItem2ColumnDefaultWidth;

        /// <summary>
        /// 承認状況の列幅
        /// </summary>
        public int SyouninStatusColumnWidth { get; set; } = SyouninStatusColumnDefaultWidth;

        /// <summary>
        /// 借方マスタ関連項目（部門／科目／取引先／枝番）の列幅
        /// </summary>
        public int KarikataMasterRelatedItemColumnWidth { get; set; }

        /// <summary>
        /// 借方税区分の列幅
        /// </summary>
        public int KarikataZeiKubunColumnWidth { get; set; }

        /// <summary>
        /// 貸方マスタ関連項目（部門／科目／取引先／枝番）の列幅
        /// </summary>
        public int KasikataMasterRelatedItemColumnWidth { get; set; }

        /// <summary>
        /// 貸方税区分の列幅
        /// </summary>
        public int KasikataZeiKubunColumnWidth { get; set; }

        /// <summary>
        /// 金額の列幅
        /// </summary>
        public int KingakuColumnWidth { get; set; }

        /// <summary>
        /// 摘要の列幅
        /// </summary>
        public int TekiyouColumnWidth { get; set; }

        /// <summary>
        /// 借方マスタ関連項目（セグメント／プロジェクト／工事／工種）の列幅
        /// </summary>
        public int KarikataMasterRelatedItem2ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１～４の列幅
        /// </summary>
        public int KarikataUniversalField01to04ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド５～８の列幅
        /// </summary>
        public int KarikataUniversalField05to08ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド９～１２の列幅
        /// </summary>
        public int KarikataUniversalField09to12ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１３～１６の列幅
        /// </summary>
        public int KarikataUniversalField13to16ColumnWidth { get; set; }

        /// <summary>
        /// 借方ユニバーサルフィールド１７～２０の列幅
        /// </summary>
        public int KarikataUniversalField17to20ColumnWidth { get; set; }

        /// <summary>
        /// 貸方マスタ関連項目（セグメント／プロジェクト／工事／工種）の列幅
        /// </summary>
        public int KasikataMasterRelatedItem2ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１～４の列幅
        /// </summary>
        public int KasikataUniversalField01to04ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド５～８の列幅
        /// </summary>
        public int KasikataUniversalField05to08ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド９～１２の列幅
        /// </summary>
        public int KasikataUniversalField09to12ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１３～１６の列幅
        /// </summary>
        public int KasikataUniversalField13to16ColumnWidth { get; set; }

        /// <summary>
        /// 貸方ユニバーサルフィールド１７～２０の列幅
        /// </summary>
        public int KasikataUniversalField17to20ColumnWidth { get; set; }

        /// <summary>
        /// その他項目（仕訳作成者／仕訳更新者／その他）の列幅
        /// </summary>
        public int OtherItemColumnWidth { get; set; } = OtherItemColumnDefaultWidth;

        /// <summary>
        /// その他項目（税科目／支払日／消込）の列幅
        /// </summary>
        public int OtherItem2ColumnWidth { get; set; } = OtherItem2ColumnDefaultWidth;

        /// <summary>
        /// 付箋の列幅
        /// </summary>
        public int HusenColumnWidth { get; set; } = HusenColumnDefaultWidth;

        /// <summary>
        /// 税対象科目の列幅
        /// </summary>
        public int SyouhizeiTaisyouKamokuColumnWidth { get; set; } = SyouhizeiTaisyouKamokuColumnDefaultWidth;

        /// <summary>
        /// 仕訳作成日／確定日の列幅
        /// </summary>
        public int SiwakeCreateDateAndKakuteiDateColumnWidth { get; set; } = SiwakeCreateDateAndKakuteiDateColumnDefaultWidth;
    }
}
