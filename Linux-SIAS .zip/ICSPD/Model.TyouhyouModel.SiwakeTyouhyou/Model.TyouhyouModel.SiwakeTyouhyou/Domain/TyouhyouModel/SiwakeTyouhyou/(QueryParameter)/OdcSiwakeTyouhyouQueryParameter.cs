﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel;

    /// <summary>
    /// ODC仕訳帳票問合せパラメータ
    /// </summary>
    public class OdcSiwakeTyouhyouQueryParameter : AbstractSiwakeTyouhyouQueryParameter, ISiwakeTyouhyouQueryParameter
    {
        private SiwakeTyouhyouOption siwakeTyouhyouOption;

        public OdcSiwakeTyouhyouQueryParameter(Kaisya kaisya, IKaisyaSyoriKikan kaisyaSyoriKikan, BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext, UserAndSyorikiSecurityContext securityContext, SiwakeTyouhyouOption siwakeTyouhyouOption, SiwakeTyouhyouQueryOption siwakeTyouhyouQueryOption, Func<GaikaInitialSetting> getGaikaInitialSetting, KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake)
            : base(kaisya, kaisyaSyoriKikan, mitenkiDataQueryContext, getGaikaInitialSetting)
        {
            this.SecurityContext = securityContext;
            this.siwakeTyouhyouOption = siwakeTyouhyouOption;
            this.SiwakeTyouhyouQueryOption = siwakeTyouhyouQueryOption;
            this.SetSiwakeTyouhyouRowItemAvailability(gaikaSystemAvailability, syouhizeiMaster, isGetSiwake);
        }

        #region プロパティ

        /// <summary>
        /// セキュリティコンテキスト
        /// </summary>
        public UserAndSyorikiSecurityContext SecurityContext { get; private set; }

        /// <summary>
        /// 仕訳帳票問合せオプション
        /// </summary>
        public SiwakeTyouhyouQueryOption SiwakeTyouhyouQueryOption { get; private set; }

        /// <summary>
        /// 仕訳一覧時の伝票並び順を使用するかどうか
        /// </summary>
        public bool IsUseTanituSiwakeDenpyouSortOrder => false;

        /// <summary>
        /// 仕訳帳票取得時に、未入力チェックオプションを使用するかどうか
        /// </summary>
        public bool IsUseNotInputCheckOptionForGetSiwakeTyouhyou => false;

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定
        /// </summary>
        public SiwakeTyouhyouRowItemAvailability SiwakeTyouhyouRowItemAvailability { get; private set; }

        /// <summary>
        /// 必要な仕訳の行番号範囲
        /// </summary>
        public Range<int?> RequiredSiwakeRowNoRange { get; private set; }

        #region リポジトリに影響する設定

        /// <summary>
        /// 承認伝票の検索条件
        /// </summary>
        public SyouninDenpyouSearchCondition SyouninDenpyouSearchCondition => default(SyouninDenpyouSearchCondition);

        /// <summary>
        /// 出力形式
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType => this.siwakeTyouhyouOption.SiwakeTyouhyouOutputType;

        /// <summary>
        /// ソート順（未使用）
        /// </summary>
        public SiwakeTyouhyouSortOrder SortOrder => default(SiwakeTyouhyouSortOrder);

        /// <summary>
        /// 出力順序の設定（未使用）
        /// </summary>
        public SiwakeTyouhyouOutputOrderSetting OutputOrderSetting => default(SiwakeTyouhyouOutputOrderSetting);

        /// <summary>
        /// 伝票単位時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder => this.siwakeTyouhyouOption.HukugouSiwakeDenpyouSortOrder;

        /// <summary>
        /// 仕訳一覧時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder => this.siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder;

        /// <summary>
        /// 仕訳の最大表示数
        /// </summary>
        public int SiwakeMaxDisplayCount => this.siwakeTyouhyouOption.SiwakeMaxDisplayCount;

        /// <summary>
        /// 貸借とも科目が表示できない仕訳を出力しないかどうか
        /// </summary>
        public bool IsNotOutputKamokuNotDisplayedSiwake => this.siwakeTyouhyouOption.IsNotOutputKamokuNotDisplayedSiwake;

        /// <summary>
        /// 伝票単位で通常出力する場合の出力内容の設定
        /// </summary>
        public SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting => this.siwakeTyouhyouOption.HukugouSiwakeNormalOutputSetting;

        /// <summary>
        /// 未入力チェックオプション
        /// </summary>
        public NotInputCheckOption NotInputCheckOption => this.siwakeTyouhyouOption.NotInputCheckOption;

        /// <summary>
        /// 摘要文字の分割形式
        /// </summary>
        public SiwakeTyouhyouTekiyouCharacterDivisionType TekiyouCharacterDivisionType => this.siwakeTyouhyouOption.TekiyouCharacterDivisionType;

        /// <summary>
        /// すべてのユーザーを対象に出力するかどうか（未使用）
        /// </summary>
        public bool IsAllUserOutputTarget => true;

        /// <summary>
        /// 未完伝票のみを検索するかどうか
        /// </summary>
        public bool IsMikanDenpyouOnlySearch => this.siwakeTyouhyouOption.IsMikanDenpyouOnlySearch;

        /// <summary>
        /// 伝票入力修正オプション（伝票入力修正設定）
        /// </summary>
        public DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption => this.siwakeTyouhyouOption.DenpyouInputAndSyuuseiOption;

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）
        /// </summary>
        public SiwakeOutputOption SiwakeOutputOption => this.siwakeTyouhyouOption.SiwakeOutputOption;

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// 並び順のハッシュセットを作成します。(zdata_h.dkei, zdata_h.dseq, zdata.sseq固定）
        /// </summary>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <returns>並び順のハッシュセット</returns>
        public ISet<SiwakeTyouhyouOrderItem> CreateSiwakeTyouhyouOrderItemSet(bool isGetDenpyou)
        {
            return new HashSet<SiwakeTyouhyouOrderItem>()
            {
                SiwakeTyouhyouOrderItem.Dseq,
                SiwakeTyouhyouOrderItem.Sseq
            };
        }

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定を設定します。
        /// </summary>
        /// <param name="gaikaSystemAvailability">外貨システム使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="isGetSiwake">仕訳を取得するかどうか</param>
        public void SetSiwakeTyouhyouRowItemAvailability(KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake)
        {
            if (this.SiwakeTyouhyouRowItemAvailability == null)
            {
                this.SiwakeTyouhyouRowItemAvailability = new SiwakeTyouhyouRowItemAvailability();
            }

            this.SetDefaultSiwakeTyouhyouRowItemAvailability(this.SiwakeTyouhyouRowItemAvailability, gaikaSystemAvailability, syouhizeiMaster, isGetSiwake);

            this.SiwakeTyouhyouRowItemAvailability.DenpyouItemEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled = this.MitenkiDataQueryContext.IncludesBusyobetuSiwake;
            this.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled = true;
            if (isGetSiwake)
            {
                this.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.ZeiKubunItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KamokuEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KingakuItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.GaikaKansanSiwakeFlagEnabled = false;
                this.SiwakeTyouhyouRowItemAvailability.SiwakeHusenEnabled = this.siwakeTyouhyouOption.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake;
                this.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled = false;
            }
        }

        /// <summary>
        /// 必要な仕訳の行番号範囲を設定します
        /// </summary>
        /// <param name="startNo">開始仕訳行番号</param>
        /// <param name="endNo">終了仕訳行番号</param>
        public void SetRequiredSiwakeRowNoRange(int? startNo, int? endNo) => this.RequiredSiwakeRowNoRange = new Range<int?>(startNo, endNo);

        /// <summary>
        /// 必要な仕訳の行番号範囲をクリアします
        /// </summary>
        public void ClearRequiredSiwakeRowNoRange() => this.RequiredSiwakeRowNoRange = null;

        /// <summary>
        /// オブジェクトを複製します。
        /// </summary>
        /// <param name="denpyou">伝票データ</param>
        /// <returns>複製済みのオブジェクト</returns>
        public ISiwakeTyouhyouQueryParameter CloneForHukugouSiwakeTyouhyou(ISiwakeTyouhyouDenpyouRow denpyou)
        {
            var queryParameter = this.MemberwiseClone() as OdcSiwakeTyouhyouQueryParameter;
            queryParameter.SiwakeTyouhyouQueryOption = new SiwakeTyouhyouQueryOption(queryParameter.KaisyaSyoriKikan, queryParameter.SiwakeTyouhyouQueryOption.IsUseSecurity, queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication, queryParameter.SiwakeTyouhyouQueryOption.IsDenpyouUpdateUserTanituSitei)
            {
                IsOutputOnlyNotPrintedSiwake = queryParameter.SiwakeTyouhyouQueryOption.IsOutputOnlyNotPrintedSiwake
            };
            queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.SetValue(denpyou.Dkei, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.DseqRangeValue.SetValue(denpyou.Dseq, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.SetValue(denpyou.DenpyouNo, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.UketukeNoRangeValue.SetValue(denpyou.UketukeNo, null, false, false);
            return queryParameter;
        }

        /// <summary>
        /// 伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうかを取得します。
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <returns>伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうか</returns>
        public bool GetHeaderFieldNotInputCheckForDenpyouSyuusei(int headerFieldNo)
        {
            return false;
        }

        #endregion
    }
}
