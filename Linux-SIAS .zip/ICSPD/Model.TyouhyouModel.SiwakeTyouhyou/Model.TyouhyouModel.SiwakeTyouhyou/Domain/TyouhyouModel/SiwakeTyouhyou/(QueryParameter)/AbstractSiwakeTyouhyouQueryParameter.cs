﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public abstract class AbstractSiwakeTyouhyouQueryParameter
    {
        public AbstractSiwakeTyouhyouQueryParameter(Kaisya kaisya, IKaisyaSyoriKikan kaisyaSyoriKikan, BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext, Func<GaikaInitialSetting> getGaikaInitialSetting)
        {
            this.Kaisya = kaisya;
            this.KaisyaSyoriKikan = kaisyaSyoriKikan;
            this.MitenkiDataQueryContext = mitenkiDataQueryContext;
            this.IsUseGaikaSystem = getGaikaInitialSetting.Invoke()?.IsUseGaikaSystem ?? false;
        }

        #region プロパティ

        /// <summary>
        /// 内部決算期
        /// </summary>
        public int Kesn => this.KaisyaSyoriKikan.Syoriki.Kesn;

        /// <summary>
        /// 会社情報
        /// </summary>
        public Kaisya Kaisya { get; private set; }

        /// <summary>
        /// 処理期間情報
        /// </summary>
        public IKaisyaSyoriKikan KaisyaSyoriKikan { get; private set; }

        /// <summary>
        /// 未転記データ問合せコンテキスト
        /// </summary>
        public BusyobetuTyouhyouMitenkiDataQueryContext MitenkiDataQueryContext { get; private set; }

        /// <summary>
        /// 外貨システム使用有無
        /// </summary>
        public bool IsUseGaikaSystem { get; private set; }

        /// <summary>
        /// 本支店展開をおこなうかどうか
        /// </summary>
        public virtual bool FromHonsitenTenkaiSiwake => this.HonsitenTenkaiServiceResult?.HonsitenTenkaiSiwakeTemporaryTableCreated ?? false;

        /// <summary>
        /// 本支店展開の処理結果
        /// </summary>
        public virtual HonsitenTenkaiServiceResult HonsitenTenkaiServiceResult { get; set; }

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）により、自動諸口の入力コード・名称を変換するかどうか
        /// trueの場合、自動諸口科目の入力コードはstring.Empty、名称はSiwakeOutputOptionの設定値を使用します
        /// </summary>
        public virtual bool ConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// オブジェクトを複製します（本支店展開用）。
        /// </summary>
        /// <param name="serviceResult"></param>
        /// <returns>複製済みのオブジェクト</returns>
        public virtual ISiwakeTyouhyouQueryParameter CloneForHonsitenTenkai(HonsitenTenkaiServiceResult serviceResult)
        {
            var queryParameter = this.MemberwiseClone() as AbstractSiwakeTyouhyouQueryParameter;
            queryParameter.HonsitenTenkaiServiceResult = serviceResult;
            return queryParameter as ISiwakeTyouhyouQueryParameter;
        }

        public virtual ISiwakeTyouhyouQueryParameter CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as ISiwakeTyouhyouQueryParameter;
        }

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定の初期値を設定します。
        /// </summary>
        /// <param name="rowItemAvailability">設定対象の仕訳帳票行項目の使用可否設定</param>
        /// <param name="gaikaSystemAvailability">外貨システム使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="isGetSiwake">仕訳を取得するかどうか</param>
        protected void SetDefaultSiwakeTyouhyouRowItemAvailability(SiwakeTyouhyouRowItemAvailability rowItemAvailability, KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake)
        {
            rowItemAvailability.KihyouDateEnabled = this.KaisyaSyoriKikan.Syoriki.UseKihyoubi;
            rowItemAvailability.KihyouTantousyaEnabled = this.KaisyaSyoriKikan.Syoriki.UseKihyousya;
            rowItemAvailability.KihyouBumonEnabled = this.KaisyaSyoriKikan.Syoriki.UseKihyouBumon && this.KaisyaSyoriKikan.Syoriki.BumonInfo.Use;
            rowItemAvailability.SetHeaderFieldAndUniversalFieldEnabled(this.KaisyaSyoriKikan.Syoriki, isGetSiwake);
            if (isGetSiwake)
            {
                rowItemAvailability.BumonEnabled = this.KaisyaSyoriKikan.Syoriki.BumonInfo.Use;
                rowItemAvailability.TorihikisakiEnabled = this.KaisyaSyoriKikan.Syoriki.TorihikisakiInfo.Use;
                rowItemAvailability.EdabanEnabled = this.KaisyaSyoriKikan.Syoriki.EdabanInfo.Use;
                rowItemAvailability.SegmentEnabled = this.KaisyaSyoriKikan.Syoriki.SegmentInfo.Use;
                rowItemAvailability.ProjectEnabled = this.KaisyaSyoriKikan.Syoriki.ProjectInfo.Use;
                rowItemAvailability.KouziEnabled = this.KaisyaSyoriKikan.Syoriki.KouziInfo.Use;
                rowItemAvailability.KousyuEnabled = this.KaisyaSyoriKikan.Syoriki.KousyuInfo.Use;
                rowItemAvailability.SiharaiDateEnabled = this.KaisyaSyoriKikan.Syoriki.UseSiharaibi;
                rowItemAvailability.SiharaiKubunEnabled = this.KaisyaSyoriKikan.Syoriki.UseSiharaiKubun;
                rowItemAvailability.SiharaiKizituEnabled = this.KaisyaSyoriKikan.Syoriki.UseSiharaiKizitu;
                rowItemAvailability.KaisyuuDateEnabled = this.KaisyaSyoriKikan.Syoriki.UseKaisyuubi;
                rowItemAvailability.NyuukinKubunEnabled = this.KaisyaSyoriKikan.Syoriki.UseNyuukinKubun;
                rowItemAvailability.KaisyuuKizituEnabled = this.KaisyaSyoriKikan.Syoriki.UseKaisyuuKizitu;
                rowItemAvailability.KesikomiCodeEnabled = this.KaisyaSyoriKikan.Syoriki.KesikomiInfo.Use;
                rowItemAvailability.GaikaItemEnabled = gaikaSystemAvailability.Available && this.IsUseGaikaSystem;
                rowItemAvailability.GaikaKansanSiwakeFlagEnabled = gaikaSystemAvailability.Available && this.IsUseGaikaSystem;
                rowItemAvailability.BumonAsBumonSiteiEnabled = this.KaisyaSyoriKikan.Syoriki.BumonInfo.Use;
                rowItemAvailability.SyouhizeiItemEnabled = this.KaisyaSyoriKikan.Syoriki.UseSyouhizei;
            }
        }

        #endregion
    }
}
