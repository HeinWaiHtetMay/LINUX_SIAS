﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel;

    /// <summary>
    /// データスキャン仕訳帳票問合せパラメータ
    /// </summary>
    public class DataScanSiwakeTyouhyouQueryParameter : AbstractSiwakeTyouhyouQueryParameter, ISiwakeTyouhyouQueryParameter
    {
        private SiwakeTyouhyouOption siwakeTyouhyouOption;

        public DataScanSiwakeTyouhyouQueryParameter(
            Kaisya kaisya,
            IKaisyaSyoriKikan kaisyaSyoriKikan,
            BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext,
            UserAndSyorikiSecurityContext securityContext,
            SiwakeTyouhyouOption option,
            SiwakeTyouhyouQueryOption queryOption,
            bool isUseTanituSiwakeDenpyouSortOrder,
            bool isUseNotInputCheckOptionForGetSiwakeTyouhyou,
            Func<GaikaInitialSetting> getGaikaInitialSetting,
            string programId)
            : base(kaisya, kaisyaSyoriKikan, mitenkiDataQueryContext, getGaikaInitialSetting)
        {
            this.SecurityContext = securityContext;
            this.siwakeTyouhyouOption = option;
            this.SiwakeTyouhyouQueryOption = queryOption;
            this.IsUseTanituSiwakeDenpyouSortOrder = isUseTanituSiwakeDenpyouSortOrder;
            this.IsUseNotInputCheckOptionForGetSiwakeTyouhyou = isUseNotInputCheckOptionForGetSiwakeTyouhyou;
            this.ConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption = queryOption.DenpyouType == DenpyouTypeSearchType.HukugouType
                ? false
                : new SiwakeTyouhyouApplication(programId).ShouldConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption();
        }

        #region プロパティ

        /// <summary>
        /// セキュリティコンテキスト
        /// </summary>
        public UserAndSyorikiSecurityContext SecurityContext { get; private set; }

        /// <summary>
        /// 仕訳帳票問合せオプション
        /// </summary>
        public SiwakeTyouhyouQueryOption SiwakeTyouhyouQueryOption { get; private set; }

        /// <summary>
        /// 仕訳一覧時の伝票並び順を使用するかどうか
        /// </summary>
        public bool IsUseTanituSiwakeDenpyouSortOrder { get; private set; }

        /// <summary>
        /// 仕訳帳票取得時に、未入力チェックオプションを使用するかどうか
        /// </summary>
        public bool IsUseNotInputCheckOptionForGetSiwakeTyouhyou { get; private set; }

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定
        /// </summary>
        public SiwakeTyouhyouRowItemAvailability SiwakeTyouhyouRowItemAvailability { get; private set; }

        /// <summary>
        /// 必要な仕訳の行番号範囲
        /// </summary>
        public Range<int?> RequiredSiwakeRowNoRange { get; private set; }

        #region リポジトリに影響する設定

        /// <summary>
        /// 承認伝票の検索条件
        /// </summary>
        public SyouninDenpyouSearchCondition SyouninDenpyouSearchCondition => this.siwakeTyouhyouOption.SyouninDenpyouSearchCondition;

        /// <summary>
        /// 出力形式
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType => this.siwakeTyouhyouOption.SiwakeTyouhyouOutputType;

        /// <summary>
        /// ソート順
        /// </summary>
        public SiwakeTyouhyouSortOrder SortOrder => this.siwakeTyouhyouOption.SortOrder;

        /// <summary>
        /// 出力順序の設定
        /// </summary>
        public SiwakeTyouhyouOutputOrderSetting OutputOrderSetting => this.siwakeTyouhyouOption.OutputOrderSetting;

        /// <summary>
        /// 伝票単位時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder => this.siwakeTyouhyouOption.HukugouSiwakeDenpyouSortOrder;

        /// <summary>
        /// 仕訳一覧時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder => this.siwakeTyouhyouOption.TanituSiwakeDenpyouSortOrder;

        /// <summary>
        /// 仕訳の最大表示数
        /// </summary>
        public int SiwakeMaxDisplayCount => this.siwakeTyouhyouOption.SiwakeMaxDisplayCount;

        /// <summary>
        /// 貸借とも科目が表示できない仕訳を出力しないかどうか
        /// </summary>
        public bool IsNotOutputKamokuNotDisplayedSiwake => this.siwakeTyouhyouOption.IsNotOutputKamokuNotDisplayedSiwake;

        /// <summary>
        /// 伝票単位で通常出力する場合の出力内容の設定
        /// </summary>
        public SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting => this.siwakeTyouhyouOption.HukugouSiwakeNormalOutputSetting;

        /// <summary>
        /// 未入力チェックオプション
        /// </summary>
        public NotInputCheckOption NotInputCheckOption => this.siwakeTyouhyouOption.NotInputCheckOption;

        /// <summary>
        /// 摘要文字の分割形式
        /// </summary>
        public SiwakeTyouhyouTekiyouCharacterDivisionType TekiyouCharacterDivisionType => this.siwakeTyouhyouOption.TekiyouCharacterDivisionType;

        /// <summary>
        /// すべてのユーザーを対象に出力するかどうか（未使用）
        /// </summary>
        public bool IsAllUserOutputTarget => true;

        /// <summary>
        /// 未完伝票のみを検索するかどうか
        /// </summary>
        public bool IsMikanDenpyouOnlySearch => this.siwakeTyouhyouOption.IsMikanDenpyouOnlySearch;

        /// <summary>
        /// 伝票入力修正オプション（伝票入力修正設定）
        /// </summary>
        public DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption => this.siwakeTyouhyouOption.DenpyouInputAndSyuuseiOption;

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）
        /// </summary>
        public SiwakeOutputOption SiwakeOutputOption => this.siwakeTyouhyouOption.SiwakeOutputOption;

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// 仕訳帳票並び順のハッシュセットを作成します。
        /// </summary>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <returns>仕訳帳票並び順のハッシュセット</returns>
        public ISet<SiwakeTyouhyouOrderItem> CreateSiwakeTyouhyouOrderItemSet(bool isGetDenpyou)
        {
            //// 本支店展開用伝票取得時
            if (this.FromHonsitenTenkaiSiwake && isGetDenpyou)
            {
                return new HashSet<SiwakeTyouhyouOrderItem>() { SiwakeTyouhyouOrderItem.Dseq };
            }

            var sortOrderSet = new HashSet<SiwakeTyouhyouOrderItem>();

            if (this.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList)
            {
                //// 入力確定・チェックリスト
                switch (this.SortOrder)
                {
                    //// 伝票日付→受付番号
                    case SiwakeTyouhyouSortOrder.DenpyouDateAndUketukeNo:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouDate);
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        break;
                    //// 伝票番号→受付番号
                    case SiwakeTyouhyouSortOrder.DenpyouNoAndUketukeNo:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouNo);
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        break;
                    //// 受付番号
                    default:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        break;
                }

                sortOrderSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                if (!isGetDenpyou)
                {
                    //// 仕訳取得時のみ
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.GroupNo);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouPage);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.LineNo);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.Sseq);
                }

                return sortOrderSet;
            }
            else if (this.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.SyouninSyori)
            {
                //// 承認処理
                switch (this.OutputOrderSetting)
                {
                    //// 承認グループ／伝票入力者／受付番号順
                    case SiwakeTyouhyouOutputOrderSetting.SgnoAndDenpyouCreateUserAndUketukeNo:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.SyouninGroup);
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouCreateUser);
                        break;
                    //// 承認グループ／受付番号順
                    case SiwakeTyouhyouOutputOrderSetting.SgnoAndUketukeNo:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.SyouninGroup);
                        break;

                    //// 伝票日付／受付番号順
                    case SiwakeTyouhyouOutputOrderSetting.DenpyouDateAndUketukeNo:
                        sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouDate);
                        break;
                }

                sortOrderSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                sortOrderSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                if (!isGetDenpyou)
                {
                    //// 仕訳取得時のみ
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.GroupNo);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.DenpyouPage);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.LineNo);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei);
                    sortOrderSet.Add(SiwakeTyouhyouOrderItem.Sseq);
                }

                return sortOrderSet;
            }

            //// 上記以外
            if (this.IsUseTanituSiwakeDenpyouSortOrder)
            {
                //// 単一仕訳
                switch (this.TanituSiwakeDenpyouSortOrder)
                {
                    //// 仕訳SEQ順
                    case SiwakeTyouhyouDenpyouSortOrder.Sseq:
                        return new HashSet<SiwakeTyouhyouOrderItem>()
                        {
                            SiwakeTyouhyouOrderItem.ZaimuToMitenki,
                            SiwakeTyouhyouOrderItem.Sseq
                        };

                    //// 伝票日付順
                    case SiwakeTyouhyouDenpyouSortOrder.DenpyouDate:
                        return new HashSet<SiwakeTyouhyouOrderItem>()
                        {
                            SiwakeTyouhyouOrderItem.DenpyouDate,
                            SiwakeTyouhyouOrderItem.DenpyouNo,
                            SiwakeTyouhyouOrderItem.UketukeNo,
                            SiwakeTyouhyouOrderItem.ZaimuToMitenki,
                            SiwakeTyouhyouOrderItem.Dseq,
                            SiwakeTyouhyouOrderItem.GroupNo,
                            SiwakeTyouhyouOrderItem.DenpyouPage,
                            SiwakeTyouhyouOrderItem.LineNo,
                            SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei,
                            SiwakeTyouhyouOrderItem.Sseq
                        };

                    //// 伝票番号順
                    case SiwakeTyouhyouDenpyouSortOrder.DenpyouNo:
                        return new HashSet<SiwakeTyouhyouOrderItem>()
                        {
                            SiwakeTyouhyouOrderItem.DenpyouNo,
                            SiwakeTyouhyouOrderItem.DenpyouDate,
                            SiwakeTyouhyouOrderItem.UketukeNo,
                            SiwakeTyouhyouOrderItem.ZaimuToMitenki,
                            SiwakeTyouhyouOrderItem.Dseq,
                            SiwakeTyouhyouOrderItem.GroupNo,
                            SiwakeTyouhyouOrderItem.DenpyouPage,
                            SiwakeTyouhyouOrderItem.LineNo,
                            SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei,
                            SiwakeTyouhyouOrderItem.Sseq
                        };

                    //// 受付番号順
                    case SiwakeTyouhyouDenpyouSortOrder.UketukeNo:
                        return new HashSet<SiwakeTyouhyouOrderItem>()
                        {
                            SiwakeTyouhyouOrderItem.UketukeNo,
                            SiwakeTyouhyouOrderItem.ZaimuToMitenki,
                            SiwakeTyouhyouOrderItem.Dseq,
                            SiwakeTyouhyouOrderItem.GroupNo,
                            SiwakeTyouhyouOrderItem.DenpyouPage,
                            SiwakeTyouhyouOrderItem.LineNo,
                            SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei,
                            SiwakeTyouhyouOrderItem.Sseq
                        };

                    //// 伝票SEQ順
                    default:
                        return new HashSet<SiwakeTyouhyouOrderItem>()
                        {
                            SiwakeTyouhyouOrderItem.ZaimuToMitenki,
                            SiwakeTyouhyouOrderItem.Dseq,
                            SiwakeTyouhyouOrderItem.GroupNo,
                            SiwakeTyouhyouOrderItem.DenpyouPage,
                            SiwakeTyouhyouOrderItem.LineNo,
                            SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei,
                            SiwakeTyouhyouOrderItem.Sseq
                        };
                }
            }
            else
            {
                //// 複合仕訳
                var siwakeTyouhyouOrderItemSet = new HashSet<SiwakeTyouhyouOrderItem>();
                switch (this.HukugouSiwakeDenpyouSortOrder)
                {
                    //// 伝票日付順
                    case SiwakeTyouhyouDenpyouSortOrder.DenpyouDate:
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.DenpyouDate);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.DenpyouNo);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.ZaimuToMitenki);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                        break;

                    //// 伝票番号順
                    case SiwakeTyouhyouDenpyouSortOrder.DenpyouNo:
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.DenpyouNo);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.DenpyouDate);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.ZaimuToMitenki);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                        break;

                    //// 受付番号順
                    case SiwakeTyouhyouDenpyouSortOrder.UketukeNo:
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.UketukeNo);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.ZaimuToMitenki);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                        break;

                    //// 伝票SEQ順
                    default:
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.ZaimuToMitenki);
                        siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.Dseq);
                        break;
                }

                if (!isGetDenpyou)
                {
                    siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.GroupNo);
                    siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.DenpyouPage);
                    siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.LineNo);
                    siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.SiwakeTaisyakuZokusei);
                    siwakeTyouhyouOrderItemSet.Add(SiwakeTyouhyouOrderItem.Sseq);
                }

                return siwakeTyouhyouOrderItemSet;
            }
        }

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定を設定します。
        /// </summary>
        /// <param name="gaikaSystemAvailability">外貨システム使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="isGetSiwake">仕訳を取得するかどうか</param>
        public void SetSiwakeTyouhyouRowItemAvailability(KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake)
        {
            if (this.SiwakeTyouhyouRowItemAvailability == null || !isGetSiwake)
            {
                this.SiwakeTyouhyouRowItemAvailability = new SiwakeTyouhyouRowItemAvailability();
            }

            this.SetDefaultSiwakeTyouhyouRowItemAvailability(this.SiwakeTyouhyouRowItemAvailability, gaikaSystemAvailability, syouhizeiMaster, isGetSiwake);

            this.SiwakeTyouhyouRowItemAvailability.DenpyouItemEnabled = this.SiwakeTyouhyouQueryOption.SyoriType == SyoriType.CheckList;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled = this.MitenkiDataQueryContext.IncludesBusyobetuSiwake || this.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other;
            this.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled = this.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.Other;
            if (isGetSiwake)
            {
                this.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.ZeiKubunItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KamokuEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KingakuItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.GaikaKansanSiwakeFlagEnabled = false;
                this.SiwakeTyouhyouRowItemAvailability.SiwakeHusenEnabled = this.siwakeTyouhyouOption.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.TanituSiwake;
                this.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled = this.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.SyuukeiBumonKobetuSitei || this.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting == BumonTaniOutputSetting.SyuukeiBumonRangeSitei;
            }
        }

        /// <summary>
        /// 必要な仕訳の行番号範囲を設定します
        /// </summary>
        /// <param name="startNo">開始仕訳行番号</param>
        /// <param name="endNo">終了仕訳行番号</param>
        public void SetRequiredSiwakeRowNoRange(int? startNo, int? endNo) => this.RequiredSiwakeRowNoRange = new Range<int?>(startNo, endNo);

        /// <summary>
        /// 必要な仕訳の行番号範囲をクリアします
        /// </summary>
        public void ClearRequiredSiwakeRowNoRange() => this.RequiredSiwakeRowNoRange = null;

        /// <summary>
        /// オブジェクトを複製します（本支店展開用）。
        /// </summary>
        /// <param name="serviceResult"></param>
        /// <returns>複製済みのオブジェクト</returns>
        public override ISiwakeTyouhyouQueryParameter CloneForHonsitenTenkai(HonsitenTenkaiServiceResult serviceResult)
        {
            var queryParameter = this.MemberwiseClone() as DataScanSiwakeTyouhyouQueryParameter;
            queryParameter.IsUseTanituSiwakeDenpyouSortOrder = false;
            queryParameter.HonsitenTenkaiServiceResult = serviceResult;
            return queryParameter;
        }

        /// <summary>
        /// オブジェクトを複製します（複合仕訳帳票取得用）。
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <returns>複製済みのオブジェクト</returns>
        public ISiwakeTyouhyouQueryParameter CloneForHukugouSiwakeTyouhyou(ISiwakeTyouhyouDenpyouRow denpyou)
        {
            var queryParameter = this.MemberwiseClone() as DataScanSiwakeTyouhyouQueryParameter;
            queryParameter.SiwakeTyouhyouQueryOption = new SiwakeTyouhyouQueryOption(queryParameter.KaisyaSyoriKikan, queryParameter.SiwakeTyouhyouQueryOption.IsUseSecurity, queryParameter.SiwakeTyouhyouQueryOption.IsSokyuuApplication, queryParameter.SiwakeTyouhyouQueryOption.IsDenpyouUpdateUserTanituSitei)
            {
                IsOutputOnlyNotPrintedSiwake = queryParameter.SiwakeTyouhyouQueryOption.IsOutputOnlyNotPrintedSiwake,
                SyoriType = queryParameter.SiwakeTyouhyouQueryOption.SyoriType
            };
            queryParameter.SiwakeTyouhyouQueryOption.DkeiRangeValue.SetValue(denpyou.Dkei, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.DseqRangeValue.SetValue(denpyou.Dseq, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.DenpyouNoRangeValue.SetValue(denpyou.DenpyouNo, null, false, false);
            queryParameter.SiwakeTyouhyouQueryOption.UketukeNoRangeValue.SetValue(denpyou.UketukeNo, null, false, false);
            return queryParameter;
        }

        /// <summary>
        /// 伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうかを取得します。
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <returns>伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうか</returns>
        public bool GetHeaderFieldNotInputCheckForDenpyouSyuusei(int headerFieldNo)
        {
            switch (headerFieldNo)
            {
                case 1:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField1Inputted;
                case 2:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField2Inputted;
                case 3:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField3Inputted;
                case 4:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField4Inputted;
                case 5:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField5Inputted;
                case 6:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField6Inputted;
                case 7:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField7Inputted;
                case 8:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField8Inputted;
                case 9:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField9Inputted;
                case 10:
                    return this.DenpyouInputAndSyuuseiOption.CheckHeaderField10Inputted;
                default:
                    return false;
            }
        }

        #endregion
    }
}
