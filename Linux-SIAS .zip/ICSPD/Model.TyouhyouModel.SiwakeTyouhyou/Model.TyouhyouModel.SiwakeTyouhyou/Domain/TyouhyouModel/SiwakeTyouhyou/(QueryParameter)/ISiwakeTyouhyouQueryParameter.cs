﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 仕訳帳票問合せパラメータ
    /// </summary>
    public interface ISiwakeTyouhyouQueryParameter
    {
        #region プロパティ

        /// <summary>
        /// 内部決算期
        /// </summary>
        int Kesn { get; }

        /// <summary>
        /// 会社情報
        /// </summary>
        Kaisya Kaisya { get; }

        /// <summary>
        /// 会社処理期間
        /// </summary>
        IKaisyaSyoriKikan KaisyaSyoriKikan { get; }

        /// <summary>
        /// セキュリティコンテキスト
        /// </summary>
        UserAndSyorikiSecurityContext SecurityContext { get; }

        /// <summary>
        /// 未転記データ問合せコンテキスト
        /// </summary>
        BusyobetuTyouhyouMitenkiDataQueryContext MitenkiDataQueryContext { get; }

        /// <summary>
        /// 仕訳帳票問合せオプション
        /// </summary>
        SiwakeTyouhyouQueryOption SiwakeTyouhyouQueryOption { get; }

        /// <summary>
        /// 仕訳帳票行項目の使用可否設定
        /// </summary>
        SiwakeTyouhyouRowItemAvailability SiwakeTyouhyouRowItemAvailability { get; }

        /// <summary>
        /// 外貨システム使用有無
        /// </summary>
        bool IsUseGaikaSystem { get; }

        /// <summary>
        /// 仕訳一覧時の伝票並び順を使用するかどうか
        /// </summary>
        bool IsUseTanituSiwakeDenpyouSortOrder { get; }

        /// <summary>
        /// 仕訳帳票取得時に、未入力チェックオプションを使用するかどうか
        /// </summary>
        bool IsUseNotInputCheckOptionForGetSiwakeTyouhyou { get; }

        /// <summary>
        /// 本支店展開仕訳から帳票を取得するかどうか
        /// </summary>
        bool FromHonsitenTenkaiSiwake { get; }

        /// <summary>
        /// 本支店展開の処理結果
        /// </summary>
        HonsitenTenkaiServiceResult HonsitenTenkaiServiceResult { get; }

        /// <summary>
        /// 必要な仕訳の行番号範囲
        /// </summary>
        Range<int?> RequiredSiwakeRowNoRange { get; }

        #region リポジトリに影響する設定

        /// <summary>
        /// 承認伝票の検索条件
        /// </summary>
        SyouninDenpyouSearchCondition SyouninDenpyouSearchCondition { get; }

        /// <summary>
        /// 出力形式
        /// </summary>
        SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; }

        /// <summary>
        /// ソート順
        /// </summary>
        SiwakeTyouhyouSortOrder SortOrder { get; }

        /// <summary>
        /// 出力順序の設定
        /// </summary>
        SiwakeTyouhyouOutputOrderSetting OutputOrderSetting { get; }

        /// <summary>
        /// 伝票単位時の伝票並び順
        /// </summary>
        SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder { get; }

        /// <summary>
        /// 仕訳一覧時の伝票並び順
        /// </summary>
        SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder { get; }

        /// <summary>
        /// 仕訳の最大表示数
        /// </summary>
        int SiwakeMaxDisplayCount { get; }

        /// <summary>
        /// 貸借とも科目が表示できない仕訳を出力しないかどうか
        /// </summary>
        bool IsNotOutputKamokuNotDisplayedSiwake { get; }

        /// <summary>
        /// 伝票単位で通常出力する場合の出力内容の設定
        /// </summary>
        SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting { get; }

        /// <summary>
        /// 未入力チェックオプション
        /// </summary>
        NotInputCheckOption NotInputCheckOption { get; }

        /// <summary>
        /// 摘要文字の分割形式
        /// </summary>
        SiwakeTyouhyouTekiyouCharacterDivisionType TekiyouCharacterDivisionType { get; }

        /// <summary>
        /// すべてのユーザーを対象に出力するかどうか
        /// </summary>
        bool IsAllUserOutputTarget { get; }

        /// <summary>
        /// 未完伝票のみを検索するかどうか
        /// </summary>
        bool IsMikanDenpyouOnlySearch { get; }

        /// <summary>
        /// 伝票入力修正オプション（伝票入力修正設定）
        /// </summary>
        DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption { get; }

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）
        /// </summary>
        SiwakeOutputOption SiwakeOutputOption { get; }

        /// <summary>
        /// 仕訳出力オプション（仕訳の出力設定）により、自動諸口の入力コード・名称を変換するかどうか
        /// </summary>
        bool ConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption { get; set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// 仕訳帳票並び順のハッシュセットを取得します。
        /// </summary>
        /// <param name="isGetDenpyou">伝票を取得するかどうか</param>
        /// <returns>仕訳帳票並び順のハッシュセット</returns>
        ISet<SiwakeTyouhyouOrderItem> CreateSiwakeTyouhyouOrderItemSet(bool isGetDenpyou);

        /// <summary>
        /// 仕訳帳票行項目を設定します。
        /// </summary>
        /// <param name="gaikaSystemAvailability">外貨システム使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <param name="isGetSiwake">仕訳を取得するかどうか</param>
        void SetSiwakeTyouhyouRowItemAvailability(KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake);

        /// <summary>
        /// 必要な仕訳の行番号範囲を設定します
        /// </summary>
        /// <param name="startNo">開始仕訳行番号</param>
        /// <param name="endNo">終了仕訳行番号</param>
        void SetRequiredSiwakeRowNoRange(int? startNo, int? endNo);

        /// <summary>
        /// 必要な仕訳の行番号範囲をクリアします
        /// </summary>
        void ClearRequiredSiwakeRowNoRange();

        /// <summary>
        /// オブジェクトを複製します（本支店展開用）。
        /// </summary>
        /// <param name="serviceResult"></param>
        /// <returns>複製済みのオブジェクト</returns>
        ISiwakeTyouhyouQueryParameter CloneForHonsitenTenkai(HonsitenTenkaiServiceResult serviceResult);

        /// <summary>
        /// オブジェクトを複製します（複合仕訳帳票取得用）。
        /// </summary>
        /// <param name="denpyou">伝票</param>
        /// <returns>複製済みのオブジェクト</returns>
        ISiwakeTyouhyouQueryParameter CloneForHukugouSiwakeTyouhyou(ISiwakeTyouhyouDenpyouRow denpyou);

        ISiwakeTyouhyouQueryParameter CloneAsShallowCopy();

        /// <summary>
        /// 伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうかを取得します。
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <returns>伝票修正に関して、ヘッダーフィールド未入力チェックをおこなうかどうか</returns>
        bool GetHeaderFieldNotInputCheckForDenpyouSyuusei(int headerFieldNo);

        #endregion
    }
}
