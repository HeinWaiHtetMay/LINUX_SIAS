﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 摘要（貸借別出力用）出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType
    {
        /// <summary>
        /// 上下に全角30文字ずつ
        /// </summary>
        FullWidth30CharsVertical = 1,

        /// <summary>
        /// 上下に全角20文字＋10文字（2行）ずつ
        /// </summary>
        FullWidth20And10CharsVertical = 2,

        /// <summary>
        /// 上下に全角15文字＋15文字（2行）ずつ
        /// </summary>
        FullWidth15And15CharsVertical = 3,

        /// <summary>
        /// 左右に全角30文字ずつ
        /// </summary>
        FullWidth30CharsHorizontal = 11,

        /// <summary>
        /// 左右に全角20文字＋10文字（2行）ずつ
        /// </summary>
        FullWidth20And10CharsHorizontal = 12,

        /// <summary>
        /// 左右に全角15文字＋15文字（2行）ずつ
        /// </summary>
        FullWidth15And15CharsHorizontal = 13,
    }
}
