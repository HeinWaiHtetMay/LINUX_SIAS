﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// マスター出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutMasterOutputType
    {
        /// <summary>
        /// コード
        /// </summary>
        Code = 0,

        /// <summary>
        /// 名称
        /// </summary>
        Name = 1
    }
}
