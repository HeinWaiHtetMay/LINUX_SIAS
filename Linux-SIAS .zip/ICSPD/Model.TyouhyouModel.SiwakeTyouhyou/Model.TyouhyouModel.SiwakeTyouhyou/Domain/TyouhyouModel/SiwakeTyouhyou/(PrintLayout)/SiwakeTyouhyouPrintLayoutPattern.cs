﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.PrintDocumentModel;

    /// <summary>
    /// 仕訳帳票印刷レイアウトパターン（テーブル名：chklayまたはsnchklay）
    /// </summary>
    public class SiwakeTyouhyouPrintLayoutPattern : IMasterData, ISiwakeTyouhyouPrintLayoutPattern
    {
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other, MasterCodeType.Numeric, 2);

        public SiwakeTyouhyouPrintLayoutPattern(SiwakeTyouhyouOutputType outputType, int layoutNo)
        {
            this.SiwakeTyouhyouOutputType = outputType;
            this.LayoutNo = layoutNo;
        }

        #region implements IMasterData

        public string Code => this.LayoutNo.ToString("D2");

        public string Name => this.Comment;

        #endregion

        #region public properties

        /// <summary>
        /// 出力形式（カラム名：laytyp）
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; private set; }

        /// <summary>
        /// レイアウトNo（カラム名：layno）
        /// </summary>
        public int LayoutNo { get; private set; }

        /// <summary>
        /// コメント（カラム名：cmnt）
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// タイトル名（カラム名：titl）
        /// </summary>
        public string TitleName { get; set; }

        /// <summary>
        /// 用紙サイズ（カラム名：psize及びport）
        /// </summary>
        public IcspPaperSize PrintPaperSize { get; set; }

        /// <summary>
        /// 左マージン（カラム名：lmgn）
        /// </summary>
        public int LeftMargin { get; set; }

        /// <summary>
        /// 上マージン（カラム名：tmgn）
        /// </summary>
        public int TopMargin { get; set; }

        /// <summary>
        /// 1行の高さ（カラム名：rowh）
        /// </summary>
        public int RowHeight { get; set; }

        /// <summary>
        /// 1ページの行数（カラム名：mrow）
        /// </summary>
        public int PageRowCount { get; set; }

        /// <summary>
        /// 項目タイトル行数（カラム名：hdrow）
        /// </summary>
        public int ItemTitleRowCount { get; set; }

        /// <summary>
        /// 伝票ヘッダー行数（カラム名：dhrow）
        /// </summary>
        public int DenpyouHeaderRowCount { get; set; }

        /// <summary>
        /// 仕訳明細行数（カラム名：ddrow）
        /// </summary>
        public int SiwakeMeisaiRowCount { get; set; }

        /// <summary>
        /// 伝票区切り（カラム名：dline）
        /// </summary>
        public DenpyouAndSiwakeSectionLine DenpyouSectionLine { get; set; }

        /// <summary>
        /// 仕訳区切り（カラム名：sline）
        /// </summary>
        public DenpyouAndSiwakeSectionLine SiwakeSectionLine { get; set; }

        /// <summary>
        /// フォントサイズ（カラム名：fsize）
        /// </summary>
        public float FontSize { get; set; }

        /// <summary>
        /// 仕訳帳票印刷レイアウトパターンタイトル項目リスト
        /// </summary>
        public IList<SiwakeTyouhyouPrintLayoutPatternTitleItem> PrintLayoutPatternTitleItemList { get; set; } = new List<SiwakeTyouhyouPrintLayoutPatternTitleItem>();

        /// <summary>
        /// 仕訳帳票印刷レイアウトパターン項目リスト
        /// </summary>
        public IList<SiwakeTyouhyouPrintLayoutPatternItem> PrintLayoutPatternItemList { get; set; } = new List<SiwakeTyouhyouPrintLayoutPatternItem>();

        #endregion
    }
}
