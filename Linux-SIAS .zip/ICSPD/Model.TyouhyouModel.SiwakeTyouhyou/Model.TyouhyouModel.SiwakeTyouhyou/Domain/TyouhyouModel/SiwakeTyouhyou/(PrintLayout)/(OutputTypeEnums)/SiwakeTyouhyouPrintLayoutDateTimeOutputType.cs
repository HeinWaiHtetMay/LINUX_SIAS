﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 日付出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutDateTimeOutputType
    {
        /// <summary>
        /// 年月日
        /// </summary>
        YearAndMonthAndDay = 0,

        /// <summary>
        /// 月日
        /// </summary>
        MonthAndDay = 1
    }
}
