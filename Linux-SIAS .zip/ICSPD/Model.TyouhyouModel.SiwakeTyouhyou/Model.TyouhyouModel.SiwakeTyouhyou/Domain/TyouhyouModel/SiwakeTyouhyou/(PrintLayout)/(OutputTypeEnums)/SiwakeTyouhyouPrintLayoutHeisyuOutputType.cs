﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 幣種出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutHeisyuOutputType
    {
        /// <summary>
        /// 通貨コード
        /// </summary>
        HeisyuCode = 0,

        /// <summary>
        /// 単位名称
        /// </summary>
        HeisyuName = 1,

        /// <summary>
        /// 単位名称＋国名
        /// </summary>
        HeisyuNameAndHeisyuUsingCountryName = 2
    }
}
