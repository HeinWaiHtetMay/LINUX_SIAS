﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 伝票及び仕訳区切り
    /// </summary>
    public enum DenpyouAndSiwakeSectionLine
    {
        /// <summary>
        /// なし
        /// </summary>
        None = 0,

        /// <summary>
        /// 実線
        /// </summary>
        SolidLine = 1,

        /// <summary>
        /// 点線
        /// </summary>
        DottedLine = 2,

        /// <summary>
        /// 太線
        /// </summary>
        ThickLine = 3
    }

    /// <summary>
    /// 項目区分
    /// </summary>
    public enum ItemKubun
    {
        /// <summary>
        /// 伝票ヘッダー
        /// </summary>
        DenpyouHeader = 0,

        /// <summary>
        /// 仕訳データ
        /// </summary>
        SiwakeData = 1,
    }

    /// <summary>
    /// 項目属性
    /// </summary>
    public enum ItemTaisyakuZokusei
    {
        /// <summary>
        /// 共通
        /// </summary>
        Common = 0,

        /// <summary>
        /// 借方
        /// </summary>
        Karikata = 1,

        /// <summary>
        /// 貸方
        /// </summary>
        Kasikata = 2
    }

    /// <summary>
    /// 単一仕訳帳票用項目ID
    /// </summary>
    public enum TanituSiwakeTyouhyouItemId
    {
        UketukeNo = 1,
        DenpyouDate = 2,
        DenpyouNo = 3,
        KarikataBumon = 4,
        KarikataTorihikisaki = 5,
        KarikataKamoku = 6,
        KarikataEdaban = 7,
        KarikataKouzi = 8,
        KarikataKousyu = 9,
        KarikataProject = 10,
        KarikataSegment = 11,
        KarikataUniversalField01 = 12,
        KarikataUniversalField02 = 13,
        KarikataUniversalField03 = 14,
        Tekiyou = 15,
        KasikataBumon = 17,
        KasikataTorihikisaki = 18,
        KasikataKamoku = 19,
        KasikataEdaban = 20,
        KasikataKouzi = 21,
        KasikataKousyu = 22,
        KasikataProject = 23,
        KasikataSegment = 24,
        KasikataUniversalField01 = 25,
        KasikataUniversalField02 = 26,
        KasikataUniversalField03 = 27,
        Kingaku = 28,
        TaikaKingaku = 29,
        ZeikomiKingaku = 30,
        KarikataZeiKubun = 31,
        KasikataZeiKubun = 32,
        SyouhizeiTaisyouKamoku = 33,
        SyouhizeiTaisyouKamokuSyouhizeiKubun = 34,
        KihyouDate = 35,
        KihyouBumon = 36,
        KihyouTantousya = 37,
        SiwakeCreateDate = 38,
        SiwakeCreateUser = 39,
        SiwakeUpdateDate = 40,
        SiwakeUpdateUser = 41,
        Sseq = 42,
        Kesikomi = 44,
        SiharaiDate = 45,
        SiharaiKubun = 46,
        SiharaiKizitu = 47,
        KaisyuuDate = 48,
        NyuukinKubun = 49,
        KaisyuuKizitu = 50,
        SyouninStatus = 51,
        GaikaKingaku = 52,
        Heisyu = 53,
        Rate = 54,
        GaikaTaikaKingaku = 55,
        GaikaZeikomiKingaku = 56,
        DenpyouTabaCode = 57,
        Dseq = 59,
        DenpyouCreateDate = 60,
        DenpyouCreateUser = 61,
        DenpyouUpdateDate = 62,
        DenpyouUpdateUser = 63,
        HeaderField01 = 64,
        HeaderField02 = 65,
        HeaderField03 = 66,
        HeaderField04 = 67,
        HeaderField05 = 68,
        HeaderField06 = 69,
        HeaderField07 = 70,
        HeaderField08 = 71,
        HeaderField09 = 72,
        HeaderField10 = 73,
        KarikataUniversalField04 = 74,
        KarikataUniversalField05 = 75,
        KarikataUniversalField06 = 76,
        KarikataUniversalField07 = 77,
        KarikataUniversalField08 = 78,
        KarikataUniversalField09 = 79,
        KarikataUniversalField10 = 80,
        KarikataUniversalField11 = 81,
        KarikataUniversalField12 = 82,
        KarikataUniversalField13 = 83,
        KarikataUniversalField14 = 84,
        KarikataUniversalField15 = 85,
        KarikataUniversalField16 = 86,
        KarikataUniversalField17 = 88,
        KarikataUniversalField18 = 89,
        KarikataUniversalField19 = 90,
        KarikataUniversalField20 = 91,
        KasikataUniversalField04 = 92,
        KasikataUniversalField05 = 93,
        KasikataUniversalField06 = 94,
        KasikataUniversalField07 = 95,
        KasikataUniversalField08 = 96,
        KasikataUniversalField09 = 97,
        KasikataUniversalField10 = 98,
        KasikataUniversalField11 = 99,
        KasikataUniversalField12 = 100,
        KasikataUniversalField13 = 101,
        KasikataUniversalField14 = 102,
        KasikataUniversalField15 = 103,
        KasikataUniversalField16 = 104,
        KasikataUniversalField17 = 105,
        KasikataUniversalField18 = 106,
        KasikataUniversalField19 = 107,
        KasikataUniversalField20 = 108,
        TekiyouForTaisyakubetuOutput = 109,
        LineNo = 110,
        KarikataTekiyouCode = 111,
        KasikataTekiyouCode = 112
    }

    /// <summary>
    /// 複合仕訳帳票用項目ID
    /// </summary>
    public enum HukugouSiwakeTyouhyouItemId
    {
        Bumon = 2,
        Torihikisaki = 3,
        Kamoku = 4,
        Edaban = 5,
        Kouzi = 6,
        Kousyu = 7,
        Project = 8,
        Segment = 9,
        UniversalField01 = 10,
        UniversalField02 = 11,
        UniversalField03 = 12,
        Tekiyou = 13,
        TekiyouCode = 14,
        Kingaku = 15,
        TaikaKingaku = 16,
        ZeikomiKingaku = 17,
        KazeiKubun = 18,
        SyouhizeiTaisyouKamoku = 19,
        SyouhizeiTaisyouKamokuSyouhizeiKubun = 20,
        SiwakeCreateDate = 24,
        SiwakeCreateUser = 25,
        SiwakeUpdateDate = 26,
        SiwakeUpdateUser = 27,
        Sseq = 28,
        Kesikomi = 30,
        SiharaiDate = 31,
        SiharaiKubun = 32,
        SiharaiKizitu = 33,
        KaisyuuDate = 34,
        NyuukinKubun = 35,
        KaisyuuKizitu = 36,
        GaikaKingaku = 38,
        Heisyu = 39,
        Rate = 40,
        GaikaTaikaKingaku = 41,
        GaikaZeikomiKingaku = 42,
        UniversalField04 = 44,
        UniversalField05 = 45,
        UniversalField06 = 46,
        UniversalField07 = 47,
        UniversalField08 = 48,
        UniversalField09 = 49,
        UniversalField10 = 50,
        UniversalField11 = 51,
        UniversalField12 = 52,
        UniversalField13 = 53,
        UniversalField14 = 54,
        UniversalField15 = 55,
        UniversalField16 = 56,
        UniversalField17 = 57,
        UniversalField18 = 58,
        UniversalField19 = 59,
        UniversalField20 = 60,
        TekiyouForTaisyakubetuOutput = 61,
        LineNo = 62
    }

    /// <summary>
    /// 伝票ヘッダー用項目ID
    /// </summary>
    public enum DenpyouHeaderItemId
    {
        UketukeNo = 1,
        DenpyouDate = 2,
        DenpyouNo = 3,
        KihyouDate = 4,
        KihyouBumon = 5,
        KihyouTantousya = 6,
        DenpyouCreateDate = 7,
        DenpyouCreateUser = 8,
        DenpyouUpdateDate = 9,
        DenpyouUpdateUser = 10,
        SyouninStatus = 11,
        DenpyouTabaCode = 12,
        Dseq = 13,
        HeaderField01 = 14,
        HeaderField02 = 15,
        HeaderField03 = 16,
        HeaderField04 = 17,
        HeaderField05 = 18,
        HeaderField06 = 19,
        HeaderField07 = 20,
        HeaderField08 = 21,
        HeaderField09 = 22,
        HeaderField10 = 23,
    }
}
