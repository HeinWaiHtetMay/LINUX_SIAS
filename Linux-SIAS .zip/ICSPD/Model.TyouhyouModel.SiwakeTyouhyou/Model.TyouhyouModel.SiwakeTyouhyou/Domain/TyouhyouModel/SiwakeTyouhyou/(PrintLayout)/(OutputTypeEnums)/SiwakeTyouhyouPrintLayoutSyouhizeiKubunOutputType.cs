﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 税区分出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutSyouhizeiKubunOutputType
    {
        /// <summary>
        /// 消費税区分名称
        /// </summary>
        Name = 0,

        /// <summary>
        /// 税率＋課税区分
        /// </summary>
        SyouhizeirituAndKazeiKubun = 1,

        /// <summary>
        /// 業種・仕入区分
        /// </summary>
        GyousyuAndSiireKubun = 2,

        /// <summary>
        /// 消費税区分略称
        /// </summary>
        ShortName = 3
    }
}
