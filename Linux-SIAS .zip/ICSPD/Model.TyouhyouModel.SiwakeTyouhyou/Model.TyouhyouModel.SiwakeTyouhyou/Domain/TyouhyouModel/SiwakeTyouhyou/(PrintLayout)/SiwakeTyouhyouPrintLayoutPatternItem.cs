﻿using Icsp.Open21.Drawing.Printing;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票印刷レイアウトパターン項目（テーブル名：chklaydまたはsnchklayd）
    /// </summary>
    public class SiwakeTyouhyouPrintLayoutPatternItem
    {
        public SiwakeTyouhyouPrintLayoutPatternItem(SiwakeTyouhyouOutputType outputType, int layoutNo, ItemKubun itemKubun, int row, int itemSequence)
        {
            this.SiwakeTyouhyouOutputType = outputType;
            this.LayoutNo = layoutNo;
            this.ItemKubun = itemKubun;
            this.Row = row - 1;
            this.ItemSequence = itemSequence;
        }

        /// <summary>
        /// 出力形式（カラム名：laytyp）
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; private set; }

        /// <summary>
        /// レイアウトNo（カラム名：layno）
        /// </summary>
        public int LayoutNo { get; private set; }

        /// <summary>
        /// 項目区分（カラム名：ctype）
        /// </summary>
        public ItemKubun ItemKubun { get; private set; }

        /// <summary>
        /// 行（カラム名：layrow）
        /// </summary>
        public int Row { get; private set; }

        /// <summary>
        /// 項目SEQ（カラム名：cseq）
        /// </summary>
        public int ItemSequence { get; private set; }

        /// <summary>
        /// 項目属性（カラム名：catt）
        /// </summary>
        public ItemTaisyakuZokusei ItemTaisyakuZokusei { get; set; }

        /// <summary>
        /// 単一仕訳帳票用項目ID（カラム名：colid）
        /// </summary>
        public TanituSiwakeTyouhyouItemId TanituSiwakeTyouhyouItemId { get; set; }

        /// <summary>
        /// 複合仕訳帳票用項目ID（カラム名：colid）
        /// </summary>
        public HukugouSiwakeTyouhyouItemId HukugouSiwakeTyouhyouItemId { get; set; }

        /// <summary>
        /// 伝票ヘッダー用項目ID（カラム名：colid）
        /// </summary>
        public DenpyouHeaderItemId DenpyouHeaderItemId { get; set; }

        /// <summary>
        /// 開始位置（左）（カラム名：posx）
        /// </summary>
        public int LeftStartPosition { get; set; }

        /// <summary>
        /// 開始位置（上）（カラム名：posy）
        /// </summary>
        public int TopStartPosition { get; set; }

        /// <summary>
        /// 幅（カラム名：cwid）
        /// </summary>
        public int Width { get; set; }

        /// <summary>
        /// フォントサイズ（カラム名：fsize）
        /// </summary>
        public int FontSize { get; set; }

        /// <summary>
        /// 税区分出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutSyouhizeiKubunOutputType SyouhizeiKubunOutputType { get; set; }

        /// <summary>
        /// 日付出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutDateTimeOutputType DateTimeOutputType { get; set; }

        /// <summary>
        /// マスター出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutMasterOutputType MasterOutputType { get; set; }

        /// <summary>
        /// 摘要出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutTekiyouOutputType TekiyouOutputType { get; set; }

        /// <summary>
        /// 摘要（貸借別出力用）出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType TaisyakubetuTekiyouOutputType { get; set; }

        /// <summary>
        /// 幣種出力形式（カラム名：frmt）
        /// </summary>
        public SiwakeTyouhyouPrintLayoutHeisyuOutputType HeisyuOutputType { get; set; }

        /// <summary>
        /// 位置寄せ（カラム名：align）
        /// </summary>
        public PrintTextAlignment Alignment { get; set; }

        /// <summary>
        /// 文字列を半角文字にするかどうか（カラム名：mwid）
        /// </summary>
        public bool IsChangeHalfwidthCharacter { get; set; }

        /// <summary>
        /// 税区分出力形式を使用するかどうか
        /// </summary>
        public bool UseSyouhizeiKubunOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake ? this.HukugouSiwakeTyouhyouItemId.IsSyouhizeiKubun() : this.TanituSiwakeTyouhyouItemId.IsSyouhizeiKubun();

        /// <summary>
        /// 日付出力形式を使用するかどうか
        /// </summary>
        public bool UseDateTimeOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake
            ? (this.ItemKubun == ItemKubun.DenpyouHeader ? this.DenpyouHeaderItemId.IsDateTimeType() : this.HukugouSiwakeTyouhyouItemId.IsDateTimeType())
            : this.TanituSiwakeTyouhyouItemId.IsDateTimeType();

        /// <summary>
        /// マスター出力形式を使用するかどうか
        /// </summary>
        public bool UseMasterOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake
            ? (this.ItemKubun == ItemKubun.DenpyouHeader ? this.DenpyouHeaderItemId.IsMasterType() : this.HukugouSiwakeTyouhyouItemId.IsMasterType())
            : this.TanituSiwakeTyouhyouItemId.IsMasterType();

        /// <summary>
        /// 摘要出力形式を使用するかどうか
        /// </summary>
        public bool UseTekiyouOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake ? this.HukugouSiwakeTyouhyouItemId == HukugouSiwakeTyouhyouItemId.Tekiyou : this.TanituSiwakeTyouhyouItemId == TanituSiwakeTyouhyouItemId.Tekiyou;

        /// <summary>
        /// 摘要（貸借別出力用）出力形式を使用するかどうか
        /// </summary>
        public bool UseTaisyakubetuTekiyouOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake ? this.HukugouSiwakeTyouhyouItemId == HukugouSiwakeTyouhyouItemId.TekiyouForTaisyakubetuOutput : this.TanituSiwakeTyouhyouItemId == TanituSiwakeTyouhyouItemId.TekiyouForTaisyakubetuOutput;

        /// <summary>
        /// 幣種出力形式を使用するかどうか
        /// </summary>
        public bool UseHeisyuOutputType => this.SiwakeTyouhyouOutputType == SiwakeTyouhyouOutputType.HukugouSiwake ? this.HukugouSiwakeTyouhyouItemId == HukugouSiwakeTyouhyouItemId.Heisyu : this.TanituSiwakeTyouhyouItemId == TanituSiwakeTyouhyouItemId.Heisyu;
    }
}
