﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputTypeExtension
    {
        /// <summary>
        /// 1行目の全角文字数を取得します
        /// </summary>
        /// <param name="value">摘要（貸借別出力用）出力形式</param>
        /// <returns>1行目の全角文字数</returns>
        public static int GetFirstLineFullWidthCharCount(this SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType value)
        {
            switch (value)
            {
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth15And15CharsHorizontal:
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth15And15CharsVertical:
                    return 15;
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth20And10CharsHorizontal:
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth20And10CharsVertical:
                    return 20;
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth30CharsHorizontal:
                case SiwakeTyouhyouPrintLayoutTaisyakubetuTekiyouOutputType.FullWidth30CharsVertical:
                    return 30;
                default:
                    return 0;
            }
        }
    }
}
