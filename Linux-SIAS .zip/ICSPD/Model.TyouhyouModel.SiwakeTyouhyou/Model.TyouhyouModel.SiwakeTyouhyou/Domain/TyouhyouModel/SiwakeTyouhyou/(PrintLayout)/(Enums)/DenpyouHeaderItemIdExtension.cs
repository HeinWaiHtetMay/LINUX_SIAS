﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class DenpyouHeaderItemIdExtension
    {
        /// <summary>
        /// マスターかどうかを判定します。
        /// </summary>
        /// <param name="value">伝票ヘッダー用項目ID</param>
        /// <returns>マスターかどうか</returns>
        public static bool IsMasterType(this DenpyouHeaderItemId value)
        {
            switch (value)
            {
                case DenpyouHeaderItemId.DenpyouCreateUser:
                case DenpyouHeaderItemId.DenpyouUpdateUser:
                case DenpyouHeaderItemId.KihyouBumon:
                case DenpyouHeaderItemId.KihyouTantousya:
                case DenpyouHeaderItemId.HeaderField01:
                case DenpyouHeaderItemId.HeaderField02:
                case DenpyouHeaderItemId.HeaderField03:
                case DenpyouHeaderItemId.HeaderField04:
                case DenpyouHeaderItemId.HeaderField05:
                case DenpyouHeaderItemId.HeaderField06:
                case DenpyouHeaderItemId.HeaderField07:
                case DenpyouHeaderItemId.HeaderField08:
                case DenpyouHeaderItemId.HeaderField09:
                case DenpyouHeaderItemId.HeaderField10:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 日付かどうかを判定します。
        /// </summary>
        /// <param name="value">伝票ヘッダー用項目ID</param>
        /// <returns>日付かどうか</returns>
        public static bool IsDateTimeType(this DenpyouHeaderItemId value)
        {
            switch (value)
            {
                case DenpyouHeaderItemId.DenpyouDate:
                case DenpyouHeaderItemId.DenpyouCreateDate:
                case DenpyouHeaderItemId.DenpyouUpdateDate:
                case DenpyouHeaderItemId.KihyouDate:
                    return true;
                default:
                    return false;
            }
        }
    }
}
