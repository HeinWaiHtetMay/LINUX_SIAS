﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class TanituSiwakeTyouhyouItemIdExtension
    {
        /// <summary>
        /// マスターかどうかを判定します。
        /// </summary>
        /// <param name="value">単一仕訳帳票用項目ID</param>
        /// <returns>マスターかどうか</returns>
        public static bool IsMasterType(this TanituSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case TanituSiwakeTyouhyouItemId.KarikataBumon:
                case TanituSiwakeTyouhyouItemId.KarikataTorihikisaki:
                case TanituSiwakeTyouhyouItemId.KarikataKamoku:
                case TanituSiwakeTyouhyouItemId.KarikataEdaban:
                case TanituSiwakeTyouhyouItemId.KarikataKouzi:
                case TanituSiwakeTyouhyouItemId.KarikataKousyu:
                case TanituSiwakeTyouhyouItemId.KarikataProject:
                case TanituSiwakeTyouhyouItemId.KarikataSegment:
                case TanituSiwakeTyouhyouItemId.KarikataTekiyouCode:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField01:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField02:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField03:
                case TanituSiwakeTyouhyouItemId.KasikataBumon:
                case TanituSiwakeTyouhyouItemId.KasikataTorihikisaki:
                case TanituSiwakeTyouhyouItemId.KasikataKamoku:
                case TanituSiwakeTyouhyouItemId.KasikataEdaban:
                case TanituSiwakeTyouhyouItemId.KasikataKouzi:
                case TanituSiwakeTyouhyouItemId.KasikataKousyu:
                case TanituSiwakeTyouhyouItemId.KasikataProject:
                case TanituSiwakeTyouhyouItemId.KasikataSegment:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField01:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField02:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField03:
                case TanituSiwakeTyouhyouItemId.KasikataTekiyouCode:
                case TanituSiwakeTyouhyouItemId.SyouhizeiTaisyouKamoku:
                case TanituSiwakeTyouhyouItemId.KihyouBumon:
                case TanituSiwakeTyouhyouItemId.KihyouTantousya:
                case TanituSiwakeTyouhyouItemId.DenpyouCreateUser:
                case TanituSiwakeTyouhyouItemId.DenpyouUpdateUser:
                case TanituSiwakeTyouhyouItemId.SiwakeCreateUser:
                case TanituSiwakeTyouhyouItemId.SiwakeUpdateUser:
                case TanituSiwakeTyouhyouItemId.HeaderField01:
                case TanituSiwakeTyouhyouItemId.HeaderField02:
                case TanituSiwakeTyouhyouItemId.HeaderField03:
                case TanituSiwakeTyouhyouItemId.HeaderField04:
                case TanituSiwakeTyouhyouItemId.HeaderField05:
                case TanituSiwakeTyouhyouItemId.HeaderField06:
                case TanituSiwakeTyouhyouItemId.HeaderField07:
                case TanituSiwakeTyouhyouItemId.HeaderField08:
                case TanituSiwakeTyouhyouItemId.HeaderField09:
                case TanituSiwakeTyouhyouItemId.HeaderField10:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField04:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField05:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField06:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField07:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField08:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField09:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField10:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField11:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField12:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField13:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField14:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField15:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField16:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField17:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField18:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField19:
                case TanituSiwakeTyouhyouItemId.KarikataUniversalField20:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField04:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField05:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField06:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField07:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField08:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField09:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField10:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField11:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField12:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField13:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField14:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField15:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField16:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField17:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField18:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField19:
                case TanituSiwakeTyouhyouItemId.KasikataUniversalField20:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 税区分かどうかを判定します。
        /// </summary>
        /// <param name="value">単一仕訳帳票用項目ID</param>
        /// <returns>税区分かどうか</returns>
        public static bool IsSyouhizeiKubun(this TanituSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case TanituSiwakeTyouhyouItemId.KarikataZeiKubun:
                case TanituSiwakeTyouhyouItemId.KasikataZeiKubun:
                case TanituSiwakeTyouhyouItemId.SyouhizeiTaisyouKamokuSyouhizeiKubun:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 日付かどうかを判定します。
        /// </summary>
        /// <param name="value">単一仕訳帳票用項目ID</param>
        /// <returns>日付かどうか</returns>
        public static bool IsDateTimeType(this TanituSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case TanituSiwakeTyouhyouItemId.DenpyouDate:
                case TanituSiwakeTyouhyouItemId.KihyouDate:
                case TanituSiwakeTyouhyouItemId.SiwakeCreateDate:
                case TanituSiwakeTyouhyouItemId.SiwakeUpdateDate:
                case TanituSiwakeTyouhyouItemId.SiharaiDate:
                case TanituSiwakeTyouhyouItemId.KaisyuuDate:
                    return true;
                default:
                    return false;
            }
        }
    }
}
