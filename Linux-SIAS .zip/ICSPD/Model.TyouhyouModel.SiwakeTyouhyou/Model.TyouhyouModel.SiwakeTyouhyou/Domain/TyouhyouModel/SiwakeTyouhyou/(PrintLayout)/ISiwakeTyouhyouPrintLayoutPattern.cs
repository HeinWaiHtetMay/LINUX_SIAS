﻿using Icsp.Open21.Domain.MasterModel;
using Icsp.Open21.Domain.PrintDocumentModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票印刷レイアウトパターン（明細リストを含まないインターフェース）
    /// </summary>
    public interface ISiwakeTyouhyouPrintLayoutPattern : IMasterData
    {
        string Comment { get; set; }

        int DenpyouHeaderRowCount { get; set; }

        DenpyouAndSiwakeSectionLine DenpyouSectionLine { get; set; }

        float FontSize { get; set; }

        int ItemTitleRowCount { get; set; }

        int LayoutNo { get; }

        SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; }

        int LeftMargin { get; set; }

        int PageRowCount { get; set; }

        IcspPaperSize PrintPaperSize { get; set; }

        int RowHeight { get; set; }

        int SiwakeMeisaiRowCount { get; set; }

        DenpyouAndSiwakeSectionLine SiwakeSectionLine { get; set; }

        string TitleName { get; set; }

        int TopMargin { get; set; }
    }
}