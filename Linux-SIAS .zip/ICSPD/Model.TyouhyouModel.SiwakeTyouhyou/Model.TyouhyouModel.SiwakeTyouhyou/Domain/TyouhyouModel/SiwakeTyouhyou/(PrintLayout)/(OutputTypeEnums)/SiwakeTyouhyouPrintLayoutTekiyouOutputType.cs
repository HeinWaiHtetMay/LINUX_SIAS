﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 摘要出力形式
    /// </summary>
    public enum SiwakeTyouhyouPrintLayoutTekiyouOutputType
    {
        /// <summary>
        /// 全角30文字
        /// </summary>
        FullWidthChars30 = 0,

        /// <summary>
        /// 全角20文字＋10文字
        /// </summary>
        FullWidthChars20And10 = 1,

        /// <summary>
        /// 全角15文字＋15文字
        /// </summary>
        FullWidthChars15And15 = 2,
    }
}
