﻿using Icsp.Open21.Drawing.Printing;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票印刷レイアウトパターンタイトル項目（テーブル名：chklayhまたはsnchklayh）
    /// </summary>
    public class SiwakeTyouhyouPrintLayoutPatternTitleItem
    {
        public SiwakeTyouhyouPrintLayoutPatternTitleItem(SiwakeTyouhyouOutputType outputType, int layoutNo, int row, int itemSequence)
        {
            this.SiwakeTyouhyouOutputType = outputType;
            this.LayoutNo = layoutNo;
            this.Row = row - 1;
            this.ItemSequence = itemSequence;
        }

        /// <summary>
        /// 出力形式（カラム名：laytyp）
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; private set; }

        /// <summary>
        /// レイアウトNo（カラム名：layno）
        /// </summary>
        public int LayoutNo { get; private set; }

        /// <summary>
        /// 行（カラム名：layrow）
        /// </summary>
        public int Row { get; private set; }

        /// <summary>
        /// 項目SEQ（カラム名：cseq）
        /// </summary>
        public int ItemSequence { get; private set; }

        /// <summary>
        /// 開始位置（左）（カラム名：posx）
        /// </summary>
        public int LeftStartPosition { get; set; }

        /// <summary>
        /// 開始位置（上）（カラム名：posy）
        /// </summary>
        public int TopStartPosition { get; set; }

        /// <summary>
        /// 幅（カラム名：cwid）
        /// </summary>
        public int Width { get; set; }

        /// <summary>
        /// フォントサイズ（カラム名：fsize）
        /// </summary>
        public int FontSize { get; set; }

        /// <summary>
        /// 項目タイトル（カラム名：cnam）
        /// </summary>
        public string ItemTitle { get; set; }

        /// <summary>
        /// 位置寄せ（カラム名：align）
        /// </summary>
        public PrintTextAlignment Alignment { get; set; }

        /// <summary>
        /// 文字列を半角文字にするかどうか（カラム名：mwid）
        /// </summary>
        public bool IsChangeHalfWidthCharacter { get; set; }
    }
}
