﻿using Icsp.Open21.Domain.KaisyaModel;
using Icsp.Open21.Domain.PrintDocumentModel;
using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouPrintOptionRepository
    {
        /// <summary>
        /// 会社情報・ユーザー情報を条件として、印刷オプション情報を取得します。
        /// </summary>
        /// <param name="kaisya">会社情報</param>
        /// <param name="user">ユーザー情報</param>
        /// <param name="prgid">プログラムID</param>
        /// <returns>印刷オプション情報</returns>
        PrintOption FindByKaisyaAndUser(Kaisya kaisya, User user, string prgid);

        /// <summary>
        /// 印刷オプション情報を保存します。
        /// </summary>
        /// <param name="printOption">印刷オプション情報</param>
        /// <param name="prgid">プログラムID</param>
        void Store(PrintOption printOption, string prgid);
    }
}