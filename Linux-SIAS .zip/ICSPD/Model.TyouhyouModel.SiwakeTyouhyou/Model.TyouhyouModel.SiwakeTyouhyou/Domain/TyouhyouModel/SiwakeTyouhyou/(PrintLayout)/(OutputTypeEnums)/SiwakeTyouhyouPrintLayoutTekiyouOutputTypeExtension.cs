﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class SiwakeTyouhyouPrintLayoutTekiyouOutputTypeExtension
    {
        /// <summary>
        /// 1行目の全角文字数を取得します
        /// </summary>
        /// <param name="value">摘要出力形式</param>
        /// <returns>1行目の全角文字数</returns>
        public static int GetFirstLineFullWidthCharCount(this SiwakeTyouhyouPrintLayoutTekiyouOutputType value)
        {
            switch (value)
            {
                case SiwakeTyouhyouPrintLayoutTekiyouOutputType.FullWidthChars15And15:
                    return 15;
                case SiwakeTyouhyouPrintLayoutTekiyouOutputType.FullWidthChars20And10:
                    return 20;
                case SiwakeTyouhyouPrintLayoutTekiyouOutputType.FullWidthChars30:
                    return 30;
                default:
                    return 0;
            }
        }
    }
}
