﻿using System.Collections.Generic;
using Icsp.Open21.Domain.MasterModel;
using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouPrintLayoutPatternRepository
    {
        /// <summary>
        /// 指定条件の仕訳帳表印刷レイアウトパターンリストを取得します。
        /// </summary>
        /// <param name="outputType">出力形式</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        /// <returns>仕訳帳表印刷レイアウトパターンリスト</returns>
        IList<IMasterData> GetPatternNoAndName(SiwakeTyouhyouOutputType outputType, ApplicationSecurityType securityType);

        /// <summary>
        /// 指定条件の仕訳帳表印刷レイアウトパターンリストを取得します。
        /// </summary>
        /// <param name="outputType">出力形式</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        /// <returns>仕訳帳表印刷レイアウトパターンリスト</returns>
        IList<ISiwakeTyouhyouPrintLayoutPattern> FindBySiwakeTyouhyouOutputType(SiwakeTyouhyouOutputType outputType, ApplicationSecurityType securityType);

        /// <summary>
        /// 指定条件の仕訳帳表印刷レイアウトパターンを取得します。
        /// </summary>
        /// <param name="outputType">出力形式</param>
        /// <param name="layno">レイアウトNo</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        /// <param name="isTanituSiwakeTyouhyou">単一仕訳帳票かどうか</param>
        /// <returns>仕訳帳表印刷レイアウトパターン</returns>
        SiwakeTyouhyouPrintLayoutPattern FindBySiwakeTyouhyouOutputTypeAndLayno(SiwakeTyouhyouOutputType outputType, int layno, ApplicationSecurityType securityType, bool isTanituSiwakeTyouhyou);

        /// <summary>
        /// 仕訳帳表印刷レイアウトパターンを保存します。
        /// </summary>
        /// <param name="printLayoutPattern">仕訳帳表印刷レイアウトパターン</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        void Store(SiwakeTyouhyouPrintLayoutPattern printLayoutPattern, ApplicationSecurityType securityType);

        /// <summary>
        /// レイアウト形式及びレイアウトNoを条件として、仕訳帳表印刷レイアウトパターンを削除します。
        /// </summary>
        /// <param name="printLayoutPattern">仕訳帳表印刷レイアウトパターン</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        void DeleteByLaytypAndLayno(SiwakeTyouhyouPrintLayoutPattern printLayoutPattern, ApplicationSecurityType securityType);

        /// <summary>
        /// 仕訳帳表印刷レイアウトパターンを追加します。
        /// </summary>
        /// <param name="printLayoutPattern">仕訳帳表印刷レイアウトパターン</param>
        /// <param name="securityType">アプリケーションのセキュリティ区分</param>
        void Insert(SiwakeTyouhyouPrintLayoutPattern printLayoutPattern, ApplicationSecurityType securityType);
    }
}