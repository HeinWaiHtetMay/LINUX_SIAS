﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class HukugouSiwakeTyouhyouItemIdExtension
    {
        /// <summary>
        /// マスターかどうかを判定します。
        /// </summary>
        /// <param name="value">複合仕訳帳票用項目ID</param>
        /// <returns>マスターかどうか</returns>
        public static bool IsMasterType(this HukugouSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case HukugouSiwakeTyouhyouItemId.Bumon:
                case HukugouSiwakeTyouhyouItemId.Torihikisaki:
                case HukugouSiwakeTyouhyouItemId.Kamoku:
                case HukugouSiwakeTyouhyouItemId.Edaban:
                case HukugouSiwakeTyouhyouItemId.Kouzi:
                case HukugouSiwakeTyouhyouItemId.Kousyu:
                case HukugouSiwakeTyouhyouItemId.Project:
                case HukugouSiwakeTyouhyouItemId.Segment:
                case HukugouSiwakeTyouhyouItemId.UniversalField01:
                case HukugouSiwakeTyouhyouItemId.UniversalField02:
                case HukugouSiwakeTyouhyouItemId.UniversalField03:
                case HukugouSiwakeTyouhyouItemId.TekiyouCode:
                case HukugouSiwakeTyouhyouItemId.SyouhizeiTaisyouKamoku:
                case HukugouSiwakeTyouhyouItemId.SiwakeCreateUser:
                case HukugouSiwakeTyouhyouItemId.SiwakeUpdateUser:
                case HukugouSiwakeTyouhyouItemId.UniversalField04:
                case HukugouSiwakeTyouhyouItemId.UniversalField05:
                case HukugouSiwakeTyouhyouItemId.UniversalField06:
                case HukugouSiwakeTyouhyouItemId.UniversalField07:
                case HukugouSiwakeTyouhyouItemId.UniversalField08:
                case HukugouSiwakeTyouhyouItemId.UniversalField09:
                case HukugouSiwakeTyouhyouItemId.UniversalField10:
                case HukugouSiwakeTyouhyouItemId.UniversalField11:
                case HukugouSiwakeTyouhyouItemId.UniversalField12:
                case HukugouSiwakeTyouhyouItemId.UniversalField13:
                case HukugouSiwakeTyouhyouItemId.UniversalField14:
                case HukugouSiwakeTyouhyouItemId.UniversalField15:
                case HukugouSiwakeTyouhyouItemId.UniversalField16:
                case HukugouSiwakeTyouhyouItemId.UniversalField17:
                case HukugouSiwakeTyouhyouItemId.UniversalField18:
                case HukugouSiwakeTyouhyouItemId.UniversalField19:
                case HukugouSiwakeTyouhyouItemId.UniversalField20:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 税区分かどうかを判定します。
        /// </summary>
        /// <param name="value">複合仕訳帳票用項目ID</param>
        /// <returns>税区分かどうか</returns>
        public static bool IsSyouhizeiKubun(this HukugouSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case HukugouSiwakeTyouhyouItemId.KazeiKubun:
                case HukugouSiwakeTyouhyouItemId.SyouhizeiTaisyouKamokuSyouhizeiKubun:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 日付かどうかを判定します。
        /// </summary>
        /// <param name="value">複合仕訳帳票用項目ID</param>
        /// <returns>日付かどうか</returns>
        public static bool IsDateTimeType(this HukugouSiwakeTyouhyouItemId value)
        {
            switch (value)
            {
                case HukugouSiwakeTyouhyouItemId.SiwakeCreateDate:
                case HukugouSiwakeTyouhyouItemId.SiwakeUpdateDate:
                case HukugouSiwakeTyouhyouItemId.SiharaiDate:
                case HukugouSiwakeTyouhyouItemId.KaisyuuDate:
                    return true;
                default:
                    return false;
            }
        }
    }
}
