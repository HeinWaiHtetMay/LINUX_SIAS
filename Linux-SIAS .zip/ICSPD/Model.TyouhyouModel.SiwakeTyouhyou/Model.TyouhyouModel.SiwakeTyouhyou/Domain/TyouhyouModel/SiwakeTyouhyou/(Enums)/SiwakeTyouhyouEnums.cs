﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 部門単位出力
    /// </summary>
    public enum BumonTaniOutputSetting
    {
        /// <summary>
        /// 通常
        /// </summary>
        Normal = 0,

        /// <summary>
        /// 部門単位（範囲）
        /// </summary>
        BumonRangeSitei = 1,

        /// <summary>
        /// 部門単位（個別）
        /// </summary>
        BumonKobetuSitei = 2,

        /// <summary>
        /// 集計部門単位（範囲）
        /// </summary>
        SyuukeiBumonRangeSitei = 3,

        /// <summary>
        /// 集計部門単位（個別）
        /// </summary>
        SyuukeiBumonKobetuSitei = 4,
    }

    /// <summary>
    /// 発生フラグ
    /// </summary>
    public enum TaisyakuKubun
    {
        /// <summary>
        /// 借方
        /// </summary>
        Karikata = 1,

        /// <summary>
        /// 貸方
        /// </summary>
        Kasikata = 2,

        /// <summary>
        /// 貸借
        /// </summary>
        Taisyaku = 3
    }

    /// <summary>
    /// 貸借摘要フラグ
    /// </summary>
    public enum TaisyakuTekiyouFlag
    {
        /// <summary>
        /// 貸借共通摘要
        /// </summary>
        TaisyakuCommonTekiyou = 0,

        /// <summary>
        /// 貸借別摘要
        /// </summary>
        TaisyakubetuTekiyou = 1
    }

    /// <summary>
    /// 外貨換算仕訳フラグ
    /// </summary>
    public enum GaikaKansanSiwakeFlag
    {
        /// <summary>
        /// 通常仕訳
        /// </summary>
        Normal = 0,

        /// <summary>
        /// 振替仕訳
        /// </summary>
        Hurikae = 1,

        /// <summary>
        /// 振替仕訳（取消済）
        /// </summary>
        HurikaeTorikesizumi = 2,

        /// <summary>
        /// 振替仕訳（訂正仕訳）
        /// </summary>
        HurikaeTeiseiSiwake = 3,

        /// <summary>
        /// 振戻仕訳
        /// </summary>
        Hurimodosi = 4,

        /// <summary>
        /// 振戻仕訳（取消済）
        /// </summary>
        HurimodosiTorikesizumi = 5,

        /// <summary>
        /// 振戻仕訳（訂正仕訳）
        /// </summary>
        HurimodosiTeiseiSiwake = 6
    }

    /// <summary>
    /// 摘要の検索条件
    /// </summary>
    public enum TekiyouSearchCondition
    {
        /// <summary>
        /// 含む
        /// </summary>
        Contain = 0,

        /// <summary>
        /// 含まない
        /// </summary>
        NotContain = 1,

        /// <summary>
        /// 等しい
        /// </summary>
        Equal = 2,

        /// <summary>
        /// 等しくない
        /// </summary>
        NotEqual = 3
    }
}
