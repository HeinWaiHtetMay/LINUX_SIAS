﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳帳票並び順
    /// </summary>
    public enum SiwakeTyouhyouOrderItem
    {
        /// <summary>
        /// 伝票SEQ
        /// </summary>
        Dseq = 0,

        /// <summary>
        /// 伝票日付
        /// </summary>
        DenpyouDate = 1,

        /// <summary>
        /// 伝票番号
        /// </summary>
        DenpyouNo = 2,

        /// <summary>
        /// 伝票入力者
        /// </summary>
        DenpyouCreateUser = 3,

        /// <summary>
        /// 受付番号
        /// </summary>
        UketukeNo = 4,

        /// <summary>
        /// 仕訳SEQ
        /// </summary>
        Sseq = 5,

        /// <summary>
        /// グループ番号
        /// </summary>
        GroupNo = 6,

        /// <summary>
        /// 伝票頁
        /// </summary>
        DenpyouPage = 7,

        /// <summary>
        /// 行番号
        /// </summary>
        LineNo = 8,

        /// <summary>
        /// 貸借属性
        /// </summary>
        SiwakeTaisyakuZokusei = 9,

        /// <summary>
        /// 承認グループ
        /// </summary>
        SyouninGroup = 10,

        /// <summary>
        /// 財務→未転記
        /// </summary>
        ZaimuToMitenki = 11
    }
}
