﻿using Icsp.Open21.Properties;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public static class SiwakeTyouhyouDenpyouSortOrderExtension
    {
        /// <summary>
        /// 伝票並び順の名称を取得します。
        /// </summary>
        /// <param name="value">伝票並び順の値</param>
        /// <returns>伝票並び順の名称</returns>
        public static string GetName(this SiwakeTyouhyouDenpyouSortOrder value)
        {
            switch (value)
            {
                case SiwakeTyouhyouDenpyouSortOrder.Sseq:
                    return Resources.仕訳SEQ順;
                case SiwakeTyouhyouDenpyouSortOrder.DenpyouDate:
                    return Resources.伝票日付順;
                case SiwakeTyouhyouDenpyouSortOrder.DenpyouNo:
                    return Resources.伝票番号順;
                case SiwakeTyouhyouDenpyouSortOrder.UketukeNo:
                    return Resources.受付番号順;
                case SiwakeTyouhyouDenpyouSortOrder.Dseq:
                    return Resources.伝票SEQ順;
                default:
                    return string.Empty;
            }
        }
    }
}
