﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.KaisyaModel;

    /// <summary>
    /// 仕訳帳票行項目の使用可否設定
    /// </summary>
    public class SiwakeTyouhyouRowItemAvailability
    {
        /// <summary>
        /// ユニバーサルフィールド正式名称を使用するユニバーサルフィールドNoのSet
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// </summary>
        private ISet<int> useUniversalFileldLongNameNoSet = new HashSet<int>();

        /// <summary>
        /// ユニバーサルフィールド正式名称が使用可能なユニバーサルフィールドNoのSet
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// </summary>
        private ISet<int> universalFileldLongNameEnabledNoSet = new HashSet<int>();

        #region プロパティ

        /// <summary>
        /// 伝票項目（複合フラグ・入力パターン・削除フラグ・未完伝票フラグ）の使用可否
        /// </summary>
        public bool DenpyouItemEnabled { get; set; }

        /// <summary>
        /// 伝票作成・更新項目（伝票作成日・伝票作成者・伝票更新日・伝票更新者）の使用可否
        /// </summary>
        public bool DenpyouCreateAndUpdateItemEnabled { get; set; }

        /// <summary>
        /// 起票日の使用可否
        /// </summary>
        public bool KihyouDateEnabled { get; set; }

        /// <summary>
        /// 起票者の使用可否
        /// </summary>
        public bool KihyouTantousyaEnabled { get; set; }

        /// <summary>
        /// 起票部門の使用可否
        /// </summary>
        public bool KihyouBumonEnabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド1の使用可否
        /// </summary>
        public bool HeaderField01Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド2の使用可否
        /// </summary>
        public bool HeaderField02Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド3の使用可否
        /// </summary>
        public bool HeaderField03Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド4の使用可否
        /// </summary>
        public bool HeaderField04Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド5の使用可否
        /// </summary>
        public bool HeaderField05Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド6の使用可否
        /// </summary>
        public bool HeaderField06Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド7の使用可否
        /// </summary>
        public bool HeaderField07Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド8の使用可否
        /// </summary>
        public bool HeaderField08Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド9の使用可否
        /// </summary>
        public bool HeaderField09Enabled { get; set; }

        /// <summary>
        /// ヘッダーフィールド10の使用可否
        /// </summary>
        public bool HeaderField10Enabled { get; set; }

        /// <summary>
        /// 伝票束の使用可否
        /// </summary>
        public bool DenpyouTabaEnabled { get; set; }

        /// <summary>
        /// 承認項目（入力確定日・承認グループNo・判定済最上位承認者順序・承認状況・第一～十承認者・第一～十承認判定）の使用可否
        /// </summary>
        public bool SyouninItemEnabled { get; set; }

        /// <summary>
        /// 承認カラーの使用可否
        /// </summary>
        public bool SyouninColorEnabled { get; set; }

        /// <summary>
        /// コメントの使用可否
        /// </summary>
        public bool SyouninCommentEnabled { get; set; }

        /// <summary>
        /// 仕訳項目（仕訳SEQNo.・行番号・親子フラグ・分離区分・貸借属性・対価入力フラグ・一括税抜仕訳フラグ・削除フラグ・貸借摘要フラグ・否認状況）の使用可否
        /// </summary>
        public bool SiwakeItemEnabled { get; set; }

        /// <summary>
        /// 仕訳作成・更新項目（仕訳作成日・仕訳作成者・仕訳更新日・仕訳更新者）の使用可否
        /// </summary>
        public bool SiwakeCreateAndUpdateItemEnabled { get; set; }

        /// <summary>
        /// 税区分項目（税率・課税区分・業種区分・仕入区分）の使用可否
        /// </summary>
        public bool ZeiKubunItemEnabled { get; set; }

        /// <summary>
        /// 消費税項目（税対象科目・税率・課税区分・業種区分・仕入区分）の使用可否
        /// </summary>
        public bool SyouhizeiItemEnabled { get; set; }

        /// <summary>
        /// 部門の使用可否
        /// </summary>
        public bool BumonEnabled { get; set; }

        /// <summary>
        /// 科目の使用可否
        /// </summary>
        public bool KamokuEnabled { get; set; }

        /// <summary>
        /// 取引先の使用可否
        /// </summary>
        public bool TorihikisakiEnabled { get; set; }

        /// <summary>
        /// 枝番の使用可否
        /// </summary>
        public bool EdabanEnabled { get; set; }

        /// <summary>
        /// セグメントの使用可否
        /// </summary>
        public bool SegmentEnabled { get; set; }

        /// <summary>
        /// プロジェクトの使用可否
        /// </summary>
        public bool ProjectEnabled { get; set; }

        /// <summary>
        /// 工事の使用可否
        /// </summary>
        public bool KouziEnabled { get; set; }

        /// <summary>
        /// 工種の使用可否
        /// </summary>
        public bool KousyuEnabled { get; set; }

        /// <summary>
        /// 摘要の使用可否
        /// </summary>
        public bool TekiyouEnabled { get; set; }

        /// <summary>
        /// 摘要コードの使用可否
        /// </summary>
        public bool TekiyouCodeEnabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1の使用可否
        /// </summary>
        public bool UniversalField01Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2の使用可否
        /// </summary>
        public bool UniversalField02Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3の使用可否
        /// </summary>
        public bool UniversalField03Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4の使用可否
        /// </summary>
        public bool UniversalField04Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5の使用可否
        /// </summary>
        public bool UniversalField05Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6の使用可否
        /// </summary>
        public bool UniversalField06Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7の使用可否
        /// </summary>
        public bool UniversalField07Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8の使用可否
        /// </summary>
        public bool UniversalField08Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9の使用可否
        /// </summary>
        public bool UniversalField09Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10の使用可否
        /// </summary>
        public bool UniversalField10Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11の使用可否
        /// </summary>
        public bool UniversalField11Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12の使用可否
        /// </summary>
        public bool UniversalField12Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13の使用可否
        /// </summary>
        public bool UniversalField13Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14の使用可否
        /// </summary>
        public bool UniversalField14Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15の使用可否
        /// </summary>
        public bool UniversalField15Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16の使用可否
        /// </summary>
        public bool UniversalField16Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17の使用可否
        /// </summary>
        public bool UniversalField17Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18の使用可否
        /// </summary>
        public bool UniversalField18Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19の使用可否
        /// </summary>
        public bool UniversalField19Enabled { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20の使用可否
        /// </summary>
        public bool UniversalField20Enabled { get; set; }

        /// <summary>
        /// 支払日の使用可否
        /// </summary>
        public bool SiharaiDateEnabled { get; set; }

        /// <summary>
        /// 支払区分の使用可否
        /// </summary>
        public bool SiharaiKubunEnabled { get; set; }

        /// <summary>
        /// 支払期日の使用可否
        /// </summary>
        public bool SiharaiKizituEnabled { get; set; }

        /// <summary>
        /// 回収日の使用可否
        /// </summary>
        public bool KaisyuuDateEnabled { get; set; }

        /// <summary>
        /// 入金区分の使用可否
        /// </summary>
        public bool NyuukinKubunEnabled { get; set; }

        /// <summary>
        /// 回収期日の使用可否
        /// </summary>
        public bool KaisyuuKizituEnabled { get; set; }

        /// <summary>
        /// 消込コードの使用可否
        /// </summary>
        public bool KesikomiCodeEnabled { get; set; }

        /// <summary>
        /// 金額項目（金額・対価金額・税込金額）の使用可否
        /// </summary>
        public bool KingakuItemEnabled { get; set; }

        /// <summary>
        /// 外貨項目（通貨コード・レート・外貨金額・外貨対価金額・外貨税込金額・単位名称・国名・小数部桁数）の使用可否
        /// </summary>
        public bool GaikaItemEnabled { get; set; }

        /// <summary>
        /// 外貨換算仕訳フラグの使用可否
        /// </summary>
        public bool GaikaKansanSiwakeFlagEnabled { get; set; }

        /// <summary>
        /// 付箋の使用可否
        /// </summary>
        public bool SiwakeHusenEnabled { get; set; }

        /// <summary>
        /// 確定の使用可否
        /// </summary>
        public bool KakuteiEnabled { get; set; }

        /// <summary>
        /// 整理月フラグの使用可否
        /// </summary>
        public bool SeiritukiFlagEnabled { get; set; }

        /// <summary>
        /// 部門指定の部門の使用可否
        /// </summary>
        public bool BumonAsBumonSiteiEnabled { get; set; }

        /// <summary>
        /// 科目正式名称（印刷用名称）を使用するかどうか、falseの場合は画面用名称を使用します
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool UseKamokuLongName { get; set; }

        /// <summary>
        /// 科目正式名称（印刷用名称）が使用可能かどうか、falseの場合は印刷用名称を使用できません
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool KamokuLongNameEnabled { get; set; }

        /// <summary>
        /// セグメント正式名称を使用するかどうか、falseの場合は通常名称を使用します
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool UseSegmentLongName { get; set; }

        /// <summary>
        /// セグメント正式名称が使用可能かどうか、falseの場合は正式名称を使用できません
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool SegmentLongNameEnabled { get; set; }

        /// <summary>
        /// プロジェクト正式名称を使用するかどうか、falseの場合は通常名称を使用します
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool UseProjectLongName { get; set; }

        /// <summary>
        /// プロジェクト正式名称が使用可能かどうか、falseの場合は正式名称を使用できません
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool ProjectLongNameEnabled { get; set; }

        /// <summary>
        /// 工事正式名称を使用するかどうか、falseの場合は通常名称を使用します
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool UseKouziLongName { get; set; }

        /// <summary>
        /// 工事正式名称が使用可能かどうか、falseの場合は正式名称を使用できません
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool KouziLongNameEnabled { get; set; }

        /// <summary>
        /// 取引先正式名称を使用するかどうか、falseの場合は通常名称を使用します
        /// ※通常名称⇔正式名称のどちらか一方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool UseTorihikisakiLongName { get; set; }

        /// <summary>
        /// 取引先正式名称が使用可能かどうか、falseの場合は正式名称を使用できません
        /// ※通常名称と正式名称の両方を出力する場合に使用します
        /// 初期値=false
        /// </summary>
        public bool TorihikisakiLongNameEnabled { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールドの使用可否を取得します。
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールドの使用可否</returns>
        public bool GetHeaderFieldEnabled(int no)
        {
            switch (no)
            {
                case 1:
                    return this.HeaderField01Enabled;
                case 2:
                    return this.HeaderField02Enabled;
                case 3:
                    return this.HeaderField03Enabled;
                case 4:
                    return this.HeaderField04Enabled;
                case 5:
                    return this.HeaderField05Enabled;
                case 6:
                    return this.HeaderField06Enabled;
                case 7:
                    return this.HeaderField07Enabled;
                case 8:
                    return this.HeaderField08Enabled;
                case 9:
                    return this.HeaderField09Enabled;
                case 10:
                    return this.HeaderField10Enabled;
                default:
                    return false;
            }
        }

        /// <summary>
        /// ユニバーサルフィールドの使用可否を取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールドの使用可否</returns>
        public bool GetUniversalFieldEnabled(int no)
        {
            switch (no)
            {
                case 1:
                    return this.UniversalField01Enabled;
                case 2:
                    return this.UniversalField02Enabled;
                case 3:
                    return this.UniversalField03Enabled;
                case 4:
                    return this.UniversalField04Enabled;
                case 5:
                    return this.UniversalField05Enabled;
                case 6:
                    return this.UniversalField06Enabled;
                case 7:
                    return this.UniversalField07Enabled;
                case 8:
                    return this.UniversalField08Enabled;
                case 9:
                    return this.UniversalField09Enabled;
                case 10:
                    return this.UniversalField10Enabled;
                case 11:
                    return this.UniversalField11Enabled;
                case 12:
                    return this.UniversalField12Enabled;
                case 13:
                    return this.UniversalField13Enabled;
                case 14:
                    return this.UniversalField14Enabled;
                case 15:
                    return this.UniversalField15Enabled;
                case 16:
                    return this.UniversalField16Enabled;
                case 17:
                    return this.UniversalField17Enabled;
                case 18:
                    return this.UniversalField18Enabled;
                case 19:
                    return this.UniversalField19Enabled;
                case 20:
                    return this.UniversalField20Enabled;
                default:
                    return false;
            }
        }

        /// <summary>
        /// ヘッダーフィールド及びユニバーサルフィールドの使用可否を設定します。
        /// </summary>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="isGetSiwake">仕訳を取得するかどうか</param>
        public void SetHeaderFieldAndUniversalFieldEnabled(Syoriki syoriki, bool isGetSiwake)
        {
            var headerFieldInfoList = syoriki.GetUniversalFieldInfoList(true);
            this.HeaderField01Enabled = headerFieldInfoList[0].Use;
            this.HeaderField02Enabled = headerFieldInfoList[1].Use;
            this.HeaderField03Enabled = headerFieldInfoList[2].Use;
            this.HeaderField04Enabled = headerFieldInfoList[3].Use;
            this.HeaderField05Enabled = headerFieldInfoList[4].Use;
            this.HeaderField06Enabled = headerFieldInfoList[5].Use;
            this.HeaderField07Enabled = headerFieldInfoList[6].Use;
            this.HeaderField08Enabled = headerFieldInfoList[7].Use;
            this.HeaderField09Enabled = headerFieldInfoList[8].Use;
            this.HeaderField10Enabled = headerFieldInfoList[9].Use;

            //// 仕訳取得時、ユニバーサルフィールドの使用可否も合わせて設定
            if (isGetSiwake)
            {
                var universalFieldInfoList = syoriki.GetUniversalFieldInfoList(false);
                this.UniversalField01Enabled = universalFieldInfoList[0].Use;
                this.UniversalField02Enabled = universalFieldInfoList[1].Use;
                this.UniversalField03Enabled = universalFieldInfoList[2].Use;
                this.UniversalField04Enabled = universalFieldInfoList[3].Use;
                this.UniversalField05Enabled = universalFieldInfoList[4].Use;
                this.UniversalField06Enabled = universalFieldInfoList[5].Use;
                this.UniversalField07Enabled = universalFieldInfoList[6].Use;
                this.UniversalField08Enabled = universalFieldInfoList[7].Use;
                this.UniversalField09Enabled = universalFieldInfoList[8].Use;
                this.UniversalField10Enabled = universalFieldInfoList[9].Use;
                this.UniversalField11Enabled = universalFieldInfoList[10].Use;
                this.UniversalField12Enabled = universalFieldInfoList[11].Use;
                this.UniversalField13Enabled = universalFieldInfoList[12].Use;
                this.UniversalField14Enabled = universalFieldInfoList[13].Use;
                this.UniversalField15Enabled = universalFieldInfoList[14].Use;
                this.UniversalField16Enabled = universalFieldInfoList[15].Use;
                this.UniversalField17Enabled = universalFieldInfoList[16].Use;
                this.UniversalField18Enabled = universalFieldInfoList[17].Use;
                this.UniversalField19Enabled = universalFieldInfoList[18].Use;
                this.UniversalField20Enabled = universalFieldInfoList[19].Use;
            }
        }

        public bool GetUseUniversalFieldLongName(int no)
        {
            return this.useUniversalFileldLongNameNoSet.Contains(no);
        }

        public bool GetUniversalFieldLongNameEnabled(int no)
        {
            return this.universalFileldLongNameEnabledNoSet.Contains(no);
        }

        public void SetUseUniversalFieldLongName(int no, bool useLongName)
        {
            if (useLongName)
            {
                this.useUniversalFileldLongNameNoSet.Add(no);
            }
            else
            {
                this.useUniversalFileldLongNameNoSet.Remove(no);
            }
        }

        public void SetUniversalFieldLongNameEnabled(int no, bool longNameEnabled)
        {
            if (longNameEnabled)
            {
                this.universalFileldLongNameEnabledNoSet.Add(no);
            }
            else
            {
                this.universalFileldLongNameEnabledNoSet.Remove(no);
            }
        }

        #endregion
    }
}
