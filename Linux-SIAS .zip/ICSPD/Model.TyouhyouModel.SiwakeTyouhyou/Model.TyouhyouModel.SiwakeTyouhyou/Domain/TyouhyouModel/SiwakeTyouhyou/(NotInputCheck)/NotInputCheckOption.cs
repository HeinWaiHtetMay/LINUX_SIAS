﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 未入力チェックオプション
    /// </summary>
    public class NotInputCheckOption
    {
        #region プロパティ

        /// <summary>
        /// 起票者未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseKihyouTantousyaNotInputCheck { get; set; }

        /// <summary>
        /// 起票部門未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseKihyouBumonNotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド1未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField01NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド2未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField02NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド3未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField03NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド4未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField04NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド5未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField05NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド6未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField06NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド7未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField07NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド8未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField08NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド9未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField09NotInputCheck { get; set; }

        /// <summary>
        /// ヘッダーフィールド10未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseHeaderField10NotInputCheck { get; set; }

        /// <summary>
        /// 部門未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseBumonNotInputCheck { get; set; }

        /// <summary>
        /// 枝番未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseEdabanNotInputCheck { get; set; }

        /// <summary>
        /// 取引先未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseTorihikisakiNotInputCheck { get; set; }

        /// <summary>
        /// セグメント未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseSegmentNotInputCheck { get; set; }

        /// <summary>
        /// プロジェクト未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseProjectNotInputCheck { get; set; }

        /// <summary>
        /// 工事未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseKouziNotInputCheck { get; set; }

        /// <summary>
        /// 工種未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseKousyuNotInputCheck { get; set; }

        /// <summary>
        /// 摘要コード未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseTekiyouCodeNotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField01NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField02NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField03NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField04NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField05NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField06NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField07NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField08NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField09NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField10NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField11NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField12NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField13NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField14NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField15NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField16NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField17NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField18NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField19NotInputCheck { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20未入力チェックをおこなうかどうか
        /// </summary>
        public bool IsUseUniversalField20NotInputCheck { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールド未入力チェックをおこなうかどうかの設定値を取得します
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールド未入力チェックをおこなうかどうかの設定値</returns>
        public bool GetHeaderFieldNotInputCheck(int headerFieldNo)
        {
            switch (headerFieldNo)
            {
                case 1:
                    return this.IsUseHeaderField01NotInputCheck;

                case 2:
                    return this.IsUseHeaderField02NotInputCheck;

                case 3:
                    return this.IsUseHeaderField03NotInputCheck;

                case 4:
                    return this.IsUseHeaderField04NotInputCheck;

                case 5:
                    return this.IsUseHeaderField05NotInputCheck;

                case 6:
                    return this.IsUseHeaderField06NotInputCheck;

                case 7:
                    return this.IsUseHeaderField07NotInputCheck;

                case 8:
                    return this.IsUseHeaderField08NotInputCheck;

                case 9:
                    return this.IsUseHeaderField09NotInputCheck;

                case 10:
                    return this.IsUseHeaderField10NotInputCheck;

                default:
                    return false;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド未入力チェックをおこなうかどうかの設定値を取得します
        /// </summary>
        /// <param name="universalFieldNo">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド未入力チェックをおこなうかどうかの設定値</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "取得項目が多いため、省略不可")]
        public bool GetUniversalFieldNotInputCheck(int universalFieldNo)
        {
            switch (universalFieldNo)
            {
                case 1:
                    return this.IsUseUniversalField01NotInputCheck;

                case 2:
                    return this.IsUseUniversalField02NotInputCheck;

                case 3:
                    return this.IsUseUniversalField03NotInputCheck;

                case 4:
                    return this.IsUseUniversalField04NotInputCheck;

                case 5:
                    return this.IsUseUniversalField05NotInputCheck;

                case 6:
                    return this.IsUseUniversalField06NotInputCheck;

                case 7:
                    return this.IsUseUniversalField07NotInputCheck;

                case 8:
                    return this.IsUseUniversalField08NotInputCheck;

                case 9:
                    return this.IsUseUniversalField09NotInputCheck;

                case 10:
                    return this.IsUseUniversalField10NotInputCheck;

                case 11:
                    return this.IsUseUniversalField11NotInputCheck;

                case 12:
                    return this.IsUseUniversalField12NotInputCheck;

                case 13:
                    return this.IsUseUniversalField13NotInputCheck;

                case 14:
                    return this.IsUseUniversalField14NotInputCheck;

                case 15:
                    return this.IsUseUniversalField15NotInputCheck;

                case 16:
                    return this.IsUseUniversalField16NotInputCheck;

                case 17:
                    return this.IsUseUniversalField17NotInputCheck;

                case 18:
                    return this.IsUseUniversalField18NotInputCheck;

                case 19:
                    return this.IsUseUniversalField19NotInputCheck;

                case 20:
                    return this.IsUseUniversalField20NotInputCheck;

                default:
                    return false;
            }
        }

        #endregion
    }
}
