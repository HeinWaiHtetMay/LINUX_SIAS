﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 仕訳項目未入力チェック結果
    /// </summary>
    public class SiwakeItemNotInputCheckResult
    {
        #region プロパティ

        /// <summary>
        /// 部門未入力チェック結果
        /// </summary>
        public bool IsBumonNotInput { get; set; }

        /// <summary>
        /// 枝番未入力チェック結果
        /// </summary>
        public bool IsEdabanNotInput { get; set; }

        /// <summary>
        /// 取引先未入力チェック結果
        /// </summary>
        public bool IsTorihikisakiNotInput { get; set; }

        /// <summary>
        /// セグメント未入力チェック結果
        /// </summary>
        public bool IsSegmentNotInput { get; set; }

        /// <summary>
        /// プロジェクト未入力チェック結果
        /// </summary>
        public bool IsProjectNotInput { get; set; }

        /// <summary>
        /// 工事未入力チェック結果
        /// </summary>
        public bool IsKouziNotInput { get; set; }

        /// <summary>
        /// 工種未入力チェック結果
        /// </summary>
        public bool IsKousyuNotInput { get; set; }

        /// <summary>
        /// 摘要コード未入力チェック結果
        /// </summary>
        public bool IsTekiyouCodeNotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド1未入力チェック結果
        /// </summary>
        public bool IsUniversalField01NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド2未入力チェック結果
        /// </summary>
        public bool IsUniversalField02NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド3未入力チェック結果
        /// </summary>
        public bool IsUniversalField03NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド4未入力チェック結果
        /// </summary>
        public bool IsUniversalField04NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド5未入力チェック結果
        /// </summary>
        public bool IsUniversalField05NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド6未入力チェック結果
        /// </summary>
        public bool IsUniversalField06NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド7未入力チェック結果
        /// </summary>
        public bool IsUniversalField07NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド8未入力チェック結果
        /// </summary>
        public bool IsUniversalField08NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド9未入力チェック結果
        /// </summary>
        public bool IsUniversalField09NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド10未入力チェック結果
        /// </summary>
        public bool IsUniversalField10NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド11未入力チェック結果
        /// </summary>
        public bool IsUniversalField11NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド12未入力チェック結果
        /// </summary>
        public bool IsUniversalField12NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド13未入力チェック結果
        /// </summary>
        public bool IsUniversalField13NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド14未入力チェック結果
        /// </summary>
        public bool IsUniversalField14NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド15未入力チェック結果
        /// </summary>
        public bool IsUniversalField15NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド16未入力チェック結果
        /// </summary>
        public bool IsUniversalField16NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド17未入力チェック結果
        /// </summary>
        public bool IsUniversalField17NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド18未入力チェック結果
        /// </summary>
        public bool IsUniversalField18NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド19未入力チェック結果
        /// </summary>
        public bool IsUniversalField19NotInput { get; set; }

        /// <summary>
        /// ユニバーサルフィールド20未入力チェック結果
        /// </summary>
        public bool IsUniversalField20NotInput { get; set; }

        #endregion

        #region メソッド

        /// <summary>
        /// ユニバーサルフィールド未入力チェック結果を取得します
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド未入力チェック結果</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "取得項目が多いため、省略不可")]
        public bool GetIsUniversalFieldNotInput(int no)
        {
            switch (no)
            {
                case 1:
                    return this.IsUniversalField01NotInput;

                case 2:
                    return this.IsUniversalField02NotInput;

                case 3:
                    return this.IsUniversalField03NotInput;

                case 4:
                    return this.IsUniversalField04NotInput;

                case 5:
                    return this.IsUniversalField05NotInput;

                case 6:
                    return this.IsUniversalField06NotInput;

                case 7:
                    return this.IsUniversalField07NotInput;

                case 8:
                    return this.IsUniversalField08NotInput;

                case 9:
                    return this.IsUniversalField09NotInput;

                case 10:
                    return this.IsUniversalField10NotInput;

                case 11:
                    return this.IsUniversalField11NotInput;

                case 12:
                    return this.IsUniversalField12NotInput;

                case 13:
                    return this.IsUniversalField13NotInput;

                case 14:
                    return this.IsUniversalField14NotInput;

                case 15:
                    return this.IsUniversalField15NotInput;

                case 16:
                    return this.IsUniversalField16NotInput;

                case 17:
                    return this.IsUniversalField17NotInput;

                case 18:
                    return this.IsUniversalField18NotInput;

                case 19:
                    return this.IsUniversalField19NotInput;

                case 20:
                    return this.IsUniversalField20NotInput;

                default:
                    return false;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド未入力チェック結果を設定します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="code">ユニバーサルフィールドコード（設定前）</param>
        /// <param name="isUniversalFieldNotInputForKamoku">科目に関して、ユニバーサルフィールド未入力チェックをおこなうかどうか</param>
        /// <param name="notInputCheckOption">未入力チェックオプション</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目・条件が多いため、分割困難")]
        public void SetIsUniversalFieldNotInput(int no, string code, bool isUniversalFieldNotInputForKamoku, NotInputCheckOption notInputCheckOption)
        {
            switch (no)
            {
                case 1:
                    this.IsUniversalField01NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField01NotInputCheck;
                    break;
                case 2:
                    this.IsUniversalField02NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField02NotInputCheck;
                    break;
                case 3:
                    this.IsUniversalField03NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField03NotInputCheck;
                    break;
                case 4:
                    this.IsUniversalField04NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField04NotInputCheck;
                    break;
                case 5:
                    this.IsUniversalField05NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField05NotInputCheck;
                    break;
                case 6:
                    this.IsUniversalField06NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField06NotInputCheck;
                    break;
                case 7:
                    this.IsUniversalField07NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField07NotInputCheck;
                    break;
                case 8:
                    this.IsUniversalField08NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField08NotInputCheck;
                    break;
                case 9:
                    this.IsUniversalField09NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField09NotInputCheck;
                    break;
                case 10:
                    this.IsUniversalField10NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField10NotInputCheck;
                    break;
                case 11:
                    this.IsUniversalField11NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField11NotInputCheck;
                    break;
                case 12:
                    this.IsUniversalField12NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField12NotInputCheck;
                    break;
                case 13:
                    this.IsUniversalField13NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField13NotInputCheck;
                    break;
                case 14:
                    this.IsUniversalField14NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField14NotInputCheck;
                    break;
                case 15:
                    this.IsUniversalField15NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField15NotInputCheck;
                    break;
                case 16:
                    this.IsUniversalField16NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField16NotInputCheck;
                    break;
                case 17:
                    this.IsUniversalField17NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField17NotInputCheck;
                    break;
                case 18:
                    this.IsUniversalField18NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField18NotInputCheck;
                    break;
                case 19:
                    this.IsUniversalField19NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField19NotInputCheck;
                    break;
                case 20:
                    this.IsUniversalField20NotInput = string.IsNullOrEmpty(code) && isUniversalFieldNotInputForKamoku && notInputCheckOption.IsUseUniversalField20NotInputCheck;
                    break;
                default:
                    break;
            }
        }

        #endregion
    }
}
