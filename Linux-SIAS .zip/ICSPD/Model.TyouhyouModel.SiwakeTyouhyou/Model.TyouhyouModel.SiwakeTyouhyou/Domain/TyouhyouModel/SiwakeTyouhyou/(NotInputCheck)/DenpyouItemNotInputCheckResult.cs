﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 伝票項目未入力チェック結果
    /// </summary>
    public class DenpyouItemNotInputCheckResult
    {
        #region プロパティ

        /// <summary>
        /// 起票者未入力チェック結果
        /// </summary>
        public bool IsKihyouTantousyaNotInput { get; set; }

        /// <summary>
        /// 起票部門未入力チェック結果
        /// </summary>
        public bool IsKihyouBumonNotInput { get; set; }

        /// <summary>
        /// ヘッダーフィールド1未入力チェック結果
        /// </summary>
        public bool IsHeaderField01NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド2未入力チェック結果
        /// </summary>
        public bool IsHeaderField02NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド3未入力チェック結果
        /// </summary>
        public bool IsHeaderField03NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド4未入力チェック結果
        /// </summary>
        public bool IsHeaderField04NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド5未入力チェック結果
        /// </summary>
        public bool IsHeaderField05NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド6未入力チェック結果
        /// </summary>
        public bool IsHeaderField06NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド7未入力チェック結果
        /// </summary>
        public bool IsHeaderField07NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド8未入力チェック結果
        /// </summary>
        public bool IsHeaderField08NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド9未入力チェック結果
        /// </summary>
        public bool IsHeaderField09NotInput { get; private set; }

        /// <summary>
        /// ヘッダーフィールド10未入力チェック結果
        /// </summary>
        public bool IsHeaderField10NotInput { get; private set; }

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールド未入力チェック結果を取得します
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールド未入力チェック結果</returns>
        public bool GetIsHeaderFieldNotInput(int no)
        {
            switch (no)
            {
                case 1:
                    return this.IsHeaderField01NotInput;

                case 2:
                    return this.IsHeaderField02NotInput;

                case 3:
                    return this.IsHeaderField03NotInput;

                case 4:
                    return this.IsHeaderField04NotInput;

                case 5:
                    return this.IsHeaderField05NotInput;

                case 6:
                    return this.IsHeaderField06NotInput;

                case 7:
                    return this.IsHeaderField07NotInput;

                case 8:
                    return this.IsHeaderField08NotInput;

                case 9:
                    return this.IsHeaderField09NotInput;

                case 10:
                    return this.IsHeaderField10NotInput;

                default:
                    return false;
            }
        }

        /// <summary>
        /// ヘッダーフィールド未入力チェック結果を設定します。
        /// </summary>
        /// <param name="headerFieldNo">ヘッダーフィールドNo</param>
        /// <param name="headerFieldCode">ヘッダーフィールドコード</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目・条件が多いため、分割困難")]
        public void SetIsHeaderFieldNotInput(int headerFieldNo, string headerFieldCode, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var isHeaderFieldNotInput = queryParameter.IsUseNotInputCheckOptionForGetSiwakeTyouhyou
                ? string.IsNullOrEmpty(headerFieldCode) && queryParameter.GetHeaderFieldNotInputCheckForDenpyouSyuusei(headerFieldNo) && queryParameter.NotInputCheckOption.GetHeaderFieldNotInputCheck(headerFieldNo)
                : string.IsNullOrEmpty(headerFieldCode) && queryParameter.NotInputCheckOption.GetHeaderFieldNotInputCheck(headerFieldNo);
            switch (headerFieldNo)
            {
                case 1:
                    this.IsHeaderField01NotInput = isHeaderFieldNotInput;
                    break;
                case 2:
                    this.IsHeaderField02NotInput = isHeaderFieldNotInput;
                    break;
                case 3:
                    this.IsHeaderField03NotInput = isHeaderFieldNotInput;
                    break;
                case 4:
                    this.IsHeaderField04NotInput = isHeaderFieldNotInput;
                    break;
                case 5:
                    this.IsHeaderField05NotInput = isHeaderFieldNotInput;
                    break;
                case 6:
                    this.IsHeaderField06NotInput = isHeaderFieldNotInput;
                    break;
                case 7:
                    this.IsHeaderField07NotInput = isHeaderFieldNotInput;
                    break;
                case 8:
                    this.IsHeaderField08NotInput = isHeaderFieldNotInput;
                    break;
                case 9:
                    this.IsHeaderField09NotInput = isHeaderFieldNotInput;
                    break;
                case 10:
                    this.IsHeaderField10NotInput = isHeaderFieldNotInput;
                    break;
                default:
                    break;
            }
        }

        #endregion
    }
}
