﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public interface IDataScanHukugouSiwakeTyouhyouRepository
    {
        /// <summary>
        /// 仕訳帳票問合せパラメータ及び伝票を条件として、複合仕訳帳票を取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="denpyou">伝票</param>
        /// <returns>複合仕訳帳票</returns>
        DataScanHukugouSiwakeTyouhyou FindByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter, ISiwakeTyouhyouDenpyouRow denpyou);

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、伝票リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>伝票リスト</returns>
        IList<ISiwakeTyouhyouDenpyouRow> FindDenpyouListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);

        /// <summary>
        /// 仕訳帳票問合せパラメータを条件として、部門リストを取得します。
        /// </summary>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>部門リスト</returns>
        IList<Bumon> FindBumonListByQueryParameter(ISiwakeTyouhyouQueryParameter queryParameter);
    }
}