﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;

    /// <summary>
    /// データスキャン複合仕訳帳票
    /// </summary>
    public class DataScanHukugouSiwakeTyouhyou
    {
        public DataScanHukugouSiwakeTyouhyou(ISiwakeTyouhyouQueryParameter queryParameter)
        {
            this.QueryParameter = queryParameter;
        }

        #region プロパティ

        /// <summary>
        /// 借方合計金額
        /// </summary>
        public decimal SiwakeKarikataTotalKingaku { get; set; }

        /// <summary>
        /// 貸方合計金額
        /// </summary>
        public decimal SiwakeKasikataTotalKingaku { get; set; }

        /// <summary>
        /// 伝票件数
        /// </summary>
        public int DenpyouCount { get; set; }

        /// <summary>
        /// 複合仕訳帳票行リスト
        /// </summary>
        public IList<HukugouSiwakeTyouhyouRow> SiwakeTyouhyouRows { get; set; } = new List<HukugouSiwakeTyouhyouRow>();

        /// <summary>
        /// 仕訳帳票問合せパラメータ
        /// </summary>
        public ISiwakeTyouhyouQueryParameter QueryParameter { get; set; }

        #endregion
    }
}
