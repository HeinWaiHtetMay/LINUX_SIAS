﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;

    public interface IHukugouSiwakeTyouhyouRowFactory
    {
        /// <summary>
        /// 複合仕訳帳票の行データリストを作成します。
        /// </summary>
        /// <param name="tanituSiwakeTyouhyouRows">単一仕訳帳票の行データリスト</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>複合仕訳帳票の行データリスト</returns>
        IList<HukugouSiwakeTyouhyouRow> CreateHukugouSiwakeTyouhyouRows(IList<TanituSiwakeTyouhyouRow> tanituSiwakeTyouhyouRows, ISiwakeTyouhyouQueryParameter queryParameter);
    }
}