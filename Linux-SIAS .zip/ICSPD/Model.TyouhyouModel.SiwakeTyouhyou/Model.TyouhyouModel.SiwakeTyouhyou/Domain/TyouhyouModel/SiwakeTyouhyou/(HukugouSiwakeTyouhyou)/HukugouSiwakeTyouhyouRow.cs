﻿using Icsp.Open21.Domain.DenpyouModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// 複合仕訳帳票の行データ
    /// </summary>
    public class HukugouSiwakeTyouhyouRow
    {
        private TanituSiwakeTyouhyouRow tanituSiwakeTyouhyouRow;

        public HukugouSiwakeTyouhyouRow(TanituSiwakeTyouhyouRow tanituSiwakeTyouhyouRow)
        {
            this.tanituSiwakeTyouhyouRow = tanituSiwakeTyouhyouRow;
        }

        #region プロパティ

        #region 伝票項目

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn => this.tanituSiwakeTyouhyouRow.Kesn;

        /// <summary>
        /// 経過月（カラム名：dkei）
        /// </summary>
        public int Dkei => this.tanituSiwakeTyouhyouRow.Dkei;

        /// <summary>
        /// 伝票SEQNo.（カラム名：dseq）
        /// </summary>
        public int Dseq => this.tanituSiwakeTyouhyouRow.Dseq;

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        public int? DenpyouNo => this.tanituSiwakeTyouhyouRow.DenpyouNo;

        /// <summary>
        /// 受付番号（カラム名：duno）
        /// </summary>
        public int UketukeNo => this.tanituSiwakeTyouhyouRow.UketukeNo;

        #endregion

        #region 仕訳項目

        /// <summary>
        /// 仕訳帳票の借方データ
        /// </summary>
        public HukugouSiwakeTyouhyouTaisyakubetuDetail KarikataDetail { get; set; }

        /// <summary>
        /// 仕訳帳票の貸方データ
        /// </summary>
        public HukugouSiwakeTyouhyouTaisyakubetuDetail KasikataDetail { get; set; }

        /// <summary>
        /// グループ番号（カラム名：grno）
        /// </summary>
        public int? GroupNo => this.tanituSiwakeTyouhyouRow.GroupNo;

        /// <summary>
        /// 行番号（カラム名：dlin）
        /// </summary>
        public int? LineNo => this.tanituSiwakeTyouhyouRow.LineNo;

        /// <summary>
        /// 取消仕訳かどうか（カラム名：delf）
        /// </summary>
        public bool IsTorikesiSiwake => this.tanituSiwakeTyouhyouRow.IsTorikesiSiwake;

        /// <summary>
        /// 貸借摘要フラグ（カラム名：tekiflg）
        /// </summary>
        public TaisyakuTekiyouFlag TaisyakuTekiyouFlag => this.tanituSiwakeTyouhyouRow.TaisyakuTekiyouFlag;

        #endregion

        #region その他項目

        /// <summary>
        /// コメントが入力されているかどうか
        /// </summary>
        public bool IsInputedComment => this.tanituSiwakeTyouhyouRow.IsInputedComment;

        #endregion

        #endregion
    }
}
