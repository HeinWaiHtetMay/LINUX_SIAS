﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;

    /// <summary>
    /// 仕訳帳票伝票
    /// </summary>
    public interface ISiwakeTyouhyouDenpyouRow : IDenpyouKey
    {
        #region プロパティ

        #region 伝票項目

        /// <summary>
        /// 内部決算期番号（カラム名：kesn）
        /// </summary>
        int Kesn { get; }

        /// <summary>
        /// 伝票SEQNo.（カラム名：dseq）
        /// </summary>
        int Dseq { get; }

        /// <summary>
        /// 伝票日付（カラム名：dymd）
        /// </summary>
        IcspDateTime DenpyouDate { get; set; }

        /// <summary>
        /// 伝票番号（カラム名：dcno）
        /// </summary>
        int? DenpyouNo { get; set; }

        /// <summary>
        /// 起票日（カラム名：kymd）
        /// </summary>
        IcspDateTime KihyouDate { get; set; }

        /// <summary>
        /// 起票部門コード（カラム名：kbmn）
        /// </summary>
        string KihyouBumonCode { get; set; }

        /// <summary>
        /// 起票者コード（カラム名：kusr）
        /// </summary>
        string KihyouTantousyaCode { get; set; }

        /// <summary>
        /// 伝票作成日（カラム名：fmod）
        /// </summary>
        IcspDateTime DenpyouCreateDate { get; set; }

        /// <summary>
        /// 伝票作成者コード（カラム名：fusr）
        /// </summary>
        int DenpyouCreateUserCode { get; set; }

        /// <summary>
        /// 伝票更新日（カラム名：lmod）
        /// </summary>
        IcspDateTime DenpyouUpdateDate { get; set; }

        /// <summary>
        /// 伝票更新者コード（カラム名：lusr）
        /// </summary>
        int DenpyouUpdateUserCode { get; set; }

        /// <summary>
        /// 受付番号（カラム名：duno）
        /// </summary>
        int UketukeNo { get; set; }

        /// <summary>
        /// 入力確定日（カラム名：kday）
        /// </summary>
        IcspDateTime InputKakuteiDate { get; set; }

        /// <summary>
        /// 承認グループNo（カラム名：sgno）
        /// </summary>
        int SyouninGroupNo { get; set; }

        /// <summary>
        /// 判定済最上位承認者順序（カラム名：hjno）
        /// </summary>
        int HanteizumiTopSyouninUserOrder { get; set; }

        /// <summary>
        /// 承認状況（カラム名：sflg）
        /// </summary>
        SyouninStatus SyouninStatus { get; set; }

        /// <summary>
        /// 第一承認者コード（カラム名：sn01）
        /// </summary>
        int Dai1SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第一承認判定（カラム名：sf01）
        /// </summary>
        SyouninStatus Dai1SyouninStatus { get; set; }

        /// <summary>
        /// 第二承認者コード（カラム名：sn02）
        /// </summary>
        int Dai2SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第二承認判定（カラム名：sf02）
        /// </summary>
        SyouninStatus Dai2SyouninStatus { get; set; }

        /// <summary>
        /// 第三承認者コード（カラム名：sn03）
        /// </summary>
        int Dai3SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第三承認判定（カラム名：sf03）
        /// </summary>
        SyouninStatus Dai3SyouninStatus { get; set; }

        /// <summary>
        /// 第四承認者コード（カラム名：sn04）
        /// </summary>
        int Dai4SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第四承認判定（カラム名：sf04）
        /// </summary>
        SyouninStatus Dai4SyouninStatus { get; set; }

        /// <summary>
        /// 第五承認者コード（カラム名：sn05）
        /// </summary>
        int Dai5SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第五承認判定（カラム名：sf05）
        /// </summary>
        SyouninStatus Dai5SyouninStatus { get; set; }

        /// <summary>
        /// 第六承認者コード（カラム名：sn06）
        /// </summary>
        int Dai6SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第六承認判定（カラム名：sf06）
        /// </summary>
        SyouninStatus Dai6SyouninStatus { get; set; }

        /// <summary>
        /// 第七承認者コード（カラム名：sn07）
        /// </summary>
        int Dai7SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第七承認判定（カラム名：sf07）
        /// </summary>
        SyouninStatus Dai7SyouninStatus { get; set; }

        /// <summary>
        /// 第八承認者コード（カラム名：sn08）
        /// </summary>
        int Dai8SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第八承認判定（カラム名：sf08）
        /// </summary>
        SyouninStatus Dai8SyouninStatus { get; set; }

        /// <summary>
        /// 第九承認者コード（カラム名：sn09）
        /// </summary>
        int Dai9SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第九承認判定（カラム名：sf09）
        /// </summary>
        SyouninStatus Dai9SyouninStatus { get; set; }

        /// <summary>
        /// 第十承認者コード（カラム名：sn10）
        /// </summary>
        int Dai10SyouninsyaUserCode { get; set; }

        /// <summary>
        /// 第十承認判定（カラム名：sf10）
        /// </summary>
        SyouninStatus Dai10SyouninStatus { get; set; }

        /// <summary>
        /// ヘッダーフィールド1コード（カラム名：duf1）
        /// </summary>
        string Hfcd01 { get; set; }

        /// <summary>
        /// ヘッダーフィールド2コード（カラム名：duf2）
        /// </summary>
        string Hfcd02 { get; set; }

        /// <summary>
        /// ヘッダーフィールド3コード（カラム名：duf3）
        /// </summary>
        string Hfcd03 { get; set; }

        /// <summary>
        /// ヘッダーフィールド4コード（カラム名：duf4）
        /// </summary>
        string Hfcd04 { get; set; }

        /// <summary>
        /// ヘッダーフィールド5コード（カラム名：duf5）
        /// </summary>
        string Hfcd05 { get; set; }

        /// <summary>
        /// ヘッダーフィールド6コード（カラム名：duf6）
        /// </summary>
        string Hfcd06 { get; set; }

        /// <summary>
        /// ヘッダーフィールド7コード（カラム名：duf7）
        /// </summary>
        string Hfcd07 { get; set; }

        /// <summary>
        /// ヘッダーフィールド8コード（カラム名：duf8）
        /// </summary>
        string Hfcd08 { get; set; }

        /// <summary>
        /// ヘッダーフィールド9コード（カラム名：duf9）
        /// </summary>
        string Hfcd09 { get; set; }

        /// <summary>
        /// ヘッダーフィールド10コード（カラム名：duf10）
        /// </summary>
        string Hfcd10 { get; set; }

        /// <summary>
        /// 未完伝票かどうか（カラム名：bflg）
        /// </summary>
        bool IsMikanDenpyou { get; set; }

        #endregion

        #region その他項目

        /// <summary>
        /// 起票部門名称
        /// </summary>
        string KihyouBumonName { get; set; }

        /// <summary>
        /// 起票者名称
        /// </summary>
        string KihyouTantousyaName { get; set; }

        /// <summary>
        /// 伝票作成者名称
        /// </summary>
        string DenpyouCreateUserName { get; set; }

        /// <summary>
        /// 伝票更新者名称
        /// </summary>
        string DenpyouUpdateUserName { get; set; }

        /// <summary>
        /// 第一承認者名称
        /// </summary>
        string Dai1SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第二承認者名称
        /// </summary>
        string Dai2SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第三承認者名称
        /// </summary>
        string Dai3SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第四承認者名称
        /// </summary>
        string Dai4SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第五承認者名称
        /// </summary>
        string Dai5SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第六承認者名称
        /// </summary>
        string Dai6SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第七承認者名称
        /// </summary>
        string Dai7SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第八承認者名称
        /// </summary>
        string Dai8SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第九承認者名称
        /// </summary>
        string Dai9SyouninsyaUserName { get; set; }

        /// <summary>
        /// 第十承認者名称
        /// </summary>
        string Dai10SyouninsyaUserName { get; set; }

        /// <summary>
        /// ヘッダーフィールド1名称
        /// </summary>
        string HeaderField01Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド2名称
        /// </summary>
        string HeaderField02Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド3名称
        /// </summary>
        string HeaderField03Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド4名称
        /// </summary>
        string HeaderField04Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド5名称
        /// </summary>
        string HeaderField05Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド6名称
        /// </summary>
        string HeaderField06Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド7名称
        /// </summary>
        string HeaderField07Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド8名称
        /// </summary>
        string HeaderField08Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド9名称
        /// </summary>
        string HeaderField09Name { get; set; }

        /// <summary>
        /// ヘッダーフィールド10名称
        /// </summary>
        string HeaderField10Name { get; set; }

        /// <summary>
        /// 伝票束コード
        /// </summary>
        string DenpyouTabaCode { get; set; }

        /// <summary>
        /// 伝票項目未入力チェック結果
        /// </summary>
        DenpyouItemNotInputCheckResult DenpyouItemNotInputCheckResult { get; set; }

        /// <summary>
        /// 未転記データかどうか
        /// </summary>
        bool IsMitenkiData { get; set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// ヘッダーフィールドコードを取得します
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールドコード</returns>
        string GetHeaderFieldCode(int no);

        /// <summary>
        /// ヘッダーフィールド名称を取得します
        /// </summary>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <returns>ヘッダーフィールド名称</returns>
        string GetHeaderFieldName(int no);

        #endregion
    }
}
