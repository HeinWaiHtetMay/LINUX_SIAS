﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.HonsitenModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 複合仕訳帳票の貸借別データ
    /// </summary>
    public class HukugouSiwakeTyouhyouTaisyakubetuDetail
    {
        private TanituSiwakeTyouhyouRow tanituSiwakeTyouhyouRow;
        private TanituSiwakeTyouhyouTaisyakubetuDetail tanituSiwakeTyouhyouTaisyakubetuDetail;

        public HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei siwakeTaisyakuZokusei, TanituSiwakeTyouhyouRow tanituSiwakeTyouhyouRow, TanituSiwakeTyouhyouTaisyakubetuDetail taisyakubetuDetail, decimal aiteSyokutiKingaku)
        {
            this.SiwakeTaisyakuZokusei = siwakeTaisyakuZokusei;
            this.tanituSiwakeTyouhyouRow = tanituSiwakeTyouhyouRow;
            this.tanituSiwakeTyouhyouTaisyakubetuDetail = taisyakubetuDetail;
            this.AiteSyokutiKingaku = aiteSyokutiKingaku;
        }

        #region プロパティ

        #region 仕訳項目

        /// <summary>
        /// 貸借属性（カラム名：dflg）
        /// </summary>
        public SiwakeTaisyakuZokusei SiwakeTaisyakuZokusei { get; private set; }

        /// <summary>
        /// 仕訳SEQNo.（カラム名：sseq）
        /// </summary>
        public int Sseq => this.tanituSiwakeTyouhyouRow.Sseq;

        /// <summary>
        /// 親子フラグ（カラム名：pflg）
        /// </summary>
        public SiwakeParentChildRelated SiwakeParentChildRelated => this.tanituSiwakeTyouhyouRow.SiwakeParentChildRelated;

        /// <summary>
        /// 分離区分（カラム名：bkbn）
        /// </summary>
        public BunriKubun BunriKubun => this.tanituSiwakeTyouhyouRow.BunriKubun;

        /// <summary>
        /// 部門コード（カラム名：rbmn, sbmn）
        /// </summary>
        public string Bcod => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Bcod;

        /// <summary>
        /// 取引先コード（カラム名：rtor, stor）
        /// </summary>
        public string Trcd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Trcd;

        /// <summary>
        /// 科目内部コード（カラム名：rkmk, skmk）
        /// </summary>
        public string Kicd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Kicd;

        /// <summary>
        /// 枝番コード（カラム名：reda, seda）
        /// </summary>
        public string Ecod => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ecod;

        /// <summary>
        /// 工事コード（カラム名：rkoj, skoj）
        /// </summary>
        public string Kzcd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Kzcd;

        /// <summary>
        /// 工種コード（カラム名：rkos, skos）
        /// </summary>
        public string Kscd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Kscd;

        /// <summary>
        /// プロジェクトコード（カラム名：rprj, sprj）
        /// </summary>
        public string Pjcd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Pjcd;

        /// <summary>
        /// セグメントコード（カラム名：rseg, sseg）
        /// </summary>
        public string Sgcd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Sgcd;

        /// <summary>
        /// ユニバーサルフィールド1コード（カラム名：rdm1, sdm1）
        /// </summary>
        public string Ufcd01 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd01;

        /// <summary>
        /// ユニバーサルフィールド2コード（カラム名：rdm2, sdm2）
        /// </summary>
        public string Ufcd02 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd02;

        /// <summary>
        /// ユニバーサルフィールド3コード（カラム名：rdm3, sdm3）
        /// </summary>
        public string Ufcd03 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd03;

        /// <summary>
        /// ユニバーサルフィールド4コード（カラム名：rdm4, sdm4）
        /// </summary>
        public string Ufcd04 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd04;

        /// <summary>
        /// ユニバーサルフィールド5コード（カラム名：rdm5, sdm5）
        /// </summary>
        public string Ufcd05 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd05;

        /// <summary>
        /// ユニバーサルフィールド6コード（カラム名：rdm6, sdm6）
        /// </summary>
        public string Ufcd06 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd06;

        /// <summary>
        /// ユニバーサルフィールド7コード（カラム名：rdm7, sdm7）
        /// </summary>
        public string Ufcd07 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd07;

        /// <summary>
        /// ユニバーサルフィールド8コード（カラム名：rdm8, sdm8）
        /// </summary>
        public string Ufcd08 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd08;

        /// <summary>
        /// ユニバーサルフィールド9コード（カラム名：rdm9, sdm9）
        /// </summary>
        public string Ufcd09 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd09;

        /// <summary>
        /// ユニバーサルフィールド10コード（カラム名：rdm10, sdm10）
        /// </summary>
        public string Ufcd10 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd10;

        /// <summary>
        /// ユニバーサルフィールド11コード（カラム名：rdm11, sdm11）
        /// </summary>
        public string Ufcd11 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd11;

        /// <summary>
        /// ユニバーサルフィールド12コード（カラム名：rdm12, sdm12）
        /// </summary>
        public string Ufcd12 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd12;

        /// <summary>
        /// ユニバーサルフィールド13コード（カラム名：rdm13, sdm13）
        /// </summary>
        public string Ufcd13 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd13;

        /// <summary>
        /// ユニバーサルフィールド14コード（カラム名：rdm14, sdm14）
        /// </summary>
        public string Ufcd14 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd14;

        /// <summary>
        /// ユニバーサルフィールド15コード（カラム名：rdm15, sdm15）
        /// </summary>
        public string Ufcd15 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd15;

        /// <summary>
        /// ユニバーサルフィールド16コード（カラム名：rdm16, sdm16）
        /// </summary>
        public string Ufcd16 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd16;

        /// <summary>
        /// ユニバーサルフィールド17コード（カラム名：rdm17, sdm17）
        /// </summary>
        public string Ufcd17 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd17;

        /// <summary>
        /// ユニバーサルフィールド18コード（カラム名：rdm18, sdm18）
        /// </summary>
        public string Ufcd18 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd18;

        /// <summary>
        /// ユニバーサルフィールド19コード（カラム名：rdm19, sdm19）
        /// </summary>
        public string Ufcd19 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd19;

        /// <summary>
        /// ユニバーサルフィールド20コード（カラム名：rdm20, sdm20）
        /// </summary>
        public string Ufcd20 => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Ufcd20;

        /// <summary>
        /// 摘要（カラム名：rtky, stky）
        /// </summary>
        public string Tekiyou => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Tekiyou;

        /// <summary>
        /// 摘要コード（カラム名：rtno, stno）
        /// </summary>
        public int? TekiyouCode => this.tanituSiwakeTyouhyouTaisyakubetuDetail.TekiyouCode;

        /// <summary>
        /// 対価金額の入力があるかどうか（カラム名：tflg）
        /// </summary>
        public bool IsInputTaikaKingaku => this.tanituSiwakeTyouhyouRow.IsInputTaikaKingaku;

        /// <summary>
        /// 対価金額（カラム名：exvl）
        /// </summary>
        public decimal? TaikaKingaku => this.tanituSiwakeTyouhyouRow.TaikaKingaku;

        /// <summary>
        /// 税込金額（カラム名：zkvl）
        /// </summary>
        public decimal? ZeikomiKingaku => this.tanituSiwakeTyouhyouRow.ZeikomiKingaku;

        /// <summary>
        /// 金額（カラム名：valu）
        /// </summary>
        public decimal? Kingaku => this.tanituSiwakeTyouhyouRow.Kingaku;

        /// <summary>
        /// 税対象科目 科目内部コード（カラム名：zkmk）
        /// </summary>
        public string SyouhizeiTaisyouKicd => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKicd;

        /// <summary>
        /// 税対象科目 税率（カラム名：zrit, zkeigen）（未設定の場合はnull）
        /// </summary>
        public Syouhizeiritu SyouhizeiTaisyouKamokuSyouhizeiritu => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuSyouhizeiritu;

        /// <summary>
        /// 税対象科目 課税区分（カラム名：zzkb）
        /// </summary>
        public KazeiKubun? SyouhizeiTaisyouKamokuKazeiKubun => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuKazeiKubun;

        /// <summary>
        /// 税対象科目 業種区分（カラム名：zgyo）
        /// </summary>
        public GyousyuKubun? SyouhizeiTaisyouKamokuGyousyuKubun => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuGyousyuKubun;

        /// <summary>
        /// 税対象科目 仕入区分（カラム名：zsre）
        /// </summary>
        public SiwakeSiireKubun? SyouhizeiTaisyouKamokuSiireKubun => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuSiireKubun;

        /// <summary>
        /// 税率（カラム名：rrit, rkeigen, srit, skeigen）（未設定の場合はnull）
        /// </summary>
        public Syouhizeiritu Syouhizeiritu => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Syouhizeiritu;

        /// <summary>
        /// 課税区分（カラム名：rzkb, szkb）
        /// </summary>
        public KazeiKubun? KazeiKubun => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KazeiKubun;

        /// <summary>
        /// 業種区分（カラム名：rgyo, sgyo）
        /// </summary>
        public GyousyuKubun? GyousyuKubun => this.tanituSiwakeTyouhyouTaisyakubetuDetail.GyousyuKubun;

        /// <summary>
        /// 仕入区分（カラム名：rsre, ssre）
        /// </summary>
        public SiwakeSiireKubun? SiwakeSiireKubun => this.tanituSiwakeTyouhyouTaisyakubetuDetail.SiwakeSiireKubun;

        /// <summary>
        /// 一括税抜仕訳フラグ（カラム名：ifri）
        /// </summary>
        public IkkatuZeinukiSiwakeFlag IkkatuZeinukiSiwakeFlag => this.tanituSiwakeTyouhyouRow.IkkatuZeinukiSiwakeFlag;

        /// <summary>
        /// 支払日（カラム名：symd）
        /// </summary>
        public IcspDateTime SiharaiDate => this.tanituSiwakeTyouhyouRow.SiharaiDate;

        /// <summary>
        /// 支払区分コード（カラム名：skbn）
        /// </summary>
        public int? SiharaiKubunCode => this.tanituSiwakeTyouhyouRow.SiharaiKubunCode;

        /// <summary>
        /// 支払期日（カラム名：skiz）
        /// </summary>
        public IcspDateTime SiharaiKizitu => this.tanituSiwakeTyouhyouRow.SiharaiKizitu;

        /// <summary>
        /// 回収日（カラム名：uymd）
        /// </summary>
        public IcspDateTime KaisyuuDate => this.tanituSiwakeTyouhyouRow.KaisyuuDate;

        /// <summary>
        /// 入金区分コード（カラム名：ukbn）
        /// </summary>
        public int? NyuukinKubunCode => this.tanituSiwakeTyouhyouRow.NyuukinKubunCode;

        /// <summary>
        /// 回収期日（カラム名：ukiz）
        /// </summary>
        public IcspDateTime KaisyuuKizitu => this.tanituSiwakeTyouhyouRow.KaisyuuKizitu;

        /// <summary>
        /// 消込コード（カラム名：dkec）
        /// </summary>
        public string KesikomiCode => this.tanituSiwakeTyouhyouRow.KesikomiCode;

        /// <summary>
        /// 仕訳作成日（カラム名：fmod）
        /// </summary>
        public IcspDateTime SiwakeCreateDate => this.tanituSiwakeTyouhyouRow.SiwakeCreateDate;

        /// <summary>
        /// 仕訳作成者コード（カラム名：fusr）
        /// </summary>
        public int SiwakeCreateUserCode => this.tanituSiwakeTyouhyouRow.SiwakeCreateUserCode;

        /// <summary>
        /// 仕訳更新日（カラム名：lmod）
        /// </summary>
        public IcspDateTime SiwakeUpdateDate => this.tanituSiwakeTyouhyouRow.SiwakeUpdateDate;

        /// <summary>
        /// 仕訳更新時間（カラム名：ltim）
        /// </summary>
        public int SiwakeUpdateTime => this.tanituSiwakeTyouhyouRow.SiwakeUpdateTime;

        /// <summary>
        /// 仕訳更新者コード（カラム名：lusr）
        /// </summary>
        public int SiwakeUpdateUserCode => this.tanituSiwakeTyouhyouRow.SiwakeUpdateUserCode;

        /// <summary>
        /// 通貨コード（カラム名：rhei_cd, shei_cd）
        /// </summary>
        public string HeisyuCode => this.tanituSiwakeTyouhyouTaisyakubetuDetail.HeisyuCode;

        /// <summary>
        /// レート（カラム名：rate）
        /// </summary>
        public decimal? Rate => this.tanituSiwakeTyouhyouRow.Rate;

        /// <summary>
        /// 外貨金額（カラム名：gaika）
        /// </summary>
        public decimal? GaikaKingaku => this.tanituSiwakeTyouhyouRow.GaikaKingaku;

        /// <summary>
        /// 外貨対価金額（カラム名：gexvl）
        /// </summary>
        public decimal? GaikaTaikaKingaku => this.tanituSiwakeTyouhyouRow.GaikaTaikaKingaku;

        /// <summary>
        /// 外貨税込金額（カラム名：gzkvl）
        /// </summary>
        public decimal? GaikaZeikomiKingaku => this.tanituSiwakeTyouhyouRow.GaikaZeikomiKingaku;

        /// <summary>
        /// 否認仕訳かどうか（カラム名：hflg）
        /// </summary>
        public bool IsHininSiwake => this.tanituSiwakeTyouhyouRow.IsHininSiwake;

        #endregion

        #region 本支店項目

        /// <summary>
        /// 本支店展開前の仕訳SEQNo.（カラム名：osseq）
        /// </summary>
        public int SseqBeforeHonsitenTenkai => this.tanituSiwakeTyouhyouRow.SseqBeforeHonsitenTenkai;

        /// <summary>
        /// 本支店勘定設定フラグ（カラム名：rsflg, ssflg）
        /// </summary>
        public HonsitenKanzyouSetFlag HonsitenKanzyouSetFlag => this.tanituSiwakeTyouhyouTaisyakubetuDetail.HonsitenKanzyouSetFlag;

        /// <summary>
        /// 部門が入力されているかどうか（カラム名：rbreg, sbreg）
        /// </summary>
        public bool IsInputedBumon => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsInputedBumon;

        /// <summary>
        /// 本支店展開明細テーブル（hstbl_m）に、部門が登録されているかどうか（カラム名：rbinp, sbinp）
        /// </summary>
        public bool IsRegisteredBumonToHonsitenTenkaiMeisaiTable => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsRegisteredBumonToHonsitenTenkaiMeisaiTable;

        /// <summary>
        /// 部門科目残高テーブル（bkzan）に、部門科目が登録されているかどうか（カラム名：rbkinp, sbkinp）
        /// </summary>
        public bool IsRegisteredBumonKamokuToBumonKamokuZandakaTable => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsRegisteredBumonKamokuToBumonKamokuZandakaTable;

        #endregion

        #region その他項目

        /// <summary>
        /// 部門名称
        /// </summary>
        public string BumonName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.BumonName;

        /// <summary>
        /// 取引先名称
        /// </summary>
        public string TorihikisakiName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.TorihikisakiName;

        /// <summary>
        /// 取引先正式名称
        /// </summary>
        public string TorihikisakiLongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.TorihikisakiLongName;

        /// <summary>
        /// 科目入力コード
        /// </summary>
        public string Kcod => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Kcod;

        /// <summary>
        /// 処理グループ
        /// </summary>
        public KamokuSyoriGroup KamokuSyoriGroup => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KamokuSyoriGroup;

        /// <summary>
        /// 科目が対価金額入力可能であるかどうか
        /// </summary>
        public bool IsInputTaikaKingakuKamoku => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsInputTaikaKingakuKamoku
                && (this.tanituSiwakeTyouhyouTaisyakubetuDetail.KamokuSyoriGroup == KamokuSyoriGroup.Sisan || this.tanituSiwakeTyouhyouTaisyakubetuDetail.KamokuSyoriGroup == KamokuSyoriGroup.Yuukasyoken);

        /// <summary>
        /// 科目が消し込み対象であるかどうか
        /// </summary>
        public bool IsKesikomiTaisyouKamoku => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsKesikomiTaisyouKamoku;

        /// <summary>
        /// 科目名称
        /// </summary>
        public string KamokuName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KamokuName;

        /// <summary>
        /// 科目正式名称
        /// </summary>
        public string KamokuLongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KamokuLongName;

        /// <summary>
        /// 枝番名称
        /// </summary>
        public string EdabanName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.EdabanName;

        /// <summary>
        /// 工事名称
        /// </summary>
        public string KouziName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KouziName;

        /// <summary>
        /// 工事正式名称
        /// </summary>
        public string KouziLongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KouziLongName;

        /// <summary>
        /// 工種名称
        /// </summary>
        public string KousyuName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.KousyuName;

        /// <summary>
        /// プロジェクト名称
        /// </summary>
        public string ProjectName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.ProjectName;

        /// <summary>
        /// プロジェクト正式名称
        /// </summary>
        public string ProjectLongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.ProjectLongName;

        /// <summary>
        /// セグメント名称
        /// </summary>
        public string SegmentName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.SegmentName;

        /// <summary>
        /// セグメント正式名称
        /// </summary>
        public string SegmentLongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.SegmentLongName;

        /// <summary>
        /// ユニバーサルフィールド1名称
        /// </summary>
        public string UniversalField01Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField01Name;

        /// <summary>
        /// ユニバーサルフィールド2名称
        /// </summary>
        public string UniversalField02Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField02Name;

        /// <summary>
        /// ユニバーサルフィールド3名称
        /// </summary>
        public string UniversalField03Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField03Name;

        /// <summary>
        /// ユニバーサルフィールド4名称
        /// </summary>
        public string UniversalField04Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField04Name;

        /// <summary>
        /// ユニバーサルフィールド5名称
        /// </summary>
        public string UniversalField05Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField05Name;

        /// <summary>
        /// ユニバーサルフィールド6名称
        /// </summary>
        public string UniversalField06Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField06Name;

        /// <summary>
        /// ユニバーサルフィールド7名称
        /// </summary>
        public string UniversalField07Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField07Name;

        /// <summary>
        /// ユニバーサルフィールド8名称
        /// </summary>
        public string UniversalField08Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField08Name;

        /// <summary>
        /// ユニバーサルフィールド9名称
        /// </summary>
        public string UniversalField09Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField09Name;

        /// <summary>
        /// ユニバーサルフィールド10名称
        /// </summary>
        public string UniversalField10Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField10Name;

        /// <summary>
        /// ユニバーサルフィールド11名称
        /// </summary>
        public string UniversalField11Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField11Name;

        /// <summary>
        /// ユニバーサルフィールド12名称
        /// </summary>
        public string UniversalField12Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField12Name;

        /// <summary>
        /// ユニバーサルフィールド13名称
        /// </summary>
        public string UniversalField13Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField13Name;

        /// <summary>
        /// ユニバーサルフィールド14名称
        /// </summary>
        public string UniversalField14Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField14Name;

        /// <summary>
        /// ユニバーサルフィールド15名称
        /// </summary>
        public string UniversalField15Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField15Name;

        /// <summary>
        /// ユニバーサルフィールド16名称
        /// </summary>
        public string UniversalField16Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField16Name;

        /// <summary>
        /// ユニバーサルフィールド17名称
        /// </summary>
        public string UniversalField17Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField17Name;

        /// <summary>
        /// ユニバーサルフィールド18名称
        /// </summary>
        public string UniversalField18Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField18Name;

        /// <summary>
        /// ユニバーサルフィールド19名称
        /// </summary>
        public string UniversalField19Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField19Name;

        /// <summary>
        /// ユニバーサルフィールド20名称
        /// </summary>
        public string UniversalField20Name => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField20Name;

        /// <summary>
        /// ユニバーサルフィールド1正式名称
        /// </summary>
        public string UniversalField01LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField01LongName;

        /// <summary>
        /// ユニバーサルフィールド2正式名称
        /// </summary>
        public string UniversalField02LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField02LongName;

        /// <summary>
        /// ユニバーサルフィールド3正式名称
        /// </summary>
        public string UniversalField03LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField03LongName;

        /// <summary>
        /// ユニバーサルフィールド4正式名称
        /// </summary>
        public string UniversalField04LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField04LongName;

        /// <summary>
        /// ユニバーサルフィールド5正式名称
        /// </summary>
        public string UniversalField05LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField05LongName;

        /// <summary>
        /// ユニバーサルフィールド6正式名称
        /// </summary>
        public string UniversalField06LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField06LongName;

        /// <summary>
        /// ユニバーサルフィールド7正式名称
        /// </summary>
        public string UniversalField07LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField07LongName;

        /// <summary>
        /// ユニバーサルフィールド8正式名称
        /// </summary>
        public string UniversalField08LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField08LongName;

        /// <summary>
        /// ユニバーサルフィールド9正式名称
        /// </summary>
        public string UniversalField09LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField09LongName;

        /// <summary>
        /// ユニバーサルフィールド10正式名称
        /// </summary>
        public string UniversalField10LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField10LongName;

        /// <summary>
        /// ユニバーサルフィールド11正式名称
        /// </summary>
        public string UniversalField11LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField11LongName;

        /// <summary>
        /// ユニバーサルフィールド12正式名称
        /// </summary>
        public string UniversalField12LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField12LongName;

        /// <summary>
        /// ユニバーサルフィールド13正式名称
        /// </summary>
        public string UniversalField13LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField13LongName;

        /// <summary>
        /// ユニバーサルフィールド14正式名称
        /// </summary>
        public string UniversalField14LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField14LongName;

        /// <summary>
        /// ユニバーサルフィールド15正式名称
        /// </summary>
        public string UniversalField15LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField15LongName;

        /// <summary>
        /// ユニバーサルフィールド16正式名称
        /// </summary>
        public string UniversalField16LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField16LongName;

        /// <summary>
        /// ユニバーサルフィールド17正式名称
        /// </summary>
        public string UniversalField17LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField17LongName;

        /// <summary>
        /// ユニバーサルフィールド18正式名称
        /// </summary>
        public string UniversalField18LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField18LongName;

        /// <summary>
        /// ユニバーサルフィールド19正式名称
        /// </summary>
        public string UniversalField19LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField19LongName;

        /// <summary>
        /// ユニバーサルフィールド20正式名称
        /// </summary>
        public string UniversalField20LongName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.UniversalField20LongName;

        /// <summary>
        /// 摘要名称
        /// </summary>
        public string TekiyouName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.TekiyouName;

        /// <summary>
        /// 税対象科目 科目入力コード
        /// </summary>
        public string SyouhizeiTaisyouKcod => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKcod;

        /// <summary>
        /// 税対象科目 科目名称
        /// </summary>
        public string SyouhizeiTaisyouKamokuName => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuName;

        /// <summary>
        /// 税対象科目 科目正式名称
        /// </summary>
        public string SyouhizeiTaisyouKamokuLongName => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuLongName;

        /// <summary>
        /// 税対象科目 処理グループ
        /// </summary>
        public KamokuSyoriGroup SyouhizeiTaisyouKamokuSyoriGroup => this.tanituSiwakeTyouhyouRow.SyouhizeiTaisyouKamokuSyoriGroup;

        /// <summary>
        /// 支払区分名称
        /// </summary>
        public string SiharaiKubunName => this.tanituSiwakeTyouhyouRow.SiharaiKubunName;

        /// <summary>
        /// 入金区分名称
        /// </summary>
        public string NyuukinKubunName => this.tanituSiwakeTyouhyouRow.NyuukinKubunName;

        /// <summary>
        /// 仕訳作成者名称
        /// </summary>
        public string SiwakeCreateUserName => this.tanituSiwakeTyouhyouRow.SiwakeCreateUserName;

        /// <summary>
        /// 仕訳更新者名称
        /// </summary>
        public string SiwakeUpdateUserName => this.tanituSiwakeTyouhyouRow.SiwakeUpdateUserName;

        /// <summary>
        /// 単位名称
        /// </summary>
        public string HeisyuName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.HeisyuName;

        /// <summary>
        /// 国名
        /// </summary>
        public string HeisyuUsingCountryName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.HeisyuUsingCountryName;

        /// <summary>
        /// 小数部桁数
        /// </summary>
        public int? HeisyuDecimalPartKetaCount => this.tanituSiwakeTyouhyouTaisyakubetuDetail.HeisyuDecimalPartKetaCount;

        /// <summary>
        /// 集計部門コード
        /// </summary>
        public string Sbcd => this.tanituSiwakeTyouhyouTaisyakubetuDetail.Sbcd;

        /// <summary>
        /// 集計部門名称
        /// </summary>
        public string SyuukeiBumonName => this.tanituSiwakeTyouhyouTaisyakubetuDetail.SyuukeiBumonName;

        /// <summary>
        /// 仕訳項目未入力チェック結果
        /// </summary>
        public SiwakeItemNotInputCheckResult SiwakeItemNotInputCheckResult => this.tanituSiwakeTyouhyouTaisyakubetuDetail.SiwakeItemNotInputCheckResult;

        /// <summary>
        /// 伝票日付以前の最新税率かどうか
        /// </summary>
        public bool IsLatestSyouhizeirituBeforeDenpyouDate => this.tanituSiwakeTyouhyouTaisyakubetuDetail.IsLatestSyouhizeirituBeforeDenpyouDate;

        /// <summary>
        /// 伝票日付以前の最新の税対象科目税率かどうか
        /// </summary>
        public bool IsLatestSyouhizeiTaisyouKamokuSyouhizeirituBeforeDenpyouDate => this.tanituSiwakeTyouhyouRow.IsLatestSyouhizeiTaisyouKamokuSyouhizeirituBeforeDenpyouDate;

        /// <summary>
        /// 相手諸口金額
        /// </summary>
        public decimal? AiteSyokutiKingaku { get; private set; }

        #endregion

        #endregion

        #region メソッド

        /// <summary>
        /// ユニバーサルフィールドコードを取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールドコード</returns>
        public string GetUniversalFieldCode(int no)
        {
            switch (no)
            {
                case 1:
                    return this.Ufcd01;

                case 2:
                    return this.Ufcd02;

                case 3:
                    return this.Ufcd03;

                case 4:
                    return this.Ufcd04;

                case 5:
                    return this.Ufcd05;

                case 6:
                    return this.Ufcd06;

                case 7:
                    return this.Ufcd07;

                case 8:
                    return this.Ufcd08;

                case 9:
                    return this.Ufcd09;

                case 10:
                    return this.Ufcd10;

                case 11:
                    return this.Ufcd11;

                case 12:
                    return this.Ufcd12;

                case 13:
                    return this.Ufcd13;

                case 14:
                    return this.Ufcd14;

                case 15:
                    return this.Ufcd15;

                case 16:
                    return this.Ufcd16;

                case 17:
                    return this.Ufcd17;

                case 18:
                    return this.Ufcd18;

                case 19:
                    return this.Ufcd19;

                case 20:
                    return this.Ufcd20;

                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド名称を取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド名称</returns>
        public string GetUniversalFieldName(int no)
        {
            switch (no)
            {
                case 1:
                    return this.UniversalField01Name;

                case 2:
                    return this.UniversalField02Name;

                case 3:
                    return this.UniversalField03Name;

                case 4:
                    return this.UniversalField04Name;

                case 5:
                    return this.UniversalField05Name;

                case 6:
                    return this.UniversalField06Name;

                case 7:
                    return this.UniversalField07Name;

                case 8:
                    return this.UniversalField08Name;

                case 9:
                    return this.UniversalField09Name;

                case 10:
                    return this.UniversalField10Name;

                case 11:
                    return this.UniversalField11Name;

                case 12:
                    return this.UniversalField12Name;

                case 13:
                    return this.UniversalField13Name;

                case 14:
                    return this.UniversalField14Name;

                case 15:
                    return this.UniversalField15Name;

                case 16:
                    return this.UniversalField16Name;

                case 17:
                    return this.UniversalField17Name;

                case 18:
                    return this.UniversalField18Name;

                case 19:
                    return this.UniversalField19Name;

                case 20:
                    return this.UniversalField20Name;

                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// ユニバーサルフィールド正式名称を取得します。
        /// </summary>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <returns>ユニバーサルフィールド正式名称</returns>
        public string GetUniversalFieldLongName(int no)
        {
            switch (no)
            {
                case 1:
                    return this.UniversalField01LongName;
                case 2:
                    return this.UniversalField02LongName;
                case 3:
                    return this.UniversalField03LongName;
                case 4:
                    return this.UniversalField04LongName;
                case 5:
                    return this.UniversalField05LongName;
                case 6:
                    return this.UniversalField06LongName;
                case 7:
                    return this.UniversalField07LongName;
                case 8:
                    return this.UniversalField08LongName;
                case 9:
                    return this.UniversalField09LongName;
                case 10:
                    return this.UniversalField10LongName;
                case 11:
                    return this.UniversalField11LongName;
                case 12:
                    return this.UniversalField12LongName;
                case 13:
                    return this.UniversalField13LongName;
                case 14:
                    return this.UniversalField14LongName;
                case 15:
                    return this.UniversalField15LongName;
                case 16:
                    return this.UniversalField16LongName;
                case 17:
                    return this.UniversalField17LongName;
                case 18:
                    return this.UniversalField18LongName;
                case 19:
                    return this.UniversalField19LongName;
                case 20:
                    return this.UniversalField20LongName;
                default:
                    return string.Empty;
            }
        }

        #endregion
    }
}
