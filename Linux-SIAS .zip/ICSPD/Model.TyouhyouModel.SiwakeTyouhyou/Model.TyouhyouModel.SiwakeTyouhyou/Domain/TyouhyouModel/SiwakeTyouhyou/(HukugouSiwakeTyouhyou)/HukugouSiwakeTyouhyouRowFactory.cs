﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.DenpyouModel;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class HukugouSiwakeTyouhyouRowFactory : IHukugouSiwakeTyouhyouRowFactory
    {
        /// <summary>
        /// 複合仕訳帳票の行データリストを作成します。
        /// </summary>
        /// <param name="tanituSiwakeTyouhyouRows">単一仕訳帳票の行データリスト</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <returns>複合仕訳帳票の行データリスト</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "仕訳合成処理は省略不可")]
        public virtual IList<HukugouSiwakeTyouhyouRow> CreateHukugouSiwakeTyouhyouRows(IList<TanituSiwakeTyouhyouRow> tanituSiwakeTyouhyouRows, ISiwakeTyouhyouQueryParameter queryParameter)
        {
            var hukugouSiwakeTyouhyouRows = new List<HukugouSiwakeTyouhyouRow>();
            var previousTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
            var previousTanituSiwakeTyouhyouRow = new TanituSiwakeTyouhyouRow(0, 0, 0, 0) { LineNo = 0, GroupNo = 0 };
            foreach (var tanituSiwakeTyouhyouRow in tanituSiwakeTyouhyouRows)
            {
                // 同一行、同一グループの仕訳の場合、合成可能であれば仕訳を合成
                if (tanituSiwakeTyouhyouRow.LineNo == previousTanituSiwakeTyouhyouRow.LineNo && tanituSiwakeTyouhyouRow.GroupNo == previousTanituSiwakeTyouhyouRow.GroupNo)
                {
                    if (tanituSiwakeTyouhyouRow.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata && previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata)
                    {
                        //// 貸方仕訳に借方仕訳を合成
                        previousTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        if (tanituSiwakeTyouhyouRow.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou
                            && (tanituSiwakeTyouhyouRow.KarikataDetail.HasSecurityNotPermittedCode || previousTanituSiwakeTyouhyouRow.KasikataDetail.HasSecurityNotPermittedCode))
                        {
                            previousTanituSiwakeTyouhyouRow.KasikataDetail.Tekiyou = string.Empty;
                            tanituSiwakeTyouhyouRow.KarikataDetail.Tekiyou = string.Empty;
                        }

                        hukugouSiwakeTyouhyouRows.Add(
                            new HukugouSiwakeTyouhyouRow(tanituSiwakeTyouhyouRow)
                            {
                                KarikataDetail = !tanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Karikata, tanituSiwakeTyouhyouRow, tanituSiwakeTyouhyouRow.KarikataDetail, tanituSiwakeTyouhyouRow.KasikataDetail?.IsSyokutiKamoku ?? false ? tanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null,
                                KasikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Kasikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KasikataDetail, previousTanituSiwakeTyouhyouRow.KarikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null
                            });
                    }
                    else if (tanituSiwakeTyouhyouRow.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata && previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata)
                    {
                        //// 借方仕訳に貸方仕訳を合成
                        previousTaisyakuZokusei = SiwakeTaisyakuZokusei.Taisyaku;
                        if (tanituSiwakeTyouhyouRow.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou
                            && (tanituSiwakeTyouhyouRow.KasikataDetail.HasSecurityNotPermittedCode || previousTanituSiwakeTyouhyouRow.KarikataDetail.HasSecurityNotPermittedCode))
                        {
                            previousTanituSiwakeTyouhyouRow.KarikataDetail.Tekiyou = string.Empty;
                            tanituSiwakeTyouhyouRow.KasikataDetail.Tekiyou = string.Empty;
                        }

                        hukugouSiwakeTyouhyouRows.Add(
                            new HukugouSiwakeTyouhyouRow(tanituSiwakeTyouhyouRow)
                            {
                                KarikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Karikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KarikataDetail, previousTanituSiwakeTyouhyouRow.KasikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null,
                                KasikataDetail = !tanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Kasikata, tanituSiwakeTyouhyouRow, tanituSiwakeTyouhyouRow.KasikataDetail, tanituSiwakeTyouhyouRow.KarikataDetail?.IsSyokutiKamoku ?? false ? tanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null
                            });
                    }
                }
                else
                {
                    //// 飛び番がある場合、空欄行を挿入（承認処理は除く）
                    if (tanituSiwakeTyouhyouRow.LineNo > previousTanituSiwakeTyouhyouRow.LineNo + 1
                        && queryParameter.HukugouSiwakeNormalOutputSetting == SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.AllSiwakeOutput
                        && queryParameter.SiwakeTyouhyouQueryOption.SyoriType != SyoriType.SyouninSyori)
                    {
                        for (int i = 0; i < tanituSiwakeTyouhyouRow.LineNo - previousTanituSiwakeTyouhyouRow.LineNo - 1; i++)
                        {
                            hukugouSiwakeTyouhyouRows.Add(new HukugouSiwakeTyouhyouRow(new TanituSiwakeTyouhyouRow(previousTanituSiwakeTyouhyouRow.Kesn, previousTanituSiwakeTyouhyouRow.Dkei, 0, 0) { LineNo = previousTanituSiwakeTyouhyouRow.LineNo + 1 + i }));
                        }
                    }

                    if (previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata)
                    {
                        //// 借方のみで、貸方が存在しない場合
                        hukugouSiwakeTyouhyouRows.Add(
                            new HukugouSiwakeTyouhyouRow(previousTanituSiwakeTyouhyouRow)
                            {
                                KarikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Karikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KarikataDetail, previousTanituSiwakeTyouhyouRow.KasikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null,
                            });
                    }
                    else if (previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata)
                    {
                        //// 貸方のみで、借方が存在しない場合
                        hukugouSiwakeTyouhyouRows.Add(
                            new HukugouSiwakeTyouhyouRow(previousTanituSiwakeTyouhyouRow)
                            {
                                KasikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Kasikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KasikataDetail, previousTanituSiwakeTyouhyouRow.KarikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                                    : null
                            });
                    }

                    previousTaisyakuZokusei = tanituSiwakeTyouhyouRow.SiwakeTaisyakuZokusei;
                    //// 貸借両方の仕訳を追加
                    if (tanituSiwakeTyouhyouRow.SiwakeTaisyakuZokusei == SiwakeTaisyakuZokusei.Taisyaku)
                    {
                        if (tanituSiwakeTyouhyouRow.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakuCommonTekiyou
                            && (tanituSiwakeTyouhyouRow.KasikataDetail.HasSecurityNotPermittedCode || previousTanituSiwakeTyouhyouRow.KarikataDetail.HasSecurityNotPermittedCode))
                        {
                            tanituSiwakeTyouhyouRow.KarikataDetail.Tekiyou = string.Empty;
                            tanituSiwakeTyouhyouRow.KasikataDetail.Tekiyou = string.Empty;
                        }

                        hukugouSiwakeTyouhyouRows.Add(
                            new HukugouSiwakeTyouhyouRow(tanituSiwakeTyouhyouRow)
                            {
                                KarikataDetail = !tanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Taisyaku, tanituSiwakeTyouhyouRow, tanituSiwakeTyouhyouRow.KarikataDetail, 0)
                                    : null,
                                KasikataDetail = !tanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                                    ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Taisyaku, tanituSiwakeTyouhyouRow, tanituSiwakeTyouhyouRow.KasikataDetail, 0)
                                    : null
                            });
                    }

                    previousTanituSiwakeTyouhyouRow = tanituSiwakeTyouhyouRow;
                }
            }

            if (previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Karikata)
            {
                //// 借方のみで、貸方が存在しない場合
                hukugouSiwakeTyouhyouRows.Add(
                    new HukugouSiwakeTyouhyouRow(previousTanituSiwakeTyouhyouRow)
                    {
                        KarikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                            ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Karikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KarikataDetail, previousTanituSiwakeTyouhyouRow.KasikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                            : null
                    });
            }
            else if (previousTaisyakuZokusei == SiwakeTaisyakuZokusei.Kasikata)
            {
                //// 貸方のみで、借方が存在しない場合
                hukugouSiwakeTyouhyouRows.Add(
                    new HukugouSiwakeTyouhyouRow(previousTanituSiwakeTyouhyouRow)
                    {
                        KasikataDetail = !previousTanituSiwakeTyouhyouRow.IsNotDisplayableSiwake
                            ? new HukugouSiwakeTyouhyouTaisyakubetuDetail(SiwakeTaisyakuZokusei.Kasikata, previousTanituSiwakeTyouhyouRow, previousTanituSiwakeTyouhyouRow.KasikataDetail, previousTanituSiwakeTyouhyouRow.KarikataDetail?.IsSyokutiKamoku ?? false ? previousTanituSiwakeTyouhyouRow.Kingaku : 0)
                            : null
                    });
            }

            return hukugouSiwakeTyouhyouRows;
        }
    }
}
