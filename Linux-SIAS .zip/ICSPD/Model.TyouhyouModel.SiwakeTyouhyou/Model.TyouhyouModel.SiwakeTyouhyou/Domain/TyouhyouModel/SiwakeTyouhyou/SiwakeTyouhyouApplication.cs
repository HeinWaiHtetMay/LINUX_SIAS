﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.SecurityModel;

    public class SiwakeTyouhyouApplication
    {
        public SiwakeTyouhyouApplication(string programId)
        {
            this.ProgramId = programId;
            if (programId == "SDSCAN" || programId == "SLEDMAIN")
            {
                this.ApplicationSecurityType = ApplicationSecurityType.Security;
            }
            else if (programId.StartsWith("SF"))
            {
                this.ApplicationSecurityType = ApplicationSecurityType.SyouninAndSecurity;
            }
            else
            {
                this.ApplicationSecurityType = ApplicationSecurityType.NoSecurity;
            }

            this.IsSokyuuApplication = this.ProgramId.StartsWith("SK");
        }

        public string ProgramId { get; private set; }

        public bool IsSokyuuApplication { get; private set; }

        public ApplicationSecurityType ApplicationSecurityType { get; private set; }

        public bool IsDataScan => this.ProgramId == "DSCAN" || this.ProgramId == "SDSCAN" || this.ProgramId == "SFDSCAN";

        public bool IsCheckList => this.ProgramId == "CHKMAIN" || this.ProgramId == "SKCHLSTB";

        public bool IsMototyouOrGaikaMototyou => this.ProgramId.EndsWith("LEDMAIN");

        /// <summary>
        /// 入力確定・チェックリストかどうかをチェックします
        /// </summary>
        /// <returns>入力確定・チェックリストかどうか</returns>
        public bool IsNyuuryokuKakuteiCheckList => this.ProgramId == "SFCHKMAIN" || this.ProgramId == "SKCHLSTA";

        public bool IsSyouninSyori => this.ProgramId == "SFSYONIN" || this.ProgramId == "SKSYONIN";

        public bool IsSiwakeNikkityou => this.ProgramId == "NIKKMAIN";

        /// <summary>
        /// 自動諸口のコード・名称を仕訳出力オプションにより変換するかどうか
        /// </summary>
        /// <returns></returns>
        public bool ShouldConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption()
        {
            if (this.IsSokyuuApplication)
            {
                return false;
            }

            if (this.IsCheckList
                || this.IsSiwakeNikkityou
                || this.IsMototyouOrGaikaMototyou
                || this.IsNyuuryokuKakuteiCheckList)
            {
                return true;
            }

            return false;
        }
    }
}
