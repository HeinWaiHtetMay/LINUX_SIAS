﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Drawing;

    /// <summary>
    /// 仕訳帳表オプション設定
    /// </summary>
    public class SiwakeTyouhyouOutputOption
    {
        public SiwakeTyouhyouOutputOption(string programIdForOption)
        {
            this.SiwakeTyouhyouOutputType = programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA" || programIdForOption.EndsWith("SYONIN")
                ? SiwakeTyouhyouOutputType.HukugouSiwake
                : SiwakeTyouhyouOutputType.TanituSiwake;

            this.TanituSiwakeDenpyouSortOrder = programIdForOption == "DSCAN" || programIdForOption == "NIKKMAIN"
                ? SiwakeTyouhyouDenpyouSortOrder.DenpyouDate
                : SiwakeTyouhyouDenpyouSortOrder.Sseq;

            this.SeiritukiDisplayType = programIdForOption.EndsWith("SYONIN")
                ? SiwakeTyouhyouSeiritukiDisplayType.Suuji
                : SiwakeTyouhyouSeiritukiDisplayType.CircleKakomiCharacter;

            this.IsPrintTotalKingakuEachDenpyou =
            this.IsPrintSyokutiCheckForEachDenpyou = programIdForOption == "SFCHKMAIN" || programIdForOption == "SKCHLSTA";
        }

        #region プロパティ

        #region オプション設定ダイアログの各設定項目

        /// <summary>
        /// 出力形式
        /// </summary>
        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType { get; set; }

        /// <summary>
        /// 伝票単位時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder { get; set; } = SiwakeTyouhyouDenpyouSortOrder.DenpyouDate;

        /// <summary>
        /// 仕訳一覧時の伝票並び順
        /// </summary>
        public SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder { get; set; }

        /// <summary>
        /// ソート順
        /// </summary>
        public SiwakeTyouhyouSortOrder SortOrder { get; set; }

        /// <summary>
        /// 仕訳の最大表示数
        /// </summary>
        public int SiwakeMaxDisplayCount { get; set; } = 100000;

        /// <summary>
        /// 整理月の月表示
        /// </summary>
        public SiwakeTyouhyouSeiritukiDisplayType SeiritukiDisplayType { get; set; }

        /// <summary>
        /// 伝票ごとに合計金額を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuEachDenpyou { get; set; }

        /// <summary>
        /// 仕訳帳票のコメントの印刷
        /// </summary>
        public SiwakeTyouhyouCommentPrintSetting CommentPrintSetting { get; set; }

        /// <summary>
        /// 本支店展開後の仕訳を印刷するかどうか
        /// </summary>
        public bool IsPrintSiwakeAfterHonsitenTenkai { get; set; }

        /// <summary>
        /// 「未承認」の色
        /// </summary>
        public Color MisyouninColor { get; set; } = Color.FromArgb(222, 67, 1);

        /// <summary>
        /// 「否認」の色
        /// </summary>
        public Color HininColor { get; set; } = Color.FromArgb(255, 0, 0);

        /// <summary>
        /// 「承認」の色
        /// </summary>
        public Color SyouninColor { get; set; } = Color.FromArgb(0, 85, 0);

        /// <summary>
        /// 伝票日付の印刷出力設定
        /// </summary>
        public SiwakeTyouhyouDenpyouDatePrintOutputSetting DenpyouDatePrintOutputSetting { get; set; } = SiwakeTyouhyouDenpyouDatePrintOutputSetting.SiwakeRowTani;

        /// <summary>
        /// 出力指定の範囲指定で印刷した場合に、伝票を印刷済に設定するかどうか
        /// </summary>
        public bool IsSetDenpyouOutputed { get; set; }

        /// <summary>
        /// 伝票単位で通常出力する場合の出力内容の設定
        /// </summary>
        public SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting { get; set; } = SiwakeTyouhyouHukugouSiwakeNormalOutputSetting.AllSiwakeOutput;

        /// <summary>
        /// 貸借とも科目が表示できない仕訳を出力しないかどうか
        /// </summary>
        public bool IsNotOutputKamokuNotDisplayedSiwake { get; set; }

        /// <summary>
        /// 処理月全体での印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForAllSyorituki { get; set; }

        /// <summary>
        /// 処理月全体での印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForAllSyorituki { get; set; }

        /// <summary>
        /// 出力された仕訳の印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForOutputSiwake { get; set; } = true;

        /// <summary>
        /// 出力された仕訳の印刷時に、伝票件数を印刷するかどうか
        /// </summary>
        public bool IsPrintDenpyouCountForOutputSiwake { get; set; }

        /// <summary>
        /// 出力された仕訳の印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForOutputSiwake { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、合計を印刷するかどうか
        /// </summary>
        public bool IsPrintTotalKingakuForEachDenpyou { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、１伝票１行でも印刷するかどうか
        /// </summary>
        public bool IsPrintRowPerOneDenpyouForEachDenpyou { get; set; }

        /// <summary>
        /// 伝票毎の印刷時に、諸口チェックを印刷するかどうか
        /// </summary>
        public bool IsPrintSyokutiCheckForEachDenpyou { get; set; }

        #endregion

        #region 出力順序の設定ダイアログの各設定項目

        /// <summary>
        /// 出力順序の設定
        /// </summary>
        public SiwakeTyouhyouOutputOrderSetting OutputOrderSetting { get; set; }

        #endregion

        #region 前回の選択内容の各設定項目

        /// <summary>
        /// 印刷レイアウトNo
        /// </summary>
        public int PrintLayoutNo { get; set; }

        #endregion

        #endregion
    }
}
