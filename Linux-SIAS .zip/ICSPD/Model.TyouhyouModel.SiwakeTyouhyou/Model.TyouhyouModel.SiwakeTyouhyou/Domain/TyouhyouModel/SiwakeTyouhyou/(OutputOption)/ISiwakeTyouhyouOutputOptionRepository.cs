﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouOutputOptionRepository
    {
        /// <summary>
        /// 指定条件の仕訳帳表オプションを取得します。
        /// </summary>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="programId">取得に使用するプログラムID</param>
        /// <returns></returns>
        SiwakeTyouhyouOutputOption FindByProgramIdAndUserCode(int userCode, string programId);

        /// <summary>
        /// オプション設定の各項目を保存します。
        /// </summary>
        /// <param name="programId">プログラムID</param>
        /// <param name="userCode">ユーザーコード</param>
        /// <param name="siwakeTyouhyouOutputOption">仕訳帳表オプション</param>
        /// <param name="programIdForOption">保存に使用するプログラムID</param>
        void Store(string programId, int userCode, SiwakeTyouhyouOutputOption siwakeTyouhyouOutputOption, string programIdForOption);
    }
}
