﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// エクスポート項目
    /// </summary>
    public enum SiwakeTyouhyouExportItem
    {
        /// <summary>
        /// 経過月
        /// </summary>
        Dkei = 1,

        /// <summary>
        /// 受付番号
        /// </summary>
        UketukeNo = 2,

        /// <summary>
        /// 伝票日付
        /// </summary>
        DenpyouDate = 3,

        /// <summary>
        /// 伝票番号
        /// </summary>
        DenpyouNo = 4,

        /// <summary>
        /// 伝票SEQ
        /// </summary>
        Dseq = 5,

        /// <summary>
        /// 伝票作成日
        /// </summary>
        DenpyouCreateDate = 6,

        /// <summary>
        /// 伝票作成者コード
        /// </summary>
        DenpyouCreateUserCode = 7,

        /// <summary>
        /// 伝票作成者名
        /// </summary>
        DenpyouCreateUserName = 8,

        /// <summary>
        /// 伝票更新日
        /// </summary>
        DenpyouUpdateDate = 9,

        /// <summary>
        /// 伝票更新者コード
        /// </summary>
        DenpyouUpdateUserCode = 10,

        /// <summary>
        /// 伝票更新者名
        /// </summary>
        DenpyouUpdateUserName = 11,

        /// <summary>
        /// 起票日
        /// </summary>
        KihyouDate = 12,

        /// <summary>
        /// 起票部門コード
        /// </summary>
        KihyouBumonCode = 13,

        /// <summary>
        /// 起票部門名称
        /// </summary>
        KihyouBumonName = 14,

        /// <summary>
        /// 起票者コード
        /// </summary>
        KihyouTantousyaCode = 15,

        /// <summary>
        /// 起票者名
        /// </summary>
        KihyouTantousyaName = 16,

        /// <summary>
        /// ヘッダーフィールド１コード
        /// </summary>
        Hfcd01 = 17,

        /// <summary>
        /// ヘッダーフィールド１名称
        /// </summary>
        HeaderField01Name = 18,

        /// <summary>
        /// ヘッダーフィールド２コード
        /// </summary>
        Hfcd02 = 19,

        /// <summary>
        /// ヘッダーフィールド２名称
        /// </summary>
        HeaderField02Name = 20,

        /// <summary>
        /// ヘッダーフィールド３コード
        /// </summary>
        Hfcd03 = 21,

        /// <summary>
        /// ヘッダーフィールド３名称
        /// </summary>
        HeaderField03Name = 22,

        /// <summary>
        /// ヘッダーフィールド４コード
        /// </summary>
        Hfcd04 = 23,

        /// <summary>
        /// ヘッダーフィールド４名称
        /// </summary>
        HeaderField04Name = 24,

        /// <summary>
        /// ヘッダーフィールド５コード
        /// </summary>
        Hfcd05 = 25,

        /// <summary>
        /// ヘッダーフィールド５名称
        /// </summary>
        HeaderField05Name = 26,

        /// <summary>
        /// ヘッダーフィールド６コード
        /// </summary>
        Hfcd06 = 27,

        /// <summary>
        /// ヘッダーフィールド６名称
        /// </summary>
        HeaderField06Name = 28,

        /// <summary>
        /// ヘッダーフィールド７コード
        /// </summary>
        Hfcd07 = 29,

        /// <summary>
        /// ヘッダーフィールド７名称
        /// </summary>
        HeaderField07Name = 30,

        /// <summary>
        /// ヘッダーフィールド８コード
        /// </summary>
        Hfcd08 = 31,

        /// <summary>
        /// ヘッダーフィールド８名称
        /// </summary>
        HeaderField08Name = 32,

        /// <summary>
        /// ヘッダーフィールド９コード
        /// </summary>
        Hfcd09 = 33,

        /// <summary>
        /// ヘッダーフィールド９名称
        /// </summary>
        HeaderField09Name = 34,

        /// <summary>
        /// ヘッダーフィールド１０コード
        /// </summary>
        Hfcd10 = 35,

        /// <summary>
        /// ヘッダーフィールド１０名称
        /// </summary>
        HeaderField10Name = 36,

        /// <summary>
        /// 借方部門コード
        /// </summary>
        KarikataBcod = 37,

        /// <summary>
        /// 借方部門名称
        /// </summary>
        KarikataBumonName = 38,

        /// <summary>
        /// 借方取引先コード
        /// </summary>
        KarikataTrcd = 39,

        /// <summary>
        /// 借方取引先名称
        /// </summary>
        KarikataTorihikisakiName = 40,

        /// <summary>
        /// 借方科目コード
        /// </summary>
        KarikataKcod = 41,

        /// <summary>
        /// 借方科目名称
        /// </summary>
        KarikataKamokuName = 42,

        /// <summary>
        /// 借方枝番コード
        /// </summary>
        KarikataEcod = 43,

        /// <summary>
        /// 借方枝番名称
        /// </summary>
        KarikataEdabanName = 44,

        /// <summary>
        /// 借方工事コード
        /// </summary>
        KarikataKzcd = 45,

        /// <summary>
        /// 借方工事名称
        /// </summary>
        KarikataKouziName = 46,

        /// <summary>
        /// 借方工種コード
        /// </summary>
        KarikataKscd = 47,

        /// <summary>
        /// 借方工種名称
        /// </summary>
        KarikataKousyuName = 48,

        /// <summary>
        /// 借方プロジェクトコード
        /// </summary>
        KarikataPjcd = 49,

        /// <summary>
        /// 借方プロジェクト名称
        /// </summary>
        KarikataProjectName = 50,

        /// <summary>
        /// 借方セグメントコード
        /// </summary>
        KarikataSgcd = 51,

        /// <summary>
        /// 借方セグメント名称
        /// </summary>
        KarikataSegmentName = 52,

        /// <summary>
        /// 借方ユニバーサルフィールド１コード
        /// </summary>
        KarikataUfcd01 = 53,

        /// <summary>
        /// 借方ユニバーサルフィールド１名称
        /// </summary>
        KarikataUniversalField01Name = 54,

        /// <summary>
        /// 借方ユニバーサルフィールド２コード
        /// </summary>
        KarikataUfcd02 = 55,

        /// <summary>
        /// 借方ユニバーサルフィールド２名称
        /// </summary>
        KarikataUniversalField02Name = 56,

        /// <summary>
        /// 借方ユニバーサルフィールド３コード
        /// </summary>
        KarikataUfcd03 = 57,

        /// <summary>
        /// 借方ユニバーサルフィールド３名称
        /// </summary>
        KarikataUniversalField03Name = 58,

        /// <summary>
        /// 借方ユニバーサルフィールド４コード
        /// </summary>
        KarikataUfcd04 = 59,

        /// <summary>
        /// 借方ユニバーサルフィールド４名称
        /// </summary>
        KarikataUniversalField04Name = 60,

        /// <summary>
        /// 借方ユニバーサルフィールド５コード
        /// </summary>
        KarikataUfcd05 = 61,

        /// <summary>
        /// 借方ユニバーサルフィールド５名称
        /// </summary>
        KarikataUniversalField05Name = 62,

        /// <summary>
        /// 借方ユニバーサルフィールド６コード
        /// </summary>
        KarikataUfcd06 = 63,

        /// <summary>
        /// 借方ユニバーサルフィールド６名称
        /// </summary>
        KarikataUniversalField06Name = 64,

        /// <summary>
        /// 借方ユニバーサルフィールド７コード
        /// </summary>
        KarikataUfcd07 = 65,

        /// <summary>
        /// 借方ユニバーサルフィールド７名称
        /// </summary>
        KarikataUniversalField07Name = 66,

        /// <summary>
        /// 借方ユニバーサルフィールド８コード
        /// </summary>
        KarikataUfcd08 = 67,

        /// <summary>
        /// 借方ユニバーサルフィールド８名称
        /// </summary>
        KarikataUniversalField08Name = 68,

        /// <summary>
        /// 借方ユニバーサルフィールド９コード
        /// </summary>
        KarikataUfcd09 = 69,

        /// <summary>
        /// 借方ユニバーサルフィールド９名称
        /// </summary>
        KarikataUniversalField09Name = 70,

        /// <summary>
        /// 借方ユニバーサルフィールド１０コード
        /// </summary>
        KarikataUfcd10 = 71,

        /// <summary>
        /// 借方ユニバーサルフィールド１０名称
        /// </summary>
        KarikataUniversalField10Name = 72,

        /// <summary>
        /// 借方ユニバーサルフィールド１１コード
        /// </summary>
        KarikataUfcd11 = 73,

        /// <summary>
        /// 借方ユニバーサルフィールド１１名称
        /// </summary>
        KarikataUniversalField11Name = 74,

        /// <summary>
        /// 借方ユニバーサルフィールド１２コード
        /// </summary>
        KarikataUfcd12 = 75,

        /// <summary>
        /// 借方ユニバーサルフィールド１２名称
        /// </summary>
        KarikataUniversalField12Name = 76,

        /// <summary>
        /// 借方ユニバーサルフィールド１３コード
        /// </summary>
        KarikataUfcd13 = 77,

        /// <summary>
        /// 借方ユニバーサルフィールド１３名称
        /// </summary>
        KarikataUniversalField13Name = 78,

        /// <summary>
        /// 借方ユニバーサルフィールド１４コード
        /// </summary>
        KarikataUfcd14 = 79,

        /// <summary>
        /// 借方ユニバーサルフィールド１４名称
        /// </summary>
        KarikataUniversalField14Name = 80,

        /// <summary>
        /// 借方ユニバーサルフィールド１５コード
        /// </summary>
        KarikataUfcd15 = 81,

        /// <summary>
        /// 借方ユニバーサルフィールド１５名称
        /// </summary>
        KarikataUniversalField15Name = 82,

        /// <summary>
        /// 借方ユニバーサルフィールド１６コード
        /// </summary>
        KarikataUfcd16 = 83,

        /// <summary>
        /// 借方ユニバーサルフィールド１６名称
        /// </summary>
        KarikataUniversalField16Name = 84,

        /// <summary>
        /// 借方ユニバーサルフィールド１７コード
        /// </summary>
        KarikataUfcd17 = 85,

        /// <summary>
        /// 借方ユニバーサルフィールド１７名称
        /// </summary>
        KarikataUniversalField17Name = 86,

        /// <summary>
        /// 借方ユニバーサルフィールド１８コード
        /// </summary>
        KarikataUfcd18 = 87,

        /// <summary>
        /// 借方ユニバーサルフィールド１８名称
        /// </summary>
        KarikataUniversalField18Name = 88,

        /// <summary>
        /// 借方ユニバーサルフィールド１９コード
        /// </summary>
        KarikataUfcd19 = 89,

        /// <summary>
        /// 借方ユニバーサルフィールド１９名称
        /// </summary>
        KarikataUniversalField19Name = 90,

        /// <summary>
        /// 借方ユニバーサルフィールド２０コード
        /// </summary>
        KarikataUfcd20 = 91,

        /// <summary>
        /// 借方ユニバーサルフィールド２０名称
        /// </summary>
        KarikataUniversalField20Name = 92,

        /// <summary>
        /// 借方摘要
        /// </summary>
        KarikataTekiyou = 93,

        /// <summary>
        /// 借方摘要コード
        /// </summary>
        KarikataTekiyouCode = 94,

        /// <summary>
        /// 借方摘要名称
        /// </summary>
        KarikataTekiyouName = 95,

        /// <summary>
        /// 借方税区分
        /// </summary>
        KarikataZeiKubun = 96,

        /// <summary>
        /// 借方仕入・業種区分
        /// </summary>
        KarikataSiireAndGyousyuKubun = 97,

        /// <summary>
        /// 借方幣種
        /// </summary>
        KarikataHeisyu = 98,

        /// <summary>
        /// 貸方部門コード
        /// </summary>
        KasikataBcod = 99,

        /// <summary>
        /// 貸方部門名称
        /// </summary>
        KasikataBumonName = 100,

        /// <summary>
        /// 貸方取引先コード
        /// </summary>
        KasikataTrcd = 101,

        /// <summary>
        /// 貸方取引先名称
        /// </summary>
        KasikataTorihikisakiName = 102,

        /// <summary>
        /// 貸方科目コード
        /// </summary>
        KasikataKcod = 103,

        /// <summary>
        /// 貸方科目名称
        /// </summary>
        KasikataKamokuName = 104,

        /// <summary>
        /// 貸方枝番コード
        /// </summary>
        KasikataEcod = 105,

        /// <summary>
        /// 貸方枝番名称
        /// </summary>
        KasikataEdabanName = 106,

        /// <summary>
        /// 貸方工事コード
        /// </summary>
        KasikataKzcd = 107,

        /// <summary>
        /// 貸方工事名称
        /// </summary>
        KasikataKouziName = 108,

        /// <summary>
        /// 貸方工種コード
        /// </summary>
        KasikataKscd = 109,

        /// <summary>
        /// 貸方工種名称
        /// </summary>
        KasikataKousyuName = 110,

        /// <summary>
        /// 貸方プロジェクトコード
        /// </summary>
        KasikataPjcd = 111,

        /// <summary>
        /// 貸方プロジェクト名称
        /// </summary>
        KasikataProjectName = 112,

        /// <summary>
        /// 貸方セグメントコード
        /// </summary>
        KasikataSgcd = 113,

        /// <summary>
        /// 貸方セグメント名称
        /// </summary>
        KasikataSegmentName = 114,

        /// <summary>
        /// 貸方ユニバーサルフィールド１コード
        /// </summary>
        KasikataUfcd01 = 115,

        /// <summary>
        /// 貸方ユニバーサルフィールド１名称
        /// </summary>
        KasikataUniversalField01Name = 116,

        /// <summary>
        /// 貸方ユニバーサルフィールド２コード
        /// </summary>
        KasikataUfcd02 = 117,

        /// <summary>
        /// 貸方ユニバーサルフィールド２名称
        /// </summary>
        KasikataUniversalField02Name = 118,

        /// <summary>
        /// 貸方ユニバーサルフィールド３コード
        /// </summary>
        KasikataUfcd03 = 119,

        /// <summary>
        /// 貸方ユニバーサルフィールド３名称
        /// </summary>
        KasikataUniversalField03Name = 120,

        /// <summary>
        /// 貸方ユニバーサルフィールド４コード
        /// </summary>
        KasikataUfcd04 = 121,

        /// <summary>
        /// 貸方ユニバーサルフィールド４名称
        /// </summary>
        KasikataUniversalField04Name = 122,

        /// <summary>
        /// 貸方ユニバーサルフィールド５コード
        /// </summary>
        KasikataUfcd05 = 123,

        /// <summary>
        /// 貸方ユニバーサルフィールド５名称
        /// </summary>
        KasikataUniversalField05Name = 124,

        /// <summary>
        /// 貸方ユニバーサルフィールド６コード
        /// </summary>
        KasikataUfcd06 = 125,

        /// <summary>
        /// 貸方ユニバーサルフィールド６名称
        /// </summary>
        KasikataUniversalField06Name = 126,

        /// <summary>
        /// 貸方ユニバーサルフィールド７コード
        /// </summary>
        KasikataUfcd07 = 127,

        /// <summary>
        /// 貸方ユニバーサルフィールド７名称
        /// </summary>
        KasikataUniversalField07Name = 128,

        /// <summary>
        /// 貸方ユニバーサルフィールド８コード
        /// </summary>
        KasikataUfcd08 = 129,

        /// <summary>
        /// 貸方ユニバーサルフィールド８名称
        /// </summary>
        KasikataUniversalField08Name = 130,

        /// <summary>
        /// 貸方ユニバーサルフィールド９コード
        /// </summary>
        KasikataUfcd09 = 131,

        /// <summary>
        /// 貸方ユニバーサルフィールド９名称
        /// </summary>
        KasikataUniversalField09Name = 132,

        /// <summary>
        /// 貸方ユニバーサルフィールド１０コード
        /// </summary>
        KasikataUfcd10 = 133,

        /// <summary>
        /// 貸方ユニバーサルフィールド１０名称
        /// </summary>
        KasikataUniversalField10Name = 134,

        /// <summary>
        /// 貸方ユニバーサルフィールド１１コード
        /// </summary>
        KasikataUfcd11 = 135,

        /// <summary>
        /// 貸方ユニバーサルフィールド１１名称
        /// </summary>
        KasikataUniversalField11Name = 136,

        /// <summary>
        /// 貸方ユニバーサルフィールド１２コード
        /// </summary>
        KasikataUfcd12 = 137,

        /// <summary>
        /// 貸方ユニバーサルフィールド１２名称
        /// </summary>
        KasikataUniversalField12Name = 138,

        /// <summary>
        /// 貸方ユニバーサルフィールド１３コード
        /// </summary>
        KasikataUfcd13 = 139,

        /// <summary>
        /// 貸方ユニバーサルフィールド１３名称
        /// </summary>
        KasikataUniversalField13Name = 140,

        /// <summary>
        /// 貸方ユニバーサルフィールド１４コード
        /// </summary>
        KasikataUfcd14 = 141,

        /// <summary>
        /// 貸方ユニバーサルフィールド１４名称
        /// </summary>
        KasikataUniversalField14Name = 142,

        /// <summary>
        /// 貸方ユニバーサルフィールド１５コード
        /// </summary>
        KasikataUfcd15 = 143,

        /// <summary>
        /// 貸方ユニバーサルフィールド１５名称
        /// </summary>
        KasikataUniversalField15Name = 144,

        /// <summary>
        /// 貸方ユニバーサルフィールド１６コード
        /// </summary>
        KasikataUfcd16 = 145,

        /// <summary>
        /// 貸方ユニバーサルフィールド１６名称
        /// </summary>
        KasikataUniversalField16Name = 146,

        /// <summary>
        /// 貸方ユニバーサルフィールド１７コード
        /// </summary>
        KasikataUfcd17 = 147,

        /// <summary>
        /// 貸方ユニバーサルフィールド１７名称
        /// </summary>
        KasikataUniversalField17Name = 148,

        /// <summary>
        /// 貸方ユニバーサルフィールド１８コード
        /// </summary>
        KasikataUfcd18 = 149,

        /// <summary>
        /// 貸方ユニバーサルフィールド１８名称
        /// </summary>
        KasikataUniversalField18Name = 150,

        /// <summary>
        /// 貸方ユニバーサルフィールド１９コード
        /// </summary>
        KasikataUfcd19 = 151,

        /// <summary>
        /// 貸方ユニバーサルフィールド１９名称
        /// </summary>
        KasikataUniversalField19Name = 152,

        /// <summary>
        /// 貸方ユニバーサルフィールド２０コード
        /// </summary>
        KasikataUfcd20 = 153,

        /// <summary>
        /// 貸方ユニバーサルフィールド２０名称
        /// </summary>
        KasikataUniversalField20Name = 154,

        /// <summary>
        /// 貸方摘要
        /// </summary>
        KasikataTekiyou = 155,

        /// <summary>
        /// 貸方摘要コード
        /// </summary>
        KasikataTekiyouCode = 156,

        /// <summary>
        /// 貸方摘要名称
        /// </summary>
        KasikataTekiyouName = 157,

        /// <summary>
        /// 貸方税区分
        /// </summary>
        KasikataZeiKubun = 158,

        /// <summary>
        /// 貸方仕入・業種区分
        /// </summary>
        KasikataSiireAndGyousyuKubun = 159,

        /// <summary>
        /// 貸方幣種
        /// </summary>
        KasikataHeisyu = 160,

        /// <summary>
        /// 金額
        /// </summary>
        Kingaku = 161,

        /// <summary>
        /// 対価金額
        /// </summary>
        TaikaKingaku = 162,

        /// <summary>
        /// 税込金額
        /// </summary>
        ZeikomiKingaku = 163,

        /// <summary>
        /// 消費税対象科目コード
        /// </summary>
        SyouhizeiTaisyouKcod = 164,

        /// <summary>
        /// 消費税対象科目名称
        /// </summary>
        SyouhizeiTaisyouKamokuName = 165,

        /// <summary>
        /// 消費税対象科目税区分
        /// </summary>
        SyouhizeiTaisyouKamokuZeiKubun = 166,

        /// <summary>
        /// 消費税対象科目仕入・業種区分
        /// </summary>
        SyouhizeiTaisyouKamokuSiireAndGyousyuKubun = 167,

        /// <summary>
        /// 消込コード
        /// </summary>
        KesikomiCode = 168,

        /// <summary>
        /// 支払日
        /// </summary>
        SiharaiDate = 169,

        /// <summary>
        /// 支払区分
        /// </summary>
        SiharaiKubun = 170,

        /// <summary>
        /// 支払期日
        /// </summary>
        SiharaiKizitu = 171,

        /// <summary>
        /// 回収日
        /// </summary>
        KaisyuuDate = 172,

        /// <summary>
        /// 入金区分
        /// </summary>
        NyuukinKubun = 173,

        /// <summary>
        /// 回収期日
        /// </summary>
        KaisyuuKizitu = 174,

        /// <summary>
        /// 外貨金額
        /// </summary>
        GaikaKingaku = 175,

        /// <summary>
        /// 外貨対価金額
        /// </summary>
        GaikaTaikaKingaku = 176,

        /// <summary>
        /// 外貨税込金額
        /// </summary>
        GaikaZeikomiKingaku = 177,

        /// <summary>
        /// レート
        /// </summary>
        Rate = 178,

        /// <summary>
        /// 仕訳SEQ
        /// </summary>
        Sseq = 179,

        /// <summary>
        /// 仕訳作成日
        /// </summary>
        SiwakeCreateDate = 180,

        /// <summary>
        /// 仕訳作成者コード
        /// </summary>
        SiwakeCreateUserCode = 181,

        /// <summary>
        /// 仕訳作成者名
        /// </summary>
        SiwakeCreateUserName = 182,

        /// <summary>
        /// 仕訳更新日
        /// </summary>
        SiwakeUpdateDate = 183,

        /// <summary>
        /// 仕訳更新者コード
        /// </summary>
        SiwakeUpdateUserCode = 184,

        /// <summary>
        /// 仕訳更新者名
        /// </summary>
        SiwakeUpdateUserName = 185,

        /// <summary>
        /// 会社コード
        /// </summary>
        Ccod = 186
    }
}
