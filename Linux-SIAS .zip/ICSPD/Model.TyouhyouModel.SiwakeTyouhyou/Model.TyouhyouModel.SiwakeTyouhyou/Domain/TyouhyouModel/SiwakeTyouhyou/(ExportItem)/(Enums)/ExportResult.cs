﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// エクスポート処理結果
    /// </summary>
    public enum ExportProcessingResult
    {
        /// <summary>
        /// 正常終了
        /// </summary>
        Success = 1,

        /// <summary>
        /// 出力データなし
        /// </summary>
        OutputDataIsNull = 2,

        /// <summary>
        /// 決算期情報取得の失敗
        /// </summary>
        KessankiInfoGetFailed = 3,

        /// <summary>
        /// ファイル作成失敗
        /// </summary>
        FileMakeFailed = 4,

        /// <summary>
        /// その他
        /// </summary>
        OtherError = 99
    }
}
