﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// エクスポート項目オプション
    /// </summary>
    public class SiwakeTyouhyouExportItemOption
    {
        #region プロパティ

        /// <summary>
        /// ヘッダーにタイトル名を出力するかどうか
        /// </summary>
        public bool IsExportTitleName { get; set; } = true;

        /// <summary>
        /// ヘッダーに会社名を出力するかどうか
        /// </summary>
        public bool IsExportCompanyName { get; set; } = true;

        /// <summary>
        /// ヘッダーに処理期間を出力するかどうか
        /// </summary>
        public bool IsExportSyoriKikan { get; set; } = true;

        /// <summary>
        /// ヘッダーに項目タイトルを出力するかどうか
        /// </summary>
        public bool IsExportItemTitle { get; set; } = true;

        /// <summary>
        /// エクスポート項目のセット
        /// </summary>
        public ISet<SiwakeTyouhyouExportItem> ExportItemSet { get; set; } = new HashSet<SiwakeTyouhyouExportItem>();

        #endregion

        #region メソッド

        /// <summary>
        /// オブジェクトを複製します。
        /// </summary>
        /// <param name="syouhizeiMaster">消費税マスター</param>
        /// <returns>複製済みのオブジェクト</returns>
        public SiwakeTyouhyouExportItemOption Clone(SyouhizeiMaster syouhizeiMaster)
        {
            var exportItemOption = this.MemberwiseClone() as SiwakeTyouhyouExportItemOption;
            //// 簡易課税でなく、かつ比例配分の場合、仕入・業種区分を出力しない
            if (syouhizeiMaster?.KazeiHousiki < KazeiHousiki.KaniKazeiZigyouNo1
                && syouhizeiMaster?.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.HireiHaibun)
            {
                exportItemOption.ExportItemSet.Remove(SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun);
                exportItemOption.ExportItemSet.Remove(SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun);
                exportItemOption.ExportItemSet.Remove(SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun);
            }

            return exportItemOption;
        }

        #endregion
    }
}
