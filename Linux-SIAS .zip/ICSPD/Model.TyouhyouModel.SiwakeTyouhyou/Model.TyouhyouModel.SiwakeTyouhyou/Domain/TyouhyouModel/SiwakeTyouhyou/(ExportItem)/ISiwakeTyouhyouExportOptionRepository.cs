﻿using Icsp.Open21.Domain.FileExportModel;
using Icsp.Open21.Domain.KaisyaModel;
using Icsp.Open21.Domain.SecurityModel;

namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouExportOptionRepository
    {
        /// <summary>
        /// 指定条件のエクスポートオプション情報を取得します。
        /// </summary>
        /// <param name="kaisya">会社情報</param>
        /// <param name="user">ユーザー情報</param>
        /// <param name="prgid">プログラムID</param>
        /// <returns>エクスポートオプション情報</returns>
        ExportOption FindByKaisyaAndUserAndPrgid(Kaisya kaisya, User user, string prgid);

        /// <summary>
        /// エクスポートオプション情報を保存します。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="prgid">プログラムID</param>
        /// <param name="usno">ユーザーコード</param>
        void Store(ExportOption exportOption, string prgid, int usno);
    }
}