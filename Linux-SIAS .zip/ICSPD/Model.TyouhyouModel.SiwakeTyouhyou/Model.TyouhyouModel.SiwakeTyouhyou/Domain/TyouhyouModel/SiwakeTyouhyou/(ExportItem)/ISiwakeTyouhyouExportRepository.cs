﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.FileExportModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public interface ISiwakeTyouhyouExportRepository
    {
        /// <summary>
        /// CSV形式でのエクスポート処理をおこないます。
        /// </summary>
        /// <param name="exportOption">エクスポートオプション情報</param>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="queryParameter">仕訳帳票問合せパラメータ</param>
        /// <param name="siwakeTyouhyouOption">仕訳帳票オプション</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>エクスポート処理結果</returns>
        ExportResultClass ExportCsv(
            ExportOption exportOption,
            SiwakeTyouhyouExportItemOption exportItemOption,
            ISiwakeTyouhyouQueryParameter queryParameter,
            SiwakeTyouhyouOption siwakeTyouhyouOption,
            SyouhizeiMaster syouhizeiMaster);
    }
}