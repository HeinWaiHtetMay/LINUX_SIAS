﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    public interface ISiwakeTyouhyouExportItemOptionRepository
    {
        /// <summary>
        /// プログラムIDとユーザーNoを条件として、エクスポート項目オプションを取得します。
        /// </summary>
        /// <param name="prgid">プログラムID</param>
        /// <param name="usno">ユーザーNo</param>
        /// <returns>エクスポート項目オプション</returns>
        SiwakeTyouhyouExportItemOption FindByUserCodeAndProgramId(string prgid, int usno);

        /// <summary>
        /// エクスポート項目を保存します。
        /// </summary>
        /// <param name="exportItemOption">エクスポート項目オプション</param>
        /// <param name="usno">ユーザーコード</param>
        void Store(SiwakeTyouhyouExportItemOption exportItemOption, int usno);
    }
}
