﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Properties;

    public static class SiwakeTyouhyouExportItemExtension
    {
        #region public methods

        /// <summary>
        /// エクスポート項目の名称を取得します。
        /// </summary>
        /// <param name="exportItem">エクスポート項目</param>
        /// <param name="kaisya">会社情報</param>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <returns>エクスポート項目の名称</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Justification = "項目が多く省略不可")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode", Justification = "項目が多く省略不可")]
        public static string GetName(this SiwakeTyouhyouExportItem exportItem, Kaisya kaisya, Syoriki syoriki, bool gaikaItemEnabled)
        {
            switch (exportItem)
            {
                case SiwakeTyouhyouExportItem.Dkei:
                    return Resources.経過月;
                case SiwakeTyouhyouExportItem.UketukeNo:
                    return Resources.受付番号;
                case SiwakeTyouhyouExportItem.DenpyouDate:
                    return Resources.伝票日付;
                case SiwakeTyouhyouExportItem.DenpyouNo:
                    return Resources.伝票番号;
                case SiwakeTyouhyouExportItem.Dseq:
                    return Resources.伝票SEQ;
                case SiwakeTyouhyouExportItem.DenpyouCreateDate:
                    return Resources.伝票作成日;
                case SiwakeTyouhyouExportItem.DenpyouCreateUserCode:
                    return Resources.伝票作成者コード;
                case SiwakeTyouhyouExportItem.DenpyouCreateUserName:
                    return Resources.伝票作成者名;
                case SiwakeTyouhyouExportItem.DenpyouUpdateDate:
                    return Resources.伝票更新日;
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserCode:
                    return Resources.伝票更新者コード;
                case SiwakeTyouhyouExportItem.DenpyouUpdateUserName:
                    return Resources.伝票更新者名;
                case SiwakeTyouhyouExportItem.KihyouDate:
                    return syoriki.UseKihyoubi ? Resources.起票日 : string.Empty;
                case SiwakeTyouhyouExportItem.KihyouBumonCode:
                    return syoriki.BumonInfo.Use && syoriki.UseKihyouBumon ? Resources.起票部門コード : string.Empty;
                case SiwakeTyouhyouExportItem.KihyouBumonName:
                    return syoriki.BumonInfo.Use && syoriki.UseKihyouBumon ? Resources.起票部門名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KihyouTantousyaCode:
                    return syoriki.UseKihyousya ? (kaisya.RenketuSienKubun.IsRenketuSienMaster ? Resources.伝票区分コード : Resources.起票者コード) : string.Empty;
                case SiwakeTyouhyouExportItem.KihyouTantousyaName:
                    return syoriki.UseKihyousya ? (kaisya.RenketuSienKubun.IsRenketuSienMaster ? Resources.伝票区分名 : Resources.起票者名) : string.Empty;
                case SiwakeTyouhyouExportItem.Hfcd01:
                    return GetHeaderFieldString(syoriki, 1, true);
                case SiwakeTyouhyouExportItem.HeaderField01Name:
                    return GetHeaderFieldString(syoriki, 1, false);
                case SiwakeTyouhyouExportItem.Hfcd02:
                    return GetHeaderFieldString(syoriki, 2, true);
                case SiwakeTyouhyouExportItem.HeaderField02Name:
                    return GetHeaderFieldString(syoriki, 2, false);
                case SiwakeTyouhyouExportItem.Hfcd03:
                    return GetHeaderFieldString(syoriki, 3, true);
                case SiwakeTyouhyouExportItem.HeaderField03Name:
                    return GetHeaderFieldString(syoriki, 3, false);
                case SiwakeTyouhyouExportItem.Hfcd04:
                    return GetHeaderFieldString(syoriki, 4, true);
                case SiwakeTyouhyouExportItem.HeaderField04Name:
                    return GetHeaderFieldString(syoriki, 4, false);
                case SiwakeTyouhyouExportItem.Hfcd05:
                    return GetHeaderFieldString(syoriki, 5, true);
                case SiwakeTyouhyouExportItem.HeaderField05Name:
                    return GetHeaderFieldString(syoriki, 5, false);
                case SiwakeTyouhyouExportItem.Hfcd06:
                    return GetHeaderFieldString(syoriki, 6, true);
                case SiwakeTyouhyouExportItem.HeaderField06Name:
                    return GetHeaderFieldString(syoriki, 6, false);
                case SiwakeTyouhyouExportItem.Hfcd07:
                    return GetHeaderFieldString(syoriki, 7, true);
                case SiwakeTyouhyouExportItem.HeaderField07Name:
                    return GetHeaderFieldString(syoriki, 7, false);
                case SiwakeTyouhyouExportItem.Hfcd08:
                    return GetHeaderFieldString(syoriki, 8, true);
                case SiwakeTyouhyouExportItem.HeaderField08Name:
                    return GetHeaderFieldString(syoriki, 8, false);
                case SiwakeTyouhyouExportItem.Hfcd09:
                    return GetHeaderFieldString(syoriki, 9, true);
                case SiwakeTyouhyouExportItem.HeaderField09Name:
                    return GetHeaderFieldString(syoriki, 9, false);
                case SiwakeTyouhyouExportItem.Hfcd10:
                    return GetHeaderFieldString(syoriki, 10, true);
                case SiwakeTyouhyouExportItem.HeaderField10Name:
                    return GetHeaderFieldString(syoriki, 10, false);
                case SiwakeTyouhyouExportItem.KarikataBcod:
                    return syoriki.BumonInfo.Use ? Resources.借方部門コード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataBumonName:
                    return syoriki.BumonInfo.Use ? Resources.借方部門名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataTrcd:
                    return syoriki.TorihikisakiInfo.Use ? Resources.借方取引先コード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataTorihikisakiName:
                    return syoriki.TorihikisakiInfo.Use ? Resources.借方取引先名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataKcod:
                    return Resources.借方科目コード;
                case SiwakeTyouhyouExportItem.KarikataKamokuName:
                    return Resources.借方科目名称;
                case SiwakeTyouhyouExportItem.KarikataEcod:
                    return syoriki.EdabanInfo.Use ? Resources.借方枝番コード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataEdabanName:
                    return syoriki.EdabanInfo.Use ? Resources.借方枝番名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataKzcd:
                    return syoriki.KouziInfo.Use ? Resources.借方工事コード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataKouziName:
                    return syoriki.KouziInfo.Use ? Resources.借方工事名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataKscd:
                    return syoriki.KousyuInfo.Use ? Resources.借方工種コード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataKousyuName:
                    return syoriki.KousyuInfo.Use ? Resources.借方工種名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataPjcd:
                    return syoriki.ProjectInfo.Use ? Resources.借方プロジェクトコード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataProjectName:
                    return syoriki.ProjectInfo.Use ? Resources.借方プロジェクト名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataSgcd:
                    return syoriki.SegmentInfo.Use ? Resources.借方セグメントコード : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataSegmentName:
                    return syoriki.SegmentInfo.Use ? Resources.借方セグメント名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataUfcd01:
                    return GetUniversalFieldString(syoriki, 1, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField01Name:
                    return GetUniversalFieldString(syoriki, 1, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd02:
                    return GetUniversalFieldString(syoriki, 2, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField02Name:
                    return GetUniversalFieldString(syoriki, 2, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd03:
                    return GetUniversalFieldString(syoriki, 3, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField03Name:
                    return GetUniversalFieldString(syoriki, 3, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd04:
                    return GetUniversalFieldString(syoriki, 4, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField04Name:
                    return GetUniversalFieldString(syoriki, 4, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd05:
                    return GetUniversalFieldString(syoriki, 5, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField05Name:
                    return GetUniversalFieldString(syoriki, 5, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd06:
                    return GetUniversalFieldString(syoriki, 6, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField06Name:
                    return GetUniversalFieldString(syoriki, 6, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd07:
                    return GetUniversalFieldString(syoriki, 7, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField07Name:
                    return GetUniversalFieldString(syoriki, 7, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd08:
                    return GetUniversalFieldString(syoriki, 8, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField08Name:
                    return GetUniversalFieldString(syoriki, 8, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd09:
                    return GetUniversalFieldString(syoriki, 9, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField09Name:
                    return GetUniversalFieldString(syoriki, 9, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd10:
                    return GetUniversalFieldString(syoriki, 10, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField10Name:
                    return GetUniversalFieldString(syoriki, 10, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd11:
                    return GetUniversalFieldString(syoriki, 11, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField11Name:
                    return GetUniversalFieldString(syoriki, 11, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd12:
                    return GetUniversalFieldString(syoriki, 12, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField12Name:
                    return GetUniversalFieldString(syoriki, 12, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd13:
                    return GetUniversalFieldString(syoriki, 13, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField13Name:
                    return GetUniversalFieldString(syoriki, 13, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd14:
                    return GetUniversalFieldString(syoriki, 14, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField14Name:
                    return GetUniversalFieldString(syoriki, 14, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd15:
                    return GetUniversalFieldString(syoriki, 15, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField15Name:
                    return GetUniversalFieldString(syoriki, 15, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd16:
                    return GetUniversalFieldString(syoriki, 16, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField16Name:
                    return GetUniversalFieldString(syoriki, 16, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd17:
                    return GetUniversalFieldString(syoriki, 17, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField17Name:
                    return GetUniversalFieldString(syoriki, 17, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd18:
                    return GetUniversalFieldString(syoriki, 18, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField18Name:
                    return GetUniversalFieldString(syoriki, 18, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd19:
                    return GetUniversalFieldString(syoriki, 19, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField19Name:
                    return GetUniversalFieldString(syoriki, 19, false, true);
                case SiwakeTyouhyouExportItem.KarikataUfcd20:
                    return GetUniversalFieldString(syoriki, 20, true, true);
                case SiwakeTyouhyouExportItem.KarikataUniversalField20Name:
                    return GetUniversalFieldString(syoriki, 20, false, true);
                case SiwakeTyouhyouExportItem.KarikataTekiyou:
                    return Resources.借方摘要;
                case SiwakeTyouhyouExportItem.KarikataTekiyouCode:
                    return Resources.借方摘要コード;
                case SiwakeTyouhyouExportItem.KarikataTekiyouName:
                    return Resources.借方摘要名称;
                case SiwakeTyouhyouExportItem.KarikataZeiKubun:
                    return syoriki.UseSyouhizei ? Resources.借方税区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun:
                    //// エクスポートの条件と異なっていますが、SIASの動作に合わせています
                    return syoriki.UseSyouhizei ? Resources.借方仕入_業種区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KarikataHeisyu:
                    return gaikaItemEnabled ? Resources.借方幣種 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataBcod:
                    return syoriki.BumonInfo.Use ? Resources.貸方部門コード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataBumonName:
                    return syoriki.BumonInfo.Use ? Resources.貸方部門名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataTrcd:
                    return syoriki.TorihikisakiInfo.Use ? Resources.貸方取引先コード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataTorihikisakiName:
                    return syoriki.TorihikisakiInfo.Use ? Resources.貸方取引先名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataKcod:
                    return Resources.貸方科目コード;
                case SiwakeTyouhyouExportItem.KasikataKamokuName:
                    return Resources.貸方科目名称;
                case SiwakeTyouhyouExportItem.KasikataEcod:
                    return syoriki.EdabanInfo.Use ? Resources.貸方枝番コード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataEdabanName:
                    return syoriki.EdabanInfo.Use ? Resources.貸方枝番名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataKzcd:
                    return syoriki.KouziInfo.Use ? Resources.貸方工事コード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataKouziName:
                    return syoriki.KouziInfo.Use ? Resources.貸方工事名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataKscd:
                    return syoriki.KousyuInfo.Use ? Resources.貸方工種コード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataKousyuName:
                    return syoriki.KousyuInfo.Use ? Resources.貸方工種名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataPjcd:
                    return syoriki.ProjectInfo.Use ? Resources.貸方プロジェクトコード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataProjectName:
                    return syoriki.ProjectInfo.Use ? Resources.貸方プロジェクト名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataSgcd:
                    return syoriki.SegmentInfo.Use ? Resources.貸方セグメントコード : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataSegmentName:
                    return syoriki.SegmentInfo.Use ? Resources.貸方セグメント名称 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataUfcd01:
                    return GetUniversalFieldString(syoriki, 1, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField01Name:
                    return GetUniversalFieldString(syoriki, 1, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd02:
                    return GetUniversalFieldString(syoriki, 2, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField02Name:
                    return GetUniversalFieldString(syoriki, 2, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd03:
                    return GetUniversalFieldString(syoriki, 3, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField03Name:
                    return GetUniversalFieldString(syoriki, 3, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd04:
                    return GetUniversalFieldString(syoriki, 4, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField04Name:
                    return GetUniversalFieldString(syoriki, 4, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd05:
                    return GetUniversalFieldString(syoriki, 5, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField05Name:
                    return GetUniversalFieldString(syoriki, 5, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd06:
                    return GetUniversalFieldString(syoriki, 6, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField06Name:
                    return GetUniversalFieldString(syoriki, 6, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd07:
                    return GetUniversalFieldString(syoriki, 7, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField07Name:
                    return GetUniversalFieldString(syoriki, 7, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd08:
                    return GetUniversalFieldString(syoriki, 8, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField08Name:
                    return GetUniversalFieldString(syoriki, 8, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd09:
                    return GetUniversalFieldString(syoriki, 9, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField09Name:
                    return GetUniversalFieldString(syoriki, 9, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd10:
                    return GetUniversalFieldString(syoriki, 10, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField10Name:
                    return GetUniversalFieldString(syoriki, 10, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd11:
                    return GetUniversalFieldString(syoriki, 11, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField11Name:
                    return GetUniversalFieldString(syoriki, 11, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd12:
                    return GetUniversalFieldString(syoriki, 12, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField12Name:
                    return GetUniversalFieldString(syoriki, 12, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd13:
                    return GetUniversalFieldString(syoriki, 13, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField13Name:
                    return GetUniversalFieldString(syoriki, 13, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd14:
                    return GetUniversalFieldString(syoriki, 14, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField14Name:
                    return GetUniversalFieldString(syoriki, 14, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd15:
                    return GetUniversalFieldString(syoriki, 15, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField15Name:
                    return GetUniversalFieldString(syoriki, 15, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd16:
                    return GetUniversalFieldString(syoriki, 16, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField16Name:
                    return GetUniversalFieldString(syoriki, 16, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd17:
                    return GetUniversalFieldString(syoriki, 17, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField17Name:
                    return GetUniversalFieldString(syoriki, 17, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd18:
                    return GetUniversalFieldString(syoriki, 18, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField18Name:
                    return GetUniversalFieldString(syoriki, 18, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd19:
                    return GetUniversalFieldString(syoriki, 19, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField19Name:
                    return GetUniversalFieldString(syoriki, 19, false, false);
                case SiwakeTyouhyouExportItem.KasikataUfcd20:
                    return GetUniversalFieldString(syoriki, 20, true, false);
                case SiwakeTyouhyouExportItem.KasikataUniversalField20Name:
                    return GetUniversalFieldString(syoriki, 20, false, false);
                case SiwakeTyouhyouExportItem.KasikataTekiyou:
                    return Resources.貸方摘要;
                case SiwakeTyouhyouExportItem.KasikataTekiyouCode:
                    return Resources.貸方摘要コード;
                case SiwakeTyouhyouExportItem.KasikataTekiyouName:
                    return Resources.貸方摘要名称;
                case SiwakeTyouhyouExportItem.KasikataZeiKubun:
                    return syoriki.UseSyouhizei ? Resources.貸方税区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun:
                    //// エクスポートの条件と異なっていますが、SIASの動作に合わせています
                    return syoriki.UseSyouhizei ? Resources.貸方仕入_業種区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataHeisyu:
                    return gaikaItemEnabled ? Resources.貸方幣種 : string.Empty;
                case SiwakeTyouhyouExportItem.Kingaku:
                    return Resources.金額;
                case SiwakeTyouhyouExportItem.TaikaKingaku:
                    return syoriki.UseSyouhizei ? Resources.対価金額 : string.Empty;
                case SiwakeTyouhyouExportItem.ZeikomiKingaku:
                    return syoriki.UseSyouhizei ? Resources.税込金額 : string.Empty;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKcod:
                    return syoriki.UseSyouhizei ? Resources.消費税対象科目コード : string.Empty;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuName:
                    return syoriki.UseSyouhizei ? Resources.消費税対象科目名称 : string.Empty;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuZeiKubun:
                    return syoriki.UseSyouhizei ? Resources.消費税対象科目税区分 : string.Empty;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                    //// エクスポートの条件と異なっていますが、SIASの動作に合わせています
                    return syoriki.UseSyouhizei ? Resources.消費税対象科目仕入_業種区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KesikomiCode:
                    return syoriki.KesikomiInfo.Use ? Resources.消込コード : string.Empty;
                case SiwakeTyouhyouExportItem.SiharaiDate:
                    return syoriki.UseSiharaibi ? Resources.支払日 : string.Empty;
                case SiwakeTyouhyouExportItem.SiharaiKubun:
                    return syoriki.UseSiharaiKubun ? Resources.支払区分 : string.Empty;
                case SiwakeTyouhyouExportItem.SiharaiKizitu:
                    return syoriki.UseSiharaiKizitu ? Resources.支払期日 : string.Empty;
                case SiwakeTyouhyouExportItem.KaisyuuDate:
                    return syoriki.UseKaisyuubi ? Resources.回収日 : string.Empty;
                case SiwakeTyouhyouExportItem.NyuukinKubun:
                    return syoriki.UseNyuukinKubun ? Resources.入金区分 : string.Empty;
                case SiwakeTyouhyouExportItem.KaisyuuKizitu:
                    return syoriki.UseKaisyuuKizitu ? Resources.回収期日 : string.Empty;
                case SiwakeTyouhyouExportItem.GaikaKingaku:
                    return gaikaItemEnabled ? Resources.外貨金額 : string.Empty;
                case SiwakeTyouhyouExportItem.GaikaTaikaKingaku:
                    return gaikaItemEnabled ? Resources.外貨対価金額 : string.Empty;
                case SiwakeTyouhyouExportItem.GaikaZeikomiKingaku:
                    return gaikaItemEnabled ? Resources.外貨税込金額 : string.Empty;
                case SiwakeTyouhyouExportItem.Rate:
                    return gaikaItemEnabled ? Resources.レート : string.Empty;
                case SiwakeTyouhyouExportItem.Sseq:
                    return Resources.仕訳SEQ;
                case SiwakeTyouhyouExportItem.SiwakeCreateDate:
                    return Resources.仕訳作成日;
                case SiwakeTyouhyouExportItem.SiwakeCreateUserCode:
                    return Resources.仕訳作成者コード;
                case SiwakeTyouhyouExportItem.SiwakeCreateUserName:
                    return Resources.仕訳作成者名;
                case SiwakeTyouhyouExportItem.SiwakeUpdateDate:
                    return Resources.仕訳更新日;
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserCode:
                    return Resources.仕訳更新者コード;
                case SiwakeTyouhyouExportItem.SiwakeUpdateUserName:
                    return Resources.仕訳更新者名;
                case SiwakeTyouhyouExportItem.Ccod:
                    return Resources.会社コード;
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// エクスポート時の、エクスポート項目の名称を取得します。
        /// </summary>
        /// <param name="exportItem">エクスポート項目</param>
        /// <param name="kaisya">会社情報</param>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="gaikaItemEnabled">外貨項目の使用可否</param>
        /// <param name="syouhizeiMaster">消費税マスター情報</param>
        /// <returns>エクスポート時の、エクスポート項目の名称</returns>
        public static string GetExportName(this SiwakeTyouhyouExportItem exportItem, Kaisya kaisya, Syoriki syoriki, bool gaikaItemEnabled, SyouhizeiMaster syouhizeiMaster)
        {
            switch (exportItem)
            {
                case SiwakeTyouhyouExportItem.KarikataSiireAndGyousyuKubun:
                    return syoriki.UseSyouhizei
                        ? (syouhizeiMaster.KazeiHousiki >= KazeiHousiki.KaniKazeiZigyouNo1
                            ? Resources.借方業種区分
                            : (syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou
                                ? Resources.借方仕入区分
                                : string.Empty))
                        : string.Empty;
                case SiwakeTyouhyouExportItem.KasikataSiireAndGyousyuKubun:
                    return syoriki.UseSyouhizei
                        ? (syouhizeiMaster.KazeiHousiki >= KazeiHousiki.KaniKazeiZigyouNo1
                            ? Resources.貸方業種区分
                            : (syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou
                                ? Resources.貸方仕入区分
                                : string.Empty))
                        : string.Empty;
                case SiwakeTyouhyouExportItem.SyouhizeiTaisyouKamokuSiireAndGyousyuKubun:
                    return syoriki.UseSyouhizei
                        ? (syouhizeiMaster.KazeiHousiki >= KazeiHousiki.KaniKazeiZigyouNo1
                            ? Resources.消費税対象科目業種区分
                            : (syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou
                                ? Resources.消費税対象科目仕入区分
                                : string.Empty))
                        : string.Empty;
                default:
                    return exportItem.GetName(kaisya, syoriki, gaikaItemEnabled);
            }
        }

        #endregion

        #region private methods

        /// <summary>
        /// ヘッダーフィールドの文字列を取得します。
        /// </summary>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="no">ヘッダーフィールドNo</param>
        /// <param name="isGetCodeString">コード文字列を取得するかどうか</param>
        /// <returns>ヘッダーフィールドの文字列</returns>
        private static string GetHeaderFieldString(Syoriki syoriki, int no, bool isGetCodeString)
        {
            var headerFieldInfo = syoriki.GetUniversalFieldInfo(true, no);

            if (headerFieldInfo.Use)
            {
                if (isGetCodeString)
                {
                    return headerFieldInfo.DataType == UniversalFieldDataType.Numeric || headerFieldInfo.DataType == UniversalFieldDataType.Alphanumeric
                        ? string.Format(Resources.Format0コード, headerFieldInfo.Name)
                        : string.IsNullOrEmpty(headerFieldInfo.Name) ? " " : headerFieldInfo.Name;
                }

                //// 名称は、マスターありの場合にのみ取得
                if (headerFieldInfo.IsCreateMaster)
                {
                    return string.Format(Resources.Format0名称, headerFieldInfo.Name);
                }
            }

            return string.Empty;
        }

        /// <summary>
        /// ユニバーサルフィールドの文字列を取得します。
        /// </summary>
        /// <param name="syoriki">処理期情報</param>
        /// <param name="no">ユニバーサルフィールドNo</param>
        /// <param name="isGetCodeString">コード文字列を取得するかどうか</param>
        /// <param name="isKarikata">借方かどうか</param>
        /// <returns>ユニバーサルフィールドの文字列</returns>
        private static string GetUniversalFieldString(Syoriki syoriki, int no, bool isGetCodeString, bool isKarikata)
        {
            var universalFieldInfo = syoriki.GetUniversalFieldInfo(false, no);

            if (universalFieldInfo.Use)
            {
                if (isGetCodeString)
                {
                    return universalFieldInfo.DataType == UniversalFieldDataType.Numeric || universalFieldInfo.DataType == UniversalFieldDataType.Alphanumeric
                        ? string.Format(Resources.Format01コード, isKarikata ? Resources.借方 : Resources.貸方, universalFieldInfo.Name)
                        : string.Format("{0}{1}", isKarikata ? Resources.借方 : Resources.貸方, universalFieldInfo.Name);
                }

                //// 名称は、マスターありの場合にのみ取得
                if (universalFieldInfo.IsCreateMaster)
                {
                    return string.Format(Resources.Format01名称, isKarikata ? Resources.借方 : Resources.貸方, universalFieldInfo.Name);
                }
            }

            return string.Empty;
        }

        #endregion
    }
}
