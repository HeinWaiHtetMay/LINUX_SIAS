﻿namespace Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou
{
    /// <summary>
    /// ExportResultClass
    /// </summary>
    public class ExportResultClass
    {
        #region プロパティ

        /// <summary>
        /// ExportContents
        /// </summary>
        public byte[] ExportContents { get; set; }

        /// <summary>
        /// ProcessingResult
        /// </summary>
        public ExportProcessingResult ProcessingResult { get; set; }
        #endregion
    }
}
