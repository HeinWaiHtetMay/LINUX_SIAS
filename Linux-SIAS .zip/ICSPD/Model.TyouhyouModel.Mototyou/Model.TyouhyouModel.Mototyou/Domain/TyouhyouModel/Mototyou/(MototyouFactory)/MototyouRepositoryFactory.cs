﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouRepositoryFactory
    {
        public MototyouRepositoryFactory(IMototyouRepository repository, IMototyouZibunItemRepository zibunItemRepository, IMototyouExportRepository exportRepository)
        {
            this.Repository = repository;
            this.ZibunItemRepository = zibunItemRepository;
            this.ExportRepository = exportRepository;
        }

        public IMototyouRepository Repository { get; private set; }

        public IMototyouZibunItemRepository ZibunItemRepository { get; private set; }

        public IMototyouExportRepository ExportRepository { get; private set; }
    }
}
