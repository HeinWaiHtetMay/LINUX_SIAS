﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Factory]
    public class MototyouFactoryCreator : IMototyouFactoryCreator
    {
        [AutoInjection]
        private IMototyouRepositoryFactoryCreator repositoryFactoryCreator = null;
        [AutoInjection]
        private InjectionContainer container = null;

        public virtual MototyouFactory Create(MototyouType mototyouType)
        {
            MasterType[] masterTypes;
            IMototyouQueryParameterValidator validator;
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    masterTypes = new MasterType[] { MasterType.Kamoku };
                    validator = this.container.GetInstance<KamokuMototyouQueryParameterValidator>();
                    break;
                case MototyouType.EdabanMototyou:
                    masterTypes = new MasterType[] { MasterType.Kamoku, MasterType.Edaban };
                    validator = this.container.GetInstance<EdabanMototyouQueryParameterValidator>();
                    break;
                case MototyouType.BumonMototyou:
                    masterTypes = new MasterType[] { MasterType.Bumon, MasterType.Kamoku };
                    validator = this.container.GetInstance<BumonMototyouQueryParameterValidator>();
                    break;
                case MototyouType.BumonKamokuEdabanMototyou:
                    masterTypes = new MasterType[] { MasterType.Bumon, MasterType.Kamoku, MasterType.Edaban };
                    validator = this.container.GetInstance<BumonKamokuEdabanMototyouQueryParameterValidator>();
                    break;
                case MototyouType.TorihikisakiMototyou:
                    masterTypes = new MasterType[] { MasterType.Kamoku, MasterType.Torihikisaki };
                    validator = this.container.GetInstance<TorihikisakiMototyouQueryParameterValidator>();
                    break;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    masterTypes = new MasterType[] { MasterType.Bumon, MasterType.Kamoku, MasterType.Torihikisaki };
                    validator = this.container.GetInstance<BumonKamokuTorihikisakiMototyouQueryParameterValidator>();
                    break;
                default:
                    return null;
            }

            //// リポジトリの具象クラスはIMototyouRepositoryFactoryCreatorの具象クラス（Persistence層）で生成
            return new MototyouFactory(masterTypes, validator, this.repositoryFactoryCreator.Create(mototyouType));
        }
    }
}
