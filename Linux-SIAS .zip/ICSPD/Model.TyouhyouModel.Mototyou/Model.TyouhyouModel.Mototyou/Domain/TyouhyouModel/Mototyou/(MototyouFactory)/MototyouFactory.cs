﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;

    public class MototyouFactory
    {
        private IReadOnlyList<MasterType> masterTypeList;
        private IMototyouQueryParameterValidator mototyouQueryParameterValidator;
        private MototyouRepositoryFactory repositoryFactory;

        public MototyouFactory(IReadOnlyList<MasterType> masterTypes, IMototyouQueryParameterValidator parameterValidator, MototyouRepositoryFactory repositoryFactory)
        {
            this.masterTypeList = masterTypes;
            this.mototyouQueryParameterValidator = parameterValidator;
            this.repositoryFactory = repositoryFactory;
        }

        public IReadOnlyList<MasterType> GetUseMasterTypeList() => this.masterTypeList;

        public IMototyouQueryParameterValidator GetMototyouQueryParameterValidator() => this.mototyouQueryParameterValidator;

        public IMototyouRepository GetMototyouRepository() => this.repositoryFactory.Repository;

        public IMototyouZibunItemRepository GetMototyouZibunItemRepository() => this.repositoryFactory.ZibunItemRepository;

        public IMototyouExportRepository GetExportRepository() => this.repositoryFactory.ExportRepository;
    }
}
