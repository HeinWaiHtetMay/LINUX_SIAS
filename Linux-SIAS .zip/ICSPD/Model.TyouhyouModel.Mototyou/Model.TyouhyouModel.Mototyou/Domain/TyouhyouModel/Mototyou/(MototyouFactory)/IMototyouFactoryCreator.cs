﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouFactoryCreator
    {
        MototyouFactory Create(MototyouType mototyouType);
    }
}
