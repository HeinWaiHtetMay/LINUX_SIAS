﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳問い合わせ時において、範囲問い合わせ条件の問題がある箇所を表示。
    /// </summary>
    public enum MototyouQueryParameterValidationResultInvalidRange
    {
        Date = 0,
        Bumon = 1,
        Kamoku = 2,
        Edaban = 3,
        Torihikisaki = 4,
        Pattern = 5
    }
}
