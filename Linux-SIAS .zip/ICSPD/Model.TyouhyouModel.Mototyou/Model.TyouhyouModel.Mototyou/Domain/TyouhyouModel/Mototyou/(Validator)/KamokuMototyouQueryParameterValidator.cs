﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Validation;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Service(ServiceType.DomainService)]
    public class KamokuMototyouQueryParameterValidator : AbstractMototyouQueryParameterValidator
    {
        [AutoInjection]
        private IKamokuRepository kamokuRepository = null;
        [AutoInjection]
        private ISecurityPatternPermittedZaimuKamokuRepository securityPatternPermittedZaimuKamokuRepository = null;
        [AutoInjection]
        private IKamokuZandakaRepository kamokuZandakaRepository = null;
        [AutoInjection]
        private IKisokugaiSyuukeiKamokuUtiwakeRepository kisokugaiSyuukeiKamokuUtiwakeRepository = null;

        protected override string MasterName => Properties.Resources.科目;

        /// <summary>
        /// 範囲の大小チェック
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kamokuOutputOrder"></param>
        /// <returns></returns>
        protected override ValidationResult ValidateRangeCompare(MototyouQueryParameter queryParameter, KamokuOutputOrder kamokuOutputOrder)
        {
            return this.ValidateIsEndKamokuLargerThanStartKamoku(queryParameter, kamokuOutputOrder);
        }

        /// <summary>
        /// 範囲内の項目存在チェック
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected override ValidationResult ValidateExistsMasterRangeItem(MototyouQueryParameter queryParameter, int kesn)
        {
            var existsAvailableMeisaiKamoku = new Func<bool>(() =>
            {
                switch (queryParameter.OptionComposite.QueryOption.KamokuType)
                {
                    // [科目分類：規則外集計科目]
                    case MototyouKamokuType.KisokugaiSyuukeiKamoku:
                        return this.GetExistsRangeItemWhenKamokuTypeIsKisokugaiSyuukeiKamoku(queryParameter, kesn, null);

                    // [科目分類：小科目または集計小科目]
                    case MototyouKamokuType.SyouKamoku:
                    case MototyouKamokuType.SyuukeiSyouKamoku:
                        return this.GetExistsRangeItemWhenKamokuTypeIsSyouKamokuOrSyuukeiSyouKamoku(queryParameter, kesn);

                    // [科目分類：明細科目]
                    case MototyouKamokuType.MeisaiKamoku:
                    default:
                        return this.GetExistsRangeItemWhenKamokuTypeIsMeisaiKamoku(queryParameter, kesn);
                }
            }).Invoke();

            if (!existsAvailableMeisaiKamoku)
            {
                return new MototyouQueryParameterValidationResult(
                    false,
                    queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType == MototyouMasterRangeQueryConditionType.NotUse ? MototyouQueryParameterValidationResultInvalidReason.TargetKoumokuNotExists : MototyouQueryParameterValidationResultInvalidReason.RangeKoumokuNotExists,
                    MototyouQueryParameterValidationResultInvalidRange.Kamoku);
            }

            return ValidationResult.Valid;
        }

        protected override bool IsItemInput(MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            return kobetuItem.Kamoku != null || kobetuItem.Pkicd != null;
        }

        protected override bool GetExistsKobetuItem(MototyouQueryConditionKobetuSiteiItem kobetuItem, int kesn, MototyouQueryParameter queryParameter)
        {
            if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku)
            {
                //// 規則外集計科目は紐づく明細科目の存在チェック（セキュリティチェック不要）
                var childrenKicdList = this.kisokugaiSyuukeiKamokuUtiwakeRepository.GetAllChildrenKicdListByKesnAndKicd(kesn, kobetuItem.Pkicd, false);
                return this.GetExistsItemInKisokugaiSyuukeiKamokuChildrenKicdList(childrenKicdList, kesn, queryParameter, kobetuItem);
            }
            else if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyouKamoku
                     || queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyuukeiSyouKamoku)
            {
                //// 小科目・集計小科目は紐づく明細科目の存在チェック（セキュリティ込み）
                var kicdRange = this.GetKicdRangeByKicd(kobetuItem.Kamoku.Kicd);
                return this.kamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndKamokuKanaRangesOrderByKamokuOutputOrder(
                    kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    null,
                    null,
                    KamokuOutputOrder.ByInnerCode,
                    queryParameter.SecurityContext,
                    SecurityKubun.Output).Count > 0;
            }

            //// 明細科目は入力時点で存在チェック（セキュリティ込み）はOKであるはず
            return true;
        }

        protected override bool GetExistsMeisaiItem(int kesn, string kicd, MototyouQueryParameter queryParameter, MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            return this.kamokuRepository.FindParentAndChildrenByKesnAndParentKicdOrderByKicd(kesn, kicd).Exists(kamoku => kamoku.Kubun == KamokuKubun.Meisai);
        }

        private bool GetExistsRangeItemWhenKamokuTypeIsMeisaiKamoku(MototyouQueryParameter queryParameter, int kesn)
        {
            return this.kamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndKamokuKanaRangesOrderByKamokuOutputOrder(
                kesn,
                queryParameter.QueryCondition.QueryConditionRange.StartKamoku?.Kicd,
                queryParameter.QueryCondition.QueryConditionRange.EndKamoku?.Kicd,
                null,
                null,
                queryParameter.KamokuOutputOrder, //// 科目出力順はオプション設定に従う
                queryParameter.SecurityContext,
                SecurityKubun.Output).Count > 0;
        }

        private bool GetExistsRangeItemWhenKamokuTypeIsSyouKamokuOrSyuukeiSyouKamoku(MototyouQueryParameter queryParameter, int kesn)
        {
            var syuukeiKamokuRangeList = this.kamokuRepository.FindByKesnAndKamokuKubun(kesn, queryParameter.OptionComposite.QueryOption.KamokuType.GetKamokuKubun())
                .Where(kamoku =>
                {
                    var kamokuComparer = new KamokuComparer(KamokuOutputOrder.ByInnerCode);
                    return kamokuComparer.Compare(queryParameter.QueryCondition.QueryConditionRange.StartKamoku, kamoku) <= 0
                           && (queryParameter.QueryCondition.QueryConditionRange.EndKamoku == null
                                   ? -1
                                   : kamokuComparer.Compare(kamoku, queryParameter.QueryCondition.QueryConditionRange.EndKamoku)) <= 0;
                });

            if (queryParameter.SecurityContext.UseBusyobetuSecurity)
            {
                var permittedSyuukeiKamokuList = this.securityPatternPermittedZaimuKamokuRepository.GetKicdSetByKesnAndSecurityKubunAndPatternNoAndKamokuKubun(
                    kesn,
                    SecurityKubun.Output,
                    queryParameter.SecurityContext.SecurityPattern.PatternNo,
                    queryParameter.OptionComposite.QueryOption.KamokuType.GetKamokuKubun());
                var permittedMeisaiKamokuList = this.securityPatternPermittedZaimuKamokuRepository.GetKicdSetByKesnAndSecurityKubunAndPatternNoAndKamokuKubun(
                    kesn,
                    SecurityKubun.Output,
                    queryParameter.SecurityContext.SecurityPattern.PatternNo,
                    KamokuKubun.Meisai);

                //// 使用可能な集計科目リスト
                var availableSyuukeiKamokuRangeList = syuukeiKamokuRangeList.Where(syuukeiKamoku => permittedSyuukeiKamokuList.Exists(permittedKicd => permittedKicd == syuukeiKamoku.InnerCode));
                //// 集計科目に紐づいた使用可能な明細科目が存在するかどうか
                return availableSyuukeiKamokuRangeList.Exists(syuukeiKamoku => this.kamokuRepository.FindParentAndChildrenByKesnAndParentKicdOrderByKicd(kesn, syuukeiKamoku.InnerCode)
                                            　　　　　　　　　.Exists(kamoku => kamoku.Kubun == KamokuKubun.Meisai && permittedMeisaiKamokuList.Exists(permittedKicd => permittedKicd == kamoku.InnerCode)));
            }
            else
            {
                //// 集計科目に紐づいた明細科目が存在するかどうか
                return syuukeiKamokuRangeList.Exists(syuukeiKamoku => this.kamokuRepository.FindParentAndChildrenByKesnAndParentKicdOrderByKicd(kesn, syuukeiKamoku.InnerCode)
                    　　　　　　　　　　　　　　　　 .Exists(kamoku => kamoku.Kubun == KamokuKubun.Meisai));
            }
        }
    }
}
