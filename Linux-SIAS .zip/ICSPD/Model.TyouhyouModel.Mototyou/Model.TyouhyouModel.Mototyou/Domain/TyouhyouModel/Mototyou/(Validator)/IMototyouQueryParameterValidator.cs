﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    public interface IMototyouQueryParameterValidator
    {
        /// <summary>
        /// 問い合わせ条件検証処理
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        MototyouQueryParameterValidationResult ValidateQueryParameter(MototyouQueryParameter queryParameter);
    }
}