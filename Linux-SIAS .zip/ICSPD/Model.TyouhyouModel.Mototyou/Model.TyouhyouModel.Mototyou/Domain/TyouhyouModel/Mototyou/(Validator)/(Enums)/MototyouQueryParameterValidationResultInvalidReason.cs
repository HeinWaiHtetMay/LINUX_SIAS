﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳問い合わせ時において、問い合わせ条件の問題がある箇所を表示。
    /// </summary>
    public enum MototyouQueryParameterValidationResultInvalidReason
    {
        /// <summary>
        /// レイアウトパターンが存在しない
        /// </summary>
        LayoutPatternNotExists = 0,

        /// <summary>
        /// 指定された条件に該当する項目が存在しない。
        /// </summary>
        TargetKoumokuNotExists = 1,

        /// <summary>
        /// 範囲指定が開始 ＞ 終了 になっている。
        /// </summary>
        StartIsLargerThanEnd = 2,

        /// <summary>
        /// 入力された範囲に該当する項目が存在しない。
        /// </summary>
        RangeKoumokuNotExists = 3,

        /// <summary>
        /// 個別指定で入力された内容に該当する項目が存在しない。
        /// </summary>
        KobetuKoumokuNotExists = 4,

        /// <summary>
        /// 個別指定で入力がない。
        /// </summary>
        KobetuNotInput = 5,

        /// <summary>
        /// 処理月範囲内に仕訳が存在しない。
        /// </summary>
        DenpyouNotExists = 6,

        /// <summary>
        /// 入力された問い合わせ条件そのものには問題が無いが、
        /// 大量に元帳が出力される可能性がある場合
        /// </summary>
        MassMototyouWillOutput = 98,
    }
}
