﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouQueryParameterValidationResultInvalidReasonExtension
    {
        public static string GetMessageText(this MototyouQueryParameterValidationResultInvalidReason invalidReason)
        {
            switch (invalidReason)
            {
                case MototyouQueryParameterValidationResultInvalidReason.LayoutPatternNotExists:
                    return Properties.Resources.レイアウトのパターンを入力してください;
                case MototyouQueryParameterValidationResultInvalidReason.TargetKoumokuNotExists:
                    return Properties.Resources.出力対象となる項目が存在しません;
                case MototyouQueryParameterValidationResultInvalidReason.StartIsLargerThanEnd:
                    return Properties.Resources.開始_終了になっています;
                case MototyouQueryParameterValidationResultInvalidReason.RangeKoumokuNotExists:
                    return Properties.Resources.入力された範囲に該当する項目が存在しません;
                case MototyouQueryParameterValidationResultInvalidReason.KobetuKoumokuNotExists:
                    return Properties.Resources.入力された内容に該当する_が存在しません;
                case MototyouQueryParameterValidationResultInvalidReason.KobetuNotInput:
                    return Properties.Resources.出力する_を入力してください;
                case MototyouQueryParameterValidationResultInvalidReason.DenpyouNotExists:
                    return Properties.Resources.処理月範囲内に仕訳が入力されていません;
                case MototyouQueryParameterValidationResultInvalidReason.MassMototyouWillOutput:
                    return Properties.Resources.項目指定なしが選択されているので大量に出力される可能性があります_元帳を出力しますか;
                default:
                    return string.Empty;
            }
        }
    }
}
