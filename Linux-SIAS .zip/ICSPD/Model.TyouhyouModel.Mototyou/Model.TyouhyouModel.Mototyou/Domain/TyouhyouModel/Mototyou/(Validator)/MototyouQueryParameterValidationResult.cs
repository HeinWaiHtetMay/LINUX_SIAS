﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Framework.Core.Validation;

    /// <summary>
    /// 検証結果インターフェースに加え、元帳問合せ条件の何に問題があるかを返すようにします。（検証結果インターフェースを継承）
    /// </summary>
    public class MototyouQueryParameterValidationResult : ValidationResult
    {
        public MototyouQueryParameterValidationResult(bool isValid)
            : base(isValid)
        {
        }

        public MototyouQueryParameterValidationResult(bool isValid, string invalidMessage)
            : base(isValid, invalidMessage)
        {
        }

        public MototyouQueryParameterValidationResult(bool isValid, MototyouQueryParameterValidationResultInvalidReason invalidReason)
            : base(isValid, invalidReason.GetMessageText())
        {
            this.InvalidReason = invalidReason;
        }

        public MototyouQueryParameterValidationResult(bool isValid, MototyouQueryParameterValidationResultInvalidReason invalidReason, int invalidIndex)
            : base(isValid, invalidReason.GetMessageText())
        {
            this.InvalidReason = invalidReason;
            this.InvalidKobetuSiteiRowIndex = invalidIndex;
        }

        public MototyouQueryParameterValidationResult(bool isValid, MototyouQueryParameterValidationResultInvalidReason invalidReason, MototyouQueryParameterValidationResultInvalidRange invalidRange)
            : base(isValid, invalidReason.GetMessageText())
        {
            this.InvalidReason = invalidReason;
            this.InvalidRange = invalidRange;
        }

        public MototyouQueryParameterValidationResult(bool isValid, MototyouQueryParameterValidationResultInvalidReason invalidReason, string koumokuName, int invalidIndex)
            : base(isValid, string.Format(invalidReason.GetMessageText(), koumokuName))
        {
            this.InvalidReason = invalidReason;
            this.InvalidKobetuSiteiRowIndex = invalidIndex;
        }

        /// <summary>
        /// エラー結果詳細（問い合わせ条件として、どの部分に問題があるか）を返します。
        /// </summary>
        public MototyouQueryParameterValidationResultInvalidReason InvalidReason { get; }

        /// <summary>
        /// 範囲指定されている場合に問い合わせ条件に問題がある範囲指定箇所を返します。
        /// </summary>
        public MototyouQueryParameterValidationResultInvalidRange InvalidRange { get; }

        /// <summary>
        /// 個別指定されている場合において、問い合わせ条件に問題がある組み合わせを持つリストのインデックスを返します。
        /// （複数ある場合は、最も若い番号が格納されます）
        /// </summary>
        public int InvalidKobetuSiteiRowIndex { get; }
    }
}
