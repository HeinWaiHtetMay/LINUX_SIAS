﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Types;
    using Icsp.Framework.Core.Validation;
    using Icsp.Open21.Domain.MasterModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Service(ServiceType.DomainService)]
    public abstract class AbstractMototyouQueryParameterValidator : IMototyouQueryParameterValidator
    {
        [AutoInjection]
        private IMototyouLayoutPatternRepository mototyouLayoutPatternRepository = null;
        [AutoInjection]
        private IMototyouQueryConditionPatternRepository mototyouQueryConditionPatternRepository = null;
        [AutoInjection]
        private IKisokugaiSyuukeiKamokuRepository kisokugaiSyuukeiKamokuRepository = null;
        [AutoInjection]
        private IKisokugaiSyuukeiKamokuUtiwakeRepository kisokugaiSyuukeiKamokuUtiwakeRepository = null;

        protected abstract string MasterName { get; }

        /// <summary>
        /// 問い合わせ条件検証処理
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        public virtual MototyouQueryParameterValidationResult ValidateQueryParameter(MototyouQueryParameter queryParameter)
        {
            //// 各チェック後の結果格納用変数
            //// 問題なしならValidationResult.Validが、そうでなければMototyouQueryParameterValidationResultのインスタンスが帰ってくる
            ValidationResult validationResult;

            // 入力されたレイアウトが適切か否か
            validationResult = this.ValidateLayoutPattern(queryParameter.OptionComposite.QueryOption.LayoutPatternNo);
            if (validationResult != ValidationResult.Valid)
            {
                return (MototyouQueryParameterValidationResult)validationResult;
            }

            // 開始日付,終了日付が適切か否か
            validationResult = this.ValidateIsEndLargerThanStartForDateRange(queryParameter, MototyouQueryParameterValidationResultInvalidRange.Date);
            if (validationResult != ValidationResult.Valid)
            {
                return (MototyouQueryParameterValidationResult)validationResult;
            }

            switch (queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType)
            {
                //// 項目指定なしの場合
                case MototyouMasterRangeQueryConditionType.NotUse:
                    return this.ValidateAllItem(queryParameter, queryParameter.Kesn);
                //// 範囲指定の場合
                case MototyouMasterRangeQueryConditionType.Range:
                    validationResult = queryParameter.QueryCondition.QueryConditionPatternType.UsePattern()
                        ? this.ValidatePatternRangeItems(queryParameter, queryParameter.Kesn)
                        : this.ValidateMasterRangeItems(queryParameter, queryParameter.Kesn, queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku ? queryParameter.KamokuOutputOrder : KamokuOutputOrder.ByInnerCode);
                    break;
                //// 個別指定の場合
                default:
                    validationResult = queryParameter.QueryCondition.QueryConditionPatternType.UsePattern()
                        ? this.ValidatePatternKobetuItemList(queryParameter.QueryCondition)
                        : this.ValidateKobetuItemList(queryParameter, queryParameter.Kesn);
                    break;
            }

            return validationResult == ValidationResult.Valid ? new MototyouQueryParameterValidationResult(true) : (MototyouQueryParameterValidationResult)validationResult;
        }

        /// <summary>
        /// 日付範囲が終了>開始になっているか
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="invalidRange"></param>
        /// <returns></returns>
        protected ValidationResult ValidateIsEndLargerThanStartForDateRange(MototyouQueryParameter queryParameter, MototyouQueryParameterValidationResultInvalidRange invalidRange)
        {
            if (queryParameter.StartCkei > queryParameter.EndCkei)
            {
                //// 整理月チェックボックスにより処理月が終了>開始になっているか
                return new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.StartIsLargerThanEnd, invalidRange);
            }

            if (queryParameter.KaisyaSyoriKikan.StartSyorituki.GetSeirituki()?.Ckei == queryParameter.KaisyaSyoriKikan.EndSyorituki.Ckei
                && (!queryParameter.QueryCondition.UseSeiritukiOnStartData && queryParameter.QueryCondition.UseSeiritukiOnEndData))
            {
                //// 処理月範囲が対応する通常月～整理月で、終了日付の整理月チェックボックスのみONとなっている場合、検証OK
                return ValidationResult.Valid;
            }

            return this.ValidateIsEndLargerThanStart(queryParameter.QueryCondition.StartDate, queryParameter.QueryCondition.EndDate, MototyouQueryParameterValidationResultInvalidRange.Date);
        }

        /// <summary>
        /// 範囲指定が終了>開始になっているか
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <param name="invalidRange"></param>
        /// <returns></returns>
        protected ValidationResult ValidateIsEndLargerThanStart(IComparable start, IComparable end, MototyouQueryParameterValidationResultInvalidRange invalidRange)
        {
            return start == null || end == null || start.CompareTo(end) <= 0
                ? ValidationResult.Valid
                : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.StartIsLargerThanEnd, invalidRange);
        }

        /// <summary>
        /// コード範囲指定が終了>開始になっているか
        /// </summary>
        /// <param name="startCode"></param>
        /// <param name="endCode"></param>
        /// <param name="invalidRange"></param>
        /// <returns></returns>
        protected ValidationResult ValidateIsEndCodeLargerThanStartCode(string startCode, string endCode, MototyouQueryParameterValidationResultInvalidRange invalidRange)
        {
            return this.ValidateIsEndLargerThanStart(startCode, endCode, invalidRange);
        }

        /// <summary>
        /// 科目範囲指定が終了>開始になっているか
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kamokuOutputOrder"></param>
        /// <returns></returns>
        protected ValidationResult ValidateIsEndKamokuLargerThanStartKamoku(MototyouQueryParameter queryParameter, KamokuOutputOrder kamokuOutputOrder)
        {
            if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku)
            {
                return this.ValidateIsEndCodeLargerThanStartCode(
                    queryParameter.QueryCondition.QueryConditionRange.StartPkicd,
                    queryParameter.QueryCondition.QueryConditionRange.EndPkicd,
                    MototyouQueryParameterValidationResultInvalidRange.Kamoku);
            }
            else
            {
                //// 科目比較用クラス
                var comparer = new KamokuComparer(kamokuOutputOrder);
                return queryParameter.QueryCondition.QueryConditionRange.EndKamoku == null
                    ? ValidationResult.Valid
                    : comparer.Compare(queryParameter.QueryCondition.QueryConditionRange.StartKamoku, queryParameter.QueryCondition.QueryConditionRange.EndKamoku) <= 0
                           ? ValidationResult.Valid
                           : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.StartIsLargerThanEnd, MototyouQueryParameterValidationResultInvalidRange.Kamoku);
            }
        }

        /// <summary>
        /// 項目が存在するかどうかの検証結果を返す
        /// </summary>
        /// <param name="existsItem"></param>
        /// <returns></returns>
        protected ValidationResult GetValidationResultExistsItem(bool existsItem)
        {
            return existsItem
                ? ValidationResult.Valid
                : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.TargetKoumokuNotExists);
        }

        /// <summary>
        /// レイアウトパターン検証
        /// </summary>
        /// <param name="patternNo"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidateLayoutPattern(int? patternNo)
        {
            return this.mototyouLayoutPatternRepository.FindByPatternNo(patternNo.GetValueOrDefault()) != null
                ? ValidationResult.Valid
                : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.LayoutPatternNotExists);
        }

        /// <summary>
        /// 項目指定なしの検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected virtual MototyouQueryParameterValidationResult ValidateAllItem(MototyouQueryParameter queryParameter, int kesn)
        {
            //// 項目指定がない場合でもセキュリティのチェックをする必要があるので、範囲指定のチェックを行う（範囲指定されていないので全項目をチェックする）
            var validationResult = this.ValidateMasterRangeItems(queryParameter, kesn, KamokuOutputOrder.ByInnerCode);

            return validationResult == ValidationResult.Valid
                ? new MototyouQueryParameterValidationResult(true, MototyouQueryParameterValidationResultInvalidReason.MassMototyouWillOutput)
                : (MototyouQueryParameterValidationResult)validationResult;
        }

        /// <summary>
        /// パターン範囲指定の検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidatePatternRangeItems(MototyouQueryParameter queryParameter, int kesn)
        {
            ValidationResult validationResult;
            validationResult = this.ValidateIsEndLargerThanStart(
                queryParameter.QueryCondition.QueryConditionRange.StartMototyouQueryConditionPatternNo,
                queryParameter.QueryCondition.QueryConditionRange.EndMototyouQueryConditionPatternNo,
                MototyouQueryParameterValidationResultInvalidRange.Pattern);
            if (!validationResult.IsValid)
            {
                return validationResult;
            }

            validationResult = this.ValidateExistsPatternRangeItem(queryParameter, kesn);
            return validationResult;
        }

        /// <summary>
        /// パターン範囲指定内にパターンが存在するか
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidateExistsPatternRangeItem(MototyouQueryParameter queryParameter, int kesn)
        {
            var patternList = this.mototyouQueryConditionPatternRepository.FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNoRange(
                kesn,
                queryParameter.OptionComposite.QueryOption.MototyouType,
                queryParameter.OptionComposite.QueryOption.BumonType,
                queryParameter.OptionComposite.QueryOption.KamokuType.GetKamokuKubun(),
                queryParameter.QueryCondition.QueryConditionPatternType,
                queryParameter.QueryCondition.QueryConditionRange.StartMototyouQueryConditionPatternNo,
                queryParameter.QueryCondition.QueryConditionRange.EndMototyouQueryConditionPatternNo);
            return patternList.Count() > 0
                ? ValidationResult.Valid
                : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.RangeKoumokuNotExists, MototyouQueryParameterValidationResultInvalidRange.Pattern);
        }

        /// <summary>
        /// マスター範囲指定の検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <param name="kamokuOutputOrder"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidateMasterRangeItems(MototyouQueryParameter queryParameter, int kesn, KamokuOutputOrder kamokuOutputOrder)
        {
            ValidationResult validationResult;
            validationResult = this.ValidateRangeCompare(queryParameter, kamokuOutputOrder);

            if (validationResult != ValidationResult.Valid)
            {
                return validationResult;
            }

            validationResult = this.ValidateExistsMasterRangeItem(queryParameter, kesn);
            return validationResult;
        }

        /// <summary>
        /// 範囲項目の開始終了比較検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kamokuOutputOrder"></param>
        /// <returns></returns>
        protected abstract ValidationResult ValidateRangeCompare(MototyouQueryParameter queryParameter, KamokuOutputOrder kamokuOutputOrder);

        /// <summary>
        /// マスター範囲指定内の存在検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected abstract ValidationResult ValidateExistsMasterRangeItem(MototyouQueryParameter queryParameter, int kesn);

        /// <summary>
        /// パターン個別項目を入力しているかチェック
        /// </summary>
        /// <param name="queryCondition"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidatePatternKobetuItemList(MototyouQueryCondition queryCondition)
        {
            foreach (var item in queryCondition.KobetuSiteiItemList)
            {
                if (item.MototyouQueryConditionPattern != null)
                {
                    return ValidationResult.Valid;
                }
            }

            return new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.KobetuNotInput, "パターン", 0);
        }

        /// <summary>
        /// 項目個別指定の検証
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <returns></returns>
        protected virtual ValidationResult ValidateKobetuItemList(MototyouQueryParameter queryParameter, int kesn)
        {
            bool existsInput = false; // 入力された項目が1つでもあるかどうか

            // 問題個所のインデックスが欲しいのでfor文で
            for (int i = 0; i < queryParameter.QueryCondition.KobetuSiteiItemList.Count; i++)
            {
                // 項目が入力されているかどうか
                bool isItemInput = this.IsItemInput(queryParameter.QueryCondition.KobetuSiteiItemList[i]);

                // 入力項目の存在チェック
                if (isItemInput && !this.GetExistsKobetuItem(queryParameter.QueryCondition.KobetuSiteiItemList[i], kesn, queryParameter))
                {
                    return new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.KobetuKoumokuNotExists, this.MasterName, i);
                }

                // 入力項目が一つでもあればtrue
                existsInput |= isItemInput;
            }

            return existsInput ? ValidationResult.Valid : new MototyouQueryParameterValidationResult(false, MototyouQueryParameterValidationResultInvalidReason.KobetuNotInput, this.MasterName, 0);
        }

        /// <summary>
        /// 個別項目を入力しているかチェック
        /// </summary>
        /// <param name="kobetuItem"></param>
        /// <returns></returns>
        protected abstract bool IsItemInput(MototyouQueryConditionKobetuSiteiItem kobetuItem);

        /// <summary>
        /// 個別項目の存在チェック
        /// </summary>
        /// <param name="kobetuItem"></param>
        /// <param name="kesn"></param>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        protected abstract bool GetExistsKobetuItem(MototyouQueryConditionKobetuSiteiItem kobetuItem, int kesn, MototyouQueryParameter queryParameter);

        /// <summary>
        /// 規則外集計科目の範囲指定内に、項目が存在するかどうか（セキュリティはチェック不要）
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kesn"></param>
        /// <param name="kobetuItem">個別指定の場合の個別アイテム</param>
        /// <returns></returns>
        protected virtual bool GetExistsRangeItemWhenKamokuTypeIsKisokugaiSyuukeiKamoku(MototyouQueryParameter queryParameter, int kesn, MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            //// 範囲指定した規則外集計科目リスト
            var kisokugaiSyuukeiKamokuList = this.kisokugaiSyuukeiKamokuRepository.FindByKesn(kesn).Where(kisokugaiSyuukeiKamoku =>
            {
                return (queryParameter.QueryCondition.QueryConditionRange.StartPkicd ?? "999000000000000").CompareTo(kisokugaiSyuukeiKamoku.Pkicd) <= 0
                    && (queryParameter.QueryCondition.QueryConditionRange.EndPkicd ?? "999999999999999").CompareTo(kisokugaiSyuukeiKamoku.Pkicd) >= 0;
            });

            //// 範囲指定した規則外集計科目に紐づく科目の内部コードリスト
            var kisokugaiSyuukeiKamokuChildrenKicdList = kisokugaiSyuukeiKamokuList.SelectMany(kisokugai =>
            this.kisokugaiSyuukeiKamokuUtiwakeRepository.GetAllChildrenKicdListByKesnAndKicd(kesn, kisokugai.Pkicd, false)).ToList();

            //// 明細科目が１つでも紐づいているかどうか
            return this.GetExistsItemInKisokugaiSyuukeiKamokuChildrenKicdList(kisokugaiSyuukeiKamokuChildrenKicdList, kesn, queryParameter, kobetuItem);
        }

        protected virtual bool GetExistsItemInKisokugaiSyuukeiKamokuChildrenKicdList(IList<string> kicdList, int kesn, MototyouQueryParameter queryParameter, MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            return kicdList.Exists(kicd =>
            {
                if (kicd.Substring(0, 3) == "999")
                {
                    // 規則外集計科目である場合は紐づく科目に明細科目があるかどうかチェック
                    var childrenKicdList = this.kisokugaiSyuukeiKamokuUtiwakeRepository.GetAllChildrenKicdListByKesnAndKicd(kesn, kicd, false);
                    return this.GetExistsItemInKisokugaiSyuukeiKamokuChildrenKicdList(childrenKicdList, kesn, queryParameter, kobetuItem);
                }
                else
                {
                    // 規則外集計科目以外の場合は、下位に明細科目があるかどうかチェック
                    return this.GetExistsMeisaiItem(kesn, kicd, queryParameter, kobetuItem);
                }
            });
        }

        protected abstract bool GetExistsMeisaiItem(int kesn, string kicd, MototyouQueryParameter queryParameter, MototyouQueryConditionKobetuSiteiItem kobetuSiteiItem);

        /// <summary>
        /// 範囲指定内の全明細科目が取得できるよう、集計科目の場合は終了側の末尾を999～に補正した内部コード範囲を取得
        /// </summary>
        /// <param name="kamokuType"></param>
        /// <param name="startKamoku"></param>
        /// <param name="endKamoku"></param>
        /// <returns></returns>
        protected virtual Range<string> GetKicdRangeByKamokuTypeAndKamokuRange(MototyouKamokuType kamokuType, Kamoku startKamoku, Kamoku endKamoku)
        {
            switch (kamokuType)
            {
                case MototyouKamokuType.SyuukeiSyouKamoku:
                    return new Range<string>(startKamoku?.Kicd, endKamoku?.Kicd.Substring(0, 9).PadRight(15, '9'));
                case MototyouKamokuType.SyouKamoku:
                    return new Range<string>(startKamoku?.Kicd, endKamoku?.Kicd.Substring(0, 12).PadRight(15, '9'));
                default:
                    return new Range<string>(startKamoku?.Kicd, endKamoku?.Kicd);
            }
        }

        /// <summary>
        /// 指定した科目内部コードの全下位科目を取得できるよう内部コード範囲を取得
        /// </summary>
        /// <param name="kicd"></param>
        /// <returns></returns>
        protected virtual Range<string> GetKicdRangeByKicd(string kicd)
        {
            if (kicd.Substring(3) == "000000000000")
            {
                // 大科目
                return new Range<string>(kicd, kicd.Substring(0, 3).PadRight(15, '9'));
            }
            else if (kicd.Substring(6) == "000000000")
            {
                // 中科目
                return new Range<string>(kicd, kicd.Substring(0, 6).PadRight(15, '9'));
            }
            else if (kicd.Substring(9) == "000000")
            {
                // 集計小科目
                return new Range<string>(kicd, kicd.Substring(0, 9).PadRight(15, '9'));
            }
            else if (kicd.Substring(12) == "000")
            {
                // 小科目
                return new Range<string>(kicd, kicd.Substring(0, 12).PadRight(15, '9'));
            }
            else
            {
                // 明細科目
                return new Range<string>(kicd, kicd);
            }
        }
    }
}
