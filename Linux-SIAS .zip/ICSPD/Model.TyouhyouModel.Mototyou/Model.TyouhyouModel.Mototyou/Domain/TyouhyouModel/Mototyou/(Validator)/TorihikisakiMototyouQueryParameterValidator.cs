﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Validation;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Service(ServiceType.DomainService)]
    public class TorihikisakiMototyouQueryParameterValidator : AbstractMototyouQueryParameterValidator
    {
        [AutoInjection]
        private ITorihikisakiKamokuZandakaRepository torihikisakiKamokuZandakaRepository = null;
        [AutoInjection]
        private IKisokugaiSyuukeiKamokuUtiwakeRepository kisokugaiSyuukeiKamokuUtiwakeRepository = null;

        protected override string MasterName => Properties.Resources.科目取引先;

        /// <summary>
        /// 範囲の大小チェック
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="kamokuOutputOrder"></param>
        /// <returns></returns>
        protected override ValidationResult ValidateRangeCompare(MototyouQueryParameter queryParameter, KamokuOutputOrder kamokuOutputOrder)
        {
            ValidationResult validationResult;
            //// 科目範囲の大小チェック
            validationResult = this.ValidateIsEndKamokuLargerThanStartKamoku(queryParameter, kamokuOutputOrder);
            if (validationResult != ValidationResult.Valid)
            {
                return validationResult;
            }

            //// 取引先範囲の大小チェック
            validationResult = this.ValidateIsEndCodeLargerThanStartCode(
                queryParameter.QueryCondition.QueryConditionRange.StartTorihikisakiCode,
                queryParameter.QueryCondition.QueryConditionRange.EndTorihikisakiCode,
                MototyouQueryParameterValidationResultInvalidRange.Torihikisaki);
            return validationResult;
        }

        protected override ValidationResult ValidateExistsMasterRangeItem(MototyouQueryParameter queryParameter, int kesn)
        {
            var existsAvailableKamokuTorihikisaki = queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku
                ? this.GetExistsRangeItemWhenKamokuTypeIsKisokugaiSyuukeiKamoku(queryParameter, kesn, null)
                : this.GetExistsRangeItemWhenKamokuTypeIsMeisaiOrSyouOrSyuukeiSyouKamoku(queryParameter, kesn);

            if (!existsAvailableKamokuTorihikisaki)
            {
                return new MototyouQueryParameterValidationResult(
                    false,
                    MototyouQueryParameterValidationResultInvalidReason.RangeKoumokuNotExists,
                    MototyouQueryParameterValidationResultInvalidRange.Kamoku);
            }

            return ValidationResult.Valid;
        }

        protected override bool IsItemInput(MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            return (kobetuItem.Kamoku != null || kobetuItem.Pkicd != null)
                && kobetuItem.TorihikisakiCode != null;
        }

        protected override bool GetExistsKobetuItem(MototyouQueryConditionKobetuSiteiItem kobetuItem, int kesn, MototyouQueryParameter queryParameter)
        {
            if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku)
            {
                //// 規則外集計科目の場合
                var childrenKicdList = this.kisokugaiSyuukeiKamokuUtiwakeRepository.GetAllChildrenKicdListByKesnAndKicd(kesn, kobetuItem.Pkicd, false);
                return this.GetExistsItemInKisokugaiSyuukeiKamokuChildrenKicdList(childrenKicdList, kesn, queryParameter, kobetuItem);
            }
            else if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyouKamoku
                     || queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyuukeiSyouKamoku)
            {
                //// 小科目または集計小科目の場合
                var kicdRange = this.GetKicdRangeByKicd(kobetuItem.Kamoku.Kicd);
                return this.torihikisakiKamokuZandakaRepository.GetExistsByPrimaryKeyRangesWithSecurity(
                    kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    kobetuItem.TorihikisakiCode,
                    kobetuItem.TorihikisakiCode,
                    KamokuOutputOrder.ByInnerCode,
                    queryParameter.SecurityContext,
                    SecurityModel.SecurityKubun.Output);
            }

            //// 明細科目の場合、セキュリティチェックは入力時点でOKのはずなので不要
            return this.torihikisakiKamokuZandakaRepository.GetExistsByKesnAndKicdAndTrcd(kesn, kobetuItem.Kamoku.Kicd, kobetuItem.TorihikisakiCode);
        }

        protected override bool GetExistsMeisaiItem(int kesn, string kicd, MototyouQueryParameter queryParameter, MototyouQueryConditionKobetuSiteiItem kobetuItem)
        {
            var kicdRange = this.GetKicdRangeByKicd(kicd);
            return queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType == MototyouMasterRangeQueryConditionType.Range
                //// 範囲指定
                ? this.torihikisakiKamokuZandakaRepository.GetExistsByPrimaryKeyRangesWithSecurity(
                    kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    queryParameter.QueryCondition.QueryConditionRange.StartTorihikisakiCode,
                    queryParameter.QueryCondition.QueryConditionRange.EndTorihikisakiCode,
                    KamokuOutputOrder.ByInnerCode,
                    queryParameter.SecurityContext,
                    SecurityModel.SecurityKubun.Output)
                //// 個別指定
                : this.torihikisakiKamokuZandakaRepository.GetExistsByPrimaryKeyRangesWithSecurity(
                    kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    kobetuItem?.TorihikisakiCode,
                    kobetuItem?.TorihikisakiCode,
                    KamokuOutputOrder.ByInnerCode,
                    queryParameter.SecurityContext,
                    SecurityModel.SecurityKubun.Output);
        }

        private bool GetExistsRangeItemWhenKamokuTypeIsMeisaiOrSyouOrSyuukeiSyouKamoku(MototyouQueryParameter queryParameter, int kesn)
        {
            var kicdRnage = this.GetKicdRangeByKamokuTypeAndKamokuRange(
                queryParameter.OptionComposite.QueryOption.KamokuType,
                queryParameter.QueryCondition.QueryConditionRange.StartKamoku,
                queryParameter.QueryCondition.QueryConditionRange.EndKamoku);
            return this.torihikisakiKamokuZandakaRepository.GetExistsByPrimaryKeyRangesWithSecurity(
                kesn,
                kicdRnage.Start,
                kicdRnage.End,
                queryParameter.QueryCondition.QueryConditionRange.StartTorihikisakiCode,
                queryParameter.QueryCondition.QueryConditionRange.EndTorihikisakiCode,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku ? queryParameter.KamokuOutputOrder : KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                SecurityModel.SecurityKubun.Output);
        }
    }
}
