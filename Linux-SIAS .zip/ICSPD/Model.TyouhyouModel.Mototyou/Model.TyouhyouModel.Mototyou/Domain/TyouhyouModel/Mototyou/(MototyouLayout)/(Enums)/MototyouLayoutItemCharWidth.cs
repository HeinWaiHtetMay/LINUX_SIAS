﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutItemCharWidth
    {
        Auto = 1, Percent100 = 2, Percent75 = 3, Percent50 = 4
    }
}
