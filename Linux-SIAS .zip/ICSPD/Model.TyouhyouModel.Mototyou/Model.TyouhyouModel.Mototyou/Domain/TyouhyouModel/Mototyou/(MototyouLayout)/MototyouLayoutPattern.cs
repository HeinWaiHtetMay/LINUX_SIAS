﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.PrintDocumentModel;

    /// <summary>
    /// 元帳のレイアウトパターンクラス（DBテーブル：LEDPTN）
    /// </summary>
    public class MototyouLayoutPattern : IMasterData
    {
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other, MasterCodeType.Numeric, 2);

        public MototyouLayoutPattern(int patternNo)
        {
            this.PatternNo = patternNo;
        }

        public MototyouLayoutPattern(int patternNo, IList<MototyouLayoutColumn> columns, IList<MototyouLayoutItem> items)
        {
            this.PatternNo = patternNo;
            this.Columns = columns;
            this.Items = items;

            //// プログラムで設定する摘要項目の決定
            //// 摘要設定項目の中で詳細の優先順位によって決定する
            //// 同じ詳細が設定された項目が複数ある場合はその中で一番左の項目
            var tekiyouItems = this.Items.OfType<MototyouLayoutTekiyouItem>();
            if (tekiyouItems.Any())
            {
                var programTekiyouItem = tekiyouItems.Aggregate((tekiyouItemOfHighestPriority, current) =>
                {
                    return tekiyouItemOfHighestPriority.TekiyouValueType.GetPriorityNumber() == current.TekiyouValueType.GetPriorityNumber()
                           ? tekiyouItemOfHighestPriority.ColumnNo < current.ColumnNo
                               ? tekiyouItemOfHighestPriority
                               : current
                           : tekiyouItemOfHighestPriority.TekiyouValueType.GetPriorityNumber() < current.TekiyouValueType.GetPriorityNumber()
                               ? tekiyouItemOfHighestPriority
                               : current;
                });

                this.ProgramTekiyouItem = programTekiyouItem.CloneAsShallowCopy();
                this.ProgramTekiyouItem.SetRowNo(1); //// レイアウトに関係なくプログラム摘要は1行目

                this.ProgramTekiyouItemForIkkatuZeinukiSiwakeAggregateRow = programTekiyouItem.CloneAsShallowCopy();
            }
        }

        #region implements IMasterData

        public string Code => MasterInfo.GetFormattedCode(this.PatternNo.ToString());

        public string Name => this.PatternName;

        #endregion

        #region public propeties

        /// <summary>
        /// パターン番号
        /// </summary>
        public int PatternNo { get; set; }

        /// <summary>
        /// パターン名
        /// </summary>
        public string PatternName { get; set; }

        /// <summary>
        /// 元帳レイアウト登録のレイアウトタブの上グリッドの内容
        /// </summary>
        public IList<MototyouLayoutColumn> Columns { get; private set; }

        /// <summary>
        /// 元帳レイアウト登録のレイアウトタブの下グリッドの内容
        /// </summary>
        public IList<MototyouLayoutItem> Items { get; private set; }

        /// <summary>
        /// 列数（カラム名：col）
        /// </summary>
        public int ColumnCount { get; set; }

        /// <summary>
        /// 行数（カラム名：gyo）
        /// </summary>
        public int RowCount { get; set; }

        /// <summary>
        /// 用紙設定（カラム名：psize）
        /// </summary>
        public IcspPaperSize PaperSize { get; set; }

        /// <summary>
        /// 印刷するかどうか
        /// </summary>
        public bool IsPrint => this.PaperSize != null;

        /// <summary>
        /// 税区分（カラム名：zeikbn）
        /// </summary>
        public bool UseSyouhizeiKubun { get; set; }

        /// <summary>
        /// 金額桁数（カラム名：keta）
        /// </summary>
        public MototyouLayoutKingakuLength KingakuLength { get; set; }

        /// <summary>
        /// 位取り（カラム名：kurai）
        /// </summary>
        public MototyouLayoutKingakuScaleType KingakuScaleType { get; set; }

        /// <summary>
        /// 左余白（カラム名：lmgn）
        /// </summary>
        public int LeftMargin { get; set; }

        /// <summary>
        /// 上余白（カラム名：tmgn）
        /// </summary>
        public int TopMargin { get; set; }

        /// <summary>
        /// タイトル項目の均等割付（カラム名：kinto）
        /// </summary>
        public MototyouLayoutKintouWaritukeType TitleKintouWarituke { get; set; }

        /// <summary>
        /// 最終更新者（カラム名：lusr）
        /// </summary>
        public int Lusr { get; set; }

        /// <summary>
        /// 最終更新日（カラム名：lmod）
        /// </summary>
        public int Lmod { get; set; }

        /// <summary>
        /// 最終更新時刻（カラム名：ltim）
        /// </summary>
        public int Ltim { get; set; }

        /// <summary>
        /// プログラムで設定する摘要に該当するレイアウト項目
        /// </summary>
        public MototyouLayoutTekiyouItem ProgramTekiyouItem { get; private set; }

        /// <summary>
        /// 一括税抜仕訳集計行の摘要を表示する該当摘要レイアウト項目
        /// </summary>
        public MototyouLayoutTekiyouItem ProgramTekiyouItemForIkkatuZeinukiSiwakeAggregateRow { get; private set; }

        public int GetItemMaxRowNo() => this.Items.Any() ? this.Items.Max(item => item.RowNo) : 0;

        /// <summary>
        /// 使用可能なカラムかどうか
        /// </summary>
        /// <param name="columnNumber"></param>
        /// <param name="currentSyoriki"></param>
        /// <returns></returns>
        public bool IsAvailableColumn(int columnNumber, Syoriki currentSyoriki)
        {
            if (!this.Items.Any(item => item.ColumnNo == columnNumber))
            {
                //// カラムにレイアウト項目が未登録である場合はfalse
                return false;
            }

            var columnItems = this.Items.Where(item => item.ColumnNo == columnNumber);
            foreach (var item in columnItems)
            {
                //// カラムに一つでも使用できる項目があればtrue
                if (this.IsAvailableItem(item, currentSyoriki))
                {
                    return true;
                }
            }

            //// カラムに一つでも使用できる項目がない場合false
            return false;
        }

        public bool IsAvailableItem(MototyouLayoutItem item, Syoriki currentSyoriki)
        {
            switch (item.ItemType)
            {
                case MototyouLayoutItemType.Bumon:
                case MototyouLayoutItemType.Edaban:
                case MototyouLayoutItemType.Torihikisaki:
                case MototyouLayoutItemType.Segment:
                case MototyouLayoutItemType.Project:
                case MototyouLayoutItemType.Kouzi:
                case MototyouLayoutItemType.Kousyu:
                case MototyouLayoutItemType.UniversalField1:
                case MototyouLayoutItemType.UniversalField2:
                case MototyouLayoutItemType.UniversalField3:
                case MototyouLayoutItemType.UniversalField4:
                case MototyouLayoutItemType.UniversalField5:
                case MototyouLayoutItemType.UniversalField6:
                case MototyouLayoutItemType.UniversalField7:
                case MototyouLayoutItemType.UniversalField8:
                case MototyouLayoutItemType.UniversalField9:
                case MototyouLayoutItemType.UniversalField10:
                case MototyouLayoutItemType.UniversalField11:
                case MototyouLayoutItemType.UniversalField12:
                case MototyouLayoutItemType.UniversalField13:
                case MototyouLayoutItemType.UniversalField14:
                case MototyouLayoutItemType.UniversalField15:
                case MototyouLayoutItemType.UniversalField16:
                case MototyouLayoutItemType.UniversalField17:
                case MototyouLayoutItemType.UniversalField18:
                case MototyouLayoutItemType.UniversalField19:
                case MototyouLayoutItemType.UniversalField20:
                    //// マスター系（科目除く）は処理期の使用可否をチェックする
                    return this.GetSyorikiMasterInfoByMototyouLayoutItemType(item.ItemType, currentSyoriki).Use;
                case MototyouLayoutItemType.GaikaRate:
                    //// HACK：外貨元帳ではtrueを返す（元帳では不要）
                    return false;
                default:
                    //// 伝票番号、受付番号、摘要、自由摘要、科目は固定で使用可
                    return true;
            }
        }

        #endregion

        private IMasterInfo GetSyorikiMasterInfoByMototyouLayoutItemType(MototyouLayoutItemType itemType, Syoriki syoriki)
        {
            switch (itemType)
            {
                case MototyouLayoutItemType.Bumon:
                    return syoriki.BumonInfo;
                case MototyouLayoutItemType.Edaban:
                    return syoriki.EdabanInfo;
                case MototyouLayoutItemType.Torihikisaki:
                    return syoriki.TorihikisakiInfo;
                case MototyouLayoutItemType.Segment:
                    return syoriki.SegmentInfo;
                case MototyouLayoutItemType.Project:
                    return syoriki.ProjectInfo;
                case MototyouLayoutItemType.Kouzi:
                    return syoriki.KouziInfo;
                case MototyouLayoutItemType.Kousyu:
                    return syoriki.KousyuInfo;
                case MototyouLayoutItemType.UniversalField1:
                case MototyouLayoutItemType.UniversalField2:
                case MototyouLayoutItemType.UniversalField3:
                case MototyouLayoutItemType.UniversalField4:
                case MototyouLayoutItemType.UniversalField5:
                case MototyouLayoutItemType.UniversalField6:
                case MototyouLayoutItemType.UniversalField7:
                case MototyouLayoutItemType.UniversalField8:
                case MototyouLayoutItemType.UniversalField9:
                case MototyouLayoutItemType.UniversalField10:
                case MototyouLayoutItemType.UniversalField11:
                case MototyouLayoutItemType.UniversalField12:
                case MototyouLayoutItemType.UniversalField13:
                case MototyouLayoutItemType.UniversalField14:
                case MototyouLayoutItemType.UniversalField15:
                case MototyouLayoutItemType.UniversalField16:
                case MototyouLayoutItemType.UniversalField17:
                case MototyouLayoutItemType.UniversalField18:
                case MototyouLayoutItemType.UniversalField19:
                case MototyouLayoutItemType.UniversalField20:
                    return syoriki.GetUniversalFieldInfo(false, itemType.GetUniversalFieldNo());
                default:
                    return null;
            }
        }
    }
}