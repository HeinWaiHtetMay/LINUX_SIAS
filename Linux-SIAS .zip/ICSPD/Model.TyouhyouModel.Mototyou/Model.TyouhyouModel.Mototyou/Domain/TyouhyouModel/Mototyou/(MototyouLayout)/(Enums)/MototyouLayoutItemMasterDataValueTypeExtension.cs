﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    public static class MototyouLayoutItemMasterDataValueTypeExtension
    {
        public static int GetUniversalFieldHalfWidthCharCount(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValue, UniversalFieldInfo universalFieldInfo)
        {
            switch (universalFieldInfo.Usage)
            {
                case UniversalFieldUsageType.NotUse:
                    return 0;
                case UniversalFieldUsageType.UseAlone:
                    switch (universalFieldInfo.DataType)
                    {
                        case UniversalFieldDataType.Alphanumeric:
                        case UniversalFieldDataType.Numeric:
                        case UniversalFieldDataType.Char:
                            return universalFieldInfo.CodeMaxLength;
                        case UniversalFieldDataType.Money:
                            return universalFieldInfo.CodeMaxLength +
                                ((universalFieldInfo.CodeMaxLength - (universalFieldInfo.CodeMaxLength % 3)) / 3) -
                                ((universalFieldInfo.CodeMaxLength % 3) == 0 ? 1 : 0);
                        case UniversalFieldDataType.Decimal:
                            return universalFieldInfo.CodeMaxLength +
                                ((universalFieldInfo.CodeMaxLength - (universalFieldInfo.CodeMaxLength % 3)) / 3) -
                                ((universalFieldInfo.CodeMaxLength % 3) == 0 ? 1 : 0) + 1 + universalFieldInfo.DecimalPartMaxLength;
                        case UniversalFieldDataType.Date:
                        default:
                            return 0;
                    }

                case UniversalFieldUsageType.UseAsMaster:
                case UniversalFieldUsageType.UseAsZandaka:
                    switch (mototyouLayoutItemMasterDataValue)
                    {
                        case MototyouLayoutItemMasterDataValueType.AiteCode:
                        case MototyouLayoutItemMasterDataValueType.ZibunCode:
                            return universalFieldInfo.CodeMaxLength;
                        case MototyouLayoutItemMasterDataValueType.AiteShortName:
                        case MototyouLayoutItemMasterDataValueType.ZibunShortName:
                            return 20;
                        case MototyouLayoutItemMasterDataValueType.AiteLongName:
                        case MototyouLayoutItemMasterDataValueType.ZibunLongName:
                            return 44;
                        default:
                            return 0;
                    }

                default:
                    return 0;
            }
        }

        public static int GetHalfWidthCharCount(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValue, IMasterInfo masterInfo)
        {
            if (masterInfo is KamokuInfo kamokuInfo)
            {
                return mototyouLayoutItemMasterDataValue.GetKamokuHalfWidthCharCount(kamokuInfo);
            }
            else if (masterInfo is UniversalFieldInfo ufInfo)
            {
                return mototyouLayoutItemMasterDataValue.GetUniversalFieldHalfWidthCharCount(ufInfo);
            }

            switch (mototyouLayoutItemMasterDataValue)
            {
                case MototyouLayoutItemMasterDataValueType.AiteCode:
                case MototyouLayoutItemMasterDataValueType.ZibunCode:
                    return masterInfo.CodeMaxLength;
                case MototyouLayoutItemMasterDataValueType.AiteShortName:
                case MototyouLayoutItemMasterDataValueType.ZibunShortName:
                    return 20;
                    //// TODO：なんの24？→ return masterInfo.MasterType == MasterType.Bumon ? 24 : 20;
                case MototyouLayoutItemMasterDataValueType.AiteLongName:
                case MototyouLayoutItemMasterDataValueType.ZibunLongName:
                    switch (masterInfo.MasterType)
                    {
                        case MasterType.Torihikisaki:
                        case MasterType.Segment:
                            return 44;
                        case MasterType.Kouzi:
                            return 60;
                        default:
                            return 40;
                    }

                default:
                    return 0;
            }
        }

        public static int GetKamokuHalfWidthCharCount(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValue, KamokuInfo kamokuInfo)
        {
            switch (mototyouLayoutItemMasterDataValue)
            {
                case MototyouLayoutItemMasterDataValueType.AiteCode:
                case MototyouLayoutItemMasterDataValueType.ZibunCode:
                    return kamokuInfo.CodeMaxLength;
                case MototyouLayoutItemMasterDataValueType.AiteLongName:
                case MototyouLayoutItemMasterDataValueType.ZibunLongName:
                    return kamokuInfo.PrintMaxCharLength * 2;
                default:
                    return 0;
            }
        }

        public static bool IsZibun(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValueType)
        {
            return mototyouLayoutItemMasterDataValueType >= MototyouLayoutItemMasterDataValueType.ZibunCode;
        }

        public static bool IsCode(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValueType)
        {
            return mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteCode ||
                mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.ZibunCode;
        }

        public static bool IsShortName(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValueType)
        {
            return mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteShortName ||
                mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.ZibunShortName;
        }

        public static bool IsLongName(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValueType)
        {
            return mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteLongName ||
                mototyouLayoutItemMasterDataValueType == MototyouLayoutItemMasterDataValueType.ZibunLongName;
        }

        public static string GetName(this MototyouLayoutItemMasterDataValueType mototyouLayoutItemMasterDataValueType, MototyouLayoutItemType itemType)
        {
            switch (mototyouLayoutItemMasterDataValueType)
            {
                case MototyouLayoutItemMasterDataValueType.AiteCode:
                    return Properties.Resources.相手コード;
                case MototyouLayoutItemMasterDataValueType.AiteShortName:
                    return Properties.Resources.相手名称;
                case MototyouLayoutItemMasterDataValueType.AiteLongName:
                    return itemType == MototyouLayoutItemType.Kamoku ? Properties.Resources.相手名称_印刷 : Properties.Resources.相手正式名称;
                case MototyouLayoutItemMasterDataValueType.ZibunCode:
                    return Properties.Resources.自分コード;
                case MototyouLayoutItemMasterDataValueType.ZibunShortName:
                    return Properties.Resources.自分名称;
                case MototyouLayoutItemMasterDataValueType.ZibunLongName:
                    return itemType == MototyouLayoutItemType.Kamoku ? Properties.Resources.自分名称_印刷 : Properties.Resources.自分正式名称;
                default:
                    return string.Empty;
            }
        }
    }
}
