﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Linq;
    using Icsp.Framework.Core.Text;

    public class MototyouLayoutColumn
    {
        private string[] headerTitles = new string[3];

        public MototyouLayoutColumn(int patternNo, int columnNo)
        {
            this.PatternNo = patternNo;
            this.ColumnNo = columnNo;
        }

        #region public properties

        /// <summary>
        /// パターン番号（カラム名：ptno）
        /// </summary>
        public int PatternNo { get; private set; }

        /// <summary>
        /// 列番号（カラム名：colno）
        /// </summary>
        public int ColumnNo { get; private set; }

        /// <summary>
        /// 列幅（カラム名：colwidth）
        /// </summary>
        public MototyouLayoutColumnPrintWidth ColumnPrintWidth { get; set; }

        /// <summary>
        /// 印刷文字サイズ（カラム名：psize）
        /// </summary>
        public MototyouLayoutCharPrintSize CharPrintSize { get; set; }

        /// <summary>
        /// 1行目（カラム名：gyo1）
        /// </summary>
        public string HeaderTitleRow1
        {
            get { return this.headerTitles[0]; }
            set { this.headerTitles[0] = value; }
        }

        /// <summary>
        /// 2行目（カラム名：gyo2）
        /// </summary>
        public string HeaderTitleRow2
        {
            get { return this.headerTitles[1]; }
            set { this.headerTitles[1] = value; }
        }

        /// <summary>
        /// 3行目（カラム名：gyo3）
        /// </summary>
        public string HeaderTitleRow3
        {
            get { return this.headerTitles[2]; }
            set { this.headerTitles[2] = value; }
        }

        public string GetHeaderTitle()
        {
            return string.Join(Environment.NewLine, this.headerTitles);
        }

        public int GetHeaderTitleMaxWidth()
        {
            return this.headerTitles.Max(title => title.GetLengthByHalfWidthConverting());
        }

        #endregion
    }
}
