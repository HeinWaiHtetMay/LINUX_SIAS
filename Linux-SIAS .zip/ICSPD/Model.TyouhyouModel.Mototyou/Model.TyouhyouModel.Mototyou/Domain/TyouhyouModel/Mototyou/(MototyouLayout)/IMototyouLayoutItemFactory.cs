﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouLayoutItemFactory
    {
        MototyouLayoutItem CreateMototyouLayoutItem(MototyouLayoutItemType itemType, int detail, int patternNo, int columnNo, int rowNo);
    }
}