﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;

    /// <summary>
    /// 元帳レイアウトマスターデータ項目用クラス
    /// 4:科目
    /// 5:部門
    /// 6:枝番
    /// 7:取引先
    /// 8:セグメント
    /// 9:プロジェクト
    /// 10:摘要コード
    /// 11～30:ユニバーサルフィールド1～20
    /// 31:工事
    /// 32:工種
    /// を扱う
    /// </summary>
    public class MototyouLayoutMasterDataItem : MototyouLayoutItem
    {
        public MototyouLayoutMasterDataItem(int detail, int patternNo, int columnNo, int rowNo)
            : base(patternNo, columnNo, rowNo)
        {
            this.MasterDataValueType = (MototyouLayoutItemMasterDataValueType)detail;
        }

        /// <summary>
        /// 項目詳細(カラム名：shosai)
        /// </summary>
        public MototyouLayoutItemMasterDataValueType MasterDataValueType { get; private set; }

        /// <summary>
        /// 半角文字換算の文字数を取得します
        /// </summary>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public override int GetHalfWidthCharCount(Syoriki syoriki)
        {
            if (this.ItemType == MototyouLayoutItemType.Kamoku)
            {
                return this.MasterDataValueType.GetKamokuHalfWidthCharCount(syoriki.KamokuInfo);
            }
            else if (this.ItemType.IsUniversalField())
            {
                return this.MasterDataValueType.GetUniversalFieldHalfWidthCharCount(syoriki.GetUniversalFieldInfo(false, this.ItemType.GetUniversalFieldNo()));
            }
            else
            {
                var masterInfo = syoriki.GetMasterInfo(this.ItemType.GetMasterType());

                return masterInfo != null ? this.MasterDataValueType.GetHalfWidthCharCount(masterInfo) : 0;
            }
        }

        public override int GetDetailNo()
        {
            return (int)this.MasterDataValueType;
        }

        public override string GetName(Syoriki syoriki)
        {
            //// 通常は自分or相手 + マスター名称 + コードor名称or正式名称。ただし、UFでデータ型が英数、数字以外の時はコードor名称or正式名称をつけない
            return this.ItemType.IsUniversalField() && syoriki.GetUniversalFieldInfo(false, this.ItemType.GetUniversalFieldNo()).DataType > MasterModel.UniversalFieldDataType.Alphanumeric
                ? this.MasterDataValueType.GetName(this.ItemType).Substring(0, 2) + this.ItemType.GetName(syoriki)
                : this.MasterDataValueType.GetName(this.ItemType).Insert(2, this.ItemType.GetName(syoriki));
        }
    }
}
