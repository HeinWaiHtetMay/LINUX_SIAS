﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;

    /// <summary>
    /// 元帳レイアウト摘要用クラス
    /// 3:摘要
    /// を扱う
    /// </summary>
    public class MototyouLayoutTekiyouItem : MototyouLayoutItem
    {
        public MototyouLayoutTekiyouItem(int detail, int patternNo, int columnNo, int rowNo)
            : base(patternNo, columnNo, rowNo)
        {
            this.TekiyouValueType = (MototyouLayoutItemTekiyouValueType)detail;
        }

        /// <summary>
        /// 項目詳細(カラム名：shosai)
        /// </summary>
        public MototyouLayoutItemTekiyouValueType TekiyouValueType { get; private set; }

        /// <summary>
        /// 半角文字換算の文字数を取得します
        /// </summary>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public override int GetHalfWidthCharCount(Syoriki syoriki)
        {
            return this.TekiyouValueType.GetHalfWidthCharCount();
        }

        public override int GetDetailNo()
        {
            return (int)this.TekiyouValueType;
        }

        public override string GetName(Syoriki syoriki)
        {
            return this.TekiyouValueType.GetName().Insert(2, this.ItemType.GetName(syoriki));
        }

        public void SetRowNo(int rowNo)
        {
            this.RowNo = rowNo;
        }

        public MototyouLayoutTekiyouItem CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as MototyouLayoutTekiyouItem;
        }
    }
}
