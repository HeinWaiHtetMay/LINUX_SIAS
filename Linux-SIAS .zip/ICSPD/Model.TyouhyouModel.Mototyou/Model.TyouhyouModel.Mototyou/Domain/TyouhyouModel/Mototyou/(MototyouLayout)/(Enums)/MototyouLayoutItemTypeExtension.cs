﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;

    public static class MototyouLayoutItemTypeExtension
    {
        public static int GetUniversalFieldNo(this MototyouLayoutItemType itemType)
        {
            return itemType - MototyouLayoutItemType.UniversalField1 + 1;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1131:Use readable conditions", Justification = "見やすさのため")]
        public static bool IsUniversalField(this MototyouLayoutItemType itemType)
        {
            return MototyouLayoutItemType.UniversalField1 <= itemType && itemType <= MototyouLayoutItemType.UniversalField20;
        }

        public static bool IsMasterType(this MototyouLayoutItemType itemType)
        {
            switch (itemType)
            {
                case MototyouLayoutItemType.DenpyouNo:
                case MototyouLayoutItemType.UketukeNo:
                case MototyouLayoutItemType.Tekiyou:
                case MototyouLayoutItemType.GaikaRate:
                    return false;
                default:
                    return true;
            }
        }

        public static MasterType GetMasterType(this MototyouLayoutItemType itemType)
        {
            if (itemType.IsUniversalField())
            {
                return MasterType.Universal;
            }

            switch (itemType)
            {
                case MototyouLayoutItemType.Kamoku:
                    return MasterType.Kamoku;
                case MototyouLayoutItemType.Bumon:
                    return MasterType.Bumon;
                case MototyouLayoutItemType.Edaban:
                    return MasterType.Edaban;
                case MototyouLayoutItemType.Torihikisaki:
                    return MasterType.Torihikisaki;
                case MototyouLayoutItemType.Segment:
                    return MasterType.Segment;
                case MototyouLayoutItemType.Project:
                    return MasterType.Project;
                case MototyouLayoutItemType.ZiyuuTekiyou:
                    return MasterType.ZiyuuTekiyou;
                case MototyouLayoutItemType.Kouzi:
                    return MasterType.Kouzi;
                case MototyouLayoutItemType.Kousyu:
                    return MasterType.Kousyu;
                default:
                    return MasterType.Other;
            }
        }

        public static string GetName(this MototyouLayoutItemType itemType, Syoriki syoriki)
        {
            if (itemType.IsUniversalField())
            {
                return syoriki.GetUniversalFieldInfo(false, itemType.GetUniversalFieldNo()).Name;
            }

            switch (itemType)
            {
                case MototyouLayoutItemType.DenpyouNo:
                    return "伝票番号";
                case MototyouLayoutItemType.UketukeNo:
                    return "受付番号";
                case MototyouLayoutItemType.Tekiyou:
                    return "摘要";
                case MototyouLayoutItemType.Kamoku:
                    return "科目";
                case MototyouLayoutItemType.Bumon:
                    return "部門";
                case MototyouLayoutItemType.Edaban:
                    return "枝番";
                case MototyouLayoutItemType.Torihikisaki:
                    return "取引先";
                case MototyouLayoutItemType.Segment:
                    return "セグメント";
                case MototyouLayoutItemType.Project:
                    return "プロジェクト";
                case MototyouLayoutItemType.ZiyuuTekiyou:
                    return "摘要";
                case MototyouLayoutItemType.Kouzi:
                    return "工事";
                case MototyouLayoutItemType.Kousyu:
                    return "工種";
                case MototyouLayoutItemType.GaikaRate:
                    return "レート";
                default:
                    return string.Empty;
            }
        }
    }
}
