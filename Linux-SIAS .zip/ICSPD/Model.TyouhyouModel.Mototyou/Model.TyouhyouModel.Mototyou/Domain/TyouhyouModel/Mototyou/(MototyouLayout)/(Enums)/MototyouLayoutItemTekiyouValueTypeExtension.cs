﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Framework.Core.Text;

    public static class MototyouLayoutItemTekiyouValueTypeExtension
    {
        /// <summary>
        /// 半角文字換算の文字数を取得します
        /// </summary>
        /// <param name="mototyouLayoutItemTekiyouValueType"></param>
        /// <returns></returns>
        public static int GetHalfWidthCharCount(this MototyouLayoutItemTekiyouValueType mototyouLayoutItemTekiyouValueType)
        {
            switch (mototyouLayoutItemTekiyouValueType)
            {
                case MototyouLayoutItemTekiyouValueType.Aite30Chars:
                case MototyouLayoutItemTekiyouValueType.Zibun30Chars:
                    return 60;
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf20Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf20Chars:
                    return 40;
                case MototyouLayoutItemTekiyouValueType.AiteScondHalf10Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunScondHalf10Chars:
                    return 20;
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf15Chars:
                case MototyouLayoutItemTekiyouValueType.AiteSecondHalf15Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf15Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunSecondHalf15Chars:
                    return 30;
                default:
                    return 0;
            }
        }

        /// <summary>
        /// 摘要文字列から指定の範囲を抽出して返します
        /// </summary>
        /// <param name="mototyouLayoutItemTekiyouValueType"></param>
        /// <param name="tekiyou"></param>
        /// <returns></returns>
        public static string GetFilteringText(this MototyouLayoutItemTekiyouValueType mototyouLayoutItemTekiyouValueType, string tekiyou)
        {
            if (string.IsNullOrEmpty(tekiyou))
            {
                return string.Empty;
            }

            switch (mototyouLayoutItemTekiyouValueType)
            {
                case MototyouLayoutItemTekiyouValueType.Aite30Chars:
                case MototyouLayoutItemTekiyouValueType.Zibun30Chars:
                    return tekiyou;
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf20Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf20Chars:
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf15Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf15Chars:
                    return tekiyou.SplitByHalfWidthConverting(mototyouLayoutItemTekiyouValueType.GetHalfWidthCharCount(), false)[0];
                case MototyouLayoutItemTekiyouValueType.AiteScondHalf10Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunScondHalf10Chars:
                case MototyouLayoutItemTekiyouValueType.AiteSecondHalf15Chars:
                case MototyouLayoutItemTekiyouValueType.ZibunSecondHalf15Chars:
                    return tekiyou.SplitByHalfWidthConverting(60 - mototyouLayoutItemTekiyouValueType.GetHalfWidthCharCount(), false)[1];
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// 自分摘要かどうかを取得します
        /// </summary>
        /// <param name="mototyouLayoutItemTekiyouValueType"></param>
        /// <returns></returns>
        public static bool IsZibun(this MototyouLayoutItemTekiyouValueType mototyouLayoutItemTekiyouValueType)
        {
            return mototyouLayoutItemTekiyouValueType >= MototyouLayoutItemTekiyouValueType.Zibun30Chars;
        }

        public static string GetName(this MototyouLayoutItemTekiyouValueType mototyouLayoutItemTekiyouValueType)
        {
            switch (mototyouLayoutItemTekiyouValueType)
            {
                case MototyouLayoutItemTekiyouValueType.Aite30Chars:
                    return "相手30文字";
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf20Chars:
                    return "相手前半20文字";
                case MototyouLayoutItemTekiyouValueType.AiteScondHalf10Chars:
                    return "相手後半10文字";
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf15Chars:
                    return "相手前半15文字";
                case MototyouLayoutItemTekiyouValueType.AiteSecondHalf15Chars:
                    return "相手後半15文字";
                case MototyouLayoutItemTekiyouValueType.Zibun30Chars:
                    return "自分30文字";
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf20Chars:
                    return "自分前半20文字";
                case MototyouLayoutItemTekiyouValueType.ZibunScondHalf10Chars:
                    return "自分後半10文字";
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf15Chars:
                    return "自分前半15文字";
                case MototyouLayoutItemTekiyouValueType.ZibunSecondHalf15Chars:
                    return "自分後半15文字";
                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// プログラムで設定する摘要の出力列を決定するための優先順位を取得します
        /// </summary>
        /// <param name="mototyouLayoutItemTekiyouValueType"></param>
        /// <returns></returns>
        public static int GetPriorityNumber(this MototyouLayoutItemTekiyouValueType mototyouLayoutItemTekiyouValueType)
        {
            switch (mototyouLayoutItemTekiyouValueType)
            {
                case MototyouLayoutItemTekiyouValueType.Aite30Chars:
                    return 6;
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf20Chars:
                    return 7;
                case MototyouLayoutItemTekiyouValueType.AiteScondHalf10Chars:
                    return 9;
                case MototyouLayoutItemTekiyouValueType.AiteFirstHalf15Chars:
                    return 8;
                case MototyouLayoutItemTekiyouValueType.AiteSecondHalf15Chars:
                    return 10;
                case MototyouLayoutItemTekiyouValueType.Zibun30Chars:
                    return 1;
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf20Chars:
                    return 2;
                case MototyouLayoutItemTekiyouValueType.ZibunScondHalf10Chars:
                    return 4;
                case MototyouLayoutItemTekiyouValueType.ZibunFirstHalf15Chars:
                    return 3;
                case MototyouLayoutItemTekiyouValueType.ZibunSecondHalf15Chars:
                    return 5;
                default:
                    return int.MaxValue;
            }
        }
    }
}
