﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;

    public interface IMototyouLayoutItemRepository
    {
        IList<MototyouLayoutItem> FindByPatternNo(int patternNo);
    }
}