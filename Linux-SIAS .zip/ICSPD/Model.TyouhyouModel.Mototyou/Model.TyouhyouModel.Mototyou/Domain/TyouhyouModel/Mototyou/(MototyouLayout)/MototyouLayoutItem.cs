﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;

    /// <summary>
    /// 元帳レイアウト項目基本クラス
    /// 1:伝票番号
    /// 2:受付番号
    /// 33:レート
    /// 詳細(カラム名：shosai)不要もしくは固定な上記項目をこのクラスで扱い、それ以外はこのクラスの子クラスで扱う
    /// </summary>
    public class MototyouLayoutItem
    {
        public MototyouLayoutItem(int patternNo, int columnNo, int rowNo)
        {
            this.PatternNo = patternNo;
            this.ColumnNo = columnNo;
            this.RowNo = rowNo;
        }

        /// <summary>
        /// パターン番号（カラム名：ptno）
        /// </summary>
        public int PatternNo { get; private set; }

        /// <summary>
        /// 列番号（カラム名：colno）
        /// </summary>
        public int ColumnNo { get; private set; }

        /// <summary>
        /// 行番号（カラム名：gyono）
        /// </summary>
        public int RowNo { get; protected set; }

        /// <summary>
        /// 項目（カラム名：komoku）
        /// </summary>
        public MototyouLayoutItemType ItemType { get; set; }

        // 詳細(カラム名：shosai)は継承先のクラスで

        /// <summary>
        /// 文字幅（カラム名：mojiwidth）
        /// </summary>
        public MototyouLayoutItemCharWidth CharWidth { get; set; }

        /// <summary>
        /// 均等割付（カラム名：kinto）
        /// </summary>
        public MototyouLayoutKintouWaritukeType KintouWaritukeType { get; set; }

        /// <summary>
        /// 半角文字換算の文字数を取得します
        /// </summary>
        /// <param name="syoriki"></param>
        /// <returns></returns>
        public virtual int GetHalfWidthCharCount(Syoriki syoriki)
        {
            switch (this.ItemType)
            {
                case MototyouLayoutItemType.DenpyouNo:
                case MototyouLayoutItemType.UketukeNo:
                    return 8;
                default:
                    return 0;
            }
        }

        public virtual int GetDetailNo()
        {
            switch (this.ItemType)
            {
                case MototyouLayoutItemType.GaikaRate:
                    return 11;
                default:
                    return 0;
            }
        }

        public virtual string GetName(Syoriki syoriki)
        {
            return this.ItemType.GetName(syoriki);
        }
    }
}
