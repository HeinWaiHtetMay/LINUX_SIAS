﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutItemType
    {
        DenpyouNo = 1,
        UketukeNo = 2,
        Tekiyou = 3,
        Kamoku = 4,
        Bumon = 5,
        Edaban = 6,
        Torihikisaki = 7,
        Segment = 8,
        Project = 9,
        ZiyuuTekiyou = 10,
        UniversalField1 = 11,
        UniversalField2 = 12,
        UniversalField3 = 13,
        UniversalField4 = 14,
        UniversalField5 = 15,
        UniversalField6 = 16,
        UniversalField7 = 17,
        UniversalField8 = 18,
        UniversalField9 = 19,
        UniversalField10 = 20,
        UniversalField11 = 21,
        UniversalField12 = 22,
        UniversalField13 = 23,
        UniversalField14 = 24,
        UniversalField15 = 25,
        UniversalField16 = 26,
        UniversalField17 = 27,
        UniversalField18 = 28,
        UniversalField19 = 29,
        UniversalField20 = 30,
        Kouzi = 31,
        Kousyu = 32,
        GaikaRate = 33
    }
}
