﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouLayoutCharPrintSizeExtension
    {
        public static float GetMillimeterSize(this MototyouLayoutCharPrintSize layoutCharPrintSize)
        {
            switch (layoutCharPrintSize)
            {
                case MototyouLayoutCharPrintSize.Big:
                    return 3.2f;
                case MototyouLayoutCharPrintSize.Small:
                    return 2f;
                default:
                    return 0f;
            }
        }
    }
}
