﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutItemMasterDataValueType
    {
        AiteCode = 1,
        AiteShortName = 2,
        AiteLongName = 3,
        ZibunCode = 11,
        ZibunShortName = 12,
        ZibunLongName = 13,
    }
}
