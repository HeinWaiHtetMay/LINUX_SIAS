﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Factory]
    public class MototyouLayoutItemFactory : IMototyouLayoutItemFactory
    {
        public MototyouLayoutItem CreateMototyouLayoutItem(MototyouLayoutItemType itemType, int detail, int patternNo, int columnNo, int rowNo)
        {
            if (itemType == MototyouLayoutItemType.Tekiyou)
            {
                return new MototyouLayoutTekiyouItem(detail, patternNo, columnNo, rowNo) { ItemType = itemType };
            }
            else if (itemType.IsMasterType())
            {
                return new MototyouLayoutMasterDataItem(detail, patternNo, columnNo, rowNo) { ItemType = itemType };
            }
            else
            {
                return new MototyouLayoutItem(patternNo, columnNo, rowNo) { ItemType = itemType };
            }
        }
    }
}
