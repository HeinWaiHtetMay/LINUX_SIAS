﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutKingakuScaleType
    {
        /// <summary>
        /// 罫線（点線）
        /// </summary>
        DottedLine = 1,

        /// <summary>
        /// 桁区切り
        /// </summary>
        SeparatedByDigits = 2
    }
}
