﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutColumnPrintWidth
    {
        FullWidthChar4 = 1,
        FullWidthChar6 = 2,
        FullWidthChar11 = 3,
        FullWidthChar15 = 4,
        FullWidthChar20 = 5,
        FullWidthChar30 = 6,
    }
}
