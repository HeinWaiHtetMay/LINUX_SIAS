﻿using Icsp.Open21.Drawing.Printing;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouLayoutItemCharWidthExtension
    {
        public static PrintTextWidthMode GetPrintTextWidthMode(this MototyouLayoutItemCharWidth charWidth)
        {
            switch (charWidth)
            {
                case MototyouLayoutItemCharWidth.Percent75:
                    return PrintTextWidthMode.ThreeQuarter;
                case MototyouLayoutItemCharWidth.Percent50:
                    return PrintTextWidthMode.Half;
                default:
                    return PrintTextWidthMode.Normal;
            }
        }

        public static PrintTextElasticMode GetPrintTextElasticMode(this MototyouLayoutItemCharWidth charWidth)
        {
            return charWidth == MototyouLayoutItemCharWidth.Auto ? PrintTextElasticMode.Reducation : PrintTextElasticMode.NotSet;
        }
    }
}
