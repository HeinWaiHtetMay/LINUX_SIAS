﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutCharPrintSize
    {
        Big = 1, Small = 2
    }
}
