﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;

    public interface IMototyouLayoutColumnRepository
    {
        IList<MototyouLayoutColumn> FindByPatternNo(int patternNo);
    }
}