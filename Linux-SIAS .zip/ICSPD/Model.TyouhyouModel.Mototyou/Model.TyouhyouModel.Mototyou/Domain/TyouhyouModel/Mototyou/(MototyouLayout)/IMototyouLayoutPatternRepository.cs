﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    public interface IMototyouLayoutPatternRepository
    {
        MototyouLayoutPattern FindByPatternNo(int patternNo);

        IList<IMasterData> GetPatternNoAndName();
    }
}