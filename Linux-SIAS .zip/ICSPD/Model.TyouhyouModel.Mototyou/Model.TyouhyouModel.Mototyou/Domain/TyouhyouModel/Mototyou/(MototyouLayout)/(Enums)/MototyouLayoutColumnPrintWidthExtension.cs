﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouLayoutColumnPrintWidthExtension
    {
        public static float GetMillimeterWidth(this MototyouLayoutColumnPrintWidth mototyouLayoutColumnPrintWidth)
        {
            switch (mototyouLayoutColumnPrintWidth)
            {
                case MototyouLayoutColumnPrintWidth.FullWidthChar4:
                    return 15f;
                case MototyouLayoutColumnPrintWidth.FullWidthChar6:
                    return 23f;
                case MototyouLayoutColumnPrintWidth.FullWidthChar11:
                    return 38f;
                case MototyouLayoutColumnPrintWidth.FullWidthChar15:
                    return 50f;
                case MototyouLayoutColumnPrintWidth.FullWidthChar20:
                    return 68f;
                case MototyouLayoutColumnPrintWidth.FullWidthChar30:
                    return 100f;
                default:
                    return 0f;
            }
        }
    }
}
