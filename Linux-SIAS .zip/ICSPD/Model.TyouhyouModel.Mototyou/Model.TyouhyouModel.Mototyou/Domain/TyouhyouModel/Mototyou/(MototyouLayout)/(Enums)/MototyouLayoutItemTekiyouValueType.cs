﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouLayoutItemTekiyouValueType
    {
        Aite30Chars = 1,
        AiteFirstHalf20Chars = 2,
        AiteScondHalf10Chars = 3,
        AiteFirstHalf15Chars = 4,
        AiteSecondHalf15Chars = 5,
        Zibun30Chars = 11,
        ZibunFirstHalf20Chars = 12,
        ZibunScondHalf10Chars = 13,
        ZibunFirstHalf15Chars = 14,
        ZibunSecondHalf15Chars = 15,
    }
}
