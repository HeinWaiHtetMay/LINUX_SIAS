﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouLayoutKingakuLengthExtension
    {
        public static int GetLength(this MototyouLayoutKingakuLength kingakuLength)
        {
            switch (kingakuLength)
            {
                case MototyouLayoutKingakuLength.Length12:
                    return 12;
                case MototyouLayoutKingakuLength.Length15:
                    return 15;
                default:
                    return 0;
            }
        }

        public static decimal GetMaxValue(this MototyouLayoutKingakuLength kingakuLength)
        {
            switch (kingakuLength)
            {
                case MototyouLayoutKingakuLength.Length12:
                    return 999999999999;
                case MototyouLayoutKingakuLength.Length15:
                    return 999999999999999;
                default:
                    return 0;
            }
        }

        public static decimal GetMinValue(this MototyouLayoutKingakuLength kingakuLength)
        {
            switch (kingakuLength)
            {
                case MototyouLayoutKingakuLength.Length12:
                    return -99999999999;
                case MototyouLayoutKingakuLength.Length15:
                    return -99999999999999;
                default:
                    return 0;
            }
        }

        public static float GetMillimeterWidth(this MototyouLayoutKingakuLength kingakuLength)
        {
            switch (kingakuLength)
            {
                case MototyouLayoutKingakuLength.Length12:
                    return 22f;
                case MototyouLayoutKingakuLength.Length15:
                    return 27.4f;
                default:
                    return 0f;
            }
        }

        public static string GetDigitsOverFlowingString(this MototyouLayoutKingakuLength kingakuLength)
        {
            switch (kingakuLength)
            {
                case MototyouLayoutKingakuLength.Length12:
                    return "***************";
                case MototyouLayoutKingakuLength.Length15:
                    return "*******************";
                default:
                    return string.Empty;
            }
        }
    }
}
