﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;

    public interface IMototyouRepository
    {
        /// <summary>
        /// 問い合わせ条件と指定項目から元帳を作成して返す
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        Mototyou FindByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem);

        /// <summary>
        /// 問い合わせ条件と指定項目から元帳を作成して返す
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="mototyouLayoutPattern"></param>
        /// <returns></returns>
        Mototyou FindByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, MototyouLayoutPattern mototyouLayoutPattern);

        /// <summary>
        /// 問い合わせ条件と指定項目から損益勘定元帳を作成して返す
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        Mototyou FindSonekiKanzyouMototyouByQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem);

        /// <summary>
        /// 問い合わせ条件と指定項目から仕訳が存在するかどうかを返す
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyouForTaisyakuHassei">「判定方法：貸借発生」の場合に使用</param>
        /// <returns></returns>
        bool GetExistsTougetuHasseiByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyouForTaisyakuHassei);

        /// <summary>
        /// 問い合わせ条件と指定項目から前残があるかどうかを返す
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyouForJudgment">「当月発生の判定方法：貸借発生」または「前残の判定方法：繰越残高」の場合に使用</param>
        /// <returns></returns>
        bool GetExistsMaezanOrTougetuHasseiByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyouForJudgment);

        ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem);
    }
}