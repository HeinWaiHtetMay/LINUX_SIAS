﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class Mototyou
    {
        private List<IMototyouRow> mototyouRows = new List<IMototyouRow>();

        public Mototyou(IMototyouZibunItem zibunItem, MototyouLayoutPattern layoutPattern)
        {
            this.LayoutProgramTekiyouItem = layoutPattern.ProgramTekiyouItem;
            this.ZibunItem = zibunItem;
        }

        public MototyouLayoutItem LayoutProgramTekiyouItem { get; }

        public IReadOnlyList<IMototyouRow> MototyouRows => this.mototyouRows;

        public decimal RuikeiZandaka { get; set; }

        public decimal MaeKarikataZandaka { get; set; }

        public decimal MaeKasikataZandaka { get; set; }

        public decimal KarikataTotal { get; set; }

        public decimal KasikataTotal { get; set; }

        public IMototyouZibunItem ZibunItem { get; }

        public void AddRow(IMototyouRow row)
        {
            this.AddRow(row, false);
        }

        public void AddRow(IMototyouRow row, bool isMonthlySyuukei)
        {
            var lastRow = this.mototyouRows.LastOrDefault();
            if (lastRow != null)
            {
                lastRow.NextRow = row;
            }

            if (row != null)
            {
                row.PreviousRow = lastRow;
            }

            //// 貸借合計と累計額に加算
            switch (row?.RowType)
            {
                case MototyouRowType.MaeKurikosiRow:
                    this.RuikeiZandaka = ((AbstractMototyouRow)row)?.SasihikiZandaka ?? 0;
                    break;
                case MototyouRowType.SiwakeRow:
                case MototyouRowType.DailyRow:
                case MototyouRowType.SonekiHurikaeRow:
                    this.RuikeiZandaka += ((AbstractMototyouRow)row)?.GetSasihikiValue() ?? 0;
                    this.KarikataTotal += ((AbstractMototyouRow)row)?.KarikataValue ?? 0;
                    this.KasikataTotal += ((AbstractMototyouRow)row)?.KasikataValue ?? 0;
                    break;
                case MototyouRowType.MonthlyRow:
                    if (isMonthlySyuukei)
                    {
                        this.RuikeiZandaka += ((AbstractMototyouRow)row)?.GetSasihikiValue() ?? 0;
                        this.KarikataTotal += ((AbstractMototyouRow)row)?.KarikataValue ?? 0;
                        this.KasikataTotal += ((AbstractMototyouRow)row)?.KasikataValue ?? 0;
                    }

                    break;
                default:
                    break;
            }

            this.mototyouRows.Add(row);
        }

        public void ClearRows()
        {
            this.mototyouRows.Clear();
            this.mototyouRows = new List<IMototyouRow>();
        }
    }
}
