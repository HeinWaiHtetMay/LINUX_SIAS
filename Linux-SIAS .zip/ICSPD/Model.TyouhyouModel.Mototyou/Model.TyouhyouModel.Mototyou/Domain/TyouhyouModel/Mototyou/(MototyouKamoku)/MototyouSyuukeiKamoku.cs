﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class MototyouSyuukeiKamoku : IMototyouKamoku
    {
        private Kamoku kamoku;
        private IDictionary<string, Kamoku> utiwakeMeisaiKamokuDictionary;
        private KamokuInnerCodeFormat codeFormat;

        public MototyouSyuukeiKamoku(Kamoku kamoku, IDictionary<string, Kamoku> utiwakeMeisaiKamokuDictionary)
        {
            this.kamoku = kamoku;
            this.utiwakeMeisaiKamokuDictionary = utiwakeMeisaiKamokuDictionary;
            this.codeFormat = new KamokuInnerCodeFormat(kamoku.Kicd);
        }

        int IKamokuInnerCode.Kesn => this.kamoku.Kesn;

        string IKamokuInnerCode.Kicd => this.kamoku.Kicd;

        string IKamokuInnerCodeAndName.KamokuShortName
        {
            get { return this.kamoku.ShortName; }
            set { this.kamoku.ShortName = value; }
        }

        string IKamokuInnerCodeAndName.KamokuLongName
        {
            get { return this.kamoku.LongName; }
            set { this.kamoku.LongName = value; }
        }

        KamokuTaisyakuZokusei IMototyouKamoku.TaisyakuZokusei => this.kamoku.TaisyakuZokusei;

        MototyouSyuukeiKeisiki? IMototyouKamoku.SyuukeiKeisiki => null;

        Kamoku IMototyouKamoku.ZeiKubunKamoku => this.kamoku;

        IList<Kamoku> IMototyouKamoku.MeisaiKamokuList => this.utiwakeMeisaiKamokuDictionary.Values.ToList();

        string IMototyouKamoku.InputCode => string.Empty;

        int IMototyouKamoku.OutputOrder => default(int);

        bool IMototyouKamoku.IsIncludeKamoku(string kicd) => this.utiwakeMeisaiKamokuDictionary.ContainsKey(kicd);

        string IMototyouKamoku.GetPrintCode() => this.codeFormat.GetKicdSubstring();
    }
}
