﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Icsp.Open21.Domain.MasterModel;
using Icsp.Open21.Domain.ZandakaYosanModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// Kicdを比較するだけの科目クラス
    /// </summary>
    public class MototyouCompareKamoku : IMototyouKamoku
    {
        private IMasterData kamoku;

        public MototyouCompareKamoku(IMasterData kamoku)
        {
            this.kamoku = kamoku;
        }

        KamokuTaisyakuZokusei IMototyouKamoku.TaisyakuZokusei => throw new NotImplementedException();

        MototyouSyuukeiKeisiki? IMototyouKamoku.SyuukeiKeisiki => throw new NotImplementedException();

        Kamoku IMototyouKamoku.ZeiKubunKamoku => throw new NotImplementedException();

        IList<Kamoku> IMototyouKamoku.MeisaiKamokuList => throw new NotImplementedException();

        string IKamokuInnerCodeAndName.KamokuShortName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        string IKamokuInnerCodeAndName.KamokuLongName { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        int IKamokuInnerCode.Kesn => throw new NotImplementedException();

        string IKamokuInnerCode.Kicd => this.kamoku is KisokugaiSyuukeiKamoku kisokugaiSyuukeiKamoku ? kisokugaiSyuukeiKamoku.Pkicd : ((Kamoku)this.kamoku).Kicd;

        string IMototyouKamoku.InputCode => throw new NotImplementedException();

        int IMototyouKamoku.OutputOrder => throw new NotImplementedException();

        string IMototyouKamoku.GetPrintCode()
        {
            throw new NotImplementedException();
        }

        bool IMototyouKamoku.IsIncludeKamoku(string kicd)
        {
            throw new NotImplementedException();
        }
    }
}
