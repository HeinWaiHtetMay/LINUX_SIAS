﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class MototyouMeisaiKamoku : IMototyouKamoku
    {
        private Kamoku kamoku;

        public MototyouMeisaiKamoku(Kamoku kamoku)
        {
            this.kamoku = kamoku;
        }

        int IKamokuInnerCode.Kesn => this.kamoku.Kesn;

        string IKamokuInnerCode.Kicd => this.kamoku.Kicd;

        string IKamokuInnerCodeAndName.KamokuShortName
        {
            get { return this.kamoku.ShortName; }
            set { this.kamoku.ShortName = value; }
        }

        string IKamokuInnerCodeAndName.KamokuLongName
        {
            get { return this.kamoku.LongName; }
            set { this.kamoku.LongName = value; }
        }

        KamokuTaisyakuZokusei IMototyouKamoku.TaisyakuZokusei => this.kamoku.TaisyakuZokusei;

        MototyouSyuukeiKeisiki? IMototyouKamoku.SyuukeiKeisiki => (MototyouSyuukeiKeisiki)this.kamoku.SyuukeiKubun;

        Kamoku IMototyouKamoku.ZeiKubunKamoku => this.kamoku;

        IList<Kamoku> IMototyouKamoku.MeisaiKamokuList => new List<Kamoku> { this.kamoku };

        string IMototyouKamoku.InputCode => this.kamoku.InputCode;

        int IMototyouKamoku.OutputOrder => this.kamoku.OutputOrder;

        bool IMototyouKamoku.IsIncludeKamoku(string kicd) => this.kamoku.Kicd == kicd;

        string IMototyouKamoku.GetPrintCode() => this.kamoku.InputCode;
    }
}
