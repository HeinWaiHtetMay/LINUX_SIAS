﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public interface IMototyouKamoku : IKamokuInnerCodeAndName
    {
        string InputCode { get; }

        int OutputOrder { get; }

        KamokuTaisyakuZokusei TaisyakuZokusei { get; }

        MototyouSyuukeiKeisiki? SyuukeiKeisiki { get; }

        Kamoku ZeiKubunKamoku { get; }

        IList<Kamoku> MeisaiKamokuList { get; }

        /// <summary>
        /// 指定した科目内部コードの科目がこの科目に含まれているかどうか
        /// </summary>
        /// <param name="kicd"></param>
        /// <returns></returns>
        bool IsIncludeKamoku(string kicd);

        /// <summary>
        /// 印刷用コードを取得
        /// </summary>
        /// <returns></returns>
        string GetPrintCode();
    }
}
