﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class MototyouKisokugaiSyuukeiKamoku : IMototyouKamoku
    {
        private KisokugaiSyuukeiKamoku kamoku;
        private IDictionary<string, Kamoku> utiwakeMeisaiKamokuDictionary;
        private Kamoku zeiKubunKamoku;

        public MototyouKisokugaiSyuukeiKamoku(KisokugaiSyuukeiKamoku kamoku, IDictionary<string, Kamoku> utiwakeMeisaiKamokuDictionary, Kamoku zeiKubunKamoku)
        {
            this.kamoku = kamoku;
            this.utiwakeMeisaiKamokuDictionary = utiwakeMeisaiKamokuDictionary;
            this.zeiKubunKamoku = zeiKubunKamoku;
        }

        int IKamokuInnerCode.Kesn => this.kamoku.Kesn;

        string IKamokuInnerCode.Kicd => this.kamoku.Pkicd;

        string IKamokuInnerCodeAndName.KamokuShortName
        {
            get { return string.Empty; }
            set { }
        }

        string IKamokuInnerCodeAndName.KamokuLongName
        {
            get { return this.kamoku.Pname; }
            set { this.kamoku.Pname = value; }
        }

        KamokuTaisyakuZokusei IMototyouKamoku.TaisyakuZokusei => this.kamoku.TaisyakuZokusei;

        MototyouSyuukeiKeisiki? IMototyouKamoku.SyuukeiKeisiki => null;

        Kamoku IMototyouKamoku.ZeiKubunKamoku => this.zeiKubunKamoku;

        IList<Kamoku> IMototyouKamoku.MeisaiKamokuList => this.utiwakeMeisaiKamokuDictionary.Values.ToList();

        string IMototyouKamoku.InputCode => string.Empty;

        int IMototyouKamoku.OutputOrder => default(int);

        bool IMototyouKamoku.IsIncludeKamoku(string kicd) => this.utiwakeMeisaiKamokuDictionary.ContainsKey(kicd);

        string IMototyouKamoku.GetPrintCode() => this.kamoku.Pkicd;
    }
}
