﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;

    /// <summary>
    /// 元帳パターンクラス（DBテーブル：LDPNM）
    /// </summary>
    public class MototyouQueryConditionPattern : IMasterData, IMototyouOutputOrders
    {
        public static readonly IMasterInfo MasterInfo = new MasterInfo(MasterType.Other, MasterCodeType.Numeric, 4);

        public MototyouQueryConditionPattern(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int patternNo)
        {
            this.Kesn = kesn;
            this.MototyouType = mototyouType;
            this.BumonType = bumonType;
            this.KamokuKubun = kamokuKubun;
            this.PatternType = patternType;
            this.PatternNo = patternNo;
        }

        #region public properties

        public string Code => MasterInfo.GetFormattedCode(this.PatternNo.ToString());

        public string Name => this.PatternName;

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 元帳種類（カラム名：lmod）
        /// </summary>
        public MototyouType MototyouType { get; private set; }

        /// <summary>
        /// 部門の種類（カラム名：bmod）
        /// </summary>
        public MototyouBumonType BumonType { get; private set; }

        /// <summary>
        /// 科目の種類（カラム名：kmod）
        /// </summary>
        public KamokuKubun KamokuKubun { get; private set; } = KamokuKubun.Meisai;

        /// <summary>
        /// ｽｹｼﾞｭｰﾙの種類（カラム名：smod）
        /// </summary>
        public MototyouQueryConditionPatternType PatternType { get; private set; }

        /// <summary>
        /// パターンno（カラム名：lptn）
        /// </summary>
        public int PatternNo { get; private set; }

        /// <summary>
        /// パターン名称（カラム名：lnam）
        /// </summary>
        public string PatternName { get; set; }

        /// <summary>
        /// 科目の並び（カラム名：kjun）
        /// </summary>
        public KamokuOutputOrder KamokuOutputOrder { get; set; } = KamokuOutputOrder.ByOutputOrderCode;

        /// <summary>
        /// 出力順（カラム名：ojun）
        /// </summary>
        public int OutputOrder { get; set; }

        /// <summary>
        /// 集計形式の適用（カラム名：skeit）
        /// </summary>
        public MototyouSyuukeiKeisikiApplyingWay SyuukeiKeisikiApplyingWay { get; set; } = MototyouSyuukeiKeisikiApplyingWay.All;

        /// <summary>
        /// 集計形式（カラム名：skei）
        /// </summary>
        public MototyouSyuukeiKeisiki SyuukeiKeisiki { get; set; } = MototyouSyuukeiKeisiki.Detail;

        /// <summary>
        /// 元帳パターン明細
        /// </summary>
        public IList<MototyouQueryConditionPatternItem> Items { get; set; }

        EdabanMototyouOutputOrder IMototyouOutputOrders.EdabanMototyouOutputOrder => (EdabanMototyouOutputOrder)this.OutputOrder;

        BumonMototyouOutputOrder IMototyouOutputOrders.BumonMototyouOutputOrder => (BumonMototyouOutputOrder)this.OutputOrder;

        BumonKamokuEdabanMototyouOutputOrder IMototyouOutputOrders.BumonKamokuEdabanMototyouOutputOrder => (BumonKamokuEdabanMototyouOutputOrder)this.OutputOrder;

        TorihikisakiMototyouOutputOrder IMototyouOutputOrders.TorihikisakiMototyouOutputOrder => (TorihikisakiMototyouOutputOrder)this.OutputOrder;

        BumonKamokuTorihikisakiMototyouOutputOrder IMototyouOutputOrders.BumonKamokuTorihikisakiMototyouOutputOrder => (BumonKamokuTorihikisakiMototyouOutputOrder)this.OutputOrder;

        #endregion
    }
}
