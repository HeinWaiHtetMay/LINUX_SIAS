﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public interface IMototyouQueryConditionPatternItemRepository
    {
        IList<MototyouQueryConditionPatternItem> FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNo(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int patternNo);
    }
}