﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public interface IMototyouQueryConditionPatternRepository
    {
        MototyouQueryConditionPattern FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNo(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int patternNo);

        IList<MototyouQueryConditionPattern> FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNoRange(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int? startPatternNo, int? endPatternNo);
    }
}