﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouQueryConditionPatternItem : IMototyouQueryConditionRange, IMototyouQueryConditionKobetuSiteiItem
    {
        public MototyouQueryConditionPatternItem(int seq)
        {
            this.Seq = seq;
        }

        #region public properties

        /// <summary>
        /// ｓｅｑ（カラム名：seq）
        /// </summary>
        public int Seq { get; private set; }

        /// <summary>
        /// 集計形式（カラム名：skei）
        /// </summary>
        public MototyouSyuukeiKeisiki SyuukeiKeisiki { get; set; } = MototyouSyuukeiKeisiki.Detail;

        /// <summary>
        /// 部門コード１（カラム名：bcod1）
        /// </summary>
        public string Bcod1 { get; set; }

        /// <summary>
        /// 科目コード1（カラム名：kicd1）
        /// </summary>
        public string Kicd1 { get; set; }

        /// <summary>
        /// 枝番コード1（カラム名：ecod1）
        /// </summary>
        public string Ecod1 { get; set; }

        /// <summary>
        /// 取引先コード1（カラム名：tcod1）
        /// </summary>
        public string Tcod1 { get; set; }

        /// <summary>
        /// 部門コード2（カラム名：bcod2）
        /// </summary>
        public string Bcod2 { get; set; }

        /// <summary>
        /// 科目コード2（カラム名：kicd2）
        /// </summary>
        public string Kicd2 { get; set; }

        /// <summary>
        /// 枝番コード2（カラム名：ecod2）
        /// </summary>
        public string Ecod2 { get; set; }

        /// <summary>
        /// 取引先コード2（カラム名：tcod2）
        /// </summary>
        public string Tcod2 { get; set; }

        public Kamoku Kamoku1 { get; set; }

        public Kamoku Kamoku2 { get; set; }

        #region implements IMototyouQueryConditionRange

        Kamoku IMototyouQueryConditionRange.StartKamoku => this.Kamoku1;

        Kamoku IMototyouQueryConditionRange.EndKamoku => this.Kamoku2;

        string IMototyouQueryConditionRange.StartPkicd => this.Kicd1;

        string IMototyouQueryConditionRange.EndPkicd => this.Kicd2;

        string IMototyouQueryConditionRange.StartEdabanCode => this.Ecod1;

        string IMototyouQueryConditionRange.EndEdabanCode => this.Ecod2;

        string IMototyouQueryConditionRange.StartBumonCode => this.Bcod1;

        string IMototyouQueryConditionRange.EndBumonCode => this.Bcod2;

        string IMototyouQueryConditionRange.StartTorihikisakiCode => this.Tcod1;

        string IMototyouQueryConditionRange.EndTorihikisakiCode => this.Tcod2;

        #endregion

        #region implements IMototyouQueryConditionKobetuSiteiItem

        Kamoku IMototyouQueryConditionKobetuSiteiItem.Kamoku => this.Kamoku1;

        string IMototyouQueryConditionKobetuSiteiItem.Pkicd => this.Kicd1;

        string IMototyouQueryConditionKobetuSiteiItem.EdabanCode => this.Ecod1;

        string IMototyouQueryConditionKobetuSiteiItem.BumonCode => this.Bcod1;

        string IMototyouQueryConditionKobetuSiteiItem.TorihikisakiCode => this.Tcod1;

        int? IMototyouQueryConditionKobetuSiteiItem.StartPageNo => null;

        int? IMototyouQueryConditionKobetuSiteiItem.EndPageNo => null;

        #endregion

        #endregion
    }
}
