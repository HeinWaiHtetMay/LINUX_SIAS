﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouOutputOrders
    {
        EdabanMototyouOutputOrder EdabanMototyouOutputOrder { get; }

        BumonMototyouOutputOrder BumonMototyouOutputOrder { get; }

        BumonKamokuEdabanMototyouOutputOrder BumonKamokuEdabanMototyouOutputOrder { get; }

        TorihikisakiMototyouOutputOrder TorihikisakiMototyouOutputOrder { get; }

        BumonKamokuTorihikisakiMototyouOutputOrder BumonKamokuTorihikisakiMototyouOutputOrder { get; }
    }
}
