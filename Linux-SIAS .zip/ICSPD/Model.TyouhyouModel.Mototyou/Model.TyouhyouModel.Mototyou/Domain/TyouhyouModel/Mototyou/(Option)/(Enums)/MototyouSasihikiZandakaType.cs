﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouSasihikiZandakaType
    {
        /// <summary>
        /// 日ごとに出力
        /// </summary>
        PerDays = 0,

        /// <summary>
        /// 常に出力
        /// </summary>
        Always = 1
    }
}
