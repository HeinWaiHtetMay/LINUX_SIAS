﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouZenzanJudgmentType
    {
        TaisyakuHasseiWithConsiderationKisyu = 0,
        TaisyakuHasseiWithoutConsiderationKisyu = 1,
        KurikosiZandaka = 2
    }
}
