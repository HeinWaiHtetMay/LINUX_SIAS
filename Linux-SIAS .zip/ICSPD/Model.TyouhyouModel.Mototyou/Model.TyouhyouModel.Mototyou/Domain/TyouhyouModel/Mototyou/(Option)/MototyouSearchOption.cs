﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳問い合わせ結果画面用の検索設定
    /// </summary>
    public class MototyouSearchOption
    {
        public MototyouSearchType MototyouSearchType { get; set; }

        public MototyouSearchType EdabanMototyouSearchType { get; set; }

        public MototyouSearchType BumonMototyouSearchType { get; set; }

        public MototyouSearchType TorihikisakiMototyouSearchType { get; set; }

        public MototyouSearchType this[MasterSearchableMototyouType masterSearchableMototyouType]
        {
            get
            {
                switch (masterSearchableMototyouType)
                {
                    case MasterSearchableMototyouType.Mototyou:
                        return this.MototyouSearchType;
                    case MasterSearchableMototyouType.EdabanMototyou:
                        return this.EdabanMototyouSearchType;
                    case MasterSearchableMototyouType.BumonMototyou:
                        return this.BumonMototyouSearchType;
                    case MasterSearchableMototyouType.TorihikisakiMototyou:
                        return this.TorihikisakiMototyouSearchType;
                    default:
                        return MototyouSearchType.KoumokuSelection;
                }
            }

            set
            {
                switch (masterSearchableMototyouType)
                {
                    case MasterSearchableMototyouType.Mototyou:
                        this.MototyouSearchType = value;
                        break;
                    case MasterSearchableMototyouType.EdabanMototyou:
                        this.EdabanMototyouSearchType = value;
                        break;
                    case MasterSearchableMototyouType.BumonMototyou:
                        this.BumonMototyouSearchType = value;
                        break;
                    case MasterSearchableMototyouType.TorihikisakiMototyou:
                        this.TorihikisakiMototyouSearchType = value;
                        break;
                    default:
                        break;
                }
            }
        }

        public MototyouSearchType this[MototyouType mototyouType]
        {
            get
            {
                switch (mototyouType)
                {
                    case MototyouType.Mototyou:
                        return this.MototyouSearchType;
                    case MototyouType.EdabanMototyou:
                        return this.EdabanMototyouSearchType;
                    case MototyouType.BumonMototyou:
                        return this.BumonMototyouSearchType;
                    case MototyouType.TorihikisakiMototyou:
                        return this.TorihikisakiMototyouSearchType;
                    default:
                        return MototyouSearchType.KoumokuSelection;
                }
            }

            set
            {
                switch (mototyouType)
                {
                    case MototyouType.Mototyou:
                        this.MototyouSearchType = value;
                        break;
                    case MototyouType.EdabanMototyou:
                        this.EdabanMototyouSearchType = value;
                        break;
                    case MototyouType.BumonMototyou:
                        this.BumonMototyouSearchType = value;
                        break;
                    case MototyouType.TorihikisakiMototyou:
                        this.TorihikisakiMototyouSearchType = value;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
