﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;

    /// <summary>
    /// レイアウトパターンごとの問い合わせ結果画面における列幅設定
    /// </summary>
    public class MototyouLayoutColumnWidthOption
    {
        private const int DateColumnDefaultWidth = 24;
        private const int KingakuColumnDefaultWidthWhenKingakuLengthIs12 = 116;
        private const int KingakuColumnDefaultWidthWhenKingakuLengthIs15 = 144;
        private const int ZeiKubunColumnDefaultWidthWhenRowCountIs1 = 123;
        private const int ZeiKubunColumnDefaultWidthWhenRowCountIsMoreThan2 = 62;

        public MototyouLayoutColumnWidthOption(MototyouLayoutPattern layoutPattern, Syoriki syoriki)
        {
            this.LayoutPattern = layoutPattern;
            //// パターンに関係ないレイアウト項目のカラム幅セット
            this.MonthColumnWidth = DateColumnDefaultWidth;
            this.DayColumnWidth = DateColumnDefaultWidth;
            this.ZeiKubunColumnWidth = layoutPattern.UseSyouhizeiKubun
                ? (int?)(layoutPattern.RowCount == 1 ? ZeiKubunColumnDefaultWidthWhenRowCountIs1 : ZeiKubunColumnDefaultWidthWhenRowCountIsMoreThan2)
                : null;
            this.KarikataValueColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;
            this.KasikataValueColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;
            this.SasihikiZandakaColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;
        }

        public MototyouLayoutPattern LayoutPattern { get; private set; }

        /// <summary>
        /// レイアウトパターン番号(4桁)
        /// </summary>
        public string LayoutPatternNo => this.LayoutPattern.PatternNo.ToString("0000");

        /// <summary>
        /// 月列幅
        /// </summary>
        public int? MonthColumnWidth { get; set; }

        /// <summary>
        /// 日列幅
        /// </summary>
        public int? DayColumnWidth { get; set; }

        /// <summary>
        /// レイアウト編集列の列幅
        /// </summary>
        public IDictionary<int, int?> EditColumnWidths { get; set; } = new Dictionary<int, int?>();

        /// <summary>
        /// 税区分列幅
        /// </summary>
        public int? ZeiKubunColumnWidth { get; set; }

        /// <summary>
        /// 借方金額列幅
        /// </summary>
        public int? KarikataValueColumnWidth { get; set; }

        /// <summary>
        /// 貸方金額列幅
        /// </summary>
        public int? KasikataValueColumnWidth { get; set; }

        /// <summary>
        /// 差引残高列幅
        /// </summary>
        public int? SasihikiZandakaColumnWidth { get; set; }

        /// <summary>
        /// 列幅にデフォルト値をセット
        /// </summary>
        /// <param name="layoutPattern"></param>
        /// <param name="currentSyoriki"></param>
        public void SetDefaultColumnWidth(MototyouLayoutPattern layoutPattern, Syoriki currentSyoriki)
        {
            this.MonthColumnWidth = DateColumnDefaultWidth;
            this.DayColumnWidth = DateColumnDefaultWidth;
            this.ZeiKubunColumnWidth = layoutPattern.UseSyouhizeiKubun
                ? (int?)(layoutPattern.RowCount == 1 ? ZeiKubunColumnDefaultWidthWhenRowCountIs1 : ZeiKubunColumnDefaultWidthWhenRowCountIsMoreThan2)
                : null;
            this.KarikataValueColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;
            this.KasikataValueColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;
            this.SasihikiZandakaColumnWidth = layoutPattern.KingakuLength == MototyouLayoutKingakuLength.Length12
                ? KingakuColumnDefaultWidthWhenKingakuLengthIs12 : KingakuColumnDefaultWidthWhenKingakuLengthIs15;

            //// 一旦クリア
            this.EditColumnWidths.Clear();
            for (int i = 1; i <= layoutPattern.ColumnCount; i++)
            {
                this.EditColumnWidths.Add(i + 100, this.GetColumnWidth((MototyouColumnType)(i + 1), i, currentSyoriki, layoutPattern));
            }
        }

        public int? GetColumnWidth(MototyouColumnType columnType, int columnNumber, Syoriki currentSyoriki, MototyouLayoutPattern layoutPattern)
        {
            var key = (int)columnType - 1 + 100;
            if (this.EditColumnWidths.ContainsKey(key))
            {
                if (this.EditColumnWidths[key] != null && this.EditColumnWidths[key] != 0)
                {
                    return this.EditColumnWidths[key];
                }
            }

            //// デフォルト値を計算して返す
            var columnItems = layoutPattern.Items.Where(item => item.ColumnNo == columnNumber);
            var width = (int?)(Math.Max(
                layoutPattern.Columns[columnNumber - 1].GetHeaderTitleMaxWidth(),
                columnItems.Any() ? columnItems.Max(item => (this.LayoutPattern.IsAvailableItem(item, currentSyoriki) ? item.GetHalfWidthCharCount(currentSyoriki) : 0)) : 0) * 0.11m * 70);
            return width;
        }
    }
}
