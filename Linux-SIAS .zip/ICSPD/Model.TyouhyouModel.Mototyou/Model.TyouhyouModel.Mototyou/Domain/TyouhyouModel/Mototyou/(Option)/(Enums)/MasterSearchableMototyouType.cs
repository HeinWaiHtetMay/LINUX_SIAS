﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 50音検索を選択可能な元帳種類
    /// </summary>
    public enum MasterSearchableMototyouType
    {
        Mototyou = 0,
        EdabanMototyou = 1,
        BumonMototyou = 2,
        TorihikisakiMototyou = 3
    }
}
