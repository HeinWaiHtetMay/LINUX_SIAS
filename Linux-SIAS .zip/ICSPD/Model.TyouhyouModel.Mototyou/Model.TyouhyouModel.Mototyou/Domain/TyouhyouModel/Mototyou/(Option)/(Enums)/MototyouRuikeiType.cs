﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouRuikeiOutputType
    {
        NotOutput = 0,

        /// <summary>
        /// 翌○繰越の前に出力
        /// </summary>
        OutputBeforeNextKurikosi = 1,

        /// <summary>
        /// 翌○繰越の後に出力
        /// </summary>
        OutputAfterNextKurikosi = 2
    }
}
