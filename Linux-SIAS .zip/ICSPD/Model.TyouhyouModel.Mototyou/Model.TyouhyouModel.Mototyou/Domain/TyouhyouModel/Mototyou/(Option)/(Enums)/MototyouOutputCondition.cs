﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouOutputCondition
    {
        NoDirection = 0,
        MaezanOrTougetuHassei = 1,
        TougetuHassei = 2
    }
}
