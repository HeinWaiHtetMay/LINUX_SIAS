﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouTypeExtension
    {
        public static bool ContainsBumon(this MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.BumonMototyou:
                case MototyouType.BumonKamokuEdabanMototyou:
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return true;
                default:
                    return false;
            }
        }

        public static bool ContainsEdaban(this MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.EdabanMototyou:
                case MototyouType.BumonKamokuEdabanMototyou:
                    return true;
                default:
                    return false;
            }
        }

        public static bool ContainsTorihikisaki(this MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.TorihikisakiMototyou:
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return true;
                default:
                    return false;
            }
        }

        public static bool IsIkkatuZandakaUpdatable(this MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.BumonKamokuEdabanMototyou:
                case MototyouType.TorihikisakiMototyou:
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return true;
                default:
                    return false;
            }
        }

        public static string GetName(this MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    return "元帳";
                case MototyouType.EdabanMototyou:
                    return "枝番元帳";
                case MototyouType.BumonMototyou:
                    return "部門元帳";
                case MototyouType.BumonKamokuEdabanMototyou:
                    return "部門科目枝番元帳";
                case MototyouType.TorihikisakiMototyou:
                    return "取引先元帳";
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return "部門科目取引先元帳";
                default:
                    return string.Empty;
            }
        }
    }
}
