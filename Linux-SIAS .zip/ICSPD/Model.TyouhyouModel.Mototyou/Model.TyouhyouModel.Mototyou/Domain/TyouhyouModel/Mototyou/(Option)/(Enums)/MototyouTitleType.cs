﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouTitleType
    {
        Fixed = 0,
        UseOption = 1
    }
}
