﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public static class BumonKamokuEdabanMototyouOutputOrderExtension
    {
        public static IReadOnlyList<MasterType> CreateMasterTypeList(this BumonKamokuEdabanMototyouOutputOrder bumonKamokuEdabanMototyouOutputOrder)
        {
            switch (bumonKamokuEdabanMototyouOutputOrder)
            {
                case BumonKamokuEdabanMototyouOutputOrder.BumonKamokuEdaban:
                    return new MasterType[] { MasterType.Bumon, MasterType.Kamoku, MasterType.Edaban };
                case BumonKamokuEdabanMototyouOutputOrder.KamokuEdabanBumon:
                    return new MasterType[] { MasterType.Kamoku, MasterType.Edaban, MasterType.Bumon };
                default:
                    return null;
            }
        }
    }
}
