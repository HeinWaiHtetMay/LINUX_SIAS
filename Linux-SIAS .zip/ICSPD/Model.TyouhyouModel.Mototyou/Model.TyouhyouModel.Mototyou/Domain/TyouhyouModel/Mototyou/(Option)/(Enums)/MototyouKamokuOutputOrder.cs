﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouKamokuOutputOrder
    {
        FollowKaisyaSetting = 0,
        ByOutputOrder = 1,
        ByInputCode = 2,
        ByInnerCode = 3
    }
}
