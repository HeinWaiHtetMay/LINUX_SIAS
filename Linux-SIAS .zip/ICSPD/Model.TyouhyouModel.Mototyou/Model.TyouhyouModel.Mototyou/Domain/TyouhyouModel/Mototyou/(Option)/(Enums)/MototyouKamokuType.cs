﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 科目分類
    /// </summary>
    public enum MototyouKamokuType
    {
        MeisaiKamoku = 0,
        SyouKamoku = 1,
        SyuukeiSyouKamoku = 2,
        KisokugaiSyuukeiKamoku = 3
    }
}
