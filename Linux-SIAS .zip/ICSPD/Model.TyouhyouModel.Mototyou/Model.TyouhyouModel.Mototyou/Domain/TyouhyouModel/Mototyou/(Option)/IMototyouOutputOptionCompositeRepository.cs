﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouOutputOptionCompositeRepository
    {
        MototyouOutputOptionComposite FindByKesn(int kesn);
    }
}