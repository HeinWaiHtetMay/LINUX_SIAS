﻿using Icsp.Open21.Domain.KaisyaModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouQueryResultFormOptionCompositeRepository
    {
        MototyouQueryResultFormOptionComposite FindByUserCodeAndLayoutPatternNoAndSyoriki(int userCode, int layoutPatternNo, Syoriki syoriki);

        void Store(MototyouQueryResultFormOptionComposite queryResultFormOptionComposite);
    }
}