﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MasterSearchableMototyouTypeExtension
    {
        public static MototyouType ConvertMototyouType(this MasterSearchableMototyouType masterSearchableMototyouType)
        {
            switch (masterSearchableMototyouType)
            {
                case MasterSearchableMototyouType.Mototyou:
                    return MototyouType.Mototyou;
                case MasterSearchableMototyouType.EdabanMototyou:
                    return MototyouType.EdabanMototyou;
                case MasterSearchableMototyouType.BumonMototyou:
                    return MototyouType.BumonMototyou;
                case MasterSearchableMototyouType.TorihikisakiMototyou:
                default:
                    return MototyouType.TorihikisakiMototyou;
            }
        }
    }
}
