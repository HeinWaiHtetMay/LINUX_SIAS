﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouOutputSeirituki
    {
        /// <summary>
        /// 数字
        /// </summary>
        Numeric = 0,

        /// <summary>
        /// 丸囲み数字
        /// </summary>
        CircleEnclosing = 1,
    }
}
