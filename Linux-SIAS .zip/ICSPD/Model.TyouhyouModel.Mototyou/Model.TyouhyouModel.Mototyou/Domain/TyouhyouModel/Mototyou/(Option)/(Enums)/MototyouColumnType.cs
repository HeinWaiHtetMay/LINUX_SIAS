﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouColumnType
    {
        Month = 0,
        Day = 1,
        EditColumn1 = 2,
        EditColumn2 = 3,
        EditColumn3 = 4,
        EditColumn4 = 5,
        EditColumn5 = 6,
        EditColumn6 = 7,
        EditColumn7 = 8,
        EditColumn8 = 9,
        EditColumn9 = 10,
        EditColumn10 = 11,
        EditColumn11 = 12,
        EditColumn12 = 13,
        EditColumn13 = 14,
        EditColumn14 = 15,
        EditColumn15 = 16,
        ZeiKubun = 17,
        Karikata = 18,
        Kasikata = 19,
        SasihikiZandaka = 20
    }
}
