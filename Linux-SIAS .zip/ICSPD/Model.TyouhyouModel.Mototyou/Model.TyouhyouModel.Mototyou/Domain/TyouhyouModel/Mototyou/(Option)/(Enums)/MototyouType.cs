﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouType
    {
        Mototyou = 1,
        EdabanMototyou = 2,
        BumonMototyou = 3,
        BumonKamokuEdabanMototyou = 4,
        TorihikisakiMototyou = 5,
        BumonKamokuTorihikisakiMototyou = 6
    }
}
