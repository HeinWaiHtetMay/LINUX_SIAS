﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;

    public static class MototyouKamokuOutputOrderExtension
    {
        public static KamokuOutputOrder GetKamokuOutputOrder(this MototyouKamokuOutputOrder mototyouKamokuOutputOrder, Syoriki syoriki)
        {
            switch (mototyouKamokuOutputOrder)
            {
                case MototyouKamokuOutputOrder.ByOutputOrder:
                    return KamokuOutputOrder.ByOutputOrderCode;
                case MototyouKamokuOutputOrder.ByInputCode:
                    return KamokuOutputOrder.ByInputCode;
                case MototyouKamokuOutputOrder.ByInnerCode:
                    return KamokuOutputOrder.ByInnerCode;
                case MototyouKamokuOutputOrder.FollowKaisyaSetting:
                default:
                    return syoriki.KamokuOutputOrder;
            }
        }
    }
}
