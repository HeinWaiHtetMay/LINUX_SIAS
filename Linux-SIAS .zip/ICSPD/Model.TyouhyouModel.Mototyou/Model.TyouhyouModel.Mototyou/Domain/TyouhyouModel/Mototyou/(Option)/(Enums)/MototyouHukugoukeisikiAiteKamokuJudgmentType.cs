﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouHukugoukeisikiAiteKamokuJudgmentType
    {
        AiteInSiwakeList = 0,
        FirstKamoku = 1,
        MaxKingakuKamoku = 2
    }
}
