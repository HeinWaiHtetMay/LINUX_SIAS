﻿using Icsp.Open21.Domain.KaisyaModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳問い合わせ結果画面用オプション
    /// </summary>
    public class MototyouQueryResultFormOptionComposite
    {
        public MototyouQueryResultFormOptionComposite(int userCode, MototyouLayoutPattern layoutPattern, Syoriki syoriki)
        {
            this.UserCode = userCode;
            this.SearchOption = new MototyouSearchOption();
            this.LayoutColumnWidthOption = new MototyouLayoutColumnWidthOption(layoutPattern, syoriki);
        }

        public int UserCode { get; private set; }

        public MototyouSearchOption SearchOption { get; private set; }

        public MototyouLayoutColumnWidthOption LayoutColumnWidthOption { get; private set; }
    }
}
