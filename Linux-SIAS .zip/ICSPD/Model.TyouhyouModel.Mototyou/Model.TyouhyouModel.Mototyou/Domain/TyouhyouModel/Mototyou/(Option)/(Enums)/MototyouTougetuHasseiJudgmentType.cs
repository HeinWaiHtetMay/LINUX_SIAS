﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouTougetuHasseiJudgmentType
    {
        TaisyakuHassei = 0,
        Siwake = 1
    }
}
