﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouZeiKubunRelativeDisplayCompareType
    {
        ConvertAvailableZeiritu = 0,
        KamokuMasterZeiritu = 1
    }
}
