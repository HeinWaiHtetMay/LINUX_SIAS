﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouOptionComposite
    {
        public MototyouOptionComposite(int userCode)
        {
            this.UserCode = userCode;
        }

        public int UserCode { get; private set; }

        public MototyouQueryOption QueryOption { get; private set; } = new MototyouQueryOption();

        public MototyouOption Option { get; private set; } = new MototyouOption();

        public MototyouMarginOption MarginOption { get; private set; } = new MototyouMarginOption();

        public MototyouPrintOption PrintOption { get; private set; } = new MototyouPrintOption();

        public MototyouOptionComposite CloneAsDeepCopy()
        {
            var optionComposite = this.MemberwiseClone() as MototyouOptionComposite;
            optionComposite.QueryOption = optionComposite.QueryOption.CloneAsShallowCopy();
            optionComposite.Option = optionComposite.Option.CloneAsShallowCopy();
            optionComposite.MarginOption = optionComposite.MarginOption.CloneAsShallowCopy();
            optionComposite.PrintOption = optionComposite.PrintOption.CloneAsShallowCopy();
            return optionComposite;
        }
    }
}
