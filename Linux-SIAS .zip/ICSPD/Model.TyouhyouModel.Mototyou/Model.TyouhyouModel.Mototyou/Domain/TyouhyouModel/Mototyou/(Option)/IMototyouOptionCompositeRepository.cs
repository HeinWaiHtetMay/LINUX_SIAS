﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouOptionCompositeRepository
    {
        MototyouOptionComposite FindByUserCode(int userCode, bool isBusyoNyuusyuturyokuSyori);

        void Store(MototyouOptionComposite optionComposite, bool isBusyoNyuusyuturyokuSyori);
    }
}