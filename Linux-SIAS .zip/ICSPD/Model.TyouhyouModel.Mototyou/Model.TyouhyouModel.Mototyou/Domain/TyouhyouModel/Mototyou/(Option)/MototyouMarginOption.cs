﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouMarginOption
    {
        /// <summary>
        /// 上余白（単位mm）
        /// </summary>
        public int Top { get; set; }

        /// <summary>
        /// 左余白（単位mm）
        /// </summary>
        public int Left { get; set; }

        public MototyouMarginOption CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as MototyouMarginOption;
        }
    }
}
