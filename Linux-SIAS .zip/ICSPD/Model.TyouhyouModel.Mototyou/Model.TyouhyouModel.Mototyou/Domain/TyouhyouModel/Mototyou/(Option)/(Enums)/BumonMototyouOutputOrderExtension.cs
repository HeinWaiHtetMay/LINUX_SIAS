﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public static class BumonMototyouOutputOrderExtension
    {
        public static IReadOnlyList<MasterType> CreateMasterTypeList(this BumonMototyouOutputOrder bumonMototyouOutputOrder)
        {
            switch (bumonMototyouOutputOrder)
            {
                case BumonMototyouOutputOrder.BumonKamoku:
                    return new MasterType[] { MasterType.Bumon, MasterType.Kamoku };
                case BumonMototyouOutputOrder.KamokuBumon:
                    return new MasterType[] { MasterType.Kamoku, MasterType.Bumon };
                default:
                    return null;
            }
        }
    }
}
