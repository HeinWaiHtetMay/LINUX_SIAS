﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouOption
    {
        /// <summary>
        /// 整理月の月を丸囲み文字で出力するかどうか
        /// </summary>
        public MototyouOutputSeirituki OutputSeirituki { get; set; } = MototyouOutputSeirituki.CircleEnclosing;

        public MototyouMonthlyTotal MonthlyTotal { get; set; } = MototyouMonthlyTotal.None;

        public MototyouRuikeiOutputType RuikeiOutputType { get; set; } = MototyouRuikeiOutputType.NotOutput;

        public MototyouKazeiKubunOutputType KazeiKubunOutputType { get; set; } = MototyouKazeiKubunOutputType.Absolute;

        /// <summary>
        /// 規則外集計科目の場合、タイトル登録されている最初の科目の課税区分とする
        /// </summary>
        public bool UseTitleRegisterdFirstKamokuKazeiKubunIfKisokugaiSyuukeiKamoku { get; set; } = true;

        public MototyouIkkatuZeinukiSiwakeSyuukeiType IkkatuZeinukiSiwakeSyuukeiType { get; set; } = MototyouIkkatuZeinukiSiwakeSyuukeiType.None;

        /// <summary>
        /// 一括税抜仕訳を集計しない場合、一括税抜仕訳を月の最後に出力する
        /// </summary>
        public bool OutputIkkatuZeinuykiSiwakeLastOnMonthIfSyuukeiTypeIsNone { get; set; } = false;

        public MototyouZenzanJudgmentType ZenzanJudgmentType { get; set; } = MototyouZenzanJudgmentType.TaisyakuHasseiWithConsiderationKisyu;

        public MototyouTougetuHasseiJudgmentType TougetuHasseiJudgmentType { get; set; } = MototyouTougetuHasseiJudgmentType.Siwake;

        public MototyouSasihikiZandakaType SasihikiZandakaType { get; set; } = MototyouSasihikiZandakaType.PerDays;

        public MototyouKamokuOutputOrder KamokuOutputOrder { get; set; } = MototyouKamokuOutputOrder.FollowKaisyaSetting;

        public MototyouHukugoukeisikiAiteKamokuJudgmentType HukugoukeisikiAiteKamokuJudgmentType { get; set; } = MototyouHukugoukeisikiAiteKamokuJudgmentType.AiteInSiwakeList;

        public MototyouPrintPageNoSequenceType PrintPageNoSequenceType { get; set; } = MototyouPrintPageNoSequenceType.PerKamoku;

        /// <summary>
        /// 取引先正式名称を印刷するかどうか
        /// </summary>
        public MototyouPrintTorihikisakiName PrintTorihikisakiName { get; set; } = MototyouPrintTorihikisakiName.ShortName;

        public string MototyouTitle { get; set; } = "元　　　　帳";

        public string EdabanMototyouTitle { get; set; } = "元　　　　帳";

        public string BumonMototyouTitle { get; set; } = "元　　　　帳";

        public string BumonKamokuEdabanMototyouTitle { get; set; } = "元　　　　帳";

        public string TorihikisakiMototyouTitle { get; set; } = "元　　　　帳";

        public string BumonKamokuTorihikisakiMototyouTitle { get; set; } = "元　　　　帳";

        public MototyouTitleType CsvTitleType { get; set; }

        public string GetTitle(MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    return this.MototyouTitle;
                case MototyouType.EdabanMototyou:
                    return this.EdabanMototyouTitle;
                case MototyouType.BumonMototyou:
                    return this.BumonMototyouTitle;
                case MototyouType.BumonKamokuEdabanMototyou:
                    return this.BumonKamokuEdabanMototyouTitle;
                case MototyouType.TorihikisakiMototyou:
                    return this.TorihikisakiMototyouTitle;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return this.BumonKamokuTorihikisakiMototyouTitle;
                default:
                    return string.Empty;
            }
        }

        public string GetTitle(MototyouType mototyouType, bool isCsv)
        {
            //// TODO CSVタイトルの設定
            return isCsv ? "CSVタイトル(仮)" : this.GetTitle(mototyouType);
        }

        public MototyouOption CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as MototyouOption;
        }
    }
}
