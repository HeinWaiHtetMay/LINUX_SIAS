﻿using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳の出力用設定
    /// </summary>
    public class MototyouOutputOptionComposite
    {
        /// <summary>
        /// 遡及の差額計算設定
        /// </summary>
        public SokyuuSagakuCalculateOption SokyuuSagakuCalculateOption { get; set; } = new SokyuuSagakuCalculateOption();

        /// <summary>
        /// 仕訳の出力設定
        /// </summary>
        public SiwakeOutputOption SiwakeOutputOption { get; set; } = new SiwakeOutputOption();

        /// <summary>
        /// 課税区分の「0:対象外」を出力するかどうか
        /// </summary>
        public bool ShouldOutputKazeiKubunTaisyougai { get; set; } = true;
    }
}
