﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    public enum MototyouSyuukeiKeisiki
    {
        Detail = MasterSyuukeiKubun.Normal,
        Daily = MasterSyuukeiKubun.Daily,
        Monthly = MasterSyuukeiKubun.Monthly
    }
}
