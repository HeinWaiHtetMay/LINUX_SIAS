﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouSearchType
    {
        KoumokuSelection = 0,
        SearchMaster = 1
    }
}
