﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouQueryOption : IMototyouOutputOrders
    {
        public MototyouType MototyouType { get; set; } = MototyouType.Mototyou;

        public MototyouKamokuType KamokuType { get; set; } = MototyouKamokuType.MeisaiKamoku;

        public MototyouBumonType BumonType { get; set; } = MototyouBumonType.Bumon;

        public int? LayoutPatternNo { get; set; } = null;

        public MototyouOutputCondition OutputCondition { get; set; } = MototyouOutputCondition.TougetuHassei;

        public MototyouSyuukeiKeisikiApplyingWay SyuukeiKeisikiApplyingWay { get; set; } = MototyouSyuukeiKeisikiApplyingWay.All;

        public MototyouSyuukeiKeisiki SyuukeiKeisiki { get; set; } = MototyouSyuukeiKeisiki.Detail;

        public bool UseUserSeiritukiCalculateOption { get; set; } = true;

        public EdabanMototyouOutputOrder EdabanMototyouOutputOrder { get; set; } = EdabanMototyouOutputOrder.KamokuEdaban;

        public BumonKamokuEdabanMototyouOutputOrder BumonKamokuEdabanMototyouOutputOrder { get; set; } = BumonKamokuEdabanMototyouOutputOrder.BumonKamokuEdaban;

        public BumonKamokuTorihikisakiMototyouOutputOrder BumonKamokuTorihikisakiMototyouOutputOrder { get; set; } = BumonKamokuTorihikisakiMototyouOutputOrder.BumonKamokuTorihikisaki;

        public BumonMototyouOutputOrder BumonMototyouOutputOrder { get; set; } = BumonMototyouOutputOrder.BumonKamoku;

        public TorihikisakiMototyouOutputOrder TorihikisakiMototyouOutputOrder { get; set; } = TorihikisakiMototyouOutputOrder.KamokuTorihikisaki;

        /// <summary>
        /// 集計科目もしくは部門を含む元帳種類で集計部門かどうか
        /// </summary>
        public bool IsSyuukeiItem => this.KamokuType != MototyouKamokuType.MeisaiKamoku || this.IsSyuukeiBumon;

        /// <summary>
        /// 部門を含む元帳種類で集計部門かどうか
        /// </summary>
        public bool IsSyuukeiBumon => this.MototyouType.ContainsBumon() && this.BumonType == MototyouBumonType.SyuukeiBumon;

        public void SetOutputOrderValueAsMototyouType(MototyouType mototyouType, int value)
        {
            switch (mototyouType)
            {
                case MototyouType.EdabanMototyou:
                    this.EdabanMototyouOutputOrder = (EdabanMototyouOutputOrder)value;
                    break;
                case MototyouType.BumonMototyou:
                    this.BumonMototyouOutputOrder = (BumonMototyouOutputOrder)value;
                    break;
                case MototyouType.BumonKamokuEdabanMototyou:
                    this.BumonKamokuEdabanMototyouOutputOrder = (BumonKamokuEdabanMototyouOutputOrder)value;
                    break;
                case MototyouType.TorihikisakiMototyou:
                    this.TorihikisakiMototyouOutputOrder = (TorihikisakiMototyouOutputOrder)value;
                    break;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    this.BumonKamokuTorihikisakiMototyouOutputOrder = (BumonKamokuTorihikisakiMototyouOutputOrder)value;
                    break;
            }
        }

        public MototyouQueryOption CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as MototyouQueryOption;
        }
    }
}
