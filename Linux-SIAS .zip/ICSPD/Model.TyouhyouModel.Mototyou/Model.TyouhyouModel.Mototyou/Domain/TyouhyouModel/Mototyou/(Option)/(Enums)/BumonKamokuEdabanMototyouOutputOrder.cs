﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum BumonKamokuEdabanMototyouOutputOrder
    {
        BumonKamokuEdaban = 0,
        KamokuEdabanBumon = 1
    }
}
