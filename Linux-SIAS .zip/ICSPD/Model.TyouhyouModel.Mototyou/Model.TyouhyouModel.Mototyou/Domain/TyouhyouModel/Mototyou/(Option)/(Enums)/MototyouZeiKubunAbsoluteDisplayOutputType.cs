﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouZeiKubunAbsoluteDisplayOutputType
    {
        LatestZeirituNotOutput = 0,
        OutputAllZeiritu = 1
    }
}
