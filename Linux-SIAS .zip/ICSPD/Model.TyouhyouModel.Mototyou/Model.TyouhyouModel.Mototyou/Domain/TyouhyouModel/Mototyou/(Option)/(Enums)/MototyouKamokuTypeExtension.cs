﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    public static class MototyouKamokuTypeExtension
    {
        public static KamokuKubun GetKamokuKubun(this MototyouKamokuType mototyouKamokuType)
        {
            switch (mototyouKamokuType)
            {
                case MototyouKamokuType.MeisaiKamoku:
                    return KamokuKubun.Meisai;
                case MototyouKamokuType.SyouKamoku:
                    return KamokuKubun.Syou;
                case MototyouKamokuType.SyuukeiSyouKamoku:
                    return KamokuKubun.SyuukeiSyou;
                case MototyouKamokuType.KisokugaiSyuukeiKamoku:
                    return KamokuKubun.KisokugaiSyuukeiKamoku;
                default:
                    return KamokuKubun.Meisai;
            }
        }
    }
}
