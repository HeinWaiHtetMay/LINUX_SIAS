﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum BumonMototyouOutputOrder
    {
        BumonKamoku = 0,
        KamokuBumon = 1
    }
}
