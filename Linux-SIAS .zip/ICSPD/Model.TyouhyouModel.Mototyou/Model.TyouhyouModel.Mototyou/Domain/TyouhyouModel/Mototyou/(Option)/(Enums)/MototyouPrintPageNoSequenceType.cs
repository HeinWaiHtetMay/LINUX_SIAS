﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouPrintPageNoSequenceType
    {
        None = 0,
        PerKamoku = 1,
        ByAllKamoku = 2
    }
}
