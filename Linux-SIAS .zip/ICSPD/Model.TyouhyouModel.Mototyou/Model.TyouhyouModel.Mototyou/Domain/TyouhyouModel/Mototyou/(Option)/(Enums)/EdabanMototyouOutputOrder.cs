﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum EdabanMototyouOutputOrder
    {
        KamokuEdaban = 0,
        EdabanKamoku = 1
    }
}
