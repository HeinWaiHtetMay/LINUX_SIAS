﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    public static class MototyouBumonTypeExtension
    {
        public static BumonFindType GetBumonFindType(this MototyouBumonType mototyouBumonType)
        {
            return (BumonFindType)mototyouBumonType;
        }

        public static MasterType GetMasterType(this MototyouBumonType mototyouBumonType)
        {
            return mototyouBumonType == MototyouBumonType.Bumon
                ? MasterType.Bumon
                : MasterType.SyuukeiBumon;
        }
    }
}
