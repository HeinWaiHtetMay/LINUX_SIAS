﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouIkkatuZeinukiSiwakeSyuukeiType
    {
        None = 0,
        PerKamoku = 1,
        PerKamokuAndZeiritu = 2
    }
}
