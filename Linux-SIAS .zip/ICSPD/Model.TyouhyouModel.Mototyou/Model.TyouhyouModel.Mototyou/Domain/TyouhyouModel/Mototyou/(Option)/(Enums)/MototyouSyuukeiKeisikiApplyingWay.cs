﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 集計形式の適用方法
    /// </summary>
    public enum MototyouSyuukeiKeisikiApplyingWay
    {
        /// <summary>
        /// すべて適用する
        /// </summary>
        All = 0,

        /// <summary>
        /// 個別指定分に適用する
        /// </summary>
        KobetuSitei = 1,

        /// <summary>
        /// マスター設定に従う
        /// </summary>
        ReferenceMasterInfo = 2
    }
}
