﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public static class EdabanMototyouOutputOrderExtension
    {
        public static IReadOnlyList<MasterType> CreateMasterTypeList(this EdabanMototyouOutputOrder edabanMototyouOutputOrder)
        {
            switch (edabanMototyouOutputOrder)
            {
                case EdabanMototyouOutputOrder.KamokuEdaban:
                    return new MasterType[] { MasterType.Kamoku, MasterType.Edaban };
                case EdabanMototyouOutputOrder.EdabanKamoku:
                    return new MasterType[] { MasterType.Edaban, MasterType.Kamoku };
                default:
                    return null;
            }
        }
    }
}
