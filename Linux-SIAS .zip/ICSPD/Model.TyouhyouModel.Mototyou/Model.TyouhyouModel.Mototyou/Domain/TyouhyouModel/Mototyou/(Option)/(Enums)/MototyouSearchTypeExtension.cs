﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouSearchTypeExtension
    {
        public static string GetName(this MototyouSearchType mototyouSearchType)
        {
            switch (mototyouSearchType)
            {
                case MototyouSearchType.KoumokuSelection:
                    return "項目選択";
                case MototyouSearchType.SearchMaster:
                    return "50音検索";
                default:
                    return string.Empty;
            }
        }
    }
}
