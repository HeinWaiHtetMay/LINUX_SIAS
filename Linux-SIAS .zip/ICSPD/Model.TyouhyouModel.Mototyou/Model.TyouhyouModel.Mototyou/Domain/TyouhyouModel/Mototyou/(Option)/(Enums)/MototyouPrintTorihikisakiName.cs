﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouPrintTorihikisakiName
    {
        ShortName = 0,
        LongName = 1
    }
}
