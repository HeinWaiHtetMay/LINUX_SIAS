﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouBumonType
    {
        Bumon = 0,
        SyuukeiBumon = 1
    }
}
