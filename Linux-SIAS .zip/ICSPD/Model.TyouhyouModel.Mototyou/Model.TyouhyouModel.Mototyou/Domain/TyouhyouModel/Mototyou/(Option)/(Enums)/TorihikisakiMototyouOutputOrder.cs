﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum TorihikisakiMototyouOutputOrder
    {
        KamokuTorihikisaki = 0,
        TorihikisakiKamoku = 1
    }
}
