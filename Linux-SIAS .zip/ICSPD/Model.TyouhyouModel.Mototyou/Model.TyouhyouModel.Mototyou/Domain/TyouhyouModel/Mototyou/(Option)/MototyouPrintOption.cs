﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouPrintOption
    {
        /// <summary>
        /// 月ごとに改頁
        /// </summary>
        public bool PrintPagePerMonth { get; set; } = true;

        /// <summary>
        /// 両面印刷
        /// </summary>
        public bool IsBothSidesPrinting { get; set; } = false;

        /// <summary>
        /// カラー印刷
        /// </summary>
        public bool IsColorPrinting { get; set; } = false;

        public MototyouPrintOption CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as MototyouPrintOption;
        }
    }
}
