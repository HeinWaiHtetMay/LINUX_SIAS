﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public static class TorihikisakiMototyouOutputOrderExtension
    {
        public static IReadOnlyList<MasterType> CreateMasterTypeList(this TorihikisakiMototyouOutputOrder torihikisakiMototyouOutputOrder)
        {
            switch (torihikisakiMototyouOutputOrder)
            {
                case TorihikisakiMototyouOutputOrder.KamokuTorihikisaki:
                    return new MasterType[] { MasterType.Kamoku, MasterType.Torihikisaki };
                case TorihikisakiMototyouOutputOrder.TorihikisakiKamoku:
                    return new MasterType[] { MasterType.Torihikisaki, MasterType.Kamoku };
                default:
                    return null;
            }
        }
    }
}
