﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouKazeiKubunOutputType
    {
        /// <summary>
        /// 絶対表示
        /// </summary>
        Absolute = 1,

        /// <summary>
        /// 相対表示（タイトルと比較）
        /// </summary>
        RelativeWithComparingTitle = 2,

        /// <summary>
        /// 相対表示（マスターと比較）
        /// </summary>
        RelativeWithComparingMaster = 3
    }
}
