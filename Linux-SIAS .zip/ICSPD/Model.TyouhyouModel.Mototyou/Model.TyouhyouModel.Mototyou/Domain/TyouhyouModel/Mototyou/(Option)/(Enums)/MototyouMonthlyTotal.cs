﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouMonthlyTotal
    {
        None = 0,
        Exists = 1,
    }
}
