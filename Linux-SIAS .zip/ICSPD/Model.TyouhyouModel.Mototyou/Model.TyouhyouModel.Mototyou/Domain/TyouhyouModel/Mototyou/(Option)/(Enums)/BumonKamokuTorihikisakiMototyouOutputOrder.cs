﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum BumonKamokuTorihikisakiMototyouOutputOrder
    {
        BumonKamokuTorihikisaki = 0,
        KamokuTorihikisakiBumon = 1,
        TorihikisakiKamokuBumon = 2
    }
}
