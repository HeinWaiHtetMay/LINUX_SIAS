﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.MasterModel;

    public static class BumonKamokuTorihikisakiMototyouOutputOrderExtension
    {
        public static IReadOnlyList<MasterType> CreateMasterTypeList(this BumonKamokuTorihikisakiMototyouOutputOrder bumonKamokuTorihikisakiMototyouOutputOrder)
        {
            switch (bumonKamokuTorihikisakiMototyouOutputOrder)
            {
                case BumonKamokuTorihikisakiMototyouOutputOrder.BumonKamokuTorihikisaki:
                    return new MasterType[] { MasterType.Bumon, MasterType.Kamoku, MasterType.Torihikisaki };
                case BumonKamokuTorihikisakiMototyouOutputOrder.KamokuTorihikisakiBumon:
                    return new MasterType[] { MasterType.Kamoku, MasterType.Torihikisaki, MasterType.Bumon };
                case BumonKamokuTorihikisakiMototyouOutputOrder.TorihikisakiKamokuBumon:
                    return new MasterType[] { MasterType.Torihikisaki, MasterType.Kamoku, MasterType.Bumon };
                default:
                    return null;
            }
        }
    }
}
