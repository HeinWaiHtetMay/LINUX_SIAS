﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    [Flags]
    public enum MototyouItemUseKobetuSetting
    {
        SyuukeiKeisiki = 1,
        Page = 1 << 1,
    }
}
