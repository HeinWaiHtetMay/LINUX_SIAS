﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class KamokuMototyouZibunItem : AbstractMototyouZibunItem, IKamokuInnerCodeAndName
    {
        public KamokuMototyouZibunItem(IMototyouZibunItemCollection parent, IMototyouKamoku kamoku, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Kamoku = kamoku;
        }

        public KamokuMototyouZibunItem(MototyouCompareKamoku kamoku)
            : this(null, kamoku, default(KamokuTaisyakuZokusei), null, null, null, null)
        {
        }

        public IMototyouKamoku Kamoku { get; }

        int IKamokuInnerCode.Kesn => this.Kamoku.Kesn;

        string IKamokuInnerCode.Kicd => this.Kamoku.Kicd;

        string IKamokuInnerCodeAndName.KamokuShortName
        {
            get { return this.Kamoku.KamokuShortName; }
            set { this.Kamoku.KamokuShortName = value; }
        }

        string IKamokuInnerCodeAndName.KamokuLongName
        {
            get { return this.Kamoku.KamokuLongName; }
            set { this.Kamoku.KamokuLongName = value; }
        }
    }
}
