﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class TorihikisakiMototyouZibunItem : KamokuMototyouZibunItem, ITorihikisakiCodeAndName
    {
        public TorihikisakiMototyouZibunItem(IMototyouZibunItemCollection parent, IMototyouKamoku kamoku, Torihikisaki torihikisaki, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Trcd = torihikisaki.Trcd;
            this.TorihikisakiShortName = torihikisaki.ShortName;
            this.TorihikisakiLongName = torihikisaki.LongName;
        }

        public TorihikisakiMototyouZibunItem(IMototyouZibunItemCollection parent, IMototyouKamoku kamoku, ITorihikisakiCodeAndName torihikisaki, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Trcd = torihikisaki.Trcd;
            this.TorihikisakiShortName = torihikisaki.TorihikisakiShortName;
            this.TorihikisakiLongName = torihikisaki.TorihikisakiLongName;
        }

        public TorihikisakiMototyouZibunItem(MototyouCompareKamoku kamoku, Torihikisaki torihikisaki)
            : this(null, kamoku, torihikisaki, default(KamokuTaisyakuZokusei), null, null, null, null)
        {
        }

        public string Trcd { get; set; }

        public string TorihikisakiShortName { get; set; }

        public string TorihikisakiLongName { get; set; }
    }
}
