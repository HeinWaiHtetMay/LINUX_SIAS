﻿using Icsp.Open21.Domain.MasterModel;
using Icsp.Open21.Domain.SyouhizeiModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouZibunItem
    {
        /// <summary>
        /// 貸借属性
        /// </summary>
        KamokuTaisyakuZokusei TaisyakuZokusei { get; }

        /// <summary>
        /// 使用する個別設定の組み合わせ
        /// </summary>
        MototyouItemUseKobetuSetting UseKobetuSetting { get; }

        /// <summary>
        /// 集計形式
        /// </summary>
        MototyouSyuukeiKeisiki SyuukeiKeisiki { get; }

        /// <summary>
        /// 開始ページ番号
        /// </summary>
        int? StartPage { get; set; }

        /// <summary>
        /// 終了ページ番号
        /// </summary>
        int? EndPage { get; set; }

        /// <summary>
        /// 税区分
        /// </summary>
        MototyouZeiKubun ZeiKubun { get; }

        /// <summary>
        /// マスター項目が同じかどうか
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        bool IsEqualMasterItem(IMototyouZibunItem item);

        /// <summary>
        /// 指定マスター種類の「マスター種類名：マスターデータ名称」の文字列を取得する
        /// </summary>
        /// <param name="masterType"></param>
        /// <returns></returns>
        string GetTypeNameAndMasterName(MasterType masterType);

        /// <summary>
        /// 指定マスター種類のマスターデータ名称を取得する
        /// </summary>
        /// <param name="masterType"></param>
        /// <returns></returns>
        string GetMasterName(MasterType masterType);
    }
}
