﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class EdabanMototyouZibunItem : KamokuMototyouZibunItem, IKamokuEdabanAndName
    {
        public EdabanMototyouZibunItem(IMototyouZibunItemCollection parent, IMototyouKamoku kamoku, Edaban edaban, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Ecod = edaban.Ecod;
            this.Enam = edaban.Enam;
        }

        public EdabanMototyouZibunItem(IMototyouZibunItemCollection parent, IMototyouKamoku kamoku, IKamokuEdabanAndName edaban, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Ecod = edaban.Ecod;
            this.Enam = edaban.Enam;
        }

        public EdabanMototyouZibunItem(MototyouCompareKamoku kamoku, Edaban edaban)
            : this(null, kamoku, edaban, default(KamokuTaisyakuZokusei), null, null, null, null)
        {
        }

        public string Ecod { get; set; }

        public string Enam { get; set; }
    }
}
