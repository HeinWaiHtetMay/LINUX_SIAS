﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouZibunItemRepository
    {
        /// <summary>
        /// 問い合わせ条件から元帳の自分項目のコレクションを作成して返します
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        IMototyouDisplayZibunItemCollection FindByMototyouQueryParameter(MototyouQueryParameter queryParameter);

        /// <summary>
        /// 問合せ条件から出力条件を考慮して、元帳の自分項目のコレクションを作成して返します
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        IMototyouDisplayZibunItemCollection FindByMototyouQueryParameterAsOutputCondition(MototyouQueryParameter queryParameter);
    }
}