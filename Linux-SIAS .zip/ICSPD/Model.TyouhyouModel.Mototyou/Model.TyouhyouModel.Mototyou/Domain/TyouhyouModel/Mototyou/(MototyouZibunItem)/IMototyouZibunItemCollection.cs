﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;

    public interface IMototyouZibunItemCollection : IList<IMototyouZibunItem>
    {
        /// <summary>
        /// コレクション内の各項目が所持する設定の組み合わせ
        /// </summary>
        MototyouItemUseKobetuSetting UseKobetuSetting { get; }

        /// <summary>
        /// コレクション全体の集計形式
        /// </summary>
        MototyouSyuukeiKeisiki SyuukeiKeisiki { get; }
    }
}