﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class BumonMototyouZibunItem : KamokuMototyouZibunItem, IBumonCodeAndName
    {
        public BumonMototyouZibunItem(IMototyouZibunItemCollection parent, Bumon bumon, IMototyouKamoku kamoku, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Bcod = bumon.Bcod;
            this.Bnam = bumon.Bnam;
        }

        public BumonMototyouZibunItem(IMototyouZibunItemCollection parent, IBumonCodeAndName bumon, IMototyouKamoku kamoku, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Bcod = bumon.Bcod;
            this.Bnam = bumon.Bnam;
        }

        public BumonMototyouZibunItem(Bumon bumon, MototyouCompareKamoku kamoku)
            : this(null, bumon, kamoku, default(KamokuTaisyakuZokusei), null, null, null, null)
        {
        }

        public string Bcod { get; set; }

        public string Bnam { get; set; }

        public BumonMototyouZibunItem CloneAsShallowCopy()
        {
            return this.MemberwiseClone() as BumonMototyouZibunItem;
        }
    }
}
