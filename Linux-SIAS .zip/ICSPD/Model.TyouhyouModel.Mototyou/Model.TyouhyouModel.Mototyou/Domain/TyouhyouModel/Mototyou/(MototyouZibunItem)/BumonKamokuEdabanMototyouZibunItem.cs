﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public class BumonKamokuEdabanMototyouZibunItem : BumonMototyouZibunItem, IKamokuEdabanAndName
    {
        public BumonKamokuEdabanMototyouZibunItem(IMototyouZibunItemCollection parent, Bumon bumon, IMototyouKamoku kamoku, Edaban edaban, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, bumon, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Ecod = edaban.Ecod;
            this.Enam = edaban.Enam;
        }

        public BumonKamokuEdabanMototyouZibunItem(IMototyouZibunItemCollection parent, IBumonCodeAndName bumon, IMototyouKamoku kamoku, Edaban edaban, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, bumon, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Ecod = edaban.Ecod;
            this.Enam = edaban.Enam;
        }

        public BumonKamokuEdabanMototyouZibunItem(IMototyouZibunItemCollection parent, IBumonCodeAndName bumon, IMototyouKamoku kamoku, IKamokuEdabanAndName edaban, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
            : base(parent, bumon, kamoku, taisyakuZokusei, zeiKubun, syuukeiKeisiki, startPage, endPage)
        {
            this.Ecod = edaban.Ecod;
            this.Enam = edaban.Enam;
        }

        public BumonKamokuEdabanMototyouZibunItem(Bumon bumon, MototyouCompareKamoku kamoku, Edaban edaban)
            : this(null, bumon, kamoku, edaban, default(KamokuTaisyakuZokusei), null, null, null, null)
        {
        }

        public string Ecod { get; set; }

        public string Enam { get; set; }
    }
}
