﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections;
    using System.Collections.Generic;
    using Icsp.Framework.Core.Collections;

    /// <summary>
    /// 元帳項目コレクション
    /// </summary>
    public class MototyouZibunItemCollection : List<IMototyouZibunItem>, IMototyouZibunItemCollection
    {
        public MototyouZibunItemCollection(MototyouItemUseKobetuSetting useKobetuSetting, MototyouSyuukeiKeisiki syuukeiKeisiki)
        {
            this.UseKobetuSetting = useKobetuSetting;
            this.SyuukeiKeisiki = syuukeiKeisiki;
        }

        public MototyouZibunItemCollection(IEnumerable<IMototyouZibunItemCollection> collections)
        {
            collections.ForEachIfNotNull(collection => this.AddRangeIfNotNull(collection));
        }

        public MototyouItemUseKobetuSetting UseKobetuSetting { get; private set; }

        public MototyouSyuukeiKeisiki SyuukeiKeisiki { get; private set; }
    }
}
