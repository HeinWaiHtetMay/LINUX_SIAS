﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    public abstract class AbstractMototyouZibunItem : IMototyouZibunItem
    {
        /// <summary>
        /// このインスタンスが含まれるコレクション
        /// </summary>
        private IMototyouZibunItemCollection itemCollection;

        private MototyouSyuukeiKeisiki? syuukeiKeisiki;

        public AbstractMototyouZibunItem(IMototyouZibunItemCollection parent, KamokuTaisyakuZokusei taisyakuZokusei, MototyouZeiKubun zeiKubun, MototyouSyuukeiKeisiki? syuukeiKeisiki, int? startPage, int? endPage)
        {
            this.itemCollection = parent;
            this.TaisyakuZokusei = taisyakuZokusei;
            this.ZeiKubun = zeiKubun;
            this.syuukeiKeisiki = syuukeiKeisiki;
            this.StartPage = startPage;
            this.EndPage = endPage;
        }

        public KamokuTaisyakuZokusei TaisyakuZokusei { get; }

        public MototyouItemUseKobetuSetting UseKobetuSetting => this.itemCollection.UseKobetuSetting;

        /// <summary>
        /// 集計形式
        /// 個別で設定しない場合コレクションから取得する
        /// </summary>
        public MototyouSyuukeiKeisiki SyuukeiKeisiki
        {
            get
            {
                return this.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki)
                    ? this.syuukeiKeisiki.Value
                    : this.itemCollection.SyuukeiKeisiki;
            }
        }

        public int? StartPage { get; set; }

        public int? EndPage { get; set; }

        public MototyouZeiKubun ZeiKubun { get; }

        public bool IsEqualMasterItem(IMototyouZibunItem item)
        {
            if (item == null)
            {
                return false;
            }

            return (this is IKamokuInnerCodeAndName kamoku ? kamoku.Kicd == ((IKamokuInnerCodeAndName)item).Kicd : true)
                && (this is IKamokuEdabanAndName edaban ? edaban.Ecod == ((IKamokuEdabanAndName)item).Ecod : true)
                && (this is IBumonCodeAndName bumon ? bumon.Bcod == ((IBumonCodeAndName)item).Bcod : true)
                && (this is ITorihikisakiCodeAndName torihikisaki ? torihikisaki.Trcd == ((ITorihikisakiCodeAndName)item).Trcd : true);
        }

        public string GetMasterCode(MasterType masterType)
        {
            switch (masterType)
            {
                case MasterType.Kamoku:
                    return this is IKamokuInnerCodeAndName kamoku ? kamoku.Kicd : string.Empty;
                case MasterType.Bumon:
                    return this is IBumonCodeAndName bumon ? bumon.Bcod : string.Empty;
                case MasterType.Torihikisaki:
                    return this is ITorihikisakiCodeAndName torihikisaki ? torihikisaki.Trcd : string.Empty;
                case MasterType.Edaban:
                    return this is IKamokuEdabanAndName edaban ? edaban.Ecod : string.Empty;
                default:
                    return string.Empty;
            }
        }

        public string GetTypeNameAndMasterName(MasterType masterType)
        {
            return masterType.GetName() + "：" + this.GetMasterName(masterType);
        }

        public string GetMasterName(MasterType masterType)
        {
            switch (masterType)
            {
                case MasterType.Kamoku:
                    return this is IKamokuInnerCodeAndName kamoku ? kamoku.KamokuLongName : string.Empty;
                case MasterType.Bumon:
                    return this is IBumonCodeAndName bumon ? bumon.Bnam : string.Empty;
                case MasterType.Torihikisaki:
                    return this is ITorihikisakiCodeAndName torihikisaki ? torihikisaki.TorihikisakiShortName : string.Empty;
                case MasterType.Edaban:
                    return this is IKamokuEdabanAndName edaban ? edaban.Enam : string.Empty;
                default:
                    return string.Empty;
            }
        }
    }
}
