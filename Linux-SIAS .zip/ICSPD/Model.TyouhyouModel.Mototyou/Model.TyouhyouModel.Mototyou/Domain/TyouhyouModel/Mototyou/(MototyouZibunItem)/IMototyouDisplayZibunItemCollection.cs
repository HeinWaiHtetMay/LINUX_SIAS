﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouDisplayZibunItemCollection : IMototyouZibunItemCollection
    {
        /// <summary>
        /// 選択中の元帳自分項目
        /// </summary>
        /// <returns></returns>
        IMototyouZibunItem GetCurrentItem();

        /// <summary>
        /// 先頭項目かどうか
        /// </summary>
        /// <returns></returns>
        bool IsFirst();

        /// <summary>
        /// 末尾項目かどうか
        /// </summary>
        /// <returns></returns>
        bool IsLast();

        /// <summary>
        /// 先頭項目へ移動する
        /// </summary>
        /// <returns></returns>
        bool MoveToFirst();

        /// <summary>
        /// 末尾項目へ移動する
        /// </summary>
        /// <returns></returns>
        bool MoveToLast();

        /// <summary>
        /// 次の項目へ移動する
        /// </summary>
        /// <returns></returns>
        bool MoveToNext();

        /// <summary>
        /// 前の項目へ移動する
        /// </summary>
        /// <returns></returns>
        bool MoveToPrevious();

        /// <summary>
        /// 選択項目へ移動する
        /// </summary>
        /// <param name="selectIndex"></param>
        void MoveToSelectItem(int selectIndex);

        /// <summary>
        /// 検索項目のインデックスを取得する
        /// 存在しなければ-1を返す
        /// </summary>
        /// <param name="searchItem"></param>
        /// <returns></returns>
        int GetSearchItemIndex(IMototyouZibunItem searchItem);
    }
}