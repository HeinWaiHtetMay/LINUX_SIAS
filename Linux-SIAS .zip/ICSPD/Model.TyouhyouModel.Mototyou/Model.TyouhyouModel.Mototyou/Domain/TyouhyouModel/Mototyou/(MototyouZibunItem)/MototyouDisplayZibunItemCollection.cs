﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Framework.Core.Collections;

    /// <summary>
    /// 元帳の表示用自分項目コレクション
    /// </summary>
    public class MototyouDisplayZibunItemCollection : MototyouZibunItemCollection, IMototyouDisplayZibunItemCollection
    {
        private int currentIndex = 0;

        public MototyouDisplayZibunItemCollection(MototyouItemUseKobetuSetting useSetting, MototyouSyuukeiKeisiki syuukeiKeisiki)
            : base(useSetting, syuukeiKeisiki)
        {
        }

        public MototyouDisplayZibunItemCollection(IEnumerable<IMototyouZibunItemCollection> collections)
            : base(collections)
        {
        }

        public IMototyouZibunItem GetCurrentItem()
        {
            return this[this.currentIndex];
        }

        public bool MoveToFirst()
        {
            if (this.IsFirst())
            {
                return false;
            }

            this.currentIndex = 0;
            return true;
        }

        public bool MoveToPrevious()
        {
            if (this.IsFirst())
            {
                return false;
            }

            this.currentIndex--;
            return true;
        }

        public bool MoveToNext()
        {
            if (this.IsLast())
            {
                return false;
            }

            this.currentIndex++;
            return true;
        }

        public bool MoveToLast()
        {
            if (this.IsLast())
            {
                return false;
            }

            this.currentIndex = this.Count - 1;
            return true;
        }

        public void MoveToSelectItem(int selectIndex)
        {
            this.currentIndex = selectIndex >= 0 ? selectIndex : 0;
        }

        public int GetSearchItemIndex(IMototyouZibunItem searchItem)
        {
            return this.IndexOf(this.FirstOrDefault(item => item.IsEqualMasterItem(searchItem)));
        }

        public bool IsFirst()
        {
            return this.Count == 0 || this.currentIndex == 0;
        }

        public bool IsLast()
        {
            return this.Count == 0 || this.currentIndex == this.Count - 1;
        }
    }
}
