﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouCellItem
    {
        public MototyouCellItem(string itemText, MototyouLayoutItemCharWidth charWidth, MototyouLayoutKintouWaritukeType kintouWaritukeType)
        {
            this.ItemText = itemText;
            this.CharWidth = charWidth;
            this.KintouWaritukeType = kintouWaritukeType;
        }

        /// <summary>
        /// 表示テキスト
        /// </summary>
        public string ItemText { get; private set; }

        /// <summary>
        /// 文字幅
        /// </summary>
        public MototyouLayoutItemCharWidth CharWidth { get; private set; }

        /// <summary>
        /// 均等割付
        /// </summary>
        public MototyouLayoutKintouWaritukeType KintouWaritukeType { get; private set; }
    }
}
