﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Icsp.Open21.Domain.DateTimeModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouSonekiHurikaeRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        private IMototyouZibunItem zibunItem;
        private bool isSonekiKanzyouMototyou = false;

        public MototyouSonekiHurikaeRow(Mototyou parent, IMototyouZibunItem zibunItem, bool isSonekiKanzyouMototyou)
            : base(parent)
        {
            this.zibunItem = zibunItem;
            this.isSonekiKanzyouMototyou = isSonekiKanzyouMototyou;
        }

        public override string ProgramTekiyouString
        {
            get
            {
                if (this.isSonekiKanzyouMototyou)
                {
                    return Properties.Resources.繰越利益剰余金へ振替;
                }

                var zibunKicd = ((KamokuMototyouZibunItem)this.zibunItem).Kamoku.Kicd;
                if ((zibunKicd.CompareTo("100000000000000") >= 0 && zibunKicd.CompareTo("160029999999999") <= 0)
                    || zibunKicd.StartsWith("210"))
                {
                    //// 内部コードが100000000000000～160029999999999、または210…のとき
                    return Properties.Resources.損益勘定へ振替;
                }
                else
                {
                    return Properties.Resources.繰越利益剰余金へ振替;
                }
            }
        }

        public override MototyouRowType RowType => MototyouRowType.SonekiHurikaeRow;

        public override IcspDateTime Date => this.DisplayDate;

        public IcspDateTime DisplayDate { get; set; } = null;
    }
}
