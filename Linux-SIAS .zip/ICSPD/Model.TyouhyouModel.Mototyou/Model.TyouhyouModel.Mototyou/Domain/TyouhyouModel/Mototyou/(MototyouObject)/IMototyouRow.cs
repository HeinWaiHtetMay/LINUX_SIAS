﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 元帳行インターフェース
    /// </summary>
    public interface IMototyouRow
    {
        /// <summary>
        /// 元帳
        /// </summary>
        Mototyou Parent { get; }

        /// <summary>
        /// 前の行
        /// </summary>
        IMototyouRow PreviousRow { get; set; }

        /// <summary>
        /// 次の行
        /// </summary>
        IMototyouRow NextRow { get; set; }

        /// <summary>
        /// 行タイプ
        /// </summary>
        MototyouRowType RowType { get; }

        /// <summary>
        /// 日付
        /// </summary>
        IcspDateTime Date { get; }

        /// <summary>
        /// 部署別伝票かどうか
        /// </summary>
        bool IsBusyobetuDenpyou { get; }

        /// <summary>
        /// 伝票のDKEI
        /// </summary>
        int DenpyouDkei { get; }

        /// <summary>
        /// 伝票SEQ
        /// </summary>
        int DenpyouSeq { get; }

        /// <summary>
        /// 伝票NO
        /// </summary>
        int? DenpyouNo { get; }

        /// <summary>
        /// 伝票受付番号
        /// </summary>
        int? DenpyouUketukeNo { get; }

        /// <summary>
        /// 仕訳SEQ
        /// </summary>
        int SiwakeSeq { get; }

        /// <summary>
        /// 借方金額
        /// </summary>
        decimal? KarikataValue { get; }

        /// <summary>
        /// 貸方金額
        /// </summary>
        decimal? KasikataValue { get; }

        /// <summary>
        /// 差引残高
        /// </summary>
        decimal? SasihikiZandaka { get; }

        /// <summary>
        /// 整理月かどうか
        /// </summary>
        bool IsSeirituki { get; }

        /// <summary>
        /// 月の文字列取得
        /// </summary>
        /// <param name="outputSeirituki"></param>
        /// <returns></returns>
        string GetMonthString(MototyouOutputSeirituki outputSeirituki);

        /// <summary>
        /// 指定セル文字列取得
        /// </summary>
        /// <param name="colNo"></param>
        /// <returns></returns>
        string GetMototyouCellString(int colNo);

        /// <summary>
        /// 指定セル項目取得
        /// </summary>
        /// <param name="layoutItem"></param>
        /// <returns></returns>
        MototyouCellItem GetMototyouCellItem(MototyouLayoutItem layoutItem);

        /// <summary>
        /// 指定セル項目取得
        /// </summary>
        /// <param name="colNo"></param>
        /// <param name="gyoNo"></param>
        /// <returns></returns>
        MototyouCellItem GetMototyouCellItem(int colNo, int gyoNo);

        /// <summary>
        /// 指定セル項目文字列取得
        /// </summary>
        /// <param name="layoutItem"></param>
        /// <returns></returns>
        string GetMototyouCellItemString(MototyouLayoutItem layoutItem);

        /// <summary>
        /// 指定セル項目文字列取得
        /// </summary>
        /// <param name="colNo"></param>
        /// <param name="gyoNo"></param>
        /// <returns></returns>
        string GetMototyouCellItemString(int colNo, int gyoNo);
    }
}
