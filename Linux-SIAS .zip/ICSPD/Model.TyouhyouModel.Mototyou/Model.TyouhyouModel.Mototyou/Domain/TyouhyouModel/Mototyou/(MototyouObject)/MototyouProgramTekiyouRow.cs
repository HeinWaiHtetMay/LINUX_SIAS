﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Icsp.Open21.Domain.DateTimeModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 仕訳データではなく、プログラムで設定する摘要を表示する行の抽象クラス
    /// </summary>
    public abstract class MototyouProgramTekiyouRow : AbstractMototyouRow
    {
        public MototyouProgramTekiyouRow(Mototyou parent)
            : base(parent)
        {
        }

        public abstract string ProgramTekiyouString { get; }

        public override MototyouCellItem GetMototyouCellItem(int colNo, int gyoNo)
        {
            return null;
        }

        public override string GetMototyouCellItemString(int colNo, int gyoNo)
        {
            if (this.Parent.LayoutProgramTekiyouItem == null)
            {
                return string.Empty;
            }

            return this.Parent.LayoutProgramTekiyouItem.ColumnNo == colNo && this.Parent.LayoutProgramTekiyouItem.RowNo == gyoNo
                ? this.ProgramTekiyouString : string.Empty;
        }

        public override string GetMototyouCellString(int colNo)
        {
            if (this.Parent.LayoutProgramTekiyouItem == null)
            {
                return string.Empty;
            }

            return this.Parent.LayoutProgramTekiyouItem.ColumnNo == colNo ? this.ProgramTekiyouString : string.Empty;
        }
    }
}
