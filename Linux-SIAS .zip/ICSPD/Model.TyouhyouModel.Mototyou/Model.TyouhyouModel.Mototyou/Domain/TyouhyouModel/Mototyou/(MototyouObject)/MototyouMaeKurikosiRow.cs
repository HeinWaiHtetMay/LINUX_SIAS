﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Icsp.Open21.Domain.DateTimeModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public class MototyouMaeKurikosiRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        private string sokyuuTekiyouText = string.Empty;

        public MototyouMaeKurikosiRow(Mototyou parent, MaeKurikosiRowType maezanRowType)
            : base(parent)
        {
            this.MaezanRowType = maezanRowType;
        }

        public MototyouMaeKurikosiRow(Mototyou parent, MaeKurikosiRowType maezanRowType, string sokyuuTekiyouText)
            : base(parent)
        {
            this.MaezanRowType = maezanRowType;
            this.sokyuuTekiyouText = sokyuuTekiyouText;
        }

        public enum MaeKurikosiRowType
        {
            /// <summary>
            /// 前日繰越
            /// </summary>
            Zenzitu,

            /// <summary>
            /// 前期繰越
            /// </summary>
            Zenki,

            /// <summary>
            /// 上期繰越
            /// </summary>
            Kamiki,

            /// <summary>
            /// 前月繰越
            /// </summary>
            Zengetu,

            /// <summary>
            /// 遡及摘要
            /// </summary>
            SokyuuTekiyou,

            /// <summary>
            /// 前期繰越差額
            /// </summary>
            ZenkiKurikosiSagaku,
        }

        public MaeKurikosiRowType MaezanRowType { get; private set; }

        public override string ProgramTekiyouString
        {
            get
            {
                switch (this.MaezanRowType)
                {
                    case MaeKurikosiRowType.Zenzitu:
                        return Properties.Resources.前日繰越;
                    case MaeKurikosiRowType.Zenki:
                        return Properties.Resources.前期繰越;
                    case MaeKurikosiRowType.Kamiki:
                        return Properties.Resources.上期繰越;
                    case MaeKurikosiRowType.Zengetu:
                        return Properties.Resources.前月繰越;
                    case MaeKurikosiRowType.SokyuuTekiyou:
                    case MaeKurikosiRowType.ZenkiKurikosiSagaku:
                        return this.sokyuuTekiyouText;
                    default:
                        return string.Empty;
                }
            }
        }

        public override MototyouRowType RowType { get; } = MototyouRowType.MaeKurikosiRow;

        /// <summary>
        /// 開始日付
        /// </summary>
        public override IcspDateTime Date => this.StartDate;

        public IcspDateTime StartDate { get; set; }

        //// 前〇繰越はIMototyouRowとして見た時に貸借金額を持たない
        //// ただし累計や翌〇繰越計算用に値は持つ

        decimal? IMototyouRow.KarikataValue => this.MaezanRowType == MaeKurikosiRowType.ZenkiKurikosiSagaku
            ? this.Parent.ZibunItem.TaisyakuZokusei == MasterModel.KamokuTaisyakuZokusei.Karikata ? this.ZenkiKurikosiSagaku : null
            : null;

        decimal? IMototyouRow.KasikataValue => this.MaezanRowType == MaeKurikosiRowType.ZenkiKurikosiSagaku
            ? this.Parent.ZibunItem.TaisyakuZokusei == MasterModel.KamokuTaisyakuZokusei.Kasikata ? this.ZenkiKurikosiSagaku : null
            : null;

        /// <summary>
        /// 借方に表示する前期繰越との差額（あくまで表示用で計算には含めない）
        /// </summary>
        public decimal? ZenkiKurikosiSagaku { get; set; }
    }
}
