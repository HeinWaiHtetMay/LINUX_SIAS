﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.DateTimeModel;

    public class MototyouRuikeiRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        public MototyouRuikeiRow(Mototyou parent)
            : base(parent)
        {
        }

        public override string ProgramTekiyouString => Properties.Resources.累計;

        public override MototyouRowType RowType { get; } = MototyouRowType.RuikeiRow;

        public override IcspDateTime Date => null;
    }
}
