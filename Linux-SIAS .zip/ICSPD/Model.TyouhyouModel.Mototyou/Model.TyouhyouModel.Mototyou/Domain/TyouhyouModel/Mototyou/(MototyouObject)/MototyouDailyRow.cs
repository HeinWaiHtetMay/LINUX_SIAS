﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 元帳日別集計行
    /// </summary>
    public class MototyouDailyRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        public MototyouDailyRow(Mototyou parent, IcspDateTime date)
            : base(parent)
        {
            this.Date = date;
        }

        public override MototyouRowType RowType { get; } = MototyouRowType.DailyRow;

        public override IcspDateTime Date { get; }

        public override string ProgramTekiyouString => string.Empty;
    }
}
