﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.DateTimeModel;

    public class MototyouYokuKurikosiRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        private bool isSonekiKamoku = false;

        public MototyouYokuKurikosiRow(Mototyou parent, YokuKurikosiType yokuzanType, bool isSonekiKamoku)
            : base(parent)
        {
            this.YokuzanType = yokuzanType;
            this.isSonekiKamoku = isSonekiKamoku;
        }

        public enum YokuKurikosiType
        {
            /// <summary>
            /// 翌日繰越
            /// </summary>
            Yokuzitu,

            /// <summary>
            /// 翌期繰越
            /// </summary>
            Yokuki,

            /// <summary>
            /// 下期繰越
            /// </summary>
            Simoki,

            /// <summary>
            /// 翌月繰越
            /// </summary>
            Yokugetu,
        }

        public YokuKurikosiType YokuzanType { get; private set; }

        public override string ProgramTekiyouString
        {
            get
            {
                switch (this.YokuzanType)
                {
                    case YokuKurikosiType.Yokuzitu:
                        return Properties.Resources.翌日繰越;
                    case YokuKurikosiType.Yokuki:
                        return this.isSonekiKamoku ? "＊＊＊" : Properties.Resources.翌期繰越;
                    case YokuKurikosiType.Simoki:
                        return this.isSonekiKamoku ? "＊＊＊" : Properties.Resources.下期繰越;
                    case YokuKurikosiType.Yokugetu:
                    default:
                        return Properties.Resources.翌月繰越;
                }
            }
        }

        public override MototyouRowType RowType { get; } = MototyouRowType.YokuKurikosiRow;

        /// <summary>
        /// 日付（表示しない）
        /// </summary>
        public override IcspDateTime Date => null;
    }
}
