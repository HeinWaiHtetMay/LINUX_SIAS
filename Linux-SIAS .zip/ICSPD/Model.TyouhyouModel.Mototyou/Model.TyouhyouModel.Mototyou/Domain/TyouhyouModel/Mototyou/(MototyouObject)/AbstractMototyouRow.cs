﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Core.Numeric;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    public abstract class AbstractMototyouRow
    {
        public AbstractMototyouRow(Mototyou parent)
        {
            this.Parent = parent;
        }

        public Mototyou Parent { get; }

        public IMototyouRow PreviousRow { get; set; }

        public IMototyouRow NextRow { get; set; }

        public abstract MototyouRowType RowType { get; }

        public abstract IcspDateTime Date { get; }

        public virtual bool IsBusyobetuDenpyou { get; set; }

        public virtual int DenpyouDkei { get; set; }

        public virtual int DenpyouSeq { get; set; }

        public virtual int? DenpyouNo { get; set; }

        public virtual int? DenpyouUketukeNo { get; set; }

        public virtual int SiwakeSeq { get; set; }

        public decimal? KarikataValue { get; set; }

        public decimal? KasikataValue { get; set; }

        public decimal? SasihikiZandaka { get; set; }

        public bool IsSeirituki { get; set; }

        public decimal GetSasihikiValue()
        {
            return this.Parent.ZibunItem.TaisyakuZokusei == KamokuTaisyakuZokusei.Karikata
                ? this.KarikataValue.GetValueOrDefault() - this.KasikataValue.GetValueOrDefault()
                : this.KasikataValue.GetValueOrDefault() - this.KarikataValue.GetValueOrDefault();
        }

        public MototyouCellItem GetMototyouCellItem(MototyouLayoutItem layoutItem)
        {
            if (layoutItem == null)
            {
                return null;
            }

            return this.GetMototyouCellItem(layoutItem.ColumnNo, layoutItem.RowNo);
        }

        public abstract MototyouCellItem GetMototyouCellItem(int colNo, int gyoNo);

        public string GetMototyouCellItemString(MototyouLayoutItem layoutItem)
        {
            if (layoutItem == null)
            {
                return string.Empty;
            }

            return this.GetMototyouCellItemString(layoutItem.ColumnNo, layoutItem.RowNo);
        }

        public abstract string GetMototyouCellItemString(int colNo, int gyoNo);

        public abstract string GetMototyouCellString(int colNo);

        public string GetMonthString(MototyouOutputSeirituki outputSeirituki)
        {
            return outputSeirituki == MototyouOutputSeirituki.CircleEnclosing && this.IsSeirituki
                ? this.Date?.Month.ToCircleEnclosingString()
                : this.Date?.Month.ToString();
        }
    }
}
