﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 元帳月別集計行
    /// </summary>
    public class MototyouMonthlyRow : MototyouProgramTekiyouRow, IMototyouRow
    {
        public MototyouMonthlyRow(Mototyou parent, Syorituki syorituki)
            : base(parent)
        {
            this.Syorituki = syorituki;
            this.ProgramTekiyouString = string.Format(
                "　　　{0}{1}",
                syorituki.GetShortGatudoLabel(),
                syorituki.IsSeirituki ? Properties.Resources.月計 : Properties.Resources.度計);
        }

        public Syorituki Syorituki { get; }

        public override MototyouRowType RowType { get; } = MototyouRowType.MonthlyRow;

        public override IcspDateTime Date => null;

        public override string ProgramTekiyouString { get; }
    }
}
