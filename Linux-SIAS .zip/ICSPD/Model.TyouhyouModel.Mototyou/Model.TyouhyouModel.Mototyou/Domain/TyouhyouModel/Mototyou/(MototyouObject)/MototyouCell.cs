﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Linq;

    public class MototyouCell
    {
        private MototyouCellItem[] cellItems;

        public MototyouCell(int gyoCount)
        {
            this.cellItems = new MototyouCellItem[gyoCount];
        }

        public override string ToString()
        {
            return string.Join(Environment.NewLine, this.cellItems.Select(item => item?.ItemText));
        }

        public MototyouCellItem GetCellItem(int gyoNo)
        {
            return this.cellItems[gyoNo - 1];
        }

        public void SetCellItem(int gyoNo, string itemText, MototyouLayoutItemCharWidth charWidth, MototyouLayoutKintouWaritukeType kintouWaritukeType)
        {
            this.cellItems[gyoNo - 1] = new MototyouCellItem(itemText, charWidth, kintouWaritukeType);
        }
    }
}
