﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Linq;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.SyouhizeiModel;

    /// <summary>
    /// 元帳仕訳明細行
    /// </summary>
    public class MototyouSiwakeRow : AbstractMototyouRow, IMototyouRow
    {
        public MototyouSiwakeRow(Mototyou parent, int colCount, int gyoCount)
            : base(parent)
        {
            this.EditCells = Enumerable.Range(0, colCount).Select(i => new MototyouCell(gyoCount)).ToArray();
        }

        /// <summary>
        /// 相手科目kicd
        /// </summary>
        public string AiteKicd { get; set; }

        public override MototyouRowType RowType { get; } = MototyouRowType.SiwakeRow;

        /// <summary>
        /// 伝票確認可能な仕訳行かどうか
        /// </summary>
        public bool IsEnabledDenpyouKakunin { get; set; } = true;

        /// <summary>
        /// 伝票日付
        /// </summary>
        public IcspDateTime DenpyouDate { get; set; }

        public override IcspDateTime Date => this.DenpyouDate;

        /// <summary>
        /// レイアウト登録で設定した項目群
        /// </summary>
        public MototyouCell[] EditCells { get; set; }

        /// <summary>
        /// 自分税区分項目
        /// </summary>
        public MototyouZeiKubun ZibunZeiKubun { get; set; }

        /// <summary>
        /// 相手税区分項目
        /// </summary>
        public MototyouZeiKubun AiteZeiKubun { get; set; }

        /// <summary>
        /// 消費税対象科目の仕入区分
        /// </summary>
        public SiwakeSiireKubun? SyouhizeiTaisyouKamokuSiireKubun { get; set; }

        //// ToDo:伝票確認に飛ぶのに必要な項目追加

        /// <summary>
        /// 指定セルデータ取得
        /// </summary>
        /// <param name="colNo">1～</param>
        /// <returns></returns>
        public MototyouCell GetMototyouCell(int colNo)
        {
            return colNo > 0 && colNo <= this.EditCells.Length ? this.EditCells[colNo - 1] : null;
        }

        public override string GetMototyouCellString(int colNo)
        {
            return this.GetMototyouCell(colNo).ToString();
        }

        public override MototyouCellItem GetMototyouCellItem(int colNo, int gyoNo)
        {
            return this.GetMototyouCell(colNo).GetCellItem(gyoNo);
        }

        public override string GetMototyouCellItemString(int colNo, int gyoNo)
        {
            return this.GetMototyouCellItem(colNo, gyoNo)?.ItemText;
        }

        public void SetCellItem(MototyouLayoutItem layoutItem, string itemText)
        {
            if (layoutItem == null)
            {
                return;
            }

            this.SetCellItem(layoutItem.ColumnNo, layoutItem.RowNo, itemText, layoutItem.CharWidth, layoutItem.KintouWaritukeType);
        }

        public void SetCellItem(int colNo, int gyoNo, string itemText, MototyouLayoutItemCharWidth charWidth, MototyouLayoutKintouWaritukeType kintouWaritukeType)
        {
            this.GetMototyouCell(colNo).SetCellItem(gyoNo, itemText, charWidth, kintouWaritukeType);
        }
    }
}
