﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Framework.Core.ComponentModel;
    using Icsp.Open21.Domain.FileExportModel;

    public interface IMototyouExportRepository
    {
        /// <summary>
        /// 検索条件に合う全項目の元帳をCSV出力する
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="methodWorker"></param>
        /// <param name="exportOption"></param>
        /// <returns></returns>
        ExportResult ExportCsv(MototyouQueryParameter queryParameter, IMethodWorker methodWorker, ExportOption exportOption);

        /// <summary>
        /// 一つの項目の元帳をCSV出力する
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="methodWorker"></param>
        /// <param name="exportOption"></param>
        /// <param name="layoutPattern"></param>
        /// <param name="mototyou"></param>
        /// <returns></returns>
        ExportResult ExportCsv(MototyouQueryParameter queryParameter, IMethodWorker methodWorker, ExportOption exportOption, MototyouLayoutPattern layoutPattern, Mototyou mototyou);
    }
}