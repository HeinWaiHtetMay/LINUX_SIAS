﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouMasterRangeQueryConditionTypeExtension
    {
        public static bool IsKobetu(this MototyouMasterRangeQueryConditionType mototyouMasterRangeQueryConditionType)
        {
            return mototyouMasterRangeQueryConditionType == MototyouMasterRangeQueryConditionType.Kobetu
                || mototyouMasterRangeQueryConditionType == MototyouMasterRangeQueryConditionType.KobetuPage;
        }
    }
}
