﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    public class MototyouSiwakeTyouhyouQueryParameter : AbstractSiwakeTyouhyouQueryParameter, ISiwakeTyouhyouQueryParameter
    {
        private MototyouQueryParameter mototyouQueryParameter = null;
        private SiwakeOutputOption siwakeOutputOption = null;

        public MototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, Func<GaikaInitialSetting> getGaikaInitialSetting, SiwakeOutputOption siwakeOutputOption)
            : base(mototyouQueryParameter.SeiritukiCalculateOption.Kaisya, mototyouQueryParameter.KaisyaSyoriKikan, mototyouQueryParameter.MitenkiDataQueryContext, getGaikaInitialSetting)
        {
            this.mototyouQueryParameter = mototyouQueryParameter;
            this.SiwakeTyouhyouQueryOption = new SiwakeTyouhyouQueryOption(mototyouQueryParameter.KaisyaSyoriKikan, mototyouQueryParameter.SecurityContext.UseBusyobetuSecurity, false, false);
            this.SiwakeTyouhyouRowItemAvailability = new SiwakeTyouhyouRowItemAvailability();
            this.SiwakeTyouhyouQueryOption.KamokuSiteiMethod = KamokuSiteiMethod.KobetuSitei;
            this.SiwakeTyouhyouQueryOption.IsSetConditionEachTaisyaku = false;
            if (mototyouQueryParameter.QueryCondition.StartDate != null || mototyouQueryParameter.QueryCondition.EndDate != null)
            {
                //// 日付範囲指定がある場合は日付を指定する
                this.SiwakeTyouhyouQueryOption.DenpyouDateRangeValue.SetValue(
                    mototyouQueryParameter.QueryCondition.StartDate ?? mototyouQueryParameter.StartSyorituki.StartDate,
                    mototyouQueryParameter.QueryCondition.EndDate ?? mototyouQueryParameter.EndSyorituki.EndDate,
                    false,
                    false);
            }

            this.SiwakeTyouhyouQueryOption.DkeiRangeValue.SetValue(
                mototyouQueryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei,
                mototyouQueryParameter.KaisyaSyoriKikan.EndSyorituki.Ckei,
                false,
                false);
            if (mototyouQueryParameter.SecurityContext?.GetUserKaisyabetuSecurity()?.OthersDenpyoPermission == OthersDenpyouPermission.Disallow)
            {
                this.SiwakeTyouhyouQueryOption.DenpyouCreateUserCodeRangeValue.SetValue(
                    mototyouQueryParameter.UserCode,
                    mototyouQueryParameter.UserCode,
                    false,
                    false);
            }

            //// 自動諸口の設定
            this.ConvertZidouSyokutiKamokuInputCodeAndNameBySiwakeOutputOption = true;
            this.siwakeOutputOption = siwakeOutputOption;
        }

        public UserAndSyorikiSecurityContext SecurityContext => this.mototyouQueryParameter.SecurityContext;

        public SiwakeTyouhyouQueryOption SiwakeTyouhyouQueryOption { get; private set; }

        public SiwakeTyouhyouRowItemAvailability SiwakeTyouhyouRowItemAvailability { get; private set; }

        public SiwakeTyouhyouOutputType SiwakeTyouhyouOutputType => SiwakeTyouhyouOutputType.TanituSiwake;

        public int SiwakeMaxDisplayCount => int.MaxValue;

        public bool IsNotOutputKamokuNotDisplayedSiwake => true;

        public bool IsAllUserOutputTarget => true;

        public bool IsMikanDenpyouOnlySearch => throw new NotImplementedException();

        public bool IsUseTanituSiwakeDenpyouSortOrder => false;

        public bool IsExport { get; set; }

        public bool IsUseNotInputCheckOptionForGetSiwakeTyouhyou => false;

        public NotInputCheckOption NotInputCheckOption => new NotInputCheckOption();

        public SiwakeTyouhyouSortOrder SortOrder => SiwakeTyouhyouSortOrder.DenpyouDateAndUketukeNo;

        public SiwakeTyouhyouOutputOrderSetting OutputOrderSetting => SiwakeTyouhyouOutputOrderSetting.DenpyouDateAndUketukeNo;

        public SiwakeTyouhyouDenpyouSortOrder HukugouSiwakeDenpyouSortOrder => SiwakeTyouhyouDenpyouSortOrder.DenpyouDate;

        public SiwakeTyouhyouDenpyouSortOrder TanituSiwakeDenpyouSortOrder => SiwakeTyouhyouDenpyouSortOrder.DenpyouDate;

        public SiwakeTyouhyouHukugouSiwakeNormalOutputSetting HukugouSiwakeNormalOutputSetting => default(SiwakeTyouhyouHukugouSiwakeNormalOutputSetting);

        public SiwakeTyouhyouTekiyouCharacterDivisionType TekiyouCharacterDivisionType => default(SiwakeTyouhyouTekiyouCharacterDivisionType);

        public SyouninDenpyouSearchCondition SyouninDenpyouSearchCondition => throw new NotImplementedException();

        public Range<int?> RequiredSiwakeRowNoRange => null;

        public DenpyouInputAndSyuuseiOption DenpyouInputAndSyuuseiOption => new DenpyouInputAndSyuuseiOption();

        public SiwakeOutputOption SiwakeOutputOption => this.siwakeOutputOption;

        public void ClearRequiredSiwakeRowNoRange()
        {
            throw new NotImplementedException();
        }

        public ISiwakeTyouhyouQueryParameter Clone(ISiwakeTyouhyouDenpyouRow denpyou)
        {
            return (ISiwakeTyouhyouQueryParameter)this.MemberwiseClone();
        }

        public ISiwakeTyouhyouQueryParameter CloneForHukugouSiwakeTyouhyou(ISiwakeTyouhyouDenpyouRow denpyou)
        {
            return (ISiwakeTyouhyouQueryParameter)this.MemberwiseClone();
        }

        public ISet<SiwakeTyouhyouOrderItem> CreateSiwakeTyouhyouOrderItemSet(bool isGetDenpyou)
        {
            return new HashSet<SiwakeTyouhyouOrderItem>()
            {
                //// 仕訳取得後に元帳独自のソートをかけるため、取得時のソートは不要
            };
        }

        public bool GetHeaderFieldNotInputCheckForDenpyouSyuusei(int headerFieldNo)
        {
            return false;
        }

        public void SetRequiredSiwakeRowNoRange(int? startNo, int? endNo)
        {
            throw new NotImplementedException();
        }

        public void SetSiwakeTyouhyouRowItemAvailability(KaisyaSubsystemAvailability gaikaSystemAvailability, SyouhizeiMaster syouhizeiMaster, bool isGetSiwake)
        {
            this.SetDefaultSiwakeTyouhyouRowItemAvailability(this.SiwakeTyouhyouRowItemAvailability, gaikaSystemAvailability, syouhizeiMaster, isGetSiwake);

            this.SiwakeTyouhyouRowItemAvailability.DenpyouItemEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouCreateAndUpdateItemEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.DenpyouTabaEnabled = this.MitenkiDataQueryContext.IncludesBusyobetuSiwake;
            this.SiwakeTyouhyouRowItemAvailability.SyouninItemEnabled = true;

            //// 正式名称と略式名称の両方を取得する
            this.SiwakeTyouhyouRowItemAvailability.UseKamokuLongName = false;
            this.SiwakeTyouhyouRowItemAvailability.KamokuLongNameEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.UseKouziLongName = false;
            this.SiwakeTyouhyouRowItemAvailability.KouziLongNameEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.UseProjectLongName = false;
            this.SiwakeTyouhyouRowItemAvailability.ProjectLongNameEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.UseSegmentLongName = false;
            this.SiwakeTyouhyouRowItemAvailability.SegmentLongNameEnabled = true;
            this.SiwakeTyouhyouRowItemAvailability.UseTorihikisakiLongName = false;
            this.SiwakeTyouhyouRowItemAvailability.TorihikisakiLongNameEnabled = true;
            for (int i = 1; i <= 20; i++)
            {
                this.SiwakeTyouhyouRowItemAvailability.SetUseUniversalFieldLongName(i, false);
                this.SiwakeTyouhyouRowItemAvailability.SetUniversalFieldLongNameEnabled(i, true);
            }

            if (isGetSiwake)
            {
                this.SiwakeTyouhyouRowItemAvailability.SiwakeItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.SiwakeCreateAndUpdateItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.ZeiKubunItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KamokuEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.TekiyouCodeEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.KingakuItemEnabled = true;
                this.SiwakeTyouhyouRowItemAvailability.GaikaKansanSiwakeFlagEnabled = false;
                this.SiwakeTyouhyouRowItemAvailability.BumonAsBumonSiteiEnabled = this.mototyouQueryParameter.OptionComposite.QueryOption.IsSyuukeiBumon;
            }
        }
    }
}
