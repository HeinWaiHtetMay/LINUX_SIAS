﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    /// <summary>
    /// 元帳問い合わせ条件個別指定項目
    /// </summary>
    public class MototyouQueryConditionKobetuSiteiItem : IMototyouQueryConditionKobetuSiteiItem//// : ZandakaYosanMasterCode
    {
        /*
        public MototyouQueryConditionKobetuSiteiItem(int kesn)
            : base(kesn)
        {
        }
        */

        public Kamoku Kamoku { get; set; }

        public string Pkicd { get; set; }

        public string BumonCode { get; set; }

        public string EdabanCode { get; set; }

        public string TorihikisakiCode { get; set; }

        /// <summary>
        /// 元帳問い合わせ条件パターンを取得・設定します
        /// </summary>
        public MototyouQueryConditionPattern MototyouQueryConditionPattern { get; set; }

        /// <summary>
        /// 集計形式を取得・設定します
        /// </summary>
        public MototyouSyuukeiKeisiki SyuukeiKeisiki { get; set; } = MototyouSyuukeiKeisiki.Detail;

        /// <summary>
        /// 開始ページNoを取得・設定します
        /// </summary>
        public int? StartPageNo { get; set; }

        /// <summary>
        /// 終了ページNoを取得・設定します
        /// </summary>
        public int? EndPageNo { get; set; }
    }
}
