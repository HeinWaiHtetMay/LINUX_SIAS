﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.Linq;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;

    public class MototyouQueryParameter : AbstractTyouhyouQueryParameter
    {
        private MototyouQueryParameter(IKaisyaSyoriKikan kaisyaSyoriKikan, Syorituki selectedEndSyorituki, bool isMultiSyorituki, BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext, SeiritukiCalculateOption seiritukiCalculateOption, MototyouOptionComposite optionComposite, MototyouQueryCondition queryCondition, Kaisya currentKaisya)
            : base(kaisyaSyoriKikan, mitenkiDataQueryContext, seiritukiCalculateOption)
        {
            this.OptionComposite = optionComposite;
            this.QueryCondition = queryCondition;
            this.KamokuOutputOrder = optionComposite.Option.KamokuOutputOrder.GetKamokuOutputOrder(kaisyaSyoriKikan.Syoriki);
            this.CurrentKaisya = currentKaisya;
            this.IsMultiSyorituki = isMultiSyorituki;
            this.SelectedEndSyorituki = selectedEndSyorituki;
        }

        public MototyouOptionComposite OptionComposite { get; private set; }

        public override bool UseUserSeiritukiCalculateOption => this.OptionComposite.QueryOption.UseUserSeiritukiCalculateOption;

        public MototyouQueryCondition QueryCondition { get; private set; }

        public Kaisya CurrentKaisya { get; private set; }

        public KamokuOutputOrder KamokuOutputOrder { get; private set; }

        /// <summary>
        /// 処理月選択ダイアログで選択した処理期間が複数月指定であるかどうか
        /// </summary>
        public bool IsMultiSyorituki { get; private set; }

        /// <summary>
        /// 処理月選択ダイアログで選択した終了月
        /// </summary>
        public Syorituki SelectedEndSyorituki { get; private set; }

        public static MototyouQueryParameter Create(IKaisyaSyoriKikan kaisyaSyoriKikan, BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext, SeiritukiCalculateOption seiritukiCalculateOption, MototyouOptionComposite optionComposite, MototyouQueryCondition queryCondition, Kaisya currentKaisya)
        {
            var startSyorituki = queryCondition.StartDate == null
             ? kaisyaSyoriKikan.StartSyorituki
             : queryCondition.UseSeiritukiOnStartData
                   ? kaisyaSyoriKikan.GetSyoritukiEnumerable().LastOrDefault(syorituki => queryCondition.StartDate.CompareTo(syorituki.StartDate) >= 0)
                   : kaisyaSyoriKikan.GetSyoritukiEnumerable().FirstOrDefault(syorituki => queryCondition.StartDate.CompareTo(syorituki.EndDate) <= 0);
            var endSyorituki = queryCondition.EndDate == null
                ? seiritukiCalculateOption.GetOptionReflectedSyorikikan(kaisyaSyoriKikan, optionComposite.QueryOption.UseUserSeiritukiCalculateOption).EndSyorituki
                : queryCondition.UseSeiritukiOnEndData
                      ? kaisyaSyoriKikan.GetSyoritukiEnumerable().LastOrDefault(syorituki => queryCondition.EndDate.CompareTo(syorituki.StartDate) >= 0)
                      : kaisyaSyoriKikan.GetSyoritukiEnumerable().FirstOrDefault(syorituki => queryCondition.EndDate.CompareTo(syorituki.EndDate) <= 0);
            if (queryCondition.EndDate != null
                && !queryCondition.UseSeiritukiOnEndData
                && endSyorituki.IsQuarterEndNormalSyorituki
                && seiritukiCalculateOption.GetOptionFlag(kaisyaSyoriKikan.Syoriki.Kesn, optionComposite.QueryOption.UseUserSeiritukiCalculateOption, endSyorituki.GetSeirituki()?.SeiritukiId ?? SeiritukiId.Other) == SeiritukiCalculateOptionFlag.IncludeSyorituki)
            {
                endSyorituki = endSyorituki.GetSeirituki();
            }

            var queryKaisyaSyoriKikan = new KaisyaSyoriKikan(kaisyaSyoriKikan.Syoriki, startSyorituki, endSyorituki);
            return new MototyouQueryParameter(queryKaisyaSyoriKikan, kaisyaSyoriKikan.EndSyorituki, kaisyaSyoriKikan.IsMultiSyorituki, mitenkiDataQueryContext, seiritukiCalculateOption, optionComposite, queryCondition, currentKaisya);
        }

        public static MototyouQueryParameter CreateWithoutSyoriKikanChangingAsSeiritukiCalculateOption(IKaisyaSyoriKikan kaisyaSyoriKikan, BusyobetuTyouhyouMitenkiDataQueryContext mitenkiDataQueryContext, SeiritukiCalculateOption seiritukiCalculateOption, MototyouOptionComposite optionComposite, MototyouQueryCondition queryCondition, Kaisya currentKaisya)
        {
            return new MototyouQueryParameter(kaisyaSyoriKikan, kaisyaSyoriKikan.EndSyorituki, kaisyaSyoriKikan.IsMultiSyorituki, mitenkiDataQueryContext, seiritukiCalculateOption, optionComposite, queryCondition, currentKaisya);
        }

        public SeiritukiCalculateOptionFlag GetSeiritukiCalculateOptionFlag(int ckei)
        {
            return this.SeiritukiCalculateOption.GetSyorikiItem(this.Kesn, this.UseUserSeiritukiCalculateOption).GetOption(ckei);
        }

        /// <summary>
        /// 元帳出力開始日を取得
        /// </summary>
        /// <returns></returns>
        public IcspDateTime GetMototyouOutputStartDate()
        {
            //// 日付範囲指定の開始日が含まれる処理月の最初の日
            //// 日付範囲指定で開始日に入力がなければ処理期間の最初の日
            return this.QueryCondition.StartDate != null
                ? this.KaisyaSyoriKikan.GetSyoritukiEnumerable().FirstOrDefault(syorituki =>
                    this.QueryCondition.StartDate.CompareTo(syorituki.StartDate) >= 0
                    && this.QueryCondition.StartDate.CompareTo(syorituki.EndDate) <= 0).StartDate
                : this.KaisyaSyoriKikan.StartDate;
        }

        /// <summary>
        /// 注釈文字列を取得します
        /// </summary>
        /// <returns></returns>
        public IList<string> GetAnnotationTextList()
        {
            IList<string> textList = new List<string>();
            var mitenkiDenpyou = this.MitenkiDataQueryContext.GetMitenkiDenpyouLabel();
            var codeSecurity = this.GetCodeSecurityAnnotation();
            var denpyouPermission = this.GetDenpyouPermissionAnnotation();

            if (!string.IsNullOrEmpty(mitenkiDenpyou))
            {
                textList.Add(mitenkiDenpyou);
            }

            if (!string.IsNullOrEmpty(codeSecurity))
            {
                textList.Add(codeSecurity);
            }

            if (!string.IsNullOrEmpty(denpyouPermission))
            {
                textList.Add(denpyouPermission);
            }

            return textList;
        }

        /// <summary>
        /// コードセキュリティがかかっている時に注釈文字列取得
        /// </summary>
        /// <returns></returns>
        private string GetCodeSecurityAnnotation()
        {
            return this.SecurityContext.GetUseZaimuKamokuCodeSecurity(SecurityKubun.Output)
                || this.SecurityContext.GetUseZaimuBumonCodeSecurity(SecurityKubun.Output)
                || this.SecurityContext.GetUseZaimuKamokuEdabanCodeSecurity(SecurityKubun.Output)
                || this.SecurityContext.GetUseZaimuTorihikisakiCodeSecurity(SecurityKubun.Output)
                ? Properties.Resources.セキュリティによる制限あり : string.Empty;
        }

        /// <summary>
        /// 他人仕訳を参照できない時に注釈文字列取得
        /// </summary>
        /// <returns></returns>
        private string GetDenpyouPermissionAnnotation()
        {
            return this.SecurityContext.GetUserKaisyabetuSecurity().OthersDenpyoPermission == OthersDenpyouPermission.Disallow
                ? Properties.Resources.伝票権限による制限あり : string.Empty;
        }
    }
}
