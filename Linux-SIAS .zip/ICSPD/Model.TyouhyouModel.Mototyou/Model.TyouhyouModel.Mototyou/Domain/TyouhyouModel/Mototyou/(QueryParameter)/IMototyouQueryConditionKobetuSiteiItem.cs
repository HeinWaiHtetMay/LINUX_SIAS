﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouQueryConditionKobetuSiteiItem
    {
        Kamoku Kamoku { get; }

        string Pkicd { get; }

        string EdabanCode { get; }

        string BumonCode { get; }

        string TorihikisakiCode { get; }

        int? StartPageNo { get; }

        int? EndPageNo { get; }

        MototyouSyuukeiKeisiki SyuukeiKeisiki { get; }
    }
}