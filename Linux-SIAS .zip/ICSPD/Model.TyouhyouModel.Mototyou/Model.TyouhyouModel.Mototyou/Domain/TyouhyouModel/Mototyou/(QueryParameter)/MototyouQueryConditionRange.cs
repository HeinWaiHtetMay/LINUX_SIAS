﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using Icsp.Open21.Domain.MasterModel;

    /// <summary>
    /// 元帳問い合わせ条件範囲指定
    /// </summary>
    public class MototyouQueryConditionRange : IMototyouQueryConditionRange
    {
        /// <summary>
        /// 元帳問い合わせ条件パターンの開始Noを取得・設定します
        /// </summary>
        public int? StartMototyouQueryConditionPatternNo { get; set; }

        /// <summary>
        /// 元帳問い合わせ条件パターンの終了Noを取得・設定します
        /// </summary>
        public int? EndMototyouQueryConditionPatternNo { get; set; }

        public Kamoku StartKamoku { get; set; }

        public Kamoku EndKamoku { get; set; }

        /// <summary>
        /// 規則外集計科目の場合の開始コード
        /// </summary>
        public string StartPkicd { get; set; }

        /// <summary>
        /// 規則外集計科目の場合の終了コード
        /// </summary>
        public string EndPkicd { get; set; }

        public string StartBumonCode { get; set; }

        public string EndBumonCode { get; set; }

        public string StartEdabanCode { get; set; }

        public string EndEdabanCode { get; set; }

        public string StartTorihikisakiCode { get; set; }

        public string EndTorihikisakiCode { get; set; }
    }
}
