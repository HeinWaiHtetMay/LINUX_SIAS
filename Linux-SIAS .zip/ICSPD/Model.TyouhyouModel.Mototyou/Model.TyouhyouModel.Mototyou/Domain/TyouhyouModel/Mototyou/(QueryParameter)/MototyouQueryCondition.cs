﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using Icsp.Open21.Domain.DateTimeModel;

    public class MototyouQueryCondition
    {
        /// <summary>
        /// 損益振替の種別を取得・設定します
        /// </summary>
        public MototyouSonekiHurikaeType SonekiHurikaeType { get; set; } = MototyouSonekiHurikaeType.NotUse;

        /// <summary>
        /// 前期繰越で差額を出力するかどうかを取得・設定します
        /// </summary>
        public bool OutputSagakuOnZenkiKurikosi { get; set; }

        /// <summary>
        /// 問い合わせ条件のパターンの種別を取得・設定します
        /// </summary>
        public MototyouQueryConditionPatternType QueryConditionPatternType { get; set; }

        /// <summary>
        /// 開始日付を取得・設定します
        /// </summary>
        public IcspDateTime StartDate { get; set; }

        /// <summary>
        /// 終了日付を取得・設定します
        /// </summary>
        public IcspDateTime EndDate { get; set; }

        /// <summary>
        /// 開始日付で整理月を使用するかどうかを取得・設定します
        /// </summary>
        public bool UseSeiritukiOnStartData { get; set; }

        /// <summary>
        /// 終了日付で整理月を使用するかどうかを取得・設定します
        /// </summary>
        public bool UseSeiritukiOnEndData { get; set; }

        /// <summary>
        /// マスター範囲指定の問い合わせ条件の種別を取得・設定します
        /// </summary>
        public MototyouMasterRangeQueryConditionType MototyouMasterRangeQueryConditionType { get; set; }

        /// <summary>
        /// 範囲指定の条件を取得・設定します
        /// </summary>
        public MototyouQueryConditionRange QueryConditionRange { get; set; } = new MototyouQueryConditionRange();

        /// <summary>
        /// 個別指定条件の項目リストを取得・設定します
        /// </summary>
        public IList<MototyouQueryConditionKobetuSiteiItem> KobetuSiteiItemList { get; set; } = new List<MototyouQueryConditionKobetuSiteiItem>();

        public MototyouQueryCondition CloneAsShallowCopy()
        {
            return (MototyouQueryCondition)this.MemberwiseClone();
        }
    }
}
