﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public enum MototyouSonekiHurikaeType
    {
        NotUse = 0,
        UseSonekiHurikae = 1,
        UseSonekiHurikaeAndSonekiKanzyou = 2
    }
}
