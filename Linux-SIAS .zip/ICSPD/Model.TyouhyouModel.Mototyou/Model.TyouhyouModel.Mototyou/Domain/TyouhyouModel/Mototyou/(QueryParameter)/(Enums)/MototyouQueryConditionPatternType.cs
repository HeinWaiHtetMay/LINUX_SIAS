﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳問い合わせ条件パターン種別
    /// </summary>
    public enum MototyouQueryConditionPatternType
    {
        NotUse = 0,
        Range = 1,
        Kobetu = 2
    }
}
