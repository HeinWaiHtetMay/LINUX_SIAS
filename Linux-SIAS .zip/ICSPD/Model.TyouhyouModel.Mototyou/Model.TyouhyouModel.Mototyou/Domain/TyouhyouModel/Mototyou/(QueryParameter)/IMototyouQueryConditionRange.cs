﻿using Icsp.Open21.Domain.MasterModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouQueryConditionRange
    {
        Kamoku StartKamoku { get; }

        Kamoku EndKamoku { get; }

        string StartPkicd { get; }

        string EndPkicd { get; }

        string StartEdabanCode { get; }

        string EndEdabanCode { get; }

        string StartBumonCode { get; }

        string EndBumonCode { get; }

        string StartTorihikisakiCode { get; }

        string EndTorihikisakiCode { get; }
    }
}