﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public static class MototyouQueryConditionPatternTypeExtension
    {
        public static bool UsePattern(this MototyouQueryConditionPatternType mototyouQueryConditionPatternType)
        {
            return mototyouQueryConditionPatternType != MototyouQueryConditionPatternType.NotUse;
        }
    }
}
