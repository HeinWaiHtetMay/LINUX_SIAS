﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    /// <summary>
    /// 元帳マスター範囲の問い合わせ条件の種別
    /// </summary>
    public enum MototyouMasterRangeQueryConditionType
    {
        /// <summary>
        /// 使用しない
        /// </summary>
        NotUse = 0,

        /// <summary>
        /// 範囲指定
        /// </summary>
        Range = 1,

        /// <summary>
        /// 個別指定
        /// </summary>
        Kobetu = 2,

        /// <summary>
        /// 個別ページ指定
        /// </summary>
        KobetuPage = 3
    }
}
