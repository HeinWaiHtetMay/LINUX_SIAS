﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using Icsp.Framework.Core.Text;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    /// <summary>
    /// 税区分クラス
    /// 外部からのインスタンス生成はpublic static Create○○メソッドを使用する（用途をメソッド名で定義）
    /// </summary>
    public class MototyouZeiKubun
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private MototyouZeiKubun()
        {
        }

        public bool IsIkkatuZeinuki { get; private set; }

        /// <summary>
        /// 消費税率（出力しない場合はnull）
        /// </summary>
        public Syouhizeiritu Syouhizeiritu { get; private set; }

        /// <summary>
        /// 課税区分（出力しない場合はnull）
        /// </summary>
        public KazeiKubun? KazeiKubun { get; private set; }

        /// <summary>
        /// 業種区分（出力しない場合はnull）
        /// </summary>
        public GyousyuKubun? GyousyuKubun { get; private set; }

        /// <summary>
        /// 仕入区分（出力しない場合はnull）
        /// </summary>
        public SiwakeSiireKubun? SiireKubun { get; private set; }

        public static MototyouZeiKubun CreateZeikubun(Syouhizeiritu syouhizeiritu, KazeiKubun? kazeiKubun)
        {
            return new MototyouZeiKubun() { Syouhizeiritu = syouhizeiritu, KazeiKubun = kazeiKubun };
        }

        public static MototyouZeiKubun CreateKanikazeiZeikubun(Syouhizeiritu syouhizeiritu, KazeiKubun? kazeiKubun, GyousyuKubun? gyousyuKubun)
        {
            return new MototyouZeiKubun() { Syouhizeiritu = syouhizeiritu, KazeiKubun = kazeiKubun, GyousyuKubun = gyousyuKubun };
        }

        public static MototyouZeiKubun CreateSiireAnbunKobetuTaiouZeikubun(Syouhizeiritu syouhizeiritu, KazeiKubun? kazeiKubun, SiwakeSiireKubun? siireKubun)
        {
            return new MototyouZeiKubun() { Syouhizeiritu = syouhizeiritu, KazeiKubun = kazeiKubun, SiireKubun = siireKubun };
        }

        public static MototyouZeiKubun CreateNullZeikubun()
        {
            return new MototyouZeiKubun();
        }

        public static MototyouZeiKubun CreateIkkatuZeinukiZeikubun(Syouhizeiritu syouhizeiritu, SiwakeSiireKubun? siireKubun)
        {
            return new MototyouZeiKubun() { IsIkkatuZeinuki = true, Syouhizeiritu = syouhizeiritu, SiireKubun = siireKubun };
        }

        public string GetZeirituText(string format)
        {
            return string.Format(
                "{0}{1}",
                (this.Syouhizeiritu?.IsKeigenzeiritu ?? false) ? "*" : string.Empty,
                this.Syouhizeiritu?.Zeiritu.GetDecmalValue().ToString(format) ?? string.Empty);
            //// TODO：問題なければ消す
            ////return format.Contains("%")
            ////    ? string.Format("{0}{1}", this.Syouhizeiritu.IsKeigenzeiritu ? "*" : string.Empty, this.Syouhizeiritu?.Zeiritu.GetDecmalValue().ToString(format) ?? string.Empty)
            ////    : this.Syouhizeiritu?.Zeiritu.GetValue().ToString(format) ?? string.Empty;
        }

        public string GetMototyouCellText()
        {
            if (this.IsIkkatuZeinuki)
            {
                return this.GetZeirituCellText("　") + "一括" + (this.SiireKubun.HasValue ? this.SiireKubun?.GetShortName() : "　");
            }
            else
            {
                return this.GetZeirituCellText("　") + this.GetKazeikubunText(2, '　') + this.GetGyousyuOrSiirekubunText("　");
            }
        }

        public string GetKazeikubunText()
        {
            return this.GetKazeikubunText(0, ' ');
        }

        public string GetKazeikubunLongNameText()
        {
            return this.KazeiKubun.HasValue ? this.KazeiKubun.Value.GetLongName() : string.Empty;
        }

        public string GetGyousyuOrSiirekubunText()
        {
            return this.GetGyousyuOrSiirekubunText(string.Empty);
        }

        private string GetZeirituCellText(string nullOrZeroText)
        {
            //// 課税区分が「計算外」の場合は税率を表示しない
            var zeiritu = this.KazeiKubun == SyouhizeiModel.KazeiKubun.計算外 ? null : (int?)this.Syouhizeiritu?.Zeiritu.GetValue();
            //// 一桁なら全角、二桁なら半角
            if (!zeiritu.HasValue || zeiritu == 0)
            {
                return nullOrZeroText;
            }
            else if (zeiritu >= 10)
            {
                return zeiritu.ToString();
            }
            else if (this.Syouhizeiritu?.IsKeigenzeiritu ?? false)
            {
                return "*" + zeiritu.ToString();
            }
            else
            {
                return zeiritu.ToString().ToWide();
            }
        }

        private string GetKazeikubunText(int minLength, char padChar)
        {
            return this.KazeiKubun.HasValue ? this.KazeiKubun.Value.GetShortName().PadRight(minLength, padChar) : new string(padChar, minLength);
        }

        private string GetGyousyuOrSiirekubunText(string nullText)
        {
            //// 全角一文字分
            if (this.GyousyuKubun.HasValue)
            {
                return this.GyousyuKubun.Value.GetShortName();
            }
            else if (this.SiireKubun.HasValue)
            {
                return this.SiireKubun.Value.GetShortName();
            }

            return nullText;
        }
    }
}
