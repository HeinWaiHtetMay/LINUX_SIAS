﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    [Factory]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouZeikubunFactoryCreator : IMototyouZeikubunFactoryCreator
    {
        [AutoInjection]
        private ISyouhizeirituRepository syouhizeirituRepository = null;
        [AutoInjection]
        private ISyouhizeiMasterRepository syouhizeiMasterRepository = null;
        [AutoInjection]
        private IKamokuRepository kamokuRepository = null;
        [AutoInjection]
        private IMototyouOutputOptionCompositeRepository mototyouOutputOptionCompositeRepository = null;
        [AutoInjection]
        private IMototyouLayoutPatternRepository layoutPatternRepository = null;

        public virtual IMototyouZeiKubunFactory Create(MototyouQueryParameter queryParameter)
        {
            return this.Create(queryParameter, this.layoutPatternRepository.FindByPatternNo(queryParameter.OptionComposite.QueryOption.LayoutPatternNo.Value), this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn));
        }

        public virtual IMototyouZeiKubunFactory Create(MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern, SyouhizeiMaster syouhizeiMaster)
        {
            return MototyouZeiKubunFactory.Create(
                queryParameter,
                this.mototyouOutputOptionCompositeRepository.FindByKesn(queryParameter.Kesn),
                layoutPattern,
                this.syouhizeirituRepository.FindAllAsSyouhizeirituDictionary(),
                syouhizeiMaster,
                this.kamokuRepository);
        }

        /// <summary>
        /// 実行回数が多い処理で条件分岐も複雑なため、各条件ごとのフィールド変数を定義する
        /// 出力しない項目は、MototyouZeiKubunにnullをセット
        /// 出力しないが、実際の値の参照が必要になる場合は、MototyouZeiKubun側に各項目を出力するかのフラグを追加する
        /// </summary>
        protected class MototyouZeiKubunFactory : IMototyouZeiKubunFactory
        {
            private IKamokuRepository kamokuRepository;

            private int kesn;
            private bool useZeikubun;
            private bool shouldOutputKazeikubunTaisyougai;
            private bool useKanikazei;
            private bool useSiirezeigakuAnbunKobetutaiou;
            private IcspDateTime outputStartDate;
            private GyousyuKubun defaultGyousyuKubun;

            private MototyouKazeiKubunOutputType kazeiKubunOutputType;
            private bool notOutputLatestZeirituIfZeikubunOutputTypeIsAbsolute;
            private MototyouIkkatuZeinukiSiwakeSyuukeiType ikkatuZeinukiSiwakeSyuukeiType;

            private SyouhizeirituDictionary syouhizeirituDictionary;
            private IDictionary<string, Kamoku> meisaikamokuDicitonary;

            private bool convertToLatestSyouhizeirituIfSiwakeRowKamokuSyouhizeirituCanNotUse;
            private bool convertToLatestSyouhizeirituIfZibunItemKamokuSyouhizeirituCanNotUse;

            private Syouhizeiritu latestSyouhizeirituOnOutputStartDate;

            private MototyouZeiKubunFactory()
            {
            }

            public static IMototyouZeiKubunFactory Create(
                MototyouQueryParameter queryParameter,
                MototyouOutputOptionComposite outputOptionComposite,
                MototyouLayoutPattern layoutPattern,
                SyouhizeirituDictionary syouhizeirituDictionary,
                SyouhizeiMaster syouhizeiMaster,
                IKamokuRepository kamokuRepository)
            {
                var result = new MototyouZeiKubunFactory();
                result.kesn = queryParameter.Kesn;
                result.useZeikubun = layoutPattern.UseSyouhizeiKubun && queryParameter.Syoriki.UseSyouhizei;
                result.shouldOutputKazeikubunTaisyougai = outputOptionComposite.ShouldOutputKazeiKubunTaisyougai;
                result.useKanikazei = syouhizeiMaster.KazeiHousiki.IsKaniKazei();
                result.useSiirezeigakuAnbunKobetutaiou = syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou;
                result.outputStartDate = queryParameter.GetMototyouOutputStartDate();
                result.syouhizeirituDictionary = syouhizeirituDictionary;
                result.latestSyouhizeirituOnOutputStartDate = syouhizeirituDictionary.GetLatestSyouhizeiritu(result.outputStartDate, false);
                result.kamokuRepository = kamokuRepository;
                result.kazeiKubunOutputType = queryParameter.OptionComposite.Option.KazeiKubunOutputType;
                result.ikkatuZeinukiSiwakeSyuukeiType = queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType;
                result.defaultGyousyuKubun = syouhizeiMaster.KazeiHousiki.GetDefaultGyousyuKubun();
                switch (result.kazeiKubunOutputType)
                {
                    case MototyouKazeiKubunOutputType.Absolute:
                        result.notOutputLatestZeirituIfZeikubunOutputTypeIsAbsolute = outputOptionComposite.SiwakeOutputOption.MototyouZeirituOutputTypeWhenKazeiKubunIsAbsoluteDisplay == KaisyaModel.KaisyaZyouhouSetteiTouroku.ZeirituOutputType.NotOutputLatestZeiritu;
                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingMaster:
                        result.convertToLatestSyouhizeirituIfSiwakeRowKamokuSyouhizeirituCanNotUse = outputOptionComposite.SiwakeOutputOption.MototyouCompareTypeWhenKazeiKubunIsRelativeDisplay == ZeirituCompareType.CompareToConvertAvailableZeiritu;
                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingTitle:
                        result.convertToLatestSyouhizeirituIfZibunItemKamokuSyouhizeirituCanNotUse = outputOptionComposite.SiwakeOutputOption.MototyouCompareTypeWhenKazeiKubunIsRelativeDisplay == ZeirituCompareType.CompareToConvertAvailableZeiritu;
                        break;
                }

                return result;
            }

            public virtual MototyouZeiKubun CreateSiwakeRowZeikubun(ITanituSiwakeTyouhyouRow row, TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
            {
                if (!this.useZeikubun)
                {
                    return MototyouZeiKubun.CreateNullZeikubun();
                }

                var syouhizeiritu = detail.Syouhizeiritu;
                var kazeiKubun = detail.KazeiKubun;
                if (!this.shouldOutputKazeikubunTaisyougai && kazeiKubun == KazeiKubun.対象外)
                {
                    kazeiKubun = null;
                }

                var siireKubun = detail.SiwakeSiireKubun;
                var gyousyuKubun = detail.GyousyuKubun;
                switch (this.kazeiKubunOutputType)
                {
                    case MototyouKazeiKubunOutputType.Absolute:
                        if (syouhizeiritu != null
                            && this.notOutputLatestZeirituIfZeikubunOutputTypeIsAbsolute
                            && this.syouhizeirituDictionary.IsLatestSyouhizeiritu(syouhizeiritu, this.outputStartDate))
                        {
                            syouhizeiritu = null;
                        }

                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingMaster:
                        if (this.GetMeisaiKamokuDictionary().TryGetValue(detail.Kicd, out Kamoku kamoku))
                        {
                            //// 科目の税率がない場合は最新の税率と比較
                            if (syouhizeiritu != null && syouhizeiritu.Id == (kamoku.Syouhizeiritu ?? this.latestSyouhizeirituOnOutputStartDate)?.Id)
                            {
                                syouhizeiritu = null;
                            }

                            if (kazeiKubun.HasValue && kazeiKubun == kamoku.KazeiKubun)
                            {
                                kazeiKubun = null;
                            }

                            if (this.useKanikazei && gyousyuKubun.HasValue)
                            {
                                //// 業種区分が「0」の場合は基本業種に置き換えて比較
                                var zibunGyousyuKubunForComparison = kamoku.GyousyuKubun == GyousyuKubun.None ? this.defaultGyousyuKubun : kamoku.GyousyuKubun;
                                var gyousyuKubunForComparison = gyousyuKubun == GyousyuKubun.None ? this.defaultGyousyuKubun : gyousyuKubun;
                                if (zibunGyousyuKubunForComparison == gyousyuKubunForComparison)
                                {
                                    gyousyuKubun = null;
                                }
                            }

                            if (this.useSiirezeigakuAnbunKobetutaiou && siireKubun.HasValue && siireKubun == kamoku.GetSiwakeSiireKubun())
                            {
                                siireKubun = null;
                            }
                        }

                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingTitle:
                        //// 自分項目の税率がない場合は最新の税率と比較
                        if (syouhizeiritu != null && syouhizeiritu.Id == (zibunItem.ZeiKubun.Syouhizeiritu ?? this.latestSyouhizeirituOnOutputStartDate)?.Id)
                        {
                            syouhizeiritu = null;
                        }

                        if (kazeiKubun.HasValue && kazeiKubun == zibunItem.ZeiKubun.KazeiKubun)
                        {
                            kazeiKubun = null;
                        }

                        if (this.useKanikazei && gyousyuKubun.HasValue)
                        {
                            //// 業種区分が「0」の場合は基本業種に置き換えて比較
                            var zibunGyousyuKubunForComparison = zibunItem.ZeiKubun.GyousyuKubun == GyousyuKubun.None ? this.defaultGyousyuKubun : zibunItem.ZeiKubun.GyousyuKubun;
                            var gyousyuKubunForComparison = gyousyuKubun == GyousyuKubun.None ? this.defaultGyousyuKubun : gyousyuKubun;
                            if (zibunGyousyuKubunForComparison == gyousyuKubunForComparison)
                            {
                                gyousyuKubun = null;
                            }
                        }

                        if (this.useSiirezeigakuAnbunKobetutaiou && siireKubun.HasValue && siireKubun == zibunItem.ZeiKubun.SiireKubun)
                        {
                            siireKubun = null;
                        }

                        break;
                }

                if (this.useKanikazei)
                {
                    return MototyouZeiKubun.CreateKanikazeiZeikubun(syouhizeiritu, kazeiKubun, gyousyuKubun);
                }
                else if (this.useSiirezeigakuAnbunKobetutaiou)
                {
                    return MototyouZeiKubun.CreateSiireAnbunKobetuTaiouZeikubun(syouhizeiritu, kazeiKubun, siireKubun);
                }
                else
                {
                    return MototyouZeiKubun.CreateZeikubun(syouhizeiritu, kazeiKubun);
                }
            }

            public virtual MototyouZeiKubun CreateNullZeikubun()
            {
                return MototyouZeiKubun.CreateNullZeikubun();
            }

            public virtual MototyouZeiKubun CreateIkkatuZeinukiSiwakeRowZeikubun(ITanituSiwakeTyouhyouRow row, IMototyouZibunItem zibunItem, SiwakeSiireKubun? siireKubun)
            {
                //// 税率は貸借で設定されている方から取得
                var detail = row.KarikataDetail.Syouhizeiritu?.Zeiritu.GetValue() > 0
                    ? row.KarikataDetail
                    : row.KasikataDetail;
                var syouhizeiritu = detail.Syouhizeiritu;
                switch (this.kazeiKubunOutputType)
                {
                    case MototyouKazeiKubunOutputType.Absolute:
                        if (syouhizeiritu != null
                            && this.notOutputLatestZeirituIfZeikubunOutputTypeIsAbsolute
                            && this.syouhizeirituDictionary.IsLatestSyouhizeiritu(syouhizeiritu, this.outputStartDate))
                        {
                            syouhizeiritu = null;
                        }

                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingMaster:
                        if (this.GetMeisaiKamokuDictionary().TryGetValue(detail.Kicd, out Kamoku kamoku))
                        {
                            //// 科目の税率がない場合は最新の税率と比較
                            if (syouhizeiritu != null && syouhizeiritu.Id == (kamoku.Syouhizeiritu ?? this.latestSyouhizeirituOnOutputStartDate)?.Id)
                            {
                                syouhizeiritu = null;
                            }
                        }

                        break;
                    case MototyouKazeiKubunOutputType.RelativeWithComparingTitle:
                        //// 自分項目の税率がない場合は最新の税率と比較
                        if (syouhizeiritu != null && syouhizeiritu.Id == (zibunItem.ZeiKubun.Syouhizeiritu ?? this.latestSyouhizeirituOnOutputStartDate)?.Id)
                        {
                            syouhizeiritu = null;
                        }

                        break;
                }

                if (this.ikkatuZeinukiSiwakeSyuukeiType == MototyouIkkatuZeinukiSiwakeSyuukeiType.PerKamoku)
                {
                    //// 「科目ごとに集計」の場合は税率関係なし
                    syouhizeiritu = null;
                }

                return MototyouZeiKubun.CreateIkkatuZeinukiZeikubun(syouhizeiritu, siireKubun);
            }

            public virtual MototyouZeiKubun CreateZibunItemZeikubun(Kamoku kamoku)
            {
                if (this.kazeiKubunOutputType == MototyouKazeiKubunOutputType.Absolute || kamoku == null)
                {
                    return MototyouZeiKubun.CreateNullZeikubun();
                }

                var syouhizeiritu = this.convertToLatestSyouhizeirituIfZibunItemKamokuSyouhizeirituCanNotUse
                    ? this.GetLatestSyouhizeirituIfCanNotUse(kamoku.Syouhizeiritu)
                    : kamoku.Syouhizeiritu;

                if (this.useKanikazei)
                {
                    return MototyouZeiKubun.CreateKanikazeiZeikubun(syouhizeiritu, kamoku.KazeiKubun, kamoku.GyousyuKubun);
                }
                else if (this.useSiirezeigakuAnbunKobetutaiou)
                {
                    return MototyouZeiKubun.CreateSiireAnbunKobetuTaiouZeikubun(syouhizeiritu, kamoku.KazeiKubun, kamoku.GetSiwakeSiireKubun());
                }
                else
                {
                    return MototyouZeiKubun.CreateZeikubun(syouhizeiritu, kamoku.KazeiKubun);
                }
            }

            private Syouhizeiritu GetLatestSyouhizeirituIfCanNotUse(Syouhizeiritu syouhizeiritu)
            {
                if (syouhizeiritu != null
                    && !syouhizeiritu.CanUse(this.outputStartDate))
                {
                    var latest = this.syouhizeirituDictionary.GetLatestSyouhizeiritu(this.outputStartDate, syouhizeiritu.IsKeigenzeiritu);
                    if (latest != null)
                    {
                        return latest;
                    }
                }

                return syouhizeiritu;
            }

            /// <summary>
            /// 遅延Getメソッド
            /// </summary>
            /// <returns></returns>
            private IDictionary<string, Kamoku> GetMeisaiKamokuDictionary()
            {
                if (this.meisaikamokuDicitonary == null)
                {
                    var kamokus = this.kamokuRepository.FindByKesnAndKamokuKubun(this.kesn, KamokuKubun.Meisai);
                    if (this.convertToLatestSyouhizeirituIfSiwakeRowKamokuSyouhizeirituCanNotUse)
                    {
                        //// 科目数は限られているので、あらかじめ有効税率に変換しておく
                        kamokus.ForEachIfNotNull(k => k.Syouhizeiritu = this.GetLatestSyouhizeirituIfCanNotUse(k.Syouhizeiritu));
                    }

                    this.meisaikamokuDicitonary = kamokus.ToDictionary(k => k.Kicd);
                }

                return this.meisaikamokuDicitonary;
            }
        }
    }
}
