﻿namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    public interface IMototyouZeiKubunFactory
    {
        /// <summary>
        /// 元帳仕訳行の税区分を生成します
        /// </summary>
        /// <param name="row"></param>
        /// <param name="detail"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        MototyouZeiKubun CreateSiwakeRowZeikubun(ITanituSiwakeTyouhyouRow row, TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem);

        /// <summary>
        /// 税区分のNULLオブジェクトを生成します
        /// </summary>
        /// <returns></returns>
        MototyouZeiKubun CreateNullZeikubun();

        /// <summary>
        /// 一括税抜仕訳行の税区分を生成します
        /// </summary>
        /// <param name="row"></param>
        /// <param name="zibunItem"></param>
        /// <param name="siireKubun"></param>
        /// <returns></returns>
        MototyouZeiKubun CreateIkkatuZeinukiSiwakeRowZeikubun(ITanituSiwakeTyouhyouRow row, IMototyouZibunItem zibunItem, SiwakeSiireKubun? siireKubun);

        /// <summary>
        /// 自分項目の税区分を生成します
        /// </summary>
        /// <param name="kamoku"></param>
        /// <returns></returns>
        MototyouZeiKubun CreateZibunItemZeikubun(Kamoku kamoku);
    }
}
