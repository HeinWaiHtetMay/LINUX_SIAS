﻿using Icsp.Open21.Domain.SyouhizeiModel;

namespace Icsp.Open21.Domain.TyouhyouModel.Mototyou
{
    public interface IMototyouZeikubunFactoryCreator
    {
        IMototyouZeiKubunFactory Create(MototyouQueryParameter queryParameter);

        IMototyouZeiKubunFactory Create(MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern, SyouhizeiMaster syouhizeiMaster);
    }
}