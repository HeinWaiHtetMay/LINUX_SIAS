﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class TorihikisakiMototyouRepository : AbstractMototyouRepository
    {
        [AutoInjection]
        private ITorihikisakiKamokuZandakaRepository torihikisakiKamokuZandakaRepository = null;

        public override ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var torihikisakiMototyouZibunItem = (TorihikisakiMototyouZibunItem)zibunItem;
            return this.FindZandakaSyuukeihyouByQueryParameter(mototyouQueryParameter, null, null, null, null, torihikisakiMototyouZibunItem.Trcd, true, true, false);
        }

        protected override MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = base.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var kamokuTorihikisakiItem = (TorihikisakiMototyouZibunItem)zibunItem;

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = kamokuTorihikisakiItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.TrcdRangeValue.SetValue(kamokuTorihikisakiItem.Trcd, kamokuTorihikisakiItem.Trcd, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = kamokuTorihikisakiItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.TrcdRangeValue.SetValue(kamokuTorihikisakiItem.Trcd, kamokuTorihikisakiItem.Trcd, false, false);

            return siwakeTyouhyouQueryParameter;
        }

        protected override bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
        {
            var kamokuTorihikisakiItem = (TorihikisakiMototyouZibunItem)zibunItem;

            return kamokuTorihikisakiItem.Kamoku.IsIncludeKamoku(detail.Kicd)
                && detail.Trcd == kamokuTorihikisakiItem.Trcd;
        }

        protected override ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment)
        {
            var torihikisakiMototyouZibunItem = (TorihikisakiMototyouZibunItem)zibunItem;
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, null, null, torihikisakiMototyouZibunItem.Trcd, isTougetuHasseiJudgment, true, false);
            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(queryParameter, zibunItem, zandakaSyuukeihyou, !isTougetuHasseiJudgment);
        }

        protected override IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var torihikisakiMototyouZibunItem = (TorihikisakiMototyouZibunItem)zibunItem;
            var mototyouKamoku = torihikisakiMototyouZibunItem.Kamoku;

            var torihikisakiZandakaList = this.torihikisakiKamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndTorihikisakiKanaRangesOrderByTrcdAndKamokuOutputOrder(
                queryParameter.Kesn,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[0]?.Kicd,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[mototyouKamoku.MeisaiKamokuList.Count - 1]?.Kicd,
                torihikisakiMototyouZibunItem.Trcd,
                torihikisakiMototyouZibunItem.Trcd,
                null,
                null,
                Domain.MasterModel.KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                Domain.SecurityModel.SecurityKubun.Output);

            var zandakaDataList = torihikisakiZandakaList.Select(
                torihikisakiZandaka => new ZandakaTableDataForZenzanTaisyakuHasseiJudgment(torihikisakiZandaka, torihikisakiZandaka.TaisyakuZokusei, torihikisakiZandaka.Kicd)).ToList();

            return zandakaDataList ?? new List<ZandakaTableDataForZenzanTaisyakuHasseiJudgment>();
        }
    }
}
