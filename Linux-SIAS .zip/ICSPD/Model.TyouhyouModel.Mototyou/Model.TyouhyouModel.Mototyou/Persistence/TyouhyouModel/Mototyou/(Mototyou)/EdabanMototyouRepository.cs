﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class EdabanMototyouRepository : AbstractMototyouRepository
    {
        [AutoInjection]
        private IKamokuEdabanZandakaRepository kamokuEdabanZandakaRepository = null;

        public override ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var edabanMototyouZibunItem = (EdabanMototyouZibunItem)zibunItem;
            return this.FindZandakaSyuukeihyouByQueryParameter(mototyouQueryParameter, null, null, edabanMototyouZibunItem.Ecod, null, null, true, true, false);
        }

        protected override MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = base.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var kamokuEdabanItem = (EdabanMototyouZibunItem)zibunItem;

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = kamokuEdabanItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.EcodRangeValue.SetValue(kamokuEdabanItem.Ecod, kamokuEdabanItem.Ecod, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = kamokuEdabanItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.EcodRangeValue.SetValue(kamokuEdabanItem.Ecod, kamokuEdabanItem.Ecod, false, false);

            return siwakeTyouhyouQueryParameter;
        }

        protected override bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
        {
            var kamokuEdabanItem = (EdabanMototyouZibunItem)zibunItem;

            return kamokuEdabanItem.Kamoku.IsIncludeKamoku(detail.Kicd)
                && detail.Ecod == kamokuEdabanItem.Ecod;
        }

        protected override ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment)
        {
            var edabanMototyouZibunItem = (EdabanMototyouZibunItem)zibunItem;
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, edabanMototyouZibunItem.Ecod, null, null, isTougetuHasseiJudgment, true, false);
            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(queryParameter, zibunItem, zandakaSyuukeihyou, !isTougetuHasseiJudgment);
        }

        protected override IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var edabanMototyouZibunItem = (EdabanMototyouZibunItem)zibunItem;

            var edabanZandakaList = this.kamokuEdabanZandakaRepository.FindZandakaWithNameByPrimaryKeyAndEdabanKanaRangesOrderByKamokuOutputOrderAndEcod(
                queryParameter.Kesn,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || edabanMototyouZibunItem.Kamoku.MeisaiKamokuList.Count == 0 ? null : edabanMototyouZibunItem.Kamoku.MeisaiKamokuList[0]?.Kicd,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || edabanMototyouZibunItem.Kamoku.MeisaiKamokuList.Count == 0 ? null : edabanMototyouZibunItem.Kamoku.MeisaiKamokuList[edabanMototyouZibunItem.Kamoku.MeisaiKamokuList.Count - 1]?.Kicd,
                edabanMototyouZibunItem.Ecod,
                edabanMototyouZibunItem.Ecod,
                null,
                null,
                KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                Domain.SecurityModel.SecurityKubun.Output);

            var zandakaDataList = edabanZandakaList.Select(
                edabanZandaka => new ZandakaTableDataForZenzanTaisyakuHasseiJudgment(edabanZandaka, edabanZandaka.TaisyakuZokusei, edabanZandaka.Kicd)).ToList();

            return zandakaDataList ?? new List<ZandakaTableDataForZenzanTaisyakuHasseiJudgment>();
        }
    }
}
