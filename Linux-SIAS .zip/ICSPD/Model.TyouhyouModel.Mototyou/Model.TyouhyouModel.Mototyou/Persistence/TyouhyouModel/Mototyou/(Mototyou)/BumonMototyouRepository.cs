﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class BumonMototyouRepository : AbstractMototyouRepository
    {
        [AutoInjection]
        private IBumonKamokuZandakaRepository bumonKamokuZandakaRepository = null;

        public override ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var bumonMototyouZibunItem = (BumonMototyouZibunItem)zibunItem;
            return this.FindZandakaSyuukeihyouByQueryParameter(mototyouQueryParameter, null, null, null, bumonMototyouZibunItem.Bcod, null, true, true, false);
        }

        protected override MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = base.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var bumonKamokuItem = (BumonMototyouZibunItem)zibunItem;

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = bumonKamokuItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = bumonKamokuItem.Kamoku.MeisaiKamokuList;
            if (mototyouQueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.Bumon)
            {
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.BcodRangeValue.SetValue(bumonKamokuItem.Bcod, bumonKamokuItem.Bcod, false, false);
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.BcodRangeValue.SetValue(bumonKamokuItem.Bcod, bumonKamokuItem.Bcod, false, false);
            }
            else
            {
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.SetValue(bumonKamokuItem.Bcod, bumonKamokuItem.Bcod, false, false);
            }

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting = mototyouQueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.SyuukeiBumon
                ? BumonTaniOutputSetting.SyuukeiBumonRangeSitei : BumonTaniOutputSetting.BumonRangeSitei;

            return siwakeTyouhyouQueryParameter;
        }

        protected override bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
        {
            var bumonKamokuItem = (BumonMototyouZibunItem)zibunItem;

            return (detail.Bcod == bumonKamokuItem.Bcod || detail.Sbcd == bumonKamokuItem.Bcod)
                && bumonKamokuItem.Kamoku.IsIncludeKamoku(detail.Kicd);
        }

        protected override ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment)
        {
            var bumonMototyouZibunItem = (BumonMototyouZibunItem)zibunItem;
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, null, bumonMototyouZibunItem.Bcod, null, isTougetuHasseiJudgment, true, false);
            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(queryParameter, zibunItem, zandakaSyuukeihyou, !isTougetuHasseiJudgment);
        }

        protected override IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var bumonMototyouZibunItem = (BumonMototyouZibunItem)zibunItem;
            var mototyouKamoku = bumonMototyouZibunItem.Kamoku;

            var bumonZandakaList = this.bumonKamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndBumonKanaRangesOrderByBcodAndKamokuOutputOrder(
                queryParameter.Kesn,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[0]?.Kicd,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[mototyouKamoku.MeisaiKamokuList.Count - 1]?.Kicd,
                bumonMototyouZibunItem.Bcod,
                bumonMototyouZibunItem.Bcod,
                null,
                null,
                Domain.MasterModel.KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                Domain.SecurityModel.SecurityKubun.Output);

            var zandakaDataList = bumonZandakaList.Select(
                bumonZandaka => new ZandakaTableDataForZenzanTaisyakuHasseiJudgment((BumonKamokuZandakaWithName)bumonZandaka, bumonZandaka.TaisyakuZokusei, bumonZandaka.Kicd)).ToList();

            return zandakaDataList ?? new List<ZandakaTableDataForZenzanTaisyakuHasseiJudgment>();
        }
    }
}
