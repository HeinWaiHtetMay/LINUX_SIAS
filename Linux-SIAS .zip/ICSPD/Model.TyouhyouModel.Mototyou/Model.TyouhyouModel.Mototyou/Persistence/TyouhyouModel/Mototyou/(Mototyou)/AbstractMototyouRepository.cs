﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Framework.Core.Text;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.DateTimeModel;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.GaikaModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SubsystemModel;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public abstract class AbstractMototyouRepository : IMototyouRepository
    {
        [AutoInjection]
        private IMototyouLayoutPatternRepository mototyouLayoutPatternRepository = null;
        [AutoInjection]
        private ITanituSiwakeTyouhyouRowRepository tanituSiwakeTyouhyouRowRepository = null;
        [AutoInjection]
        private IKaisyaSubsystemAvailabilityRepository kaisyaSubsystemAvailabilityRepository = null;
        [AutoInjection]
        private ISyouhizeiMasterRepository syouhizeiMasterRepository = null;
        [AutoInjection]
        private IGaikaInitialSettingRepository gaikaInitialSettingRepository = null;
        [AutoInjection]
        private IZandakaSyuukeihyouRepository zandakaSyuukeihyouRepository = null;
        [AutoInjection]
        private ISokyuuSagakuCalculateOptionRepository sokyuuSagakuCalculateOptionRepository = null;
        [AutoInjection]
        private ISeiritukiCalculateOptionRepository seiritukiCalculateOptionRepository = null;
        [AutoInjection]
        private IKamokuRepository kamokuRepository = null;
        [AutoInjection]
        private ITokuteiSyuunyuuKamokuRepository tokuteiSyuunyuuKamokuRepository = null;
        [AutoInjection]
        private IMototyouZeikubunFactoryCreator zeikubunFactoryCreator = null;
        [AutoInjection]
        private ISiwakeOutputOptionRepository siwakeOutputOptionRepository = null;

        public virtual Mototyou FindByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            //// レイアウトパターン取得
            var mototyouLayoutPattern = this.mototyouLayoutPatternRepository.FindByPatternNo(mototyouQueryParameter.OptionComposite.QueryOption.LayoutPatternNo.Value);

            return this.FindByQueryParameterAndItem(mototyouQueryParameter, zibunItem, mototyouLayoutPattern);
        }

        public virtual Mototyou FindSonekiKanzyouMototyouByQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var layoutPattern = this.mototyouLayoutPatternRepository.FindByPatternNo(mototyouQueryParameter.OptionComposite.QueryOption.LayoutPatternNo.Value);
            var mototyou = this.CreateMototyou(zibunItem, layoutPattern);
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(
                mototyouQueryParameter,
                null,
                null,
                null,
                mototyouQueryParameter.OptionComposite.QueryOption.MototyouType == MototyouType.Mototyou ? null : ((BumonMototyouZibunItem)zibunItem).Bcod,
                null,
                false,
                false,
                true);
            var outputSonekiZandakaRowList = zandakaSyuukeihyou.ZandakaSyuukeihyouRowList.Where(row =>
            row.RowType == ZandakaSyuukeihyouRowType.Meisai && ((row.Kicd.CompareTo("100000000000000") >= 0 && row.Kicd.CompareTo("160029999999999") <= 0) || row.Kicd.StartsWith("210")));
            var aiteKamokuNameForPrintItem = layoutPattern.Items.FirstOrDefault(item => item.ItemType == MototyouLayoutItemType.Kamoku && ((MototyouLayoutMasterDataItem)item).MasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteLongName);
            foreach (var zandakaRow in outputSonekiZandakaRowList)
            {
                if (zandakaRow.KarikataTougetuZandaka != null || zandakaRow.KasikataTougetuZandaka != null)
                {
                    var sonekiKanzyouRow = new MototyouSiwakeRow(mototyou, layoutPattern.ColumnCount, layoutPattern.RowCount);
                    var aiteKamokuLongNameInLayoutItems = layoutPattern.Items.OfType<MototyouLayoutMasterDataItem>().FirstOrDefault(item => item.ItemType == MototyouLayoutItemType.Kamoku && item.MasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteLongName);
                    if (aiteKamokuLongNameInLayoutItems != null)
                    {
                        sonekiKanzyouRow.SetCellItem(aiteKamokuLongNameInLayoutItems, zandakaRow.KamokuName);
                    }

                    sonekiKanzyouRow.IsSeirituki = mototyouQueryParameter.StartSyorituki.SeiritukiId == SeiritukiId.Fourth
                                        || mototyouQueryParameter.SeiritukiCalculateOption.GetOptionFlag(mototyouQueryParameter.Kesn, mototyouQueryParameter.UseUserSeiritukiCalculateOption, SeiritukiId.Fourth) == SeiritukiCalculateOptionFlag.SeparateSyorituki;
                    sonekiKanzyouRow.DenpyouDate = mototyouQueryParameter.EndSyorituki.EndDate;
                    sonekiKanzyouRow.IsEnabledDenpyouKakunin = false;
                    sonekiKanzyouRow.KarikataValue = zandakaRow.KarikataTougetuZandaka;
                    sonekiKanzyouRow.KasikataValue = zandakaRow.KasikataTougetuZandaka;
                    mototyou.AddRow(sonekiKanzyouRow);
                }
            }

            var hurikaeKingaku = outputSonekiZandakaRowList.Sum(row => row.KasikataTougetuZandaka ?? 0) - outputSonekiZandakaRowList.Sum(row => row.KarikataTougetuZandaka ?? 0);
            var mototyouHurikaeRow = new MototyouSonekiHurikaeRow(mototyou, zibunItem, true);
            if (hurikaeKingaku >= 0)
            {
                mototyouHurikaeRow.KarikataValue = hurikaeKingaku;
            }
            else
            {
                mototyouHurikaeRow.KasikataValue = -hurikaeKingaku;
            }

            if (mototyou.MototyouRows.Count() == 0)
            {
                //// 明細行が１行も存在しない場合は振替行に日付を表示する
                mototyouHurikaeRow.DisplayDate = mototyouQueryParameter.EndSyorituki.EndDate;
            }

            mototyou.AddRow(mototyouHurikaeRow);
            var goukeiRow = new MototyouSiwakeRow(mototyou, layoutPattern.ColumnCount, layoutPattern.RowCount);
            goukeiRow.KarikataValue = mototyou.KarikataTotal;
            goukeiRow.KasikataValue = mototyou.KasikataTotal;
            goukeiRow.SasihikiZandaka = 0;
            mototyou.AddRow(goukeiRow);
            return mototyou;
        }

        public virtual Mototyou FindByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, MototyouLayoutPattern mototyouLayoutPattern)
        {
            //// 元帳インスタンス生成
            var mototyou = this.CreateMototyou(zibunItem, mototyouLayoutPattern);

            //// 前○繰越行
            if (this.IsOutputMaezanRow(mototyouQueryParameter, zibunItem))
            {
                var zandakaRow = this.GetZandakaSyuukeihyouRowByMototyouQueryParameter(mototyouQueryParameter, zibunItem, false);
                this.AddMaeKurikosiRows(mototyou, mototyouQueryParameter, zandakaRow);
            }

            //// 仕訳データ取得
            var siwakeTyouhyouQueryParameter = this.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var tanituSiwakeTyouhyouRows = this.GetTanituSiwakeTyouhyouRowsList(siwakeTyouhyouQueryParameter);

            //// 仕訳のソート
            var tanituSiwakeTyouhyouRowsSorted = this.GetSortedTanituSiwakeTyouhouRows(tanituSiwakeTyouhyouRows, mototyouQueryParameter, zibunItem);
            if (mototyouQueryParameter.OptionComposite.QueryOption.SyuukeiKeisiki == MototyouSyuukeiKeisiki.Detail
                && mototyouQueryParameter.OptionComposite.Option.HukugoukeisikiAiteKamokuJudgmentType != MototyouHukugoukeisikiAiteKamokuJudgmentType.AiteInSiwakeList
                && ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd != "000000000001001")
            {
                //// 複合形式の相手科目
                this.ChangeSiwakeAiteKamokuAsMototyouHukugouKeisikiAiteKamokuJudgmentType(tanituSiwakeTyouhyouRowsSorted, mototyouQueryParameter, zibunItem, siwakeTyouhyouQueryParameter);
            }

            //// 元帳の仕訳行（月度計、累計行(翌○繰越の後に出力する場合のみ除く)もここでセット）
            this.AddMototyouRows(mototyou, mototyouQueryParameter, mototyouLayoutPattern, tanituSiwakeTyouhyouRowsSorted, zibunItem, mototyouQueryParameter.KaisyaSyoriKikan.Syoriki);

            //// メモリ使用量削減対応
            tanituSiwakeTyouhyouRows?.Clear();
            tanituSiwakeTyouhyouRowsSorted?.Clear();
            GC.Collect();

            //// 翌○繰越行
            this.AddYokuKurikosiRows(mototyou, mototyouQueryParameter, zibunItem);

            if (this.IsSonekiHurikae(mototyouQueryParameter, zibunItem) && !((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050020"))
            {
                //// 損益勘定振替行（繰越利益剰余金は当期純利益を仕訳として出力するので損益振替行は出力しない）
                this.AddSonekiHurikaeRow(mototyou, mototyouQueryParameter, zibunItem);
            }

            if (mototyouQueryParameter.OptionComposite.Option.RuikeiOutputType == MototyouRuikeiOutputType.OutputAfterNextKurikosi)
            {
                //// 累計行（翌○繰越の後に出力する場合）
                this.SetMototyouRuikeiRow(mototyou, true);
            }

            return mototyou;
        }

        /// <summary>
        /// 当月発生があるかどうか
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyou">「判定方法：貸借発生」の場合に使用</param>
        /// <returns></returns>
        public bool GetExistsTougetuHasseiByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyou)
        {
            if (mototyouQueryParameter.OptionComposite.Option.TougetuHasseiJudgmentType == MototyouTougetuHasseiJudgmentType.TaisyakuHassei)
            {
                // 当月発生：貸借発生
                return this.GetExistsTougetuHasseiWhenMototyouTougetuHasseiJudgmentTypeIsTaisyakuHassei(mototyouQueryParameter, zibunItem, zandakaSyuukeihyou);
            }
            else
            {
                // 当月発生：仕訳の有無
                if (this.IsSonekiHurikae(mototyouQueryParameter, zibunItem) && ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050020"))
                {
                    //// 損益振替をする、かつ自分項目が繰越利益剰余金の場合、「○期純利益（損失）」行が存在するため仕訳有りと判断する
                    return true;
                }

                var siwakeTyouhyouQueryParameter = this.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
                return this.tanituSiwakeTyouhyouRowRepository.GetExistsByQuertyParameter(siwakeTyouhyouQueryParameter);
            }
        }

        public abstract ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem);

        /// <summary>
        /// 前残または当月発生があるかどうか
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyouForJudgment"></param>
        /// <returns></returns>
        public bool GetExistsMaezanOrTougetuHasseiByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyouForJudgment)
        {
            return this.GetExistsTougetuHasseiByQueryParameterAndItem(mototyouQueryParameter, zibunItem, zandakaSyuukeihyouForJudgment)
                || this.GetExistsMaezanByQueryParameterAndItem(mototyouQueryParameter, zibunItem, zandakaSyuukeihyouForJudgment);
        }

        public bool GetExistsMaezanByQueryParameterAndItem(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyou)
        {
            if (mototyouQueryParameter.OptionComposite.Option.ZenzanJudgmentType == MototyouZenzanJudgmentType.TaisyakuHasseiWithConsiderationKisyu
                || mototyouQueryParameter.OptionComposite.Option.ZenzanJudgmentType == MototyouZenzanJudgmentType.TaisyakuHasseiWithoutConsiderationKisyu)
            {
                // 前残の判定：貸借発生（期首を考慮する/しない）
                if (mototyouQueryParameter.SeiritukiCalculateOption.NeedCalculateSimoki(mototyouQueryParameter.KaisyaSyoriKikan)
                    && mototyouQueryParameter.StartCkei == 70
                    && this.IsSonekiKamoku(mototyouQueryParameter, zibunItem))
                {
                    //// 下期計算・開始月が第7経過月・PL科目である場合は前残なしと判断する
                    return false;
                }

                if (mototyouQueryParameter.StartCkei == 10
                    && mototyouQueryParameter.OptionComposite.Option.ZenzanJudgmentType == MototyouZenzanJudgmentType.TaisyakuHasseiWithoutConsiderationKisyu)
                {
                    //// 開始月が第1経過月・期首を考慮しない場合は前残なしと判断する
                    return false;
                }

                var zandakaDataDictionary = this.GetZandakaDataDictionaryByMototyouQueryParameter(mototyouQueryParameter, zibunItem);
                return zandakaDataDictionary[KamokuTaisyakuZokusei.Karikata].FirstOrDefault(zandaka => zandaka != 0) != 0
                    || zandakaDataDictionary[KamokuTaisyakuZokusei.Kasikata].FirstOrDefault(zandaka => zandaka != 0) != 0;
            }
            else
            {
                // 前残の判定：繰越残高
                var zandakaRow = this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(mototyouQueryParameter, zibunItem, zandakaSyuukeihyou, true);
                return this.GetMaeKurikosiRowType(mototyouQueryParameter) == MototyouMaeKurikosiRow.MaeKurikosiRowType.Zenki
                    ? (zandakaRow?.ZengetuZandaka ?? 0) != 0
                    : (zandakaRow?.TougetuZandaka ?? 0) != 0;
            }
        }

        /// <summary>
        /// 前○繰越行を出力するかどうか
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        public bool IsOutputMaezanRow(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            //// 【注意】if文の順序変更不可
            if (mototyouQueryParameter.QueryCondition.StartDate != null
                && mototyouQueryParameter.QueryCondition.StartDate.Ymd != mototyouQueryParameter.KaisyaSyoriKikan.StartSyorituki.StartDate.Ymd)
            {
                //// 開始日の指定がされており、開始日が該当月の開始年月日と異なる場合は出力する
                return true;
            }

            if (mototyouQueryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei == mototyouQueryParameter.Syoriki.GetFirstSyorituki(false).Ckei
                || (mototyouQueryParameter.SeiritukiCalculateOption.NeedCalculateSimoki(mototyouQueryParameter.KaisyaSyoriKikan) && mototyouQueryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei == 70))
            {
                //// 1ヶ月目を出力する場合、または下期計算で7ヶ月目を出力する場合、損益科目は前期繰越を出力しない
                if (this.IsSonekiKamoku(mototyouQueryParameter, zibunItem))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 損益振替するかどうか
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        public bool IsSonekiHurikae(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            if (queryParameter.QueryCondition.SonekiHurikaeType == MototyouSonekiHurikaeType.NotUse
                || (queryParameter.OptionComposite.QueryOption.MototyouType != MototyouType.Mototyou && queryParameter.OptionComposite.QueryOption.MototyouType != MototyouType.BumonMototyou)
                || queryParameter.OptionComposite.QueryOption.IsSyuukeiBumon
                || (queryParameter.QueryCondition.EndDate != null && queryParameter.QueryCondition.EndDate != queryParameter.EndSyorituki.EndDate)
                || !(this.IsSonekiKamoku(queryParameter, zibunItem) || ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050")))
            {
                //// オプション設定＞損益振替しない、元帳種類が科目・部門以外、集計部門、指定した終了日が指定月の終了日と異なる、自分項目がPL科目または前期繰越損益または繰越利益剰余金でない場合は、選択月に関わらずfalse
                return false;
            }

            //// 終了月が決算整理月または、下期計算設定かつ中間整理月
            return queryParameter.EndSyorituki.SeiritukiId == SeiritukiId.Fourth
                || (queryParameter.EndSyorituki.SeiritukiId == SeiritukiId.Second && queryParameter.SeiritukiCalculateOption.ZadakaCalclationAfter7thMonth == SeiritukiCalculateOptionZadakaAfter7thMonthFlag.Simoki);
        }

        protected abstract IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem);

        /// <summary>
        /// TanituSiwakeTyouhyouRowRepositoryを利用するためのクラス作成
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        protected virtual MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = new MototyouSiwakeTyouhyouQueryParameter(queryParameter, () => this.gaikaInitialSettingRepository?.FindByKesn(queryParameter.Kesn), this.siwakeOutputOptionRepository.Find());

            siwakeTyouhyouQueryParameter.SetSiwakeTyouhyouRowItemAvailability(
                this.kaisyaSubsystemAvailabilityRepository?.FindByCcodAndSubid(queryParameter.KaisyaSyoriKikan.Syoriki.Ccod, SubsystemId.Gaika),
                this.syouhizeiMasterRepository.FindByKesn(queryParameter.KaisyaSyoriKikan.Syoriki.Kesn),
                true);
            return siwakeTyouhyouQueryParameter;
        }

        protected virtual void AddMototyouRows(Mototyou mototyou, MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern, IList<ITanituSiwakeTyouhyouRow> tanituSiwakeTyouhyouRows, IMototyouZibunItem zibunItem, Syoriki syoriki)
        {
            //// 月度計を出力する設定か、もしくは範囲が複数月なら月度計を出力する
            var useMonthlyTotal = queryParameter.OptionComposite.Option.MonthlyTotal == MototyouMonthlyTotal.Exists
                || queryParameter.IsMultiSyorituki;
            //// 月ごとにグループ化(反映しない設定の整理月はKey = -1)
            var monthlyRowGroups = tanituSiwakeTyouhyouRows.GroupBy(row => this.GetGroupKeyDkei(row.Dkei, queryParameter)).Where(group => group.Key >= 0);

            //// 集計形式別で行作成
            switch (mototyou.ZibunItem.SyuukeiKeisiki)
            {
                case MototyouSyuukeiKeisiki.Detail:
                    this.SetMototyouSiwakeRows(mototyou, layoutPattern, monthlyRowGroups, zibunItem, queryParameter, useMonthlyTotal);
                    break;
                case MototyouSyuukeiKeisiki.Daily:
                    this.SetMototyouDailyRows(mototyou, monthlyRowGroups, zibunItem, queryParameter, useMonthlyTotal);
                    break;
                case MototyouSyuukeiKeisiki.Monthly:
                    this.SetMototyouMonthlyRows(mototyou, monthlyRowGroups, zibunItem, queryParameter);
                    break;
            }

            if (queryParameter.OptionComposite.Option.RuikeiOutputType == MototyouRuikeiOutputType.OutputBeforeNextKurikosi)
            {
                //// 累計行（翌○繰越の前に出力する場合）
                this.SetMototyouRuikeiRow(mototyou, false);
            }

            mototyou.AddRow(null);
        }

        protected virtual void AddMaeKurikosiRows(Mototyou mototyou, MototyouQueryParameter queryParameter, ZandakaSyuukeihyouRow zandakaRow)
        {
            var maezanType = this.GetMaeKurikosiRowType(queryParameter);
            var maeKurikosiRow = new MototyouMaeKurikosiRow(mototyou, maezanType);
            //// 前期繰越との差額を出力するかどうか
            var isOutputZenkiKurikosiSagakuRow = maezanType == MototyouMaeKurikosiRow.MaeKurikosiRowType.Zenki
                && queryParameter.QueryCondition.OutputSagakuOnZenkiKurikosi
                && queryParameter.Syoriki.SyorikiId != SyorikiId.Yokuki //// 翌期の場合は「差額なし」と判断
                && queryParameter.ZennenSyoriki != null; //// 前年が存在しない場合は「差額なし」と判断
            if (isOutputZenkiKurikosiSagakuRow)
            {
                var zennenKimatuZandakaRow = this.GetZennenKimatuZandakaRow(mototyou, queryParameter);
                //// 差額がある場合
                if (zennenKimatuZandakaRow?.TougetuZandaka != zandakaRow?.ZengetuZandaka)
                {
                    var sokyuuSagakuCalculateOption = this.sokyuuSagakuCalculateOptionRepository.Find();
                    //// 前期繰越行（前年の期末残高を出力）
                    maeKurikosiRow.StartDate = queryParameter.QueryCondition.StartDate ?? queryParameter.KaisyaSyoriKikan.StartDate;
                    maeKurikosiRow.SasihikiZandaka = zennenKimatuZandakaRow?.TougetuZandaka ?? 0;
                    mototyou.AddRow(maeKurikosiRow);
                    //// 過年度遡及による累積的影響額行（差額を借方または貸方に出力）
                    var sagakuTekiyouRow = new MototyouMaeKurikosiRow(mototyou, MototyouMaeKurikosiRow.MaeKurikosiRowType.ZenkiKurikosiSagaku, sokyuuSagakuCalculateOption.MototyouTekiyouOfSagakuRow);
                    sagakuTekiyouRow.StartDate = queryParameter.QueryCondition.StartDate ?? queryParameter.KaisyaSyoriKikan.StartDate;
                    sagakuTekiyouRow.ZenkiKurikosiSagaku = zandakaRow?.ZengetuZandaka ?? 0 - zennenKimatuZandakaRow?.TougetuZandaka ?? 0;
                    mototyou.AddRow(sagakuTekiyouRow);
                    //// 遡及処理後前期繰越行（当年の期首残高を出力）
                    var zenkiKurikosiAfterSokyuuSyoriRow = new MototyouMaeKurikosiRow(mototyou, MototyouMaeKurikosiRow.MaeKurikosiRowType.SokyuuTekiyou, sokyuuSagakuCalculateOption.MototyouTekiyouOfZenkiKurikosi);
                    zenkiKurikosiAfterSokyuuSyoriRow.StartDate = queryParameter.QueryCondition.StartDate ?? queryParameter.KaisyaSyoriKikan.StartDate;
                    zenkiKurikosiAfterSokyuuSyoriRow.SasihikiZandaka = zandakaRow?.ZengetuZandaka ?? 0;
                    zenkiKurikosiAfterSokyuuSyoriRow.KarikataValue = zandakaRow?.KarikataRuikei ?? 0;
                    zenkiKurikosiAfterSokyuuSyoriRow.KasikataValue = zandakaRow?.KasikataRuikei ?? 0;
                    //// 前○借方金額、前○貸方金額をセット（累計計算用）
                    mototyou.MaeKarikataZandaka = zandakaRow?.KarikataRuikei ?? 0;
                    mototyou.MaeKasikataZandaka = zandakaRow?.KasikataRuikei ?? 0;
                    mototyou.AddRow(zenkiKurikosiAfterSokyuuSyoriRow);
                    return;
                }
            }

            //// 前期繰越との差額を出力しない場合、もしくは差額なしの場合の通常前○繰越行
            maeKurikosiRow.StartDate = queryParameter.QueryCondition.StartDate ?? queryParameter.KaisyaSyoriKikan.StartDate;
            maeKurikosiRow.SasihikiZandaka = zandakaRow.ZengetuZandaka ?? 0;
            maeKurikosiRow.KarikataValue = zandakaRow?.KarikataRuikei ?? 0;
            maeKurikosiRow.KasikataValue = zandakaRow?.KasikataRuikei ?? 0;
            maeKurikosiRow.IsSeirituki = queryParameter.KaisyaSyoriKikan.StartSyorituki.IsSeirituki;
            //// 前○借方金額、前○貸方金額をセット（累計計算用）
            mototyou.MaeKarikataZandaka = zandakaRow?.KarikataRuikei ?? 0;
            mototyou.MaeKasikataZandaka = zandakaRow?.KasikataRuikei ?? 0;
            mototyou.AddRow(maeKurikosiRow);
        }

        protected virtual void AddYokuKurikosiRows(Mototyou mototyou, MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var yokuzanType = new Func<MototyouYokuKurikosiRow.YokuKurikosiType>(() =>
            {
                if (queryParameter.QueryCondition.EndDate != null && queryParameter.QueryCondition.EndDate != queryParameter.EndSyorituki.EndDate)
                {
                    return MototyouYokuKurikosiRow.YokuKurikosiType.Yokuzitu;
                }
                else if (queryParameter.EndCkei == queryParameter.Syoriki.GetSyoriKikan().EndSyorituki.Ckei
                         || (queryParameter.EndCkei == queryParameter.Syoriki.GetLastNormalSyorituki().Ckei && queryParameter.GetSeiritukiCalculateOptionFlag(queryParameter.EndCkei) == SeiritukiCalculateOptionFlag.IncludeSyorituki))
                {
                    //// 処理期の最終月（決算整理月が存在しない場合は通常最終月、決算整理月が存在する場合は決算整理月または決算整理月を含める設定の通常最終月）を選択している場合
                    return MototyouYokuKurikosiRow.YokuKurikosiType.Yokuki;
                }
                else if (queryParameter.SeiritukiCalculateOption.ZadakaCalclationAfter7thMonth == SeiritukiCalculateOptionZadakaAfter7thMonthFlag.Simoki
                 && (queryParameter.EndCkei == (queryParameter.Syoriki.GetQuarterEndNormalSyorituki(SihankiId.Second).GetSeirituki()?.Ckei ?? 0)
                             || (queryParameter.EndCkei == queryParameter.Syoriki.GetQuarterEndNormalSyorituki(SihankiId.Second).Ckei && queryParameter.GetSeiritukiCalculateOptionFlag(queryParameter.EndCkei) == SeiritukiCalculateOptionFlag.IncludeSyorituki)))
                {
                    //// 上期末月（中間整理月が存在しない場合は通常上期末月、中間整理月が存在する場合は中間整理月または中間整理月を含める設定の上期末月）を選択している場合
                    return MototyouYokuKurikosiRow.YokuKurikosiType.Simoki;
                }
                else
                {
                    return MototyouYokuKurikosiRow.YokuKurikosiType.Yokugetu;
                }
            }).Invoke();

            //// 翌○繰越行の追加
            var yokuKurikosiRow = new MototyouYokuKurikosiRow(mototyou, yokuzanType, this.IsSonekiKamoku(queryParameter, zibunItem));
            this.SetMototyouYokuKurikosiRow(mototyou, queryParameter, yokuKurikosiRow);
            mototyou.AddRow(yokuKurikosiRow);
        }

        protected virtual void AddSonekiHurikaeRow(Mototyou mototyou, MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            //// 振替金額（翌○繰越の差引残高）
            var hurikaeKingaku = mototyou.MototyouRows[mototyou.MototyouRows.Count - 1].SasihikiZandaka;
            if (hurikaeKingaku == 0)
            {
                //// 損益が0となる場合は振替行は出力しない
                return;
            }

            var sonekiHurikaeRow = new MototyouSonekiHurikaeRow(mototyou, zibunItem, false);
            if (zibunItem.TaisyakuZokusei == KamokuTaisyakuZokusei.Kasikata)
            {
                sonekiHurikaeRow.KarikataValue = hurikaeKingaku >= 0 ? hurikaeKingaku : null;
                sonekiHurikaeRow.KasikataValue = hurikaeKingaku < 0 ? -hurikaeKingaku : null;
            }
            else
            {
                sonekiHurikaeRow.KarikataValue = hurikaeKingaku < 0 ? -hurikaeKingaku : null;
                sonekiHurikaeRow.KasikataValue = hurikaeKingaku >= 0 ? hurikaeKingaku : null;
            }

            //// 差引残高は0固定
            sonekiHurikaeRow.SasihikiZandaka = 0;
            mototyou.AddRow(sonekiHurikaeRow);
        }

        /// <summary>
        /// 指定した借方もしくは貸方が自分項目と一致するかどうか
        /// </summary>
        /// <param name="detail"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        protected abstract bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem);

        protected abstract ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment);

        protected virtual ZandakaSyuukeihyou FindZandakaSyuukeihyouByQueryParameter(
            MototyouQueryParameter queryParameter,
            Kamoku startKamoku,
            Kamoku endKamoku,
            string zibunEdabanCode,
            string zibunBumonCode,
            string zibunTorihikisakiCode,
            bool isTougetuHasseiJudgment,
            bool isCheckZaimuKamokuCodeSecurity,
            bool isSonekiKanzyouMototyou)
        {
            //// 開始日が指定されており、開始日が該当月の開始年月日と異なる場合
            var isDailyKurikosi = queryParameter.QueryCondition.StartDate != null
                                && queryParameter.QueryCondition.StartDate.Ymd != queryParameter.KaisyaSyoriKikan.StartSyorituki.StartDate.Ymd;
            var zandakaType = this.GetZandakaSyuukeihyouType(queryParameter.OptionComposite.QueryOption.MototyouType);
            var zandakaSyuukeihyouQueryOptionDetail = new ZandakaSyuukeihyouQueryOptionDetail(zandakaType)
            {
                SyuukeiTani = isTougetuHasseiJudgment
                     ? ZandakaSyuukeihyouSyuukeiTani.Monthly
                     : isDailyKurikosi
                         ? ZandakaSyuukeihyouSyuukeiTani.Daily
                         : ZandakaSyuukeihyouSyuukeiTani.Monthly,
                HaniSitei = ZandakaSyuukeihyouHaniSitei.SpecifyRange, // 範囲指定
                SyuturyokuZyouken = ZandakaSyuukeihyouSyuturyokuZyouken.All,
            };
            var zandakaSyuukeihyouQueryValues = new ZandakaSyuukeihyouQueryValues(
                queryParameter.KaisyaSyoriKikan,
                queryParameter.QueryCondition.StartDate,
                queryParameter.QueryCondition.EndDate,
                startKamoku,
                endKamoku,
                zibunEdabanCode,
                zibunEdabanCode,
                zibunBumonCode,
                zibunBumonCode,
                zibunTorihikisakiCode,
                zibunTorihikisakiCode);
            var zandakaSyuukeihyouQueryOption = new ZandakaSyuukeihyouQueryOption()
            {
                SeiritukiSettei = queryParameter.UseUserSeiritukiCalculateOption ? ZandakaSyuukeihyouSeiritukiSettei.UserSettei : ZandakaSyuukeihyouSeiritukiSettei.KaisyaSettei,
                ZandakaSyuukeihyouQueryOptionDetailDictionary = new Dictionary<ZandakaSyuukeihyouType, ZandakaSyuukeihyouQueryOptionDetail>()
                {
                    { zandakaType, zandakaSyuukeihyouQueryOptionDetail }
                },
                SyuturyokuHouhouOfEdaban = ZandakaSyuukeihyouSyuturyokuHouhouOfEdaban.Edaban,
                SyuturyokuHouhouOfBumon = queryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.Bumon ? ZandakaSyuukeihyouSyuturyokuHouhouOfBumon.Bumon : ZandakaSyuukeihyouSyuturyokuHouhouOfBumon.SyuukeiBumon,
                SyuturyokuHouhouOfBumonKamokuEdaban = queryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.Bumon ? ZandakaSyuukeihyouSyuturyokuHouhouOfBumonKamokuEdaban.Bumon : ZandakaSyuukeihyouSyuturyokuHouhouOfBumonKamokuEdaban.SyuukeiBumon,
                SyuturyokuHouhouOfTorihikisaki = ZandakaSyuukeihyouSyuturyokuHouhouOfTorihikisaki.Torihikisaki,
                SyuturyokuHouhouOfBumonKamokuTorihikisaki = queryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.Bumon ? ZandakaSyuukeihyouSyuturyokuHouhouOfBumonKamokuTorihikisaki.Bumon : ZandakaSyuukeihyouSyuturyokuHouhouOfBumonKamokuTorihikisaki.SyuukeiBumon,
                SyuturyokuZyunzyoOfEdaban = ZandakaSyuukeihyouSyuturyokuZyunzyoOfEdaban.EdabanKamokuZyun,
                SyuturyokuZyunzyoOfBumon = ZandakaSyuukeihyouSyuturyokuZyunzyoOfBumon.BumonKamokuZyun,
                SyuturyokuZyunzyoOfBumonKamokuEdaban = ZandakaSyuukeihyouSyuturyokuZyunzyoOfBumonKamokuEdaban.BumonEdabanKamokuZyun,
                SyuturyokuZyunzyoOfTorihikisaki = ZandakaSyuukeihyouSyuturyokuZyunzyoOfTorihikisaki.TorihikisakiKamokuZyun,
                SyuturyokuZyunzyoOfBumonKamokuTorihikisaki = ZandakaSyuukeihyouSyuturyokuZyunzyoOfBumonKamokuTorihikisaki.BumonTorihikisakiKamoku,
            };
            var syuukeiSiteiOptionDetail = new ZandakaSyuukeihyouSyuukeiSiteiOptionDetail(zandakaType)
            {
                CalculateTotalBySyuukeiSyouKamoku = queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyuukeiSyouKamoku
                 ? ZandakaSyuukeihyouCalculateTotalByKamokuKubun.CalculateTotal
                 : ZandakaSyuukeihyouCalculateTotalByKamokuKubun.NotCalculateTotal,
                CalculateTotalBySyouKamoku = queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.SyouKamoku
                 ? ZandakaSyuukeihyouCalculateTotalByKamokuKubun.CalculateTotal
                 : ZandakaSyuukeihyouCalculateTotalByKamokuKubun.NotCalculateTotal,
            };
            var kaisyaSyoriKikan = new KaisyaSyoriKikan(
                queryParameter.KaisyaSyoriKikan.Syoriki,
                queryParameter.KaisyaSyoriKikan.StartSyorituki,
                queryParameter.KaisyaSyoriKikan.EndSyorituki);
            kaisyaSyoriKikan.Syoriki.KamokuOutputOrder = KamokuOutputOrder.ByInnerCode; //// 集計小科目の計をとるため内部コード順に変更
            var zandakaSyuukeihyouQueryCondition = new ZandakaSyuukeihyouQueryCondition(
                kaisyaSyoriKikan,
                queryParameter.CurrentKaisya,
                queryParameter.User,
                zandakaType,
                new ZandakaSyuukeihyouOutputOption() { RuikeiVisible = RuikeiVisible.RuikeiVisible, },
                zandakaSyuukeihyouQueryOption,
                new ZandakaSyuukeihyouSyuukeiSiteiOption() { ZandakaSyuukeihyouSyuukeiSiteiOptionDetailDictionary = new Dictionary<ZandakaSyuukeihyouType, ZandakaSyuukeihyouSyuukeiSiteiOptionDetail>() { { zandakaType, syuukeiSiteiOptionDetail } } },
                zandakaSyuukeihyouQueryValues,
                null,
                queryParameter.SecurityContext,
                queryParameter.MitenkiDataQueryContext.QueryOption as MitenkiDataQueryOption,
                new ZandakaSyuukeihyouScenarioOption(),
                queryParameter.SeiritukiCalculateOption,
                null,
                isSonekiKanzyouMototyou ? queryParameter.OptionComposite.Option.KamokuOutputOrder.GetKamokuOutputOrder(queryParameter.Syoriki) : KamokuOutputOrder.ByInnerCode);

            //// 元帳は累計金額の計算期間を期首月～処理期間の前月までにする
            zandakaSyuukeihyouQueryCondition.IsCalculateRuikeiBetweenKisyuzukiAndPreiviousStartSyorituki = true;
            //// 科目コードのセキュリティチェックを行うかどうか
            zandakaSyuukeihyouQueryCondition.IsCheckZaimuKamokuCodeSecurity = isCheckZaimuKamokuCodeSecurity;
            //// 元帳は棚卸振替を行わない
            zandakaSyuukeihyouQueryCondition.IsCalculateTanaorosiHurikae = false;
            //// 元帳は利益計算しない
            zandakaSyuukeihyouQueryCondition.IsCalculateRieki = false;
            var siteiMasterForQuery = new ZandakaSyuukeihyouSiteiMasterForQuery(zandakaSyuukeihyouQueryCondition);
            siteiMasterForQuery.MasterCode1 = this.GetMasterCode(siteiMasterForQuery.MasterType1, zibunEdabanCode, zibunBumonCode, zibunTorihikisakiCode);
            siteiMasterForQuery.MasterCode2 = this.GetMasterCode(siteiMasterForQuery.MasterType2, zibunEdabanCode, zibunBumonCode, zibunTorihikisakiCode);
            zandakaSyuukeihyouQueryCondition.SiteiMaster = siteiMasterForQuery;
            var zandakaSyuukeihyou = this.zandakaSyuukeihyouRepository.FindByQueryCondition(zandakaSyuukeihyouQueryCondition);
            return zandakaSyuukeihyou;
        }

        protected IDictionary<KamokuTaisyakuZokusei, IList<decimal>> GetZandakaDataDictionaryByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var zandakaDataList = this.GetZandakaTableDataList(queryParameter, zibunItem);
            var zibunKamoku = ((KamokuMototyouZibunItem)zibunItem).Kamoku;
            var zandaka = new KamokuZandakaWithName(queryParameter.Kesn, zibunKamoku.Kicd);
            if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku)
            {
                //// 規則外集計科目
                foreach (var meisaiKamoku in zibunKamoku.MeisaiKamokuList)
                {
                    var zandakaData = zandakaDataList.FirstOrDefault(zan => zan.Kicd == meisaiKamoku.Kicd);
                    if (zandakaData != null)
                    {
                        if (zibunKamoku.TaisyakuZokusei == zandakaData.TaisyakuZokusei)
                        {
                            zandaka.AddKingakuAllKeikazuki(zandakaData.Zandaka);
                        }
                        else
                        {
                            zandaka.SubKingakuAllKeikazuki(zandakaData.Zandaka);
                        }
                    }
                }
            }
            else
            {
                //// 集計小科目・小科目・明細科目
                foreach (var zan in zandakaDataList)
                {
                    zandaka.AddKingakuAllKeikazuki(zan.Zandaka);
                }
            }

            var dictionary = new Dictionary<KamokuTaisyakuZokusei, IList<decimal>>();
            dictionary.Add(KamokuTaisyakuZokusei.Karikata, this.GetZandakaKingakuList(queryParameter, zandaka, true, this.IsSonekiKamoku(queryParameter, zibunItem)));
            dictionary.Add(KamokuTaisyakuZokusei.Kasikata, this.GetZandakaKingakuList(queryParameter, zandaka, false, this.IsSonekiKamoku(queryParameter, zibunItem)));
            return dictionary;
        }

        protected ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyou, bool isGetForZenzan)
        {
            var zibunKamoku = ((KamokuMototyouZibunItem)zibunItem).Kamoku;
            ZandakaSyuukeihyouRow zandakaRow = null;
            if (queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku)
            {
                zandakaRow = new ZandakaSyuukeihyouRow(ZandakaSyuukeihyouRowType.Meisai)
                {
                    ZengetuZandaka = 0,
                    TougetuZandaka = 0,
                    KarikataHassei = 0,
                    KasikataHassei = 0,
                    KarikataRuikei = 0,
                    KasikataRuikei = 0,
                    SagakuRuikei = 0,
                    HasseiSagaku = 0,
                    KarikataTougetuZandaka = 0,
                    KasikataTougetuZandaka = 0,
                };

                if (isGetForZenzan && zibunKamoku.Kicd == "999023000000000")
                {
                    //// 規則外集計科目の「内当月損益」の前残は常に0を出力する
                    return zandakaRow;
                }

                foreach (var meisaiKamoku in zibunKamoku.MeisaiKamokuList)
                {
                    var meisaiRow = zandakaSyuukeihyou.ZandakaSyuukeihyouRowList.FirstOrDefault(row => row.Kicd == meisaiKamoku.Kicd);
                    if (meisaiRow != null)
                    {
                        if (meisaiKamoku.TaisyakuZokusei == zibunKamoku.TaisyakuZokusei)
                        {
                            zandakaRow.ZengetuZandaka += meisaiRow.ZengetuZandaka ?? 0;
                            zandakaRow.TougetuZandaka += meisaiRow.TougetuZandaka ?? 0;
                            zandakaRow.KarikataHassei += meisaiRow.KarikataHassei ?? 0;
                            zandakaRow.KasikataHassei += meisaiRow.KasikataHassei ?? 0;
                            zandakaRow.KarikataRuikei += meisaiRow.KarikataRuikei ?? 0;
                            zandakaRow.KasikataRuikei += meisaiRow.KasikataRuikei ?? 0;
                            zandakaRow.SagakuRuikei += meisaiRow.SagakuRuikei ?? 0;
                            zandakaRow.HasseiSagaku += meisaiRow.HasseiSagaku ?? 0;
                            zandakaRow.KarikataTougetuZandaka += meisaiRow.KarikataTougetuZandaka ?? 0;
                            zandakaRow.KasikataTougetuZandaka += meisaiRow.KasikataTougetuZandaka ?? 0;
                        }
                        else
                        {
                            zandakaRow.ZengetuZandaka -= meisaiRow.ZengetuZandaka ?? 0;
                            zandakaRow.TougetuZandaka -= meisaiRow.TougetuZandaka ?? 0;
                            zandakaRow.KarikataHassei -= meisaiRow.KarikataHassei ?? 0;
                            zandakaRow.KasikataHassei -= meisaiRow.KasikataHassei ?? 0;
                            zandakaRow.KarikataRuikei -= meisaiRow.KarikataRuikei ?? 0;
                            zandakaRow.KasikataRuikei -= meisaiRow.KasikataRuikei ?? 0;
                            zandakaRow.SagakuRuikei -= meisaiRow.SagakuRuikei ?? 0;
                            zandakaRow.HasseiSagaku -= meisaiRow.HasseiSagaku ?? 0;
                            zandakaRow.KarikataTougetuZandaka -= meisaiRow.KarikataTougetuZandaka ?? 0;
                            zandakaRow.KasikataTougetuZandaka -= meisaiRow.KasikataTougetuZandaka ?? 0;
                        }
                    }
                }
            }
            else
            {
                zandakaRow = zandakaSyuukeihyou.ZandakaSyuukeihyouRowList.FirstOrDefault(row => row.Kicd == zibunKamoku.Kicd);
            }

            return zandakaRow ?? new ZandakaSyuukeihyouRow(ZandakaSyuukeihyouRowType.Meisai);
        }

        /// <summary>
        /// 元帳インスタンス作成
        /// </summary>
        /// <param name="zibunItem"></param>
        /// <param name="layoutPattern"></param>
        /// <returns></returns>
        private Mototyou CreateMototyou(IMototyouZibunItem zibunItem, MototyouLayoutPattern layoutPattern)
        {
            return new Mototyou(zibunItem, layoutPattern);
        }

        private IList<ITanituSiwakeTyouhyouRow> GetTanituSiwakeTyouhyouRowsList(MototyouSiwakeTyouhyouQueryParameter siwakeTyouhyouQueryParameter)
        {
            return this.tanituSiwakeTyouhyouRowRepository.FindSiwakeTyouhyouRowsByQueryParameter(siwakeTyouhyouQueryParameter)
                .Where(siwakeRow => string.IsNullOrEmpty(siwakeRow.DenpyouTabaCode)) //// 伝票束に紐づいている伝票は除外
                .GroupBy(siwakeRow => new { siwakeRow.IsMitenkiData, siwakeRow.Dkei, siwakeRow.Dseq, siwakeRow.Sseq }) //// HACK：GroupByとSelectは仕訳取得モジュールバグの回避用
                .Select(siwakeRow => siwakeRow.FirstOrDefault()).ToList();
        }

        /// <summary>
        /// 当月発生があるかどうか（判定方法：貸借発生）
        /// </summary>
        /// <param name="mototyouQueryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyou"></param>
        /// <returns></returns>
        private bool GetExistsTougetuHasseiWhenMototyouTougetuHasseiJudgmentTypeIsTaisyakuHassei(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyou)
        {
            var existsTaisyakuHassei = true;
            var zandakaRow = this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(mototyouQueryParameter, zibunItem, zandakaSyuukeihyou, false);
            existsTaisyakuHassei = (zandakaRow?.KarikataHassei ?? 0) != 0 || (zandakaRow?.KasikataHassei ?? 0) != 0;

            //// 未転記仕訳を含むかどうか
            var isIncludeMitenkiSiwake = mototyouQueryParameter.ApplicationSecurityType == ApplicationSecurityType.SyouninAndSecurity
                && (mototyouQueryParameter.IsYokuki ? mototyouQueryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwake || mototyouQueryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwakeInTouki
                                                    : mototyouQueryParameter.MitenkiDataQueryContext.IncludesBusyobetuSiwake);
            if (!isIncludeMitenkiSiwake)
            {
                return existsTaisyakuHassei;
            }

            //// 未転記仕訳を含む場合は仕訳の有無も確認する
            var siwakeQueryParameter = this.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            return existsTaisyakuHassei || this.tanituSiwakeTyouhyouRowRepository.GetExistsByQuertyParameter(siwakeQueryParameter);
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "SA1513:Closing brace must be followed by blank line", Justification = "見やすさのため")]
        private IList<decimal> GetZandakaKingakuList(MototyouQueryParameter queryParameter, IMasterZandaka zandaka, bool isKarikata, bool isPLKamoku)
        {
            var kingakuList = new List<decimal>();
            var isIncludeKisyu = queryParameter.OptionComposite.Option.ZenzanJudgmentType == MototyouZenzanJudgmentType.TaisyakuHasseiWithConsiderationKisyu;
            //// 前残があるかどうかをチェックする処理月一覧を取得
            //// （PL科目で下期計算の場合は第7経過月～開始月の前月まで）
            //// （期首を考慮しない場合は第1経過月～開始月の前月まで、期首を考慮する場合は期首～開始月の前月まで）
            var zenzanSyoritukiEnumerable = new KaisyaSyoriKikan(
                queryParameter.Syoriki,
                isPLKamoku && queryParameter.SeiritukiCalculateOption.NeedCalculateSimoki(queryParameter.KaisyaSyoriKikan) ? queryParameter.Syoriki.GetSyorituki(70) : queryParameter.Syoriki.GetFirstSyorituki(isIncludeKisyu),
                queryParameter.KaisyaSyoriKikan.StartSyorituki.GetPrevious(true)).GetSyoritukiEnumerable();
            foreach (var syorituki in zenzanSyoritukiEnumerable)
            {
                switch (syorituki.Ckei)
                {
                    case 0:
                        kingakuList.Add(isKarikata ? zandaka.R000 : zandaka.S000);
                        break;
                    case 10:
                        kingakuList.Add(isKarikata ? zandaka.R010 : zandaka.S010);
                        break;
                    case 20:
                        kingakuList.Add(isKarikata ? zandaka.R020 : zandaka.S020);
                        break;
                    case 30:
                        kingakuList.Add(isKarikata ? zandaka.R030 : zandaka.S030);
                        break;
                    case 35:
                        if (queryParameter.GetSeiritukiCalculateOptionFlag(35) != SeiritukiCalculateOptionFlag.NotReflect)
                        {
                            kingakuList.Add(isKarikata ? zandaka.R035 : zandaka.S035);
                        }
                        break;
                    case 40:
                        kingakuList.Add(isKarikata ? zandaka.R040 : zandaka.S040);
                        break;
                    case 50:
                        kingakuList.Add(isKarikata ? zandaka.R050 : zandaka.S050);
                        break;
                    case 60:
                        kingakuList.Add(isKarikata ? zandaka.R060 : zandaka.S060);
                        break;
                    case 65:
                        if (queryParameter.GetSeiritukiCalculateOptionFlag(65) != SeiritukiCalculateOptionFlag.NotReflect)
                        {
                            kingakuList.Add(isKarikata ? zandaka.R065 : zandaka.S065);
                        }
                        break;
                    case 70:
                        kingakuList.Add(isKarikata ? zandaka.R070 : zandaka.S070);
                        break;
                    case 80:
                        kingakuList.Add(isKarikata ? zandaka.R080 : zandaka.S080);
                        break;
                    case 90:
                        kingakuList.Add(isKarikata ? zandaka.R090 : zandaka.S090);
                        break;
                    case 95:
                        if (queryParameter.GetSeiritukiCalculateOptionFlag(95) != SeiritukiCalculateOptionFlag.NotReflect)
                        {
                            kingakuList.Add(isKarikata ? zandaka.R095 : zandaka.S095);
                        }
                        break;
                    case 100:
                        kingakuList.Add(isKarikata ? zandaka.R100 : zandaka.S100);
                        break;
                    case 110:
                        kingakuList.Add(isKarikata ? zandaka.R110 : zandaka.S110);
                        break;
                    case 120:
                        kingakuList.Add(isKarikata ? zandaka.R120 : zandaka.S120);
                        break;
                        //// case 125は前月残高として含まれることはないので省略
                }
            }

            return kingakuList;
        }

        private MototyouMaeKurikosiRow.MaeKurikosiRowType GetMaeKurikosiRowType(MototyouQueryParameter queryParameter)
        {
            if (queryParameter.QueryCondition.StartDate != null && queryParameter.QueryCondition.StartDate.Ymd != queryParameter.KaisyaSyoriKikan.StartSyorituki.StartDate.Ymd)
            {
                return MototyouMaeKurikosiRow.MaeKurikosiRowType.Zenzitu;
            }
            else if (queryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei == queryParameter.Syoriki.GetFirstSyorituki(false).Ckei)
            {
                return MototyouMaeKurikosiRow.MaeKurikosiRowType.Zenki;
            }
            else if (queryParameter.SeiritukiCalculateOption.NeedCalculateSimoki(queryParameter.KaisyaSyoriKikan) && queryParameter.KaisyaSyoriKikan.StartSyorituki.Ckei == 70)
            {
                return MototyouMaeKurikosiRow.MaeKurikosiRowType.Kamiki;
            }
            else
            {
                return MototyouMaeKurikosiRow.MaeKurikosiRowType.Zengetu;
            }
        }

        private ZandakaSyuukeihyouType GetZandakaSyuukeihyouType(MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    return ZandakaSyuukeihyouType.Kamoku;
                case MototyouType.EdabanMototyou:
                    return ZandakaSyuukeihyouType.Edaban;
                case MototyouType.BumonMototyou:
                    return ZandakaSyuukeihyouType.Bumon;
                case MototyouType.BumonKamokuEdabanMototyou:
                    return ZandakaSyuukeihyouType.BumonKamokuEdaban;
                case MototyouType.TorihikisakiMototyou:
                    return ZandakaSyuukeihyouType.Torihikisaki;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return ZandakaSyuukeihyouType.BumonKamokuTorihikisaki;
                default:
                    return ZandakaSyuukeihyouType.Kamoku;
            }
        }

        private string GetMasterCode(MasterType masterType, string ecod, string bcod, string tcod)
        {
            switch (masterType)
            {
                case MasterType.Kamoku:
                    return null;
                case MasterType.Edaban:
                    return ecod;
                case MasterType.Bumon:
                    return bcod;
                case MasterType.Torihikisaki:
                    return tcod;
                default:
                    return null;
            }
        }

        private ZandakaSyuukeihyouRow GetZennenKimatuZandakaRow(Mototyou mototyou, MototyouQueryParameter queryParameter)
        {
            var syoriKikanForGetZennenKimatuZandaka = new KaisyaSyoriKikan(queryParameter.ZennenSyoriki, queryParameter.ZennenSyoriki.GetLastNormalSyorituki(), queryParameter.ZennenSyoriki.GetLastNormalSyorituki());
            //// 設定を変更するため再取得
            var seiritukiCalculateOption = this.seiritukiCalculateOptionRepository.FindByUser(queryParameter.User, queryParameter.CurrentKaisya);
            var queryParameterForGetZennenKimatuZandaka = MototyouQueryParameter.Create(
                syoriKikanForGetZennenKimatuZandaka,
                queryParameter.MitenkiDataQueryContext,
                seiritukiCalculateOption,
                queryParameter.OptionComposite,
                queryParameter.QueryCondition,
                queryParameter.CurrentKaisya);

            var zennenYokukiKousinSettei = queryParameter.ZennenSyoriki.SeiritukiCalculateOptionYokukiKisyuZandakaOnYokukiKousin;
            //// 翌期更新設定を整理月設定に反映する
            queryParameterForGetZennenKimatuZandaka.SeiritukiCalculateOption.GetSyorikiItem(queryParameter.ZennenSyoriki.Kesn, queryParameter.UseUserSeiritukiCalculateOption).FirstQuarterOption =
                zennenYokukiKousinSettei.FirstQuarterOption == SeiritukiCalculateOptionYokukiKisyuZandakaFlag.Include ? SeiritukiCalculateOptionFlag.IncludeSyorituki : SeiritukiCalculateOptionFlag.NotReflect;
            queryParameterForGetZennenKimatuZandaka.SeiritukiCalculateOption.GetSyorikiItem(queryParameter.ZennenSyoriki.Kesn, queryParameter.UseUserSeiritukiCalculateOption).SecondQuarterOption =
                zennenYokukiKousinSettei.SecondQuarterOption == SeiritukiCalculateOptionYokukiKisyuZandakaFlag.Include ? SeiritukiCalculateOptionFlag.IncludeSyorituki : SeiritukiCalculateOptionFlag.NotReflect;
            queryParameterForGetZennenKimatuZandaka.SeiritukiCalculateOption.GetSyorikiItem(queryParameter.ZennenSyoriki.Kesn, queryParameter.UseUserSeiritukiCalculateOption).ThirdQuarterOption =
                zennenYokukiKousinSettei.ThirdQuarterOption == SeiritukiCalculateOptionYokukiKisyuZandakaFlag.Include ? SeiritukiCalculateOptionFlag.IncludeSyorituki : SeiritukiCalculateOptionFlag.NotReflect;
            queryParameterForGetZennenKimatuZandaka.SeiritukiCalculateOption.GetSyorikiItem(queryParameter.ZennenSyoriki.Kesn, queryParameter.UseUserSeiritukiCalculateOption).FourthQuarterOption =
                zennenYokukiKousinSettei.FourthQuarterOption == SeiritukiCalculateOptionYokukiKisyuZandakaFlag.Include ? SeiritukiCalculateOptionFlag.IncludeSyorituki : SeiritukiCalculateOptionFlag.NotReflect;

            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameter(queryParameterForGetZennenKimatuZandaka, mototyou.ZibunItem, false);
        }

        /// <summary>
        /// 自分項目がPL科目かどうか
        /// 規則外集計科目の場合は、その内訳がPL科目のみで構成されている場合はPL科目とみなす
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <returns></returns>
        private bool IsSonekiKamoku(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var mototyouZibunItem = zibunItem as KamokuMototyouZibunItem;
            return queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku
                ? mototyouZibunItem.Kamoku.MeisaiKamokuList.FirstOrDefault(meisaiKamoku => meisaiKamoku.Kicd.CompareTo("100000000000000") < 0) == null
                : mototyouZibunItem.Kamoku.Kicd.CompareTo("100000000000000") >= 0;
        }

        private TaisyakuValue GetZyunriekiTaisyakuValue(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            //// 金額の計算
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, null, queryParameter.OptionComposite.QueryOption.MototyouType == MototyouType.Mototyou ? null : ((BumonMototyouZibunItem)zibunItem).Bcod, null, false, false, false);
            var syuukeiTargetZandakaRowList = zandakaSyuukeihyou.ZandakaSyuukeihyouRowList.Where(row =>
                                              row.RowType == ZandakaSyuukeihyouRowType.Meisai
                                              && ((row.Kicd.CompareTo("100000000000000") >= 0
                                                   && row.Kicd.CompareTo("160029999999999") <= 0)
                                                   || row.Kicd.StartsWith("210")));
            var hasseiSagakuSyuukei = syuukeiTargetZandakaRowList.Sum(row => row.KasikataTougetuZandaka ?? 0) - syuukeiTargetZandakaRowList.Sum(row => row.KarikataTougetuZandaka ?? 0);
            var taisyakuValue = new TaisyakuValue(0, 0);
            if (hasseiSagakuSyuukei >= 0)
            {
                //// 利益の場合は貸方に表示
                taisyakuValue.KasikataValue += hasseiSagakuSyuukei;
            }
            else
            {
                //// 損失の場合は借方に表示（符号反転）
                taisyakuValue.KarikataValue += -hasseiSagakuSyuukei;
            }

            return taisyakuValue;
        }

        /// <summary>
        /// ○期純利益（損失）行の作成・追加し、貸借金額を加算する
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="queryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="layoutPattern"></param>
        /// <param name="existsSiwakeRows">仕訳が存在するかどうか</param>
        /// <param name="taisyakuTotal"></param>
        private void SetZyunriekiRowAndAddTaisyakuKingaku(Mototyou mototyou, MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, MototyouLayoutPattern layoutPattern, bool existsSiwakeRows, TaisyakuValue taisyakuTotal)
        {
            var taisyakuValue = this.GetZyunriekiTaisyakuValue(queryParameter, zibunItem);

            switch (queryParameter.OptionComposite.QueryOption.SyuukeiKeisiki)
            {
                case MototyouSyuukeiKeisiki.Detail:
                    this.SetZyunriekiSiwakeRow(mototyou, queryParameter, layoutPattern, taisyakuValue);
                    break;
                case MototyouSyuukeiKeisiki.Daily:
                    this.SetZyunriekiDailyRow(mototyou, queryParameter, taisyakuValue);
                    break;
                case MototyouSyuukeiKeisiki.Monthly:
                    this.SetZyunriekiMonthlyRow(mototyou, queryParameter, taisyakuValue);
                    break;
            }

            taisyakuTotal?.AddKingaku(taisyakuValue.KarikataValue, taisyakuValue.KasikataValue);
        }

        private void SetZyunriekiSiwakeRow(Mototyou mototyou, MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern, TaisyakuValue zyunriekiTaisyakuValue)
        {
            var siwakeRow = new MototyouSiwakeRow(mototyou, layoutPattern.ColumnCount, layoutPattern.RowCount);
            //// 相手科目に表示する名称
            var hyouziName = string.Format(
                "{0}{1}",
                queryParameter.SeiritukiCalculateOption.ZadakaCalclationAfter7thMonth == SeiritukiCalculateOptionZadakaAfter7thMonthFlag.Tuuki ? Properties.Resources.当期 : queryParameter.EndSyorituki.IsKamiki() ? Properties.Resources.上期 : Properties.Resources.下期,
                zyunriekiTaisyakuValue.KasikataValue >= 0 ? Properties.Resources.純利益 : Properties.Resources.純損失);
            var aiteKamokuLongNameInLayoutItems = layoutPattern.Items.OfType<MototyouLayoutMasterDataItem>().FirstOrDefault(item => item.ItemType == MototyouLayoutItemType.Kamoku && item.MasterDataValueType == MototyouLayoutItemMasterDataValueType.AiteLongName);
            if (aiteKamokuLongNameInLayoutItems != null)
            {
                siwakeRow.SetCellItem(aiteKamokuLongNameInLayoutItems, hyouziName);
            }

            siwakeRow.IsSeirituki = queryParameter.StartSyorituki.SeiritukiId == SeiritukiId.Fourth
                || queryParameter.SeiritukiCalculateOption.GetOptionFlag(queryParameter.Kesn, queryParameter.UseUserSeiritukiCalculateOption, SeiritukiId.Fourth) == SeiritukiCalculateOptionFlag.SeparateSyorituki;
            siwakeRow.DenpyouDate = queryParameter.EndSyorituki.EndDate;
            siwakeRow.IsEnabledDenpyouKakunin = false;
            siwakeRow.KarikataValue = zyunriekiTaisyakuValue.KarikataValue == 0 ? null : (decimal?)zyunriekiTaisyakuValue.KarikataValue;
            siwakeRow.KasikataValue = zyunriekiTaisyakuValue.KasikataValue == 0 ? null : (decimal?)zyunriekiTaisyakuValue.KasikataValue;
            siwakeRow.SasihikiZandaka = mototyou.RuikeiZandaka + siwakeRow.GetSasihikiValue();
            mototyou.AddRow(siwakeRow);
        }

        /// <summary>
        /// 元帳に当期純利益の日別集計行を追加する（期末最終日に通常仕訳がない場合に行う処理）
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="queryParameter"></param>
        /// <param name="zyunriekiTaisyakuValue"></param>
        private void SetZyunriekiDailyRow(Mototyou mototyou, MototyouQueryParameter queryParameter, TaisyakuValue zyunriekiTaisyakuValue)
        {
            var useMonthlyTotal = queryParameter.OptionComposite.Option.MonthlyTotal == MototyouMonthlyTotal.Exists
                || queryParameter.IsMultiSyorituki;
            var dailyRow = new MototyouDailyRow(mototyou, queryParameter.EndSyorituki.EndDate);
            dailyRow.KarikataValue = zyunriekiTaisyakuValue.KarikataValue == 0 ? null : (decimal?)zyunriekiTaisyakuValue.KarikataValue;
            dailyRow.KasikataValue = zyunriekiTaisyakuValue.KasikataValue == 0 ? null : (decimal?)zyunriekiTaisyakuValue.KasikataValue;
            dailyRow.SasihikiZandaka = mototyou.RuikeiZandaka + dailyRow.GetSasihikiValue();
            dailyRow.IsSeirituki = queryParameter.StartSyorituki.SeiritukiId == SeiritukiId.Fourth
                || queryParameter.SeiritukiCalculateOption.GetOptionFlag(queryParameter.Kesn, queryParameter.UseUserSeiritukiCalculateOption, SeiritukiId.Fourth) == SeiritukiCalculateOptionFlag.SeparateSyorituki;
            mototyou.AddRow(dailyRow);
        }

        /// <summary>
        /// 元帳に当期純利益の月別集計行を追加する（期末最終月に通常仕訳がない場合に行う処理）
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="queryParameter"></param>
        /// <param name="zyunriekiTaisyakuValue"></param>
        private void SetZyunriekiMonthlyRow(Mototyou mototyou, MototyouQueryParameter queryParameter, TaisyakuValue zyunriekiTaisyakuValue)
        {
            this.SetMototyouMonthlyAndRuikeiRow(
                queryParameter,
                mototyou,
                queryParameter.SelectedEndSyorituki,
                zyunriekiTaisyakuValue.KarikataValue,
                zyunriekiTaisyakuValue.KasikataValue,
                row => mototyou.RuikeiZandaka + row.GetSasihikiValue(),
                true);
        }

        /// <summary>
        /// 仕訳明細行を作成して元帳に追加する
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="layoutPattern"></param>
        /// <param name="monthlyRowGroups"></param>
        /// <param name="zibunItem"></param>
        /// <param name="queryParameter"></param>
        /// <param name="useMonthlyTotal"></param>
        private void SetMototyouSiwakeRows(Mototyou mototyou, MototyouLayoutPattern layoutPattern, IEnumerable<IGrouping<int, ITanituSiwakeTyouhyouRow>> monthlyRowGroups, IMototyouZibunItem zibunItem, MototyouQueryParameter queryParameter, bool useMonthlyTotal)
        {
            var syouhizeiMaster = this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn);
            var mototyouSiwakeRowFactory = new MototyouSiwakeRowFactory(
                queryParameter,
                layoutPattern,
                syouhizeiMaster,
                zibunItem,
                this.IsMasterMatch,
                this.zeikubunFactoryCreator.Create(queryParameter, layoutPattern, syouhizeiMaster),
                syouhizeiMaster.IsTokuteiSyuunyuuTokureiKeisan ? this.tokuteiSyuunyuuKamokuRepository.FindByKesn(queryParameter.Kesn).ToDictionary(k => k.Kicd) : new Dictionary<string, TokuteiSyuunyuuKamoku>());
            var isSonekiHurikae = this.IsSonekiHurikae(queryParameter, zibunItem) && ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050020");
            var endSyoritukiGroupKey = this.GetGroupKeyDkei(queryParameter.SelectedEndSyorituki.Ckei, queryParameter);
            var addIkkatuZeinukiSiwakeToEnd = queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType != MototyouIkkatuZeinukiSiwakeSyuukeiType.None || queryParameter.OptionComposite.Option.OutputIkkatuZeinuykiSiwakeLastOnMonthIfSyuukeiTypeIsNone;
            foreach (var monthlyRowGroup in monthlyRowGroups)
            {
                var syorituki = queryParameter.Syoriki.SyoritukiList.First(tuki => tuki.Ckei == monthlyRowGroup.Key);
                TaisyakuValue taisyakuTotal = new TaisyakuValue(0, 0);
                IList<ITanituSiwakeTyouhyouRow> ikkatuZeinukiSiwakeRows = new List<ITanituSiwakeTyouhyouRow>();
                foreach (var siwakeRow in monthlyRowGroup)
                {
                    if (addIkkatuZeinukiSiwakeToEnd && siwakeRow.IkkatuZeinukiSiwakeFlag != IkkatuZeinukiSiwakeFlag.TuuzyouSiwake)
                    {
                        ikkatuZeinukiSiwakeRows.Add(siwakeRow);
                    }
                    else
                    {
                        foreach (var row in mototyouSiwakeRowFactory.CreateRowEnumerable(mototyou, siwakeRow, syorituki.IsSeirituki))
                        {
                            mototyou.AddRow(row);
                            taisyakuTotal.AddKingaku(row.KarikataValue, row.KasikataValue);
                        }
                    }
                }

                //// 一括税抜仕訳行を作成して元帳に追加し、貸借の合計金額を加算する
                if (addIkkatuZeinukiSiwakeToEnd)
                {
                    foreach (var row in mototyouSiwakeRowFactory.CreateIkkatuZeinukiSiwakeRows(mototyou, ikkatuZeinukiSiwakeRows, syorituki.IsSeirituki))
                    {
                        mototyou.AddRow(row);
                        taisyakuTotal.AddKingaku(row.KarikataValue, row.KasikataValue);
                    }
                }

                if (isSonekiHurikae && monthlyRowGroup.Key == endSyoritukiGroupKey)
                {
                    //// 当期純利益行を作成して元帳に追加し、貸借の合計金額を加算する
                    this.SetZyunriekiRowAndAddTaisyakuKingaku(mototyou, queryParameter, zibunItem, layoutPattern, true, taisyakuTotal);
                }

                //// 月度計行作成
                if (useMonthlyTotal)
                {
                    this.SetMototyouMonthlyAndRuikeiRow(queryParameter, mototyou, syorituki, taisyakuTotal.KarikataValue, taisyakuTotal.KasikataValue, row => mototyou.RuikeiZandaka, monthlyRowGroups.Last().Key == monthlyRowGroup.Key);
                }
            }

            if (isSonekiHurikae && (monthlyRowGroups.Count() == 0 || monthlyRowGroups.Last().Key != endSyoritukiGroupKey))
            {
                if (monthlyRowGroups.Count() != 0)
                {
                    mototyou.AddRow(null);
                }

                //// 当期純利益（期末月に仕訳が存在しなかった場合）
                var taisyakuValue = new TaisyakuValue(0, 0);
                this.SetZyunriekiRowAndAddTaisyakuKingaku(mototyou, queryParameter, zibunItem, layoutPattern, false, taisyakuValue);
                if (useMonthlyTotal)
                {
                    this.SetMototyouMonthlyAndRuikeiRow(queryParameter, mototyou, queryParameter.SelectedEndSyorituki, taisyakuValue.KarikataValue, taisyakuValue.KasikataValue, row => mototyou.RuikeiZandaka, true);
                }
            }
        }

        /// <summary>
        /// 日別集計の行を作成して元帳に追加する
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="monthlyRowGroups"></param>
        /// <param name="zibunItem"></param>
        /// <param name="queryParameter"></param>
        /// <param name="useMonthlyTotal"></param>
        private void SetMototyouDailyRows(Mototyou mototyou, IEnumerable<IGrouping<int, ITanituSiwakeTyouhyouRow>> monthlyRowGroups, IMototyouZibunItem zibunItem, MototyouQueryParameter queryParameter, bool useMonthlyTotal)
        {
            var isSonekiHurikae = this.IsSonekiHurikae(queryParameter, zibunItem) && ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050020");
            var endSyoritukiGroupKey = this.GetGroupKeyDkei(queryParameter.SelectedEndSyorituki.Ckei, queryParameter);
            foreach (var monthlyRowGroup in monthlyRowGroups)
            {
                var taisyakuTotal = new TaisyakuValue(0, 0);
                var syorituki = queryParameter.Syoriki.SyoritukiList.First(tuki => tuki.Ckei == monthlyRowGroup.Key);
                var dailyRows = monthlyRowGroup.GroupBy(row => row.DenpyouDate.Ymd);
                //// 日別集計行作成
                foreach (var group in dailyRows)
                {
                    var dailyRow = new MototyouDailyRow(mototyou, group.First().DenpyouDate);
                    dailyRow.KarikataValue = group.Where(row => this.IsMasterMatch(row.KarikataDetail, zibunItem)).Sum(row => row.Kingaku);
                    dailyRow.KasikataValue = group.Where(row => this.IsMasterMatch(row.KasikataDetail, zibunItem)).Sum(row => row.Kingaku);
                    if (isSonekiHurikae && monthlyRowGroup.Key == endSyoritukiGroupKey && group.Key == queryParameter.EndSyorituki.EndDate.Ymd)
                    {
                        //// 当期純利益（期末最終日に仕訳がある場合）
                        var taisyakuValue = this.GetZyunriekiTaisyakuValue(queryParameter, zibunItem);
                        dailyRow.KarikataValue += taisyakuValue.KarikataValue;
                        dailyRow.KasikataValue += taisyakuValue.KasikataValue;
                    }

                    dailyRow.SasihikiZandaka = mototyou.RuikeiZandaka + dailyRow.GetSasihikiValue();
                    dailyRow.IsSeirituki = syorituki.IsSeirituki;
                    mototyou.AddRow(dailyRow);
                    taisyakuTotal.AddKingaku(dailyRow.KarikataValue, dailyRow.KasikataValue);
                }

                if (isSonekiHurikae && dailyRows.Last().Key != queryParameter.EndSyorituki.EndDate.Ymd)
                {
                    //// 当期純利益（期末最終日に仕訳がない場合）
                    this.SetZyunriekiRowAndAddTaisyakuKingaku(mototyou, queryParameter, zibunItem, null, false, taisyakuTotal);
                }

                //// 月度計行作成
                if (useMonthlyTotal)
                {
                    this.SetMototyouMonthlyAndRuikeiRow(queryParameter, mototyou, syorituki, taisyakuTotal.KarikataValue, taisyakuTotal.KasikataValue, row => mototyou.RuikeiZandaka, monthlyRowGroups.Last().Key == monthlyRowGroup.Key);
                }
            }

            if (isSonekiHurikae && (monthlyRowGroups.Count() == 0 || monthlyRowGroups.Last().Key != endSyoritukiGroupKey))
            {
                if (monthlyRowGroups.Count() != 0)
                {
                    mototyou.AddRow(null);
                }

                //// 当期純利益（期末最終月に仕訳がない場合）
                var taisyakuValue = new TaisyakuValue(0, 0);
                this.SetZyunriekiRowAndAddTaisyakuKingaku(mototyou, queryParameter, zibunItem, null, false, taisyakuValue);
                if (useMonthlyTotal)
                {
                    this.SetMototyouMonthlyAndRuikeiRow(queryParameter, mototyou, queryParameter.SelectedEndSyorituki, taisyakuValue.KarikataValue, taisyakuValue.KasikataValue, row => mototyou.RuikeiZandaka, true);
                }
            }
        }

        /// <summary>
        /// 月別集計行を作成して元帳に追加する
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="monthlyRowGroups"></param>
        /// <param name="zibunItem"></param>
        /// <param name="queryParameter"></param>
        private void SetMototyouMonthlyRows(Mototyou mototyou, IEnumerable<IGrouping<int, ITanituSiwakeTyouhyouRow>> monthlyRowGroups, IMototyouZibunItem zibunItem, MototyouQueryParameter queryParameter)
        {
            var isSonekiHurikae = this.IsSonekiHurikae(queryParameter, zibunItem) && ((KamokuMototyouZibunItem)zibunItem).Kamoku.Kicd.StartsWith("080050020");
            var endSyoritukiGroupKey = this.GetGroupKeyDkei(queryParameter.SelectedEndSyorituki.Ckei, queryParameter);
            foreach (var group in monthlyRowGroups)
            {
                var karikataTotal = group.Where(row => this.IsMasterMatch(row.KarikataDetail, zibunItem)).Sum(row => row.Kingaku);
                var kasikataTotal = group.Where(row => this.IsMasterMatch(row.KasikataDetail, zibunItem)).Sum(row => row.Kingaku);
                if (isSonekiHurikae && group.Key == endSyoritukiGroupKey)
                {
                    //// 当期純利益（期末最終月に仕訳がある場合）
                    var taisyakuValue = this.GetZyunriekiTaisyakuValue(queryParameter, zibunItem);
                    karikataTotal += taisyakuValue.KarikataValue;
                    kasikataTotal += taisyakuValue.KasikataValue;
                }

                this.SetMototyouMonthlyAndRuikeiRow(
                    queryParameter,
                    mototyou,
                    queryParameter.Syoriki.SyoritukiList.First(syorituki => syorituki.Ckei == group.Key),
                    karikataTotal,
                    kasikataTotal,
                    row => mototyou.RuikeiZandaka + row.GetSasihikiValue(),
                    monthlyRowGroups.Last().Key == group.Key);
            }

            if (isSonekiHurikae && (monthlyRowGroups.Count() == 0 || monthlyRowGroups.Last().Key != endSyoritukiGroupKey))
            {
                if (monthlyRowGroups.Count() != 0)
                {
                    mototyou.AddRow(null);
                }

                //// 当期純利益（期末最終月に仕訳がない場合）
                this.SetZyunriekiRowAndAddTaisyakuKingaku(mototyou, queryParameter, zibunItem, null, false, new TaisyakuValue(0, 0));
            }
        }

        /// <summary>
        /// 月度計行を作成して元帳に追加する
        /// （累計行を出力する場合は後ろに累計行を追加する）
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="mototyou"></param>
        /// <param name="syorituki"></param>
        /// <param name="karikataTotal"></param>
        /// <param name="kasikataTotal"></param>
        /// <param name="getSasihikiZandaka"></param>
        /// <param name="isLastDisplayMonth">最終月表示かどうか</param>
        private void SetMototyouMonthlyAndRuikeiRow(MototyouQueryParameter queryParameter, Mototyou mototyou, Syorituki syorituki, decimal karikataTotal, decimal kasikataTotal, Func<MototyouMonthlyRow, decimal> getSasihikiZandaka, bool isLastDisplayMonth)
        {
            //// 月度計行
            var monthlyRow = new MototyouMonthlyRow(mototyou, syorituki);
            monthlyRow.KarikataValue = karikataTotal;
            monthlyRow.KasikataValue = kasikataTotal;
            monthlyRow.SasihikiZandaka = getSasihikiZandaka(monthlyRow);
            monthlyRow.IsSeirituki = syorituki.IsSeirituki;
            mototyou.AddRow(monthlyRow, queryParameter.OptionComposite.QueryOption.SyuukeiKeisiki == MototyouSyuukeiKeisiki.Monthly);

            //// 累計行
            if (!isLastDisplayMonth && queryParameter.OptionComposite.Option.RuikeiOutputType != MototyouRuikeiOutputType.NotOutput)
            {
                this.SetMototyouRuikeiRow(mototyou, true);
            }

            if (!isLastDisplayMonth)
            {
                mototyou.AddRow(null);
            }
        }

        private void SetMototyouRuikeiRow(Mototyou mototyou, bool isClearTaisyakuTotal)
        {
            var ruikeiRow = new MototyouRuikeiRow(mototyou);
            ruikeiRow.KarikataValue = mototyou.MaeKarikataZandaka + mototyou.KarikataTotal;
            ruikeiRow.KasikataValue = mototyou.MaeKasikataZandaka + mototyou.KasikataTotal;
            mototyou.MaeKarikataZandaka += mototyou.KarikataTotal;
            mototyou.MaeKasikataZandaka += mototyou.KasikataTotal;

            if (isClearTaisyakuTotal)
            {
                //// 各貸借の合計を初期化
                mototyou.KarikataTotal = 0;
                mototyou.KasikataTotal = 0;
            }

            ruikeiRow.SasihikiZandaka = mototyou.RuikeiZandaka;
            mototyou.AddRow(ruikeiRow);
        }

        /// <summary>
        /// グループ化用の経過月の値を取得する
        /// </summary>
        /// <param name="dkei"></param>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        private int GetGroupKeyDkei(int dkei, MototyouQueryParameter queryParameter)
        {
            //// 指定経過月が通常月に含まれる設定の整理月の場合、通常月の経過月の値を返す
            //// それ以外ならそのままの経過月の値を返す
            if (!Syorituki.IsSeiritukiCkei(dkei))
            {
                return dkei;
            }

            if (!queryParameter.IsMultiSyorituki && queryParameter.SelectedEndSyorituki.IsSeirituki)
            {
                //// 整理月の単月指定ならそのまま返す
                return dkei;
            }

            switch (queryParameter.GetSeiritukiCalculateOptionFlag(dkei))
            {
                case SeiritukiCalculateOptionFlag.NotReflect:
                    return -1;
                case SeiritukiCalculateOptionFlag.IncludeSyorituki:
                    return (dkei / 10) * 10;
                default:
                    return dkei;
            }
        }

        private void SetMototyouYokuKurikosiRow(Mototyou mototyou, MototyouQueryParameter queryParameter, MototyouYokuKurikosiRow mototyouRow)
        {
            ////var useMonthlyRow = queryParameter.OptionComposite.Option.MonthlyTotal == MototyouMonthlyTotal.Exists
            ////                    || queryParameter.StartCkei != queryParameter.EndCkei;
            if (!mototyou.MototyouRows.Any(row => row?.RowType == MototyouRowType.MonthlyRow))
            {
                //// 月度計が出力されていなければ借方・貸方金額を表示する
                mototyouRow.KarikataValue = mototyou.KarikataTotal;
                mototyouRow.KasikataValue = mototyou.KasikataTotal;
            }

            mototyouRow.SasihikiZandaka = mototyou.RuikeiZandaka;
        }

        private IList<ITanituSiwakeTyouhyouRow> GetSortedTanituSiwakeTyouhouRows(IList<ITanituSiwakeTyouhyouRow> siwakeTyouhyouRows, MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            //// 経過月（仮）
            var sortedSiwakeTyouhyouRows = siwakeTyouhyouRows.OrderBy(siwake =>
            {
                if (Syorituki.IsSeiritukiCkei(siwake.Dkei)
                    && queryParameter.GetSeiritukiCalculateOptionFlag(siwake.Dkei) == SeiritukiCalculateOptionFlag.IncludeSyorituki)
                {
                    return siwake.Dkei - 5; //// 整理月に対応する通常月(dkei)を返す
                }
                return siwake.Dkei;
            });

            if (queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType == MototyouIkkatuZeinukiSiwakeSyuukeiType.None
                && queryParameter.OptionComposite.Option.OutputIkkatuZeinuykiSiwakeLastOnMonthIfSyuukeiTypeIsNone)
            {
                //// 一括税抜仕訳を「0：まとめない」かつ、月の最後に出力する場合
                sortedSiwakeTyouhyouRows = sortedSiwakeTyouhyouRows.ThenBy(siwake => siwake.IkkatuZeinukiSiwakeFlag); //// 通常仕訳→一括税抜仕訳
            }

            sortedSiwakeTyouhyouRows = sortedSiwakeTyouhyouRows
                .ThenBy(siwake => siwake.DenpyouDate) //// 伝票日付
                .ThenBy(siwake => siwake.DenpyouNo) //// 伝票番号
                .ThenBy(siwake => siwake.Dkei); //// 経過月（実）

            if (queryParameter.SecurityContext.ApplicationSecurityType == ApplicationSecurityType.NoSecurity)
            {
                sortedSiwakeTyouhyouRows = sortedSiwakeTyouhyouRows
                    .ThenBy(siwake => siwake.IsMitenkiData ? 2 : 1) //// 財務→未転記
                    .ThenBy(siwake => siwake.UketukeNo); //// 受付番号
            }

            sortedSiwakeTyouhyouRows = sortedSiwakeTyouhyouRows
                .ThenBy(siwake => siwake.GroupNo) //// グループ番号
                .ThenBy(siwake => siwake.LineNo) //// 行番号
                .ThenBy(siwake => this.IsKarikataKoumokuZibunItemInSiwake(siwake, zibunItem, queryParameter) ? 1 : 2) //// 借方→貸方
                .ThenBy(siwake => siwake.Sseq); //// 仕訳SEQ

            return sortedSiwakeTyouhyouRows.ToList();
        }

        /// <summary>
        /// 自分項目が仕訳行の借方項目かどうか（貸方項目ならfalse）
        /// </summary>
        /// <param name="siwake"></param>
        /// <param name="zibunItem"></param>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        private bool IsKarikataKoumokuZibunItemInSiwake(ITanituSiwakeTyouhyouRow siwake, IMototyouZibunItem zibunItem, MototyouQueryParameter queryParameter)
        {
            switch (queryParameter.OptionComposite.QueryOption.MototyouType)
            {
                case MototyouType.Mototyou:
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, ((KamokuMototyouZibunItem)zibunItem).Kamoku, queryParameter);
                case MototyouType.EdabanMototyou:
                    var edabanMototyouZibunItem = (EdabanMototyouZibunItem)zibunItem;
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, edabanMototyouZibunItem.Kamoku, queryParameter)
                        && siwake.KarikataDetail.Ecod == edabanMototyouZibunItem.Ecod;
                case MototyouType.BumonMototyou:
                    var bumonMototyouZibunItem = (BumonMototyouZibunItem)zibunItem;
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, bumonMototyouZibunItem.Kamoku, queryParameter)
                        && siwake.KarikataDetail.Bcod == bumonMototyouZibunItem.Bcod;
                case MototyouType.BumonKamokuEdabanMototyou:
                    var bumonKamokuEdabanMototyouZibunItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, bumonKamokuEdabanMototyouZibunItem.Kamoku, queryParameter)
                        && siwake.KarikataDetail.Ecod == bumonKamokuEdabanMototyouZibunItem.Ecod
                        && siwake.KarikataDetail.Bcod == bumonKamokuEdabanMototyouZibunItem.Bcod;
                case MototyouType.TorihikisakiMototyou:
                    var torihikisakiMototyouZibunItem = (TorihikisakiMototyouZibunItem)zibunItem;
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, torihikisakiMototyouZibunItem.Kamoku, queryParameter)
                        && siwake.KarikataDetail.Trcd == torihikisakiMototyouZibunItem.Trcd;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    var bumonKamokuTorihikisakiMototyouZibunItem = (BumonKamokuTorihikisakiMototyouZibunItem)zibunItem;
                    return this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, bumonKamokuTorihikisakiMototyouZibunItem.Kamoku, queryParameter)
                        && siwake.KarikataDetail.Bcod == bumonKamokuTorihikisakiMototyouZibunItem.Bcod
                        && siwake.KarikataDetail.Trcd == bumonKamokuTorihikisakiMototyouZibunItem.Trcd;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 自分科目が仕訳行の借方科目かどうか（貸方科目ならfalse）
        /// </summary>
        /// <param name="kicdOfKarikataSiwake"></param>
        /// <param name="zibunKamoku"></param>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        private bool IsKarikataKamokuZibunItemKamokuInSiwake(string kicdOfKarikataSiwake, IMototyouKamoku zibunKamoku, MototyouQueryParameter queryParameter)
        {
            switch (queryParameter.OptionComposite.QueryOption.KamokuType)
            {
                case MototyouKamokuType.MeisaiKamoku:
                    return kicdOfKarikataSiwake == zibunKamoku.Kicd;
                case MototyouKamokuType.SyouKamoku:
                    return kicdOfKarikataSiwake.Substring(0, 12) == zibunKamoku.Kicd.Substring(0, 12);
                case MototyouKamokuType.SyuukeiSyouKamoku:
                    return kicdOfKarikataSiwake.Substring(0, 9) == zibunKamoku.Kicd.Substring(0, 9);
                case MototyouKamokuType.KisokugaiSyuukeiKamoku:
                    return zibunKamoku.MeisaiKamokuList.Any(meisaiKamoku => kicdOfKarikataSiwake == meisaiKamoku.Kicd);
                default:
                    return false;
            }
        }

        /// <summary>
        /// 仕訳の相手科目を「複合形式の相手科目」設定に応じて変更する
        /// </summary>
        /// <param name="siwakeList"></param>
        /// <param name="queryParameter"></param>
        /// <param name="zibunItem"></param>
        /// <param name="siwakeTyouhyouQueryParameter"></param>
        private void ChangeSiwakeAiteKamokuAsMototyouHukugouKeisikiAiteKamokuJudgmentType(IList<ITanituSiwakeTyouhyouRow> siwakeList, MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, MototyouSiwakeTyouhyouQueryParameter siwakeTyouhyouQueryParameter)
        {
            //// 「諸口」の仕訳一覧を取得するためのパラメータ―を設定（科目以外の指定コードはクリア）
            var syokutiKamoku = this.kamokuRepository.FindByKesnAndInputCode(queryParameter.Syoriki.Kesn, "099999");
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = new List<Kamoku>() { syokutiKamoku };
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = new List<Kamoku>() { syokutiKamoku };
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.BcodRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.BcodRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.EcodRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.EcodRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.TrcdRangeValue.SetValue(null, null, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.TrcdRangeValue.SetValue(null, null, false, false);
            //// 「諸口」の仕訳一覧を取得
            var syokutiSiwakeTyouhyouRows = this.GetTanituSiwakeTyouhyouRowsList(siwakeTyouhyouQueryParameter);

            foreach (var siwake in siwakeList)
            {
                if (siwake.KarikataDetail.Kicd == "000000000001001" || siwake.KasikataDetail.Kicd == "000000000001001")
                {
                    this.ChangeSiwakeTaisyakubetuDetailAsMototyouHukugouKeisikiAiteKamokuJudgmentType(
                        syokutiSiwakeTyouhyouRows,
                        siwake,
                        this.IsKarikataKamokuZibunItemKamokuInSiwake(siwake.KarikataDetail.Kicd, ((KamokuMototyouZibunItem)zibunItem).Kamoku, queryParameter) ? TaisyakuKubun.Kasikata : TaisyakuKubun.Karikata,
                        queryParameter);
                }
            }
        }

        private void ChangeSiwakeTaisyakubetuDetailAsMototyouHukugouKeisikiAiteKamokuJudgmentType(IList<ITanituSiwakeTyouhyouRow> syokutiSiwakeList, ITanituSiwakeTyouhyouRow siwake, TaisyakuKubun aiteTaisyakuKubun, MototyouQueryParameter queryParameter)
        {
            var sameGroupAiteSiwakeList = syokutiSiwakeList.Where(syokutiSiwake =>
                                          syokutiSiwake.DenpyouNo == siwake.DenpyouNo
                                          && syokutiSiwake.DenpyouDate.Ymd == siwake.DenpyouDate.Ymd
                                          && syokutiSiwake.GroupNo == siwake.GroupNo
                                          && (aiteTaisyakuKubun == TaisyakuKubun.Karikata ? syokutiSiwake.KarikataDetail : syokutiSiwake.KasikataDetail).Kicd != "000000000001001");
            var aiteKamokuTargetSiwake = queryParameter.OptionComposite.Option.HukugoukeisikiAiteKamokuJudgmentType == MototyouHukugoukeisikiAiteKamokuJudgmentType.FirstKamoku
                ? sameGroupAiteSiwakeList.OrderBy(syokutiSiwake => syokutiSiwake.LineNo).FirstOrDefault() //// 1：先頭の科目（行番号が最も若い仕訳）
                : sameGroupAiteSiwakeList.OrderByDescending(syokutiSiwake => syokutiSiwake.Kingaku).FirstOrDefault(); //// 2：一番金額が大きい科目
            if (aiteTaisyakuKubun == TaisyakuKubun.Karikata)
            {
                siwake.KarikataDetail = aiteKamokuTargetSiwake.KarikataDetail;
            }
            else
            {
                siwake.KasikataDetail = aiteKamokuTargetSiwake.KasikataDetail;
            }
        }

        /// <summary>
        /// 仕訳の借方と貸方のマスタデータが同じかどうかのチェック
        /// </summary>
        /// <param name="siwake"></param>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        private bool IsSameMasterDataOfKarikataAndKasikataInSiwake(ITanituSiwakeTyouhyouRow siwake, MototyouQueryParameter queryParameter)
        {
            switch (queryParameter.OptionComposite.QueryOption.MototyouType)
            {
                case MototyouType.Mototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd;

                case MototyouType.EdabanMototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd
                        && siwake.KarikataDetail.Ecod == siwake.KasikataDetail.Ecod;

                case MototyouType.BumonMototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd
                        && siwake.KarikataDetail.Bcod == siwake.KasikataDetail.Bcod;

                case MototyouType.BumonKamokuEdabanMototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd
                        && siwake.KarikataDetail.Bcod == siwake.KasikataDetail.Bcod
                        && siwake.KarikataDetail.Ecod == siwake.KasikataDetail.Ecod;

                case MototyouType.TorihikisakiMototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd
                        && siwake.KarikataDetail.Trcd == siwake.KasikataDetail.Trcd;

                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return siwake.KarikataDetail.Kicd == siwake.KasikataDetail.Kicd
                       && siwake.KarikataDetail.Bcod == siwake.KasikataDetail.Bcod
                       && siwake.KarikataDetail.Trcd == siwake.KasikataDetail.Trcd;

                default:
                    return false;
            }
        }

        protected class ZandakaTableDataForZenzanTaisyakuHasseiJudgment
        {
            public ZandakaTableDataForZenzanTaisyakuHasseiJudgment(IMasterZandaka zandaka, KamokuTaisyakuZokusei taisyakuZokusei, string kicd)
            {
                this.Zandaka = zandaka;
                this.TaisyakuZokusei = taisyakuZokusei;
                this.Kicd = kicd;
            }

            public IMasterZandaka Zandaka { get; private set; }

            public KamokuTaisyakuZokusei TaisyakuZokusei { get; private set; }

            public string Kicd { get; private set; }
        }

        /// <summary>
        /// 貸借金額
        /// </summary>
        private class TaisyakuValue
        {
            public TaisyakuValue(decimal karikataValue, decimal kasikataValue)
            {
                this.KarikataValue = karikataValue;
                this.KasikataValue = kasikataValue;
            }

            public decimal KarikataValue { get; set; }

            public decimal KasikataValue { get; set; }

            public void AddKingaku(decimal? karikataValue, decimal? kasikataValue)
            {
                if (karikataValue.HasValue)
                {
                    this.KarikataValue += karikataValue.Value;
                }

                if (kasikataValue.HasValue)
                {
                    this.KasikataValue += kasikataValue.Value;
                }
            }
        }
    }
}
