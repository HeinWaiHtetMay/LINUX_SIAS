﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class BumonKamokuEdabanMototyouRepository : AbstractMototyouRepository
    {
        [AutoInjection]
        private IBumonKamokuEdabanZandakaRepository bumonKamokuEdabanZandakaRepository = null;

        public override ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var bumonKamokuEdabanMototyouZibunItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;
            return this.FindZandakaSyuukeihyouByQueryParameter(mototyouQueryParameter, null, null, bumonKamokuEdabanMototyouZibunItem.Ecod, bumonKamokuEdabanMototyouZibunItem.Bcod, null, true, true, false);
        }

        protected override MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = base.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var bumonKamokuEdabanItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = bumonKamokuEdabanItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.EcodRangeValue.SetValue(bumonKamokuEdabanItem.Ecod, bumonKamokuEdabanItem.Ecod, false, false);
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = bumonKamokuEdabanItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.EcodRangeValue.SetValue(bumonKamokuEdabanItem.Ecod, bumonKamokuEdabanItem.Ecod, false, false);
            if (mototyouQueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.Bumon)
            {
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.BcodRangeValue.SetValue(bumonKamokuEdabanItem.Bcod, bumonKamokuEdabanItem.Bcod, false, false);
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.BcodRangeValue.SetValue(bumonKamokuEdabanItem.Bcod, bumonKamokuEdabanItem.Bcod, false, false);
            }
            else
            {
                siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.BcodRangeValue.SetValue(bumonKamokuEdabanItem.Bcod, bumonKamokuEdabanItem.Bcod, false, false);
            }

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.BumonTaniOutputSetting = mototyouQueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.SyuukeiBumon
                ? BumonTaniOutputSetting.SyuukeiBumonRangeSitei : BumonTaniOutputSetting.BumonRangeSitei;

            return siwakeTyouhyouQueryParameter;
        }

        protected override bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
        {
            var bumonKamokuEdabanItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;

            return (detail.Bcod == bumonKamokuEdabanItem.Bcod || detail.Sbcd == bumonKamokuEdabanItem.Bcod)
                && bumonKamokuEdabanItem.Kamoku.IsIncludeKamoku(detail.Kicd)
                && detail.Ecod == bumonKamokuEdabanItem.Ecod;
        }

        protected override ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment)
        {
            var bumonKamokuEdabanMototyouZibunItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, bumonKamokuEdabanMototyouZibunItem.Ecod, bumonKamokuEdabanMototyouZibunItem.Bcod, null, isTougetuHasseiJudgment, true, false);
            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(queryParameter, zibunItem, zandakaSyuukeihyou, !isTougetuHasseiJudgment);
        }

        protected override IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var bumonKamokuEdabanMototyouZibunItem = (BumonKamokuEdabanMototyouZibunItem)zibunItem;
            var mototyouKamoku = bumonKamokuEdabanMototyouZibunItem.Kamoku;

            var bumonKamokuEdabanZandakaList = this.bumonKamokuEdabanZandakaRepository.FindZandakaWithNameByPrimaryKeyRangesOrderByBcodAndKamokuOutputOrderAndEcod(
                queryParameter.Kesn,
                bumonKamokuEdabanMototyouZibunItem.Bcod,
                bumonKamokuEdabanMototyouZibunItem.Bcod,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[0]?.Kicd,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[mototyouKamoku.MeisaiKamokuList.Count - 1]?.Kicd,
                bumonKamokuEdabanMototyouZibunItem.Ecod,
                bumonKamokuEdabanMototyouZibunItem.Ecod,
                Domain.MasterModel.KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                Domain.SecurityModel.SecurityKubun.Output);

            var zandakaDataList = bumonKamokuEdabanZandakaList.Select(
                bumonKamokuEdabanZandaka => new ZandakaTableDataForZenzanTaisyakuHasseiJudgment((BumonKamokuEdabanZandakaWithName)bumonKamokuEdabanZandaka, bumonKamokuEdabanZandaka.TaisyakuZokusei, bumonKamokuEdabanZandaka.Kicd)).ToList();

            return zandakaDataList ?? new List<ZandakaTableDataForZenzanTaisyakuHasseiJudgment>();
        }
    }
}
