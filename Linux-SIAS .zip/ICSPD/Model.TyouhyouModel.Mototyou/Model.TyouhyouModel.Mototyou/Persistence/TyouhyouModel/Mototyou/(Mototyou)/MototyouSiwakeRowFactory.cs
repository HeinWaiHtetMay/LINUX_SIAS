﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Mathematics;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    public class MototyouSiwakeRowFactory
    {
        private MototyouQueryParameter queryParameter;
        private MototyouLayoutPattern layoutPattern;
        private SyouhizeiMaster syouhizeiMaster;
        private IDictionary<string, TokuteiSyuunyuuKamoku> tokuteiSyuunyuuKamokuDictionary;
        private IList<TanituSiwakeTyouhyouRowItemTextGetterByLayoutItem> siwakeRowItemTextGetters;
        private IMototyouZibunItem zibunItem;
        private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, IMototyouZibunItem, bool> isMasterMatch;
        private IMototyouZeiKubunFactory zeiKubunFactory;

        public MototyouSiwakeRowFactory(
            MototyouQueryParameter queryParameter,
            MototyouLayoutPattern layoutPattern,
            SyouhizeiMaster syouhizeiMaster,
            IMototyouZibunItem zibunItem,
            Func<TanituSiwakeTyouhyouTaisyakubetuDetail, IMototyouZibunItem, bool> isMasterMatch,
            IMototyouZeiKubunFactory zeiKubunFactory,
            IDictionary<string, TokuteiSyuunyuuKamoku> tokuteiSyuunyuuKamokuDictionary)
        {
            this.queryParameter = queryParameter;
            this.layoutPattern = layoutPattern;
            this.syouhizeiMaster = syouhizeiMaster;
            //// レイアウトパターンに自分摘要が存在するかどうか
            var existsZibunTekiyou = layoutPattern.Items.Any(item => item is MototyouLayoutTekiyouItem layoutItem && layoutItem.TekiyouValueType.IsZibun());
            this.siwakeRowItemTextGetters = layoutPattern.Items.Select(i => new TanituSiwakeTyouhyouRowItemTextGetterByLayoutItem(i, queryParameter.Syoriki, existsZibunTekiyou)).ToList();
            this.zibunItem = zibunItem;
            this.isMasterMatch = isMasterMatch;
            this.zeiKubunFactory = zeiKubunFactory;
            this.tokuteiSyuunyuuKamokuDictionary = tokuteiSyuunyuuKamokuDictionary;
        }

        private enum MototyouTaisyakuZokusei
        {
            Karikata, Kasikata, KarikataAndKasikata, None
        }

        /// <summary>
        /// 元帳の仕訳行のIEnumerableを生成します。
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="siwakeRow"></param>
        /// <param name="isSeirituki"></param>
        /// <returns></returns>
        public IEnumerable<MototyouSiwakeRow> CreateRowEnumerable(Mototyou mototyou, ITanituSiwakeTyouhyouRow siwakeRow, bool isSeirituki)
        {
            switch (this.GetTaisyakuZokusei(siwakeRow))
            {
                case MototyouTaisyakuZokusei.Karikata:
                    yield return this.CreateRow(mototyou, siwakeRow, isSeirituki, true);
                    break;
                case MototyouTaisyakuZokusei.Kasikata:
                    yield return this.CreateRow(mototyou, siwakeRow, isSeirituki, false);
                    break;
                case MototyouTaisyakuZokusei.KarikataAndKasikata:
                    //// 貸借ともに自分項目の場合は1仕訳から2行生成
                    yield return this.CreateRow(mototyou, siwakeRow, isSeirituki, true);
                    yield return this.CreateRow(mototyou, siwakeRow, isSeirituki, false);
                    break;
                default:
                    yield break;
            }
        }

        /// <summary>
        /// 一括税抜き仕訳行を生成します
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="ikkatuZeinukiSiwakeRows"></param>
        /// <param name="isSeirituki"></param>
        /// <returns></returns>
        public IEnumerable<MototyouSiwakeRow> CreateIkkatuZeinukiSiwakeRows(Mototyou mototyou, IEnumerable<ITanituSiwakeTyouhyouRow> ikkatuZeinukiSiwakeRows, bool isSeirituki)
        {
            Func<ITanituSiwakeTyouhyouRow, string> getAiteKicd = row => this.isMasterMatch(row.KarikataDetail, this.zibunItem) ? row.KasikataDetail.Kicd : row.KarikataDetail.Kicd;
            switch (this.queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType)
            {
                case MototyouIkkatuZeinukiSiwakeSyuukeiType.None:
                    //// 集計なし
                    return ikkatuZeinukiSiwakeRows.SelectMany(siwake => this.CreateRowEnumerable(mototyou, siwake, isSeirituki));
                case MototyouIkkatuZeinukiSiwakeSyuukeiType.PerKamoku:
                    return ikkatuZeinukiSiwakeRows
                        .GroupBy(getAiteKicd)
                        .OrderBy(g => g.Key)
                        .Select(g => this.CreateIkkatuZeinukiSiwakeAggregateRow(mototyou, g, isSeirituki))
                        .Where(s => s != null);
                case MototyouIkkatuZeinukiSiwakeSyuukeiType.PerKamokuAndZeiritu:
                    return ikkatuZeinukiSiwakeRows
                        //// 通常8%と軽減税率8%を区別するため、税率IDでグループ化
                        .GroupBy(siwake => new { AiteKicd = getAiteKicd(siwake), ZeirituId = this.GetIkkatuZeinukiZeiritu(siwake)?.Id ?? 0 })
                        .OrderBy(g => g.Key.AiteKicd)
                        .ThenBy(g => g.Key.ZeirituId)
                        .Select(g => this.CreateIkkatuZeinukiSiwakeAggregateRow(mototyou, g, isSeirituki))
                        .Where(s => s != null);
                default:
                    return new MototyouSiwakeRow[0];
            }
        }

        public MototyouSiwakeRow CreateRow(Mototyou mototyou, ITanituSiwakeTyouhyouRow siwakeRow, bool isSeirituki, bool isKarikata)
        {
            var mototyouRow = new MototyouSiwakeRow(mototyou, this.layoutPattern.ColumnCount, this.layoutPattern.RowCount);
            this.SetMototyouRowItems(mototyouRow, siwakeRow, isKarikata);
            this.SetMototyouRowItemsByLayoutItem(mototyou, mototyouRow, siwakeRow, isKarikata);
            if (this.layoutPattern.UseSyouhizeiKubun)
            {
                this.SetMototyouSiwakeRowZeikubunItems(mototyou, mototyouRow, siwakeRow, isKarikata);
            }

            mototyouRow.SasihikiZandaka = mototyou.RuikeiZandaka + mototyouRow.GetSasihikiValue();
            mototyouRow.IsSeirituki = isSeirituki;
            return mototyouRow;
        }

        /// <summary>
        /// 一括税抜仕訳の集計行を生成します。
        /// ※出力内容は「月日/金額/税区分（出力する場合のみ）/科目/摘要」のみ
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="siwakeRows"></param>
        /// <param name="isSeirituki"></param>
        /// <returns></returns>
        private MototyouSiwakeRow CreateIkkatuZeinukiSiwakeAggregateRow(Mototyou mototyou, IEnumerable<ITanituSiwakeTyouhyouRow> siwakeRows, bool isSeirituki)
        {
            var firstSiwake = siwakeRows.FirstOrDefault();
            if (firstSiwake == null)
            {
                return null;
            }

            var syuukeiRow = new MototyouSiwakeRow(mototyou, this.layoutPattern.ColumnCount, this.layoutPattern.RowCount);

            // 月日
            syuukeiRow.DenpyouDate = firstSiwake.DenpyouDate;

            if (this.layoutPattern.UseSyouhizeiKubun)
            {
                // 税区分
                this.SetMototyouSiwakeRowZeikubunItems(mototyou, syuukeiRow, firstSiwake, true);
            }

            // 摘要
            if (this.layoutPattern.ProgramTekiyouItemForIkkatuZeinukiSiwakeAggregateRow != null)
            {
                var syouhizeiritu = this.GetIkkatuZeinukiZeiritu(firstSiwake);
                var tekiyouText = this.queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType == MototyouIkkatuZeinukiSiwakeSyuukeiType.PerKamoku
                    ? Properties.Resources.一括税抜き_科目集計
                    : string.Format(
                        Properties.Resources.一括税抜き_科目集計_各税率分フォーマット,
                        (syouhizeiritu?.IsKeigenzeiritu ?? false) ? "*" : string.Empty, //// 軽減税率なら*をつける
                        this.GetIkkatuZeinukiZeiritu(firstSiwake)?.Zeiritu.GetDecmalValue().ToString("0%"));
                syuukeiRow.SetCellItem(this.layoutPattern.ProgramTekiyouItemForIkkatuZeinukiSiwakeAggregateRow, tekiyouText);
            }

            // 科目
            foreach (var textGetter in this.siwakeRowItemTextGetters.Where(textGetter => textGetter.LayoutItem is MototyouLayoutMasterDataItem))
            {
                var layoutMasterDataItem = textGetter.LayoutItem as MototyouLayoutMasterDataItem;
                if (layoutMasterDataItem.ItemType == MototyouLayoutItemType.Kamoku) //// TODO：仕様書には「相手科目」って書いてたけど、SIASは自分科目も表示してるから不要？→  && !layoutMasterDataItem.MasterDataValueType.IsZibun())
                {
                    syuukeiRow.SetCellItem(textGetter.LayoutItem, textGetter.GetItemText(firstSiwake, this.GetTaisyakuZokusei(firstSiwake) == MototyouTaisyakuZokusei.Karikata));
                }
            }

            // 金額
            decimal karikata = 0;
            decimal kasikata = 0;
            foreach (var siwake in siwakeRows)
            {
                switch (this.GetTaisyakuZokusei(siwake))
                {
                    case MototyouTaisyakuZokusei.Karikata:
                        karikata += siwake.Kingaku;
                        break;
                    case MototyouTaisyakuZokusei.Kasikata:
                        kasikata += siwake.Kingaku;
                        break;
                }
            }

            syuukeiRow.KarikataValue = karikata;
            syuukeiRow.KasikataValue = kasikata;
            syuukeiRow.SasihikiZandaka = mototyou.RuikeiZandaka + syuukeiRow.GetSasihikiValue();
            syuukeiRow.IsEnabledDenpyouKakunin = false;
            syuukeiRow.IsSeirituki = isSeirituki;
            return syuukeiRow;
        }

        private MototyouTaisyakuZokusei GetTaisyakuZokusei(ITanituSiwakeTyouhyouRow siwakeRow)
        {
            var isKarikata = this.isMasterMatch(siwakeRow.KarikataDetail, this.zibunItem);
            var isKasikata = this.isMasterMatch(siwakeRow.KasikataDetail, this.zibunItem);
            if (isKarikata && isKasikata)
            {
                return MototyouTaisyakuZokusei.KarikataAndKasikata;
            }
            else if (isKarikata)
            {
                return MototyouTaisyakuZokusei.Karikata;
            }
            else if (isKasikata)
            {
                return MototyouTaisyakuZokusei.Kasikata;
            }
            else
            {
                return MototyouTaisyakuZokusei.None;
            }
        }

        /// <summary>
        /// レイアウト無関係の共通項目取得
        /// </summary>
        /// <param name="mototyouRow"></param>
        /// <param name="tanituSiwaketyouhyouRow"></param>
        /// <param name="isKarikata"></param>
        private void SetMototyouRowItems(MototyouSiwakeRow mototyouRow, ITanituSiwakeTyouhyouRow tanituSiwaketyouhyouRow, bool isKarikata)
        {
            var aiteDetail = isKarikata ? tanituSiwaketyouhyouRow.KarikataDetail : tanituSiwaketyouhyouRow.KasikataDetail;
            mototyouRow.AiteKicd = aiteDetail.Kicd;
            mototyouRow.IsSeirituki = Syorituki.IsSeiritukiCkei(tanituSiwaketyouhyouRow.Dkei);
            mototyouRow.DenpyouDate = tanituSiwaketyouhyouRow.DenpyouDate;
            mototyouRow.DenpyouDkei = tanituSiwaketyouhyouRow.Dkei;
            mototyouRow.DenpyouNo = tanituSiwaketyouhyouRow.DenpyouNo;
            mototyouRow.DenpyouSeq = tanituSiwaketyouhyouRow.Dseq;
            mototyouRow.DenpyouUketukeNo = tanituSiwaketyouhyouRow?.UketukeNo == 0 ? null : (int?)tanituSiwaketyouhyouRow.UketukeNo;
            mototyouRow.SiwakeSeq = tanituSiwaketyouhyouRow.Sseq;
            mototyouRow.IsBusyobetuDenpyou = tanituSiwaketyouhyouRow.IsMitenkiData;
            mototyouRow.KarikataValue = isKarikata ? tanituSiwaketyouhyouRow.Kingaku : (decimal?)null;
            mototyouRow.KasikataValue = !isKarikata ? tanituSiwaketyouhyouRow.Kingaku : (decimal?)null;
            mototyouRow.SyouhizeiTaisyouKamokuSiireKubun = tanituSiwaketyouhyouRow.SyouhizeiTaisyouKamokuSiireKubun;
            ////差引残高は1行の内容で判別できないのでここでは扱わない
        }

        /// <summary>
        /// レイアウト項目から元帳行項目をセット
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="mototyouRow"></param>
        /// <param name="tyouhyouRow"></param>
        /// <param name="isKarikata"></param>
        private void SetMototyouRowItemsByLayoutItem(Mototyou mototyou, MototyouSiwakeRow mototyouRow, ITanituSiwakeTyouhyouRow tyouhyouRow, bool isKarikata)
        {
            foreach (var textGetter in this.siwakeRowItemTextGetters)
            {
                mototyouRow.SetCellItem(textGetter.LayoutItem, textGetter.GetItemText(tyouhyouRow, isKarikata));
            }
        }

        private void SetMototyouSiwakeRowZeikubunItems(Mototyou mototyou, MototyouSiwakeRow mototyouRow, ITanituSiwakeTyouhyouRow tyouhyouRow, bool isKarikata)
        {
            if (tyouhyouRow.IkkatuZeinukiSiwakeFlag == IkkatuZeinukiSiwakeFlag.TuuzyouSiwake)
            {
                //// 通常仕訳
                var zibunDetail = tyouhyouRow.GetUseDetail(true, isKarikata);
                var aiteDetail = tyouhyouRow.GetUseDetail(false, isKarikata);
                zibunDetail.KazeiKubun = this.GetKazeiKubun(zibunDetail);
                aiteDetail.KazeiKubun = this.GetKazeiKubun(aiteDetail);

                mototyouRow.ZibunZeiKubun = this.zeiKubunFactory.CreateSiwakeRowZeikubun(tyouhyouRow, zibunDetail, mototyou.ZibunItem);
                mototyouRow.AiteZeiKubun = this.zeiKubunFactory.CreateSiwakeRowZeikubun(tyouhyouRow, aiteDetail, mototyou.ZibunItem);
            }
            else
            {
                //// 一括税抜仕訳
                //// 一括税抜では相手の税区分のみ出力する
                //// 個別対応で一括税抜仕訳をまとめない場合は消費税対象科目の仕入区分を表示する
                mototyouRow.ZibunZeiKubun = this.zeiKubunFactory.CreateNullZeikubun();
                mototyouRow.AiteZeiKubun = this.zeiKubunFactory.CreateIkkatuZeinukiSiwakeRowZeikubun(
                    tyouhyouRow,
                    mototyou.ZibunItem,
                    this.syouhizeiMaster.SiireZeigakuAnbunhou == SiireZeigakuAnbunhou.KobetuTaiou && this.queryParameter.OptionComposite.Option.IkkatuZeinukiSiwakeSyuukeiType == MototyouIkkatuZeinukiSiwakeSyuukeiType.None ? tyouhyouRow.SyouhizeiTaisyouKamokuSiireKubun : null);
            }
        }

        private KazeiKubun? GetKazeiKubun(TanituSiwakeTyouhyouTaisyakubetuDetail taisyakubetuDetail)
        {
            if (this.syouhizeiMaster.IsTokuteiSyuunyuuTokureiKeisan
                && taisyakubetuDetail.KazeiKubun == KazeiKubun.消費税設定対象外
                && taisyakubetuDetail.KamokuSyoriGroup == KamokuSyoriGroup.Taisyougai
                && this.queryParameter.OptionComposite.Option.KazeiKubunOutputType != MototyouKazeiKubunOutputType.RelativeWithComparingMaster)
            {
                //// 特定収入の特例計算を行う
                //// 課税区分が未設定（消費税設定対象外）
                //// 科目の処理グループが対象外
                //// 課税区分の表示設定が「相対表示（マスターと比較）」以外　（→特定収入関連は伝票入力で課税区分の変更ができない為）
                if (this.tokuteiSyuunyuuKamokuDictionary.TryGetValue(taisyakubetuDetail.Kicd, out var tokuteiSyuunyuuKamoku))
                {
                    //// 特定収入関連科目として登録されている場合は、特定収入関連の課税区分として出力する
                    switch (tokuteiSyuunyuuKamoku.TokuteiSyuunyuuKubun)
                    {
                        case TokuteiSyuunyuuKubun.TokuteiSyuunyuu:
                            return KazeiKubun.特定収入;
                        case TokuteiSyuunyuuKubun.HutokuteiSyuunyuu:
                            return KazeiKubun.使途不明特定収入;
                        case TokuteiSyuunyuuKubun.TaisyougaiTokuteiSyuunyuu:
                            return KazeiKubun.外特定収入;
                    }
                }
            }

            return taisyakubetuDetail.KazeiKubun;
        }

        private Syouhizeiritu GetIkkatuZeinukiZeiritu(ITanituSiwakeTyouhyouRow tyouhyouRow)
        {
            //// 税率が設定されている方から取得
            return tyouhyouRow.KarikataDetail.Syouhizeiritu?.Zeiritu.GetValue() > 0
                ? tyouhyouRow.KarikataDetail.Syouhizeiritu
                : tyouhyouRow.KasikataDetail.Syouhizeiritu;
        }
    }
}
