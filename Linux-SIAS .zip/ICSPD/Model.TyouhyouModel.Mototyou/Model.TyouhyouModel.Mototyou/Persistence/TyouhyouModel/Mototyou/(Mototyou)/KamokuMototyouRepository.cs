﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class KamokuMototyouRepository : AbstractMototyouRepository
    {
        [AutoInjection]
        private IKamokuZandakaRepository kamokuZandakaRepotisory = null;

        public override ZandakaSyuukeihyou GetZandakaSyuukeihyou(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var kamokuMototyouZibunItem = (KamokuMototyouZibunItem)zibunItem;
            return this.FindZandakaSyuukeihyouByQueryParameter(mototyouQueryParameter, null, null, null, null, null, true, true, false);
        }

        protected override MototyouSiwakeTyouhyouQueryParameter CreateMototyouSiwakeTyouhyouQueryParameter(MototyouQueryParameter mototyouQueryParameter, IMototyouZibunItem zibunItem)
        {
            var siwakeTyouhyouQueryParameter = base.CreateMototyouSiwakeTyouhyouQueryParameter(mototyouQueryParameter, zibunItem);
            var kamokuItem = (KamokuMototyouZibunItem)zibunItem;

            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KarikataQueryOption.KamokuKobetuSiteiList = kamokuItem.Kamoku.MeisaiKamokuList;
            siwakeTyouhyouQueryParameter.SiwakeTyouhyouQueryOption.KasikataQueryOption.KamokuKobetuSiteiList = kamokuItem.Kamoku.MeisaiKamokuList;

            return siwakeTyouhyouQueryParameter;
        }

        protected override bool IsMasterMatch(TanituSiwakeTyouhyouTaisyakubetuDetail detail, IMototyouZibunItem zibunItem)
        {
            var kamokuItem = (KamokuMototyouZibunItem)zibunItem;

            return kamokuItem.Kamoku.IsIncludeKamoku(detail.Kicd);
        }

        protected override ZandakaSyuukeihyouRow GetZandakaSyuukeihyouRowByMototyouQueryParameter(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, bool isTougetuHasseiJudgment)
        {
            var kamokuMototyouZibunItem = (KamokuMototyouZibunItem)zibunItem;
            var zandakaSyuukeihyou = this.FindZandakaSyuukeihyouByQueryParameter(queryParameter, null, null, null, null, null, isTougetuHasseiJudgment, true, false);
            return this.GetZandakaSyuukeihyouRowByMototyouQueryParameterAndZandakaSyuukeihyou(queryParameter, zibunItem, zandakaSyuukeihyou, !isTougetuHasseiJudgment);
        }

        protected override IList<ZandakaTableDataForZenzanTaisyakuHasseiJudgment> GetZandakaTableDataList(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem)
        {
            var mototyouKamoku = ((KamokuMototyouZibunItem)zibunItem).Kamoku;

            var kamokuZandakaList = this.kamokuZandakaRepotisory.FindZandakaWithNameByPrimaryKeyAndKamokuKanaRangesOrderByKamokuOutputOrder(
                queryParameter.Kesn,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[0]?.Kicd,
                queryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.KisokugaiSyuukeiKamoku || mototyouKamoku.MeisaiKamokuList.Count == 0 ? null : mototyouKamoku.MeisaiKamokuList[mototyouKamoku.MeisaiKamokuList.Count - 1]?.Kicd,
                null,
                null,
                KamokuOutputOrder.ByInnerCode,
                queryParameter.SecurityContext,
                Domain.SecurityModel.SecurityKubun.Output);

            var zandakaDataList = kamokuZandakaList.Select(
                kamokuZandaka => new ZandakaTableDataForZenzanTaisyakuHasseiJudgment(kamokuZandaka, kamokuZandaka.TaisyakuZokusei, kamokuZandaka.Kicd)).ToList();

            return zandakaDataList ?? new List<ZandakaTableDataForZenzanTaisyakuHasseiJudgment>();
        }
    }
}
