﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    /// <summary>
    /// 自分or相手の概念は元帳独自かつ、各クラスから参照するメソッドのため、Mototyou側の拡張メソッドとして実装
    /// </summary>
    public static class TanituSiwakeTyouhyouRowExtension
    {
        public static TanituSiwakeTyouhyouTaisyakubetuDetail GetUseDetail(this ITanituSiwakeTyouhyouRow tanituSiwakeTyouhyouRow, bool isZibun, bool isKarikata)
        {
            return isZibun == isKarikata ? tanituSiwakeTyouhyouRow.KarikataDetail : tanituSiwakeTyouhyouRow.KasikataDetail;
        }
    }
}
