﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Open21.Domain.DenpyouModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.SiwakeTyouhyou;

    /// <summary>
    /// MototyouLayoutItemからTanituSiwakeTyouhyouRowの項目を取得するクラス
    /// </summary>
    public class TanituSiwakeTyouhyouRowItemTextGetterByLayoutItem
    {
        private AbstractRowItemTextGetter rowItemTextGetter;

        public TanituSiwakeTyouhyouRowItemTextGetterByLayoutItem(MototyouLayoutItem layoutItem, Syoriki syoriki, bool existsZibunTekiyou)
        {
            this.LayoutItem = layoutItem;
            if (layoutItem.ItemType == MototyouLayoutItemType.Tekiyou)
            {
                this.rowItemTextGetter = new TekiyouLayoutItem((MototyouLayoutTekiyouItem)layoutItem, existsZibunTekiyou);
            }
            else if (layoutItem.ItemType.IsMasterType())
            {
                this.rowItemTextGetter = new MasterLayoutItem((MototyouLayoutMasterDataItem)layoutItem, syoriki);
            }
            else
            {
                this.rowItemTextGetter = new NonDetailLayoutItem(layoutItem.ItemType);
            }
        }

        public MototyouLayoutItem LayoutItem { get; private set; }

        public string GetItemText(ITanituSiwakeTyouhyouRow row, bool isKarikata)
        {
            return this.rowItemTextGetter.GetItemText(row, isKarikata);
        }

        private abstract class AbstractRowItemTextGetter
        {
            public abstract string GetItemText(ITanituSiwakeTyouhyouRow row, bool isKarikata);
        }

        private class TekiyouLayoutItem : AbstractRowItemTextGetter
        {
            private MototyouLayoutTekiyouItem layoutItem;
            private bool existsZibunTekiyou;

            public TekiyouLayoutItem(MototyouLayoutTekiyouItem layoutItem, bool existsZibunTekiyou)
            {
                this.layoutItem = layoutItem;
                this.existsZibunTekiyou = existsZibunTekiyou;
            }

            public override string GetItemText(ITanituSiwakeTyouhyouRow row, bool isKarikata)
            {
                var isZibun = this.layoutItem.TekiyouValueType.IsZibun();
                if (isZibun)
                {
                    return this.layoutItem.TekiyouValueType.GetFilteringText(row.GetUseDetail(isZibun, isKarikata).Tekiyou);
                }
                else
                {
                    //// 貸借別摘要になっているか、自分摘要がレイアウトに存在しない場合しか相手摘要を取得しない
                    return !this.existsZibunTekiyou || row.TaisyakuTekiyouFlag == TaisyakuTekiyouFlag.TaisyakubetuTekiyou
                        ? this.layoutItem.TekiyouValueType.GetFilteringText(row.GetUseDetail(isZibun, isKarikata).Tekiyou)
                        : string.Empty;
                }
            }
        }

        private class MasterLayoutItem : AbstractRowItemTextGetter
        {
            private MototyouLayoutMasterDataItem layoutItem;
            private Syoriki syoriki;
            private bool isZibun;
            private bool isUniversalField;
            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> getMasterItemText;
            private int universalFieldNo;

            public MasterLayoutItem(MototyouLayoutMasterDataItem layoutItem, Syoriki syoriki)
            {
                this.layoutItem = layoutItem;
                this.isZibun = this.layoutItem.MasterDataValueType.IsZibun();
                this.syoriki = syoriki;
                this.isUniversalField = this.layoutItem.ItemType.IsUniversalField();

                //// GetItemTextにて、元帳行×レイアウト項目数分のCASE判定を避けるため、TanituSiwakeTyouhyouTaisyakubetuDetail→stringの変換デリゲートを設定する
                //// (レイアウト項目により、TanituSiwakeTyouhyouTaisyakubetuDetail→stringの変換対象は決まるため、GetItemTextごとに判定する必要がない)
                this.getMasterItemText = this.isUniversalField
                    ? this.CreateGetUniversalFieldText()
                    : this.CreateGetMasterCodeOrName();
            }

            public override string GetItemText(ITanituSiwakeTyouhyouRow row, bool isKarikata)
            {
                var detail = row.GetUseDetail(this.isZibun, isKarikata);
                return this.getMasterItemText(detail);
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetUniversalFieldText()
            {
                this.universalFieldNo = this.layoutItem.ItemType.GetUniversalFieldNo();
                var universalFieldInfo = this.syoriki.GetUniversalFieldInfo(false, this.universalFieldNo);
                if (!universalFieldInfo.IsCreateMaster || this.layoutItem.MasterDataValueType.IsCode())
                {
                    return this.CreateGetUniversalFieldText(universalFieldInfo);
                }
                else if (this.layoutItem.MasterDataValueType.IsShortName())
                {
                    return detail => detail.GetUniversalFieldName(this.universalFieldNo);
                }
                else
                {
                    return detail => detail.GetUniversalFieldLongName(this.universalFieldNo);
                }
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetUniversalFieldText(UniversalFieldInfo universalFieldInfo)
            {
                switch (universalFieldInfo.DataType)
                {
                    case UniversalFieldDataType.Decimal:
                        //// カンマと小数点を合わせた最大文字数
                        var maxLengthWithCommaAndDecimalPoint = universalFieldInfo.CodeMaxLength + universalFieldInfo.DecimalPartMaxLength
                            + (universalFieldInfo.CodeMaxLength % 3 > 0 ? (universalFieldInfo.CodeMaxLength / 3) + 1 : universalFieldInfo.CodeMaxLength / 3)
                            + 1;
                        return detail => detail.GetUniversalFieldCode(this.universalFieldNo).PadLeft(maxLengthWithCommaAndDecimalPoint, ' ');
                    case UniversalFieldDataType.Money:
                        //// カンマを合わせた最大文字数
                        var maxLengthWithComma = universalFieldInfo.CodeMaxLength
                            + (universalFieldInfo.CodeMaxLength % 3 > 0 ? (universalFieldInfo.CodeMaxLength / 3) + 1 : universalFieldInfo.CodeMaxLength / 3);
                        return detail => detail.GetUniversalFieldCode(this.universalFieldNo).PadLeft(maxLengthWithComma, ' ');
                    default:
                        return detail => detail.GetUniversalFieldCode(this.universalFieldNo);
                }
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetMasterCodeOrName()
            {
                switch (this.layoutItem.MasterDataValueType)
                {
                    case MototyouLayoutItemMasterDataValueType.AiteCode:
                    case MototyouLayoutItemMasterDataValueType.ZibunCode:
                        return this.CreateGetMasterCode();
                    case MototyouLayoutItemMasterDataValueType.AiteShortName:
                    case MototyouLayoutItemMasterDataValueType.ZibunShortName:
                        return this.CreateGetMasterShortName();
                    case MototyouLayoutItemMasterDataValueType.AiteLongName:
                    case MototyouLayoutItemMasterDataValueType.ZibunLongName:
                        return this.CreateGetLongName();
                    default:
                        return detail => string.Empty;
                }
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetMasterCode()
            {
                switch (this.layoutItem.ItemType)
                {
                    case MototyouLayoutItemType.Kamoku:
                        return detail => detail.Kcod;
                    case MototyouLayoutItemType.Bumon:
                        return detail => detail.Bcod;
                    case MototyouLayoutItemType.Edaban:
                        return detail => detail.Ecod;
                    case MototyouLayoutItemType.Torihikisaki:
                        return detail => detail.Trcd;
                    case MototyouLayoutItemType.Segment:
                        return detail => detail.Sgcd;
                    case MototyouLayoutItemType.Project:
                        return detail => detail.Pjcd;
                    case MototyouLayoutItemType.ZiyuuTekiyou:
                        return detail => string.Format("{0:D4}", detail.TekiyouCode);
                    case MototyouLayoutItemType.Kouzi:
                        return detail => detail.Kzcd;
                    case MototyouLayoutItemType.Kousyu:
                        return detail => detail.Kscd;
                    default:
                        return detail => string.Empty;
                }
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetMasterShortName()
            {
                switch (this.layoutItem.ItemType)
                {
                    case MototyouLayoutItemType.Bumon:
                        return detail => detail.BumonName;
                    case MototyouLayoutItemType.Edaban:
                        return detail => detail.EdabanName;
                    case MototyouLayoutItemType.Torihikisaki:
                        return detail => detail.TorihikisakiName;
                    case MototyouLayoutItemType.Segment:
                        return detail => detail.SegmentName;
                    case MototyouLayoutItemType.Project:
                        return detail => detail.ProjectName;
                    case MototyouLayoutItemType.ZiyuuTekiyou:
                        return detail => detail.TekiyouName;
                    case MototyouLayoutItemType.Kouzi:
                        return detail => detail.KouziName;
                    case MototyouLayoutItemType.Kousyu:
                        return detail => detail.KousyuName;
                    default:
                        return detail => string.Empty;
                }
            }

            private Func<TanituSiwakeTyouhyouTaisyakubetuDetail, string> CreateGetLongName()
            {
                switch (this.layoutItem.ItemType)
                {
                    case MototyouLayoutItemType.Kamoku:
                        return detail => detail.KamokuLongName;
                    case MototyouLayoutItemType.Torihikisaki:
                        return detail => detail.TorihikisakiLongName;
                    case MototyouLayoutItemType.Segment:
                        return detail => detail.SegmentLongName;
                    case MototyouLayoutItemType.Project:
                        return detail => detail.ProjectLongName;
                    case MototyouLayoutItemType.Kouzi:
                        return detail => detail.KouziLongName;
                    default:
                        return detail => string.Empty;
                }
            }
        }

        /// <summary>
        /// 詳細不要項目の取得処理を取得する
        /// </summary>
        private class NonDetailLayoutItem : AbstractRowItemTextGetter
        {
            private Func<ITanituSiwakeTyouhyouRow, string> getSiwakeItemText;

            public NonDetailLayoutItem(MototyouLayoutItemType itemType)
            {
                //// GetItemTextにて、元帳行×レイアウト項目数分のCASE判定を避けるため、ITanituSiwakeTyouhyouRow→stringの変換デリゲートを設定する
                //// (レイアウト項目により、ITanituSiwakeTyouhyouRow→stringの変換対象は決まるため、GetItemTextごとに判定する必要がない)
                this.getSiwakeItemText = this.CreateGetSiwakeItemText(itemType);
            }

            public override string GetItemText(ITanituSiwakeTyouhyouRow row, bool isKarikata)
            {
                return this.getSiwakeItemText(row);
            }

            private Func<ITanituSiwakeTyouhyouRow, string> CreateGetSiwakeItemText(MototyouLayoutItemType itemType)
            {
                switch (itemType)
                {
                    case MototyouLayoutItemType.DenpyouNo:
                        return row => row.DenpyouNo?.ToString().PadLeft(8) ?? string.Empty;
                    case MototyouLayoutItemType.UketukeNo:
                        return row => row.UketukeNo.ToString().PadLeft(8);
                    //// TODO：外貨元帳用の項目
                    case MototyouLayoutItemType.GaikaRate:
                    default:
                        return row => string.Empty;
                }
            }
        }
    }
}
