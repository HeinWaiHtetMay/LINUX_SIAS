﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouLayoutColumnRepository : IMototyouLayoutColumnRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<MototyouLayoutColumn> FindByPatternNo(int patternNo)
        {
            return this.dbc.QueryForList(
                "SELECT ptno, colno, colwidth, psize, gyo1, gyo2, gyo3, cdm1, cdm2, idm1, idm2 " +
                "FROM ledwidth " +
                "WHERE ptno = :p ",
                (values, no) =>
                {
                    var ptno = (int)(short)values[0];
                    var colno = (int)(short)values[1];
                    var row = new MototyouLayoutColumn(ptno, colno);
                    row.ColumnPrintWidth = (MototyouLayoutColumnPrintWidth)(short)values[2]; // 列幅
                    row.CharPrintSize = (MototyouLayoutCharPrintSize)(short)values[3]; // 印刷サイズ
                    row.HeaderTitleRow1 = DbNullConverter.ToString(values[4]); // 1行目
                    row.HeaderTitleRow2 = DbNullConverter.ToString(values[5]); // 2行目
                    row.HeaderTitleRow3 = DbNullConverter.ToString(values[6]); // 3行目
                    return row;
                },
                () => new List<MototyouLayoutColumn>(),
                patternNo);
        }
    }
}
