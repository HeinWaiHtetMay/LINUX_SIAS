﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouLayoutItemRepository : IMototyouLayoutItemRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private IMototyouLayoutItemFactory mototyouLayoutItemFactory = null;

        public virtual IList<MototyouLayoutItem> FindByPatternNo(int patternNo)
        {
            return this.dbc.QueryForList(
                "SELECT ptno, colno, gyono, komoku, shosai, mojiwidth, kinto " +
                "FROM ledlay " +
                "WHERE ptno = :p ",
                (values, no) =>
                {
                    var ptno = (int)(short)values[0];
                    var colno = (int)(short)values[1];
                    var gyono = (int)(short)values[2];
                    var itemType = (MototyouLayoutItemType)(short)values[3];
                    var detail = (int)(short)values[4];

                    var item = this.mototyouLayoutItemFactory.CreateMototyouLayoutItem(itemType, detail, ptno, colno, gyono);

                    item.CharWidth = (MototyouLayoutItemCharWidth)(short)values[5]; // 文字幅
                    item.KintouWaritukeType = (MototyouLayoutKintouWaritukeType)(short)values[6]; // 均等割付
                    return item;
                },
                () => new List<MototyouLayoutItem>(),
                patternNo);
        }
    }
}
