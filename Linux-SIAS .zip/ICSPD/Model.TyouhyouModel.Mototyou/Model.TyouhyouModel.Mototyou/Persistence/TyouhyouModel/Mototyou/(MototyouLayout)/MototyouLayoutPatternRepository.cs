﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.PrintDocumentModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouLayoutPatternRepository : IMototyouLayoutPatternRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private IMototyouLayoutColumnRepository columnRepository = null;
        [AutoInjection]
        private MototyouLayoutItemRepository itemRepository = null;

        public virtual MototyouLayoutPattern FindByPatternNo(int patternNo)
        {
            var columns = this.columnRepository.FindByPatternNo(patternNo);
            var items = this.itemRepository.FindByPatternNo(patternNo);
            return this.dbc.QueryForObject(
                "SELECT ptno, ptnm, col, gyo, psize, zeikbn, keta, kurai, lmgn, tmgn, kinto, lusr, lmod, ltim " +
                "FROM ledptn " +
                "WHERE ptno = :p ",
                (values, no) =>
                {
                    var row = new MototyouLayoutPattern((int)(short)values[0], columns, items);
                    row.PatternName = DbNullConverter.ToString(values[1]); // パターン名称
                    row.ColumnCount = (int)(short)values[2]; // 列数
                    row.RowCount = (int)(short)values[3]; // 行数
                    var paperSetting = (short)values[4]; // 用紙設定、1:A4横、2:A4縦、3:A3横、4:A3縦、9:印刷しない
                    row.PaperSize = paperSetting == 9
                        ? null
                        : new IcspPaperSize(
                            paperSetting == 1 || paperSetting == 2 ? IcspPaperKind.A4 : IcspPaperKind.A3,
                            paperSetting == 1 || paperSetting == 3 ? IcspPaperOrient.LandScape : IcspPaperOrient.Portrait);
                    row.UseSyouhizeiKubun = (short)values[5] == 1; // 税区分
                    row.KingakuLength = (MototyouLayoutKingakuLength)(short)values[6]; // 金額桁数
                    row.KingakuScaleType = (MototyouLayoutKingakuScaleType)(short)values[7]; // 位取り
                    row.LeftMargin = (int)(short)values[8]; // 左余白
                    row.TopMargin = (int)(short)values[9]; // 上余白
                    row.TitleKintouWarituke = (MototyouLayoutKintouWaritukeType)(short)values[10]; // タイトル項目の均等割付
                    row.Lusr = (int)values[11]; // 最終更新者
                    row.Lmod = (int)values[12]; // 最終更新日
                    row.Ltim = (int)values[13]; // 最終更新時刻
                    return row;
                },
                patternNo);
        }

        public virtual IList<IMasterData> GetPatternNoAndName()
        {
            return this.dbc.QueryForList(
                "SELECT ptno, ptnm " +
                "FROM ledptn ORDER BY ptno",
                (values, no) =>
                {
                    var ptno = (int)(short)values[0];
                    var row = new MototyouLayoutPattern(ptno);
                    row.PatternName = DbNullConverter.ToString(values[1]); // パターン名称
                    return row;
                },
                () => new List<IMasterData>());
        }
    }
}
