﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class MototyouOutputOptionCompositeRepository : IMototyouOutputOptionCompositeRepository
    {
        [AutoInjection]
        private ISokyuuSagakuCalculateOptionRepository sokyuuSagakuCalculateOptionRepository = null;
        [AutoInjection]
        private ISiwakeOutputOptionRepository siwakeOutputOptionRepository = null;
        [AutoInjection]
        private ISiwakeKazeikubunOutputOptionRepository siwakeKazeikubunOutputOptionRepository = null;

        public MototyouOutputOptionComposite FindByKesn(int kesn)
        {
            var optionComposite = new MototyouOutputOptionComposite();

            //// 遡及の差額計算設定取得
            optionComposite.SokyuuSagakuCalculateOption = this.sokyuuSagakuCalculateOptionRepository.Find();

            //// 税率出力設定と自動諸口名称設定取得
            optionComposite.SiwakeOutputOption = this.siwakeOutputOptionRepository.Find();

            optionComposite.ShouldOutputKazeiKubunTaisyougai = this.siwakeKazeikubunOutputOptionRepository.GetOutputKazeiKubunTaisyougaiByKesn(kesn);

            return optionComposite;
        }
    }
}
