﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class MototyouOptionCompositeRepository : IMototyouOptionCompositeRepository
    {
        private const int CommonUserCode = 10000;

        [AutoInjection]
        private IOption1Dao option1Dao = null;
        [AutoInjection]
        private IOptionUnitRepository optionUnitRepository = null;

        public virtual MototyouOptionComposite FindByUserCode(int userCode, bool isBusyoNyuusyuturyokuSyori)
        {
            var result = new MototyouOptionComposite(userCode);
            var isUserOption = this.GetIsUserOption(isBusyoNyuusyuturyokuSyori);

            foreach (var option1 in this.option1Dao.FindByPrgidAndUsno(DatabaseType.KaisyaDb, "LEDMAIN", userCode))
            {
                switch (option1.Keynm1)
                {
                    case "SAVEDATA":
                        this.SetQueryOptionAndPrintOptionProperties(result.QueryOption, result.PrintOption, option1);
                        break;
                    case "MARGIN":
                        switch (option1.Keynm2)
                        {
                            case "LEFT":
                                result.MarginOption.Left = option1?.Idata.Value ?? 0;
                                break;
                            case "TOP":
                                result.MarginOption.Top = option1?.Idata.Value ?? 0;
                                break;
                        }

                        break;
                }
            }

            foreach (var option1 in isUserOption ? this.option1Dao.FindByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "LEDMAIN", userCode, "OPTION") : this.option1Dao.FindByPrgidAndKeyNm1ForUserShared(DatabaseType.KaisyaDb, "LEDMAIN", "OPTION"))
            {
                this.SetOptionProperties(result.Option, option1);
            }

            return result;
        }

        public virtual void Store(MototyouOptionComposite optionComposite, bool isBusyoNyuusyuturyokuSyori)
        {
            //// [KEYNM1=OPTION]の情報を削除・保存するためのユーザーコード
            var userCodeForOption = this.GetIsUserOption(isBusyoNyuusyuturyokuSyori) ? optionComposite.UserCode : CommonUserCode;
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "LEDMAIN", optionComposite.UserCode, "SAVEDATA");
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "LEDMAIN", userCodeForOption, "OPTION");
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1(DatabaseType.KaisyaDb, "LEDMAIN", optionComposite.UserCode, "MARGIN");
            var printOption = optionComposite.PrintOption;
            var queryOption = optionComposite.QueryOption;
            var option = optionComposite.Option;
            var marginOption = optionComposite.MarginOption;
            new List<Option1Dto>()
            {
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "KAIPG", 0, printOption.PrintPagePerMonth),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "DUPLEX", 0, printOption.IsBothSidesPrinting),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "COLOR", 0, printOption.IsColorPrinting),

                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "LAYOUT_NO", 0, queryOption.LayoutPatternNo.GetValueOrDefault()),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "BFLG", 0, (int)queryOption.BumonType),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "BKBN", 0, (int)queryOption.KamokuType),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "HASSEI", 0, (int)queryOption.OutputCondition),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "MOTOTYPE", 0, this.ConvertToDBMOTOTYPE(queryOption.MototyouType)),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SORT", 1, (int)queryOption.BumonMototyouOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SORT", 2, (int)queryOption.EdabanMototyouOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SORT", 3, (int)queryOption.TorihikisakiMototyouOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SORT", 4, (int)queryOption.BumonKamokuEdabanMototyouOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SORT", 5, (int)queryOption.BumonKamokuTorihikisakiMototyouOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SEIRI", 0, queryOption.UseUserSeiritukiCalculateOption ? 0 : 1),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SYUKEI", 0, (int)queryOption.SyuukeiKeisikiApplyingWay),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "SAVEDATA", "SKEI", 0, (int)queryOption.SyuukeiKeisiki),

                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "KANJI", 0, (int)option.OutputSeirituki),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TUKIKEI", 0, (int)option.MonthlyTotal),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "RUIKEI", 0, (int)option.RuikeiOutputType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "ZEIKBN", 0, (int)optionComposite.Option.KazeiKubunOutputType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "EXKMK_ZEIKBN", 0, option.UseTitleRegisterdFirstKamokuKazeiKubunIfKisokugaiSyuukeiKamoku),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "IKKATU", 0, (int)option.IkkatuZeinukiSiwakeSyuukeiType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "IKKATU_POS", 0, option.OutputIkkatuZeinuykiSiwakeLastOnMonthIfSyuukeiTypeIsNone ? 1 : 0),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "ZENZAN", 0, (int)option.ZenzanJudgmentType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TOUGETU", 0, (int)option.TougetuHasseiJudgmentType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "DAYZAN", 0, (int)option.SasihikiZandakaType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "KOUT", 0, (int)option.KamokuOutputOrder),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "AITEKMK", 0, (int)option.HukugoukeisikiAiteKamokuJudgmentType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "PAGE", 0, (int)option.PrintPageNoSequenceType),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TORINM", 0, (int)option.PrintTorihikisakiName),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 0, option.MototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 2, option.EdabanMototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 1, option.BumonMototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 4, option.BumonKamokuEdabanMototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 3, option.TorihikisakiMototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "TITLE", 5, option.BumonKamokuTorihikisakiMototyouTitle),
                new Option1Dto().SetValues("LEDMAIN", userCodeForOption, "OPTION", "CSVTITLE", 0, (int)option.CsvTitleType),

                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "MARGIN", "LEFT", 0, marginOption.Left),
                new Option1Dto().SetValues("LEDMAIN", optionComposite.UserCode, "MARGIN", "TOP", 0, marginOption.Top)
            }.ForEach(dto => this.option1Dao.InsertOrUpdate(DatabaseType.KaisyaDb, dto));
        }

        private void SetQueryOptionAndPrintOptionProperties(MototyouQueryOption queryOption, MototyouPrintOption printOption, Option1Dto option1Dto)
        {
            var idata = option1Dto?.Idata ?? 0;
            switch (option1Dto.Keynm2)
            {
                case "LAYOUT_NO":
                    queryOption.LayoutPatternNo = idata == 0 ? (int?)null : idata;
                    break;
                case "BFLG":
                    queryOption.BumonType = (MototyouBumonType)idata;
                    break;
                case "BKBN":
                    queryOption.KamokuType = (MototyouKamokuType)idata;
                    break;
                case "HASSEI":
                    queryOption.OutputCondition = (MototyouOutputCondition)idata;
                    break;
                case "MOTOTYPE":
                    queryOption.MototyouType = this.ConvertToMototyouType(idata);
                    break;
                case "SORT":
                    this.SetMototyouOutputOrder(queryOption, option1Dto.Keyno, idata);
                    break;
                case "SYUKEI":
                    queryOption.SyuukeiKeisikiApplyingWay = (MototyouSyuukeiKeisikiApplyingWay)idata;
                    break;
                case "SKEI":
                    queryOption.SyuukeiKeisiki = (MototyouSyuukeiKeisiki)idata;
                    break;
                case "SEIRI":
                    queryOption.UseUserSeiritukiCalculateOption = idata == 0;
                    break;

                case "KAIPG":
                    printOption.PrintPagePerMonth = idata == 1;
                    break;
                case "DUPLEX":
                    printOption.IsBothSidesPrinting = idata == 1;
                    break;
                case "COLOR":
                    printOption.IsColorPrinting = idata == 1;
                    break;
            }
        }

        private void SetOptionProperties(MototyouOption option, Option1Dto option1Dto)
        {
            var idata = option1Dto?.Idata ?? 0;
            switch (option1Dto.Keynm2)
            {
                //// 全般
                case "KANJI":
                    option.OutputSeirituki = (MototyouOutputSeirituki)idata;
                    break;
                case "TUKIKEI":
                    option.MonthlyTotal = (MototyouMonthlyTotal)idata;
                    break;
                case "RUIKEI":
                    option.RuikeiOutputType = (MototyouRuikeiOutputType)idata;
                    break;
                case "ZEIKBN":
                    option.KazeiKubunOutputType = (MototyouKazeiKubunOutputType)idata;
                    break;
                case "EXKMK_ZEIKBN":
                    option.UseTitleRegisterdFirstKamokuKazeiKubunIfKisokugaiSyuukeiKamoku = idata == 1;
                    break;
                case "IKKATU":
                    option.IkkatuZeinukiSiwakeSyuukeiType = (MototyouIkkatuZeinukiSiwakeSyuukeiType)idata;
                    break;
                case "IKKATU_POS":
                    option.OutputIkkatuZeinuykiSiwakeLastOnMonthIfSyuukeiTypeIsNone = idata == 1;
                    break;

                //// 判定方法
                case "ZENZAN":
                    option.ZenzanJudgmentType = (MototyouZenzanJudgmentType)idata;
                    break;
                case "TOUGETU":
                    option.TougetuHasseiJudgmentType = (MototyouTougetuHasseiJudgmentType)idata;
                    break;
                case "DAYZAN":
                    option.SasihikiZandakaType = (MototyouSasihikiZandakaType)idata;
                    break;
                case "KOUT":
                    option.KamokuOutputOrder = (MototyouKamokuOutputOrder)idata;
                    break;
                case "AITEKMK":
                    option.HukugoukeisikiAiteKamokuJudgmentType = (MototyouHukugoukeisikiAiteKamokuJudgmentType)idata;
                    break;

                //// 印刷設定
                case "PAGE":
                    option.PrintPageNoSequenceType = (MototyouPrintPageNoSequenceType)idata;
                    break;
                case "TORINM":
                    option.PrintTorihikisakiName = (MototyouPrintTorihikisakiName)idata;
                    break;

                //// タイトル
                case "TITLE":
                    this.SetTitle(option, option1Dto.Keyno, option1Dto.Cdata);
                    break;
                case "CSVTITLE":
                    option.CsvTitleType = (MototyouTitleType)idata;
                    break;
            }
        }

        private void SetMototyouOutputOrder(MototyouQueryOption queryOption, int keyNo, int idata)
        {
            switch (keyNo)
            {
                case 1:
                    queryOption.BumonMototyouOutputOrder = (BumonMototyouOutputOrder)idata;
                    break;
                case 2:
                    queryOption.EdabanMototyouOutputOrder = (EdabanMototyouOutputOrder)idata;
                    break;
                case 3:
                    queryOption.TorihikisakiMototyouOutputOrder = (TorihikisakiMototyouOutputOrder)idata;
                    break;
                case 4:
                    queryOption.BumonKamokuEdabanMototyouOutputOrder = (BumonKamokuEdabanMototyouOutputOrder)idata;
                    break;
                case 5:
                    queryOption.BumonKamokuTorihikisakiMototyouOutputOrder = (BumonKamokuTorihikisakiMototyouOutputOrder)idata;
                    break;
            }
        }

        private void SetTitle(MototyouOption option, int keyNo, string cdata)
        {
            switch (keyNo)
            {
                case 0:
                    option.MototyouTitle = cdata;
                    break;
                case 1:
                    option.BumonMototyouTitle = cdata;
                    break;
                case 2:
                    option.EdabanMototyouTitle = cdata;
                    break;
                case 3:
                    option.TorihikisakiMototyouTitle = cdata;
                    break;
                case 4:
                    option.BumonKamokuEdabanMototyouTitle = cdata;
                    break;
                case 5:
                    option.BumonKamokuTorihikisakiMototyouTitle = cdata;
                    break;
            }
        }

        private bool GetIsUserOption(bool isBusyoNyuusyuturyokuSyori)
        {
            if (isBusyoNyuusyuturyokuSyori)
            {
                return (this.optionUnitRepository.Find()?.BusyobetuMototyouOptionUnit ?? new OptionUnit().BusyobetuMototyouOptionUnit) == OptionUnitValue.User;
            }
            else
            {
                return (this.optionUnitRepository.Find()?.MototyouOptionUnit ?? new OptionUnit().MototyouOptionUnit) == OptionUnitValue.User;
            }
        }

        private MototyouType ConvertToMototyouType(int idata)
        {
            switch (idata)
            {
                case 1:
                    return MototyouType.Mototyou;
                case 2:
                    return MototyouType.BumonMototyou;
                case 3:
                    return MototyouType.EdabanMototyou;
                case 4:
                    return MototyouType.TorihikisakiMototyou;
                case 5:
                    return MototyouType.BumonKamokuEdabanMototyou;
                case 6:
                    return MototyouType.BumonKamokuTorihikisakiMototyou;
                default:
                    return MototyouType.Mototyou;
            }
        }

        private int ConvertToDBMOTOTYPE(MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    return 1;
                case MototyouType.EdabanMototyou:
                    return 3;
                case MototyouType.BumonMototyou:
                    return 2;
                case MototyouType.BumonKamokuEdabanMototyou:
                    return 5;
                case MototyouType.TorihikisakiMototyou:
                    return 4;
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return 6;
                default:
                    return 1;
            }
        }
    }
}
