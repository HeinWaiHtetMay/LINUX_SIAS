﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Open21.Data.DataSource;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Persistence.OptionModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class MototyouQueryResultFormOptionCompositeRepository : IMototyouQueryResultFormOptionCompositeRepository
    {
        //// 検索設定用定数定義
        private const string SearchOptionProgramId = "LEDSCANV";
        private const string SearchOptionKeyName1 = "OPTION";
        private const string SearchOptionKeyName2 = "Search_Type";
        //// 列幅用定数定義
        private const string ColumnWidthProgramId = "LEDMAIN";
        private const string ColumnWidthKeyName1 = "COLWIDTH";
        private const int MonthColumnWidthKeyNo = 1;
        private const int DayColumnWidthKeyNo = 2;
        private const int EditColumnWidthStartKeyNo = 101;
        private const int ZeiKubunColumnWidthKeyNo = 201;
        private const int KarikataValueColumnWidthKeyNo = 301;
        private const int KasikataValueColumnWidthKeyNo = 302;
        private const int SasihikiZandakaColumnWidthKeyNo = 303;

        [AutoInjection]
        private IOption1Dao option1Dao = null;
        [AutoInjection]
        private IMototyouLayoutPatternRepository mototyouLayoutPatternRepository = null;

        public MototyouQueryResultFormOptionComposite FindByUserCodeAndLayoutPatternNoAndSyoriki(int userCode, int layoutPatternNo, Syoriki syoriki)
        {
            //// レイアウトパターン番号をOPTION1テーブルでは4桁で扱う
            var layoutPattern = this.mototyouLayoutPatternRepository.FindByPatternNo(layoutPatternNo);
            var optionComposite = new MototyouQueryResultFormOptionComposite(userCode, layoutPattern, syoriki);

            //// 検索設定取得
            var dtoList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2);
            this.SetMototyouSearchOption(optionComposite.SearchOption, dtoList);

            //// 列幅取得
            string layoutPatternNoString = layoutPatternNo.ToString("0000");
            dtoList = this.option1Dao.FindByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, ColumnWidthProgramId, userCode, ColumnWidthKeyName1, layoutPatternNoString);
            this.SetMototyouLayoutColumnWidthOption(optionComposite.LayoutColumnWidthOption, dtoList, layoutPatternNoString);

            return optionComposite;
        }

        public void Store(MototyouQueryResultFormOptionComposite queryResultFormOptionComposite)
        {
            var userCode = queryResultFormOptionComposite.UserCode;
            var searchOption = queryResultFormOptionComposite.SearchOption;
            var widthOption = queryResultFormOptionComposite.LayoutColumnWidthOption;

            var dtoList = new List<Option1Dto>()
            {
                new Option1Dto().SetValues(SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2, (short)MasterSearchableMototyouType.Mototyou, (int)searchOption.MototyouSearchType),
                new Option1Dto().SetValues(SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2, (short)MasterSearchableMototyouType.EdabanMototyou, (int)searchOption.EdabanMototyouSearchType),
                new Option1Dto().SetValues(SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2, (short)MasterSearchableMototyouType.BumonMototyou, (int)searchOption.BumonMototyouSearchType),
                new Option1Dto().SetValues(SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2, (short)MasterSearchableMototyouType.TorihikisakiMototyou, (int)searchOption.TorihikisakiMototyouSearchType),
                new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, MonthColumnWidthKeyNo, widthOption.MonthColumnWidth),
                new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, DayColumnWidthKeyNo, widthOption.DayColumnWidth),
                new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, KarikataValueColumnWidthKeyNo, widthOption.KarikataValueColumnWidth),
                new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, KasikataValueColumnWidthKeyNo, widthOption.KasikataValueColumnWidth),
                new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, SasihikiZandakaColumnWidthKeyNo, widthOption.SasihikiZandakaColumnWidth),
            };

            if (widthOption.ZeiKubunColumnWidth != null)
            {
                //// 税区分
                dtoList.Add(new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, ZeiKubunColumnWidthKeyNo, widthOption.ZeiKubunColumnWidth));
            }

            //// 可変長な編集列の列幅(keyno:101～)
            foreach (var keyAndValue in widthOption.EditColumnWidths)
            {
                dtoList.Add(new Option1Dto().SetKeyValuesAndIData(ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo, (short)keyAndValue.Key, keyAndValue.Value));
            }

            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, SearchOptionProgramId, userCode, SearchOptionKeyName1, SearchOptionKeyName2);
            this.option1Dao.DeleteByPrgidAndUsnoAndKeyNm1AndKeyNm2(DatabaseType.KaisyaDb, ColumnWidthProgramId, userCode, ColumnWidthKeyName1, widthOption.LayoutPatternNo);
            dtoList.ForEach(dto => this.option1Dao.Insert(DatabaseType.KaisyaDb, dto));
        }

        private void SetMototyouSearchOption(MototyouSearchOption searchOption, IList<Option1Dto> dtoList)
        {
            dtoList.ForEach(dto => dto.Keynm2 == SearchOptionKeyName2, dto => searchOption[(MasterSearchableMototyouType)dto.Keyno] = (MototyouSearchType)dto.Idata);
        }

        private void SetMototyouLayoutColumnWidthOption(MototyouLayoutColumnWidthOption layoutColumnWidthOption, IList<Option1Dto> dtoList, string layoutPatternNo)
        {
            foreach (var dto in dtoList.Where(dto => dto.Keynm2 == layoutPatternNo).OrderBy(dto => dto.Keyno))
            {
                if (dto.Keyno >= EditColumnWidthStartKeyNo && dto.Keyno < ZeiKubunColumnWidthKeyNo)
                {
                    layoutColumnWidthOption.EditColumnWidths.Add(dto.Keyno, dto.Idata);
                    continue;
                }

                switch (dto.Keyno)
                {
                    case MonthColumnWidthKeyNo:
                        layoutColumnWidthOption.MonthColumnWidth = dto.Idata;
                        break;
                    case DayColumnWidthKeyNo:
                        layoutColumnWidthOption.DayColumnWidth = dto.Idata;
                        break;
                    case ZeiKubunColumnWidthKeyNo:
                        layoutColumnWidthOption.ZeiKubunColumnWidth = dto.Idata;
                        break;
                    case KarikataValueColumnWidthKeyNo:
                        layoutColumnWidthOption.KarikataValueColumnWidth = dto.Idata;
                        break;
                    case KasikataValueColumnWidthKeyNo:
                        layoutColumnWidthOption.KasikataValueColumnWidth = dto.Idata;
                        break;
                    case SasihikiZandakaColumnWidthKeyNo:
                        layoutColumnWidthOption.SasihikiZandakaColumnWidth = dto.Idata;
                        break;
                }
            }
        }
    }
}
