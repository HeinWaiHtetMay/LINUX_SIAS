﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class KamokuMototyouExportRepository : AbstractMototyouExportRepository
    {
        private readonly IReadOnlyList<string> titleItemColumnHeaders = new string[] { "科目コード", "科目名称" };

        protected override string FixedTitleName => "元帳";

        protected override IReadOnlyList<string> TitleItemColumnHeaders => this.titleItemColumnHeaders;

        protected override string GetOptionTitleName(MototyouOption mototyouOption)
        {
            return mototyouOption.MototyouTitle;
        }

        protected override IReadOnlyList<string> GetTitleItemDatas(Mototyou mototyou, MototyouOption mototyouOption)
        {
            var titleDatas = new string[this.TitleItemColumnHeaders.Count];
            var kamokuMototyouZibunItem = (KamokuMototyouZibunItem)mototyou.ZibunItem;
            titleDatas[0] = kamokuMototyouZibunItem.Kamoku.InputCode;
            titleDatas[1] = kamokuMototyouZibunItem.Kamoku.KamokuLongName;
            return titleDatas;
        }
    }
}
