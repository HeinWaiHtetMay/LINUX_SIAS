﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class BumonKamokuTorihikisakiMototyouExportRepository : AbstractMototyouExportRepository
    {
        private readonly IReadOnlyList<string> titleItemColumnHeaders = new string[] { "部門コード", "部門名称", "科目コード", "科目名称", "取引先コード", "取引先名称" };

        protected override string FixedTitleName => "部門科目取引先元帳";

        protected override IReadOnlyList<string> TitleItemColumnHeaders => this.titleItemColumnHeaders;

        protected override string GetOptionTitleName(MototyouOption mototyouOption)
        {
            return mototyouOption.BumonKamokuTorihikisakiMototyouTitle;
        }

        protected override IReadOnlyList<string> GetTitleItemDatas(Mototyou mototyou, MototyouOption mototyouOption)
        {
            var titleDatas = new string[this.TitleItemColumnHeaders.Count];
            var bumonKamokuTorihikisakiMototyouZibunItem = (BumonKamokuTorihikisakiMototyouZibunItem)mototyou.ZibunItem;
            titleDatas[0] = bumonKamokuTorihikisakiMototyouZibunItem.Bcod;
            titleDatas[1] = bumonKamokuTorihikisakiMototyouZibunItem.Bnam;
            titleDatas[2] = bumonKamokuTorihikisakiMototyouZibunItem.Kamoku.InputCode;
            titleDatas[3] = bumonKamokuTorihikisakiMototyouZibunItem.Kamoku.KamokuLongName;
            titleDatas[4] = bumonKamokuTorihikisakiMototyouZibunItem.Trcd;
            titleDatas[5] = mototyouOption.PrintTorihikisakiName == MototyouPrintTorihikisakiName.ShortName
                ? bumonKamokuTorihikisakiMototyouZibunItem.TorihikisakiShortName : bumonKamokuTorihikisakiMototyouZibunItem.TorihikisakiLongName;
            return titleDatas;
        }
    }
}
