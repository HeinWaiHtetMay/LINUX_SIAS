﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.ComponentModel;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.IO;
    using Icsp.Open21.Domain.FileExportModel;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.KaisyaModel.KaisyaZyouhouSetteiTouroku;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public abstract class AbstractMototyouExportRepository : IMototyouExportRepository
    {
        [AutoInjection]
        private ICsvReadWirter csvReadWriter = null;
        [AutoInjection]
        private IMototyouLayoutPatternRepository mototyouLayoutPatternRepository = null;
        [AutoInjection]
        private IMototyouOutputOptionCompositeRepository outputOptionCompositeRepository = null;
        [AutoInjection]
        private IMototyouRepositoryFactoryCreator repositoryFactoryCreator = null;

        protected abstract string FixedTitleName { get; }

        protected abstract IReadOnlyList<string> TitleItemColumnHeaders { get; }

        /// <summary>
        /// 検索条件に合う全項目の元帳をCSV出力する
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="methodWorker"></param>
        /// <param name="exportOption"></param>
        /// <returns></returns>
        public virtual ExportResult ExportCsv(MototyouQueryParameter queryParameter, IMethodWorker methodWorker, ExportOption exportOption)
        {
            //// レイアウトパターン取得
            var layoutPattern = this.mototyouLayoutPatternRepository.FindByPatternNo(queryParameter.OptionComposite.QueryOption.LayoutPatternNo.Value);
            //// カラム数取得
            var columnCount = this.GetColumnCount(layoutPattern, queryParameter);
            //// CsvConfig作成
            var csvConfig = this.CreateCsvConfig(methodWorker, exportOption, columnCount);
            //// ヘッダー行作成
            var headerRows = this.CreateHeaderRows(queryParameter, exportOption, layoutPattern, columnCount);
            //// データ行作成
            var dataRows = this.CreateRows(queryParameter, layoutPattern);
            //// CSV出力
            return this.CheckAndWrite(headerRows, dataRows, csvConfig, exportOption);
        }

        /// <summary>
        /// 一つの項目の元帳をCSV出力する
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <param name="methodWorker"></param>
        /// <param name="exportOption"></param>
        /// <param name="layoutPattern"></param>
        /// <param name="mototyou"></param>
        /// <returns></returns>
        public virtual ExportResult ExportCsv(MototyouQueryParameter queryParameter, IMethodWorker methodWorker, ExportOption exportOption, MototyouLayoutPattern layoutPattern, Mototyou mototyou)
        {
            //// カラム数取得
            var columnCount = this.GetColumnCount(layoutPattern, queryParameter);
            //// CsvConfig作成
            var csvConfig = this.CreateCsvConfig(methodWorker, exportOption, columnCount);
            //// ヘッダー行作成
            var headerRows = this.CreateHeaderRows(queryParameter, exportOption, layoutPattern, columnCount);
            //// データ行作成
            var dataRows = this.CreateRows(mototyou, queryParameter, layoutPattern);
            //// CSV出力
            return this.CheckAndWrite(headerRows, dataRows, csvConfig, exportOption);
        }

        protected virtual string GetTitleName(MototyouOption mototyouOption)
        {
            return mototyouOption.CsvTitleType == MototyouTitleType.Fixed ? this.FixedTitleName : this.GetOptionTitleName(mototyouOption);
        }

        protected abstract string GetOptionTitleName(MototyouOption mototyouOption);

        protected abstract IReadOnlyList<string> GetTitleItemDatas(Mototyou mototyou, MototyouOption mototyouOption);

        /// <summary>
        /// 出力条件に応じた自分項目コレクションの生成
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        private IMototyouDisplayZibunItemCollection CreateZibunItemCollectionAsQueryCondition(MototyouQueryParameter queryParameter)
        {
            return this.repositoryFactoryCreator.Create(queryParameter.OptionComposite.QueryOption.MototyouType).ZibunItemRepository.FindByMototyouQueryParameterAsOutputCondition(queryParameter);
        }

        private Mototyou CreateMototyou(MototyouQueryParameter queryParameter, IMototyouZibunItem zibunItem, MototyouLayoutPattern layoutPattern)
        {
            return this.repositoryFactoryCreator.Create(queryParameter.OptionComposite.QueryOption.MototyouType).Repository.FindByQueryParameterAndItem(queryParameter, zibunItem, layoutPattern);
        }

        private CsvConfig CreateCsvConfig(IMethodWorker methodWorker, ExportOption exportOption, int columnCount)
        {
            var csvConfig = new CsvConfig(exportOption.CreateFileResource());
            //// indexの配列作成
            var indices = Enumerable.Range(0, columnCount).ToArray();
            //// ヘッダー行は全て囲み文字使用
            csvConfig.AddHeaderRowQuoteFieldIndexCollection(indices);
            //// 通常行は借方金額、貸方金額、差引残高（後ろ3つ）以外囲み文字使用
            csvConfig.AddRowQuoteFieldIndexCollection(indices.Take(columnCount - 3));
            csvConfig.MethodWorker = methodWorker;
            return csvConfig;
        }

        private IReadOnlyList<IReadOnlyList<string>> CreateHeaderRows(MototyouQueryParameter queryParameter, ExportOption exportOption, MototyouLayoutPattern layoutPattern, int columnCount)
        {
            var headerRows = new List<IReadOnlyList<string>>();
            //// 1行目 会社名、元帳名、コメント、セキュリティ注釈
            var headerRow1 = new string[columnCount];
            headerRow1[0] = this.GetKaisyaName(exportOption, queryParameter.Syoriki);
            headerRow1[1] = this.GetTitleName(queryParameter.OptionComposite.Option);
            headerRow1[2] = exportOption.IsOutputComment ? exportOption.Comment : string.Empty;
            headerRow1[3] = string.Concat(queryParameter.GetAnnotationTextList());
            headerRows.Add(headerRow1);
            //// 2行目 年表示
            var headerRow2 = new string[columnCount];
            headerRow2[0] = queryParameter.KaisyaSyoriKikan.StartSyorituki.StartDate.GetFormattedYear("年", false, false, true);
            headerRows.Add(headerRow2);
            //// 3行目 列名
            headerRows.Add(this.GetColumnNames(layoutPattern, queryParameter.Syoriki));
            return headerRows;
        }

        private int GetColumnCount(MototyouLayoutPattern layoutPattern, MototyouQueryParameter queryParameter)
        {
            //// タイトル項目コード＆名称+
            //// 月、日+
            //// レイアウト項目（使用できるもののみ）+
            //// （自分税区分、相手税区分）、借方金額、貸方金額、差引残高
            return this.TitleItemColumnHeaders.Count + layoutPattern.Items.Count(item => layoutPattern.IsAvailableItem(item, queryParameter.Syoriki)) + (layoutPattern.UseSyouhizeiKubun ? 7 : 5);
        }

        private string GetKaisyaName(ExportOption exportOption, Syoriki syoriki)
        {
            return string.Format("{0}名 {1}", exportOption.OrganizationTypeName, syoriki.KaisyaName);
        }

        private IReadOnlyList<string> GetColumnNames(MototyouLayoutPattern layoutPattern, Syoriki syoriki)
        {
            var columnNames = new List<string>();
            columnNames.AddRange(this.TitleItemColumnHeaders);
            columnNames.Add("月");
            columnNames.Add("日");
            columnNames.AddRange(layoutPattern.Items.Where(item => layoutPattern.IsAvailableItem(item, syoriki)).Select(item => item.GetName(syoriki)));
            if (layoutPattern.UseSyouhizeiKubun)
            {
                columnNames.Add("自分税区分");
                columnNames.Add("相手税区分");
            }

            columnNames.Add("借方金額");
            columnNames.Add("貸方金額");
            columnNames.Add("差引残高");

            return columnNames;
        }

        private IEnumerable<IReadOnlyList<string>> CreateRows(MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern)
        {
            var outputOptionComposite = this.outputOptionCompositeRepository.FindByKesn(queryParameter.Kesn);
            var dataRows = new List<IReadOnlyList<string>>();
            //// 出力する自分項目のコレクション取得→項目ごとに元帳データ取得をして出力データを作成してリストに追加
            this.CreateZibunItemCollectionAsQueryCondition(queryParameter).ForEachIfNotNull(item =>
                dataRows.AddRange(
                    this.CreateRowsItemUnit(
                        this.CreateMototyou(queryParameter, item, layoutPattern),
                        queryParameter,
                        layoutPattern)));

            return dataRows;
        }

        private IEnumerable<IReadOnlyList<string>> CreateRows(Mototyou mototyou, MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern)
        {
            var outputOptionComposite = this.outputOptionCompositeRepository.FindByKesn(queryParameter.Kesn);
            //// エクスポート用に指定したレイアウトパターンが問い合わせ時と同じなら問い合わせ時の元帳を流用、そうでなければ元帳再取得
            var exportMototyou = queryParameter.OptionComposite.QueryOption.LayoutPatternNo == layoutPattern.PatternNo
                ? mototyou : this.CreateMototyou(queryParameter, mototyou.ZibunItem, layoutPattern);
            return this.CreateRowsItemUnit(mototyou, queryParameter, layoutPattern);
        }

        /// <summary>
        /// 項目単位での行作成
        /// </summary>
        /// <param name="mototyou"></param>
        /// <param name="queryParameter"></param>
        /// <param name="layoutPattern"></param>
        /// <returns></returns>
        private IEnumerable<IReadOnlyList<string>> CreateRowsItemUnit(Mototyou mototyou, MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern)
        {
            var titleDatas = this.GetTitleItemDatas(mototyou, queryParameter.OptionComposite.Option);
            //// エクスポートでは空行を出力しない
            //// 複数月でも月度計を出力しない設定の時は月度計を出力しない（月別集計の場合を除く）
            return mototyou.MototyouRows
                .Where(row => row != null && (!(row is MototyouMonthlyRow) || mototyou.ZibunItem.SyuukeiKeisiki == MototyouSyuukeiKeisiki.Monthly || queryParameter.OptionComposite.Option.MonthlyTotal == MototyouMonthlyTotal.Exists))
                .Select(row => this.CreateRow(row, titleDatas, queryParameter, layoutPattern));
        }

        private IReadOnlyList<string> CreateRow(IMototyouRow mototyouRow, IReadOnlyList<string> titleDatas, MototyouQueryParameter queryParameter, MototyouLayoutPattern layoutPattern)
        {
            var rowDatas = new List<string>();
            rowDatas.AddRange(titleDatas);
            rowDatas.Add(mototyouRow.GetMonthString(queryParameter.OptionComposite.Option.OutputSeirituki));
            rowDatas.Add(mototyouRow.Date?.Day.ToString());
            rowDatas.AddRange(layoutPattern.Items.Where(item => layoutPattern.IsAvailableItem(item, queryParameter.Syoriki)).Select(item => this.GetCellItemString(mototyouRow, item)));
            if (layoutPattern.UseSyouhizeiKubun)
            {
                if (mototyouRow is MototyouSiwakeRow siwakeRow)
                {
                    rowDatas.Add(siwakeRow.ZibunZeiKubun.GetMototyouCellText());
                    rowDatas.Add(siwakeRow.AiteZeiKubun.GetMototyouCellText());
                }
                else
                {
                    rowDatas.Add(string.Empty);
                    rowDatas.Add(string.Empty);
                }
            }

            rowDatas.Add(mototyouRow.KarikataValue?.ToString());
            rowDatas.Add(mototyouRow.KasikataValue?.ToString());
            rowDatas.Add(mototyouRow.SasihikiZandaka?.ToString());
            return rowDatas;
        }

        private string GetCellItemString(IMototyouRow mototyouRow, MototyouLayoutItem layoutItem)
        {
            //// エクスポートの時は伝票番号と受付番号の前スペース削除
            return layoutItem.ItemType == MototyouLayoutItemType.DenpyouNo || layoutItem.ItemType == MototyouLayoutItemType.UketukeNo
                ? mototyouRow.GetMototyouCellItemString(layoutItem)?.TrimStart(' ')
                : mototyouRow.GetMototyouCellItemString(layoutItem);
        }

        private ExportResult CheckAndWrite(IEnumerable<IEnumerable<string>> headerRows, IEnumerable<IEnumerable<string>> rows, CsvConfig csvConfig, ExportOption exportOption)
        {
            if (!rows.Any())
            {
                return ExportResult.CreateNoDataResult(exportOption);
            }

            //// CSV出力
            try
            {
                this.csvReadWriter.Write(csvConfig, rows, headerRows, null);
                return ExportResult.CreateSucceededResult(exportOption);
            }
            catch (Exception ex)
            {
                return ExportResult.CreateErrorResult(exportOption, ex);
            }
        }

        /* 一連のエクスポート処理でフィールド変数を保持したくなったら
        private class ExportDataCreater
        {
            private AbstractMototyouExportRepository parent;
            private MototyouQueryParameter queryParameter;
            private MototyouOutputOptionComposite outputOptionComposite;
            private MototyouLayoutPattern layoutPattern;

            private MototyouZeiKubunComparer zeiKubunComparer;

            public ExportDataCreater(AbstractMototyouExportRepository parent, MototyouQueryParameter queryParameter, MototyouOutputOptionComposite outputOptionComposite, MototyouLayoutPattern layoutPattern)
            {
                this.parent = parent;
                this.queryParameter = queryParameter;
                this.outputOptionComposite = outputOptionComposite;
                this.layoutPattern = layoutPattern;

                this.zeiKubunComparer = this.parent.CreateMototyouZeiKubunComparer(queryParameter, outputOptionComposite.SiwakeZeirituOutputOption);
            }

            public IReadOnlyList<IReadOnlyList<string>> Rows { get; private set; }

            public bool IsNoData => !this.Rows.Any();
        }
        */
    }
}
