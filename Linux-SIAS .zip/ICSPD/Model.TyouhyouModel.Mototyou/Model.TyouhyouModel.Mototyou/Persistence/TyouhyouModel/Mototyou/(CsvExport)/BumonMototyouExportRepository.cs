﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Icsp.Framework.Attributes;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class BumonMototyouExportRepository : AbstractMototyouExportRepository
    {
        private readonly IReadOnlyList<string> titleItemColumnHeaders = new string[] { "部門コード", "部門名称", "科目コード", "科目名称" };

        protected override string FixedTitleName => "部門元帳";

        protected override IReadOnlyList<string> TitleItemColumnHeaders => this.titleItemColumnHeaders;

        protected override string GetOptionTitleName(MototyouOption mototyouOption)
        {
            return mototyouOption.BumonMototyouTitle;
        }

        protected override IReadOnlyList<string> GetTitleItemDatas(Mototyou mototyou, MototyouOption mototyouOption)
        {
            var titleDatas = new string[this.TitleItemColumnHeaders.Count];
            var bumonMototyouZibunItem = (BumonMototyouZibunItem)mototyou.ZibunItem;
            titleDatas[0] = bumonMototyouZibunItem.Bcod;
            titleDatas[1] = bumonMototyouZibunItem.Bnam;
            titleDatas[2] = bumonMototyouZibunItem.Kamoku.InputCode;
            titleDatas[3] = bumonMototyouZibunItem.Kamoku.KamokuLongName;
            return titleDatas;
        }
    }
}
