﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class EdabanMototyouZibunItemRepository : AbstractMototyouZibunItemRepository
    {
        protected override CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
        {
            return new KamokuEdabanCollectionCreater(queryParameter, kamokuFactory, container);
        }

        protected class KamokuEdabanCollectionCreater : CollectionCreater
        {
            [AutoInjection]
            private IEdabanRepository edabanRepository = null;
            [AutoInjection]
            private IKamokuEdabanZandakaRepository kamokuEdabanZandakaRepository = null;

            public KamokuEdabanCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
                : base(queryParameter, kamokuFactory, container)
            {
            }

            protected override void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange)
            {
                queryConditionRange.StartKamoku = null;
                queryConditionRange.EndKamoku = null;
                queryConditionRange.StartPkicd = null;
                queryConditionRange.EndPkicd = null;
                queryConditionRange.StartEdabanCode = null;
                queryConditionRange.EndEdabanCode = null;
            }

            protected override void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                var edabanItemList = new List<EdabanMototyouZibunItem>();
                var kicdRange = this.KamokuFactory.GetKicdRange(queryConditionRange);
                var kamokuEdabanZandakaList = this.kamokuEdabanZandakaRepository.FindZandakaWithNameByPrimaryKeyAndEdabanKanaRangesOrderByKamokuOutputOrderAndEcod(
                    this.QueryParameter.Kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    queryConditionRange.StartEdabanCode,
                    queryConditionRange.EndEdabanCode,
                    null,
                    null,
                    kamokuOutputOrder,
                    this.QueryParameter.SecurityContext,
                    SecurityKubun.Output);

                if (itemCollection.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki))
                {
                    kamokuEdabanZandakaList.ForEachIfNotNull(entity =>
                    {
                        var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                        edabanItemList.Add(new EdabanMototyouZibunItem(itemCollection, kamoku, entity, entity.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), (MototyouSyuukeiKeisiki)this.edabanRepository.FindByKesnAndKicdAndEcod(this.QueryParameter.Kesn, entity.Kicd, entity.Ecod).SyuukeiKubun, null, null));
                    });
                }
                else
                {
                    if (this.QueryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku)
                    {
                        kamokuEdabanZandakaList.ForEachIfNotNull(entity =>
                        {
                            var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                            edabanItemList.Add(new EdabanMototyouZibunItem(itemCollection, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null));
                        });
                    }
                    else
                    {
                        var edabanGroups = kamokuEdabanZandakaList.GroupBy(entity => entity.Ecod);
                        foreach (var group in edabanGroups)
                        {
                            var edaban = new Edaban(this.QueryParameter.Kesn, string.Empty, group.Key) { Enam = group.Key };
                            var kamokus = this.KamokuFactory.CreateMototyouKamokuList(group, queryConditionRange);
                            kamokus.ForEachIfNotNull(kamoku => edabanItemList.Add(new EdabanMototyouZibunItem(itemCollection, kamoku, edaban, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null)));
                        }
                    }
                }

                itemCollection.AddRangeIfNotNull(this.SortItems(edabanItemList, kamokuOutputOrder, outputOrders.EdabanMototyouOutputOrder));
            }

            protected override void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                if ((kobetuItem.Kamoku == null && string.IsNullOrEmpty(kobetuItem.Pkicd)) || string.IsNullOrEmpty(kobetuItem.EdabanCode))
                {
                    return;
                }

                var kamoku = this.KamokuFactory.GetMototyouKamoku(kobetuItem);
                //// 枝番取得 明細科目以外の時は名称にも枝番コードを入れる
                var edaban = this.edabanRepository.FindByKesnAndKicdAndEcod(this.QueryParameter.Kesn, kobetuItem.Kamoku?.Kicd, kobetuItem.EdabanCode) ?? new Edaban(this.QueryParameter.Kesn, string.Empty, kobetuItem.EdabanCode) { Enam = kobetuItem.EdabanCode };
                var syuukeiKeisiki = this.GetUseKobetuSyuukeiKeisiki(
                    queryConditionType,
                    syuukeiKeisikiApplyingWay,
                    kobetuItem,
                    edaban.SyuukeiKubun);

                itemCollection.Add(new EdabanMototyouZibunItem(itemCollection, kamoku, edaban, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), syuukeiKeisiki, kobetuItem.StartPageNo, kobetuItem.EndPageNo));
            }

            private IEnumerable<EdabanMototyouZibunItem> SortItems(IEnumerable<EdabanMototyouZibunItem> items, KamokuOutputOrder kamokuOutputOrder, EdabanMototyouOutputOrder mototyouOutputOrder)
            {
                switch (mototyouOutputOrder)
                {
                    case EdabanMototyouOutputOrder.KamokuEdaban:
                        return this.SortKamoku(items, kamokuOutputOrder).ThenBy(item => item.Ecod);
                    case EdabanMototyouOutputOrder.EdabanKamoku:
                        return this.SortKamoku(items.OrderBy(item => item.Ecod), kamokuOutputOrder);
                    default:
                        return items;
                }
            }
        }
    }
}
