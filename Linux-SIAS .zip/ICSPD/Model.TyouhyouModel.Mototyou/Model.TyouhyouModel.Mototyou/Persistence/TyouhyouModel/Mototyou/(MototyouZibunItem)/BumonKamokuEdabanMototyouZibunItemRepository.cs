﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class BumonKamokuEdabanMototyouZibunItemRepository : AbstractMototyouZibunItemRepository
    {
        protected override CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
        {
            return new BumonKamokuEdabanCollectionCreater(queryParameter, kamokuFactory, container);
        }

        protected class BumonKamokuEdabanCollectionCreater : CollectionCreater
        {
            [AutoInjection]
            private IBumonKamokuEdabanZandakaRepository bumonKamokuEdabanZandakaRepository = null;

            public BumonKamokuEdabanCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
                : base(queryParameter, kamokuFactory, container)
            {
            }

            protected override void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange)
            {
                queryConditionRange.StartKamoku = null;
                queryConditionRange.EndKamoku = null;
                queryConditionRange.StartPkicd = null;
                queryConditionRange.EndPkicd = null;
                queryConditionRange.StartBumonCode = null;
                queryConditionRange.EndBumonCode = null;
                queryConditionRange.StartEdabanCode = null;
                queryConditionRange.EndEdabanCode = null;
            }

            protected override void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                var bumonKamokuEdabanItemList = new List<BumonKamokuEdabanMototyouZibunItem>();
                var kicdRange = this.KamokuFactory.GetKicdRange(queryConditionRange);
                var bumonKamokuEdabanList = this.FindBumonKamokuEdabanList(queryConditionRange.StartBumonCode, queryConditionRange.EndBumonCode, kicdRange.Start, kicdRange.End, queryConditionRange.StartEdabanCode, queryConditionRange.EndEdabanCode, kamokuOutputOrder);

                if (itemCollection.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki))
                {
                    bumonKamokuEdabanList.ForEachIfNotNull(entity =>
                    {
                        var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                        bumonKamokuEdabanItemList.Add(new BumonKamokuEdabanMototyouZibunItem(itemCollection, entity, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), (MototyouSyuukeiKeisiki)entity.MasterSyuukeiKubun, null, null));
                    });
                }
                else
                {
                    if (this.QueryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku)
                    {
                        bumonKamokuEdabanList.ForEachIfNotNull(entity =>
                        {
                            var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                            bumonKamokuEdabanItemList.Add(new BumonKamokuEdabanMototyouZibunItem(itemCollection, entity, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null));
                        });
                    }
                    else
                    {
                        var bumonEdabanGroups = bumonKamokuEdabanList.GroupBy(entity => new { ((IBumonCodeAndName)entity).Bcod, ((IKamokuEdabanAndName)entity).Ecod });
                        foreach (var group in bumonEdabanGroups)
                        {
                            var bumon = group.First();
                            var edaban = new Edaban(this.QueryParameter.Kesn, string.Empty, group.Key.Ecod) { Enam = group.Key.Ecod };
                            var kamokus = this.KamokuFactory.CreateMototyouKamokuList(group, queryConditionRange);
                            kamokus.ForEachIfNotNull(kamoku => bumonKamokuEdabanItemList.Add(new BumonKamokuEdabanMototyouZibunItem(itemCollection, bumon, kamoku, edaban, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null)));
                        }
                    }
                }

                itemCollection.AddRangeIfNotNull(this.SortItems(bumonKamokuEdabanItemList, kamokuOutputOrder, outputOrders.BumonKamokuEdabanMototyouOutputOrder));
            }

            protected override void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                if (string.IsNullOrEmpty(kobetuItem.BumonCode) || (kobetuItem.Kamoku == null && string.IsNullOrEmpty(kobetuItem.Pkicd)) || string.IsNullOrEmpty(kobetuItem.EdabanCode))
                {
                    return;
                }

                var entity = this.FindBumonKamokuEdaban(kobetuItem.BumonCode, kobetuItem.Kamoku?.Kicd, kobetuItem.EdabanCode);

                var syuukeiKeisiki = this.GetUseKobetuSyuukeiKeisiki(
                    queryConditionType,
                    syuukeiKeisikiApplyingWay,
                    kobetuItem,
                    entity.MasterSyuukeiKubun);

                var kamoku = this.KamokuFactory.GetMototyouKamoku(kobetuItem);
                itemCollection.Add(new BumonKamokuEdabanMototyouZibunItem(itemCollection, entity, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), syuukeiKeisiki, kobetuItem.StartPageNo, kobetuItem.EndPageNo));
            }

            private IEnumerable<BumonKamokuEdabanMototyouZibunItem> SortItems(IEnumerable<BumonKamokuEdabanMototyouZibunItem> items, KamokuOutputOrder kamokuOutputOrder, BumonKamokuEdabanMototyouOutputOrder mototyouOutputOrder)
            {
                switch (mototyouOutputOrder)
                {
                    case BumonKamokuEdabanMototyouOutputOrder.BumonKamokuEdaban:
                        return this.SortKamoku(items.OrderBy(item => item.Bcod), kamokuOutputOrder).ThenBy(item => item.Ecod);
                    case BumonKamokuEdabanMototyouOutputOrder.KamokuEdabanBumon:
                        return this.SortKamoku(items, kamokuOutputOrder).ThenBy(item => item.Ecod).ThenBy(item => item.Bcod);
                    default:
                        return items;
                }
            }

            private IList<IBumonKamokuEdabanWithName> FindBumonKamokuEdabanList(string startBcod, string endBcod, string startKicd, string endKicd, string startEcod, string endEcod, KamokuOutputOrder kamokuOutputOrder)
            {
                return this.bumonKamokuEdabanZandakaRepository.FindCodeWithNameByPrimaryKeyRangesWithSecurity(
                    this.QueryParameter.Kesn,
                    startBcod,
                    endBcod,
                    startKicd,
                    endKicd,
                    startEcod,
                    endEcod,
                    kamokuOutputOrder,
                    this.QueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.SyuukeiBumon,
                    this.QueryParameter.SecurityContext,
                    SecurityKubun.Output);
            }

            private IBumonKamokuEdabanWithName FindBumonKamokuEdaban(string bcod, string kicd, string ecod)
            {
                var kicdRange = this.KamokuFactory.GetKicdRange(kicd);
                return this.FindBumonKamokuEdabanList(bcod, bcod, kicdRange.Start, kicdRange.End, ecod, ecod, KamokuOutputOrder.ByInnerCode).FirstOrDefault();
            }
        }
    }
}
