﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class TorihikisakiMototyouZibunItemRepository : AbstractMototyouZibunItemRepository
    {
        protected override CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
        {
            return new TorihikisakiKamokuCollectionCreater(queryParameter, kamokuFactory, container);
        }

        protected class TorihikisakiKamokuCollectionCreater : CollectionCreater
        {
            [AutoInjection]
            private ITorihikisakiKamokuZandakaRepository torihikisakiKamokuZandakaRepository = null;

            public TorihikisakiKamokuCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
                : base(queryParameter, kamokuFactory, container)
            {
            }

            protected override void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange)
            {
                queryConditionRange.StartKamoku = null;
                queryConditionRange.EndKamoku = null;
                queryConditionRange.StartPkicd = null;
                queryConditionRange.EndPkicd = null;
                queryConditionRange.StartTorihikisakiCode = null;
                queryConditionRange.EndTorihikisakiCode = null;
            }

            protected override void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                var torihikisakiItemList = new List<TorihikisakiMototyouZibunItem>();
                var kicdRange = this.KamokuFactory.GetKicdRange(queryConditionRange);
                var torihikisakiKamokuZandakaList = this.torihikisakiKamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndTorihikisakiKanaRangesOrderByTrcdAndKamokuOutputOrder(
                    this.QueryParameter.Kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    queryConditionRange.StartTorihikisakiCode,
                    queryConditionRange.EndTorihikisakiCode,
                    null,
                    null,
                    kamokuOutputOrder,
                    this.QueryParameter.SecurityContext,
                    SecurityKubun.Output);

                if (itemCollection.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki))
                {
                    torihikisakiKamokuZandakaList.ForEachIfNotNull(entity =>
                    {
                        var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                        torihikisakiItemList.Add(new TorihikisakiMototyouZibunItem(itemCollection, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), (MototyouSyuukeiKeisiki)entity.MasterSyuukeiKubun, null, null));
                    });
                }
                else
                {
                    var torihikisakiGroups = torihikisakiKamokuZandakaList.GroupBy(entity => entity.Trcd);
                    foreach (var group in torihikisakiGroups)
                    {
                        var torihikisaki = group.First();
                        var kamokus = this.KamokuFactory.CreateMototyouKamokuList(group, queryConditionRange);
                        kamokus.ForEachIfNotNull(kamoku => torihikisakiItemList.Add(new TorihikisakiMototyouZibunItem(itemCollection, kamoku, torihikisaki, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null)));
                    }
                }

                itemCollection.AddRangeIfNotNull(this.SortItems(torihikisakiItemList, kamokuOutputOrder, outputOrders.TorihikisakiMototyouOutputOrder));
            }

            protected override void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                if ((kobetuItem.Kamoku == null && string.IsNullOrEmpty(kobetuItem.Pkicd)) || string.IsNullOrEmpty(kobetuItem.TorihikisakiCode))
                {
                    return;
                }

                var kicdRange = this.KamokuFactory.GetKicdRange(kobetuItem.Kamoku?.Kicd);
                var entity = this.torihikisakiKamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndTorihikisakiKanaRangesOrderByTrcdAndKamokuOutputOrder(
                    this.QueryParameter.Kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    kobetuItem.TorihikisakiCode,
                    kobetuItem.TorihikisakiCode,
                    null,
                    null,
                    KamokuOutputOrder.ByInnerCode,
                    null,
                    SecurityKubun.Output).FirstOrDefault();

                var syuukeiKeisiki = this.GetUseKobetuSyuukeiKeisiki(
                    queryConditionType,
                    syuukeiKeisikiApplyingWay,
                    kobetuItem,
                    entity.MasterSyuukeiKubun);

                var kamoku = this.KamokuFactory.GetMototyouKamoku(kobetuItem);
                itemCollection.Add(new TorihikisakiMototyouZibunItem(itemCollection, kamoku, entity, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), syuukeiKeisiki, kobetuItem.StartPageNo, kobetuItem.EndPageNo));
            }

            private IEnumerable<TorihikisakiMototyouZibunItem> SortItems(IEnumerable<TorihikisakiMototyouZibunItem> items, KamokuOutputOrder kamokuOutputOrder, TorihikisakiMototyouOutputOrder mototyouOutputOrder)
            {
                switch (mototyouOutputOrder)
                {
                    case TorihikisakiMototyouOutputOrder.KamokuTorihikisaki:
                        return this.SortKamoku(items, kamokuOutputOrder).ThenBy(item => item.Trcd);
                    case TorihikisakiMototyouOutputOrder.TorihikisakiKamoku:
                        return this.SortKamoku(items.OrderBy(item => item.Trcd), kamokuOutputOrder);
                    default:
                        return items;
                }
            }
        }
    }
}
