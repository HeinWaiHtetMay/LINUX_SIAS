﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyakaiHukusiHouzinModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.TyouhyouModel.ZandakaSyuukeihyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public abstract class AbstractMototyouZibunItemRepository : IMototyouZibunItemRepository
    {
        [AutoInjection]
        private InjectionContainer container = null;
        [AutoInjection]
        private IMototyouRepositoryFactoryCreator repositoryFactoryCreator = null;

        /// <summary>
        /// 自分項目が出力可能かどうかの判定処理用デリゲート
        /// </summary>
        /// <param name="zibunItem"></param>
        /// <param name="zandakaSyuukeihyouForOutputtableJudgment"></param>
        /// <returns></returns>
        private delegate bool IsOutputtableZibunItemFunc(IMototyouZibunItem zibunItem, ZandakaSyuukeihyou zandakaSyuukeihyouForOutputtableJudgment);

        /// <summary>
        /// 問い合わせ条件から元帳の自分項目のコレクションを作成して返します
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        public IMototyouDisplayZibunItemCollection FindByMototyouQueryParameter(MototyouQueryParameter queryParameter)
        {
            var creater = this.CreateCollectionCreater(queryParameter, this.CreateMototyouKamokuFactory(queryParameter), this.container);
            return creater.CreateZibunItemCollection(queryParameter);
        }

        /// <summary>
        /// 問合せ条件から出力条件を考慮して、元帳の自分項目のコレクションを作成して返します
        /// </summary>
        /// <param name="queryParameter"></param>
        /// <returns></returns>
        public IMototyouDisplayZibunItemCollection FindByMototyouQueryParameterAsOutputCondition(MototyouQueryParameter queryParameter)
        {
            var mototyouRepositoryFactory = this.repositoryFactoryCreator.Create(queryParameter.OptionComposite.QueryOption.MototyouType);
            var zibunItems = this.FindByMototyouQueryParameter(queryParameter);

            IsOutputtableZibunItemFunc isOutputtableZibunItemFunc = null;
            switch (queryParameter.OptionComposite.QueryOption.OutputCondition)
            {
                case MototyouOutputCondition.MaezanOrTougetuHassei:
                    isOutputtableZibunItemFunc = (item, zandakaSyuukeihyouForOutputtableJudgment)
                         => mototyouRepositoryFactory.Repository.GetExistsMaezanOrTougetuHasseiByQueryParameterAndItem(queryParameter, item, zandakaSyuukeihyouForOutputtableJudgment);
                    break;
                case MototyouOutputCondition.TougetuHassei:
                    isOutputtableZibunItemFunc = (item, zandakaSyuukeihyouForOutputtableJudgment)
                         => mototyouRepositoryFactory.Repository.GetExistsTougetuHasseiByQueryParameterAndItem(queryParameter, item, zandakaSyuukeihyouForOutputtableJudgment);
                    break;
                default:
                    //// 「出力条件：指定なし」の場合は自分項目コレクションをそのまま
                    return zibunItems;
            }

            var dictionaryForOutputtableJudgment = new Dictionary<string, ZandakaSyuukeihyou>();
            var removeList = new List<IMototyouZibunItem>();
            foreach (var item in zibunItems)
            {
                var itemKey = this.GetKeyForZandakaSyuukeihyouDictionary(item, queryParameter);
                if (((queryParameter.OptionComposite.QueryOption.OutputCondition == MototyouOutputCondition.MaezanOrTougetuHassei
                      && queryParameter.OptionComposite.Option.ZenzanJudgmentType == MototyouZenzanJudgmentType.KurikosiZandaka)
                     || queryParameter.OptionComposite.Option.TougetuHasseiJudgmentType == MototyouTougetuHasseiJudgmentType.TaisyakuHassei)
                    && !dictionaryForOutputtableJudgment.ContainsKey(itemKey))
                {
                    //// チェック用のZandakaSyuukeihyouを追加
                    dictionaryForOutputtableJudgment.Add(itemKey, mototyouRepositoryFactory.Repository.GetZandakaSyuukeihyou(queryParameter, item));
                }

                if (!isOutputtableZibunItemFunc(item, dictionaryForOutputtableJudgment.Count == 0 ? new ZandakaSyuukeihyou() : dictionaryForOutputtableJudgment[itemKey]))
                {
                    //// 出力条件を満たさない自分項目は除外リストに追加
                    removeList.Add(item);
                }
            }

            if (removeList.Count > 0)
            {
                //// 除外リスト項目は自分項目コレクションから削除
                removeList.ForEach(removeItem => zibunItems.Remove(removeItem));
            }

            return zibunItems;
        }

        protected abstract CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container);

        private string GetKeyForZandakaSyuukeihyouDictionary(IMototyouZibunItem item, MototyouQueryParameter queryParameter)
        {
            switch (queryParameter.OptionComposite.QueryOption.MototyouType)
            {
                case MototyouType.EdabanMototyou:
                    return ((EdabanMototyouZibunItem)item).Ecod;
                case MototyouType.BumonMototyou:
                    return ((BumonMototyouZibunItem)item).Bcod;
                case MototyouType.TorihikisakiMototyou:
                    return ((TorihikisakiMototyouZibunItem)item).Trcd;
                case MototyouType.BumonKamokuEdabanMototyou:
                    var currentBumonKamokuEdabanItem = (BumonKamokuEdabanMototyouZibunItem)item;
                    return string.Format("{0}{1}", currentBumonKamokuEdabanItem.Bcod, currentBumonKamokuEdabanItem.Ecod);
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    var currentBumonKamokuTorihikisakiItem = (BumonKamokuTorihikisakiMototyouZibunItem)item;
                    return string.Format("{0}{1}", currentBumonKamokuTorihikisakiItem.Bcod, currentBumonKamokuTorihikisakiItem.Trcd);
                case MototyouType.Mototyou:
                default:
                    return string.Empty;
            }
        }

        private MototyouKamokuFactory CreateMototyouKamokuFactory(MototyouQueryParameter queryParameter)
        {
            switch (queryParameter.OptionComposite.QueryOption.KamokuType)
            {
                case MototyouKamokuType.MeisaiKamoku:
                    return new MototyouMeisaiKamokuFactory(queryParameter, this.container);
                case MototyouKamokuType.SyouKamoku:
                case MototyouKamokuType.SyuukeiSyouKamoku:
                    return new MototyouSyuukeiKamokuFactory(queryParameter, this.container);
                case MototyouKamokuType.KisokugaiSyuukeiKamoku:
                    return new MototyouKisokugaiSyuukeiKamokuFactory(queryParameter, this.container);
                default:
                    return null;
            }
        }

        protected abstract class CollectionCreater
        {
            [AutoInjection]
            private IMototyouQueryConditionPatternRepository queryConditionPatternRepository = null;
            [AutoInjection]
            private IMototyouZeikubunFactoryCreator mototyouZeikubunFactoryCreator = null;

            public CollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
            {
                container.InjectDependeciesToAutoInjectionMembers(this);
                this.QueryParameter = queryParameter;
                this.ZeiKubunFactory = this.mototyouZeikubunFactoryCreator.Create(queryParameter);
                this.KamokuFactory = kamokuFactory;
            }

            protected MototyouQueryParameter QueryParameter { get; }

            protected IMototyouZeiKubunFactory ZeiKubunFactory { get; }

            protected MototyouKamokuFactory KamokuFactory { get; }

            public IMototyouDisplayZibunItemCollection CreateZibunItemCollection(MototyouQueryParameter queryParameter)
            {
                switch (queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType)
                {
                    case MototyouMasterRangeQueryConditionType.NotUse:
                        return this.CreateAllItemCollection(queryParameter);
                    case MototyouMasterRangeQueryConditionType.Range:
                        return queryParameter.QueryCondition.QueryConditionPatternType.UsePattern()
                            ? this.CreatePatternRangeItemCollection(queryParameter)
                            : this.CreateRangeItemCollection(queryParameter);
                    default:
                        return queryParameter.QueryCondition.QueryConditionPatternType.UsePattern()
                            ? this.CreatePatternKobetuItemCollection(queryParameter)
                            : this.CreateKobetuItemCollection(queryParameter);
                }
            }

            /// <summary>
            /// パターン範囲指定による項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <returns></returns>
            protected virtual IMototyouDisplayZibunItemCollection CreatePatternRangeItemCollection(MototyouQueryParameter queryParameter)
            {
                return queryParameter.QueryCondition.QueryConditionPatternType == MototyouQueryConditionPatternType.Range
                    ? new MototyouDisplayZibunItemCollection(this.FindMototyouPatternRangeList(queryParameter).Select(pattern => this.CreateRangePatternUnitItemCollection(queryParameter, pattern)))
                    : new MototyouDisplayZibunItemCollection(this.FindMototyouPatternRangeList(queryParameter).Select(pattern => this.CreateKobetuPatternUnitItemCollection(queryParameter.Kesn, pattern)));
            }

            /// <summary>
            /// パターン個別指定による項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <returns></returns>
            protected virtual IMototyouDisplayZibunItemCollection CreatePatternKobetuItemCollection(MototyouQueryParameter queryParameter)
            {
                return queryParameter.QueryCondition.QueryConditionPatternType == MototyouQueryConditionPatternType.Range
                    ? new MototyouDisplayZibunItemCollection(queryParameter.QueryCondition.KobetuSiteiItemList.Where(kobetuItem => kobetuItem.MototyouQueryConditionPattern != null).Select(kobetuItem => this.CreateRangePatternUnitItemCollection(queryParameter, kobetuItem.MototyouQueryConditionPattern)))
                    : new MototyouDisplayZibunItemCollection(queryParameter.QueryCondition.KobetuSiteiItemList.Where(kobetuItem => kobetuItem.MototyouQueryConditionPattern != null).Select(kobetuItem => this.CreateKobetuPatternUnitItemCollection(queryParameter.Kesn, kobetuItem.MototyouQueryConditionPattern)));
            }

            /// <summary>
            /// 項目指定なしでの項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <returns></returns>
            protected virtual IMototyouDisplayZibunItemCollection CreateAllItemCollection(MototyouQueryParameter queryParameter)
            {
                //// null～nullの範囲指定という形で全件出力する
                this.ClearQueryConditionRange(queryParameter.QueryCondition.QueryConditionRange);

                return this.CreateRangeItemCollection(queryParameter);
            }

            /// <summary>
            /// 範囲指定条件をクリアする
            /// </summary>
            /// <param name="queryConditionRange"></param>
            protected abstract void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange);

            /// <summary>
            /// 項目範囲指定での項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <returns></returns>
            protected virtual IMototyouDisplayZibunItemCollection CreateRangeItemCollection(MototyouQueryParameter queryParameter)
            {
                var useData = this.CreateMototyouItemUseData(
                    queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType,
                    queryParameter.OptionComposite.QueryOption.SyuukeiKeisikiApplyingWay);
                var itemCollection = new MototyouDisplayZibunItemCollection(useData, queryParameter.OptionComposite.QueryOption.SyuukeiKeisiki);

                this.AddRangeItemToItemCollection(
                    queryParameter.Kesn,
                    itemCollection,
                    queryParameter.QueryCondition.QueryConditionRange,
                    this.KamokuFactory.GetKamokuOutputOrder(queryParameter.KamokuOutputOrder),
                    queryParameter.OptionComposite.QueryOption,
                    queryParameter.OptionComposite.QueryOption.SyuukeiKeisikiApplyingWay);

                return itemCollection;
            }

            /// <summary>
            /// 項目個別指定での項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <returns></returns>
            protected virtual IMototyouDisplayZibunItemCollection CreateKobetuItemCollection(MototyouQueryParameter queryParameter)
            {
                var useData = this.CreateMototyouItemUseData(
                    queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType,
                    queryParameter.OptionComposite.QueryOption.SyuukeiKeisikiApplyingWay);
                var itemCollection = new MototyouDisplayZibunItemCollection(useData, queryParameter.OptionComposite.QueryOption.SyuukeiKeisiki);

                queryParameter.QueryCondition.KobetuSiteiItemList.ForEachIfNotNull(item => this.AddKobetuItemToItemCollection(
                    queryParameter.Kesn,
                    itemCollection,
                    item,
                    queryParameter.QueryCondition.MototyouMasterRangeQueryConditionType,
                    queryParameter.OptionComposite.QueryOption.SyuukeiKeisikiApplyingWay));

                return itemCollection;
            }

            /// <summary>
            /// 範囲パターン単位の元帳項目コレクションを作成して返す
            /// </summary>
            /// <param name="queryParameter"></param>
            /// <param name="mototyouPattern"></param>
            /// <returns></returns>
            protected virtual IMototyouZibunItemCollection CreateRangePatternUnitItemCollection(MototyouQueryParameter queryParameter, MototyouQueryConditionPattern mototyouPattern)
            {
                var useData = this.CreateMototyouItemUseData(
                        MototyouMasterRangeQueryConditionType.Range,
                        mototyouPattern.SyuukeiKeisikiApplyingWay);
                //// 集計形式の適用が個別指定となっている場合
                if (mototyouPattern.SyuukeiKeisikiApplyingWay == MototyouSyuukeiKeisikiApplyingWay.KobetuSitei)
                {
                    //// 個別の範囲ごとにコレクションを作成してそれを一つのコレクションにまとめる
                    var collections = new List<IMototyouZibunItemCollection>();
                    foreach (var item in mototyouPattern.Items)
                    {
                        var itemCollection = new MototyouZibunItemCollection(useData, item.SyuukeiKeisiki);

                        this.AddRangeItemToItemCollection(
                            queryParameter.Kesn,
                            itemCollection,
                            item,
                            this.KamokuFactory.GetKamokuOutputOrder(mototyouPattern.KamokuOutputOrder),
                            mototyouPattern,
                            mototyouPattern.SyuukeiKeisikiApplyingWay);

                        collections.Add(itemCollection);
                    }

                    return new MototyouZibunItemCollection(collections);
                }
                else
                {
                    //// 一つのコレクションに全ての範囲項目を追加していく
                    var itemCollection = new MototyouZibunItemCollection(useData, mototyouPattern.SyuukeiKeisiki);
                    foreach (var item in mototyouPattern.Items)
                    {
                        this.AddRangeItemToItemCollection(
                            queryParameter.Kesn,
                            itemCollection,
                            item,
                            this.KamokuFactory.GetKamokuOutputOrder(mototyouPattern.KamokuOutputOrder),
                            mototyouPattern,
                            mototyouPattern.SyuukeiKeisikiApplyingWay);
                    }

                    return itemCollection;
                }
            }

            /// <summary>
            /// 個別パターン単位の元帳コレクションを作成して返す
            /// </summary>
            /// <param name="kesn"></param>
            /// <param name="mototyouPattern"></param>
            /// <returns></returns>
            protected virtual IMototyouZibunItemCollection CreateKobetuPatternUnitItemCollection(int kesn, MototyouQueryConditionPattern mototyouPattern)
            {
                var useData = this.CreateMototyouItemUseData(
                    MototyouMasterRangeQueryConditionType.Kobetu,
                    mototyouPattern.SyuukeiKeisikiApplyingWay);
                var itemCollection = new MototyouZibunItemCollection(useData, mototyouPattern.SyuukeiKeisiki);

                mototyouPattern.Items.ForEachIfNotNull(item => this.AddKobetuItemToItemCollection(
                    kesn,
                    itemCollection,
                    item,
                    MototyouMasterRangeQueryConditionType.Kobetu,
                    mototyouPattern.SyuukeiKeisikiApplyingWay));

                return itemCollection;
            }

            protected abstract void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay);

            protected abstract void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay);

            /// <summary>
            /// 使用するデータの組み合わせ作成
            /// </summary>
            /// <param name="masterRangeQueryConditionType"></param>
            /// <param name="syuukeiKeisikiApplyingWay"></param>
            /// <returns></returns>
            protected virtual MototyouItemUseKobetuSetting CreateMototyouItemUseData(MototyouMasterRangeQueryConditionType masterRangeQueryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                MototyouItemUseKobetuSetting useData = 0;

                //// 個別ページ設定を使用しているかどうか
                if (masterRangeQueryConditionType == MototyouMasterRangeQueryConditionType.KobetuPage)
                {
                    useData |= MototyouItemUseKobetuSetting.Page;
                }

                //// 個別で集計形式を設定するかどうか
                if (syuukeiKeisikiApplyingWay == MototyouSyuukeiKeisikiApplyingWay.ReferenceMasterInfo
                    || (syuukeiKeisikiApplyingWay == MototyouSyuukeiKeisikiApplyingWay.KobetuSitei && masterRangeQueryConditionType.IsKobetu()))
                {
                    useData |= MototyouItemUseKobetuSetting.SyuukeiKeisiki;
                }

                return useData;
            }

            /// <summary>
            /// 個別で設定する集計形式を取得する
            /// 集計形式を全体に適用する場合はnullを返す
            /// </summary>
            /// <param name="masterRangeQueryConditionType"></param>
            /// <param name="syuukeiKeisikiApplyingWay"></param>
            /// <param name="kobetuSiteiItem"></param>
            /// <param name="syuukeiKubun"></param>
            /// <returns></returns>
            protected MototyouSyuukeiKeisiki? GetUseKobetuSyuukeiKeisiki(MototyouMasterRangeQueryConditionType masterRangeQueryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay, IMototyouQueryConditionKobetuSiteiItem kobetuSiteiItem, MasterSyuukeiKubun syuukeiKubun)
            {
                switch (syuukeiKeisikiApplyingWay)
                {
                    case MototyouSyuukeiKeisikiApplyingWay.KobetuSitei:
                        return kobetuSiteiItem.SyuukeiKeisiki;
                    case MototyouSyuukeiKeisikiApplyingWay.ReferenceMasterInfo:
                        return (MototyouSyuukeiKeisiki)syuukeiKubun;
                    default:
                        return null;
                }
            }

            protected MototyouZeiKubun CreateZeiKubun(Kamoku kamoku)
            {
                return this.ZeiKubunFactory.CreateZibunItemZeikubun(kamoku);
            }

            protected IOrderedEnumerable<TItem> SortKamoku<TItem>(IEnumerable<TItem> items, KamokuOutputOrder kamokuOutputOrder)
                where TItem : KamokuMototyouZibunItem
            {
                //// 明細科目なら引数の科目並び順で、それ以外なら内部コード順でソート
                switch (this.QueryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku ? kamokuOutputOrder : KamokuOutputOrder.ByInnerCode)
                {
                    case KamokuOutputOrder.ByOutputOrderCode:
                        return items.OrderBy(item => item.Kamoku.OutputOrder).ThenBy(item => item.Kamoku.InputCode);
                    case KamokuOutputOrder.ByInputCode:
                        return items.OrderBy(item => item.Kamoku.InputCode);
                    default:
                        return items.OrderBy(item => item.Kamoku.Kicd);
                }
            }

            protected IOrderedEnumerable<TItem> SortKamoku<TItem>(IOrderedEnumerable<TItem> items, KamokuOutputOrder kamokuOutputOrder)
                where TItem : KamokuMototyouZibunItem
            {
                //// 明細科目なら引数の科目並び順で、それ以外なら内部コード順でソート
                switch (this.QueryParameter.OptionComposite.QueryOption.KamokuType == MototyouKamokuType.MeisaiKamoku ? kamokuOutputOrder : KamokuOutputOrder.ByInnerCode)
                {
                    case KamokuOutputOrder.ByOutputOrderCode:
                        return items.ThenBy(item => item.Kamoku.OutputOrder).ThenBy(item => item.Kamoku.InputCode);
                    case KamokuOutputOrder.ByInputCode:
                        return items.ThenBy(item => item.Kamoku.InputCode);
                    default:
                        return items.ThenBy(item => item.Kamoku.Kicd);
                }
            }

            private IList<MototyouQueryConditionPattern> FindMototyouPatternRangeList(MototyouQueryParameter queryParameter)
            {
                return this.queryConditionPatternRepository.FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNoRange(
                    queryParameter.Kesn,
                    queryParameter.OptionComposite.QueryOption.MototyouType,
                    queryParameter.OptionComposite.QueryOption.BumonType,
                    queryParameter.OptionComposite.QueryOption.KamokuType.GetKamokuKubun(),
                    queryParameter.QueryCondition.QueryConditionPatternType,
                    queryParameter.QueryCondition.QueryConditionRange.StartMototyouQueryConditionPatternNo,
                    queryParameter.QueryCondition.QueryConditionRange.EndMototyouQueryConditionPatternNo);
            }
        }

        protected abstract class MototyouKamokuFactory
        {
            [AutoInjection]
            private IMasterFindServiceWithSecurity masterFindServiceWithSecurity = null;
            [AutoInjection]
            private ISyouhizeiMasterRepository syouhizeiMasterRepository = null;
            [AutoInjection]
            private ITokuteiSyuunyuuKamokuRepository tokuteiSyuunyuuKamokuRepository = null;

            public MototyouKamokuFactory(MototyouQueryParameter queryParameter, InjectionContainer container)
            {
                container.InjectDependeciesToAutoInjectionMembers(this);
                this.QueryParameter = queryParameter;
                this.KamokuList = this.masterFindServiceWithSecurity.FindKamokuByKesnOrderByKamokuOutputOrderWithSecurity(queryParameter.Kesn, KamokuOutputOrder.ByInnerCode, SecurityKubun.Output, queryParameter.SecurityContext);

                var syouhizeiMaster = this.syouhizeiMasterRepository.FindByKesn(queryParameter.Kesn);
                var tokuteiSyuunyuuKamokuList = this.tokuteiSyuunyuuKamokuRepository.FindByKesn(queryParameter.Kesn);
                this.MeisaiKamokuList = this.KamokuList.Where(kamoku => kamoku.Kubun == KamokuKubun.Meisai)
                    .Select(kamoku =>
                    {
                        if (syouhizeiMaster.IsTokuteiSyuunyuuTokureiKeisan && kamoku.SyoriGroup == KamokuSyoriGroup.Taisyougai)
                        {
                            var tokuteiSyuunyuuKamoku = tokuteiSyuunyuuKamokuList.FirstOrDefault(tsKamoku => tsKamoku.Kicd == kamoku.Kicd);
                            if (tokuteiSyuunyuuKamoku != null)
                            {
                                switch (tokuteiSyuunyuuKamoku.TokuteiSyuunyuuKubun)
                                {
                                    case TokuteiSyuunyuuKubun.TokuteiSyuunyuu:
                                        kamoku.KazeiKubun = KazeiKubun.特定収入;
                                        break;
                                    case TokuteiSyuunyuuKubun.HutokuteiSyuunyuu:
                                        kamoku.KazeiKubun = KazeiKubun.使途不明特定収入;
                                        break;
                                    case TokuteiSyuunyuuKubun.TaisyougaiTokuteiSyuunyuu:
                                        kamoku.KazeiKubun = KazeiKubun.外特定収入;
                                        break;
                                }
                            }
                        }

                        return kamoku;
                    })
                    .OrderBy(kamoku => kamoku.Kicd).ToList();
            }

            protected IList<Kamoku> KamokuList { get; private set; }

            protected IList<Kamoku> MeisaiKamokuList { get; private set; }

            protected MototyouQueryParameter QueryParameter { get; }

            /// <summary>
            /// 明細科目のコレクションからオプションの科目区分のクラスのリストを作成して返す
            /// </summary>
            /// <param name="kamokuInnerCodes"></param>
            /// <param name="range"></param>
            /// <returns></returns>
            public abstract IList<IMototyouKamoku> CreateMototyouKamokuList(IEnumerable<IKamokuInnerCode> kamokuInnerCodes, IMototyouQueryConditionRange range);

            /// <summary>
            /// オプションの科目区分のクラスを取得する
            /// </summary>
            /// <param name="kobetu"></param>
            /// <returns></returns>
            public abstract IMototyouKamoku GetMototyouKamoku(IMototyouQueryConditionKobetuSiteiItem kobetu);

            /// <summary>
            /// オプションの科目区分のクラスを取得する
            /// </summary>
            /// <param name="kicd"></param>
            /// <returns></returns>
            public abstract IMototyouKamoku GetMototyouKamoku(string kicd);

            public abstract Range<string> GetKicdRange(IMototyouQueryConditionRange range);

            public abstract Range<string> GetKicdRange(string kicd);

            /// <summary>
            /// 明細科目なら引数をそのまま、集計科目なら内部コードのKamokuOutputOrderを返す
            /// </summary>
            /// <param name="kamokuOutputOrder"></param>
            /// <returns></returns>
            public abstract KamokuOutputOrder GetKamokuOutputOrder(KamokuOutputOrder kamokuOutputOrder);
        }

        protected class MototyouMeisaiKamokuFactory : MototyouKamokuFactory
        {
            private IDictionary<string, IMototyouKamoku> mototyouKamokuDictionary;

            public MototyouMeisaiKamokuFactory(MototyouQueryParameter queryParameter, InjectionContainer container)
                : base(queryParameter, container)
            {
                this.mototyouKamokuDictionary = this.MeisaiKamokuList.Select(kamoku => this.CreateMototyouMeisaiKamoku(kamoku)).ToDictionary(kamoku => kamoku.Kicd);
            }

            public override IList<IMototyouKamoku> CreateMototyouKamokuList(IEnumerable<IKamokuInnerCode> kamokuInnerCodes, IMototyouQueryConditionRange range)
            {
                //// kamokuInnerCodesがそもそも範囲指定内の科目しか入っていないはず
                return kamokuInnerCodes.Select(k => this.GetMototyouKamoku(k.Kicd)).Where(k => k?.Kicd != null).ToList();
            }

            public override IMototyouKamoku GetMototyouKamoku(IMototyouQueryConditionKobetuSiteiItem kobetu)
            {
                return this.mototyouKamokuDictionary.GetValue(kobetu.Kamoku.Kicd, null);
            }

            public override IMototyouKamoku GetMototyouKamoku(string kicd)
            {
                return this.mototyouKamokuDictionary.GetValue(kicd, null);
            }

            public override Range<string> GetKicdRange(IMototyouQueryConditionRange range)
            {
                return new Range<string>(range.StartKamoku?.Kicd, range.EndKamoku?.Kicd);
            }

            public override Range<string> GetKicdRange(string kicd)
            {
                return new Range<string>(kicd, kicd);
            }

            public override KamokuOutputOrder GetKamokuOutputOrder(KamokuOutputOrder kamokuOutputOrder)
            {
                return kamokuOutputOrder;
            }

            private IMototyouKamoku CreateMototyouMeisaiKamoku(Kamoku meisaiKamoku)
            {
                return new MototyouMeisaiKamoku(meisaiKamoku);
            }
        }

        protected class MototyouSyuukeiKamokuFactory : MototyouKamokuFactory
        {
            private KamokuKubun kamokuKubun;
            private int kubunLength;
            private IDictionary<string, IMototyouKamoku> mototyouKamokuDictionary;

            public MototyouSyuukeiKamokuFactory(MototyouQueryParameter queryParameter, InjectionContainer container)
                : base(queryParameter, container)
            {
                this.kamokuKubun = queryParameter.OptionComposite.QueryOption.KamokuType.GetKamokuKubun();
                this.kubunLength = (int)this.kamokuKubun * 3; // 集計小科目、小科目以外は来ないはず
                this.mototyouKamokuDictionary = this.KamokuList.Where(kamoku => kamoku.Kubun == this.kamokuKubun).Select(kamoku => this.CreateMototyouSyuukeiKamoku(kamoku)).ToDictionary(kamoku => kamoku.Kicd);
            }

            public override IList<IMototyouKamoku> CreateMototyouKamokuList(IEnumerable<IKamokuInnerCode> kamokuInnerCodes, IMototyouQueryConditionRange range)
            {
                //// kamokuInnerCodesがそもそも範囲指定内の科目しか入っていないはず
                return kamokuInnerCodes.GroupBy(k => k.Kicd.Substring(0, this.kubunLength)).Select(group => this.GetMototyouKamoku(group.Key.PadRight(15, '0'))).ToList();
            }

            public override IMototyouKamoku GetMototyouKamoku(IMototyouQueryConditionKobetuSiteiItem kobetu)
            {
                return this.mototyouKamokuDictionary.GetValue(kobetu.Kamoku.Kicd, null);
            }

            public override IMototyouKamoku GetMototyouKamoku(string kicd)
            {
                return this.mototyouKamokuDictionary.GetValue(kicd, null);
            }

            public override Range<string> GetKicdRange(IMototyouQueryConditionRange range)
            {
                //// 集計科目の時は諸口を含まない
                return new Range<string>(range.StartKamoku?.Kicd ?? "010000000000000", range.EndKamoku?.Kicd.Substring(0, this.kubunLength).PadRight(15, '9'));
            }

            public override Range<string> GetKicdRange(string kicd)
            {
                return new Range<string>(kicd, kicd.Substring(0, this.kubunLength).PadRight(15, '9'));
            }

            public override KamokuOutputOrder GetKamokuOutputOrder(KamokuOutputOrder kamokuOutputOrder)
            {
                return KamokuOutputOrder.ByInnerCode;
            }

            private IMototyouKamoku CreateMototyouSyuukeiKamoku(Kamoku syuukeiKamoku)
            {
                var kicdSubString = syuukeiKamoku.Kicd.Substring(0, this.kubunLength);
                return new MototyouSyuukeiKamoku(syuukeiKamoku, this.MeisaiKamokuList.SkipWhile(kamoku => !kamoku.Kicd.StartsWith(kicdSubString)).TakeWhile(kamoku => kamoku.Kicd.StartsWith(kicdSubString)).ToDictionary(kamoku => kamoku.Kicd));
            }
        }

        protected class MototyouKisokugaiSyuukeiKamokuFactory : MototyouKamokuFactory
        {
            [AutoInjection]
            private IKamokuRepository kamokuRepository = null;
            [AutoInjection]
            private IKisokugaiSyuukeiKamokuRepository kisokugaiSyuukeiKamokuRepository = null;
            [AutoInjection]
            private IKisokugaiSyuukeiKamokuUtiwakeRepository kisokugaiSyuukeiKamokuUtiwakeRepository = null;

            private IDictionary<string, IMototyouKamoku> mototyouKamokuDictionary;

            public MototyouKisokugaiSyuukeiKamokuFactory(MototyouQueryParameter queryParameter, InjectionContainer container)
                : base(queryParameter, container)
            {
                this.mototyouKamokuDictionary = this.kisokugaiSyuukeiKamokuRepository.FindByKesn(queryParameter.Kesn).Select(kamoku => this.CreateMototyouKisokugaiSyuukeiKamoku(kamoku)).ToDictionary(kamoku => kamoku.Kicd);
            }

            public override IList<IMototyouKamoku> CreateMototyouKamokuList(IEnumerable<IKamokuInnerCode> kamokuInnerCodes, IMototyouQueryConditionRange range)
            {
                //// 範囲指定内かつ内訳科目と引数のKicdで一致する部分がある規則外集計科目のリストを返す
                return this.mototyouKamokuDictionary.Values.Where(kamoku => kamoku.Kicd.CompareTo(range.StartPkicd) >= 0 && kamoku.Kicd.CompareTo(range.EndPkicd ?? "999999999999999") <= 0 && kamokuInnerCodes.Any(k => kamoku.IsIncludeKamoku(k.Kicd))).ToList();
            }

            public override IMototyouKamoku GetMototyouKamoku(IMototyouQueryConditionKobetuSiteiItem kobetu)
            {
                return this.mototyouKamokuDictionary.GetValue(kobetu.Pkicd, null);
            }

            public override IMototyouKamoku GetMototyouKamoku(string kicd)
            {
                return this.mototyouKamokuDictionary.GetValue(kicd, null);
            }

            public override Range<string> GetKicdRange(IMototyouQueryConditionRange range)
            {
                //// 集計科目の時は諸口を含まない
                return new Range<string>("010000000000000", null);
            }

            public override Range<string> GetKicdRange(string kicd)
            {
                return new Range<string>("010000000000000", null);
            }

            public override KamokuOutputOrder GetKamokuOutputOrder(KamokuOutputOrder kamokuOutputOrder)
            {
                return KamokuOutputOrder.ByInnerCode;
            }

            private IMototyouKamoku CreateMototyouKisokugaiSyuukeiKamoku(KisokugaiSyuukeiKamoku kisokugaiSyuukeiKamoku)
            {
                var utiwakeKicdList = this.kisokugaiSyuukeiKamokuUtiwakeRepository.GetAllChildrenKicdListByKesnAndKicd(kisokugaiSyuukeiKamoku.Kesn, kisokugaiSyuukeiKamoku.Pkicd, true);
                var zeiKubunKamoku = this.QueryParameter.OptionComposite.Option.UseTitleRegisterdFirstKamokuKazeiKubunIfKisokugaiSyuukeiKamoku ? this.kamokuRepository.FindByKesnAndKicd(kisokugaiSyuukeiKamoku.Kesn, utiwakeKicdList.FirstOrDefault()) : null;
                var utiwakeKicdFormatList = utiwakeKicdList.Select(kicd => new KamokuInnerCodeFormat(kicd)).ToList();
                var utiwakeKamokuDictionary = this.MeisaiKamokuList.Where(kamoku => utiwakeKicdFormatList.Any(kicdFormat => kamoku.Kicd.StartsWith(kicdFormat.GetKicdSubstring()))).ToDictionary(kamoku => kamoku.Kicd);

                return new MototyouKisokugaiSyuukeiKamoku(kisokugaiSyuukeiKamoku, utiwakeKamokuDictionary, zeiKubunKamoku);
            }
        }
    }
}
