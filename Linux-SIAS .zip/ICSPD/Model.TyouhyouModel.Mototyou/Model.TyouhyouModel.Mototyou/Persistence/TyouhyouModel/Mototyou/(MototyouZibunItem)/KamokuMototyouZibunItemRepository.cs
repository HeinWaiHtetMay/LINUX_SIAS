﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class KamokuMototyouZibunItemRepository : AbstractMototyouZibunItemRepository
    {
        protected override CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
        {
            return new KamokuCollectionCreater(queryParameter, kamokuFactory, container);
        }

        protected class KamokuCollectionCreater : CollectionCreater
        {
            [AutoInjection]
            private IKamokuZandakaRepository kamokuZandakaRepository = null;

            public KamokuCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
                : base(queryParameter, kamokuFactory, container)
            {
            }

            protected override void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange)
            {
                queryConditionRange.StartKamoku = null;
                queryConditionRange.EndKamoku = null;
                queryConditionRange.StartPkicd = null;
                queryConditionRange.EndPkicd = null;
            }

            protected override void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                var kamokuItemList = new List<KamokuMototyouZibunItem>();
                //// 指定された範囲の科目取得
                var kicdRange = this.KamokuFactory.GetKicdRange(queryConditionRange);
                var kamokuZandakaList = this.kamokuZandakaRepository.FindZandakaWithNameByPrimaryKeyAndKamokuKanaRangesOrderByKamokuOutputOrder(
                    this.QueryParameter.Kesn,
                    kicdRange.Start,
                    kicdRange.End,
                    null,
                    null,
                    kamokuOutputOrder,
                    this.QueryParameter.SecurityContext,
                    SecurityKubun.Output);

                //// 範囲指定で集計形式を個別に設定する = マスター設定に従う
                if (itemCollection.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki))
                {
                    kamokuZandakaList.ForEachIfNotNull(entity =>
                    {
                        //// マスター設定に従うが設定できるのは科目分類が明細科目の時のみ
                        var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                        kamokuItemList.Add(new KamokuMototyouZibunItem(itemCollection, kamoku, entity.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), kamoku.SyuukeiKeisiki, null, null));
                    });
                }
                else
                {
                    this.KamokuFactory.CreateMototyouKamokuList(kamokuZandakaList, queryConditionRange).ForEachIfNotNull(kamoku =>
                        kamokuItemList.Add(new KamokuMototyouZibunItem(itemCollection, kamoku, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null)));
                }

                itemCollection.AddRangeIfNotNull(this.SortKamoku(kamokuItemList, kamokuOutputOrder));
            }

            protected override void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                if (kobetuItem.Kamoku == null && string.IsNullOrEmpty(kobetuItem.Pkicd))
                {
                    return;
                }

                var kamoku = this.KamokuFactory.GetMototyouKamoku(kobetuItem);

                //// 個別で設定する集計形式の取得
                var syuukeiKeisiki = this.GetUseKobetuSyuukeiKeisiki(
                    queryConditionType,
                    syuukeiKeisikiApplyingWay,
                    kobetuItem,
                    kobetuItem.Kamoku?.SyuukeiKubun ?? default(MasterSyuukeiKubun));

                itemCollection.Add(new KamokuMototyouZibunItem(itemCollection, kamoku, kobetuItem.Kamoku.TaisyakuZokusei, this.CreateZeiKubun(kobetuItem.Kamoku), syuukeiKeisiki, kobetuItem.StartPageNo, kobetuItem.EndPageNo));
            }
        }
    }
}
