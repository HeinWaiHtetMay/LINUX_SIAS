﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Core.Injection;
    using Icsp.Framework.Core.Types;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.SecurityModel;
    using Icsp.Open21.Domain.SyouhizeiModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;
    using Icsp.Open21.Domain.ZandakaYosanModel;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Repository]
    public class BumonMototyouZibunItemRepository : AbstractMototyouZibunItemRepository
    {
        protected override CollectionCreater CreateCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
        {
            return new BumonKamokuCollectionCreater(queryParameter, kamokuFactory, container);
        }

        protected class BumonKamokuCollectionCreater : CollectionCreater
        {
            [AutoInjection]
            private IBumonKamokuZandakaRepository bumonKamokuZandakaRepository = null;

            public BumonKamokuCollectionCreater(MototyouQueryParameter queryParameter, MototyouKamokuFactory kamokuFactory, InjectionContainer container)
                : base(queryParameter, kamokuFactory, container)
            {
            }

            protected override void ClearQueryConditionRange(MototyouQueryConditionRange queryConditionRange)
            {
                queryConditionRange.StartKamoku = null;
                queryConditionRange.EndKamoku = null;
                queryConditionRange.StartPkicd = null;
                queryConditionRange.EndPkicd = null;
                queryConditionRange.StartBumonCode = null;
                queryConditionRange.EndBumonCode = null;
            }

            protected override void AddRangeItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionRange queryConditionRange, KamokuOutputOrder kamokuOutputOrder, IMototyouOutputOrders outputOrders, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                var bumonItemList = new List<BumonMototyouZibunItem>();
                var kicdRange = this.KamokuFactory.GetKicdRange(queryConditionRange);
                var bumonKamokuList = this.FindBumonKamokuList(kicdRange.Start, kicdRange.End, queryConditionRange.StartBumonCode, queryConditionRange.EndBumonCode, kamokuOutputOrder);

                if (itemCollection.UseKobetuSetting.HasFlag(MototyouItemUseKobetuSetting.SyuukeiKeisiki))
                {
                    bumonKamokuList.ForEachIfNotNull(entity =>
                    {
                        var kamoku = this.KamokuFactory.GetMototyouKamoku(entity.Kicd);
                        bumonItemList.Add(new BumonMototyouZibunItem(itemCollection, entity, kamoku, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), (MototyouSyuukeiKeisiki)entity.MasterSyuukeiKubun, null, null));
                    });
                }
                else
                {
                    var bumonGroups = bumonKamokuList.GroupBy(entity => ((IBumonCodeAndName)entity).Bcod);
                    foreach (var group in bumonGroups)
                    {
                        var bumon = group.First();
                        var kamokus = this.KamokuFactory.CreateMototyouKamokuList(group, queryConditionRange);
                        kamokus.ForEachIfNotNull(kamoku => bumonItemList.Add(new BumonMototyouZibunItem(itemCollection, bumon, kamoku, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), null, null, null)));
                    }
                }

                itemCollection.AddRangeIfNotNull(this.SortItems(bumonItemList, kamokuOutputOrder, outputOrders.BumonMototyouOutputOrder));
            }

            protected override void AddKobetuItemToItemCollection(int kesn, IMototyouZibunItemCollection itemCollection, IMototyouQueryConditionKobetuSiteiItem kobetuItem, MototyouMasterRangeQueryConditionType queryConditionType, MototyouSyuukeiKeisikiApplyingWay syuukeiKeisikiApplyingWay)
            {
                if ((kobetuItem.Kamoku == null && string.IsNullOrEmpty(kobetuItem.Pkicd)) || string.IsNullOrEmpty(kobetuItem.BumonCode))
                {
                    return;
                }

                var entity = this.FindBumonKamoku(kobetuItem.Kamoku?.Kicd, kobetuItem.BumonCode);

                var syuukeiKeisiki = this.GetUseKobetuSyuukeiKeisiki(
                    queryConditionType,
                    syuukeiKeisikiApplyingWay,
                    kobetuItem,
                    entity.MasterSyuukeiKubun);

                var kamoku = this.KamokuFactory.GetMototyouKamoku(kobetuItem);
                itemCollection.Add(new BumonMototyouZibunItem(itemCollection, entity, kamoku, kamoku.TaisyakuZokusei, this.CreateZeiKubun(kamoku.ZeiKubunKamoku), syuukeiKeisiki, kobetuItem.StartPageNo, kobetuItem.EndPageNo));
            }

            private IEnumerable<BumonMototyouZibunItem> SortItems(IEnumerable<BumonMototyouZibunItem> items, KamokuOutputOrder kamokuOutputOrder, BumonMototyouOutputOrder mototyouOutputOrder)
            {
                switch (mototyouOutputOrder)
                {
                    case BumonMototyouOutputOrder.BumonKamoku:
                        return this.SortKamoku(items.OrderBy(item => item.Bcod), kamokuOutputOrder);
                    case BumonMototyouOutputOrder.KamokuBumon:
                        return this.SortKamoku(items, kamokuOutputOrder).ThenBy(item => item.Bcod);
                    default:
                        return items;
                }
            }

            private IList<IBumonKamokuWithName> FindBumonKamokuList(string startKicd, string endKicd, string startBcod, string endBcod, KamokuOutputOrder kamokuOutputOrder)
            {
                return this.bumonKamokuZandakaRepository.FindCodeWithNameByPrimaryKeyRangesWithSecurity(
                    this.QueryParameter.Kesn,
                    startKicd,
                    endKicd,
                    startBcod,
                    endBcod,
                    kamokuOutputOrder,
                    this.QueryParameter.OptionComposite.QueryOption.BumonType == MototyouBumonType.SyuukeiBumon,
                    this.QueryParameter.SecurityContext,
                    SecurityKubun.Output);
            }

            private IBumonKamokuWithName FindBumonKamoku(string kicd, string bcod)
            {
                var kicdRange = this.KamokuFactory.GetKicdRange(kicd);
                return this.FindBumonKamokuList(kicdRange.Start, kicdRange.End, bcod, bcod, KamokuOutputOrder.ByInnerCode).FirstOrDefault();
            }
        }
    }
}
