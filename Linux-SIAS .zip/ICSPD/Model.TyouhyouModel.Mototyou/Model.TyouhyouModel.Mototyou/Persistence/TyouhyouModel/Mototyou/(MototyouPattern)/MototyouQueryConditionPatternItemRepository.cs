﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouQueryConditionPatternItemRepository : IMototyouQueryConditionPatternItemRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private IKamokuRepository kamokuRepository = null;

        public virtual IList<MototyouQueryConditionPatternItem> FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNo(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int patternNo)
        {
            var kamokuList = this.kamokuRepository.FindByKesnAndKamokuKubun(kesn, kamokuKubun);
            return this.dbc.QueryForList(
                "SELECT seq, skei, bcod1, kicd1, ecod1, tcod1, bcod2, kicd2, ecod2, tcod2 " +
                "FROM ldpsh " +
                "Where kesn = :p AND lmod = :p AND bmod = :p AND kmod = :p AND smod = :p AND lptn = :p",
                (values, no) =>
                {
                    var seq = (int)(short)values[0];
                    var row = new MototyouQueryConditionPatternItem(seq);
                    row.SyuukeiKeisiki = (MototyouSyuukeiKeisiki)DbNullConverter.ToNullableShort(values[1]); // ｓｋｅｉ
                    row.Bcod1 = DbNullConverter.ToString(values[2]); // 部門コード１
                    row.Kicd1 = DbNullConverter.ToString(values[3]); // 科目コード1
                    row.Ecod1 = DbNullConverter.ToString(values[4]); // 枝番コード1
                    row.Tcod1 = DbNullConverter.ToString(values[5]); // 取引先コード1
                    row.Bcod2 = DbNullConverter.ToString(values[6]); // 部門コード2
                    row.Kicd2 = DbNullConverter.ToString(values[7]); // 科目コード2
                    row.Ecod2 = DbNullConverter.ToString(values[8]); // 枝番コード2
                    row.Tcod2 = DbNullConverter.ToString(values[9]); // 取引先コード2

                    row.Kamoku1 = kamokuList.FirstOrDefault(kamoku => kamoku.Kicd == row.Kicd1);
                    row.Kamoku2 = kamokuList.FirstOrDefault(kamoku => kamoku.Kicd == row.Kicd2);
                    return row;
                },
                () => new List<MototyouQueryConditionPatternItem>(),
                kesn,
                (int)mototyouType - 1, // 画面では1始まりだがDBでは0始まりなので1引く
                (int)bumonType,
                (int)kamokuKubun,
                patternType == MototyouQueryConditionPatternType.Kobetu ? 0 : 1, // 画面では1:範囲パターン,2:個別パターンだがDBでは0:個別パターン,1:範囲パターン
                patternNo);
        }
    }
}
