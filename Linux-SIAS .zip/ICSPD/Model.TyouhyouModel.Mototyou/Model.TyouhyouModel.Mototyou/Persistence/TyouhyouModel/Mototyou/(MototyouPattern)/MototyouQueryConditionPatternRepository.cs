﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Collections;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Data;
    using Icsp.Open21.Domain.KaisyaModel;
    using Icsp.Open21.Domain.MasterModel;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class MototyouQueryConditionPatternRepository : IMototyouQueryConditionPatternRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;
        [AutoInjection]
        private IMototyouQueryConditionPatternItemRepository mototyouPatternItemRepository = null;

        public virtual MototyouQueryConditionPattern FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNo(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int patternNo)
        {
            return this.FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNoRange(kesn, mototyouType, bumonType, kamokuKubun, patternType, patternNo, patternNo).FirstOrDefault();
        }

        public virtual IList<MototyouQueryConditionPattern> FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNoRange(int kesn, MototyouType mototyouType, MototyouBumonType bumonType, KamokuKubun kamokuKubun, MototyouQueryConditionPatternType patternType, int? startPatternNo, int? endPatternNo)
        {
            SqlStatementBuilder sqlBuilder = new SqlStatementBuilder();
            sqlBuilder.AppendLine("SELECT kesn, lmod, bmod, kmod, smod, lptn, lnam, kjun, ojun, skeit, skei ");
            sqlBuilder.AppendLine("FROM ldpnm ");
            sqlBuilder.AppendLine("WHERE kesn = :p ", kesn);
            sqlBuilder.AppendLine("AND lmod = :p ", (int)mototyouType - 1); // 画面では1始まりだがDBでは0始まりなので1引く
            var bmod =
                mototyouType == MototyouType.BumonMototyou || mototyouType == MototyouType.BumonKamokuEdabanMototyou || mototyouType == MototyouType.BumonKamokuTorihikisakiMototyou
                ? (int)bumonType : 0;
            sqlBuilder.AppendLine("AND bmod = :p ", bmod);
            sqlBuilder.AppendLine("AND kmod = :p ", (int)kamokuKubun);
            sqlBuilder.AppendLine("AND smod = :p ", patternType == MototyouQueryConditionPatternType.Kobetu ? 0 : 1); // 画面では1:範囲パターン,2:個別パターンだがDBでは0:個別パターン,1:範囲パターン
            sqlBuilder.AppendWhereStatementByIntRange("lptn", startPatternNo, endPatternNo, true);
            sqlBuilder.AppendLine("ORDER BY lptn");

            var patternList = this.dbc.QueryForList(
                sqlBuilder.GetSqlStatement(),
                (values, no) => this.MapRow(values),
                () => new List<MototyouQueryConditionPattern>(),
                sqlBuilder.GetSqlParameters());

            foreach (var pattern in patternList)
            {
                pattern.Items = this.mototyouPatternItemRepository.FindByKesnAndMototyouTypeAndBumonTypeAndKamokuKubunAndPatternTypeAndPatternNo(pattern.Kesn, pattern.MototyouType, pattern.BumonType, pattern.KamokuKubun, pattern.PatternType, pattern.PatternNo);
            }

            return patternList;
        }

        private MototyouQueryConditionPattern MapRow(object[] values)
        {
            var kesn = (int)(short)values[0];
            var lmod = (int)(short)values[1] + 1; // 元帳種類 画面では1始まりだがDBでは0始まりなので1足す
            var bmod = (int)(short)values[2]; // 部門種類
            var kmod = (int)(short)values[3]; // 科目種類
            var smod = (int)(short)values[4]; // パターン種類 画面では1:範囲パターン,2:個別パターンだがDBでは0:個別パターン,1:範囲パターン
            var lptn = (int)(short)values[5]; // パターン番号
            var row = new MototyouQueryConditionPattern(kesn, (MototyouType)lmod, (MototyouBumonType)bmod, (KamokuKubun)kmod, smod == 0 ? MototyouQueryConditionPatternType.Kobetu : MototyouQueryConditionPatternType.Range, lptn);
            row.PatternName = DbNullConverter.ToString(values[6]); // パターン名称
            row.KamokuOutputOrder = (KamokuOutputOrder)(short)values[7]; // 科目の並び
            row.OutputOrder = (short)values[8]; // 出力順
            row.SyuukeiKeisikiApplyingWay = (MototyouSyuukeiKeisikiApplyingWay)(short)values[9]; // 集計形式の適用
            row.SyuukeiKeisiki = (MototyouSyuukeiKeisiki)(short)values[10]; // 集計形式
            return row;
        }
    }
}
