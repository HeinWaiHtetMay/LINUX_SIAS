﻿namespace Icsp.Open21.Persistence.TyouhyouModel.Mototyou
{
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Core.Injection;
    using Icsp.Open21.Domain.TyouhyouModel.Mototyou;

    [EditorBrowsable(EditorBrowsableState.Never)]
    [Factory]
    public class MototyouRepositoryFactoryCreator : IMototyouRepositoryFactoryCreator
    {
        [AutoInjection]
        private InjectionContainer container = null;

        public virtual MototyouRepositoryFactory Create(MototyouType mototyouType)
        {
            switch (mototyouType)
            {
                case MototyouType.Mototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<KamokuMototyouRepository>(),
                        this.container.GetInstance<KamokuMototyouZibunItemRepository>(),
                        this.container.GetInstance<KamokuMototyouExportRepository>());
                case MototyouType.EdabanMototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<EdabanMototyouRepository>(),
                        this.container.GetInstance<EdabanMototyouZibunItemRepository>(),
                        this.container.GetInstance<EdabanMototyouExportRepository>());
                case MototyouType.BumonMototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<BumonMototyouRepository>(),
                        this.container.GetInstance<BumonMototyouZibunItemRepository>(),
                        this.container.GetInstance<BumonMototyouExportRepository>());
                case MototyouType.BumonKamokuEdabanMototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<BumonKamokuEdabanMototyouRepository>(),
                        this.container.GetInstance<BumonKamokuEdabanMototyouZibunItemRepository>(),
                        this.container.GetInstance<BumonKamokuEdabanMototyouExportRepository>());
                case MototyouType.TorihikisakiMototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<TorihikisakiMototyouRepository>(),
                        this.container.GetInstance<TorihikisakiMototyouZibunItemRepository>(),
                        this.container.GetInstance<TorihikisakiMototyouExportRepository>());
                case MototyouType.BumonKamokuTorihikisakiMototyou:
                    return new MototyouRepositoryFactory(
                        this.container.GetInstance<BumonKamokuTorihikisakiMototyouRepository>(),
                        this.container.GetInstance<BumonKamokuTorihikisakiMototyouZibunItemRepository>(),
                        this.container.GetInstance<BumonKamokuTorihikisakiMototyouExportRepository>());
                default:
                    return null;
            }
        }
    }
}
