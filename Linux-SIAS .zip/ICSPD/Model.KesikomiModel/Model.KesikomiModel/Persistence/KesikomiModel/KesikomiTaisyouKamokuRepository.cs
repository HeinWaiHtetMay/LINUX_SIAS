﻿namespace Icsp.Open21.Persistence.KesikomiModel
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using Icsp.Framework.Attributes;
    using Icsp.Framework.Data;
    using Icsp.Open21.Attributes;
    using Icsp.Open21.Domain.KesikomiModel;

    [Repository]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public class KesikomiTaisyouKamokuRepository : IKesikomiTaisyouKamokuRepository
    {
        [KaisyaDbAutoInjection]
        private IDbc dbc = null;

        public virtual IList<KesikomiTaisyouKamoku> FindByKesn(int kesn)
        {
            return this.dbc.QueryForList(
                "SELECT kesn, kicd, knri, fubn, fusr, fmod, ftim, lusr, lmod, ltim FROM kskmk WHERE kesn = :p ",
                (values, no) =>
                {
                    var kicd = values[1].ToString();
                    var row = new KesikomiTaisyouKamoku(kesn, kicd);
                    row.Knri = (int)(short)values[2]; // 管理単位
                    row.Fubn = (int)(short)values[3]; // 自動付番
                    row.Fusr = (int)values[4]; // 新規作成ﾕｰｻﾞｰ
                    row.Fmod = (int)values[5]; // 新規作成年月日
                    row.Ftim = (int)values[6]; // 新規作成時間
                    row.Lusr = (int)values[7]; // 最終変更ﾕｰｻﾞｰ
                    row.Lmod = (int)values[8]; // 最終変更年月日
                    row.Ltim = (int)values[9]; // 最終変更時間
                    return row;
                },
                () => new List<KesikomiTaisyouKamoku>(),
                kesn);
        }
    }
}
