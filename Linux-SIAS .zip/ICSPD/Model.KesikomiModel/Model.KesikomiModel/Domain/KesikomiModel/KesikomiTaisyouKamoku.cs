﻿using Icsp.Open21.Domain.DateTimeModel;

namespace Icsp.Open21.Domain.KesikomiModel
{
    public class KesikomiTaisyouKamoku : ICreatedAndLastUpdatedYmdHmsEntity
    {
        public KesikomiTaisyouKamoku(int kesn, string kicd)
        {
            this.Kesn = kesn;
            this.Kicd = kicd;
        }

        #region public properties

        /// <summary>
        /// 内部決算期（カラム名：kesn）
        /// </summary>
        public int Kesn { get; private set; }

        /// <summary>
        /// 科目内部コード（カラム名：kicd）
        /// </summary>
        public string Kicd { get; private set; }

        /// <summary>
        /// 管理単位（カラム名：knri）
        /// </summary>
        public int Knri { get; set; }

        /// <summary>
        /// 自動付番（カラム名：fubn）
        /// </summary>
        public int Fubn { get; set; }

        /// <summary>
        /// 新規作成ﾕｰｻﾞｰ（カラム名：fusr）
        /// </summary>
        public int Fusr { get; set; }

        /// <summary>
        /// 新規作成年月日（カラム名：fmod）
        /// </summary>
        public int Fmod { get; set; }

        /// <summary>
        /// 新規作成時間（カラム名：ftim）
        /// </summary>
        public int Ftim { get; set; }

        /// <summary>
        /// 最終変更ﾕｰｻﾞｰ（カラム名：lusr）
        /// </summary>
        public int Lusr { get; set; }

        /// <summary>
        /// 最終変更年月日（カラム名：lmod）
        /// </summary>
        public int Lmod { get; set; }

        /// <summary>
        /// 最終変更時間（カラム名：ltim）
        /// </summary>
        public int Ltim { get; set; }

        public int CreatedYmd { get => this.Fmod; set => this.Fmod = value; }

        public int CreatedHms { get => this.Ftim; set => this.Ftim = value; }

        public int LastUpdatedYmd { get => this.Lmod; set => this.Lmod = value; }

        public int LastUpdatedHms { get => this.Ltim; set => this.Ltim = value; }

        public SecondPrecision SecondPrecision => SecondPrecision.Second;
        #endregion
    }
}
