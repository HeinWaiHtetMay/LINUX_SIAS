﻿using System.Collections.Generic;

namespace Icsp.Open21.Domain.KesikomiModel
{
    public interface IKesikomiTaisyouKamokuRepository
    {
        IList<KesikomiTaisyouKamoku> FindByKesn(int kesn);
    }
}